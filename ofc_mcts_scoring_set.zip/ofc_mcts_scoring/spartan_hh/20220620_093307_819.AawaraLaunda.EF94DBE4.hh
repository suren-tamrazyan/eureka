{
    "stakes": 5,
    "handData": {"338194177": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Mayur2217",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ah1 Ks3 9c4/2d0 4s2 5h2 5c3 Kd4/7c0 7s0 Th0 Tc0 7h1",
            "win": 60,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "AawaraLaunda",
            "orderIndex": 0,
            "hero": true,
            "dead": "8s1 9d2 3c3 Qd4",
            "rows": "Ac0 As2 4c4/5d0 5s0 4d2 Jd3 Jc3/7d0 9s0 6d1 8c1 3s4",
            "win": -60,
            "playerId": "AawaraLaunda"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 06:33:07",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338194415": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "Mayur2217",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qd2 Qs4 Ah4/7s0 7d1 4s2 Jd3 Jc3/2c0 3c0 7c0 9c0 8c1",
            "win": 60,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "AawaraLaunda",
            "orderIndex": 1,
            "hero": true,
            "dead": "4h1 4c2 Ts3 Td4",
            "rows": "2s2 Qh3 As3/5d0 Js0 8h1 8s1 Jh4/Kh0 Kd0 Ks0 6d2 Ac4",
            "win": -60,
            "playerId": "AawaraLaunda"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 06:34:31",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338194586": [
        {
            "inFantasy": true,
            "result": -3,
            "playerName": "Mayur2217",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "5s0 8s0 Td0/6c0 8c0 Jc0 Qc0 Ac0/8h0 9h0 Th0 Jh0 Qh0",
            "win": 100,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "AawaraLaunda",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h1 2c2 5c3 7c4",
            "rows": "7h2 3h3 3c4/Ts0 4s1 6s2 Js3 6d4/5d0 9d0 Kd0 Ad0 2d1",
            "win": -100,
            "playerId": "AawaraLaunda"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 06:35:13",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338194691": [
        {
            "inFantasy": true,
            "result": 12,
            "playerName": "Mayur2217",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "7h0 7s0 Kd0/2s0 3s0 5s0 9s0 Qs0/2c0 4c0 6c0 9c0 Ac0",
            "win": 80,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "AawaraLaunda",
            "orderIndex": 1,
            "hero": true,
            "dead": "6d1 6s2 8h3 7d4",
            "rows": "Kh1 As3 9d4/2d0 4d0 4h1 6h2 2h3/5c0 Jc0 Qc0 7c2 Kc4",
            "win": -80,
            "playerId": "AawaraLaunda"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 06:36:04",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338194800": [
        {
            "inFantasy": false,
            "result": 60,
            "playerName": "Mayur2217",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Ks0 Js3/Ah0 2s1 6d1 Ac2 Jc4/4c0 9c0 Qc2 9h3 Qd4",
            "win": 140,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "AawaraLaunda",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qs1 5s2 2h3 7h4",
            "rows": "Ad0 As0 Ts3/3c0 6c0 8h2 8d3 5h4/Jd0 2d1 Kd1 5d2 3d4",
            "win": -100,
            "playerId": "AawaraLaunda"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "Santhoshkumarmu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kh0 7d3 Jh4/4h0 4s0 5c1 6s1 7s4/9d0 Tc0 7c2 9s2 Th3",
            "win": -40,
            "playerId": "Santhoshkumarmu"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 06:38:37",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338195092": [
        {
            "inFantasy": true,
            "result": 45,
            "playerName": "Mayur2217",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Jh0 Jc0 Kd0/7c0 7s0 9d0 9c0 Qs0/2h0 3d0 4c0 5s0 Ah0",
            "win": 85,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "AawaraLaunda",
            "orderIndex": 2,
            "hero": true,
            "dead": "Th1 8h2 2s3 8d4",
            "rows": "Kh0 Jd2 Qd3/4s0 5h1 3h2 3s3 5d4/6h0 6d0 6s0 9s1 Ks4",
            "win": -95,
            "playerId": "AawaraLaunda"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "Santhoshkumarmu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kc0 8c2 Qh4/4d0 Ac0 3c2 Ad3 As4/8s0 9h0 Td1 Js1 7d3",
            "win": 10,
            "playerId": "Santhoshkumarmu"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 06:40:36",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338195311": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "Mayur2217",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "9s2 9h3 Kc3/Ah0 Ad0 8c1 5c2 As4/5d0 6d0 7d0 Kd1 9d4",
            "win": 25,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "AawaraLaunda",
            "orderIndex": 0,
            "hero": true,
            "dead": "3h1 7s2 3c3 Jd4",
            "rows": "Ac0 4c3 Qd4/6c0 6h1 5s2 2s3 5h4/Td0 Tc0 Jh0 Th1 Js2",
            "win": -25,
            "playerId": "AawaraLaunda"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 06:42:32",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338195527": [
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "Mayur2217",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Kd3 Qh4/5h0 Ah0 4d1 Ac2 Td4/8s0 Jd0 8d1 Js2 Jh3",
            "win": 100,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "AawaraLaunda",
            "orderIndex": 1,
            "hero": true,
            "dead": "6s1 4h2 Ts3 Ad4",
            "rows": "Qs0 Kh0 Qd3/3d0 As0 2h2 2s3 7s4/9c0 5c1 5s1 7h2 6d4",
            "win": -100,
            "playerId": "AawaraLaunda"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 06:44:05",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338195692": [
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "Mayur2217",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ts0 Kh0 As0/3d0 7d0 9d0 Td0 Jd0/3c0 4c0 6c0 Qc0 Kc0",
            "win": 70,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "AawaraLaunda",
            "orderIndex": 0,
            "hero": true,
            "dead": "2c1 8c2 6s3 9s4",
            "rows": "8d2 Js3 Ah4/4d0 5c0 6d1 3s2 5h4/2h0 6h0 8h0 Jh1 Qh3",
            "win": -70,
            "playerId": "AawaraLaunda"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 06:45:00",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338195785": [
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "Mayur2217",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "7h3 6s4 Js4/3d0 5s0 5h1 3s2 Td2/9c0 Tc0 Ac0 6c1 4c3",
            "win": -20,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "AawaraLaunda",
            "orderIndex": 1,
            "hero": true,
            "dead": "6h1 2c2 4s3 5d4",
            "rows": "Qh0 Qd1 Ad4/Kd0 Kc0 2s3 Jc3 4h4/8h0 9s0 7d1 6d2 Ts2",
            "win": 20,
            "playerId": "AawaraLaunda"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 06:47:04",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338195993": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "Mayur2217",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Th3 Td3 Ad4/6d1 6c1 5h2 5s2 7c4/6h0 Jd0 Qh0 Qd0 Kh0",
            "win": -90,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": true,
            "result": 24,
            "playerName": "AawaraLaunda",
            "orderIndex": 0,
            "hero": true,
            "dead": "6s0",
            "rows": "Jh0 Js0 Qc0/7d0 9d0 Ks0 Ah0 Ac0/2h0 2c0 2s0 8h0 8c0",
            "win": 90,
            "playerId": "AawaraLaunda"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 06:48:00",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338196093": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Mayur2217",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Td3 Ks3 Th4/3d0 4d0 3c1 4h2 3s4/5c0 5s0 Js0 Jc1 5h2",
            "win": 180,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "AawaraLaunda",
            "orderIndex": 2,
            "hero": true,
            "dead": "7s1 4c2 4s3 9s4",
            "rows": "6h2 6s2 Ts4/8c0 Qc0 9c1 Jh1 Tc3/Jd0 Qd0 Kd0 7d3 5d4",
            "win": -90,
            "playerId": "AawaraLaunda"
        },
        {
            "inFantasy": false,
            "result": -24,
            "playerName": "Santhoshkumarmu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Qh2 Kh3/2s0 Ah0 Ac0 7c2 6d4/8h0 2h1 2d1 8s3 Ad4",
            "win": -90,
            "playerId": "Santhoshkumarmu"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 06:50:30",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338196348": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "Mayur2217",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qh0 Js2 Qd3/Kd0 2s1 Kh1 5s2 8d4/7h0 9h0 9d0 7s3 Jh4",
            "win": -105,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "AawaraLaunda",
            "orderIndex": 1,
            "hero": true,
            "dead": "9s1 2h2 Qc3 5d4",
            "rows": "Ah0 Jd4 Ad4/5c0 6s0 4h1 6h2 6d3/9c0 Th0 8h1 Tc2 Ts3",
            "win": 50,
            "playerId": "AawaraLaunda"
        },
        {
            "inFantasy": true,
            "result": 9,
            "playerName": "Santhoshkumarmu",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qs0 Kc0 Ks0/3h0 3d0 4d0 4s0 Td0/6c0 7c0 8c0 Jc0 Ac0",
            "win": 55,
            "playerId": "Santhoshkumarmu"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 06:52:38",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338196531": [
        {
            "inFantasy": true,
            "result": 43,
            "playerName": "Mayur2217",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "8d0 Td0 Tc0/5h0 9h0 Qh0 Kh0 Ah0/4d0 4s0 Jh0 Jd0 Js0",
            "win": 55,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": true,
            "result": 78,
            "playerName": "AawaraLaunda",
            "orderIndex": 0,
            "hero": true,
            "dead": "2d0 3d0 8h0",
            "rows": "6h0 6d0 6c0/3c0 4c0 7c0 8c0 Ac0/5s0 7s0 8s0 Ts0 As0",
            "win": 160,
            "playerId": "AawaraLaunda"
        },
        {
            "inFantasy": false,
            "result": 47,
            "playerName": "Santhoshkumarmu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ks3 Ad3 Qs4/2h1 2c1 2s2 7h2 6s4/5c0 9c0 Jc0 Qc0 Kc0",
            "win": -215,
            "playerId": "Santhoshkumarmu"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 06:53:57",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338196652": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "Mayur2217",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kd3 Ah3 9s4/6d1 6s1 2h2 2s2 4s4/7d0 7c0 Jc0 Qh0 Qd0",
            "win": -55,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "AawaraLaunda",
            "orderIndex": 1,
            "hero": true,
            "dead": "3c0",
            "rows": "8c0 Jh0 Jd0/4d0 Td0 Qs0 Ad0 Ac0/4h0 5h0 7h0 8h0 Kh0",
            "win": 55,
            "playerId": "AawaraLaunda"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 06:54:48",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338196731": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "Mayur2217",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Js2 Ad3 6c4/3c0 4d0 6h1 6d1 4c2/8h0 8c0 Ts0 Kc3 5d4",
            "win": -75,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": 33,
            "playerName": "AawaraLaunda",
            "orderIndex": 0,
            "hero": true,
            "dead": "9c1 4h2 Tc3 Kh4",
            "rows": "As0 Qc3 Ac4/2h0 7s0 3h1 3d1 7h4/5c0 5s0 9h2 Qs2 9s3",
            "win": 75,
            "playerId": "AawaraLaunda"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 06:56:46",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338196913": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "Mayur2217",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "7h3 Qc3 6s4/5h1 5c1 3h2 3s2 Ac4/Td0 Tc0 Ts0 Jd0 Js0",
            "win": -50,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "AawaraLaunda",
            "orderIndex": 1,
            "hero": true,
            "dead": "2c0 3d0 8h0",
            "rows": "Qh0 Ah0 As0/9c0 9s0 Jc0 Kh0 Kd0/4h0 4s0 7d0 7c0 7s0",
            "win": 50,
            "playerId": "AawaraLaunda"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 06:57:48",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338197005": [
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "Mayur2217",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Ks2 Qd4/9h1 9s1 Qc2 3d3 Qh4/4h0 5h0 6d0 7d0 8c3",
            "win": 80,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "AawaraLaunda",
            "orderIndex": 0,
            "hero": true,
            "dead": "6s1 2h2 As3 Kh4",
            "rows": "Ah2 4s3 Ad3/Th0 6c1 Td1 2d4 3h4/5d0 6h0 7c0 8s0 4c2",
            "win": -80,
            "playerId": "AawaraLaunda"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 06:59:57",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338197197": [
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "Mayur2217",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Ks0 Ad0/3h0 4h0 8h0 Th0 Jh0/5d0 5c0 5s0 Tc0 Ts0",
            "win": 140,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "AawaraLaunda",
            "orderIndex": 1,
            "hero": true,
            "dead": "7s1 4s2 3s3 Ah4",
            "rows": "Ac0 8c2 Qc3/2s0 Js1 Kh2 2c3 Qh4/6d0 7c0 8s0 4c1 9s4",
            "win": -140,
            "playerId": "AawaraLaunda"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:01:00",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338197317": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Mayur2217",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qc0 Kc3 8h4/2s0 5h0 Ad1 Jd3 Js4/7s0 9d0 Td1 9h2 9s2",
            "win": 30,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "AawaraLaunda",
            "orderIndex": 0,
            "hero": true,
            "dead": "5c1 6s2 4s3 Qs4",
            "rows": "Kd0 9c2 6d4/3c0 As0 4c1 3s2 4d3/Th0 Jh0 Ts1 7d3 5s4",
            "win": -30,
            "playerId": "AawaraLaunda"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:03:00",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338197557": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "Mayur2217",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Qc2 Jh4/4s0 Ac0 Ah1 6s3 Jd3/5d0 9d0 Td1 5h2 7h4",
            "win": 0,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "AawaraLaunda",
            "orderIndex": 1,
            "hero": true,
            "dead": "8s1 4c2 4d3 Qs4",
            "rows": "Ad0 As1 7s3/2s0 3c0 6d0 6h1 6c3/Qh0 9c2 Js2 5c4 7d4",
            "win": 0,
            "playerId": "AawaraLaunda"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:04:37",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338197775": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "Mayur2217",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kd0 As2 Tc4/4c0 3h1 6d1 5d3 4s4/8d0 8s0 Js0 7c2 Jd3",
            "win": 60,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "AawaraLaunda",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qs1 Jh2 6c3 3c4",
            "rows": "Ac0 4h4 Qc4/2c0 3s1 3d2 Qh2 7d3/7s0 8h0 9h0 Jc1 9c3",
            "win": 0,
            "playerId": "AawaraLaunda"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "Santhoshkumarmu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Ks1 Th4/6h0 7h0 5h1 Ad2 Ah3/8c0 Ts0 9s2 Qd3 Td4",
            "win": -60,
            "playerId": "Santhoshkumarmu"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:07:41",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338198172": [
        {
            "inFantasy": false,
            "result": 39,
            "playerName": "Mayur2217",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kd1 Tc3 Ah3/7h0 7d0 4d1 2h2 8c4/2s0 4s0 Ks0 6s2 7s4",
            "win": -105,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "AawaraLaunda",
            "orderIndex": 2,
            "hero": true,
            "dead": "Jc1 Td2 2d3 4c4",
            "rows": "Ad1 Ac3 6d4/2c0 8s0 6h2 8h2 6c3/3d0 3c0 Jh0 3s1 As4",
            "win": 5,
            "playerId": "AawaraLaunda"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "Santhoshkumarmu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qd0 8d2 Qc2/Kc0 9c1 4h3 9s3 Kh4/5h0 5c0 Th0 Ts1 5s4",
            "win": 100,
            "playerId": "Santhoshkumarmu"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:10:26",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338198522": [
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "Mayur2217",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qd3 Qc3 6h4/Qh1 Qs1 Js2 Ac2 5h4/6s0 7c0 9d0 Th0 Ts0",
            "win": -145,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": true,
            "result": 24,
            "playerName": "AawaraLaunda",
            "orderIndex": 1,
            "hero": true,
            "dead": "3s0 5s0 9s0",
            "rows": "Kd0 Ks0 Ad0/2h0 3h0 4d0 5c0 6c0/8h0 8d0 8c0 Jd0 Jc0",
            "win": 160,
            "playerId": "AawaraLaunda"
        },
        {
            "inFantasy": true,
            "result": 15,
            "playerName": "Santhoshkumarmu",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Tc0 Ah0 As0/3d0 3c0 6d0 Kh0 Kc0/7s0 8s0 9h0 Td0 Jh0",
            "win": -15,
            "playerId": "Santhoshkumarmu"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:12:08",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338198698": [
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "AawaraLaunda",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jh1 6c2 2d3 Ad4",
            "rows": "Ah0 Qh2 Ac3/3s0 7s0 8s1 3c2 7h3/9d0 Tc0 Td1 8d4 9c4",
            "win": 50,
            "playerId": "AawaraLaunda"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "Santhoshkumarmu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ks2 As3 6d4/2h0 4h0 2s1 8h1 4d2/5h0 5c0 Jc0 Qd3 Jd4",
            "win": -50,
            "playerId": "Santhoshkumarmu"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:13:54",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338198933": [
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "AawaraLaunda",
            "orderIndex": 0,
            "hero": true,
            "dead": "6c0 7c0 Jc0",
            "rows": "3c0 3s0 Kc0/2h0 4h0 5h0 9h0 Qh0/2d0 5d0 6d0 Td0 Ad0",
            "win": 90,
            "playerId": "AawaraLaunda"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "Santhoshkumarmu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ac3 As3 Ks4/8d1 8c1 6h2 6s2 5s4/7h0 7d0 Tc0 Jd0 Qd0",
            "win": -90,
            "playerId": "Santhoshkumarmu"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:14:49",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338199076": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "anantv",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qs2 Ah2 Kh4/2s0 7c0 3h1 7s1 3c3/4d0 4c0 9d0 6h3 4s4",
            "win": -5,
            "playerId": "anantv"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "AawaraLaunda",
            "orderIndex": 1,
            "hero": true,
            "dead": "7h1 Jh2 9s3 Tc4",
            "rows": "Kd0 2d1 6d3/5c0 8h0 3s1 Jd4 Ac4/Ts0 Jc0 9c2 Qh2 8s3",
            "win": 5,
            "playerId": "AawaraLaunda"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:17:02",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338199398": [
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "anantv",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ah0 Ks1 Kc4/7d0 6d1 6s2 7h2 Tc4/9h0 9s0 Jh0 4h3 4c3",
            "win": 25,
            "playerId": "anantv"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "AawaraLaunda",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jc1 8s2 3s3 2h4",
            "rows": "Qc0 Ad3 Th4/4s0 5c1 8h1 5s3 Qd4/3d0 Td0 Kd0 9d2 Jd2",
            "win": -25,
            "playerId": "AawaraLaunda"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:19:12",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338199705": [
        {
            "inFantasy": true,
            "result": 9,
            "playerName": "anantv",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qc0 Ad0 Ac0/3s0 4d0 5h0 6h0 7d0/2h0 2d0 2s0 Td0 Tc0",
            "win": 25,
            "playerId": "anantv"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "AawaraLaunda",
            "orderIndex": 1,
            "hero": true,
            "dead": "9h1 Kh2 4c3 9s4",
            "rows": "Qs0 Qh2 Jc4/3d0 4h0 3c1 3h3 9d4/7s0 8c0 7c1 8d2 7h3",
            "win": -25,
            "playerId": "AawaraLaunda"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:20:12",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338199879": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "anantv",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ad3 As3 Kc4/8h1 8d1 5d2 5c2 3c4/4h0 6h0 7h0 Js0 Qh0",
            "win": -75,
            "playerId": "anantv"
        },
        {
            "inFantasy": true,
            "result": 15,
            "playerName": "AawaraLaunda",
            "orderIndex": 0,
            "hero": true,
            "dead": "5h0",
            "rows": "8c0 8s0 Qd0/6s0 9h0 9s0 Jc0 Ah0/2h0 2c0 2s0 3d0 3s0",
            "win": 75,
            "playerId": "AawaraLaunda"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:21:02",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338199996": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "AawaraLaunda",
            "orderIndex": 1,
            "hero": true,
            "dead": "Kh1 7d2 4d3 6h4",
            "rows": "9s3 5s4 8h4/2c0 3s0 5h0 4c2 Ad3/7h0 9c0 8s1 Th1 6s2",
            "win": 60,
            "playerId": "AawaraLaunda"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "Santhoshkumarmu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qd0 Kc1 Ks2/Ah0 Jc2 8c3 5c4 Qh4/3d0 3c0 4h0 4s1 3h3",
            "win": -60,
            "playerId": "Santhoshkumarmu"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:22:36",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338200227": [
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "AawaraLaunda",
            "orderIndex": 0,
            "hero": true,
            "dead": "Tc1 7s2 Ac3 6c4",
            "rows": "Ks1 Kh3 8d4/3c0 6h0 3s2 9h2 6s3/4h0 4d0 Js0 4c1 Jc4",
            "win": 45,
            "playerId": "AawaraLaunda"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "Santhoshkumarmu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ad1 Qd4 Kc4/5s0 6d0 Jd2 7h3 7c3/2d0 2c0 8c0 8s1 8h2",
            "win": -45,
            "playerId": "Santhoshkumarmu"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:24:16",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338200466": [
        {
            "inFantasy": true,
            "result": 18,
            "playerName": "AawaraLaunda",
            "orderIndex": 1,
            "hero": true,
            "dead": "2d0 Js0",
            "rows": "9h0 9d0 Ad0/4h0 5s0 6d0 7d0 8h0/2c0 8c0 Qc0 Kc0 Ac0",
            "win": 70,
            "playerId": "AawaraLaunda"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Santhoshkumarmu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "6c3 8s3 3s4/7h1 7c1 5d2 7s2 4c4/9c0 Th0 Jh0 Qs0 Ks0",
            "win": -70,
            "playerId": "Santhoshkumarmu"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:25:13",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338200607": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "AawaraLaunda",
            "orderIndex": 0,
            "hero": true,
            "dead": "7d1 Qs2 4h3 Ks4",
            "rows": "Ac0 Qc2 As2/3s0 8s0 8h1 Th3 Ts3/2d0 Jd0 9d1 7c4 7s4",
            "win": 0,
            "playerId": "AawaraLaunda"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "Santhoshkumarmu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qd0 Kc3 Ah4/4s0 Jh1 Js1 4d2 3h3/6s0 7h0 9c0 5c2 3c4",
            "win": 0,
            "playerId": "Santhoshkumarmu"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:27:19",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338200930": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "AawaraLaunda",
            "orderIndex": 1,
            "hero": true,
            "dead": "Kh1 2d2 2s3 5d4",
            "rows": "Ah0 Ad1 Qh3/9s0 3d2 3c2 3s4 Jc4/8c0 8s0 Jh0 8d1 4h3",
            "win": -5,
            "playerId": "AawaraLaunda"
        },
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "Santhoshkumarmu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qc0 Kd1 Qd3/Jd0 4d1 4s2 2h3 Js4/Td0 Tc0 Ts0 7h2 7d4",
            "win": 5,
            "playerId": "Santhoshkumarmu"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:29:22",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338201259": [
        {
            "inFantasy": true,
            "result": -6,
            "playerName": "AawaraLaunda",
            "orderIndex": 0,
            "hero": true,
            "dead": "2s0 9s0 Tc0",
            "rows": "Jc0 Kh0 Ks0/2d0 3c0 4d0 5s0 Ad0/5h0 6h0 7h0 Jh0 Qh0",
            "win": 0,
            "playerId": "AawaraLaunda"
        },
        {
            "inFantasy": true,
            "result": 0,
            "playerName": "Santhoshkumarmu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Ah0 As0/2c0 3s0 4c0 5d0 6s0/7s0 8s0 9c0 Td0 Jd0",
            "win": 0,
            "playerId": "Santhoshkumarmu"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:30:34",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338201529": [
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "AawaraLaunda",
            "orderIndex": 1,
            "hero": true,
            "dead": "5d1 4h2 8d3 8c4",
            "rows": "Kh0 As3 Kd4/2d0 4d0 2h1 4c1 6c2/Qc0 Qs0 9s2 9h3 2s4",
            "win": 70,
            "playerId": "AawaraLaunda"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "Santhoshkumarmu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ah2 Ad2 8s4/6h0 7h0 7c1 7d3 Td3/Jd0 Kc0 Ks0 Jc1 6s4",
            "win": -70,
            "playerId": "Santhoshkumarmu"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:32:37",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338201998": [
        {
            "inFantasy": true,
            "result": 18,
            "playerName": "AawaraLaunda",
            "orderIndex": 0,
            "hero": true,
            "dead": "2c0 3c0",
            "rows": "9h0 9d0 Ah0/6h0 7s0 Jd0 Jc0 Kd0/5c0 5s0 8h0 8s0 Qs0",
            "win": 50,
            "playerId": "AawaraLaunda"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Santhoshkumarmu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kh3 Ks3 Qh4/4d1 4c1 2h2 2d2 5d4/6s0 7h0 8d0 Th0 Ts0",
            "win": -50,
            "playerId": "Santhoshkumarmu"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:42:38",
    "roomId": "41b-1d653b5e"
}


