{
    "stakes": 10,
    "handData": {"338238986": [
        {
            "inFantasy": false,
            "result": 57,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "Th1 Js2 Ts3 9s4",
            "rows": "Ks0 Kh1 Jd4/3s0 7c0 As1 Td3 Ac3/5d0 5c0 4h2 4s2 7d4",
            "win": 170,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "MUKSNOLE",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "3h0 Ah0 6h3/5h0 5s0 7s1 4d2 Tc4/Qs0 9h1 8h2 Qh3 Jh4",
            "win": -240,
            "playerId": "MUKSNOLE"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kd0 Qc4 Ad4/2s0 3d0 2h2 8d3 8s3/8c0 9c0 6c1 Jc1 4c2",
            "win": 70,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:53:53",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338239480": [
        {
            "inFantasy": true,
            "result": 27,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "5h0 7d0",
            "rows": "Jh0 Js0 Kc0/3d0 8d0 8s0 Th0 Td0/6h0 6d0 6c0 9c0 9s0",
            "win": 50,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 48,
            "playerName": "MUKSNOLE",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "As0 Kh1 Ad3/2h0 3s0 2c2 Jc2 2s3/Ts0 Qd0 Qc1 Tc4 Qh4",
            "win": 320,
            "playerId": "MUKSNOLE"
        },
        {
            "inFantasy": false,
            "result": 33,
            "playerName": "Tgomegan",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ac0 Kd1 8h4/2d0 4h0 4s1 5c3 3h4/5s0 6s0 4d2 7c2 3c3",
            "win": -370,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:56:09",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338239829": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "TuPac1",
            "orderIndex": 2,
            "hero": true,
            "dead": "9h1 3s2 Jd3 4h4",
            "rows": "Kh0 Ts3 Td4/3h0 6d0 6h2 3d3 7c4/5c0 9c0 3c1 Ac1 Jc2",
            "win": -220,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": true,
            "result": 84,
            "playerName": "MUKSNOLE",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "7h0 7d0 7s0/8c0 9s0 Tc0 Jh0 Qs0/2h0 2c0 2s0 4d0 4c0",
            "win": 420,
            "playerId": "MUKSNOLE"
        },
        {
            "inFantasy": false,
            "result": 42,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ks1 As1 Ah2/2d0 4s0 5h3 5d3 Js4/8h0 8s0 9d0 8d2 Qc4",
            "win": -200,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:58:10",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338240137": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "2s1 2c2 3d3 4h4",
            "rows": "As1 Jc3 Qs4/6d0 5d1 6h2 9c2 9d3/9s0 Tc0 Jd0 Qd0 Kd4",
            "win": -120,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "MUKSNOLE",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ts0 Ah0 Ad0/3h0 3s0 7d0 7c0 9h0/4c0 5c0 6c0 Qc0 Ac0",
            "win": 120,
            "playerId": "MUKSNOLE"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:59:45",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338240384": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "4c1 Kh2 Js3 8d4",
            "rows": "7c2 9h3 Td3/2s0 3c1 4h2 Ac4 As4/6d0 7d0 8c0 9c0 5h1",
            "win": -40,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "MUKSNOLE",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qc0 Ah1 Qs3/2h0 2c1 2d2 3h3 3s4/5c0 5s0 Jc0 Jd2 Qh4",
            "win": -220,
            "playerId": "MUKSNOLE"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "Tgomegan",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ad2 6h3 Qd4/7h0 Tc0 8s1 Ts2 Th3/4s0 Kd0 Ks0 Kc1 4d4",
            "win": 260,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:02:33",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338240810": [
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "TuPac1",
            "orderIndex": 2,
            "hero": true,
            "dead": "3h1 8h2 2s3 6h4",
            "rows": "Ah0 Qh3 5c4/Kh0 Kd0 8c1 7h2 Ks2/3d0 5h0 7s1 6d3 4d4",
            "win": 60,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "MUKSNOLE",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "As0 9s2 9d4/Th0 2d1 2c1 8d3 Ts4/3c0 3s0 Jd0 Jh2 Qs3",
            "win": 90,
            "playerId": "MUKSNOLE"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc2 2h3 Ac4/5d0 7d0 4h1 4c1 6s3/9h0 9c0 Js0 8s2 Qc4",
            "win": -150,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:05:22",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338241241": [
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qc1 9d2 8c3 Qd4",
            "rows": "Ad1 Kc3 8s4/2d0 3d0 4h0 2c1 3c2/6s0 Js0 7s2 2s3 Qs4",
            "win": -50,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 63,
            "playerName": "MUKSNOLE",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ah0 As1 Ks4/4c0 5d0 5c1 5s3 Jd4/9c0 Jh0 8h2 Qh2 Tc3",
            "win": 290,
            "playerId": "MUKSNOLE"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ac2 4d3 Ts3/7c0 Td0 6h1 6d1 7d2/9h0 9s0 Jc0 Kh4 Kd4",
            "win": -240,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:07:47",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338241629": [
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qd1 7c2 As3 7s4",
            "rows": "Kh0 7h2 Kc4/3s0 6c0 5c1 3c2 5d3/8h0 8d0 9s1 9h3 Tc4",
            "win": -70,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": true,
            "result": 45,
            "playerName": "MUKSNOLE",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "2h0 2d0 2s0/Th0 Td0 Ts0 Qs0 Ac0/5h0 6s0 7d0 8c0 9c0",
            "win": 230,
            "playerId": "MUKSNOLE"
        },
        {
            "inFantasy": false,
            "result": 48,
            "playerName": "Tgomegan",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ks0 Js2 Qc4/4d0 Ad1 3d2 4s3 5s4/6h0 Qh0 Ah0 Jh1 3h3",
            "win": -160,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:10:16",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338241991": [
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "TuPac1",
            "orderIndex": 2,
            "hero": true,
            "dead": "2s0 7s0",
            "rows": "Th0 Qc0 Ad0/4h0 4d0 6d0 6c0 8s0/3h0 3d0 Jd0 Jc0 Js0",
            "win": -110,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": true,
            "result": 54,
            "playerName": "MUKSNOLE",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kh0 Kc0 Ah0/5h0 6h0 7d0 8h0 9s0/2c0 3c0 4c0 7c0 8c0",
            "win": 210,
            "playerId": "MUKSNOLE"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kd3 Ks3 2h4/5c1 5s1 9h2 Ac2 7h4/2d0 5d0 8d0 Td0 Qd0",
            "win": -100,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:11:50",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338242187": [
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "Td1 3c2 7d3 Tc4",
            "rows": "Qh0 5s2 Qc4/8s0 9d0 7c1 8d2 8c4/6d0 6s0 Jc1 6h3 6c3",
            "win": 360,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "MUKSNOLE",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ah0 Ac3 9h4/3s0 4d0 4s2 5d2 5h3/Js0 Ks0 Qd1 Qs1 Jd4",
            "win": 40,
            "playerId": "MUKSNOLE"
        },
        {
            "inFantasy": false,
            "result": 36,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Kd1 2s4/2d0 3h0 3d2 2c3 Kh3/8h0 9s0 Ts1 Th2 5c4",
            "win": -400,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:14:31",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338242542": [
        {
            "inFantasy": true,
            "result": -24,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "4s0",
            "rows": "Th0 Ts0 Qc0/2c0 2s0 3h0 3c0 5s0/4c0 5c0 6c0 7c0 8c0",
            "win": 120,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": true,
            "result": -3,
            "playerName": "MUKSNOLE",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qh0 Qd0 Ad0/4h0 5h0 6s0 7d0 8s0/9h0 9s0 Jd0 Jc0 Js0",
            "win": -20,
            "playerId": "MUKSNOLE"
        },
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "Tgomegan",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ah3 As3 Jh4/3d1 3s1 2h2 2d2 Kh4/7h0 7s0 9d0 9c0 Td0",
            "win": -100,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:16:10",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338242764": [
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "2h0",
            "rows": "Td0 Qd0 As0/5h0 6h0 6c0 6s0 7c0/8h0 8d0 8s0 9c0 9s0",
            "win": 140,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "MUKSNOLE",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kh3 Kc3 9d4/8c1 Ac1 4s2 5d2 2c4/3d0 3c0 3s0 Jh0 Jd0",
            "win": -140,
            "playerId": "MUKSNOLE"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:17:03",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338242884": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "5c1 Td2 3d3 4h4",
            "rows": "8d1 Kc2 8c4/3s0 9s0 Ts1 2s2 9d3/7h0 Th0 Qh0 Qd3 2h4",
            "win": 0,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "9h2 8h3 3c4/Jd0 4d1 5d2 7d3 6h4/2c0 4c0 7c0 9c0 Qc1",
            "win": 0,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:18:52",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338243107": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "5c1 Ks2 Th3 Ah4",
            "rows": "As0 2d3 6s3/3c0 7h0 6c1 4s2 5d2/Jh0 Qd0 Qs1 7d4 8c4",
            "win": -100,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Tc0 9d3 Qc4/Kh0 Kc0 6d2 8h2 Kd4/5h0 6h0 7c1 8d1 9s3",
            "win": 100,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:20:34",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338243329": [
        {
            "inFantasy": false,
            "result": 33,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "6h1 Kh2 3c3 Th4",
            "rows": "As0 Ah2 2c3/2s0 4h0 2h1 4c3 Qc4/Jd0 Jc0 8c1 8h2 7c4",
            "win": 150,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Js0 8d2 5c3/4d0 Ac1 3d2 5h3 3s4/6c0 6s0 9c0 9h1 3h4",
            "win": -150,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:22:21",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338243592": [
        {
            "inFantasy": true,
            "result": -12,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "4h0 6h0 9d0",
            "rows": "Jh0 Jc0 Ks0/3c0 3s0 8d0 8c0 Th0/2c0 2s0 7h0 7d0 7s0",
            "win": 40,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ad3 As3 Kh4/5h1 5d1 4d2 4c2 9h4/3h0 3d0 Ts0 Qh0 Qs0",
            "win": -40,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:23:05",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338243687": [
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "4s1 Qh2 6h3 4d4",
            "rows": "Ks0 Kc3 Qd4/5c0 6s0 Ad2 As2 9s4/2h0 3h0 7h1 Ah1 Kh3",
            "win": -120,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": true,
            "result": -27,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Td0 Js0 Kd0/2c0 4c0 6c0 8c0 Tc0/5d0 6d0 7d0 8d0 9d0",
            "win": 120,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:23:52",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338243790": [
        {
            "inFantasy": true,
            "result": 33,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "7d0 8h0",
            "rows": "Jc0 Ad0 As0/3s0 8s0 9s0 Ts0 Ks0/2h0 2d0 Qh0 Qd0 Qs0",
            "win": 170,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "4d0 8d0 Th0/2c0 4c0 6c0 9c0 Tc0/6h0 7h0 9h0 Kh0 Ah0",
            "win": -170,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:24:31",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338243883": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "8s1 4s2 3h3 3d4",
            "rows": "Qs1 Ac3 5d4/5h0 6h0 6c2 6s3 8h4/4c0 7c0 Jc0 Kc1 2c2",
            "win": 120,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kh0 Qh1 Ks3/7h0 9s0 Ts2 8c3 5s4/2d0 6d0 8d1 4d2 Tc4",
            "win": -120,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:26:31",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338244135": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "Js1 Qh2 2d3 Jd4",
            "rows": "Kc1 Kh2 6h4/4h0 4s0 2s1 5c2 3d4/6c0 6s0 Td0 Ah3 Ad3",
            "win": -60,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Jc0 5d4 6d4/4c0 7h0 9c1 Kd3 Ks3/3s0 Ts0 Qs1 Th2 Qc2",
            "win": 60,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:28:16",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338244378": [
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "8c1 6d2 4d3 2s4",
            "rows": "Ks0 Td2 Kd2/5s0 Ac0 9c1 Kh3 Ah3/7d0 Jd0 Jh1 6c4 6s4",
            "win": 90,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Jc0 2d3 Kc3/8d0 9h0 6h1 8h2 9s4/Th0 Tc0 4s1 4c2 Qh4",
            "win": -90,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:30:27",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338244737": [
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "3h0 5s0",
            "rows": "Jc0 Ks0 As0/2h0 2s0 6h0 9h0 Td0/3c0 4c0 5c0 6c0 7c0",
            "win": 210,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qh3 Qd3 Kh4/Ah1 Ad1 8h2 Qc2 2c4/2d0 4h0 9d0 Jh0 Js0",
            "win": -210,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:31:15",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338244918": [
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "2c0",
            "rows": "Qd0 Ad0 As0/3s0 4h0 4d0 4s0 6h0/9s0 Ts0 Js0 Qs0 Ks0",
            "win": 200,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ah3 Ac3 2d4/5h1 5s1 2h2 2s2 3d4/3c0 6d0 6c0 Jh0 Kc0",
            "win": -200,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:32:06",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338245089": [
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qc1 5c2 7s3 3h4",
            "rows": "Ad0 Ac0 9c4/3s0 6h0 3c2 6d2 5s4/9d0 8d1 Js1 8h3 Jd3",
            "win": 100,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qs1 Kd3 As4/6s0 7c0 9h1 7h2 9s2/2c0 Th0 Td0 4c3 2s4",
            "win": -100,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:33:57",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338245421": [
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "2s0 6s0 Qs0",
            "rows": "Kd0 Ac0 As0/8d0 9h0 Ts0 Jc0 Qd0/3c0 4c0 5c0 8c0 Tc0",
            "win": 140,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Jd3 Qc3 7c4/9d1 9s1 7s2 8s2 5s4/2d0 4d0 5d0 7d0 Ad0",
            "win": -140,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:34:53",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338245595": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "TuPac1",
            "orderIndex": 2,
            "hero": true,
            "dead": "3h1 7s2 2s3 Ac4",
            "rows": "Kh0 9c3 Kc4/2h0 3c0 Ad0 4h1 5s2/9d0 7d1 3d2 Td3 Js4",
            "win": -170,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 54,
            "playerName": "ishanip",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qs0 Ks3 Qd4/Th0 Tc2 Jh2 Ts3 7c4/3s0 4c0 5c0 6c1 7h1",
            "win": 340,
            "playerId": "ishanip"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "5d2 Ah2 As3/8c0 9s0 4s1 8h1 9h3/2c0 Jd0 Jc0 Qc4 Kd4",
            "win": -170,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:37:48",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338246117": [
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "8c1 3h2 3s3 Qc4",
            "rows": "9s1 Kd2 Kc3/4s0 6h0 5h1 5c2 Tc4/2c0 2s0 Jd0 Ac3 Td4",
            "win": -240,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": true,
            "result": 60,
            "playerName": "ishanip",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Jh0 Kh0 Ks0/4d0 5d0 6c0 7h0 8d0/9h0 9d0 9c0 Qh0 Qd0",
            "win": 480,
            "playerId": "ishanip"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ad1 Ts2 4h4/2d0 4c0 3c1 Jc2 Js3/7c0 7s0 8s0 Qs3 6s4",
            "win": -240,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:40:24",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338246596": [
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "Kh1 Jh2 Jd3 8s4",
            "rows": "Ac0 7d4 Kc4/5h0 8d0 Qh1 Qc1 8c2/2s0 Ks0 Ts2 Th3 Kd3",
            "win": -130,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "ishanip",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Tc1 Ah3 9c4/2h0 5d0 7c1 2d2 4s4/3h0 3d0 9d0 9s2 3c3",
            "win": 10,
            "playerId": "ishanip"
        },
        {
            "inFantasy": false,
            "result": 60,
            "playerName": "Tgomegan",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qs0 Ad1 As4/9h0 7s1 5c3 7h3 5s4/4c0 6c0 Jc0 4h2 Js2",
            "win": 120,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:43:01",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338247063": [
        {
            "inFantasy": false,
            "result": 63,
            "playerName": "TuPac1",
            "orderIndex": 2,
            "hero": true,
            "dead": "5d1 8h2 3c3 2h4",
            "rows": "Ah3 5c4 Kc4/9h0 Jh0 8d1 9d1 Jd2/6h0 6d0 6s0 2s2 2d3",
            "win": -110,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 48,
            "playerName": "ishanip",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kd1 4h3 Qd3/7h0 9s0 5h1 9c2 Ks4/Tc0 Jc0 Ac0 2c2 Ad4",
            "win": -460,
            "playerId": "ishanip"
        },
        {
            "inFantasy": true,
            "result": 129,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qh0 Qc0 Qs0/4d0 5s0 6c0 7c0 8c0/7s0 8s0 Ts0 Js0 As0",
            "win": 570,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:46:15",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338247652": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "6h1 3h2 7h3 Ad4",
            "rows": "Kc0 Kd3 Ah3/5h0 4s1 8s1 8d2 6s4/Jh0 Jc0 Qs0 Qh2 3s4",
            "win": -200,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "ishanip",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "As0 5s2 Ks2/3c0 7c1 8c1 4c3 7d4/5d0 6d0 Jd0 Qd3 9d4",
            "win": -50,
            "playerId": "ishanip"
        },
        {
            "inFantasy": true,
            "result": 3,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "7s0 8h0 Kh0/5c0 6c0 9c0 Qc0 Ac0/2h0 2d0 2s0 Td0 Tc0",
            "win": 250,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:49:06",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338248082": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "4h1 2c2 4d3 5s4",
            "rows": "Kc1 6c3 3s4/3h0 9s0 9c2 8h3 8d4/7d0 Td0 Jd0 Js1 7s2",
            "win": -70,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "ishanip",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kd1 As2 Jh4/4s0 6h0 6s1 4c2 Tc3/9d0 Qc0 Qs0 9h3 6d4",
            "win": -50,
            "playerId": "ishanip"
        },
        {
            "inFantasy": false,
            "result": 48,
            "playerName": "Tgomegan",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qh0 Qd0 8c3/2s0 Ac1 Ah2 Th3 Kh4/3d0 5d0 2d1 5h2 2h4",
            "win": 120,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:51:55",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338248497": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "TuPac1",
            "orderIndex": 2,
            "hero": true,
            "dead": "Ts1 5h2 Qs3 Jc4",
            "rows": "Kh2 As3 Qc4/2s0 6h0 8c1 8s1 6d4/3d0 4d0 9d0 2d2 Ad3",
            "win": 100,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "ishanip",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ah0 Ks2 Kd4/3s0 4h0 7s1 3c3 7h3/Th0 Jd0 Jh1 Qd2 4c4",
            "win": -210,
            "playerId": "ishanip"
        },
        {
            "inFantasy": true,
            "result": 27,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "5s0 8h0 8d0/9c0 9s0 Tc0 Qh0 Kc0/3h0 4s0 5d0 6s0 7c0",
            "win": 110,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:54:22",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338248857": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "4h1 4s2 6s3 Qh4",
            "rows": "8h2 7s3 7d4/6d0 9h0 9s1 9d2 2d3/2c0 5c0 Qc0 Kc1 6c4",
            "win": 280,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "ishanip",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qs0 Kh2 As3/5s0 3h1 4d1 5h2 4c4/7h0 7c0 8c0 8s3 3c4",
            "win": -80,
            "playerId": "ishanip"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ac0 Jd2 Jh3/6h0 Qd0 Th1 Ad2 Ah3/3s0 Ks0 3d1 5d4 Tc4",
            "win": -200,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:57:08",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338249240": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "9c1 5d2 6c3 Jd4",
            "rows": "Qh0 Kc2 Qc3/Ah0 Ad1 7h2 6d3 Th4/5s0 6s0 7d0 4h1 9s4",
            "win": 0,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qs0 Ac3 As3/3d0 5c0 2s1 3c2 3h4/8h0 Kh0 6h1 Ks2 8c4",
            "win": 0,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:59:00",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338249491": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "5s1 7c2 6c3 8c4",
            "rows": "6h3 5h4 5c4/2h0 Tc0 Ah1 Ac1 2c2/2d0 3d0 4d0 7d2 Td3",
            "win": 80,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "9d3 Ks3 As4/6d1 6s1 4h2 4c2 Ad4/8s0 9c0 Ts0 Jd0 Qd0",
            "win": -80,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 12:00:44",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338249729": [
        {
            "inFantasy": false,
            "result": 57,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "Kd1 Td2 6c3 As4",
            "rows": "Ac0 Kc2 Kh3/4h0 4s0 3h1 3s2 Jh4/7h0 Qh0 Qs1 7d3 Th4",
            "win": 170,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "Mayur2217",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Js2 Ad3 5d4/2h0 5s0 2c1 2s2 7c3/7s0 9d0 Tc0 Jc1 Ts4",
            "win": -260,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "Tgomegan",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ah0 Qc3 3d4/2d0 4c0 6s2 6h3 5c4/8h0 9h0 8d1 8s1 9s2",
            "win": 90,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 12:03:06",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338250079": [
        {
            "inFantasy": true,
            "result": 15,
            "playerName": "TuPac1",
            "orderIndex": 2,
            "hero": true,
            "dead": "2s0 5s0",
            "rows": "8c0 Ts0 Ks0/3h0 5h0 9h0 Th0 Qh0/3d0 6d0 Td0 Jd0 Kd0",
            "win": 70,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 48,
            "playerName": "Mayur2217",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qs0 Qc1 Js4/2c0 Ah0 4h2 3s3 5d4/7h0 9c0 8h1 Tc2 6h3",
            "win": 100,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "9d1 Kh2 Ad3/6c0 7d0 3c1 7c2 Qd4/7s0 8s0 9s0 6s3 As4",
            "win": -170,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 12:05:16",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338250385": [
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "3h1 Jc2 5d3 4s4",
            "rows": "2h1 Qd2 Jh3/7s0 8s0 Ks3 7d4 8d4/3c0 6c0 Kc0 9c1 Ac2",
            "win": -150,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": true,
            "result": -33,
            "playerName": "Mayur2217",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "8c0 Tc0 Qh0/4d0 6d0 Td0 Kd0 Ad0/2c0 2s0 9h0 9d0 9s0",
            "win": 170,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "As1 Ah2 6h4/5h0 5s0 7h0 7c3 Kh3/Ts0 Js0 Qc1 Th2 Jd4",
            "win": -20,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 12:07:35",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338250717": [
        {
            "inFantasy": false,
            "result": 42,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qd1 Jh2 Ts3 Tc4",
            "rows": "Ad0 Kd1 Kh2/3h0 7s0 3s1 5s3 8s4/6c0 9c0 4c2 6h3 2c4",
            "win": -280,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 42,
            "playerName": "Mayur2217",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qc2 7h3 Ac3/3d0 4h0 5h0 7c2 Kc4/2s0 9s0 Js1 As1 2h4",
            "win": -280,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": true,
            "result": 108,
            "playerName": "Tgomegan",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "8h0 8d0 8c0/3c0 4s0 5d0 6d0 7d0/9h0 Td0 Jc0 Qh0 Ks0",
            "win": 560,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 12:09:46",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338251013": [
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "TuPac1",
            "orderIndex": 2,
            "hero": true,
            "dead": "5s1 2h2 8h3 2s4",
            "rows": "Js1 Qh3 Kh3/6d0 Td0 4d2 9h4 As4/3c0 4c0 7c0 Ac1 2c2",
            "win": -290,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 51,
            "playerName": "Mayur2217",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qc1 Kd3 Qd4/3h0 5c0 3s1 6c2 6h4/7d0 Tc0 Ts0 7s2 Th3",
            "win": 170,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": true,
            "result": 24,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "9c0 Kc0 Ah0/6s0 8s0 9s0 Qs0 Ks0/2d0 3d0 5d0 8d0 Ad0",
            "win": 120,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 12:11:35",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338251280": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jh1 3d2 9s3 9c4",
            "rows": "Qd0 Qc0 Tc3/Kc0 6s1 4c2 Ac3 8s4/5d0 8d0 5h1 7h2 2h4",
            "win": -20,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": true,
            "result": -3,
            "playerName": "Mayur2217",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "3c0 5c0 6c0/6h0 8h0 9h0 Th0 Qh0/2s0 5s0 7s0 Js0 Ks0",
            "win": 130,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ah0 3h2 8c2/2d0 Jd0 Td1 7c3 Ad3/Ts0 Qs0 3s1 4h4 4d4",
            "win": -110,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 12:13:45",
    "roomId": "41b-1d7888fa"
}


