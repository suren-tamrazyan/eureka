{
    "stakes": 5,
    "handData": {"338198137": [
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "anantv",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ac0 Jd2 7h3/5h0 7c0 8d1 6s2 7s3/9c0 9s0 Qd1 6c4 Qh4",
            "win": -75,
            "playerId": "anantv"
        },
        {
            "inFantasy": false,
            "result": 66,
            "playerName": "fishbutton",
            "orderIndex": 0,
            "hero": true,
            "dead": "2s1 5s2 8s3 6d4",
            "rows": "As0 Ah3 9h4/8h0 Qc0 8c1 Qs2 3c4/Kh0 Kd0 4c1 4s2 4h3",
            "win": 210,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "chirag1993",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc1 Ad2 Ks3/5d0 7d0 6h1 Td4 Tc4/2h0 2c0 Jc0 Js2 Jh3",
            "win": -135,
            "playerId": "chirag1993"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:10:16",
    "roomId": "41b-1d6ae9f6"
}


{
    "stakes": 5,
    "handData": {"338198483": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "anantv",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ac0 Kc2 6d4/3d0 6c0 3c1 3s3 Qs3/5s0 7s0 5d1 7h2 5c4",
            "win": -125,
            "playerId": "anantv"
        },
        {
            "inFantasy": true,
            "result": -9,
            "playerName": "fishbutton",
            "orderIndex": 2,
            "hero": true,
            "dead": "6s0 9h0 Th0",
            "rows": "7d0 7c0 Qc0/4d0 4s0 Jd0 Jc0 Js0/2h0 2d0 2c0 2s0 As0",
            "win": 185,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "chirag1993",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qh1 Kh2 Ks3/8s0 Tc0 8h1 8d2 Ah3/9c0 9s0 Jh0 9d4 Qd4",
            "win": -60,
            "playerId": "chirag1993"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:12:29",
    "roomId": "41b-1d6ae9f6"
}


{
    "stakes": 5,
    "handData": {"338198740": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "anantv",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ks3 Ad3 Qh4/2s1 3c1 4h2 5d2 6c4/8d0 Jh0 Qd0 Qc0 Kc0",
            "win": -50,
            "playerId": "anantv"
        },
        {
            "inFantasy": true,
            "result": -24,
            "playerName": "fishbutton",
            "orderIndex": 1,
            "hero": true,
            "dead": "2d0",
            "rows": "7h0 Qs0 Ac0/3h0 5s0 9h0 9d0 9c0/Th0 Td0 Jd0 Jc0 Js0",
            "win": 55,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": true,
            "result": -21,
            "playerName": "chirag1993",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kh0 Kd0 Ah0/5h0 5c0 8c0 8s0 9s0/3d0 6h0 6d0 Tc0 Ts0",
            "win": -5,
            "playerId": "chirag1993"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:14:04",
    "roomId": "41b-1d6ae9f6"
}


{
    "stakes": 5,
    "handData": {"338198942": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "fishbutton",
            "orderIndex": 1,
            "hero": true,
            "dead": "7s1 9h2 6h3 3d4",
            "rows": "Kd1 2d4 Qc4/Ah0 Ac0 6c2 Ts2 8c3/3s0 4h0 5h0 3h1 5d3",
            "win": -35,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "chirag1993",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kh1 Qh3 9s4/4s0 6s0 7c0 8d3 6d4/Tc0 Jh0 Th1 Td2 Js2",
            "win": 35,
            "playerId": "chirag1993"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:15:53",
    "roomId": "41b-1d6ae9f6"
}


{
    "stakes": 5,
    "handData": {"338199211": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "fishbutton",
            "orderIndex": 0,
            "hero": true,
            "dead": "Kh1 Th2 4s3 Qd4",
            "rows": "Ks0 Kd3 Ts4/5h0 6c0 2c2 5s3 3d4/9h0 9c0 Qc1 Qs1 9s2",
            "win": -105,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": false,
            "result": 33,
            "playerName": "chirag1993",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "As0 Qh1 Ac3/5c0 4h1 5d2 7c2 4d4/8h0 Jc0 Js0 8s3 Jd4",
            "win": 105,
            "playerId": "chirag1993"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:17:35",
    "roomId": "41b-1d6ae9f6"
}


{
    "stakes": 5,
    "handData": {"338199454": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "fishbutton",
            "orderIndex": 1,
            "hero": true,
            "dead": "9c1 8c2 2s3 4s4",
            "rows": "Tc1 Jc4 Qh4/2h0 4h1 4d2 2c3 5c3/3s0 8s0 Qs0 As0 Ts2",
            "win": -125,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": true,
            "result": 33,
            "playerName": "chirag1993",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kh0 Ad0 Ac0/3d0 7d0 8d0 Qd0 Kd0/5h0 5d0 6h0 6c0 6s0",
            "win": 125,
            "playerId": "chirag1993"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:18:27",
    "roomId": "41b-1d6ae9f6"
}


{
    "stakes": 5,
    "handData": {"338199581": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "fishbutton",
            "orderIndex": 0,
            "hero": true,
            "dead": "Tc1 2s2 4c3 5s4",
            "rows": "Ad2 8s3 As4/3h0 7d1 Qd2 7s3 7h4/4d0 4s0 8h0 8d0 8c1",
            "win": 45,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "chirag1993",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ac0 Js2 Ah4/4h0 5d0 2d1 2h3 5h3/6s0 9s0 9h1 6c2 Qs4",
            "win": -45,
            "playerId": "chirag1993"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:20:08",
    "roomId": "41b-1d6ae9f6"
}


{
    "stakes": 5,
    "handData": {"338199842": [
        {
            "inFantasy": true,
            "result": 45,
            "playerName": "fishbutton",
            "orderIndex": 1,
            "hero": true,
            "dead": "5h0 9d0 Qh0",
            "rows": "6h0 6d0 6s0/3c0 6c0 8c0 Tc0 Ac0/2s0 3s0 Ts0 Js0 As0",
            "win": 35,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": true,
            "result": 39,
            "playerName": "chirag1993",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "5c0 Qc0 Ks0/4h0 4d0 4c0 Ah0 Ad0/7h0 7s0 Jh0 Jd0 Jc0",
            "win": -35,
            "playerId": "chirag1993"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:21:01",
    "roomId": "41b-1d6ae9f6"
}


{
    "stakes": 5,
    "handData": {"338199965": [
        {
            "inFantasy": true,
            "result": 15,
            "playerName": "fishbutton",
            "orderIndex": 0,
            "hero": true,
            "dead": "3h0",
            "rows": "Qh0 Kh0 Kd0/6c0 7d0 Jc0 Ah0 As0/2d0 2c0 2s0 8d0 8s0",
            "win": 35,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "chirag1993",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "9d3 9c3 8h4/Td1 Tc1 Ts2 Jd2 7s4/2h0 3s0 4h0 5c0 6d0",
            "win": -35,
            "playerId": "chirag1993"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:21:42",
    "roomId": "41b-1d6ae9f6"
}


{
    "stakes": 5,
    "handData": {"338200062": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "fishbutton",
            "orderIndex": 1,
            "hero": true,
            "dead": "4h1 2c2 4d3 Th4",
            "rows": "Kh0 Ks0 Jh2/3c0 6h0 Ac1 9h4 9c4/Td0 7d1 Qd2 7h3 Qs3",
            "win": -125,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "chirag1993",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qc1 Ts2 Qh2/3s0 6d0 6s1 6c4 Jc4/5h0 5c0 5s0 5d3 Jd3",
            "win": 125,
            "playerId": "chirag1993"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:23:15",
    "roomId": "41b-1d6ae9f6"
}


{
    "stakes": 5,
    "handData": {"338200294": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "fishbutton",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jc1 5s2 Ad3 8s4",
            "rows": "Ks0 Qh3 Qc3/5c0 8c0 Ac1 As1 6s2/Th0 Jh0 Js2 3c4 3s4",
            "win": -55,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": true,
            "result": 9,
            "playerName": "chirag1993",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "9d0 Kh0 Kc0/4d0 6d0 6c0 7h0 7c0/2s0 4s0 9s0 Ts0 Qs0",
            "win": 55,
            "playerId": "chirag1993"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:23:56",
    "roomId": "41b-1d6ae9f6"
}


{
    "stakes": 5,
    "handData": {"338200392": [
        {
            "inFantasy": true,
            "result": 24,
            "playerName": "fishbutton",
            "orderIndex": 1,
            "hero": true,
            "dead": "4h0",
            "rows": "Qd0 Kc0 Ah0/6s0 8c0 9h0 9d0 Jc0/3d0 3s0 7d0 7c0 7s0",
            "win": -20,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "chirag1993",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ac3 As3 Kh4/5h1 5s1 2c2 2s2 8h4/4s0 Th0 Tc0 Jh0 Jd0",
            "win": 20,
            "playerId": "chirag1993"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:24:41",
    "roomId": "41b-1d6ae9f6"
}


{
    "stakes": 5,
    "handData": {"338200502": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "fishbutton",
            "orderIndex": 0,
            "hero": true,
            "dead": "6d1 Tc2 8d3 4s4",
            "rows": "Kh0 Jc2 7s4/2s0 4c0 5s2 2d3 2h4/8c0 Jh0 9s1 Ts1 Qh3",
            "win": -50,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "chirag1993",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "9c0 Ah0 Ad0/4d0 5d0 9d0 Td0 Kd0/6h0 6c0 6s0 Qc0 Qs0",
            "win": 50,
            "playerId": "chirag1993"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:25:30",
    "roomId": "41b-1d6ae9f6"
}


{
    "stakes": 5,
    "handData": {"338200620": [
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "fishbutton",
            "orderIndex": 1,
            "hero": true,
            "dead": "5d1 Qh2 5c3 9c4",
            "rows": "Kh0 Kd0 4d3/Ah0 5h2 Ac2 Js3 Ks4/8s0 9h0 Jh1 Qd1 Tc4",
            "win": 80,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "chirag1993",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kc1 Th3 7c4/2c0 3h0 8d0 4h2 4c2/5s0 6s0 2s1 6d3 9d4",
            "win": -80,
            "playerId": "chirag1993"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:27:20",
    "roomId": "41b-1d6ae9f6"
}


{
    "stakes": 5,
    "handData": {"338200902": [
        {
            "inFantasy": true,
            "result": -30,
            "playerName": "fishbutton",
            "orderIndex": 0,
            "hero": true,
            "dead": "4s0 9c0",
            "rows": "Qh0 Kc0 Ah0/3d0 4d0 7d0 9d0 Qd0/8h0 8d0 8c0 Jd0 Jc0",
            "win": 20,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": false,
            "result": -24,
            "playerName": "chirag1993",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ad3 As3 Ks4/3h1 3c1 2d2 2c2 4h4/5d0 6c0 7s0 8s0 9s0",
            "win": -20,
            "playerId": "chirag1993"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:28:19",
    "roomId": "41b-1d6ae9f6"
}


{
    "stakes": 5,
    "handData": {"338201054": [
        {
            "inFantasy": false,
            "result": 54,
            "playerName": "fishbutton",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qd1 Kh2 5h3 Kd4",
            "rows": "Kc0 Ac1 Ah3/3s0 4d0 3d1 2h2 2d2/6s0 8h0 7h3 7c4 Qh4",
            "win": -150,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": true,
            "result": 60,
            "playerName": "chirag1993",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Jh0 Jd0 Js0/6h0 6d0 6c0 Td0 Ts0/8d0 8s0 9d0 9c0 9s0",
            "win": 150,
            "playerId": "chirag1993"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:29:04",
    "roomId": "41b-1d6ae9f6"
}


{
    "stakes": 5,
    "handData": {"338201173": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "fishbutton",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jh1 7s2 7h3 Kh4",
            "rows": "Qh0 Ad2 Ks3/5h0 6s0 7d1 9d1 9h3/2c0 Tc0 2d2 4h4 Qc4",
            "win": -90,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "chirag1993",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "5c0 7c0 Th0/3s0 4s0 5s0 Js0 Qs0/3d0 4d0 5d0 6d0 Kd0",
            "win": 90,
            "playerId": "chirag1993"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:29:53",
    "roomId": "41b-1d6ae9f6"
}


