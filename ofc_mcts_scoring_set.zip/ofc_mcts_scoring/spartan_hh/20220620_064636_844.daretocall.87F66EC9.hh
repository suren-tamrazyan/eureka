{
    "stakes": 10,
    "handData": {"338176205": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Kainyu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qs0 6c4 Kd4/5d0 5s1 4d2 7d2 7c3/4h0 7h0 Kh0 8h1 Qh3",
            "win": 100,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "daretocall",
            "orderIndex": 0,
            "hero": true,
            "dead": "2c1 2d2 2h3 6h4",
            "rows": "Ac1 Ad2 5h4/Th0 Ts1 9h3 Js3 2s4/3s0 4s0 6s0 Ks0 9s2",
            "win": -100,
            "playerId": "daretocall"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 03:46:36",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338176368": [
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "Kainyu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kh0 Ks0 Ac4/4h0 8d2 As2 Qc3 Ah3/3c0 6c0 3h1 6s1 3s4",
            "win": 140,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "daretocall",
            "orderIndex": 1,
            "hero": true,
            "dead": "5s1 5c2 4d3 4c4",
            "rows": "5h2 6h3 8c3/9s0 Tc0 7h1 7c1 Ad4/2d0 Jh0 Jc0 2c2 2s4",
            "win": -140,
            "playerId": "daretocall"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 03:48:16",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338176518": [
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "Kainyu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "7s0 Td0 Ah0/8d0 8c0 8s0 9d0 9c0/2d0 2s0 Kd0 Kc0 Ks0",
            "win": 200,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "daretocall",
            "orderIndex": 0,
            "hero": true,
            "dead": "7d1 Jd2 2h3 3c4",
            "rows": "Kh1 7h3 Js4/5d0 9s0 3d2 Qh3 Qc4/2c0 6c0 Jc0 Ac1 7c2",
            "win": -200,
            "playerId": "daretocall"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 03:49:05",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338176582": [
        {
            "inFantasy": false,
            "result": 33,
            "playerName": "Kainyu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ah2 9s3 As3/4h0 6s0 6d1 6h2 7s4/8h0 8c0 Js0 8d1 6c4",
            "win": 170,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "daretocall",
            "orderIndex": 1,
            "hero": true,
            "dead": "9h1 Td2 Jh3 Th4",
            "rows": "Qh0 Ad2 2c4/5s0 Ks0 3s1 4s2 2h4/4c0 Ac0 Qc1 9c3 Jc3",
            "win": -170,
            "playerId": "daretocall"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 03:50:46",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338176719": [
        {
            "inFantasy": true,
            "result": 27,
            "playerName": "Kainyu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qh0 Qs0 Ks0/6d0 9d0 Td0 Jd0 Ad0/2h0 2c0 3h0 3d0 3c0",
            "win": 270,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "daretocall",
            "orderIndex": 0,
            "hero": true,
            "dead": "9s1 8s2 8h3 Js4",
            "rows": "Ah0 As2 9h3/3s0 4s0 5d2 4h4 7h4/8c0 9c0 5c1 Qc1 Ac3",
            "win": -270,
            "playerId": "daretocall"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 03:51:59",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338176814": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "Kainyu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kd0 Qc1 Kh2/8d0 9c1 8s2 5h3 9h4/2h0 2s0 Js0 2c3 Qd4",
            "win": -20,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "daretocall",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qs1 Jc2 6c3 Th4",
            "rows": "Kc0 Ks1 Qh4/6d0 2d1 Ac2 6h3 As4/7h0 7s0 Tc0 3h2 7c3",
            "win": 20,
            "playerId": "daretocall"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 03:53:41",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338176954": [
        {
            "inFantasy": true,
            "result": -18,
            "playerName": "Kainyu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Jh0 Kd0 Ks0/4h0 8d0 8c0 Qh0 Qc0/3s0 4d0 5d0 6s0 7c0",
            "win": 0,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": true,
            "result": -24,
            "playerName": "daretocall",
            "orderIndex": 0,
            "hero": true,
            "dead": "2d0 2c0",
            "rows": "4c0 6h0 6d0/7d0 8h0 9c0 Td0 Jc0/3h0 5h0 Th0 Kh0 Ah0",
            "win": 0,
            "playerId": "daretocall"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 03:54:49",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338177044": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "Kainyu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc1 Kh2 5h3/7d0 7c0 9c0 4s2 9h3/8h0 8c0 Tc1 6h4 Kd4",
            "win": -60,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "daretocall",
            "orderIndex": 2,
            "hero": true,
            "dead": "Ts1 2d2 9s3 8d4",
            "rows": "Ks0 Qs2 5s3/Ac0 Td1 Ah1 3s2 4d3/2h0 Th0 Jh0 6c4 7h4",
            "win": -60,
            "playerId": "daretocall"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "NikhilSegel",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qh1 4h3 As4/5c0 7s0 Ad1 2c2 Qd3/9d0 Jd0 Js0 6s2 8s4",
            "win": 120,
            "playerId": "NikhilSegel"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 03:57:40",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338177219": [
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "Kainyu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ah0 Kc2 4d4/3c0 3s0 Tc1 6d2 3h3/9s0 Js0 Jc1 Jh3 Jd4",
            "win": 180,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "daretocall",
            "orderIndex": 1,
            "hero": true,
            "dead": "2s1 3d2 5d3 7d4",
            "rows": "Qc0 Qd1 9c4/Ad0 As0 8d2 4s3 4c4/5h0 9h0 2h1 7h2 6h3",
            "win": 130,
            "playerId": "daretocall"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "NikhilSegel",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qs0 8h4 Kd4/Td0 Ks1 Ac1 6s3 Kh3/4h0 5s0 6c0 7c2 8s2",
            "win": -310,
            "playerId": "NikhilSegel"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 04:00:55",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338177446": [
        {
            "inFantasy": false,
            "result": 33,
            "playerName": "Kainyu",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "As0 9c3 Ah4/7s0 Th0 7h1 2c2 Ts4/8d0 Kd0 9d1 Qd2 Td3",
            "win": 90,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "daretocall",
            "orderIndex": 0,
            "hero": true,
            "dead": "9h0",
            "rows": "8c0 8s0 Jd0/3s0 5h0 Tc0 Kc0 Ks0/2d0 2s0 4h0 4d0 4c0",
            "win": 100,
            "playerId": "daretocall"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "NikhilSegel",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qs1 Kh1 Qc4/3d0 3c0 5s0 5d2 7c3/Jh0 Js0 8h2 6h3 5c4",
            "win": -190,
            "playerId": "NikhilSegel"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 04:03:39",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338177716": [
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "Kainyu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kd0 Ks0 Ac0/4h0 5s0 6s0 7s0 8c0/7h0 7d0 Qh0 Qd0 Qs0",
            "win": 240,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "daretocall",
            "orderIndex": 1,
            "hero": true,
            "dead": "5d1 7c2 6d3 Kh4",
            "rows": "Qc0 As2 8s4/4s0 Jh1 Jc1 9d2 9c3/2h0 Th0 Ts0 4c3 8h4",
            "win": -240,
            "playerId": "daretocall"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 04:04:42",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338177821": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "Kainyu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ah0 8h4 Ks4/3c0 7d0 7s2 7h3 9h3/8s0 Js0 4s1 5s1 Ts2",
            "win": 240,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "daretocall",
            "orderIndex": 1,
            "hero": true,
            "dead": "4c1 4h2 6d3 Kd4",
            "rows": "Kh0 Qc3 Tc4/3s0 6h0 5c1 6s1 3d3/2d0 Jd0 2c2 9d2 8d4",
            "win": -180,
            "playerId": "daretocall"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "NikhilSegel",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "9s0 Qs2 8c3/2h0 6c0 Th1 As2 Kc4/4d0 5d0 Ad1 Ac3 Qd4",
            "win": -60,
            "playerId": "NikhilSegel"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 04:07:47",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338178124": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "Kainyu",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qd0 Ad2 As2/7d0 6d1 6c1 4s3 9c3/2h0 8h0 Kh0 2d4 9s4",
            "win": -160,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "daretocall",
            "orderIndex": 0,
            "hero": true,
            "dead": "7h1 5h2 4d3 5c4",
            "rows": "Kd1 Th2 8d4/8c0 Jh0 6h1 Jc2 3d3/6s0 Ts0 Qs0 7s3 Qc4",
            "win": 10,
            "playerId": "daretocall"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "NikhilSegel",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qh1 5s3 Kc4/2s0 9h0 Ah1 8s2 9d3/7c0 Tc0 Ac0 4c2 2c4",
            "win": 150,
            "playerId": "NikhilSegel"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 04:12:58",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338178565": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "Kainyu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Js1 Ac2 6c4/2d0 5d0 5c1 8d2 Ad4/6h0 9d0 9s0 4c3 9h3",
            "win": 120,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "daretocall",
            "orderIndex": 2,
            "hero": true,
            "dead": "7h1 Jh2 Tc3 Qh4",
            "rows": "As0 2s3 9c4/5h0 8h0 4h2 7c3 3d4/Qd0 Qs0 Kc1 Ks1 Kd2",
            "win": -60,
            "playerId": "daretocall"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "NikhilSegel",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qc1 Ts2 6d3/3h0 8s0 3s1 7s2 7d3/2h0 2c0 Jc0 Td4 Ah4",
            "win": -60,
            "playerId": "NikhilSegel"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 04:16:00",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338178810": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "Kainyu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "As0 Qc2 Qd4/4s0 4h1 6s2 6d3 9c3/5h0 5d0 Tc0 Th1 Kc4",
            "win": -40,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 42,
            "playerName": "daretocall",
            "orderIndex": 1,
            "hero": true,
            "dead": "5c1 7c2 Td3 7d4",
            "rows": "Qh1 Ac1 Ah4/3c0 9h2 9s2 6c3 3s4/8h0 8s0 Jh0 Jd0 Kh3",
            "win": 140,
            "playerId": "daretocall"
        },
        {
            "inFantasy": false,
            "result": 42,
            "playerName": "NikhilSegel",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "9d2 2d3 8d4/4c0 Kd1 3d2 2s3 Ks4/5s0 Ts0 Js0 Qs0 7s1",
            "win": -100,
            "playerId": "NikhilSegel"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 04:18:39",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338179050": [
        {
            "inFantasy": true,
            "result": 57,
            "playerName": "Kainyu",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "6d0 6c0 Ac0/4h0 8d0 9d0 9s0 Jh0/4s0 7s0 Qs0 Ks0 As0",
            "win": -210,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": true,
            "result": 117,
            "playerName": "daretocall",
            "orderIndex": 0,
            "hero": true,
            "dead": "8s0 Qd0 Ad0",
            "rows": "Jd0 Jc0 Js0/2s0 3s0 4d0 5h0 6s0/3c0 4c0 8c0 9c0 Qc0",
            "win": 470,
            "playerId": "daretocall"
        },
        {
            "inFantasy": false,
            "result": 54,
            "playerName": "NikhilSegel",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Td3 Kh3 5c4/Kd1 Kc1 7c2 Tc2 3d4/3h0 7h0 8h0 Th0 Qh0",
            "win": -260,
            "playerId": "NikhilSegel"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 04:20:16",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338179190": [
        {
            "inFantasy": false,
            "result": 48,
            "playerName": "Kainyu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qc0 Qd2 Th4/Kc1 Kh2 2h3 7d3 Tc4/5s0 6c0 7s0 8c0 4s1",
            "win": 140,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "daretocall",
            "orderIndex": 2,
            "hero": true,
            "dead": "4c0",
            "rows": "6s0 8s0 Ac0/2d0 2s0 3s0 9h0 9c0/4h0 6h0 8h0 Jh0 Qh0",
            "win": 0,
            "playerId": "daretocall"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "NikhilSegel",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qs0 Js3 Ks4/Ah0 As0 8d1 9d2 Ts2/3c0 5c0 5d1 Td3 3h4",
            "win": -140,
            "playerId": "NikhilSegel"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 04:22:41",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338179393": [
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "Kainyu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "8c0 9h0 Qh0/5d0 6d0 7d0 9d0 Ad0/Jc0 Js0 Kh0 Kd0 Kc0",
            "win": 200,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "daretocall",
            "orderIndex": 1,
            "hero": true,
            "dead": "7s1 3d2 5s3 Tc4",
            "rows": "4d2 4s3 Jd3/2s0 3c0 5c0 3h1 3s1/9s0 Jh0 8s2 2c4 Td4",
            "win": -200,
            "playerId": "daretocall"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 04:23:31",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338179475": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "Kainyu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ah1 Ad1 7h3/2h0 4h0 9c2 2c3 5d4/8s0 Jd0 Js0 8h2 Kc4",
            "win": -60,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "daretocall",
            "orderIndex": 0,
            "hero": true,
            "dead": "2s1 9h2 2d3 Th4",
            "rows": "As0 Jh2 Ks3/4s0 5c0 3c1 6s1 6c2/7d0 Qd0 Qs3 7s4 8d4",
            "win": 60,
            "playerId": "daretocall"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 04:26:50",
    "roomId": "41b-1d515c57"
}


