{
    "stakes": 10,
    "handData": {"338210375": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "rajprateek1993",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qh0 Th2 Ts2/3h0 9c0 Jh1 Js1 8d4/4d0 5d0 4h3 As3 Ah4",
            "win": -30,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "fishbutton",
            "orderIndex": 1,
            "hero": true,
            "dead": "3c1 Kh2 3d3 5c4",
            "rows": "Qs0 Qc3 Ac4/4c1 8s1 2h2 2d2 4s3/6c0 6s0 9d0 9s0 2s4",
            "win": 30,
            "playerId": "fishbutton"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:16:24",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338210686": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "rajprateek1993",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ah3 As3 9d4/4h1 4c1 Jd2 Kd2 5h4/6c0 6s0 7h0 7s0 Kh0",
            "win": -140,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "fishbutton",
            "orderIndex": 0,
            "hero": true,
            "dead": "2c0",
            "rows": "3h0 4s0 5s0/8s0 9h0 Td0 Jc0 Qc0/3d0 4d0 5d0 8d0 Qd0",
            "win": 140,
            "playerId": "fishbutton"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:17:34",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338210900": [
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "fishbutton",
            "orderIndex": 1,
            "hero": true,
            "dead": "2h1 Jh2 8h3 6c4",
            "rows": "Qh0 Qd0 4d3/4s0 3s1 Ah2 4h3 4c4/7c0 9c0 9s1 7d2 2d4",
            "win": -220,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "Preetkunwar",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qc0 Kh2 Kd4/8d0 8s1 8c2 Ad3 Ts4/7h0 7s0 Js0 Jc1 Jd3",
            "win": 220,
            "playerId": "Preetkunwar"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:19:09",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338211175": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "fishbutton",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qd1 5d2 5h3 9h4",
            "rows": "Kc2 Ah2 As3/2c0 3s0 4d0 2d1 3h4/9c0 Th0 8d1 6s3 7c4",
            "win": -170,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": true,
            "result": -3,
            "playerName": "Preetkunwar",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qh0 Ad0 Ac0/7h0 7d0 7s0 Td0 Ts0/Jh0 Jd0 Jc0 Kd0 Ks0",
            "win": 170,
            "playerId": "Preetkunwar"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:19:45",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338211299": [
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "fishbutton",
            "orderIndex": 1,
            "hero": true,
            "dead": "2h0 4s0 Th0",
            "rows": "Qc0 Ah0 Ad0/3c0 3s0 Jd0 Kh0 Kc0/4c0 5d0 6h0 7s0 8s0",
            "win": 110,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "Preetkunwar",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qh3 Qs3 Kd4/Tc1 Ts1 Jc2 As2 8c4/3h0 4h0 5s0 6d0 9s0",
            "win": -110,
            "playerId": "Preetkunwar"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:20:50",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338211485": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "rajprateek1993",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kd0 Ks3 4h4/8h0 8d0 7h1 9s2 3c4/6c0 Qc0 Jc1 Kc2 5c3",
            "win": -100,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "fishbutton",
            "orderIndex": 0,
            "hero": true,
            "dead": "5d1 4s2 6s3 2s4",
            "rows": "Qs0 7c3 9c4/8c0 Jd1 As1 4d3 Js4/3h0 6h0 Ah0 2h2 Th2",
            "win": 100,
            "playerId": "fishbutton"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:23:04",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338211881": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "rajprateek1993",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "As1 Ad2 Kh3/2h0 2c1 6s2 9d4 Ah4/6c0 7c0 8c0 Jc0 Ac3",
            "win": 0,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "fishbutton",
            "orderIndex": 1,
            "hero": true,
            "dead": "Td1 3h2 2s3 5s4",
            "rows": "Qs0 Qc1 5d4/3s0 4c0 Kc2 Ks2 Qh3/9h0 Jh0 9s1 Th3 4d4",
            "win": 0,
            "playerId": "fishbutton"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:24:36",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338212128": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "rajprateek1993",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ad0 Ah1 Jc3/2h0 3s0 5s0 3c2 2c4/7c0 9s1 Kh2 Qs3 8h4",
            "win": -120,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "fishbutton",
            "orderIndex": 0,
            "hero": true,
            "dead": "Th1 4h2 5c3 9d4",
            "rows": "7s3 Td3 Kc4/2d0 3h0 5d0 4d1 6c4/8c0 Ts0 Jd1 9c2 Qc2",
            "win": 120,
            "playerId": "fishbutton"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:26:30",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338212439": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "rajprateek1993",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "As0 8h4 Js4/4h0 6c1 5d2 4c3 5c3/2d0 2s0 9c0 Jc1 9h2",
            "win": 10,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "fishbutton",
            "orderIndex": 2,
            "hero": true,
            "dead": "4d1 6s2 Th3 8c4",
            "rows": "Kd0 Ad1 Ac3/7h0 8s0 7c1 3s2 3c3/Tc0 Qc0 Qh2 2c4 5s4",
            "win": -160,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "Preetkunwar",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ah1 7s3 Ks4/6h0 Jh0 2h1 3h3 Jd4/3d0 7d0 8d0 9d2 Td2",
            "win": 150,
            "playerId": "Preetkunwar"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:30:51",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338213246": [
        {
            "inFantasy": false,
            "result": 60,
            "playerName": "rajprateek1993",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kh0 8c3 Kc4/2s0 9s0 5d1 5h3 2d4/Jc0 Qd0 7c1 7s2 Qh2",
            "win": 280,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "fishbutton",
            "orderIndex": 0,
            "hero": true,
            "dead": "9d1 Jh2 6h3 Qc4",
            "rows": "As1 Ac2 9c4/3s0 8h0 7d2 5s3 9h4/4c0 4s0 Tc0 Qs1 2h3",
            "win": -200,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "Preetkunwar",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ad0 Ks2 2c3/4h0 8d0 6c2 7h3 6d4/Td0 Ts0 Jd1 Js1 Kd4",
            "win": -80,
            "playerId": "Preetkunwar"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:33:33",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338213798": [
        {
            "inFantasy": true,
            "result": 24,
            "playerName": "rajprateek1993",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "9d0 Th0 Td0/3s0 6s0 8s0 9s0 Ts0/3c0 5c0 6c0 7c0 Jc0",
            "win": 140,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": 42,
            "playerName": "fishbutton",
            "orderIndex": 2,
            "hero": true,
            "dead": "Ah1 6d2 Tc3 4d4",
            "rows": "Qc3 Kc3 Kh4/4s0 5s0 Ks2 As2 7s4/2d0 Qd0 Ad0 8d1 Kd1",
            "win": 280,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "Preetkunwar",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "9c2 Jh3 Ac3/2c0 3d0 3h1 6h2 5d4/7d0 8h0 9h0 Js1 8c4",
            "win": -420,
            "playerId": "Preetkunwar"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:35:54",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338214248": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "rajprateek1993",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ad3 Ac3 Kc4/9d1 9c1 8s2 Jc2 7c4/2h0 3h0 5h0 Th0 Ah0",
            "win": -200,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "fishbutton",
            "orderIndex": 1,
            "hero": true,
            "dead": "2c0 5c0",
            "rows": "6h0 8h0 9h0/4s0 5s0 6s0 Ts0 Ks0/Jh0 Jd0 Js0 Qd0 Qc0",
            "win": 200,
            "playerId": "fishbutton"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:36:53",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338214439": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "rajprateek1993",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kh1 Qs2 Kd3/Js0 Ah2 Ad3 7s4 8s4/5c0 6h0 7h0 8d0 9s1",
            "win": -200,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": 42,
            "playerName": "fishbutton",
            "orderIndex": 0,
            "hero": true,
            "dead": "Td1 Tc2 3c3 Qd4",
            "rows": "Ac0 As1 Ks3/2h0 2d0 4s1 4c3 4h4/9d0 Qc0 9h2 9c2 Qh4",
            "win": 500,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": false,
            "result": 42,
            "playerName": "RIDEME",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "7c3 Kc3 6s4/2c0 8c0 Th1 Ts1 8h2/3h0 3s0 Jd0 3d2 Jh4",
            "win": -300,
            "playerId": "RIDEME"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:39:38",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338214902": [
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "rajprateek1993",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "3h0 3c0 Kh0/5d0 7d0 8d0 Jd0 Kd0/4s0 8s0 9s0 Qs0 Ks0",
            "win": 40,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": true,
            "result": 48,
            "playerName": "fishbutton",
            "orderIndex": 2,
            "hero": true,
            "dead": "3d0 3s0 4d0",
            "rows": "Td0 Ad0 As0/4h0 5h0 8h0 Th0 Qh0/2c0 6c0 Tc0 Qc0 Kc0",
            "win": 160,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "RIDEME",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Jh3 Ac3 9h4/9d1 9c1 7h2 7s2 5c4/2s0 5s0 6s0 Ts0 Js0",
            "win": -200,
            "playerId": "RIDEME"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:41:03",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338215149": [
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "fishbutton",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qs1 3h2 3c3 8c4",
            "rows": "Qd0 Qh1 5s3/4c0 5d0 5h1 Tc3 4d4/9h0 9d0 Ah2 Ac2 4h4",
            "win": 130,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "RIDEME",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "8h1 Kd2 Ks2/3d0 6d0 9c0 9s0 Ts4/Jc0 7c1 Kh3 As3 7s4",
            "win": -130,
            "playerId": "RIDEME"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:42:40",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338215453": [
        {
            "inFantasy": true,
            "result": 15,
            "playerName": "fishbutton",
            "orderIndex": 1,
            "hero": true,
            "dead": "5d0",
            "rows": "8d0 8s0 9s0/8h0 Th0 Jh0 Kh0 Ah0/3h0 3c0 3s0 6c0 6s0",
            "win": 230,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "RIDEME",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ad3 As3 Qc4/9d1 9c1 8c2 9h2 4c4/7h0 7d0 7c0 Td0 Jc0",
            "win": -230,
            "playerId": "RIDEME"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:43:49",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338215675": [
        {
            "inFantasy": false,
            "result": 66,
            "playerName": "rajprateek1993",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ah0 Ad0 6d4/Th1 Td1 5d2 Qd3 5s4/6c0 Qc0 Kc0 9c2 Ac3",
            "win": 340,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "fishbutton",
            "orderIndex": 1,
            "hero": true,
            "dead": "7h1 8d2 2s3 Kd4",
            "rows": "Kh0 Ks1 6s4/9s0 Tc0 8h1 8c3 8s3/Jc0 Js0 2h2 2c2 3h4",
            "win": -290,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "RIDEME",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "9h0 Qs1 6h4/3c0 3s2 7c2 5h3 7s4/7d0 9d0 Jd0 4d1 2d3",
            "win": -50,
            "playerId": "RIDEME"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:47:26",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338216301": [
        {
            "inFantasy": true,
            "result": 24,
            "playerName": "rajprateek1993",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "5d0 Jc0 Ad0/5h0 6s0 7h0 8h0 9d0/3s0 5s0 Js0 Qs0 Ks0",
            "win": 0,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "fishbutton",
            "orderIndex": 0,
            "hero": true,
            "dead": "7s1 6d2 6h3 9c4",
            "rows": "Kc0 9h2 Qd3/4h0 Ah0 5c1 4c3 Qc4/8c0 Td0 8d1 3d2 Ac4",
            "win": -210,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": false,
            "result": 57,
            "playerName": "RIDEME",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kh0 Kd2 Qh3/2d0 6c0 As3 2h4 2s4/7d0 9s0 8s1 Ts1 Jd2",
            "win": 210,
            "playerId": "RIDEME"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:49:32",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338216670": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "rajprateek1993",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc3 Ac3 6h4/3d1 3s1 8s2 Js2 7d4/Th0 Td0 Qh0 Qd0 Qc0",
            "win": -100,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "RIDEME",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Jh0 Ah0 Ad0/3h0 3c0 9s0 Kh0 Ks0/2d0 2c0 4d0 4c0 4s0",
            "win": 100,
            "playerId": "RIDEME"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": false,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:50:44",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338216880": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "rajprateek1993",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qc0 Kd0 Qs1/2c0 As0 2s1 8s2 2d3/Ts0 7h2 5h3 Th4 Ks4",
            "win": -240,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "fishbutton",
            "orderIndex": 1,
            "hero": true,
            "dead": "4s1 4c2 5c3 8h4",
            "rows": "Ac0 Jh3 6s4/Qh0 9h1 7d2 7s2 4h4/3s0 Kh0 Kc0 3d1 3c3",
            "win": 110,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": false,
            "result": 33,
            "playerName": "RIDEME",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "9d1 Ah2 9c3/6c0 7c0 6h1 6d2 Td4/Jd0 Jc0 Js0 8c3 9s4",
            "win": 130,
            "playerId": "RIDEME"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:53:21",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338217322": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "rajprateek1993",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kh0 Kc0 5h3/7d0 6c1 4h2 4s2 Qs4/8h0 8c0 9h1 Qd3 Qh4",
            "win": -210,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": 66,
            "playerName": "fishbutton",
            "orderIndex": 0,
            "hero": true,
            "dead": "Td1 2h2 5d3 Ks4",
            "rows": "Ad0 As0 8d3/6s0 7c1 7h2 3d3 6d4/4c0 Jc0 4d1 Jh2 Kd4",
            "win": 300,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "RIDEME",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Js0 3s4 Ac4/2d0 5c0 2s1 5s2 9d3/8s0 Tc0 Th1 3h2 3c3",
            "win": -90,
            "playerId": "RIDEME"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:56:19",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338217789": [
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "rajprateek1993",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qc0 Kh0 Qs2/5d0 Td1 Tc1 9c2 7h3/3s0 Js0 8s3 Qh4 Ah4",
            "win": -290,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": true,
            "result": 63,
            "playerName": "fishbutton",
            "orderIndex": 2,
            "hero": true,
            "dead": "3c0 4d0 9h0",
            "rows": "Jd0 Ad0 Ac0/4s0 5s0 7s0 9s0 As0/2h0 2d0 2c0 8d0 8c0",
            "win": 360,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "RIDEME",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qd2 Kd2 7d4/3d0 2s1 6s1 4h3 5h4/4c0 5c0 7c0 Jc0 Kc3",
            "win": -70,
            "playerId": "RIDEME"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:58:43",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338218115": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "fishbutton",
            "orderIndex": 0,
            "hero": true,
            "dead": "9c1 Jc2 3d3 6s4",
            "rows": "Js1 Th2 4c3/2c0 6c0 5d1 Kc2 Ks4/7d0 8d0 8s0 7c3 As4",
            "win": -50,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "RIDEME",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "5s1 Qc1 Kd4/2d0 9d0 4d2 Ac3 Ts4/3h0 4h0 Jh0 2h2 6h3",
            "win": 50,
            "playerId": "RIDEME"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:00:26",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338218362": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "fishbutton",
            "orderIndex": 1,
            "hero": true,
            "dead": "7d1 3h2 2d3 5c4",
            "rows": "Kc0 8h3 Qd4/Ad0 Tc1 Ah2 3s3 9d4/5h0 7h0 Jh0 6h1 Kh2",
            "win": 30,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "RIDEME",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Js2 5d4 7s4/2h0 4d0 4h1 2c3 6c3/8d0 9s0 Jc0 7c1 Ts2",
            "win": -30,
            "playerId": "RIDEME"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:01:55",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338218640": [
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "fishbutton",
            "orderIndex": 0,
            "hero": true,
            "dead": "6d1 6c2 7d3 2s4",
            "rows": "Ac0 Kd2 Th4/8s0 5s1 Jd2 9h3 9s3/3d0 3c0 Qh0 3s1 2c4",
            "win": -160,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "RIDEME",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kh0 Kc2 Jc3/2d0 Ad1 6h2 Qs4 Ah4/6s0 7s0 8d0 Tc1 9d3",
            "win": 160,
            "playerId": "RIDEME"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:03:35",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338218963": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "fishbutton",
            "orderIndex": 1,
            "hero": true,
            "dead": "8d1 Kd2 3s3 3d4",
            "rows": "Qd1 9c4 Ah4/2s0 4s0 7d0 2h1 2c2/6h0 Th0 4h2 7h3 9h3",
            "win": -90,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": true,
            "result": 9,
            "playerName": "RIDEME",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "5d0 6c0 6s0/9d0 Ts0 Jh0 Qs0 Kh0/5c0 8c0 Tc0 Jc0 Qc0",
            "win": 90,
            "playerId": "RIDEME"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:04:16",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338219100": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "fishbutton",
            "orderIndex": 0,
            "hero": true,
            "dead": "7s1 Jh2 3h3 7h4",
            "rows": "8d1 As2 Qd4/2c0 5c0 2d2 Tc3 Th4/9d0 Qh0 Qc0 9c1 9s3",
            "win": -10,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "RIDEME",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Ks0 Ts4/5d0 5s0 6c1 6s2 Qs3/Jc0 7c1 Ac2 Ad3 Js4",
            "win": 10,
            "playerId": "RIDEME"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:06:00",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338219417": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "fishbutton",
            "orderIndex": 1,
            "hero": true,
            "dead": "8h1 Tc2 8s3 Ts4",
            "rows": "Kd0 Qh2 6s4/Ad0 4h1 4c1 2s2 2h3/3h0 3c0 7c0 9h3 4s4",
            "win": -190,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": true,
            "result": 33,
            "playerName": "RIDEME",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Jh0 Ac0 As0/6h0 Qc0 Qs0 Kc0 Ks0/4d0 5d0 7d0 Td0 Jd0",
            "win": 190,
            "playerId": "RIDEME"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:06:44",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338219551": [
        {
            "inFantasy": false,
            "result": -27,
            "playerName": "fishbutton",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qd1 Ah2 9h3 2h4",
            "rows": "Kd0 Ad3 9d4/8c1 6c2 7d2 6d3 Ts4/3h0 4h0 5h0 6h0 7h1",
            "win": 0,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "RIDEME",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "4s2 Kh3 Ks4/2c0 3c0 3s0 Th1 2s2/Qh0 Qs0 Js1 Qc3 Jc4",
            "win": 0,
            "playerId": "RIDEME"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:08:22",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338219852": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "fishbutton",
            "orderIndex": 1,
            "hero": true,
            "dead": "Ts1 7h2 Jc3 Tc4",
            "rows": "Kc1 Qs4 Kd4/3h0 4c0 5h1 2h2 6s3/8d0 9h0 9s0 8c2 9d3",
            "win": 60,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": true,
            "result": 0,
            "playerName": "RIDEME",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ks0 Ac0 As0/4h0 4s0 Jh0 Qh0 Qd0/2d0 3d0 5d0 6d0 7d0",
            "win": -60,
            "playerId": "RIDEME"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:09:03",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338219971": [
        {
            "inFantasy": true,
            "result": 33,
            "playerName": "fishbutton",
            "orderIndex": 0,
            "hero": true,
            "dead": "2d0 3s0",
            "rows": "7h0 Ah0 Ad0/5d0 6c0 8h0 8d0 8c0/Td0 Ts0 Jh0 Jd0 Jc0",
            "win": 190,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "RIDEME",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Th3 Kd3 9d4/4d1 4c1 3h2 3d2 6d4/2s0 4s0 6s0 7s0 Ks0",
            "win": -190,
            "playerId": "RIDEME"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:09:49",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338220102": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "Honey17890",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "3s0 Ad1 8c4/2d0 Jd0 7d1 8d2 8s3/9h0 Qh0 Th2 9s3 5d4",
            "win": -230,
            "playerId": "Honey17890"
        },
        {
            "inFantasy": false,
            "result": 57,
            "playerName": "fishbutton",
            "orderIndex": 2,
            "hero": true,
            "dead": "5s1 6s2 Qc3 Ac4",
            "rows": "2h1 Kh1 Ks3/3c0 7c0 7s3 3d4 Tc4/4d0 6d0 Kd0 Td2 Qd2",
            "win": 270,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "RIDEME",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Jc2 Ah2 8h3/5c0 6h0 5h1 2c3 Kc4/4s0 Ts0 Js0 Qs1 As4",
            "win": -40,
            "playerId": "RIDEME"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:12:18",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338220551": [
        {
            "inFantasy": false,
            "result": 42,
            "playerName": "Honey17890",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ad2 Ah3 7h4/2s0 5h0 4h1 4d1 5c4/8d0 8s0 Jh0 8h2 Jd3",
            "win": 220,
            "playerId": "Honey17890"
        },
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "fishbutton",
            "orderIndex": 1,
            "hero": true,
            "dead": "2d0 8c0",
            "rows": "Qh0 Qd0 Kc0/3h0 3d0 9d0 Th0 Td0/6h0 6d0 6c0 7c0 7s0",
            "win": 140,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": false,
            "result": 36,
            "playerName": "RIDEME",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ac2 Jc3 Ks4/2h0 2c0 7d0 3c3 Qc4/Js0 Qs0 9h1 Ts1 Kh2",
            "win": -360,
            "playerId": "RIDEME"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:14:15",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338220920": [
        {
            "inFantasy": true,
            "result": 9,
            "playerName": "Honey17890",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "7h0 8s0 Js0/5h0 5d0 6h0 6c0 6s0/9h0 9d0 9s0 Qh0 Qd0",
            "win": 340,
            "playerId": "Honey17890"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "fishbutton",
            "orderIndex": 0,
            "hero": true,
            "dead": "Kh1 Jh2 Jc3 Jd4",
            "rows": "Ah2 Ad2 Tc4/6d0 8d1 7s3 Th3 7d4/3c0 8c0 Qc0 Ac0 9c1",
            "win": -240,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "RIDEME",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ks0 Kc1 2d3/3h0 4d0 4h2 5c2 3s4/8h0 Ts0 7c1 Td3 5s4",
            "win": -100,
            "playerId": "RIDEME"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:16:38",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338221369": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "Honey17890",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc1 4s2 7d3/2c0 Tc0 Ts2 Jc3 Td4/4h0 8h0 Ah0 5h1 Kd4",
            "win": -230,
            "playerId": "Honey17890"
        },
        {
            "inFantasy": false,
            "result": 54,
            "playerName": "fishbutton",
            "orderIndex": 2,
            "hero": true,
            "dead": "2s1 3c2 As3 Jh4",
            "rows": "Ks0 Qh2 Qc4/5d0 7c0 5s1 7s1 2h4/8s0 9h0 9c2 9d3 9s3",
            "win": 460,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "RIDEME",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ac0 Ad1 8d3/2d0 6h0 6d2 Th2 Kh4/3d0 3s0 Qd1 Js3 3h4",
            "win": -230,
            "playerId": "RIDEME"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:19:06",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338221810": [
        {
            "inFantasy": false,
            "result": 51,
            "playerName": "Honey17890",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ks1 6d3 Qs4/3s0 4h0 Ah1 7s3 Qd4/2h0 2c0 8d0 9h2 9s2",
            "win": -270,
            "playerId": "Honey17890"
        },
        {
            "inFantasy": true,
            "result": 114,
            "playerName": "fishbutton",
            "orderIndex": 1,
            "hero": true,
            "dead": "9c0",
            "rows": "Th0 Td0 Tc0/2s0 Qh0 Kh0 Kd0 Kc0/6h0 6c0 6s0 8c0 8s0",
            "win": 540,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": false,
            "result": 51,
            "playerName": "RIDEME",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ad2 As2 7h4/7c0 8h1 9d1 Jh3 4s4/5h0 5c0 Jd0 Js0 Jc3",
            "win": -270,
            "playerId": "RIDEME"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:20:51",
    "roomId": "41b-1d7888fa"
}


