{
    "stakes": 10,
    "handData": {"338226955": [
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "rajsinha112",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc1 Ks2 Jd3/5d0 6d0 7s1 7d3 6h4/9d0 9c0 Ts0 9s2 Tc4",
            "win": 130,
            "playerId": "rajsinha112"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "doorwindow",
            "orderIndex": 0,
            "hero": true,
            "dead": "Td1 7c2 Qc3 9h4",
            "rows": "Qh0 4d4 Th4/8c0 Kh1 3d2 3s2 8d3/3c0 4s0 5h0 As1 2c3",
            "win": -130,
            "playerId": "doorwindow"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:47:36",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338227265": [
        {
            "inFantasy": true,
            "result": 27,
            "playerName": "rajsinha112",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qh0 Qs0 Ks0/4s0 5h0 6s0 7c0 8c0/2d0 2c0 Jh0 Jd0 Jc0",
            "win": 190,
            "playerId": "rajsinha112"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "doorwindow",
            "orderIndex": 1,
            "hero": true,
            "dead": "5s1 Ad2 Js3 4h4",
            "rows": "Kd1 7d4 Th4/8s0 9h0 7s2 8h3 9d3/6c0 Kc0 Ac0 4c1 9c2",
            "win": -190,
            "playerId": "doorwindow"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:48:22",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338227401": [
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "rajsinha112",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Jh2 Ad3 Qc4/2d0 3c0 5h0 3d1 5s2/6h0 6s0 9s1 4s3 8d4",
            "win": -140,
            "playerId": "rajsinha112"
        },
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "doorwindow",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ac1 6d2 3s3 9c4",
            "rows": "Kh0 8s3 Kc3/Ah0 As0 Jc1 4c2 9h4/7d0 Td0 Tc1 7s2 8c4",
            "win": 140,
            "playerId": "doorwindow"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:49:55",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338227693": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "rajsinha112",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Js3 Ah3 8s4/Qd1 Qc1 Td2 Ts2 2d4/2s0 5s0 9s0 Qs0 Ks0",
            "win": -60,
            "playerId": "rajsinha112"
        },
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "doorwindow",
            "orderIndex": 1,
            "hero": true,
            "dead": "2c0 3h0",
            "rows": "Kd0 Ad0 As0/4d0 4s0 6h0 7h0 7c0/8d0 9d0 Tc0 Jd0 Qh0",
            "win": 60,
            "playerId": "doorwindow"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:50:59",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338227871": [
        {
            "inFantasy": false,
            "result": 33,
            "playerName": "rajsinha112",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ah0 Ac1 2c4/2h0 3d0 3c0 2d2 Qc4/4s0 4d1 Jc2 Qd3 Qs3",
            "win": 150,
            "playerId": "rajsinha112"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "doorwindow",
            "orderIndex": 0,
            "hero": true,
            "dead": "8c1 As2 5d3 9c4",
            "rows": "Kd0 Kc3 Ad3/3s0 4c0 4h2 6s2 7d4/9h0 9d0 7h1 7c1 5s4",
            "win": -150,
            "playerId": "doorwindow"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:52:33",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338228191": [
        {
            "inFantasy": true,
            "result": 54,
            "playerName": "rajsinha112",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "8d0 8c0 8s0/4d0 5d0 Td0 Qd0 Ad0/4h0 7h0 9h0 Kh0 Ah0",
            "win": 300,
            "playerId": "rajsinha112"
        },
        {
            "inFantasy": false,
            "result": 42,
            "playerName": "doorwindow",
            "orderIndex": 1,
            "hero": true,
            "dead": "7s1 Jd2 6s3 Th4",
            "rows": "Qs2 2h3 Ac4/4c0 9s0 7d1 4s3 Qc4/3h0 5h0 Jh0 6h1 8h2",
            "win": -300,
            "playerId": "doorwindow"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:53:49",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338228420": [
        {
            "inFantasy": true,
            "result": 12,
            "playerName": "rajsinha112",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "8h0 8d0 Kd0/6c0 7c0 9c0 Jc0 Ac0/4h0 4d0 4c0 4s0 Td0",
            "win": 50,
            "playerId": "rajsinha112"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "doorwindow",
            "orderIndex": 0,
            "hero": true,
            "dead": "3d1 Tc2 2d3 8c4",
            "rows": "Ad0 7d3 5d4/9s0 Qs1 Ks1 Ts3 2c4/6h0 Th0 Kh0 2h2 3h2",
            "win": -50,
            "playerId": "doorwindow"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:54:30",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338228560": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "rajsinha112",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qs0 Ks1 Qd3/Jh0 As2 7h3 5d4 Ts4/3c0 7c0 Ac0 9c1 Qc2",
            "win": -120,
            "playerId": "rajsinha112"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "doorwindow",
            "orderIndex": 2,
            "hero": true,
            "dead": "8c1 5c2 Kc3 Ad4",
            "rows": "Js1 Tc2 Jc3/2d0 2s2 8d3 3d4 Td4/3h0 4h0 Qh0 Ah0 Kh1",
            "win": -120,
            "playerId": "doorwindow"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "rajprateek1993",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kd0 Jd2 Th3/4c0 8h0 5h1 5s2 4d4/9d0 9s0 6s1 6c3 6h4",
            "win": 240,
            "playerId": "rajprateek1993"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:57:05",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338229025": [
        {
            "inFantasy": false,
            "result": 48,
            "playerName": "rajsinha112",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qd1 Qh2 Ks4/2d0 2s0 5d0 4c2 5h4/Th0 Td0 9s1 8d3 8s3",
            "win": 80,
            "playerId": "rajsinha112"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "doorwindow",
            "orderIndex": 1,
            "hero": true,
            "dead": "7d1 4h2 9d3 6d4",
            "rows": "Ah0 7c2 Jd3/8h1 Kc1 2h2 3h3 Ac4/6s0 7s0 Js0 As0 4s4",
            "win": -30,
            "playerId": "doorwindow"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "rajprateek1993",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kh1 9h3 Qc4/3s0 4d0 Ad1 3c3 6h4/5c0 9c0 Jc0 6c2 Tc2",
            "win": -50,
            "playerId": "rajprateek1993"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:00:13",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338229660": [
        {
            "inFantasy": true,
            "result": 3,
            "playerName": "rajsinha112",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Tc0 Jd0 Qd0/2h0 6h0 8h0 9h0 Th0/3s0 6s0 7s0 Js0 As0",
            "win": 270,
            "playerId": "rajsinha112"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "doorwindow",
            "orderIndex": 0,
            "hero": true,
            "dead": "6c1 Qc2 8c3 Ah4",
            "rows": "Kd0 Ks0 Qh2/2c0 3h0 5s1 5c2 Jh4/9d0 9c1 6d3 Kc3 7h4",
            "win": -280,
            "playerId": "doorwindow"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "rajprateek1993",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qs0 Ad2 7d4/2d0 8d1 8s2 2s3 Td3/3c0 Jc0 Ac0 4c1 7c4",
            "win": 10,
            "playerId": "rajprateek1993"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:02:35",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338230156": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "rajsinha112",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Jc2 Kh3/4d0 5s0 4c1 4s1 8s2/7h0 Qh0 7s3 5h4 Qs4",
            "win": -270,
            "playerId": "rajsinha112"
        },
        {
            "inFantasy": false,
            "result": 63,
            "playerName": "doorwindow",
            "orderIndex": 2,
            "hero": true,
            "dead": "Qc1 8h2 9h3 7d4",
            "rows": "Ah0 As0 Ks4/3c0 5c0 6d1 6s1 3h2/Js0 9d2 Jh3 Jd3 Kd4",
            "win": 190,
            "playerId": "doorwindow"
        },
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "rajprateek1993",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qd0 9s3 5d4/3s0 6h0 Ac2 2h3 6c4/2d0 2c0 Tc1 Ts1 Th2",
            "win": 80,
            "playerId": "rajprateek1993"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:06:02",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338230812": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "rajsinha112",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kh1 Qc3 Jc4/4h0 7h0 4s2 6s2 7s3/3d0 Qd0 Kd0 8d1 Td4",
            "win": 50,
            "playerId": "rajsinha112"
        },
        {
            "inFantasy": true,
            "result": 9,
            "playerName": "doorwindow",
            "orderIndex": 1,
            "hero": true,
            "dead": "3s0 5h0 6d0",
            "rows": "2h0 2d0 9d0/Ts0 Jd0 Qh0 Ks0 Ah0/3c0 6c0 7c0 8c0 9c0",
            "win": 190,
            "playerId": "doorwindow"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "rajprateek1993",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "8s1 Ad2 Qs3/3h0 7d0 9h0 9s1 Jh3/4c0 Kc0 Tc2 Js4 As4",
            "win": -240,
            "playerId": "rajprateek1993"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:08:52",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338231345": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "doorwindow",
            "orderIndex": 1,
            "hero": true,
            "dead": "5h1 7s2 4h3 Qs4",
            "rows": "Qh0 Jd2 Jc3/5c0 Kc0 4s1 Ks2 Ad4/3d0 8d0 8s1 3s3 3c4",
            "win": 40,
            "playerId": "doorwindow"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "rajprateek1993",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Th3 Td3 6c4/Jh0 6d1 6s2 Js2 Kh4/2c0 4c0 8c0 9c0 Tc1",
            "win": -40,
            "playerId": "rajprateek1993"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:10:17",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338231603": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "rajsinha112",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ah0 Ks3 Ac3/4h0 4d0 4s2 9c2 9d4/Td0 Qc0 6h1 6d1 8d4",
            "win": 0,
            "playerId": "rajsinha112"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "doorwindow",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qh1 Jh2 6s3 9s4",
            "rows": "Kc0 As1 Ad3/3h0 3d0 5h2 7h3 5s4/7c0 Jc0 Tc1 6c2 2s4",
            "win": 0,
            "playerId": "doorwindow"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "rajprateek1993",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kd1 9h3 7d4/3c0 5d0 2h2 2c2 2d3/Ts0 Js0 Qs0 7s1 Jd4",
            "win": 0,
            "playerId": "rajprateek1993"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:13:36",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338232182": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "rajsinha112",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Ac1 5c3/2d0 4h0 5s0 5h1 Kh3/Td0 8d2 Qh2 9s4 Ah4",
            "win": 0,
            "playerId": "rajsinha112"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "doorwindow",
            "orderIndex": 0,
            "hero": true,
            "dead": "2s1 Ts2 7d3 Jd4",
            "rows": "Qc0 Jc1 Qd3/9h0 Kd0 Ks0 Ad3 4d4/5d0 6d1 7s2 9c2 3s4",
            "win": 0,
            "playerId": "doorwindow"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:15:51",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338232557": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "doorwindow",
            "orderIndex": 1,
            "hero": true,
            "dead": "6c1 9s2 As3 5s4",
            "rows": "8s0 Qc1 Jc4/2d0 4d0 Kd2 Kh3 2c4/3h0 Qh0 8h1 Jh2 Ah3",
            "win": 10,
            "playerId": "doorwindow"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "rajprateek1993",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kc0 8c2 Js4/4s0 6s0 7s1 3c2 Ad4/3d0 Jd0 5d1 6d3 8d3",
            "win": -10,
            "playerId": "rajprateek1993"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:17:27",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338232840": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ah3 Ac3 7s4/7d0 Td0 8d1 4d2 8c4/3s0 4s0 As0 Qs1 2s2",
            "win": 0,
            "playerId": "Tgomegan"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "doorwindow",
            "orderIndex": 1,
            "hero": true,
            "dead": "5d1 9c2 Jh3 5h4",
            "rows": "Ks0 Jd1 Kh2/9h0 Ts0 Ad1 3d4 8h4/2c0 6c0 6h2 4h3 7h3",
            "win": 0,
            "playerId": "doorwindow"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "rajprateek1993",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qc0 Qh1 Qd4/2d0 3h0 3c1 2h3 Js3/7c0 8s0 9d2 9s2 Th4",
            "win": 0,
            "playerId": "rajprateek1993"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:20:09",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338233357": [
        {
            "inFantasy": false,
            "result": 57,
            "playerName": "Tgomegan",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ks0 Tc2 Kc2/3h0 5c0 4d1 4c3 3d4/6s0 Js0 Jh1 8d3 Jd4",
            "win": 150,
            "playerId": "Tgomegan"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "doorwindow",
            "orderIndex": 0,
            "hero": true,
            "dead": "2c1 7d2 6c3 7s4",
            "rows": "Ad2 Kh3 6h4/7c0 Th0 4h1 Ts2 4s3/5s0 Qd0 Qc0 5h1 5d4",
            "win": 110,
            "playerId": "doorwindow"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "rajprateek1993",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qh0 Ah2 Ac2/2h0 2d0 7h3 Jc3 3c4/8s0 9d0 9h1 9c1 8c4",
            "win": -260,
            "playerId": "rajprateek1993"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:22:30",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338233799": [
        {
            "inFantasy": true,
            "result": 18,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Jc0 Qc0 Qs0/2d0 3c0 4c0 5c0 6d0/2h0 9h0 Th0 Kh0 Ah0",
            "win": 280,
            "playerId": "Tgomegan"
        },
        {
            "inFantasy": false,
            "result": 36,
            "playerName": "doorwindow",
            "orderIndex": 2,
            "hero": true,
            "dead": "Kc1 7h2 6s3 Jd4",
            "rows": "Ks0 Kd1 Jh3/Ac0 2s2 4d2 5d3 Tc4/3h0 3s0 8h0 8d1 2c4",
            "win": -360,
            "playerId": "doorwindow"
        },
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "rajprateek1993",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ad0 As2 5s4/Ts0 7c1 9c1 Td2 9d3/6h0 6c0 Qh0 Qd3 5h4",
            "win": 80,
            "playerId": "rajprateek1993"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:24:29",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338234158": [
        {
            "inFantasy": false,
            "result": 45,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "7s1 Ah2 As3/2h0 5s0 6h0 2s2 6c3/Td0 Qd0 Qc1 9c4 Ts4",
            "win": -110,
            "playerId": "Tgomegan"
        },
        {
            "inFantasy": false,
            "result": 63,
            "playerName": "doorwindow",
            "orderIndex": 1,
            "hero": true,
            "dead": "2c1 7c2 4d3 5c4",
            "rows": "Ac0 Th2 Qh4/3h0 5d0 4s1 3s2 5h3/9h0 9d0 Kc1 8s3 Kh4",
            "win": -250,
            "playerId": "doorwindow"
        },
        {
            "inFantasy": true,
            "result": 72,
            "playerName": "rajprateek1993",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "8h0 8d0 8c0/9s0 Tc0 Jc0 Qs0 Kd0/3d0 6d0 7d0 Jd0 Ad0",
            "win": 360,
            "playerId": "rajprateek1993"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:26:48",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338234575": [
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Th0 Tc0 Ts0/5c0 6h0 7d0 8h0 9c0/3s0 4s0 5s0 8s0 9s0",
            "win": 20,
            "playerId": "Tgomegan"
        },
        {
            "inFantasy": true,
            "result": 24,
            "playerName": "rajprateek1993",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kh0 Ah0 Ad0/4d0 5d0 8d0 9d0 Kd0/3d0 3c0 Jh0 Jd0 Jc0",
            "win": -20,
            "playerId": "rajprateek1993"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": false,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:27:25",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338234678": [
        {
            "inFantasy": true,
            "result": -27,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "7d0 Jc0 Qd0/3h0 5h0 6h0 9h0 Kh0/4d0 4s0 Ah0 Ac0 As0",
            "win": 70,
            "playerId": "Tgomegan"
        },
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "rajprateek1993",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kd3 Kc3 Ad4/5d1 5c1 4h2 4c2 9s4/Th0 Ts0 Jh0 Js0 Qs0",
            "win": -70,
            "playerId": "rajprateek1993"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": false,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:28:14",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338234833": [
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ah3 As3 3c4/4d1 4s1 2h2 2c2 5c4/5d0 Ts0 Qd0 Kh0 Kd0",
            "win": -150,
            "playerId": "Tgomegan"
        },
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "rajprateek1993",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Td0 Tc0 Js0/5h0 6d0 6s0 8h0 8d0/4c0 7c0 9c0 Kc0 Ac0",
            "win": 150,
            "playerId": "rajprateek1993"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": false,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:29:09",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338235014": [
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "Tgomegan",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kd0 Kc1 2c4/3d0 3c2 8h2 3h3 4c4/8s0 9h0 Jc0 7h1 Th3",
            "win": 30,
            "playerId": "Tgomegan"
        },
        {
            "inFantasy": false,
            "result": 36,
            "playerName": "doorwindow",
            "orderIndex": 0,
            "hero": true,
            "dead": "Td1 2s2 4d3 4s4",
            "rows": "As0 Ac2 Js4/9c0 6d1 6s1 7d3 9d4/2h0 6h0 Kh0 4h2 Qh3",
            "win": 100,
            "playerId": "doorwindow"
        },
        {
            "inFantasy": false,
            "result": 45,
            "playerName": "rajprateek1993",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Tc2 Ah3 Ks4/6c0 9s0 5c1 5s2 5h3/2d0 5d0 Qd0 8d1 Jd4",
            "win": -130,
            "playerId": "rajprateek1993"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:31:49",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338235568": [
        {
            "inFantasy": true,
            "result": 51,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "6h0 Ts0 Qs0/3c0 5c0 Tc0 Qc0 Kc0/7h0 7c0 7s0 9h0 9d0",
            "win": 110,
            "playerId": "Tgomegan"
        },
        {
            "inFantasy": true,
            "result": 102,
            "playerName": "doorwindow",
            "orderIndex": 2,
            "hero": true,
            "dead": "2c0 9c0 Ad0",
            "rows": "8h0 8d0 8c0/2h0 3h0 4c0 5d0 6d0/6s0 8s0 Js0 Ks0 As0",
            "win": 260,
            "playerId": "doorwindow"
        },
        {
            "inFantasy": false,
            "result": 39,
            "playerName": "rajprateek1993",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ah3 Ac3 Qd4/Jd1 Jc1 2d2 2s2 Td4/4h0 5s0 6c0 7d0 Jh0",
            "win": -370,
            "playerId": "rajprateek1993"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:33:09",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338235831": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Th3 Qc3 7s4/Ac1 As1 5h2 Jd2 3s4/4c0 6d0 6s0 9h0 9c0",
            "win": -70,
            "playerId": "Tgomegan"
        },
        {
            "inFantasy": true,
            "result": 9,
            "playerName": "doorwindow",
            "orderIndex": 1,
            "hero": true,
            "dead": "2h0",
            "rows": "4d0 7h0 7c0/3h0 6h0 8d0 8c0 Ad0/2s0 9s0 Js0 Qs0 Ks0",
            "win": 70,
            "playerId": "doorwindow"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:34:12",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338236017": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "Tgomegan",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qh0 Qs2 Js3/2d0 Ad0 Ah1 2h3 2s4/6s0 7d0 9s1 Tc2 9c4",
            "win": -250,
            "playerId": "Tgomegan"
        },
        {
            "inFantasy": false,
            "result": 48,
            "playerName": "doorwindow",
            "orderIndex": 0,
            "hero": true,
            "dead": "6d1 7s2 5c3 5s4",
            "rows": "Kd0 Ks1 5d4/As0 Jc1 4c2 Ac2 Kc3/3c0 3s0 9h0 8h3 3d4",
            "win": 160,
            "playerId": "doorwindow"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "rajprateek1993",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qd0 8c4 8s4/4d1 4s2 5h2 6h3 6c3/7h0 8d0 9d0 Ts0 Jh1",
            "win": 90,
            "playerId": "rajprateek1993"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:36:43",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338236493": [
        {
            "inFantasy": false,
            "result": 36,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "4s0 3d2 7s2/6c0 9c0 Jc1 Qc1 4d3/2h0 Th0 Kh3 8d4 9d4",
            "win": -250,
            "playerId": "Tgomegan"
        },
        {
            "inFantasy": true,
            "result": 18,
            "playerName": "doorwindow",
            "orderIndex": 2,
            "hero": true,
            "dead": "6s0 7h0",
            "rows": "Td0 Qh0 Qd0/2c0 3c0 4c0 7c0 8c0/2d0 2s0 Jh0 Jd0 Js0",
            "win": 250,
            "playerId": "doorwindow"
        },
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "rajprateek1993",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qs0 Kd0 Ks1/Ac0 5s3 Ah3 4h4 Tc4/7d0 9s0 6d1 6h2 9h2",
            "win": 0,
            "playerId": "rajprateek1993"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:39:04",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338236923": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "doorwindow",
            "orderIndex": 0,
            "hero": true,
            "dead": "2d1 2c2 7c3 8s4",
            "rows": "5s2 7d2 Kd4/3s0 9d0 Tc1 Ad3 8h4/2h0 4h0 6h0 Qh1 3h3",
            "win": -160,
            "playerId": "doorwindow"
        },
        {
            "inFantasy": true,
            "result": 24,
            "playerName": "rajprateek1993",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Jh0 Jd0 Qd0/5h0 6d0 7s0 8c0 9h0/4c0 5c0 6c0 Kc0 Ac0",
            "win": 160,
            "playerId": "rajprateek1993"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:40:00",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338237076": [
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "Tgomegan",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ah0 Kd2 Qd3/7c0 Jh0 Jd2 8h3 Th4/2s0 Qs0 4s1 6s1 Ts4",
            "win": 110,
            "playerId": "Tgomegan"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "doorwindow",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ks1 6d2 2h3 Kc4",
            "rows": "As0 Ad2 9c4/3h0 3d0 7h0 7d1 4d3/Qc0 Qh1 5d2 Td3 8c4",
            "win": -200,
            "playerId": "doorwindow"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "rajprateek1993",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ac0 Kh2 9h4/4h0 4c0 2d1 2c1 Jc3/8s0 9s0 7s2 Js3 5s4",
            "win": 90,
            "playerId": "rajprateek1993"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:42:48",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338237603": [
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "7s0 Qh2 As3/2d0 Td0 2s1 7c2 3c4/5c0 Jc0 Js1 Jh3 6c4",
            "win": -40,
            "playerId": "Tgomegan"
        },
        {
            "inFantasy": false,
            "result": 63,
            "playerName": "doorwindow",
            "orderIndex": 2,
            "hero": true,
            "dead": "7h1 5d2 9c3 Ad4",
            "rows": "Ah0 Ac1 8d4/4c0 4s0 8c0 8s1 5h2/Th0 Ts2 6h3 Qs3 Qc4",
            "win": 250,
            "playerId": "doorwindow"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "rajprateek1993",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Tc2 Kd3 Kc3/2c0 3s0 4d0 2h1 Ks4/9s0 Jd0 9d1 9h2 5s4",
            "win": -210,
            "playerId": "rajprateek1993"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:45:31",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338238078": [
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qh0 Ac2 As2/8h0 8c1 4c3 5h3 5s4/6h0 6d0 Jc0 6s1 Qs4",
            "win": -70,
            "playerId": "Tgomegan"
        },
        {
            "inFantasy": true,
            "result": 18,
            "playerName": "doorwindow",
            "orderIndex": 1,
            "hero": true,
            "dead": "2d0 3c0 4s0",
            "rows": "Ts0 Qd0 Qc0/3h0 4h0 9h0 Th0 Jh0/5d0 5c0 7h0 7d0 7s0",
            "win": 360,
            "playerId": "doorwindow"
        },
        {
            "inFantasy": false,
            "result": 39,
            "playerName": "rajprateek1993",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ad1 Kh2 Js4/8s0 9d0 8d2 3d3 3s3/2c0 6c0 Tc0 7c1 Kc4",
            "win": -290,
            "playerId": "rajprateek1993"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:48:14",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338238547": [
        {
            "inFantasy": true,
            "result": 33,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ks0 Ac0 As0/5c0 6c0 7h0 8s0 9d0/4d0 4c0 Jd0 Jc0 Js0",
            "win": 250,
            "playerId": "Tgomegan"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "doorwindow",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qh1 4s2 Qd3 Kd4",
            "rows": "Ah0 5d2 Ad3/8d0 9s1 Th1 Ts3 Jh4/2c0 3c0 Qc0 Kc2 2s4",
            "win": -250,
            "playerId": "doorwindow"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:49:05",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338238680": [
        {
            "inFantasy": false,
            "result": -24,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qs1 Kd3 Ah4/3h0 5h0 4h1 9h2 8h3/4c0 Tc0 Ac0 Kc2 6c4",
            "win": 20,
            "playerId": "Tgomegan"
        },
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "doorwindow",
            "orderIndex": 1,
            "hero": true,
            "dead": "2c1 7c2 7h3 Th4",
            "rows": "Qh0 Jh1 Qc3/4s0 Ks0 Kh1 9s2 4d4/8d0 9d0 Td2 Qd3 3d4",
            "win": -20,
            "playerId": "doorwindow"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:50:45",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338238955": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc3 Ks3 9c4/Jh1 Jc1 4h2 4d2 5s4/2h0 2d0 2c0 Qh0 Qc0",
            "win": 20,
            "playerId": "Tgomegan"
        },
        {
            "inFantasy": true,
            "result": 0,
            "playerName": "doorwindow",
            "orderIndex": 0,
            "hero": true,
            "dead": "3s0",
            "rows": "Kd0 Ah0 Ad0/Tc0 Ts0 Jd0 Js0 Kh0/5h0 6c0 7h0 8c0 9s0",
            "win": -20,
            "playerId": "doorwindow"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:51:30",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338239082": [
        {
            "inFantasy": true,
            "result": 15,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "8h0 8s0 Td0/2c0 3d0 4c0 5s0 6s0/3h0 4h0 5h0 6h0 Jh0",
            "win": 150,
            "playerId": "Tgomegan"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "doorwindow",
            "orderIndex": 1,
            "hero": true,
            "dead": "Th1 7d2 Jd3 5d4",
            "rows": "Jc2 Kd3 As3/3c0 6d0 2d1 6c2 8d4/Tc0 Js0 Qs0 8c1 9s4",
            "win": -150,
            "playerId": "doorwindow"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:52:29",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338239242": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "9c0 Ah3 8d4/4h0 Kh2 Kd2 3d3 Ks4/9d0 Td0 Jd0 2d1 5d1",
            "win": -250,
            "playerId": "Tgomegan"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "doorwindow",
            "orderIndex": 0,
            "hero": true,
            "dead": "6h1 2h2 5s3 8c4",
            "rows": "Qh0 6s3 Qc3/4s0 7d2 7c2 4d4 4c4/8h0 Jh0 Jc0 8s1 Js1",
            "win": 250,
            "playerId": "doorwindow"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:54:18",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338239547": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Js3 Ah3 2c4/4d1 4c1 4h2 Td2 9d4/5c0 6c0 6s0 7d0 7c0",
            "win": -180,
            "playerId": "Tgomegan"
        },
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "doorwindow",
            "orderIndex": 1,
            "hero": true,
            "dead": "3d0",
            "rows": "Th0 Kh0 Ad0/3c0 8c0 9c0 Qc0 Kc0/2s0 7s0 9s0 Qs0 As0",
            "win": 180,
            "playerId": "doorwindow"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:55:14",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338239695": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "Tgomegan",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kc1 Qc3 6h4/4c0 9s0 7h2 4s3 4d4/Th0 Tc0 Jh0 Td1 8h2",
            "win": -260,
            "playerId": "Tgomegan"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "doorwindow",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ac1 7c2 Ad3 8c4",
            "rows": "Qd0 2c3 7d3/5s0 8s0 Ks1 Ts2 Qs4/9d0 9c0 3s1 3d2 9h4",
            "win": 120,
            "playerId": "doorwindow"
        },
        {
            "inFantasy": false,
            "result": 54,
            "playerName": "PARIS_to_ROME",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kh0 Kd2 Qh3/6s0 As0 2d3 6d4 Ah4/5h0 5c0 Jc1 Js1 Jd2",
            "win": 140,
            "playerId": "PARIS_to_ROME"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:57:58",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338240106": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "As0 Qh4 Ah4/2d0 3c0 2h1 3h1 9d3/8s0 Qs0 7h2 7s2 8h3",
            "win": -20,
            "playerId": "Tgomegan"
        },
        {
            "inFantasy": false,
            "result": 36,
            "playerName": "doorwindow",
            "orderIndex": 2,
            "hero": true,
            "dead": "5s1 3d2 Tc3 4s4",
            "rows": "3s0 Ac2 Qc3/5c0 8c0 9h2 Kc3 9s4/7d0 Jd0 7c1 Jh1 9c4",
            "win": -360,
            "playerId": "doorwindow"
        },
        {
            "inFantasy": true,
            "result": 12,
            "playerName": "PARIS_to_ROME",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Jc0 Js0 Kh0/5d0 6d0 Qd0 Kd0 Ad0/4h0 4c0 Th0 Td0 Ts0",
            "win": 380,
            "playerId": "PARIS_to_ROME"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:59:56",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338240411": [
        {
            "inFantasy": true,
            "result": 57,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "8h0 8d0 8c0/2c0 3d0 4s0 5d0 6s0/2d0 6d0 9d0 Td0 Kd0",
            "win": 410,
            "playerId": "Tgomegan"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "doorwindow",
            "orderIndex": 1,
            "hero": true,
            "dead": "2s1 3h2 3c3 4h4",
            "rows": "Ad2 Ac2 7d4/7s0 Jd0 9h1 9c1 7h3/6c0 Qh0 Qd0 Ts3 Qs4",
            "win": -210,
            "playerId": "doorwindow"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "PARIS_to_ROME",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ks0 Jh3 Kh4/3s1 As1 5s2 2h3 Ah4/5h0 6h0 7c0 8s0 4c2",
            "win": -200,
            "playerId": "PARIS_to_ROME"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:02:02",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338240729": [
        {
            "inFantasy": true,
            "result": 3,
            "playerName": "Tgomegan",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Td0 Qd0 Qc0/2s0 3h0 3s0 9d0 9s0/2c0 4c0 5c0 6c0 Ac0",
            "win": -100,
            "playerId": "Tgomegan"
        },
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "doorwindow",
            "orderIndex": 0,
            "hero": true,
            "dead": "4d0 6h0 8h0",
            "rows": "Kd0 Ah0 Ad0/5h0 5d0 5s0 Tc0 Ts0/7h0 7d0 7c0 7s0 Jh0",
            "win": 150,
            "playerId": "doorwindow"
        },
        {
            "inFantasy": true,
            "result": 0,
            "playerName": "PARIS_to_ROME",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Jd0 Js0 As0/6d0 9c0 Qs0 Kh0 Ks0/3d0 3c0 8d0 8c0 8s0",
            "win": -50,
            "playerId": "PARIS_to_ROME"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:02:50",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338240865": [
        {
            "inFantasy": false,
            "result": -42,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kd0 Kh1 Qh4/4h0 7s2 8s2 Ah3 As3/5s0 Th0 Ts0 Tc1 Jd4",
            "win": -80,
            "playerId": "Tgomegan"
        },
        {
            "inFantasy": true,
            "result": -30,
            "playerName": "doorwindow",
            "orderIndex": 2,
            "hero": true,
            "dead": "4s0",
            "rows": "3d0 6s0 8h0/2c0 3c0 7c0 8c0 Jc0/5h0 5d0 5c0 9d0 9s0",
            "win": 140,
            "playerId": "doorwindow"
        },
        {
            "inFantasy": false,
            "result": -24,
            "playerName": "PARIS_to_ROME",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ad2 Kc3 7d4/9c0 Td0 Js1 8d2 Qc3/3h0 6h0 Jh0 2h1 7h4",
            "win": -60,
            "playerId": "PARIS_to_ROME"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:05:14",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338241197": [
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qd0 Qc0 Kc0/5c0 6s0 7d0 8h0 9c0/2d0 3d0 4d0 9d0 Ad0",
            "win": 250,
            "playerId": "Tgomegan"
        },
        {
            "inFantasy": false,
            "result": 36,
            "playerName": "doorwindow",
            "orderIndex": 1,
            "hero": true,
            "dead": "5d1 8s2 4s3 Jd4",
            "rows": "Ac1 Ts3 Kd4/2s0 3c0 3s0 3h2 Qs4/7h0 8c0 6h1 5h2 4c3",
            "win": -200,
            "playerId": "doorwindow"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "PARIS_to_ROME",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qh0 Kh1 Ks2/2c0 5s0 Ah1 As2 Jh4/9h0 Js0 Th3 Td3 Tc4",
            "win": -50,
            "playerId": "PARIS_to_ROME"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:07:13",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338241544": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "Tgomegan",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qs1 9d2 9h3/6h0 Td0 Jd1 Js3 5d4/8h0 Kh0 Kc0 8c2 7d4",
            "win": -110,
            "playerId": "Tgomegan"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "doorwindow",
            "orderIndex": 0,
            "hero": true,
            "dead": "4c1 3c2 2h3 2c4",
            "rows": "Qc3 Ad3 8s4/4h0 5c0 7h0 4d1 Ah4/2s0 Ts0 5s1 6s2 9s2",
            "win": -130,
            "playerId": "doorwindow"
        },
        {
            "inFantasy": true,
            "result": 36,
            "playerName": "PARIS_to_ROME",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Jh0 Jc0 Ks0/7s0 Th0 Qh0 Ac0 As0/2d0 3d0 6d0 8d0 Kd0",
            "win": 240,
            "playerId": "PARIS_to_ROME"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:09:49",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338241936": [
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ah0 As3 4c4/2s0 8c0 6h1 8d1 2h4/7d0 Qd0 4d2 Td2 2d3",
            "win": 110,
            "playerId": "Tgomegan"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "doorwindow",
            "orderIndex": 1,
            "hero": true,
            "dead": "7s1 7c2 6c3 Qc4",
            "rows": "Qh0 Kh1 Kc3/3s0 4s0 3d2 4h2 Jd4/5c0 5s0 Ts1 9d3 5h4",
            "win": -110,
            "playerId": "doorwindow"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:11:34",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338242151": [
        {
            "inFantasy": true,
            "result": 12,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Tc0 Ts0 Ac0/4d0 5s0 6s0 7s0 8c0/2h0 4h0 5h0 9h0 Kh0",
            "win": 0,
            "playerId": "Tgomegan"
        },
        {
            "inFantasy": true,
            "result": 18,
            "playerName": "doorwindow",
            "orderIndex": 0,
            "hero": true,
            "dead": "3s0 9c0",
            "rows": "2d0 2c0 2s0/Jh0 Qh0 Qd0 Qc0 Kc0/7h0 8d0 9d0 Td0 Js0",
            "win": 0,
            "playerId": "doorwindow"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:12:24",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338242261": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ac3 As3 Qs4/7d1 7s1 3h2 3d2 4h4/8d0 Th0 Td0 Tc0 Jh0",
            "win": -20,
            "playerId": "Tgomegan"
        },
        {
            "inFantasy": true,
            "result": -6,
            "playerName": "doorwindow",
            "orderIndex": 1,
            "hero": true,
            "dead": "2d0",
            "rows": "Ts0 Kh0 Kd0/8c0 8s0 9d0 Qh0 Qc0/3c0 4c0 5h0 6s0 7h0",
            "win": 20,
            "playerId": "doorwindow"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:13:14",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338242379": [
        {
            "inFantasy": true,
            "result": 72,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ah0 Ad0 As0/2h0 3c0 4d0 5s0 6s0/3h0 6h0 9h0 Th0 Kh0",
            "win": 360,
            "playerId": "Tgomegan"
        },
        {
            "inFantasy": false,
            "result": 60,
            "playerName": "doorwindow",
            "orderIndex": 0,
            "hero": true,
            "dead": "5c1 6d2 3s3 2s4",
            "rows": "Kd0 4h4 Qh4/2d0 9c0 2c1 9s1 4s3/7h0 Jh0 7d2 Ts2 7s3",
            "win": -360,
            "playerId": "doorwindow"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:14:06",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338242486": [
        {
            "inFantasy": true,
            "result": 3,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "6d0 Qc0 Ac0/9d0 Ts0 Js0 Qs0 Kc0/3h0 6h0 7h0 8h0 Jh0",
            "win": 50,
            "playerId": "Tgomegan"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "doorwindow",
            "orderIndex": 1,
            "hero": true,
            "dead": "2c1 Kd2 Jd3 Qd4",
            "rows": "Jc1 3d3 Td4/5h0 Th0 6c1 Ad2 Tc3/2s0 5s0 6s0 3s2 2d4",
            "win": -50,
            "playerId": "doorwindow"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:14:55",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338242599": [
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "Tgomegan",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "6h2 As3 6c4/8s0 9h0 3s1 3c2 3h4/7h0 7c0 Jc0 Jd1 7s3",
            "win": 90,
            "playerId": "Tgomegan"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "doorwindow",
            "orderIndex": 0,
            "hero": true,
            "dead": "9s1 7d2 5c3 Ah4",
            "rows": "Kc1 8c3 Qs4/4h0 5h0 4c1 3d2 5d3/2h0 2c0 Js0 6s2 9c4",
            "win": -350,
            "playerId": "doorwindow"
        },
        {
            "inFantasy": false,
            "result": 54,
            "playerName": "Fishontable",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kd1 Ks1 Jh3/2s0 4s0 5s3 Ad4 Ac4/8d0 Th0 Ts0 8h2 Tc2",
            "win": 260,
            "playerId": "Fishontable"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:17:14",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338242911": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Td0 Ks3 Qd4/4h0 6c0 Ah2 4c3 6s4/2s0 8s0 7s1 As1 Ts2",
            "win": -130,
            "playerId": "Tgomegan"
        },
        {
            "inFantasy": false,
            "result": 17,
            "playerName": "doorwindow",
            "orderIndex": 2,
            "hero": true,
            "dead": "4s1 9c2 Th3 8d4",
            "rows": "Qh0 Ac3 9d4/Kh0 7h1 8c1 Jh3 Jc4/3h0 3d0 5c0 2h2 2d2",
            "win": -150,
            "playerId": "doorwindow"
        },
        {
            "inFantasy": true,
            "result": 52,
            "playerName": "Fishontable",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qc0 Qs0 Kc0/3c0 3s0 8h0 9h0 9s0/5d0 7d0 Jd0 Kd0 Ad0",
            "win": 280,
            "playerId": "Fishontable"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:19:14",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338243157": [
        {
            "inFantasy": false,
            "result": 54,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "9c1 Qh3 Qc4/3h0 4c0 6c1 3c3 4d4/5d0 5c0 8d0 Tc2 Ts2",
            "win": 260,
            "playerId": "Tgomegan"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "doorwindow",
            "orderIndex": 1,
            "hero": true,
            "dead": "Js1 Ks2 7h3 Th4",
            "rows": "Ac1 Kd3 6s4/2c0 7s0 2s1 7c2 4h3/9d0 Jd0 Qd0 9h2 6h4",
            "win": -130,
            "playerId": "doorwindow"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "Fishontable",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kh0 Kc1 Jc2/3d0 8h1 Ad2 6d3 As4/5h0 5s0 7d0 Jh3 9s4",
            "win": -130,
            "playerId": "Fishontable"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:21:45",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338243504": [
        {
            "inFantasy": true,
            "result": 24,
            "playerName": "Tgomegan",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "7h0 Qh0 Qc0/9d0 Th0 Kh0 Ad0 Ac0/2s0 5s0 7s0 9s0 Ks0",
            "win": 0,
            "playerId": "Tgomegan"
        },
        {
            "inFantasy": false,
            "result": 33,
            "playerName": "doorwindow",
            "orderIndex": 0,
            "hero": true,
            "dead": "5h1 As2 2c3 7d4",
            "rows": "Kc1 Kd2 Qs4/8s0 7c1 Tc3 Ts3 8c4/4d0 6d0 8d0 Td0 2d2",
            "win": 50,
            "playerId": "doorwindow"
        },
        {
            "inFantasy": false,
            "result": 39,
            "playerName": "Fishontable",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qd2 9h4 Jd4/4c0 5c0 6h1 4h3 4s3/3h0 3c0 Js0 3d1 Jh2",
            "win": -50,
            "playerId": "Fishontable"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:23:39",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338243762": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kd1 Ks2 2s3/3s0 8d0 9c1 5c3 6d4/7d0 7c0 Tc0 Ad2 9s4",
            "win": -240,
            "playerId": "Tgomegan"
        },
        {
            "inFantasy": true,
            "result": 72,
            "playerName": "doorwindow",
            "orderIndex": 2,
            "hero": true,
            "dead": "Td0 Qd0",
            "rows": "2h0 2d0 2c0/4d0 5d0 6c0 7h0 8c0/5h0 9h0 Th0 Jh0 Kh0",
            "win": 480,
            "playerId": "doorwindow"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "Fishontable",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ac1 As2 Ah4/4s0 7s0 Jd0 4c1 Jc3/Qc0 Kc0 Qh2 5s3 9d4",
            "win": -240,
            "playerId": "Fishontable"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:25:52",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338244055": [
        {
            "inFantasy": false,
            "result": 48,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qh0 Qc1 Ks4/8c0 Ah0 Ad2 3s3 7c4/3d0 Td0 8d1 Kd2 Qd3",
            "win": 60,
            "playerId": "Tgomegan"
        },
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "doorwindow",
            "orderIndex": 1,
            "hero": true,
            "dead": "3h0",
            "rows": "8s0 Kc0 As0/2h0 2c0 6d0 6s0 9h0/4h0 4c0 Th0 Tc0 Ts0",
            "win": -70,
            "playerId": "doorwindow"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "Fishontable",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qs0 Ac2 8h4/5h0 5c1 5d2 Kh3 6c4/4s0 Jh0 Jc0 4d1 Jd3",
            "win": 10,
            "playerId": "Fishontable"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:28:08",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338244311": [
        {
            "inFantasy": true,
            "result": 39,
            "playerName": "Tgomegan",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kd0 Ad0 As0/4h0 5s0 6c0 7h0 8h0/3s0 4s0 9s0 Ts0 Ks0",
            "win": 250,
            "playerId": "Tgomegan"
        },
        {
            "inFantasy": false,
            "result": -24,
            "playerName": "doorwindow",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qh1 Ah2 Td3 5c4",
            "rows": "Kh1 Js3 Kc3/2h0 3d0 6h2 6s2 2s4/4d0 4c0 7s0 7d1 Th4",
            "win": -160,
            "playerId": "doorwindow"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "Fishontable",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "8d3 Tc4 Ac4/2d0 Jc0 3h2 Jd2 Jh3/9h0 Qd0 Qc0 9d1 Qs1",
            "win": -90,
            "playerId": "Fishontable"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:30:05",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338244640": [
        {
            "inFantasy": false,
            "result": -24,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ac3 As3 Qs4/5c1 5s1 2h2 2s2 8c4/7h0 7d0 7s0 9c0 Tc0",
            "win": -100,
            "playerId": "Tgomegan"
        },
        {
            "inFantasy": true,
            "result": -30,
            "playerName": "doorwindow",
            "orderIndex": 1,
            "hero": true,
            "dead": "2d0 3d0",
            "rows": "5d0 7c0 Js0/4h0 4s0 8h0 8d0 8s0/Th0 Ts0 Kh0 Kd0 Kc0",
            "win": 100,
            "playerId": "doorwindow"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:31:18",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338244834": [
        {
            "inFantasy": true,
            "result": 57,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Td0 Tc0 Ts0/3c0 4d0 5s0 6d0 7c0/3s0 6s0 8s0 9s0 As0",
            "win": 230,
            "playerId": "Tgomegan"
        },
        {
            "inFantasy": false,
            "result": 51,
            "playerName": "doorwindow",
            "orderIndex": 1,
            "hero": true,
            "dead": "9h1 4h2 5h3",
            "rows": "Kh0 2s3 Ah3/4c0 6h1 Kc1 5c2 Ks2/2d0 5d0 Kd0",
            "win": -230,
            "playerId": "doorwindow"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:32:49",
    "roomId": "41b-1d8a01d1"
}


{
    "stakes": 10,
    "handData": {"338245210": [
        {
            "inFantasy": true,
            "result": 24,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Jh0 Js0 Ac0/4s0 5h0 6d0 7h0 8c0/3d0 7d0 Qd0 Kd0 Ad0",
            "win": 200,
            "playerId": "Tgomegan"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "doorwindow",
            "orderIndex": 0,
            "hero": true,
            "dead": "7s1 Jd2 9h3",
            "rows": "Kc0 5c3 6h3/5d0 Jc0 8d2 9d2/2s0 Qs0 Tc1 Kh1",
            "win": -200,
            "playerId": "doorwindow"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:42:57",
    "roomId": "41b-1d8a01d1"
}


