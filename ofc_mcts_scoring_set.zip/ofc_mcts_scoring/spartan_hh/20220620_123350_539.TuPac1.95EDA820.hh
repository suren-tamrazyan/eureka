{
    "stakes": 10,
    "handData": {"338224292": [
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "PARIS_to_ROME",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ah0 Qd1 Ac4/6s0 7d0 6h2 7h2 Jc3/9s0 Th0 Ts1 9c3 Td4",
            "win": 70,
            "playerId": "PARIS_to_ROME"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "Js1 6c2 7s3 9d4",
            "rows": "Ks0 Kd4 As4/2h0 5d0 8s1 5h2 2s3/4c0 Qc0 4d1 4s2 Qh3",
            "win": -70,
            "playerId": "TuPac1"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:33:50",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338224632": [
        {
            "inFantasy": true,
            "result": 12,
            "playerName": "PARIS_to_ROME",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Th0 Kh0 Kd0/2h0 2c0 2s0 6h0 6c0/8d0 8s0 Qh0 Qd0 Qc0",
            "win": 140,
            "playerId": "PARIS_to_ROME"
        },
        {
            "inFantasy": true,
            "result": 0,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "3c0 4c0",
            "rows": "Jh0 Jc0 Kc0/2d0 5d0 6d0 7d0 Ad0/4s0 7s0 Ts0 Qs0 As0",
            "win": -140,
            "playerId": "TuPac1"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:34:41",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338224795": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "PARIS_to_ROME",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qh0 Kh1 Js4/2c0 9c0 5c2 2d3 3h4/3d0 Td0 Tc1 3c2 3s3",
            "win": 120,
            "playerId": "PARIS_to_ROME"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "7h1 Ts2 2h3 As4",
            "rows": "Ac1 8h3 Ad3/9h0 9s1 8c2 9d2 Kd4/6h0 6d0 Jh0 Jd0 8s4",
            "win": -120,
            "playerId": "TuPac1"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:36:33",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338225158": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "PARIS_to_ROME",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kd0 Ks0 Kh4/Ac1 As1 4d2 7h3 Tc3/5s0 6s0 Qs0 6h2 Td4",
            "win": -300,
            "playerId": "PARIS_to_ROME"
        },
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "TuPac1",
            "orderIndex": 2,
            "hero": true,
            "dead": "4h1 4s2 9h3 9s4",
            "rows": "Qd0 Ad1 8h4/2d0 6c0 2s2 6d3 7c4/Jh0 Jd0 Js1 5h2 Jc3",
            "win": 170,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "MUKSNOLE",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "7d2 9d3 9c4/3h0 3s0 8d1 8s1 Th3/2c0 8c0 Qc0 5c2 3c4",
            "win": 130,
            "playerId": "MUKSNOLE"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:38:49",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338225613": [
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "PARIS_to_ROME",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qd0 Ah1 Jc4/5h0 6s0 8s1 8d2 As4/Jh0 Js0 3c2 7h3 7s3",
            "win": -190,
            "playerId": "PARIS_to_ROME"
        },
        {
            "inFantasy": false,
            "result": 54,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "6h1 4h2 7d3 5s4",
            "rows": "Qh1 Ad3 Qs4/2d0 Jd0 2c1 9d2 9s2/Kd0 Kc0 Ks0 4d3 9c4",
            "win": 260,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "MUKSNOLE",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ac0 Kh2 Tc4/2h0 5d0 7c0 2s1 5c3/Ts0 4c1 Th2 Qc3 Td4",
            "win": -70,
            "playerId": "MUKSNOLE"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:41:09",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338226047": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "PARIS_to_ROME",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ks0 Qd2 Jd4/4h0 6c0 5c3 7h3 5s4/2h0 2d0 9h1 9d1 2c2",
            "win": -210,
            "playerId": "PARIS_to_ROME"
        },
        {
            "inFantasy": true,
            "result": 60,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "4s0",
            "rows": "Qs0 Kd0 Kc0/8c0 9s0 Th0 Jc0 Qc0/6h0 6d0 Ad0 Ac0 As0",
            "win": 340,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "MUKSNOLE",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kh0 6s3 9c3/4c0 7d0 8s1 8h2 8d4/3h0 3c0 Js1 Jh2 3d4",
            "win": -130,
            "playerId": "MUKSNOLE"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:42:58",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338226397": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "PARIS_to_ROME",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ac0 Ah2 Kc3/3h1 6h1 3c3 2d4 Tc4/5s0 6c0 7h0 8h0 4s2",
            "win": -80,
            "playerId": "PARIS_to_ROME"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "TuPac1",
            "orderIndex": 2,
            "hero": true,
            "dead": "Jc1 6d2 Js3 7c4",
            "rows": "Jd2 Qc3 As4/4d0 2h1 2c1 9d2 Kh4/8s0 9h0 Th0 Jh0 7d3",
            "win": 160,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "MUKSNOLE",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kd1 Ks1 8d3/2s0 5d0 5h2 Qh2 Qs3/4c0 8c0 9c0 4h4 6s4",
            "win": -80,
            "playerId": "MUKSNOLE"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:44:54",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338226755": [
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "PARIS_to_ROME",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qh1 As3 3h4/2s0 5h0 5d0 2c1 3d2/8c0 Tc0 7s2 9h3 6h4",
            "win": 90,
            "playerId": "PARIS_to_ROME"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qc1 Js2 5s3 7h4",
            "rows": "Ah0 Ts2 8d4/3s0 4s0 6c0 3c3 Td4/Th0 7c1 8h1 Jc2 9c3",
            "win": 70,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "MUKSNOLE",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ks0 Kd1 8s3/2h0 4h0 6d0 4c2 Qd4/9s0 Jh1 9d2 Ac3 Ad4",
            "win": -160,
            "playerId": "MUKSNOLE"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:47:29",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338227241": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "PARIS_to_ROME",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ac1 4h2 4c4/3h0 5d0 5s0 7s0 7d1/Jc0 9d2 Ts3 Kh3 Qd4",
            "win": -40,
            "playerId": "PARIS_to_ROME"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "Js1 4d2 4s3 Jd4",
            "rows": "Kd0 Ks0 8d3/Ah0 2c1 2d2 Td3 6s4/5h0 7h0 6h1 Qh2 2h4",
            "win": -270,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 51,
            "playerName": "MUKSNOLE",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qc0 Qs1 Jh3/3s0 5c0 Kc2 Ad4 As4/8h0 Th0 8c1 8s2 Tc3",
            "win": 310,
            "playerId": "MUKSNOLE"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:49:41",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338227640": [
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "PARIS_to_ROME",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Tc2 Qc4 Ac4/3c0 5c0 5s0 4s2 4c3/8h0 8d0 6h1 6d1 6c3",
            "win": -130,
            "playerId": "PARIS_to_ROME"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "TuPac1",
            "orderIndex": 2,
            "hero": true,
            "dead": "7s1 Jc2 3s3 7h4",
            "rows": "Ah1 9d4 As4/8c0 9h0 9c0 Qh2 8s3/2d0 Td0 Jd1 5d2 Kd3",
            "win": 80,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": true,
            "result": -33,
            "playerName": "MUKSNOLE",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "4d0 7c0 Kc0/3h0 4h0 5h0 Th0 Kh0/6s0 9s0 Ts0 Qs0 Ks0",
            "win": 50,
            "playerId": "MUKSNOLE"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:51:54",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338228052": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "PARIS_to_ROME",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ah2 Ac2 Js4/3s0 6c0 3h1 3d1 2s3/8h0 9d0 Th0 Qs3 Jc4",
            "win": -150,
            "playerId": "PARIS_to_ROME"
        },
        {
            "inFantasy": true,
            "result": 39,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "3c0 4h0 5d0",
            "rows": "Qc0 Ad0 As0/9h0 9c0 Kd0 Kc0 Ks0/6s0 7h0 7d0 7c0 7s0",
            "win": 610,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 42,
            "playerName": "MUKSNOLE",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Jh2 4s4 Td4/2h0 2c0 5h1 4c2 5c3/8c0 8s0 Tc0 Ts1 9s3",
            "win": -460,
            "playerId": "MUKSNOLE"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:53:55",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338228445": [
        {
            "inFantasy": true,
            "result": 15,
            "playerName": "PARIS_to_ROME",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Jc0 Kh0 Kd0/9h0 9d0 9s0 Qd0 Qc0/6s0 Th0 Td0 Tc0 Ts0",
            "win": 440,
            "playerId": "PARIS_to_ROME"
        },
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "2c0",
            "rows": "3h0 3c0 3s0/4h0 Qh0 Ah0 Ad0 As0/4s0 5s0 6c0 7d0 8d0",
            "win": -40,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 51,
            "playerName": "MUKSNOLE",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qs3 Ac3 Js4/Kc1 Ks1 5c2 6d2 2d4/2h0 5h0 6h0 8h0 Jh0",
            "win": -400,
            "playerId": "MUKSNOLE"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:55:03",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338228656": [
        {
            "inFantasy": true,
            "result": 15,
            "playerName": "PARIS_to_ROME",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "5c0 Ah0 Ac0/3d0 4c0 5d0 6h0 7s0/8c0 9s0 Th0 Jh0 Qs0",
            "win": 130,
            "playerId": "PARIS_to_ROME"
        },
        {
            "inFantasy": true,
            "result": 3,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "2h0",
            "rows": "Jc0 Js0 Ad0/5h0 6d0 7h0 Kh0 Kc0/6c0 7c0 8d0 9d0 Ts0",
            "win": -130,
            "playerId": "TuPac1"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:55:44",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338228784": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "PARIS_to_ROME",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Kh2 Qc3/5c0 2c1 Tc1 5d2 Th4/7s0 9s0 Js0 3s3 7c4",
            "win": 0,
            "playerId": "PARIS_to_ROME"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h1 9d2 Td3 8d4",
            "rows": "7h1 Ah3 4h4/4d0 9c0 Jc1 9h2 4c3/Ts0 Qs0 Ks0 4s2 2d4",
            "win": 0,
            "playerId": "TuPac1"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:57:23",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338229084": [
        {
            "inFantasy": false,
            "result": -27,
            "playerName": "PARIS_to_ROME",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "8c2 9s4 Ac4/4s0 5c0 6s1 3c2 2s3/3d0 7d0 Jd0 Td1 4d3",
            "win": 10,
            "playerId": "PARIS_to_ROME"
        },
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "8s1 Qs2 Tc3 9c4",
            "rows": "Ks0 Kd2 Qd3/Ad0 As0 9d1 Ts1 Js3/3s0 5d0 6h2 3h4 6d4",
            "win": -10,
            "playerId": "TuPac1"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:58:46",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338229345": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "PARIS_to_ROME",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ah3 Ac3 Kc4/3d1 3s1 2d2 2c2 6s4/2s0 5d0 5s0 9h0 Th0",
            "win": -200,
            "playerId": "PARIS_to_ROME"
        },
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "4d0 6h0",
            "rows": "Jd0 Qd0 Ks0/3c0 4c0 6c0 7c0 Jc0/8h0 8c0 9d0 9c0 9s0",
            "win": 200,
            "playerId": "TuPac1"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:59:38",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338229528": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qc1 9c2 7h3 2d4",
            "rows": "Ks0 8c2 9s4/Th0 Ac0 Jh2 Tc3 2h4/3d0 Qd0 8d1 9d1 5d3",
            "win": 10,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ah0 Kc1 Td4/4s0 2c2 9h2 4c3 4d4/6d0 6c0 Qh0 6s1 Jd3",
            "win": -10,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:01:20",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338229881": [
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jh1 6d2 3s3 6c4",
            "rows": "Kh0 Kd1 Td4/Ac0 2d2 3c2 5h3 4c4/6s0 8s0 9s0 5s1 Ts3",
            "win": 220,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ks0 Kc1 Qc3/2c0 7c0 4s1 2h2 8h4/5d0 9d0 Ad2 As3 9h4",
            "win": -220,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:03:09",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338230260": [
        {
            "inFantasy": true,
            "result": 57,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "3h0 Tc0",
            "rows": "9d0 9c0 9s0/Td0 Jd0 Qc0 Kh0 Ah0/2s0 4s0 6s0 7s0 Ks0",
            "win": 250,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 45,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Jh3 Qh3 8h4/3d1 3c1 3s2 5s2 2d4/2c0 4c0 5c0 6c0 8c0",
            "win": -250,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:03:52",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338230398": [
        {
            "inFantasy": true,
            "result": 12,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "2s0",
            "rows": "Qc0 Kd0 Ad0/6s0 7h0 7c0 8d0 Jh0/4h0 4d0 5h0 5d0 5s0",
            "win": -30,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ah3 Ac3 As4/9c1 Tc1 6c2 8c2 5c4/7s0 8s0 9s0 Qs0 Ks0",
            "win": 30,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:04:39",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338230539": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "3c1 2d2 6h3 6s4",
            "rows": "Ad1 As3 Qh4/Jc0 Qc1 Jh2 Qd2 9c4/6c0 7h0 8h0 9s0 5h3",
            "win": -60,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": true,
            "result": -6,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kd0 Kc0 Ah0/2c0 3h0 4c0 5d0 Ac0/2s0 5s0 7s0 Js0 Qs0",
            "win": 60,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:05:23",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338230700": [
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "4c0 7s0 9c0",
            "rows": "Th0 Td0 Tc0/5s0 6h0 7c0 8d0 9h0/Ts0 Jd0 Qd0 Kh0 As0",
            "win": 120,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ad3 Ac3 2s4/Kc1 Ks1 Qh2 Qc2 8s4/3h0 3d0 3c0 4d0 Ah0",
            "win": -120,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:06:08",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338230824": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "kaysons",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "9s2 8c3 Jc4/2d0 3c0 3s0 2c1 6h3/Th0 Td0 Tc1 4s2 5d4",
            "win": -20,
            "playerId": "kaysons"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "TuPac1",
            "orderIndex": 2,
            "hero": true,
            "dead": "Qh1 Ah2 9h3 9d4",
            "rows": "Kd0 Kh1 8s3/3d0 4h2 7c2 Ac3 4c4/7s0 9c0 Ts0 8h1 4d4",
            "win": -190,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 51,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ks0 Qs1 Qd3/3h0 As0 Ad1 2h2 Qc4/7d0 Jd0 Js2 5h3 Jh4",
            "win": 210,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:08:18",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338231236": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "kaysons",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Jd2 Ah3 Qc4/3h0 4c0 5h1 5c2 4h3/8d0 8s0 Tc0 6h1 8h4",
            "win": -210,
            "playerId": "kaysons"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "Ad1 3d2 4d3 6c4",
            "rows": "Jc2 7s3 7c4/Th0 Jh0 Qd1 Kh1 Ac4/3s0 Ts0 Qs0 6s2 2s3",
            "win": 210,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": true,
            "result": 0,
            "playerName": "Tgomegan",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "4s0 5s0 6d0/8c0 Td0 Qh0 Kc0 As0/2h0 2d0 2c0 9h0 9s0",
            "win": 0,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:10:21",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338231618": [
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "kaysons",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ah0 Ad1 7s4/3c0 8h0 7c1 7d2 3s3/2c0 2s0 Jd2 2h3 6d4",
            "win": 20,
            "playerId": "kaysons"
        },
        {
            "inFantasy": false,
            "result": 45,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "5s1 8c2 6s3 6c4",
            "rows": "Qc1 Kd2 Js4/9d0 Td0 2d1 As2 Qs4/6h0 9h0 Qh0 7h3 Kh3",
            "win": -150,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Jc4 Ks4/8s0 9c0 4c2 9s2 4d3/3h0 5h0 4h1 Jh1 Th3",
            "win": 130,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:13:03",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338232080": [
        {
            "inFantasy": true,
            "result": 42,
            "playerName": "kaysons",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Ac0 As0/2d0 3d0 8d0 Td0 Jd0/6d0 6c0 7d0 7c0 7s0",
            "win": 400,
            "playerId": "kaysons"
        },
        {
            "inFantasy": false,
            "result": 39,
            "playerName": "TuPac1",
            "orderIndex": 2,
            "hero": true,
            "dead": "Qc1 2h2 6h3 9s4",
            "rows": "Ah0 Ks2 Kh3/3h0 5h1 5c1 3s2 5s4/9d0 Tc0 Jh0 8s3 4d4",
            "win": -350,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": true,
            "result": 27,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qd0 Qs0 Ad0/8h0 Th0 Ts0 Jc0 Js0/4s0 5d0 6s0 7h0 8c0",
            "win": -50,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:14:54",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338232388": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "kaysons",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ah0 As1 Kc4/3s0 5d0 3c1 6d2 Qd4/7d0 7s0 Qh2 8h3 8s3",
            "win": -220,
            "playerId": "kaysons"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "9s1 2c2 3d3 Tc4",
            "rows": "Kd0 8c4 Qc4/2d0 2s0 2h1 5h2 Ac3/3h0 7h0 5s1 6s2 4d3",
            "win": 70,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "Tgomegan",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ad2 Qs3 4c4/5c0 9c0 9h1 Td2 Ts3/Jh0 Jd0 Js0 4s1 4h4",
            "win": 150,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:17:26",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338232835": [
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "kaysons",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kh2 6c3 8h4/4d0 4c0 7s0 9h2 2d3/Td0 Jd0 Tc1 Jh1 Ks4",
            "win": -90,
            "playerId": "kaysons"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "2s1 Jc2 4h3 7h4",
            "rows": "Kd0 Ad2 5d3/2c0 2h1 9c2 7c3 8c4/4s0 Qs0 As0 3s1 Qc4",
            "win": -110,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qh0 Ah0 Kc4/3c0 5s0 3h1 5c1 9s4/7d0 6d2 8d2 9d3 Qd3",
            "win": 200,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:20:05",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338233342": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "kaysons",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kd1 Ks3 Ad4/6s0 Td0 9d1 8c2 7c3/3h0 5h0 Jh0 Qh2 Ac4",
            "win": -280,
            "playerId": "kaysons"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "TuPac1",
            "orderIndex": 2,
            "hero": true,
            "dead": "8h1 9c2 2h3 Jd4",
            "rows": "Kc2 4c3 Ah4/2s0 4s0 Js0 8s3 9s4/2d0 Qd0 3d1 5d1 4d2",
            "win": 250,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "As0 Kh2 7d4/6d1 Th1 6h3 7h3 Ts4/2c0 5c0 6c0 Tc0 Qc2",
            "win": 30,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:22:41",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338233826": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jd1 3h2 Td3 3c4",
            "rows": "Ad0 Qh3 Jh4/6c0 6s1 4c2 9h2 6h4/2s0 8s0 9s0 Ts1 7s3",
            "win": 50,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "As2 Qc3 Kh4/2h0 2c0 4s0 Th2 2d4/3d0 5d0 5c1 5s1 8d3",
            "win": -50,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:24:25",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338234138": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "3h1 9h2 4c3 Kd4",
            "rows": "Kh0 Ac0 Kc1/Js0 Tc1 8d2 7h3 9d3/Qh0 Qd0 6c2 7d4 Ts4",
            "win": -100,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qc1 Jd3 7s4/Ah0 Ad0 9c2 5d3 8s4/2s0 4s0 5s0 6s1 9s2",
            "win": 100,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:26:25",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338234504": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "4c1 Ks2 2s3 8c4",
            "rows": "8d1 Ah2 8h4/7c0 9h0 6c1 6h3 9s4/5s0 Jh0 Js0 Qc2 Qs3",
            "win": 90,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kd0 7d3 7s3/3s0 Tc0 4s2 Ts2 3c4/4h0 7h0 5h1 Kh1 3d4",
            "win": -90,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:28:22",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338234857": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "3h1 7s2 Jc3 3c4",
            "rows": "Qc1 Kd3 9s4/8h1 4s2 5d2 8c3 4h4/6c0 7h0 7c0 Td0 Tc0",
            "win": -30,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "8s1 Kh2 Qh3/2s0 9h0 2c2 4c3 5s4/3d0 4d0 Jd0 2d1 7d4",
            "win": 30,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:33:06",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338235823": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "5s1 9s2 Js3 Ad4",
            "rows": "Kc1 Kh2 Jc3/2h0 2d0 7d1 9d2 Qd4/5d0 6c0 7c0 3h3 6s4",
            "win": -150,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 33,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ah0 As1 6h4/5c0 8s0 8d1 3s2 3c3/Qh0 Qs0 Qc2 Tc3 Jh4",
            "win": 150,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:34:54",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338236146": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "5c1 5d2 Ac3 7d4",
            "rows": "Ad0 As1 Kh3/2s0 4h0 4s0 6s2 2d4/9c0 8s1 Th2 8h3 2h4",
            "win": -200,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": true,
            "result": 24,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Td0 Jh0 Jd0/5s0 6d0 7c0 8c0 9d0/3h0 5h0 6h0 9h0 Qh0",
            "win": 200,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:35:52",
    "roomId": "41b-1d7888fa"
}


{
    "stakes": 10,
    "handData": {"338236311": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "2s1 Qc2 4s3 3h4",
            "rows": "As0 Ah2 5d4/3c0 5c0 5h1 3s3 8h4/6d0 8d0 2d1 4d2 Jd3",
            "win": 40,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ac0 Kh2 Kd3/6h0 7d0 6c1 6s1 Qh4/9s0 Tc0 Td2 Th3 7c4",
            "win": -40,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:37:30",
    "roomId": "41b-1d7888fa"
}





