{
    "stakes": 5,
    "handData": {"338271023": [
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "Pro1995",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Ac2 Th3/4s0 5s0 Js3 3d4 7h4/7d0 Td0 4d1 Jd1 Qd2",
            "win": -70,
            "playerId": "Pro1995"
        },
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "6h1 7c2 8s3 Qc4",
            "rows": "Kd0 Ks1 Qh4/As0 3c1 Ah2 Qs3 5c4/9d0 Ts0 Jc0 Tc2 9s3",
            "win": 70,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:11:36",
    "roomId": "41b-1db88c20"
}


{
    "stakes": 5,
    "handData": {"338271251": [
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "Pro1995",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "6c3 Kd3 5s4/9d1 9c1 7s2 Jd2 2s4/2d0 3d0 3c0 3s0 8h0",
            "win": -120,
            "playerId": "Pro1995"
        },
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "6d0 8s0",
            "rows": "Ts0 Kc0 Ks0/Th0 Jc0 Qd0 Kh0 As0/5h0 5c0 7h0 7d0 7c0",
            "win": 120,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:12:24",
    "roomId": "41b-1db88c20"
}


{
    "stakes": 5,
    "handData": {"338271363": [
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "Pro1995",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qc0 Qd1 9s4/2c0 3h0 3c1 Kh3 Kd3/7s0 8d0 6d2 9d2 5d4",
            "win": 75,
            "playerId": "Pro1995"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "6c1 5h2 8c3 Ah4",
            "rows": "Ad1 Ac2 Qh3/7d0 Td0 4d1 4c2 7c3/3s0 4s0 5s0 8s4 Tc4",
            "win": -75,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:13:55",
    "roomId": "41b-1db88c20"
}


{
    "stakes": 5,
    "handData": {"338271593": [
        {
            "inFantasy": true,
            "result": -3,
            "playerName": "Pro1995",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "9s0 Tc0 Jh0/3s0 4s0 5c0 6c0 7s0/2h0 2c0 8h0 8d0 8c0",
            "win": 35,
            "playerId": "Pro1995"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "9c1 6d2 Kd3 5h4",
            "rows": "Qc2 Ac3 Ks4/9d0 Js0 Jc1 Ts3 Qd4/3h0 4h0 7h0 Ah1 Kh2",
            "win": -35,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:14:46",
    "roomId": "41b-1db88c20"
}


{
    "stakes": 5,
    "handData": {"338271718": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "Pro1995",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ts3 3h4 4s4/2s0 8c1 9s1 9c2 8h3/5c0 5s0 7c0 7s0 7h2",
            "win": -5,
            "playerId": "Pro1995"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "2c1 Tc2 5d3 Kh4",
            "rows": "Ks0 Kc2 Th3/4h0 8s0 Jc1 As2 Ad4/3d0 Qd0 Qh1 6s3 6h4",
            "win": 5,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:16:09",
    "roomId": "41b-1db88c20"
}


{
    "stakes": 5,
    "handData": {"338271920": [
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "Pro1995",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ah3 Ac3 2c4/8h1 8s1 7h2 7s2 Td4/4s0 9d0 9c0 9s0 Jd0",
            "win": 10,
            "playerId": "Pro1995"
        },
        {
            "inFantasy": true,
            "result": 24,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "2d0 8c0",
            "rows": "Th0 Kc0 As0/5d0 5c0 9h0 Qh0 Qs0/4h0 4d0 6d0 6c0 6s0",
            "win": -10,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:17:03",
    "roomId": "41b-1db88c20"
}


{
    "stakes": 5,
    "handData": {"338272055": [
        {
            "inFantasy": true,
            "result": -9,
            "playerName": "Pro1995",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Tc0 Qh0 Qc0/5h0 7h0 8h0 Jh0 Kh0/8s0 9s0 Ts0 Qs0 As0",
            "win": 25,
            "playerId": "Pro1995"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "4c1 7c2 5c3 9c4",
            "rows": "Ac1 Js3 Ad4/2c0 6s0 3d2 2h3 2s4/4d0 5d0 8d0 9d1 Qd2",
            "win": -25,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:18:53",
    "roomId": "41b-1db88c20"
}


{
    "stakes": 5,
    "handData": {"338272314": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "Pro1995",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kd3 Ah3 Qs4/9c1 9s1 6d2 Td2 5c4/2s0 4h0 4c0 Th0 Tc0",
            "win": -140,
            "playerId": "Pro1995"
        },
        {
            "inFantasy": true,
            "result": 36,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "4d0 9d0 Kh0",
            "rows": "2h0 2d0 2c0/3s0 4s0 5s0 8s0 Ks0/3c0 7c0 Jc0 Kc0 Ac0",
            "win": 140,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:19:27",
    "roomId": "41b-1db88c20"
}


{
    "stakes": 5,
    "handData": {"338272399": [
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "Pro1995",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kh3 Kc3 7d4/5h1 5s1 3c2 3s2 Qc4/7s0 8h0 9c0 Th0 As0",
            "win": -110,
            "playerId": "Pro1995"
        },
        {
            "inFantasy": true,
            "result": 42,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h0",
            "rows": "4d0 4c0 4s0/5c0 6h0 6d0 6s0 Ah0/8d0 9s0 Ts0 Jc0 Qd0",
            "win": 110,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:19:58",
    "roomId": "41b-1db88c20"
}


{
    "stakes": 5,
    "handData": {"338272472": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "Pro1995",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kh3 Ks3 5d4/6c1 6s1 2d2 2c2 8c4/7s0 9c0 Jc0 Qh0 Qd0",
            "win": -30,
            "playerId": "Pro1995"
        },
        {
            "inFantasy": true,
            "result": 3,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "5c0",
            "rows": "9s0 Ts0 Ad0/4h0 4d0 4c0 Jh0 Jd0/8h0 8d0 8s0 Qc0 Qs0",
            "win": 30,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:20:32",
    "roomId": "41b-1db88c20"
}


{
    "stakes": 5,
    "handData": {"338272559": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "Pro1995",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "5c0 As0 Qs4/2c0 2d1 7d2 4d3 Ad4/Qh0 Qc0 8c1 8s2 Kc3",
            "win": -40,
            "playerId": "Pro1995"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "6h1 8h2 2h3 7s4",
            "rows": "3c1 3h2 Ks2/4c0 9h0 Ts1 7h3 7c4/5d0 6d0 Jd0 9d3 4h4",
            "win": -100,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "Parthhxx",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kh0 Td3 Ah4/5h0 3s1 4s2 6s2 2s3/6c0 9c0 Ac0 Tc1 Jc4",
            "win": 140,
            "playerId": "Parthhxx"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:24:31",
    "roomId": "41b-1db88c20"
}


{
    "stakes": 5,
    "handData": {"338273110": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "Pro1995",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ah0 As0 Kh3/Ts0 Jh1 Js1 5s2 Jd4/3c0 Qc0 2c2 3s3 9s4",
            "win": 0,
            "playerId": "Pro1995"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "7c1 2s2 Kd3 Tc4",
            "rows": "Kc0 Ks2 Jc3/Th0 Ac0 4h2 6c4 6s4/9h0 9d0 Qh1 Qs1 5d3",
            "win": 0,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:26:13",
    "roomId": "41b-1db88c20"
}


{
    "stakes": 5,
    "handData": {"338273390": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "Pro1995",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Kd2 2d3/Td0 Jc0 Jd1 7s3 7d4/3s0 4s0 As1 3c2 4h4",
            "win": -85,
            "playerId": "Pro1995"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "8s1 5c2 4c3 8d4",
            "rows": "Qs0 Qd1 Ah4/6d0 6h1 2s2 9s3 9c4/2h0 Th0 Kh0 5h2 7h3",
            "win": 85,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:27:54",
    "roomId": "41b-1db88c20"
}


{
    "stakes": 5,
    "handData": {"338273636": [
        {
            "inFantasy": false,
            "result": 39,
            "playerName": "Pro1995",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qh3 Kh3 Ts4/7d1 8s1 9d2 Td2 Jd4/3c0 4c0 5c0 7c0 Jc0",
            "win": -75,
            "playerId": "Pro1995"
        },
        {
            "inFantasy": true,
            "result": 45,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "9h0",
            "rows": "6h0 6d0 6c0/Js0 Qd0 Qc0 Qs0 Kc0/2h0 2d0 2s0 Ah0 Ac0",
            "win": 75,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:28:42",
    "roomId": "41b-1db88c20"
}


{
    "stakes": 5,
    "handData": {"338273748": [
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "Pro1995",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "2h3 2c3 Qc4/Kh1 Kc1 4c2 Ks2 2d4/5h0 5c0 7h0 7c0 7s0",
            "win": -10,
            "playerId": "Pro1995"
        },
        {
            "inFantasy": true,
            "result": 24,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "3d0",
            "rows": "Jh0 Qh0 Qd0/4d0 7d0 8h0 Ah0 Ac0/2s0 4s0 6s0 Ts0 Qs0",
            "win": 10,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:29:35",
    "roomId": "41b-1db88c20"
}


{
    "stakes": 5,
    "handData": {"338273879": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Pro1995",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Jc3 Ks4/3s0 7h0 Ac1 As1 Ts2/4d0 8d0 4c2 2d3 4s4",
            "win": 0,
            "playerId": "Pro1995"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "6c1 Ah2 8s3 7d4",
            "rows": "Qd0 Qh3 9s4/Th0 Jd1 Kh2 Kd3 5h4/5s0 6s0 7s0 4h1 8h2",
            "win": 0,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:30:58",
    "roomId": "41b-1db88c20"
}


{
    "stakes": 5,
    "handData": {"338274053": [
        {
            "inFantasy": true,
            "result": 24,
            "playerName": "Pro1995",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Jh0 Jd0 Qs0/6h0 8h0 9h0 Th0 Kh0/3h0 3c0 Ah0 Ac0 As0",
            "win": 70,
            "playerId": "Pro1995"
        },
        {
            "inFantasy": true,
            "result": 12,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "2c0",
            "rows": "4h0 5h0 8c0/2d0 5d0 6d0 8d0 Qd0/4s0 7s0 9s0 Ts0 Ks0",
            "win": -70,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:31:57",
    "roomId": "41b-1db88c20"
}


{
    "stakes": 5,
    "handData": {"338274193": [
        {
            "inFantasy": false,
            "result": 33,
            "playerName": "Pro1995",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ac0 As0 Qs4/5s0 6d0 6s2 Qd2 Qc3/9c0 Th1 Ks1 Kc3 Kh4",
            "win": 75,
            "playerId": "Pro1995"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qh1 Ah2 Ad3 8c4",
            "rows": "Kd0 9h3 7h4/4d0 Jh1 Jd1 4h2 3d3/7s0 8h0 9s0 Tc2 4c4",
            "win": -75,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:33:30",
    "roomId": "41b-1db88c20"
}


{
    "stakes": 5,
    "handData": {"338274401": [
        {
            "inFantasy": true,
            "result": 24,
            "playerName": "Pro1995",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Th0 Qd0 Qc0/5s0 6s0 8s0 Ks0 As0/2c0 6c0 9c0 Kc0 Ac0",
            "win": 80,
            "playerId": "Pro1995"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "Js1 7c2 Qs3 7s4",
            "rows": "7h2 Kh2 Tc3/2h0 3c0 4s0 Ts4 Ah4/7d0 9d0 Kd1 Ad1 8d3",
            "win": -80,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:34:16",
    "roomId": "41b-1db88c20"
}


{
    "stakes": 5,
    "handData": {"338274501": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "Pro1995",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kd0 Ad2 9h4/6c0 7d0 8d1 7c2 5c4/3h0 8h0 Th1 7h3 Ah3",
            "win": 5,
            "playerId": "Pro1995"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "Ts1 2d2 3s3 3c4",
            "rows": "Qh1 As2 2h4/4s0 Jh0 4d2 3d3 Js4/8c0 Tc0 Qc0 Kc1 Jc3",
            "win": -5,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:35:38",
    "roomId": "41b-1db88c20"
}


{
    "stakes": 5,
    "handData": {"338274683": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "Pro1995",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc0 7s3 9h4/3h0 8s0 8h1 8c1 6c2/5d0 6d0 2d2 8d3 5h4",
            "win": 0,
            "playerId": "Pro1995"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "5s1 6h2 6s3 9d4",
            "rows": "Qh1 Ac2 As3/7d0 Ts0 Jh1 Tc3 3s4/3c0 Kd0 Ks0 4d2 3d4",
            "win": 0,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:37:16",
    "roomId": "41b-1db88c20"
}


{
    "stakes": 5,
    "handData": {"338274897": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "Pro1995",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Js2 Jc4/5c0 Td0 3c1 2h3 Qc4/Qh0 Ah0 Qs1 As2 Ac3",
            "win": 0,
            "playerId": "Pro1995"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "Th1 5s2 Jd3 Qd4",
            "rows": "Ks0 Kd1 9s4/4d0 6c0 2c2 4c3 7d4/8d0 Jh0 8c1 9c2 8h3",
            "win": 0,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:38:43",
    "roomId": "41b-1db88c20"
}


{
    "stakes": 5,
    "handData": {"338275077": [
        {
            "inFantasy": false,
            "result": 33,
            "playerName": "Pro1995",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "8s0 Ah1 As1/9h0 Qh0 Kh2 9c3 9s3/Jd0 Kd0 Td2 2d4 9d4",
            "win": 105,
            "playerId": "Pro1995"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "7c1 7h2 6c3 Jc4",
            "rows": "Qs0 Qd1 6d3/8c0 Kc0 Ks0 6h3 5c4/4d0 2h1 5d2 Ad2 4h4",
            "win": -105,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:40:09",
    "roomId": "41b-1db88c20"
}


{
    "stakes": 5,
    "handData": {"338275273": [
        {
            "inFantasy": true,
            "result": 48,
            "playerName": "Pro1995",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "7h0 7d0 7c0/2s0 7s0 Js0 Qs0 As0/4d0 4c0 4s0 Th0 Td0",
            "win": 145,
            "playerId": "Pro1995"
        },
        {
            "inFantasy": false,
            "result": 42,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qd1 6d2 6s3 9s4",
            "rows": "Ad0 9d3 9h4/3h0 3s0 5d0 3c1 6h2/Jc0 9c1 Tc2 Qc3 2h4",
            "win": -145,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:41:09",
    "roomId": "41b-1db88c20"
}


{
    "stakes": 5,
    "handData": {"338275408": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "Pro1995",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ad0 Td2 As4/4d0 6h0 6d2 6c3 Qc4/Jc0 Js0 3d1 3c1 3h3",
            "win": 80,
            "playerId": "Pro1995"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jd1 Ac2 Jh3 Ks4",
            "rows": "Qh0 Qd2 Ah4/2d0 7s0 Kh1 2s2 7d3/8h0 8d0 5d1 9d3 9c4",
            "win": -80,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:42:37",
    "roomId": "41b-1db88c20"
}


{
    "stakes": 5,
    "handData": {"338275617": [
        {
            "inFantasy": true,
            "result": 48,
            "playerName": "Pro1995",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "9h0 9c0 9s0/3d0 5d0 7d0 8d0 Ad0/2s0 4s0 7s0 Qs0 As0",
            "win": 110,
            "playerId": "Pro1995"
        },
        {
            "inFantasy": true,
            "result": 42,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "2c0",
            "rows": "7h0 7c0 Ah0/4c0 5s0 8h0 8s0 Kd0/6d0 6s0 Qh0 Qd0 Qc0",
            "win": -110,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:43:32",
    "roomId": "41b-1db88c20"
}


{
    "stakes": 5,
    "handData": {"338275726": [
        {
            "inFantasy": true,
            "result": 24,
            "playerName": "Pro1995",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qh0 Qc0 Ac0/5h0 5c0 6h0 6c0 Ks0/3d0 5d0 9d0 Td0 Jd0",
            "win": 60,
            "playerId": "Pro1995"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "9c1 2h2 2c3 3h4",
            "rows": "Kd0 Ts2 Jc4/Ah0 Ad0 9h1 7s2 4d4/5s0 8d0 8s1 3c3 3s3",
            "win": -60,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:44:20",
    "roomId": "41b-1db88c20"
}


{
    "stakes": 5,
    "handData": {"338275833": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "3d1 Qh2 Qd3 6s4",
            "rows": "Kd1 Ks2 Ad3/4h0 5s0 6h0 4s1 5d2/7h0 7s0 Ts3 Jc4 Js4",
            "win": 30,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "Parthhxx",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kh0 Qs1 Kc3/5h0 Ah0 9h2 2s3 Ac4/8d0 8c0 3c1 3h2 Th4",
            "win": -30,
            "playerId": "Parthhxx"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:46:22",
    "roomId": "41b-1db88c20"
}


{
    "stakes": 5,
    "handData": {"338276099": [
        {
            "inFantasy": true,
            "result": 3,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "2d0 4h0",
            "rows": "Th0 Td0 Ad0/7d0 8c0 9h0 Jc0 Js0/5h0 5c0 Kh0 Kc0 Ks0",
            "win": 15,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": true,
            "result": -3,
            "playerName": "Parthhxx",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Tc0 Ts0 Kd0/2h0 3h0 Qh0 Ah0 Ac0/3s0 4s0 5s0 7s0 8s0",
            "win": -15,
            "playerId": "Parthhxx"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:47:28",
    "roomId": "41b-1db88c20"
}


{
    "stakes": 5,
    "handData": {"338276244": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "anantv",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ah0 Ad1 Jd3/3d0 4h0 6c2 6d4 7d4/5h0 5c0 5d1 5s2 Js3",
            "win": -60,
            "playerId": "anantv"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "MukeshGiri33",
            "orderIndex": 2,
            "hero": true,
            "dead": "3c1 Ac2 Jh3 Qs4",
            "rows": "Kh0 6h2 Kd3/9s0 2s2 Qd3 7h4 Ts4/2c0 4c0 7c0 8c1 Qc1",
            "win": -60,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "Parthhxx",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qh0 3h2 9h4/8h0 Jc0 Tc1 Td3 Th4/6s0 7s0 4s1 As2 3s3",
            "win": 120,
            "playerId": "Parthhxx"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:50:10",
    "roomId": "41b-1db88c20"
}


{
    "stakes": 5,
    "handData": {"338276561": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "anantv",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "As1 9c3 Qc3/3h0 4h0 2d2 2c4 4s4/7c0 7s0 8c0 8h1 8s2",
            "win": -65,
            "playerId": "anantv"
        },
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "4d1 7h2 Ah3 4c4",
            "rows": "9h2 Js4 Ad4/3d0 5d0 5s0 2s1 3s2/Ts0 Jh0 Th1 Jd3 Jc3",
            "win": -55,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "Parthhxx",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ac0 Qs3 Td4/3c0 6c0 6h1 6s1 5c2/Kd0 Kc0 9d2 Ks3 Kh4",
            "win": 120,
            "playerId": "Parthhxx"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:53:51",
    "roomId": "41b-1db88c20"
}


{
    "stakes": 5,
    "handData": {"338277005": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "3c1 Ks2 Qd3 Ac4",
            "rows": "6h1 Ad2 As2/2s0 5s0 9h1 2d3 9c3/7h0 7d0 Jc0 3s4 6s4",
            "win": -80,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "Parthhxx",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qh0 Jd3 Jh4/3d0 Kh1 6d2 Kc2 5h3/5c0 6c0 8c0 7c1 2c4",
            "win": 80,
            "playerId": "Parthhxx"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:56:16",
    "roomId": "41b-1db88c20"
}


{
    "stakes": 5,
    "handData": {"338277276": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "anantv",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kd0 Tc2 Ac4/6c0 7s0 5s1 5h3 4c4/Jh0 Ah0 3h1 4h2 Qh3",
            "win": -40,
            "playerId": "anantv"
        },
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "Js1 Ks2 7c3 6s4",
            "rows": "Ad0 As3 Qc4/3s0 4d0 2d1 2s3 3d4/6h0 8h0 7h1 5d2 9s2",
            "win": 40,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:58:19",
    "roomId": "41b-1db88c20"
}


{
    "stakes": 5,
    "handData": {"338277478": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "anantv",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qs3 Ac3 5c4/7d1 7s1 9d2 Tc2 6s4/2h0 3h0 9h0 Th0 Kh0",
            "win": -115,
            "playerId": "anantv"
        },
        {
            "inFantasy": true,
            "result": 33,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "4h0 5d0 8d0",
            "rows": "Jd0 Ah0 Ad0/4s0 5s0 Ts0 Js0 Ks0/2c0 4c0 8c0 Qc0 Kc0",
            "win": 115,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:59:14",
    "roomId": "41b-1db88c20"
}


{
    "stakes": 5,
    "handData": {"338277592": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "anantv",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "8s2 Ah3 As3/9s0 Jd0 Td1 Ts1 Jc2/5c0 Qc0 Qs0 7c4 Js4",
            "win": 0,
            "playerId": "anantv"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "Th1 6s2 2s3 Ad4",
            "rows": "Ks0 Kc2 4s3/2h0 7h0 8h1 Ac2 6c4/3d0 9d0 2d1 7d3 3c4",
            "win": 0,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 15:01:10",
    "roomId": "41b-1db88c20"
}


{
    "stakes": 5,
    "handData": {"338277800": [
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "anantv",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ks0 Kd3 5c4/5h0 5s0 7c1 9h2 9c2/Js0 Qd0 Jd1 Qs3 Jh4",
            "win": 65,
            "playerId": "anantv"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "2c1 5d2 4h3 3s4",
            "rows": "Ac0 4d2 4s4/3d0 8s0 6s1 8h2 8d4/9d0 Qc0 Th1 Td3 Ts3",
            "win": -65,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 15:02:40",
    "roomId": "41b-1db88c20"
}


{
    "stakes": 5,
    "handData": {"338278006": [
        {
            "inFantasy": true,
            "result": -30,
            "playerName": "anantv",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Js0 Qd0 Kh0/4h0 4d0 4s0 8d0 8s0/7s0 9h0 9d0 9c0 9s0",
            "win": 10,
            "playerId": "anantv"
        },
        {
            "inFantasy": false,
            "result": -24,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "Td1 3d2 2d3 Kd4",
            "rows": "Ac0 6d3 Ad4/2s0 6s0 5s1 3s2 Qs2/8h0 Qh0 Th1 Jh3 2h4",
            "win": -10,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 15:03:34",
    "roomId": "41b-1db88c20"
}


{
    "stakes": 5,
    "handData": {"338278131": [
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "anantv",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "2d0 2s0 9s0/6h0 6c0 7d0 Jd0 Ks0/3h0 5h0 8h0 Th0 Ah0",
            "win": -85,
            "playerId": "anantv"
        },
        {
            "inFantasy": true,
            "result": 33,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "3c0 3s0 4d0",
            "rows": "Qh0 Ac0 As0/4h0 Tc0 Ts0 Jh0 Js0/5d0 5c0 Kh0 Kd0 Kc0",
            "win": 85,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 15:04:55",
    "roomId": "41b-1db88c20"
}


{
    "stakes": 5,
    "handData": {"338278319": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "anantv",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kh0 Kd2 Js4/2c0 7c0 9h3 9s3 3s4/3d0 5d0 8d1 9d1 2d2",
            "win": 0,
            "playerId": "anantv"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "Kc1 Ac2 7s3 4c4",
            "rows": "As0 Ad1 4h3/5s0 6h1 Ts2 Td3 4d4/8h0 8c0 9c0 Jh2 2h4",
            "win": 0,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 15:06:42",
    "roomId": "41b-1db88c20"
}


