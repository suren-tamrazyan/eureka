{
    "stakes": 5,
    "handData": {"338266737": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "PitziTiger",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kh2 Td3 Th4/3s0 3h1 5d2 5c3 7h4/2d0 2c0 Qh0 Qc0 Qd1",
            "win": 85,
            "playerId": "PitziTiger"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "variable13",
            "orderIndex": 0,
            "hero": true,
            "dead": "9c1 3d2 3c3 9d4",
            "rows": "Kc0 Ac3 Js4/Ad0 6d1 4h2 6c2 8h4/5h0 5s0 8s0 8c1 7s3",
            "win": -85,
            "playerId": "variable13"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 13:44:23",
    "roomId": "41b-1dae9f5c"
}


{
    "stakes": 5,
    "handData": {"338267022": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "PitziTiger",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ad0 Ah2 9c3/4s0 5h1 Th2 6d4 Kc4/2c0 5c0 6c0 Ac1 Jc3",
            "win": -100,
            "playerId": "PitziTiger"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "variable13",
            "orderIndex": 2,
            "hero": true,
            "dead": "2h1 3s2 3h3 8s4",
            "rows": "Ks1 Tc2 Qc4/7s0 8c0 4h1 4c3 8d4/7d0 9d0 Jd0 Td2 3d3",
            "win": 55,
            "playerId": "variable13"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "jeyjey",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qs0 7c3 Ts4/2d0 3c1 4d1 Kd2 2s3/9h0 Jh0 Kh0 7h2 8h4",
            "win": 45,
            "playerId": "jeyjey"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 13:46:42",
    "roomId": "41b-1dae9f5c"
}


{
    "stakes": 5,
    "handData": {"338267400": [
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "PitziTiger",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kd2 Ac2 Td4/3d0 Tc0 Ts1 Th3 Qh3/4s0 8s0 Js0 2s1 6s4",
            "win": 75,
            "playerId": "PitziTiger"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "variable13",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jh1 3h2 7c3 5d4",
            "rows": "Ad0 Jc3 4c4/8d0 7d1 9s1 7h2 9h4/2c0 5c0 Qc0 Qs2 5s3",
            "win": -75,
            "playerId": "variable13"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "jeyjey",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kc0 8h2 6c4/4h0 7s0 As2 Kh3 Ah4/2d0 Jd0 4d1 6d1 Qd3",
            "win": 0,
            "playerId": "jeyjey"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 13:49:13",
    "roomId": "41b-1dae9f5c"
}


{
    "stakes": 5,
    "handData": {"338267782": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "PitziTiger",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kh0 Qs1 3c3/6d0 8s0 Ad1 5s2 Ah4/7h0 Th0 9d2 9h3 Td4",
            "win": 5,
            "playerId": "PitziTiger"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "variable13",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qd1 6c2 As3 7c4",
            "rows": "Ac0 2d3 3h3/3d0 4h0 5h1 3s2 Jh4/8h0 9c0 Tc1 8d2 Ts4",
            "win": -5,
            "playerId": "variable13"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 13:51:01",
    "roomId": "41b-1dae9f5c"
}


{
    "stakes": 5,
    "handData": {"338268067": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "PitziTiger",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ac0 Ad1 7h3/5d0 3s1 2s2 6c4 7s4/6h0 6d0 9d0 Tc2 Th3",
            "win": -75,
            "playerId": "PitziTiger"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "variable13",
            "orderIndex": 1,
            "hero": true,
            "dead": "8h1 7d2 8s3 3h4",
            "rows": "Qd0 Qh2 Jc4/3d0 Kc0 2h3 2d3 Kd4/9s0 Ts0 Js1 Qs1 8d2",
            "win": 75,
            "playerId": "variable13"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 13:52:30",
    "roomId": "41b-1dae9f5c"
}


{
    "stakes": 5,
    "handData": {"338268302": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "PitziTiger",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc3 Ks3 8c4/5h1 5c1 2h2 2c2 4d4/3h0 7s0 Tc0 Ts0 Qs0",
            "win": -85,
            "playerId": "PitziTiger"
        },
        {
            "inFantasy": true,
            "result": 33,
            "playerName": "variable13",
            "orderIndex": 0,
            "hero": true,
            "dead": "2d0",
            "rows": "Td0 Ac0 As0/8h0 Jh0 Jc0 Qd0 Qc0/4h0 5d0 6h0 7c0 8s0",
            "win": 85,
            "playerId": "variable13"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 13:53:23",
    "roomId": "41b-1dae9f5c"
}


{
    "stakes": 5,
    "handData": {"338268436": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "PitziTiger",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Js2 Kd2 7h4/2c0 6c0 5c1 9c3 Th4/9h0 Jh0 Ah0 6h1 5h3",
            "win": -80,
            "playerId": "PitziTiger"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "variable13",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jc1 4c2 Qs3 9s4",
            "rows": "Qc2 Ac3 6s4/5d0 7c1 7d2 2d3 Tc4/8h0 8c0 8s0 Ts0 8d1",
            "win": 80,
            "playerId": "variable13"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 13:55:04",
    "roomId": "41b-1dae9f5c"
}


{
    "stakes": 5,
    "handData": {"338268681": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "PitziTiger",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "As0 5d3 9d4/8h1 7c2 Td2 6d3 9c4/6h0 Jh0 Qh0 Kh0 4h1",
            "win": -40,
            "playerId": "PitziTiger"
        },
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "variable13",
            "orderIndex": 0,
            "hero": true,
            "dead": "4s1 Kd2 7h3 4d4",
            "rows": "Ah0 Ad1 Th4/2c0 3d0 2h1 9s2 3h3/Tc0 Ts0 5c2 5s3 5h4",
            "win": 40,
            "playerId": "variable13"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 13:56:39",
    "roomId": "41b-1dae9f5c"
}


{
    "stakes": 5,
    "handData": {"338268885": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "PitziTiger",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kd3 Ks3 Ac4/4d1 4c1 5c2 Jd2 3s4/6c0 7d0 8c0 9d0 Ts0",
            "win": -125,
            "playerId": "PitziTiger"
        },
        {
            "inFantasy": true,
            "result": 27,
            "playerName": "variable13",
            "orderIndex": 1,
            "hero": true,
            "dead": "3h0 Tc0 Jc0",
            "rows": "Qh0 Qd0 Ad0/4h0 5h0 7h0 8h0 Th0/2s0 5s0 6s0 9s0 Js0",
            "win": 125,
            "playerId": "variable13"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 13:58:56",
    "roomId": "41b-1dae9f5c"
}


{
    "stakes": 5,
    "handData": {"338269190": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "PARIS_to_ROME",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qd0 Qs2 Ks4/2d0 2c0 5c3 Kd3 2s4/4s0 7s0 7h1 7d1 4c2",
            "win": 40,
            "playerId": "PARIS_to_ROME"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "variable13",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jh1 6h2 Ac3 6d4",
            "rows": "Kh0 Qc1 Kc2/2h0 Ad1 As2 8s3 9c4/5h0 5d0 Tc0 9d3 9h4",
            "win": -40,
            "playerId": "variable13"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:00:25",
    "roomId": "41b-1dae9f5c"
}


{
    "stakes": 5,
    "handData": {"338269403": [
        {
            "inFantasy": true,
            "result": -21,
            "playerName": "PARIS_to_ROME",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "8h0 8d0 Jd0/3c0 7c0 Qc0 Kc0 Ac0/4d0 4c0 4s0 6h0 6s0",
            "win": 15,
            "playerId": "PARIS_to_ROME"
        },
        {
            "inFantasy": true,
            "result": -15,
            "playerName": "variable13",
            "orderIndex": 0,
            "hero": true,
            "dead": "2d0 3h0",
            "rows": "Ks0 Ad0 As0/7h0 7d0 7s0 8s0 9h0/2c0 5c0 6c0 8c0 Tc0",
            "win": -15,
            "playerId": "variable13"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:01:30",
    "roomId": "41b-1dae9f5c"
}


{
    "stakes": 5,
    "handData": {"338269598": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "PARIS_to_ROME",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "4s1 Qd2 3s3/5d0 8d0 8s0 3d1 Td3/7h0 Jh0 4h2 2h4 4c4",
            "win": -75,
            "playerId": "PARIS_to_ROME"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "variable13",
            "orderIndex": 2,
            "hero": true,
            "dead": "5c1 7c2 9s3 9h4",
            "rows": "Kh0 8h1 Kd2/Jd0 3h1 Th2 Js3 4d4/6h0 6d0 Qc0 9c3 2c4",
            "win": -75,
            "playerId": "variable13"
        },
        {
            "inFantasy": false,
            "result": 66,
            "playerName": "jeyjey",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ah3 As3 Qh4/Ad0 Ac0 9d1 Jc2 Ks4/5h0 5s0 7s0 Ts1 7d2",
            "win": 150,
            "playerId": "jeyjey"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:04:04",
    "roomId": "41b-1dae9f5c"
}


{
    "stakes": 5,
    "handData": {"338270023": [
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "PARIS_to_ROME",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kd1 Jc3 9d4/2c0 7h0 7c1 3h2 3d2/5h0 5c0 Qd0 Qh3 8h4",
            "win": -175,
            "playerId": "PARIS_to_ROME"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "variable13",
            "orderIndex": 1,
            "hero": true,
            "dead": "5s1 7d2 Ac3 Qs4",
            "rows": "Kc0 Js2 Qc3/3c0 4s0 2d1 6s2 Ah3/Td0 Tc0 8s1 8c4 Ts4",
            "win": -70,
            "playerId": "variable13"
        },
        {
            "inFantasy": true,
            "result": 54,
            "playerName": "jeyjey",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Th0 Kh0 Ks0/6h0 6d0 6c0 Jh0 Jd0/4d0 4c0 9h0 9c0 9s0",
            "win": 245,
            "playerId": "jeyjey"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:09:36",
    "roomId": "41b-1dae9f5c"
}


{
    "stakes": 5,
    "handData": {"338270943": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "variable13",
            "orderIndex": 1,
            "hero": true,
            "dead": "6h1 Td2 Kc3 Ts4",
            "rows": "Kd0 Ks0 9c3/2d0 3d1 Ah3 3c4 5h4/8h0 Jh0 8s1 8c2 Jc2",
            "win": 0,
            "playerId": "variable13"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "Parthhxx",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "As1 Qc3 4s4/6s0 7s0 3h1 7h2 6c3/5d0 5c0 Jd0 9s2 8d4",
            "win": 0,
            "playerId": "Parthhxx"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:14:57",
    "roomId": "41b-1dae9f5c"
}


{
    "stakes": 5,
    "handData": {"338271751": [
        {
            "inFantasy": false,
            "result": 33,
            "playerName": "variable13",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jc1 9h2 5c3 3s4",
            "rows": "Ah0 Ad2 8h4/7d0 7s0 2s1 3d1 3h2/5h0 Qh0 9d3 9c3 9s4",
            "win": 75,
            "playerId": "variable13"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "DONDONAP",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "As1 6s3 Kc3/2h0 5s0 Jd0 Js1 2c4/3c0 7c0 8d2 8s2 Th4",
            "win": -75,
            "playerId": "DONDONAP"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:17:12",
    "roomId": "41b-1dae9f5c"
}


{
    "stakes": 5,
    "handData": {"338272073": [
        {
            "inFantasy": true,
            "result": 42,
            "playerName": "variable13",
            "orderIndex": 0,
            "hero": true,
            "dead": "2s0 7d0 8d0",
            "rows": "4h0 4d0 4c0/Th0 Jh0 Qs0 Ks0 Ah0/2c0 6c0 9c0 Tc0 Kc0",
            "win": 100,
            "playerId": "variable13"
        },
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "DONDONAP",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Jd3 Kd3 Td4/5d1 5c1 3d2 5s2 2d4/3h0 5h0 6h0 9h0 Kh0",
            "win": -100,
            "playerId": "DONDONAP"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:18:10",
    "roomId": "41b-1dae9f5c"
}


{
    "stakes": 5,
    "handData": {"338272206": [
        {
            "inFantasy": true,
            "result": -24,
            "playerName": "variable13",
            "orderIndex": 1,
            "hero": true,
            "dead": "2d0",
            "rows": "Kc0 Ah0 As0/6d0 6c0 7h0 8h0 8d0/3d0 4h0 4c0 Tc0 Ts0",
            "win": -75,
            "playerId": "variable13"
        },
        {
            "inFantasy": false,
            "result": -30,
            "playerName": "DONDONAP",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "4d3 4s3 Th4/Jh1 Jc1 3h2 3s2 9c4/Td0 Jd0 Qd0 Kd0 Ad0",
            "win": 75,
            "playerId": "DONDONAP"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:18:56",
    "roomId": "41b-1dae9f5c"
}


{
    "stakes": 5,
    "handData": {"338272325": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "variable13",
            "orderIndex": 0,
            "hero": true,
            "dead": "6h1 6c2 3c3 8c4",
            "rows": "Qc1 Qh3 Kc3/5h0 6d0 6s0 2s2 5c4/9s0 Ts0 7h1 Th2 Tc4",
            "win": -70,
            "playerId": "variable13"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "DONDONAP",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ad2 Kh3 Ah3/4h0 8h0 8d1 3s4 8s4/Js0 Qs0 Ks0 7s1 As2",
            "win": 70,
            "playerId": "DONDONAP"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:21:04",
    "roomId": "41b-1dae9f5c"
}


{
    "stakes": 5,
    "handData": {"338272631": [
        {
            "inFantasy": true,
            "result": 3,
            "playerName": "variable13",
            "orderIndex": 1,
            "hero": true,
            "dead": "4h0",
            "rows": "6d0 6s0 Kc0/7h0 8c0 9h0 Ts0 Jh0/2h0 2d0 2c0 5c0 5s0",
            "win": -65,
            "playerId": "variable13"
        },
        {
            "inFantasy": true,
            "result": 15,
            "playerName": "DONDONAP",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "9d0 9c0 Kh0/7s0 9s0 Js0 Ks0 As0/4d0 4c0 Qh0 Qd0 Qc0",
            "win": 65,
            "playerId": "DONDONAP"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:22:28",
    "roomId": "41b-1dae9f5c"
}


{
    "stakes": 5,
    "handData": {"338272829": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "Santhoshkumarmu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kc1 Kd2 Ah4/2h0 3d0 5d1 3c3 5h3/8h0 8c0 Jd0 Td2 9d4",
            "win": -70,
            "playerId": "Santhoshkumarmu"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "variable13",
            "orderIndex": 1,
            "hero": true,
            "dead": "7c1 4s2 Ac3 4c4",
            "rows": "2c0 9h1 6c4/Ts0 3s1 Jh2 Ks2 Th4/8d0 Qd0 Ad0 Qh3 Qs3",
            "win": 15,
            "playerId": "variable13"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "DONDONAP",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kh1 As1 2s4/4d0 6h0 6d0 6s2 8s2/7d0 7s0 7h3 9s3 2d4",
            "win": 55,
            "playerId": "DONDONAP"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:25:01",
    "roomId": "41b-1dae9f5c"
}


{
    "stakes": 5,
    "handData": {"338273194": [
        {
            "inFantasy": false,
            "result": 57,
            "playerName": "Santhoshkumarmu",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kd0 Kh2 Ah3/2h0 6s0 6h1 6c2 Qc4/7d0 7c0 7s1 5d3 9c4",
            "win": 85,
            "playerId": "Santhoshkumarmu"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "variable13",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ks1 9d2 As3 5s4",
            "rows": "Ad0 Ac1 Kc2/2d0 3s0 4s1 4h3 5h4/Tc0 Ts0 8c2 Qh3 4d4",
            "win": -160,
            "playerId": "variable13"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "DONDONAP",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "2s0 6d4 Qs4/9h0 Th0 8h2 9s2 8d3/Jd0 Jc0 Jh1 Js1 3h3",
            "win": 75,
            "playerId": "DONDONAP"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:27:27",
    "roomId": "41b-1dae9f5c"
}


{
    "stakes": 5,
    "handData": {"338273569": [
        {
            "inFantasy": true,
            "result": 10,
            "playerName": "Santhoshkumarmu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "5c0 Tc0 Ad0/8s0 9d0 Ts0 Jc0 Qc0/4h0 5h0 6h0 Qh0 Ah0",
            "win": 130,
            "playerId": "Santhoshkumarmu"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "variable13",
            "orderIndex": 2,
            "hero": true,
            "dead": "9c1 2d2 Jh3 Qd4",
            "rows": "As1 Ac2 Td4/3c0 4d0 4c1 6d3 7s4/2h0 Th0 Kh0 Ks2 2c3",
            "win": -90,
            "playerId": "variable13"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "DONDONAP",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "8c2 Kc2 Qs4/2s0 5d0 3h1 5s3 3s4/7h0 7c0 Jd0 7d1 9h3",
            "win": -40,
            "playerId": "DONDONAP"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:29:38",
    "roomId": "41b-1dae9f5c"
}


{
    "stakes": 5,
    "handData": {"338273888": [
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "Santhoshkumarmu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qc1 Qh3 Ah3/3s0 8d0 3d2 8s2 4s4/2h0 2s0 Jh0 2d1 7c4",
            "win": 20,
            "playerId": "Santhoshkumarmu"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "variable13",
            "orderIndex": 1,
            "hero": true,
            "dead": "3c1 Tc2 2c3 5c4",
            "rows": "Kh0 3h3 Kc3/Ad0 5s1 6c2 Ac2 Kd4/7s0 9d0 9s0 7h1 Ts4",
            "win": 25,
            "playerId": "variable13"
        },
        {
            "inFantasy": false,
            "result": 39,
            "playerName": "DONDONAP",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qs1 Ks2 8c3/9c0 Th1 9h2 5h3 8h4/4d0 5d0 6d0 Jd0 Qd4",
            "win": -45,
            "playerId": "DONDONAP"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:31:50",
    "roomId": "41b-1dae9f5c"
}


{
    "stakes": 5,
    "handData": {"338274177": [
        {
            "inFantasy": true,
            "result": 63,
            "playerName": "Santhoshkumarmu",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "5d0 Ac0 As0/4d0 7h0 7c0 8h0 8s0/3h0 3c0 3s0 6c0 6s0",
            "win": 145,
            "playerId": "Santhoshkumarmu"
        },
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "variable13",
            "orderIndex": 0,
            "hero": true,
            "dead": "2s0 4c0",
            "rows": "Jh0 Qs0 Ks0/5c0 6h0 7d0 8c0 9c0/6d0 8d0 Td0 Jd0 Ad0",
            "win": 30,
            "playerId": "variable13"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "DONDONAP",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qh3 Kc3 Th4/Kh1 Kd1 7s2 Tc2 5s4/2h0 2d0 3d0 9h0 9d0",
            "win": -175,
            "playerId": "DONDONAP"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:33:55",
    "roomId": "41b-1dae9f5c"
}


{
    "stakes": 5,
    "handData": {"338274451": [
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "Santhoshkumarmu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ks2 Tc3 Kc3/Ad0 Ac0 9h1 3c4 5c4/6h0 6d0 6c0 8d1 8h2",
            "win": 55,
            "playerId": "Santhoshkumarmu"
        },
        {
            "inFantasy": false,
            "result": 39,
            "playerName": "variable13",
            "orderIndex": 2,
            "hero": true,
            "dead": "Kh1 9d2 3h3 4d4",
            "rows": "Td3 Jc3 Qs4/5h1 5d1 2h2 8c2 8s4/4s0 5s0 6s0 Js0 As0",
            "win": -105,
            "playerId": "variable13"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "DONDONAP",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qc0 9s1 Qd3/4c0 2c1 Ah2 2s3 4h4/7d0 7c0 Jh0 7h2 Jd4",
            "win": 50,
            "playerId": "DONDONAP"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:36:32",
    "roomId": "41b-1dae9f5c"
}


{
    "stakes": 5,
    "handData": {"338274800": [
        {
            "inFantasy": true,
            "result": 60,
            "playerName": "Santhoshkumarmu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "7s0 Kh0 Ks0/7h0 8h0 9d0 Tc0 Jh0/3c0 3s0 Ah0 Ad0 As0",
            "win": 200,
            "playerId": "Santhoshkumarmu"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "variable13",
            "orderIndex": 1,
            "hero": true,
            "dead": "5s1 8c2 9c3 5h4",
            "rows": "Qs1 Kc2 9s4/4c0 4s1 6h2 4d3 Jd3/7c0 8s0 9h0 Js0 Td4",
            "win": -105,
            "playerId": "variable13"
        },
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "DONDONAP",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Th0 Qc0 Ac0/2h0 2s0 3h0 4h0 Jc0/3d0 6d0 7d0 8d0 Qd0",
            "win": -95,
            "playerId": "DONDONAP"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:38:22",
    "roomId": "41b-1dae9f5c"
}


{
    "stakes": 5,
    "handData": {"338275033": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "Santhoshkumarmu",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qd0 Qs0 8h3/Kc0 3h1 Js3 Kh4 Ac4/9d0 9c0 8s1 6h2 6c2",
            "win": -85,
            "playerId": "Santhoshkumarmu"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "variable13",
            "orderIndex": 0,
            "hero": true,
            "dead": "2d1 Qh2 3d3 3c4",
            "rows": "Ks2 Qc3 Kd3/4d0 9h0 5h1 5d1 9s4/Td0 Ts0 Jd0 Jh2 7c4",
            "win": 15,
            "playerId": "variable13"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "DONDONAP",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ad2 8c3 Ah4/6d0 7h0 7d1 4h2 4c4/3s0 4s0 As0 5s1 2h3",
            "win": 70,
            "playerId": "DONDONAP"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:41:01",
    "roomId": "41b-1dae9f5c"
}


{
    "stakes": 5,
    "handData": {"338275385": [
        {
            "inFantasy": true,
            "result": 60,
            "playerName": "Santhoshkumarmu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Js0 Ah0 Ad0/7s0 9d0 9c0 Qc0 Qs0/3d0 3c0 3s0 6h0 6s0",
            "win": 60,
            "playerId": "Santhoshkumarmu"
        },
        {
            "inFantasy": true,
            "result": 27,
            "playerName": "variable13",
            "orderIndex": 2,
            "hero": true,
            "dead": "2s0 4c0",
            "rows": "5h0 5c0 Ks0/7c0 8d0 9s0 Ts0 Jc0/3h0 4h0 7h0 8h0 Jh0",
            "win": -65,
            "playerId": "variable13"
        },
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "DONDONAP",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Th0 Qh0 Kh0/2d0 5d0 Td0 Jd0 Kd0/2c0 6c0 8c0 Kc0 Ac0",
            "win": 5,
            "playerId": "DONDONAP"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:42:33",
    "roomId": "41b-1dae9f5c"
}


{
    "stakes": 5,
    "handData": {"338275606": [
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "Santhoshkumarmu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kc2 8s4 Ts4/2h0 5c1 5s1 3c2 3d3/9d0 9c0 Td0 Tc0 Th3",
            "win": 0,
            "playerId": "Santhoshkumarmu"
        },
        {
            "inFantasy": false,
            "result": 57,
            "playerName": "variable13",
            "orderIndex": 1,
            "hero": true,
            "dead": "7c1 Qc2 Js3 4c4",
            "rows": "Kh0 Ad2 Kd3/2c0 2d1 3s1 2s3 Qs4/6d0 6c0 8c0 6h2 9h4",
            "win": 105,
            "playerId": "variable13"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "DONDONAP",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ac1 Ks3 9s4/7s0 8d1 7d2 8h2 5h3/Jd0 Jc0 Qh0 Qd0 4d4",
            "win": -105,
            "playerId": "DONDONAP"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:45:08",
    "roomId": "41b-1dae9f5c"
}


{
    "stakes": 5,
    "handData": {"338275938": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "Santhoshkumarmu",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qh0 9d4 Ks4/Ah0 2d1 2s2 Js2 2h3/6s0 7s0 9s0 8s1 5c3",
            "win": -75,
            "playerId": "Santhoshkumarmu"
        },
        {
            "inFantasy": true,
            "result": 60,
            "playerName": "variable13",
            "orderIndex": 0,
            "hero": true,
            "dead": "4d0 Jh0",
            "rows": "Qs0 Kd0 Kc0/4h0 5h0 6c0 7d0 8c0/3h0 3d0 3s0 Td0 Tc0",
            "win": 220,
            "playerId": "variable13"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "DONDONAP",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ad0 Ac1 4c4/4s0 5s0 5d1 6h2 6d2/8d0 9c0 8h3 Kh3 Ts4",
            "win": -145,
            "playerId": "DONDONAP"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:47:52",
    "roomId": "41b-1dae9f5c"
}


{
    "stakes": 5,
    "handData": {"338276287": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "variable13",
            "orderIndex": 1,
            "hero": true,
            "dead": "2h1 3h2 7d3 Ac4",
            "rows": "Ks0 Ts2 Kh3/5d0 7h0 4h1 5h3 Qs4/9c0 Jd0 Jh1 Js2 9s4",
            "win": -50,
            "playerId": "variable13"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "DONDONAP",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "7s3 4c4 4s4/8s0 Ah0 6h2 6s2 As3/2d0 3d0 6d0 Qd1 Ad1",
            "win": 50,
            "playerId": "DONDONAP"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:49:27",
    "roomId": "41b-1dae9f5c"
}


{
    "stakes": 5,
    "handData": {"338276471": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "variable13",
            "orderIndex": 0,
            "hero": true,
            "dead": "9d1 Qc2 5s3 Ks4",
            "rows": "Kh0 Kc0 2s4/2c0 4d0 Ad1 Kd2 Ac2/7s0 3h1 7h3 Jh3 Jd4",
            "win": 10,
            "playerId": "variable13"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "DONDONAP",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qd1 7d3 Qs3/6c0 Ah0 As1 2h2 3d2/8c0 8s0 9s0 6d4 8d4",
            "win": -10,
            "playerId": "DONDONAP"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:50:57",
    "roomId": "41b-1dae9f5c"
}


{
    "stakes": 5,
    "handData": {"338276655": [
        {
            "inFantasy": true,
            "result": 18,
            "playerName": "variable13",
            "orderIndex": 1,
            "hero": true,
            "dead": "2c0 5s0",
            "rows": "Th0 Ts0 Ac0/6h0 7h0 Jd0 Js0 Qc0/5c0 6d0 7s0 8d0 9d0",
            "win": 10,
            "playerId": "variable13"
        },
        {
            "inFantasy": true,
            "result": 12,
            "playerName": "DONDONAP",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Jh0 Kd0 Ad0/2h0 2d0 4d0 9h0 9s0/3c0 4c0 6c0 7c0 Kc0",
            "win": -10,
            "playerId": "DONDONAP"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:51:58",
    "roomId": "41b-1dae9f5c"
}


{
    "stakes": 5,
    "handData": {"338276771": [
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "variable13",
            "orderIndex": 0,
            "hero": true,
            "dead": "9s1 Tc2 3c3 3h4",
            "rows": "Kc0 8c3 7s4/2c0 6d0 2s2 6s2 4h3/Th0 Jh0 8h1 9c1 7c4",
            "win": -90,
            "playerId": "variable13"
        },
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "DONDONAP",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "5s0 Kh3 Ks4/Ah1 8s2 Ac2 As3 Qc4/4d0 9d0 Kd0 Ad0 3d1",
            "win": 90,
            "playerId": "DONDONAP"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:53:46",
    "roomId": "41b-1dae9f5c"
}


{
    "stakes": 5,
    "handData": {"338276995": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "variable13",
            "orderIndex": 1,
            "hero": true,
            "dead": "3h1 6d2 3s3 5h4",
            "rows": "Qh2 Ad3 Td4/5c0 9h0 9c1 5s2 8d3/4d0 4s0 Jd0 4c1 9d4",
            "win": -155,
            "playerId": "variable13"
        },
        {
            "inFantasy": true,
            "result": 27,
            "playerName": "DONDONAP",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Js0 Qd0 Qc0/2c0 3c0 6c0 Tc0 Jc0/7h0 7d0 7c0 7s0 9s0",
            "win": 155,
            "playerId": "DONDONAP"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:54:28",
    "roomId": "41b-1dae9f5c"
}


{
    "stakes": 5,
    "handData": {"338277089": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "variable13",
            "orderIndex": 0,
            "hero": true,
            "dead": "Kc1 2d2 6s3 6h4",
            "rows": "Ah0 3s2 Ac3/5c0 7s0 8c1 8s1 3c4/9h0 Jh0 Ks2 Qd3 3d4",
            "win": -5,
            "playerId": "variable13"
        },
        {
            "inFantasy": true,
            "result": 3,
            "playerName": "DONDONAP",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Jd0 Kd0 As0/4h0 8h0 Th0 Td0 Tc0/2c0 3h0 Qh0 Qc0 Qs0",
            "win": 5,
            "playerId": "DONDONAP"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:55:46",
    "roomId": "41b-1dae9f5c"
}


{
    "stakes": 5,
    "handData": {"338277232": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "variable13",
            "orderIndex": 1,
            "hero": true,
            "dead": "6s1 Tc2 9c3 Ad4",
            "rows": "Kc0 Qh1 Kh4/4s0 5c0 4c1 7c2 7d3/2d0 Jd0 2c2 8c3 7h4",
            "win": -95,
            "playerId": "variable13"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "DONDONAP",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qd0 Js3 Qs4/2h0 Ac0 As0 5s2 8s3/9d0 6c1 9h1 6d2 6h4",
            "win": 95,
            "playerId": "DONDONAP"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:57:39",
    "roomId": "41b-1dae9f5c"
}


{
    "stakes": 5,
    "handData": {"338277412": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "variable13",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ts1 Qd2 Ks3 8h4",
            "rows": "Ac0 Kd2 Ad2/5c0 2s1 3c1 2c3 5h3/7h0 Th0 Jh0 4c4 4s4",
            "win": -60,
            "playerId": "variable13"
        },
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "DONDONAP",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Jc0 Kc0 Ah0/3s0 5d0 6h0 8c0 8s0/7d0 7c0 7s0 9h0 9d0",
            "win": 60,
            "playerId": "DONDONAP"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:58:39",
    "roomId": "41b-1dae9f5c"
}


{
    "stakes": 5,
    "handData": {"338277521": [
        {
            "inFantasy": false,
            "result": 63,
            "playerName": "Santhoshkumarmu",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ks1 Ah3 As4/3h0 6c0 8d0 6d2 8s2/Th0 Td0 Ts1 7d3 9s4",
            "win": 95,
            "playerId": "Santhoshkumarmu"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "variable13",
            "orderIndex": 0,
            "hero": true,
            "dead": "6s1 7h2 3s3 3d4",
            "rows": "Qd3 2s4 Jh4/4d0 Js0 Jc1 4c2 2h3/5c0 8c0 9c0 7c1 3c2",
            "win": 5,
            "playerId": "variable13"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "DONDONAP",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "7s2 Jd3 Ad3/4s0 5d0 6h0 5h1 Kh4/Tc0 Qc0 Qs1 2d2 Kc4",
            "win": -100,
            "playerId": "DONDONAP"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 15:01:15",
    "roomId": "41b-1dae9f5c"
}


{
    "stakes": 5,
    "handData": {"338277809": [
        {
            "inFantasy": true,
            "result": 51,
            "playerName": "Santhoshkumarmu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "3h0 3d0 3c0/6h0 7d0 8c0 9h0 Td0/4s0 5s0 6s0 8s0 As0",
            "win": 155,
            "playerId": "Santhoshkumarmu"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "variable13",
            "orderIndex": 2,
            "hero": true,
            "dead": "Ks1 Qd2 2c3 4c4",
            "rows": "Qs0 Kc0 Kh1/Ah0 Ad0 5c2 6d4 9d4/Jd0 Tc1 Jh2 Ts3 Jc3",
            "win": -5,
            "playerId": "variable13"
        },
        {
            "inFantasy": false,
            "result": 36,
            "playerName": "DONDONAP",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "4h2 4d2 8h3/Th0 Ac0 5h1 5d1 8d4/7s0 9s0 Js0 7h3 Qc4",
            "win": -150,
            "playerId": "DONDONAP"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 15:03:24",
    "roomId": "41b-1dae9f5c"
}


{
    "stakes": 5,
    "handData": {"338278111": [
        {
            "inFantasy": true,
            "result": 18,
            "playerName": "Santhoshkumarmu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "5h0 5d0 5c0/8d0 Tc0 Jd0 Jc0 Js0/3d0 3c0 3s0 7h0 7d0",
            "win": 80,
            "playerId": "Santhoshkumarmu"
        },
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "variable13",
            "orderIndex": 1,
            "hero": true,
            "dead": "4c0 7s0",
            "rows": "Ks0 Ah0 Ad0/2d0 2s0 6d0 6s0 9h0/8c0 9c0 Th0 Jh0 Qd0",
            "win": -80,
            "playerId": "variable13"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 15:04:27",
    "roomId": "41b-1dae9f5c"
}


{
    "stakes": 5,
    "handData": {"338278256": [
        {
            "inFantasy": true,
            "result": -9,
            "playerName": "Santhoshkumarmu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Th0 Td0 Qc0/3d0 4s0 5s0 6d0 7c0/2h0 4h0 6h0 8h0 9h0",
            "win": 35,
            "playerId": "Santhoshkumarmu"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "variable13",
            "orderIndex": 0,
            "hero": true,
            "dead": "2d1 As2 6s3 4d4",
            "rows": "Qh0 Kd0 Qd4/Ah0 Ad0 3h1 7d3 Tc3/Js0 8s1 9d2 9c2 Jd4",
            "win": -35,
            "playerId": "variable13"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 15:05:14",
    "roomId": "41b-1dae9f5c"
}


{
    "stakes": 5,
    "handData": {"338278364": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "Santhoshkumarmu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ts3 Qs3 5d4/Jh1 Js1 8h2 8c2 4h4/7d0 9d0 Td0 Qd0 Ad0",
            "win": -50,
            "playerId": "Santhoshkumarmu"
        },
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "variable13",
            "orderIndex": 1,
            "hero": true,
            "dead": "3s0",
            "rows": "5s0 6c0 6s0/6h0 7h0 9h0 Th0 Qh0/5c0 7c0 Jc0 Qc0 Kc0",
            "win": 50,
            "playerId": "variable13"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 15:05:50",
    "roomId": "41b-1dae9f5c"
}


