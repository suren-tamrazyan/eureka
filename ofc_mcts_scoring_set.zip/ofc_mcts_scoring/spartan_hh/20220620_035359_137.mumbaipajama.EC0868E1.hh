{
    "stakes": 10,
    "handData": {"338163890": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "rajprateek1993",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "3h1 Ah2 As3/8s0 Th0 2h1 2d3 7s4/2c0 5c0 Jc0 3c2 Ac4",
            "win": -60,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "mumbaipajama",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jd1 Js2 2s3 9h4",
            "rows": "Qs0 7d2 Kc4/8h0 4h1 9d2 9s3 Td3/6h0 6d0 6s0 5d1 Qh4",
            "win": 120,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "Mickier",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kh2 Qc3 8c4/4c0 7c0 6c1 Tc1 9c3/3d0 Qd0 Ad0 8d2 Ts4",
            "win": -60,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 00:53:59",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338164021": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "rajprateek1993",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ah0 As0 8h3/3h0 3d0 5h1 5s2 Kc4/Ts0 Td1 7s2 7c3 Kd4",
            "win": -210,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "mumbaipajama",
            "orderIndex": 0,
            "hero": true,
            "dead": "Tc1 6h2 7h3 4s4",
            "rows": "Ks0 Ad3 Kh4/5c0 2h1 2c2 5d2 2d4/8c0 8s0 9h0 9s1 9d3",
            "win": 320,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qh0 Ac3 Qd4/3s0 4d1 6c2 3c3 4h4/6d0 6s0 Jd0 Jc1 Jh2",
            "win": -110,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 00:56:41",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338164138": [
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "rajprateek1993",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "6h0 6d0 6s0/9c0 Th0 Jh0 Qd0 Ks0/2s0 3s0 4s0 9s0 Js0",
            "win": 60,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "mumbaipajama",
            "orderIndex": 2,
            "hero": true,
            "dead": "3h0 5s0",
            "rows": "Qc0 Ad0 Ac0/8h0 8c0 9h0 Jd0 Jc0/4h0 4d0 4c0 7c0 7s0",
            "win": -220,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": true,
            "result": -12,
            "playerName": "Mickier",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kh0 Ah0 As0/3d0 8d0 9d0 Td0 Kd0/5h0 5d0 5c0 Qh0 Qs0",
            "win": 160,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 00:58:32",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338164212": [
        {
            "inFantasy": true,
            "result": 57,
            "playerName": "rajprateek1993",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qd0 Kd0 Kc0/8c0 Tc0 Jh0 Ah0 Ac0/4h0 5s0 6c0 7d0 8d0",
            "win": 230,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "mumbaipajama",
            "orderIndex": 1,
            "hero": true,
            "dead": "Td1 Ks2 Js3 Kh4",
            "rows": "Ad0 As2 Qh3/3s0 5d0 6s0 5c1 Jd4/8h0 7s1 4s2 7h3 6h4",
            "win": -260,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "Mickier",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qs0 4d3 3c4/6d0 Th0 8s1 9d2 9h4/2c0 Jc0 Qc1 7c2 4c3",
            "win": 30,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 01:00:56",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338164316": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "rajprateek1993",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "8c3 Ah3 9h4/5c0 6h0 Kh2 Ks2 5d4/7c0 7s0 Ts0 7h1 Tc1",
            "win": -30,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "mumbaipajama",
            "orderIndex": 0,
            "hero": true,
            "dead": "6s1 2h2 2s3 7d4",
            "rows": "Qs1 Ac3 8s4/5h0 9d0 4s1 5s2 9s4/8h0 8d0 Js0 Jh2 Td3",
            "win": -280,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 63,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kd0 Ad3 As4/3d0 6d0 3s1 Qh2 3c4/9c0 Jc0 Kc1 2c2 Qc3",
            "win": 310,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 01:03:29",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338164435": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "rajprateek1993",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qh1 Tc2 6s4/3s0 9s0 8d1 9h2 8s3/2h0 2c0 Jc0 4h3 Jd4",
            "win": -240,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "mumbaipajama",
            "orderIndex": 2,
            "hero": true,
            "dead": "7d1 Js2 4d3 Qc4",
            "rows": "7s3 Ts3 Kd4/2s0 3d1 2d2 5c2 Kh4/6h0 Th0 Jh0 Ah0 5h1",
            "win": -100,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": true,
            "result": 54,
            "playerName": "Mickier",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "5s0 Qd0 Qs0/8h0 8c0 9d0 9c0 Ks0/7h0 7c0 Ad0 Ac0 As0",
            "win": 340,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 01:06:08",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338164582": [
        {
            "inFantasy": false,
            "result": 63,
            "playerName": "rajprateek1993",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ac2 Ad3 4s4/2h0 6s0 7h0 6c1 2d3/9s0 Jd0 9c1 8h2 Jh4",
            "win": 170,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "mumbaipajama",
            "orderIndex": 1,
            "hero": true,
            "dead": "6h1 2c2 9d3 As4",
            "rows": "Kh0 Kc3 Ah4/7d0 7c0 Qd2 5c3 4c4/8c0 Tc0 9h1 Jc1 Qh2",
            "win": -270,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "Mickier",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qc0 4d4 8s4/6d0 Th0 Td2 Ts2 3h3/3s0 5s0 2s1 Js1 7s3",
            "win": 100,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 01:09:09",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338164739": [
        {
            "inFantasy": true,
            "result": 102,
            "playerName": "rajprateek1993",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "7h0 7d0 7s0/Td0 Jd0 Qs0 Ks0 Ac0/2d0 3d0 4d0 8d0 Ad0",
            "win": 540,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": 45,
            "playerName": "mumbaipajama",
            "orderIndex": 0,
            "hero": true,
            "dead": "Kd1 3h2 2h3 2c4",
            "rows": "Ah0 6d3 Tc4/Js0 8s1 9h2 As3 Qh4/5c0 7c0 Kc0 9c1 8c2",
            "win": -150,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 33,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Jh0 8h2 5s3/2s0 6c0 3c1 Qc2 6s3/5d0 Qd0 9d1 Ts4 Jc4",
            "win": -390,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 01:11:29",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338164853": [
        {
            "inFantasy": true,
            "result": 0,
            "playerName": "rajprateek1993",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qh0 Qs0 Ad0/9s0 Td0 Jh0 Kd0 Kc0/3c0 4s0 5d0 6s0 7c0",
            "win": -80,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "mumbaipajama",
            "orderIndex": 2,
            "hero": true,
            "dead": "6c1 As2 9c3 Jd4",
            "rows": "Qc1 Qd2 Js3/2c0 3s0 3d1 2d2 Tc3/4h0 6h0 8h0 5c4 7s4",
            "win": -80,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "Mickier",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ac0 Ah1 Jc3/2h0 Ks2 5s3 2s4 Kh4/8s0 9d0 Th0 7h1 6d2",
            "win": 160,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 01:14:05",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338164986": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "rajprateek1993",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kc3 Ac3 8d4/7h1 7d1 4d2 4c2 5c4/5s0 7s0 8s0 9s0 Js0",
            "win": -260,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": true,
            "result": 24,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Jd0 Jc0 Ks0/2c0 2s0 3h0 3c0 3s0/9h0 9c0 Qh0 Qc0 Qs0",
            "win": 260,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": false,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 01:14:51",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338165036": [
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "rajprateek1993",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qh0 8c4 Jd4/7c1 7s1 3c2 8s2 3s3/5d0 7d0 9d0 Td0 4d3",
            "win": 70,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": 57,
            "playerName": "mumbaipajama",
            "orderIndex": 0,
            "hero": true,
            "dead": "Tc1 Ts2 3d3 2h4",
            "rows": "Kd0 Qc1 Kh2/Ah0 Jc1 4h3 Kc4 Ks4/2s0 6h0 6s0 6d2 Qs3",
            "win": 170,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ad0 Qd2 8d4/2d0 4c0 5s3 Ac3 8h4/5h0 Th0 7h1 Jh1 9h2",
            "win": -240,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 01:17:19",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338165185": [
        {
            "inFantasy": false,
            "result": 57,
            "playerName": "rajprateek1993",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ah1 Js3 Qc4/4c0 6d0 5h2 6h3 5s4/8h0 8c0 Jd0 8d1 8s2",
            "win": -270,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": true,
            "result": 75,
            "playerName": "mumbaipajama",
            "orderIndex": 2,
            "hero": true,
            "dead": "4s0 Ad0",
            "rows": "7h0 7d0 7s0/2d0 3d0 4h0 5c0 6s0/2c0 3c0 7c0 9c0 Jc0",
            "win": 210,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 48,
            "playerName": "Mickier",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qh0 Qd1 3h4/9h0 9s1 As2 Kd3 Kc3/3s0 Tc0 Ts0 Td2 Th4",
            "win": 60,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 01:19:48",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338165324": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "rajprateek1993",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qh3 Kc3 Td4/4h1 4c1 2h2 2d2 As4/7h0 8s0 9s0 Th0 Jd0",
            "win": -90,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": true,
            "result": 48,
            "playerName": "mumbaipajama",
            "orderIndex": 1,
            "hero": true,
            "dead": "2s0",
            "rows": "Jc0 Qd0 Qs0/3d0 5c0 Tc0 Ad0 Ac0/4s0 5s0 6d0 7d0 8d0",
            "win": 100,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": true,
            "result": 15,
            "playerName": "Mickier",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "5h0 9d0 Qc0/2c0 7s0 Ts0 Kd0 Ks0/6h0 6c0 6s0 8h0 8c0",
            "win": -10,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 01:20:56",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338165389": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "rajprateek1993",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ah0 Ks2 Ac2/2h0 3d0 5c0 5h1 3h3/Ts0 9h1 Qh3 2s4 Qd4",
            "win": -270,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": 39,
            "playerName": "mumbaipajama",
            "orderIndex": 0,
            "hero": true,
            "dead": "2c1 Kh2 6c3 7d4",
            "rows": "9c1 Tc3 Td4/5d0 Jc0 6h1 Js2 8h4/3s0 6s0 7s0 Qs2 8s3",
            "win": 170,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qc2 2d4 Jh4/4s0 5s0 4c1 Th2 4h3/Jd0 Kd0 Ad0 6d1 9d3",
            "win": 100,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 01:23:34",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338165527": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "rajprateek1993",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ah0 Kc1 As2/4d0 9h0 4c2 8h3 3c4/7c0 Jc0 7s1 Kh3 Qs4",
            "win": -220,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "mumbaipajama",
            "orderIndex": 2,
            "hero": true,
            "dead": "Js1 Ks2 8s3 6h4",
            "rows": "9s0 Ac1 3s4/2c0 8c1 2s2 Ts2 Ad4/6d0 Qd0 Kd0 3d3 7d3",
            "win": 90,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "Mickier",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "8d3 4h4 6c4/4s0 9c0 5s1 5d2 5c2/7h0 Th0 Jh0 5h1 3h3",
            "win": 130,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 01:26:25",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338165674": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "mumbaipajama",
            "orderIndex": 0,
            "hero": true,
            "dead": "Td1 5h2 8c3 Ad4",
            "rows": "Ah2 Jc3 As3/3d0 4c0 4s1 5d1 9c4/2d0 2c0 7h0 7s2 7d4",
            "win": -130,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qh0 Qc2 3c4/3h0 3s0 8h3 8s3 6d4/9d0 Th0 Kd1 Ks1 Kh2",
            "win": 130,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 01:28:09",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338165772": [
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "mumbaipajama",
            "orderIndex": 1,
            "hero": true,
            "dead": "6s1 4h2 4s3 6d4",
            "rows": "Ah1 Ac2 Kc3/3s0 7s0 3c2 Qd3 5d4/2d0 2c0 9d0 2s1 5h4",
            "win": -200,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "Mickier",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "9s0 Kh0 Ks0/2h0 5s0 Th0 Td0 Ts0/5c0 6c0 7c0 Jc0 Qc0",
            "win": 200,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 01:29:09",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338165840": [
        {
            "inFantasy": false,
            "result": -27,
            "playerName": "rajprateek1993",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "7c3 2h4 Jd4/4h0 6c0 9d0 9c1 9h2/7s0 Ts0 9s1 As2 3s3",
            "win": 50,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "mumbaipajama",
            "orderIndex": 1,
            "hero": true,
            "dead": "2s1 Th2 7h3 5c4",
            "rows": "Qc0 Ac3 3d4/Jh0 Kc0 Jc1 8d3 2d4/6s0 7d0 5d1 3h2 4d2",
            "win": -110,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Mickier",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qh0 Qs1 4c3/2c0 6d0 Ad2 Kh3 Ks4/5s0 8s0 8h1 5h2 4s4",
            "win": 60,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 01:31:54",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338166044": [
        {
            "inFantasy": false,
            "result": 48,
            "playerName": "rajprateek1993",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qc1 6h3 Qh4/8s0 Jc0 8h1 Tc2 Ts4/3d0 9d0 Ad0 2d2 5d3",
            "win": 160,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "mumbaipajama",
            "orderIndex": 0,
            "hero": true,
            "dead": "9s1 6d2 5c3 4s4",
            "rows": "Ah0 Kc1 7d4/2h0 2s0 Kd3 Ks3 6c4/9h0 Th0 7h1 8d2 Js2",
            "win": -150,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": true,
            "result": 15,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "4c0 9c0 Qs0/3h0 4d0 5h0 6s0 7s0/Td0 Jh0 Qd0 Kh0 Ac0",
            "win": -10,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 01:34:30",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338166253": [
        {
            "inFantasy": true,
            "result": 9,
            "playerName": "rajprateek1993",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Tc0 Ts0 As0/8d0 9h0 Jh0 Jd0 Qd0/2c0 3h0 4c0 5h0 6d0",
            "win": 30,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "mumbaipajama",
            "orderIndex": 2,
            "hero": true,
            "dead": "7s1 Kh2 2h3 7d4",
            "rows": "Qh0 Kd0 Qs1/Ah0 Ad2 Th3 Jc3 Qc4/5d0 5s0 6h1 5c2 9d4",
            "win": 50,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Mickier",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "9c2 9s2 Kc4/3d0 4d0 2d1 3s1 4s4/7h0 7c0 Td0 6c3 6s3",
            "win": -80,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 01:37:35",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338166462": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "rajprateek1993",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "9d0 Ks2 Qd3/3c0 Jc1 8c3 4c4 Tc4/5h0 Qh0 Ah0 Th1 4h2",
            "win": 120,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": true,
            "result": 9,
            "playerName": "mumbaipajama",
            "orderIndex": 1,
            "hero": true,
            "dead": "3d0",
            "rows": "2s0 Kh0 As0/6s0 7s0 8h0 9c0 Td0/2c0 7c0 Qc0 Kc0 Ac0",
            "win": 70,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "Mickier",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Js2 Qs4 Ad4/2h0 3h0 3s1 9h2 2d3/4d0 6d0 8d0 Jd1 5d3",
            "win": -190,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 01:40:21",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338166652": [
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "rajprateek1993",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Jh2 Qh3 Th4/4s0 6h0 2h1 5h1 3s2/2c0 3c0 9c0 Tc3 Qc4",
            "win": -40,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "mumbaipajama",
            "orderIndex": 0,
            "hero": true,
            "dead": "9s1 4d2 Td3 4c4",
            "rows": "As0 3h2 7s4/6s0 8d0 5c1 8s3 Ah4/7h0 7c0 2d1 7d2 2s3",
            "win": -80,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 54,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kh0 Ks3 Jc4/6c0 8c0 4h1 8h1 6d4/9d0 Jd0 Qd2 Ad2 3d3",
            "win": 120,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 01:43:00",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338166818": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "rajprateek1993",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qc3 Kc3 4d4/2h0 3h0 4c0 2s1 4s1/9d0 Jc0 3d2 3c2 7d4",
            "win": -140,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "mumbaipajama",
            "orderIndex": 2,
            "hero": true,
            "dead": "As1 3s2 Jd3 Ac4",
            "rows": "Qd0 Ah2 Qs3/6s0 6d1 6c2 Ks3 Js4/5h0 5c0 Th0 Ts1 4h4",
            "win": -140,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": true,
            "result": 12,
            "playerName": "Mickier",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "9s0 Jh0 Kh0/5s0 6h0 7c0 8h0 9c0/2d0 5d0 8d0 Kd0 Ad0",
            "win": 280,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 01:45:07",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338166935": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "rajprateek1993",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ac0 As0 6s4/3c0 7h0 4d1 3d2 2c4/Js0 Td1 Qs2 9h3 Kc3",
            "win": -220,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": 57,
            "playerName": "mumbaipajama",
            "orderIndex": 1,
            "hero": true,
            "dead": "5s1 6h2 3s3 5h4",
            "rows": "Kh0 Ks2 6d3/2s0 9c1 Th1 9d2 Tc3/8h0 8d0 Jh0 4h4 Jc4",
            "win": 210,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "Mickier",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qh1 Ts2 9s4/3h0 5d0 Ad2 4s3 Jd4/4c0 5c0 6c0 7c1 8s3",
            "win": 10,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 01:47:45",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338167086": [
        {
            "inFantasy": false,
            "result": 8,
            "playerName": "rajprateek1993",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ks0 Kh2 Kd4/4h0 4c0 6d0 6h1 2d3/9c0 8c1 Tc2 7s3 Ts4",
            "win": -280,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": true,
            "result": 45,
            "playerName": "mumbaipajama",
            "orderIndex": 0,
            "hero": true,
            "dead": "3c0 9s0",
            "rows": "Jc0 Js0 Qc0/6s0 7h0 8h0 9d0 Th0/5d0 7d0 8d0 Td0 Ad0",
            "win": 310,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 19,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Jd0 Qd2 9h3/4s0 2s2 As3 5c4 6c4/3h0 5h0 Ah0 2h1 Jh1",
            "win": -30,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 01:50:23",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338167224": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "rajprateek1993",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc0 As1 Kd4/3h0 5s0 8h0 8s1 5c3/Jc0 Tc2 Qd2 Jh3 5d4",
            "win": -190,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": 66,
            "playerName": "mumbaipajama",
            "orderIndex": 2,
            "hero": true,
            "dead": "2s1 3d2 7c3 6d4",
            "rows": "Ah2 Ac2 9s4/4c0 5h0 4s1 4d3 8c4/7h0 9d0 Ts0 8d1 6h3",
            "win": 380,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "Mickier",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qc0 Kh2 2c4/9h0 Ad0 9c1 Th3 Td3/7s0 Js0 6s1 Ks2 3c4",
            "win": -190,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 01:53:14",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338167418": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "rajprateek1993",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qc0 Ac2 Ks4/2d0 4c0 3h1 2c2 4d3/7d0 7c0 Td1 Jh3 7h4",
            "win": -310,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": true,
            "result": 39,
            "playerName": "mumbaipajama",
            "orderIndex": 1,
            "hero": true,
            "dead": "9h0 Jd0 Kc0",
            "rows": "Th0 Tc0 Ad0/2s0 4s0 7s0 Js0 As0/3d0 3c0 3s0 8d0 8c0",
            "win": 350,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "Mickier",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kh1 Ts2 Qs3/2h0 Jc0 5d2 Ah3 8h4/6h0 6d0 6s0 8s1 6c4",
            "win": -40,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 01:55:44",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338167554": [
        {
            "inFantasy": false,
            "result": 36,
            "playerName": "rajprateek1993",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "3s2 Ac3 3c4/5d0 5c0 3d1 9d1 5s2/9h0 Qh0 Ah0 3h3 9c4",
            "win": -340,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "mumbaipajama",
            "orderIndex": 0,
            "hero": true,
            "dead": "9s1 7c2 2d3 Qd4",
            "rows": "Qs0 Kd2 Kh4/7h0 2h1 4c1 7d2 4h3/Td0 Jd0 Js0 Th3 6s4",
            "win": 80,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc1 Qc2 Ks4/Jc0 Ad0 As1 2s2 5h3/6d0 6c0 8s0 8d3 8h4",
            "win": 260,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 01:58:20",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338167695": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "rajprateek1993",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kd3 Ac3 Qh4/5h1 5d1 7d2 Kh2 4d4/6s0 8c0 8s0 Jd0 Js0",
            "win": -160,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": true,
            "result": 9,
            "playerName": "mumbaipajama",
            "orderIndex": 2,
            "hero": true,
            "dead": "2d0 4c0",
            "rows": "3h0 3c0 3s0/6h0 6d0 6c0 7c0 Kc0/7s0 8d0 9s0 Th0 Jh0",
            "win": 10,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": true,
            "result": 33,
            "playerName": "Mickier",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ks0 Ah0 As0/5c0 5s0 7h0 9d0 9c0/4h0 4s0 Td0 Tc0 Ts0",
            "win": 150,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 01:59:38",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338167770": [
        {
            "inFantasy": true,
            "result": 3,
            "playerName": "mumbaipajama",
            "orderIndex": 0,
            "hero": true,
            "dead": "3h0",
            "rows": "Jd0 Qh0 Qd0/4d0 4s0 8s0 9d0 9s0/3c0 8c0 Tc0 Jc0 Ac0",
            "win": -110,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ah3 Ad3 Js4/Th1 Jh1 5h2 7h2 2h4/2c0 4c0 6c0 7c0 Qc0",
            "win": 110,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:00:25",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338167827": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "mumbaipajama",
            "orderIndex": 0,
            "hero": true,
            "dead": "7c1 6d2 Qc3 6c4",
            "rows": "Ac2 Kc3 Ah4/3s0 2d1 5c2 6h3 4h4/9h0 9s0 Qh0 Qd0 Qs1",
            "win": 40,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": true,
            "result": 9,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Td0 Ts0 Ad0/2s0 3h0 4c0 5s0 6s0/8h0 8c0 Kh0 Kd0 Ks0",
            "win": -40,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:01:15",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338167878": [
        {
            "inFantasy": true,
            "result": 33,
            "playerName": "mumbaipajama",
            "orderIndex": 1,
            "hero": true,
            "dead": "2d0 3h0 6s0",
            "rows": "8s0 Ah0 Ac0/8d0 9h0 Th0 Jd0 Qc0/7c0 7s0 Kh0 Kd0 Kc0",
            "win": 250,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "Mickier",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qs3 As3 4d4/9s1 Js1 5s2 7d2 3s4/2c0 6c0 8c0 9c0 Jc0",
            "win": -250,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:02:12",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338167940": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "mumbaipajama",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qc1 4d2 4c3 5s4",
            "rows": "Qs0 Ks0 Kh1/Ah0 Ac0 6d3 Qd3 5h4/7c0 8s1 7s2 8d2 3c4",
            "win": -130,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kd0 Ad0 As2/2s0 2c1 5c2 2h4 Jd4/9h0 Qh0 4h1 6h3 Th3",
            "win": 130,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:03:50",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338168044": [
        {
            "inFantasy": true,
            "result": 27,
            "playerName": "mumbaipajama",
            "orderIndex": 1,
            "hero": true,
            "dead": "2s0 5s0",
            "rows": "7c0 Th0 Js0/4d0 Jd0 Qd0 Kd0 Ad0/8h0 8c0 8s0 9d0 9c0",
            "win": -10,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": true,
            "result": 33,
            "playerName": "Mickier",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "2h0 2d0 2c0/3h0 3d0 3c0 6d0 7d0/4s0 7s0 9s0 Qs0 As0",
            "win": 10,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:04:47",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338168095": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "mumbaipajama",
            "orderIndex": 0,
            "hero": true,
            "dead": "2s1 4h2 Qc3 4c4",
            "rows": "Qs0 Kh1 Kd2/3d0 5s0 5c1 8h3 3c4/9h0 9c0 Js2 Jd3 Qh4",
            "win": -20,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qd0 Ah0 Ac0/3h0 3s0 6d0 6s0 7c0/2h0 5h0 5d0 8d0 8s0",
            "win": 20,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:05:34",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338168148": [
        {
            "inFantasy": true,
            "result": -3,
            "playerName": "mumbaipajama",
            "orderIndex": 1,
            "hero": true,
            "dead": "3h0 5d0",
            "rows": "5h0 Kh0 Ks0/8c0 9h0 Ts0 Jh0 Qc0/2s0 4s0 6s0 8s0 Js0",
            "win": -130,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "Mickier",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ah3 As3 Kd4/8d1 Qd1 3d2 4d2 2d4/7h0 7c0 7s0 9d0 9c0",
            "win": 130,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:06:19",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338168199": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "mumbaipajama",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ts1 6d2 5d3 Jc4",
            "rows": "As0 Ah2 Kh4/2h0 2c1 2s3 Tc3 Ac4/3d0 8d0 Td0 9d1 Qd2",
            "win": -10,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": true,
            "result": -9,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qh0 Qc0 Kd0/3c0 4c0 5c0 6c0 7d0/4s0 6s0 7s0 Js0 Ks0",
            "win": 10,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:07:17",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338168273": [
        {
            "inFantasy": true,
            "result": 24,
            "playerName": "mumbaipajama",
            "orderIndex": 1,
            "hero": true,
            "dead": "Th0 Ts0 Qs0",
            "rows": "Jh0 Js0 As0/2s0 3c0 4h0 5h0 6h0/2d0 3d0 8d0 9d0 Qd0",
            "win": 200,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "Mickier",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "9s3 Kh3 6s4/3h1 4s1 5d2 6d2 7d4/8c0 8s0 9c0 Tc0 Ac0",
            "win": -200,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:08:12",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338168335": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "mumbaipajama",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jc1 3c2 3s3 6s4",
            "rows": "3d3 5h3 7h4/2d0 8c0 4c1 2h2 9s4/7s0 Qs0 Ks0 Ts1 4s2",
            "win": 30,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc1 As3 8d4/2c0 6h0 9c1 2s2 Tc4/Th0 Td0 Js0 Jh2 4d3",
            "win": -30,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:10:21",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338168500": [
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "mumbaipajama",
            "orderIndex": 1,
            "hero": true,
            "dead": "6c1 Ah2 2c3 Ks4",
            "rows": "Kd0 Kc1 8s4/3c0 5s0 4d1 3d2 4h3/7h0 7s0 Qh2 Jc3 Jd4",
            "win": 140,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "Mickier",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ad1 8h3 Ac3/2h0 5h0 6h1 5d2 2d4/2s0 4s0 6s0 3s2 Td4",
            "win": -140,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:12:06",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338168643": [
        {
            "inFantasy": true,
            "result": 9,
            "playerName": "mumbaipajama",
            "orderIndex": 0,
            "hero": true,
            "dead": "3h0 7c0",
            "rows": "6h0 6s0 Td0/2h0 2c0 4h0 4s0 Js0/3d0 4d0 5d0 6d0 7d0",
            "win": 220,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qh3 Qs3 9c4/9h1 9d1 9s2 As2 Tc4/8d0 8s0 Th0 Jd0 Jc0",
            "win": -220,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:12:51",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338168698": [
        {
            "inFantasy": true,
            "result": 15,
            "playerName": "mumbaipajama",
            "orderIndex": 1,
            "hero": true,
            "dead": "2c0",
            "rows": "6s0 8h0 8c0/5s0 9h0 9c0 Jc0 Qs0/2d0 5d0 6d0 7d0 Ad0",
            "win": -70,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "Mickier",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ah3 Ac3 Kc4/4d1 4c1 4h2 9s2 2s4/6h0 7c0 8d0 9d0 Ts0",
            "win": 70,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:13:38",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338168774": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "mumbaipajama",
            "orderIndex": 0,
            "hero": true,
            "dead": "3h1 7h2 2s3 Qd4",
            "rows": "Ah1 As2 Jd4/2c0 5d0 4h1 2d3 5h3/8h0 8c0 Th0 Ks2 3c4",
            "win": -210,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": true,
            "result": 27,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Jh0 Kh0 Kc0/6h0 6d0 6s0 Qh0 Qs0/4d0 4c0 9d0 9c0 9s0",
            "win": 210,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:14:30",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338168859": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "mumbaipajama",
            "orderIndex": 1,
            "hero": true,
            "dead": "6c1 3s2 3h3 Td4",
            "rows": "Ad0 6s4 Kd4/3c0 4d0 5s1 3d2 5d3/Jc0 Qh0 8h1 8s2 Js3",
            "win": -90,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "Mickier",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ks0 Kh1 5h4/2s0 9c1 4c2 4s2 2d3/7d0 7c0 7s0 Tc3 9h4",
            "win": 90,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:16:28",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338169032": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "mumbaipajama",
            "orderIndex": 0,
            "hero": true,
            "dead": "6s1 2d2 3c3 3d4",
            "rows": "Kd0 7c3 6h4/5h0 5c0 9c1 3h2 9d2/8h0 Ts0 Tc1 4c3 Th4",
            "win": -230,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": true,
            "result": 33,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Jc0 Ah0 Ad0/3s0 4h0 5s0 6c0 7s0/4d0 5d0 6d0 Td0 Qd0",
            "win": 230,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:17:30",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338169132": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "mumbaipajama",
            "orderIndex": 1,
            "hero": true,
            "dead": "4c1 2d2 8h3 Jh4",
            "rows": "Ks2 As2 Td4/8c0 9c0 6c1 Kc3 4h4/7d0 7s0 Ts0 7c1 Th3",
            "win": -60,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Mickier",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kd0 Ah2 Qh4/2c0 6s0 2h1 6d1 3h3/4d0 4s0 9d2 9s3 5s4",
            "win": 60,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:19:22",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338169306": [
        {
            "inFantasy": false,
            "result": 48,
            "playerName": "rajprateek1993",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Ac2 Ks4/6s0 7s0 7c1 Ad3 As3/4h0 4s0 Js1 4d2 Jd4",
            "win": 360,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "mumbaipajama",
            "orderIndex": 1,
            "hero": true,
            "dead": "Th1 5s2 7d3 Kd4",
            "rows": "2h3 9c3 9h4/2c0 3c0 2d1 5c1 5h4/6h0 6c0 9s0 8h2 8d2",
            "win": -60,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "Mickier",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kh0 Qh2 Qs3/7h0 Tc1 Ts1 Jc2 Jh3/6d0 Td0 Qd0 Qc4 Ah4",
            "win": -300,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:22:03",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338169540": [
        {
            "inFantasy": true,
            "result": 60,
            "playerName": "rajprateek1993",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Js0 Ad0 Ac0/7h0 7c0 8c0 Qh0 Qs0/3d0 4d0 5d0 8d0 9d0",
            "win": 200,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "mumbaipajama",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qc1 Jd2 Td3 2d4",
            "rows": "Ks0 8s4 9h4/5s0 4c1 7s1 7d2 5h3/4h0 8h0 Th0 Ah2 3h3",
            "win": 0,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kd0 Kc2 6s4/2h0 3s1 9c1 As3 6d4/Jh0 Jc0 Qd0 6h2 6c3",
            "win": -200,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:25:19",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338169819": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "rajprateek1993",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ah2 Td3 Kd4/3s0 5h0 5d1 4s3 Qs4/7s0 8c0 9h0 Th1 6s2",
            "win": 20,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "mumbaipajama",
            "orderIndex": 2,
            "hero": true,
            "dead": "2d1 4c2 4h3 Jh4",
            "rows": "Ts1 7h4 7c4/5c0 Jd0 Qc1 Ks2 Kh3/2h0 3h0 8h0 3c2 2s3",
            "win": 40,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "Mickier",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qh0 Kc3 7d4/4d0 6h2 As2 8d3 6d4/2c0 9d0 9s0 Jc1 Js1",
            "win": -60,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:28:04",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338170088": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "rajprateek1993",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qc0 Qs3 4d4/2h0 4h0 Ks2 2d3 Kc4/Td0 Js0 Th1 Jc1 Ts2",
            "win": 220,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "mumbaipajama",
            "orderIndex": 1,
            "hero": true,
            "dead": "6d1 5h2 7d3 6s4",
            "rows": "6h1 Qh2 Qd4/5s0 8s1 8d2 5d3 7c4/4c0 5c0 Tc0 Ac0 8c3",
            "win": 140,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "Mickier",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ah0 Ad0 9d3/6c0 7h0 9h2 9s2 2s4/Jd0 3h1 3s1 Jh3 2c4",
            "win": -360,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:30:44",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338170355": [
        {
            "inFantasy": true,
            "result": 12,
            "playerName": "rajprateek1993",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qc0 Kh0 Kc0/3c0 6d0 Th0 Td0 Ts0/4h0 5h0 6s0 7c0 8d0",
            "win": 100,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": true,
            "result": 24,
            "playerName": "mumbaipajama",
            "orderIndex": 0,
            "hero": true,
            "dead": "4c0",
            "rows": "Jc0 Js0 Qh0/7d0 7s0 8h0 9h0 9c0/2c0 3s0 4d0 5c0 Ac0",
            "win": 40,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ad3 As3 Tc4/6h1 8c1 3h2 4s2 2h4/3d0 5d0 Jd0 Qd0 Kd0",
            "win": -140,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:32:20",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338170553": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "rajprateek1993",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc2 As3 Td4/3d0 8d0 3s1 Jd3 6c4/Th0 Jh0 Ah0 8h1 9h2",
            "win": 20,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "mumbaipajama",
            "orderIndex": 2,
            "hero": true,
            "dead": "4d1 3c2 3h3 4s4",
            "rows": "Kd2 Js3 4h4/9s0 5d1 8s2 5s3 Kh4/6d0 6s0 Qh0 Qs0 Qc1",
            "win": 80,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "Mickier",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ks0 Qd2 2h4/9d0 Ts0 Ad1 Tc2 5c3/6h0 7h0 7d1 4c3 7s4",
            "win": -100,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:34:46",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338170794": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "rajprateek1993",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qc1 6c2 Js4/5s0 7s0 As1 Ks3 4h4/2h0 6h0 Ah0 Th2 7h3",
            "win": -40,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "mumbaipajama",
            "orderIndex": 1,
            "hero": true,
            "dead": "Ad1 7d2 8h3 6s4",
            "rows": "8s1 9h3 Jh3/3d0 5d0 4d2 4c4 Kh4/5c0 7c0 Ac0 2c1 8c2",
            "win": -60,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 54,
            "playerName": "Mickier",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kc0 3h3 Kd3/3c0 3s0 Jd2 Jc2 2s4/4s0 Qs0 Qh1 Qd1 Tc4",
            "win": 100,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:37:39",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338171052": [
        {
            "inFantasy": false,
            "result": 33,
            "playerName": "rajprateek1993",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "8c3 Qh3 Qs4/2s0 3d0 6s0 5s2 4h4/9h0 Th0 Td1 Tc1 9c2",
            "win": 270,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "mumbaipajama",
            "orderIndex": 0,
            "hero": true,
            "dead": "4d1 5c2 Ks3 Qd4",
            "rows": "Kh1 Kd2 9s3/7s0 5d1 7h2 Ad3 7d4/2d0 2c0 3h0 3c0 6c4",
            "win": -430,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": true,
            "result": 24,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Jh0 Jd0 Qc0/4c0 5h0 6h0 7c0 8d0/3s0 4s0 8s0 Ts0 As0",
            "win": 160,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:39:40",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338171199": [
        {
            "inFantasy": true,
            "result": 36,
            "playerName": "rajprateek1993",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kd0 Ac0 As0/7c0 8c0 8s0 Td0 Ts0/4h0 5h0 6h0 7h0 Kh0",
            "win": 170,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "mumbaipajama",
            "orderIndex": 2,
            "hero": true,
            "dead": "Js1 8d2 5d3 6s4",
            "rows": "Ad0 Ah2 9h4/3c0 4c0 3s2 4d3 3h4/6d0 6c0 Qh1 Qd1 Qs3",
            "win": 30,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "Mickier",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Jc2 Jd3 2c4/5c0 7d0 7s1 9s2 9d3/8h0 Th0 Jh0 2h1 3d4",
            "win": -200,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:41:49",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338171348": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "rajprateek1993",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kh0 Kd0 6s4/As0 7h1 5d2 Kc3 Ks3/9c0 Qd0 8c1 Qs2 Ac4",
            "win": -100,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": true,
            "result": 36,
            "playerName": "mumbaipajama",
            "orderIndex": 1,
            "hero": true,
            "dead": "3d0 Tc0 Ad0",
            "rows": "Jd0 Jc0 Js0/4c0 5s0 6c0 7d0 8d0/5h0 8h0 9h0 Th0 Ah0",
            "win": 120,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "Mickier",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qh0 5c3 Jh3/3c0 6h0 3h1 2h2 2s4/4d0 Td0 9d1 Ts2 9s4",
            "win": -20,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:44:07",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338171512": [
        {
            "inFantasy": false,
            "result": 42,
            "playerName": "rajprateek1993",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Ks0 Qh2/5s0 7d0 4c1 4s3 Jc4/Th0 9c1 Td2 9d3 2d4",
            "win": -300,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": true,
            "result": 102,
            "playerName": "mumbaipajama",
            "orderIndex": 0,
            "hero": true,
            "dead": "9h0",
            "rows": "8h0 8d0 8s0/2h0 3d0 4h0 5c0 6h0/3s0 6s0 Js0 Qs0 As0",
            "win": 460,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 42,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ah0 Ad1 7s3/2c0 9s1 Jd2 6d4 7c4/3c0 Qd0 Qc0 3h2 5h3",
            "win": -160,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:46:42",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338171691": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "rajprateek1993",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qs0 Ad1 9s3/7d0 9h1 3s2 7s2 Kd3/6c0 Tc0 Jc0 8h4 Th4",
            "win": -40,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": true,
            "result": 12,
            "playerName": "mumbaipajama",
            "orderIndex": 2,
            "hero": true,
            "dead": "6h0",
            "rows": "Js0 Qh0 As0/2h0 4h0 9d0 Td0 Ts0/5c0 8c0 9c0 Qc0 Kc0",
            "win": 200,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "Mickier",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kh0 Ks0 Ac3/4c0 5h1 4d2 2c3 2s4/8d0 Jh0 Qd1 8s2 6d4",
            "win": -160,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:49:18",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338171879": [
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "rajprateek1993",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ad0 Kc2 7h4/Td0 9h2 3c3 9d3 5s4/2c0 6c0 7c0 8c1 Jc1",
            "win": 40,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "mumbaipajama",
            "orderIndex": 1,
            "hero": true,
            "dead": "4h1 7d2 9c3 Qd4",
            "rows": "Ac0 Qh2 Qc2/3d0 4c0 Tc3 7s4 Jd4/Th0 Js0 9s1 Qs1 Kh3",
            "win": -250,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 63,
            "playerName": "Mickier",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ah0 As0 Jh1/2h0 2s0 5h2 5d2 Ks3/8h0 8s1 6s3 3h4 8d4",
            "win": 210,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:51:55",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338172062": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "rajprateek1993",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Js3 5h4 5s4/7d0 4s1 7c2 7s2 6s3/3c0 8c0 Jc0 Ac0 2c1",
            "win": -130,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "mumbaipajama",
            "orderIndex": 0,
            "hero": true,
            "dead": "6c1 4c2 Qc3 8d4",
            "rows": "Kh2 Kc2 Qs4/Tc0 9c1 9s3 Ah3 Ad4/3d0 6d0 Jd0 Qd0 5d1",
            "win": 30,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": true,
            "result": -30,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "3h0 3s0 8s0/4h0 4d0 9d0 Td0 As0/8h0 9h0 Th0 Jh0 Qh0",
            "win": 100,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:54:11",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338172205": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "rajprateek1993",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kh3 Kc3 Th4/3h1 3d1 3s2 7s2 4h4/4d0 7d0 9d0 Td0 Kd0",
            "win": 40,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": true,
            "result": 3,
            "playerName": "mumbaipajama",
            "orderIndex": 2,
            "hero": true,
            "dead": "2h0 Js0",
            "rows": "Qd0 Ad0 As0/4s0 5d0 6s0 7h0 8d0/8c0 9s0 Tc0 Jc0 Qc0",
            "win": 90,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": true,
            "result": 3,
            "playerName": "Mickier",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ks0 Ah0 Ac0/5h0 5c0 8s0 Jh0 Jd0/2c0 6h0 6d0 Qh0 Qs0",
            "win": -130,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:55:19",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338172274": [
        {
            "inFantasy": true,
            "result": 12,
            "playerName": "rajprateek1993",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "7d0 Td0 Ad0/3h0 6h0 9h0 Th0 Jh0/2d0 2c0 2s0 5d0 5c0",
            "win": 360,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "mumbaipajama",
            "orderIndex": 1,
            "hero": true,
            "dead": "4d1 Js2 7h3 Ac4",
            "rows": "Qd0 Qc1 8d3/As0 7s2 Kh2 6s3 Kc4/3c0 4c0 9c0 4h1 6d4",
            "win": -300,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "Mickier",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "3d3 Tc3 Qh4/7c0 8c0 9d1 5h2 9s4/5s0 Qs0 Ks0 Ts1 8s2",
            "win": -60,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:57:58",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338172418": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "rajprateek1993",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ah0 Ts2 As3/2c0 7h0 3h1 2h2 5s4/6s0 Qs0 9h1 9d3 Jh4",
            "win": -140,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "mumbaipajama",
            "orderIndex": 0,
            "hero": true,
            "dead": "3c1 3d2 9s3 Th4",
            "rows": "Kh0 Qd3 7c4/4s0 5c0 5d1 6c2 Kd4/8s0 Jd0 9c1 Tc2 Qh3",
            "win": 90,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc1 Ad1 7s4/3s0 6h0 4h2 6d3 Qc4/8c0 Td0 Jc0 7d2 Js3",
            "win": 50,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 03:00:50",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338172593": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "rajprateek1993",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "2d2 Th4 Jd4/3d0 6c0 3h1 Ts1 6s2/8h0 Jh0 Jc0 8c3 Js3",
            "win": 120,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "mumbaipajama",
            "orderIndex": 2,
            "hero": true,
            "dead": "3s1 3c2 5h3 7s4",
            "rows": "Ah0 Ac3 5s4/2s1 Ks1 9h2 Kh3 4d4/5d0 6d0 9d0 Qd0 Td2",
            "win": -250,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 51,
            "playerName": "Mickier",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qh0 Qc1 5c4/Ad0 As0 8s1 9s3 Qs4/4s0 7d0 Kd2 Kc2 7h3",
            "win": 130,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 03:03:03",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338172781": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "rajprateek1993",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ah0 Ad0 Jh2/4s0 6h0 6d1 Qc4 Ac4/7c0 5c1 6c2 8c3 9d3",
            "win": -240,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "mumbaipajama",
            "orderIndex": 1,
            "hero": true,
            "dead": "3s1 3h2 9h3 3c4",
            "rows": "Th3 Kc3 4c4/Js0 2h1 Jd1 8s2 8h4/3d0 4d0 7d0 Qd0 Kd2",
            "win": 0,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": true,
            "result": 12,
            "playerName": "Mickier",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "2d0 2c0 5s0/9c0 Td0 Jc0 Qh0 Kh0/6s0 7s0 9s0 Qs0 As0",
            "win": 240,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 03:05:18",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338172965": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "rajprateek1993",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kd1 2h2 2d3/6c0 7s0 9c0 9d2 Ac3/Ts0 Jd0 Td1 3h4 Th4",
            "win": -190,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "mumbaipajama",
            "orderIndex": 0,
            "hero": true,
            "dead": "8c1 Ad2 6h3 Tc4",
            "rows": "Kc0 Ah3 Jh4/6s0 7h0 5d1 6d2 5h3/3d0 3s0 Qc1 Qs2 4d4",
            "win": -210,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 60,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ks0 Qh3 Kh4/4h0 7d0 7c1 2c2 4s4/8h0 8d0 9s1 9h2 8s3",
            "win": 400,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 03:08:03",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338173213": [
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "rajprateek1993",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Jh2 9d3/4d0 5c0 6d1 3h2 3d3/2s0 6s0 3s1 9s4 Ah4",
            "win": -180,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "mumbaipajama",
            "orderIndex": 2,
            "hero": true,
            "dead": "8c1 9c2 2c3 Jc4",
            "rows": "Ac0 As2 5h3/4s0 7d0 Ts1 7s2 8s4/Jd0 Qd0 Js1 Qc3 3c4",
            "win": -180,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": true,
            "result": 60,
            "playerName": "Mickier",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qs0 Kh0 Ks0/2h0 2d0 5d0 5s0 Ad0/4h0 6h0 9h0 Th0 Qh0",
            "win": 360,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 03:10:21",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338173409": [
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "rajprateek1993",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kc0 7c3 Qc4/6h0 9h1 Ah1 2d3 Jc4/3d0 4d0 5d0 4c2 5h2",
            "win": -350,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "mumbaipajama",
            "orderIndex": 1,
            "hero": true,
            "dead": "6d1 5s2 4h3 6s4",
            "rows": "Jd1 Td2 Ts4/7d0 9c0 2h1 7h3 9d4/8h0 8d0 Qd0 Qh2 Qs3",
            "win": 150,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 42,
            "playerName": "Mickier",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kh0 Kd3 4s4/6c0 Ad0 Th1 Tc2 As3/3s0 9s0 Ks1 Js2 8s4",
            "win": 200,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 03:13:21",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338173644": [
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "rajprateek1993",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Ad0 Ah3/2c0 4d1 6s2 4c3 Ks4/7h0 Qh0 7c1 9h2 7d4",
            "win": -150,
            "playerId": "rajprateek1993"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "mumbaipajama",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ts1 Qd2 9s3 Jd4",
            "rows": "4h3 8c3 4s4/2h0 5d0 As1 5s2 5h4/6c0 9c0 Ac0 Tc1 3c2",
            "win": 30,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": true,
            "result": 0,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "6h0 7s0 Qs0/2d0 3d0 6d0 Td0 Kd0/8h0 8d0 8s0 Jh0 Jc0",
            "win": 120,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 03:15:43",
    "roomId": "41b-1cff2ad9"
}


