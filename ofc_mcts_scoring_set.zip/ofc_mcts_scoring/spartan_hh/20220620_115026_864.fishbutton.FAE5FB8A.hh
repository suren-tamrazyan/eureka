{
    "stakes": 10,
    "handData": {"338216553": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "Kainyu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qd0 Kh2 4s4/7h0 9c1 7s2 6c3 Qs4/2s0 6s0 Js0 8s1 Ks3",
            "win": -60,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "fishbutton",
            "orderIndex": 1,
            "hero": true,
            "dead": "Th1 Kc2 7d3 2c4",
            "rows": "As0 Qh3 7c4/Jc0 Jh1 5h2 9h3 Ah4/3d0 6d0 Ad0 8d1 Kd2",
            "win": 60,
            "playerId": "fishbutton"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:50:26",
    "roomId": "41b-1d7eb2e9"
}


{
    "stakes": 10,
    "handData": {"338216829": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "Kainyu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ah0 Ad3 3d4/5c0 Th0 2h1 2s2 5d2/8d0 Qd0 Qh1 8c3 Ac4",
            "win": 40,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "fishbutton",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ts1 2c2 3h3 4h4",
            "rows": "Jd1 Jc2 8s3/4c0 5h0 5s1 7s2 7d4/6h0 6c0 9d0 As3 9s4",
            "win": -40,
            "playerId": "fishbutton"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:52:22",
    "roomId": "41b-1d7eb2e9"
}


{
    "stakes": 10,
    "handData": {"338217149": [
        {
            "inFantasy": true,
            "result": 27,
            "playerName": "Kainyu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kh0 Ks0 Ah0/4d0 5c0 6d0 7s0 8d0/9c0 Tc0 Jc0 Qc0 Ac0",
            "win": 50,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "fishbutton",
            "orderIndex": 1,
            "hero": true,
            "dead": "Td1 Ad2 2s3 2d4",
            "rows": "Kd0 4s4 8s4/2h0 7h1 Qh1 4h3 5h3/6s0 9s0 Qs0 5s2 Ts2",
            "win": -50,
            "playerId": "fishbutton"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:53:27",
    "roomId": "41b-1d7eb2e9"
}


{
    "stakes": 10,
    "handData": {"338217335": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "Kainyu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kd2 Kc2 Jd3/2s0 3h0 3c1 Qc3 9h4/5c0 6d0 8s0 9s1 5s4",
            "win": -170,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "fishbutton",
            "orderIndex": 0,
            "hero": true,
            "dead": "7d1 Th2 Ad3 3d4",
            "rows": "Qd2 5d4 Qh4/3s0 6s0 6c1 Td3 Tc3/2h0 4h0 8h0 5h1 Jh2",
            "win": 170,
            "playerId": "fishbutton"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:55:05",
    "roomId": "41b-1d7eb2e9"
}


{
    "stakes": 10,
    "handData": {"338217616": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "Kainyu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "8h3 Ad3 6s4/Tc1 Ts1 8c2 8s2 7c4/3h0 4h0 6h0 7h0 Th0",
            "win": -110,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": true,
            "result": 27,
            "playerName": "fishbutton",
            "orderIndex": 1,
            "hero": true,
            "dead": "2d0",
            "rows": "Qh0 Kd0 Ks0/4s0 5d0 5c0 9c0 9s0/3d0 3c0 Jh0 Jd0 Js0",
            "win": 110,
            "playerId": "fishbutton"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:56:01",
    "roomId": "41b-1d7eb2e9"
}


{
    "stakes": 10,
    "handData": {"338217747": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "Kainyu",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kh0 6s2 6d4/8h0 Jd0 As1 Ac3 Tc4/3c0 6c0 7c1 Jc2 Qc3",
            "win": 130,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "fishbutton",
            "orderIndex": 0,
            "hero": true,
            "dead": "Js1 Qd2 9s3 Ah4",
            "rows": "Jh0 Kd2 Ks2/2c0 5s0 2d1 2s3 Qs4/7d0 8d0 8s1 7s3 4d4",
            "win": -210,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "vivloc",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ad3 8c4 Ts4/3d0 3s1 5c1 5d2 Td3/2h0 3h0 9h0 Th0 Qh2",
            "win": 80,
            "playerId": "vivloc"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:59:25",
    "roomId": "41b-1d7eb2e9"
}


{
    "stakes": 10,
    "handData": {"338218206": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "Kainyu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "8c3 Kc3 Ad4/6c0 8d0 5d1 5s1 6h2/2s0 Jh0 Js0 9s2 9h4",
            "win": -20,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "fishbutton",
            "orderIndex": 2,
            "hero": true,
            "dead": "Tc1 As2 Td3 5h4",
            "rows": "Qh0 Ah2 Kd4/7d0 Kh0 3s3 7s3 3c4/3d0 5c0 2h1 Ac1 4c2",
            "win": 160,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "vivloc",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qc1 3h3 Jc3/7c0 8s0 Th1 Ts2 4h4/6d0 Jd0 Qd0 2d2 9c4",
            "win": -140,
            "playerId": "vivloc"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:01:46",
    "roomId": "41b-1d7eb2e9"
}


{
    "stakes": 10,
    "handData": {"338218615": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "Kainyu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ah2 8s3 7h4/4c0 5h1 5c2 4d3 4s4/7d0 8d0 Td0 Jd0 9d1",
            "win": 620,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "fishbutton",
            "orderIndex": 1,
            "hero": true,
            "dead": "Ts1 6c2 Qs3 Ad4",
            "rows": "Kh0 Kd0 Ac3/2d0 3h1 Js2 Jc3 Qc4/6s0 7c0 5d1 9s2 Jh4",
            "win": -430,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "vivloc",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kc0 8h3 Qd4/3s0 2s1 5s2 3d3 Th4/6h0 9h0 Qh0 2h1 4h2",
            "win": -190,
            "playerId": "vivloc"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:04:34",
    "roomId": "41b-1d7eb2e9"
}


{
    "stakes": 10,
    "handData": {"338219152": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "Kainyu",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qh0 Jc2 3h3/Ah0 8h1 9h1 9c2 Ad4/4d0 6d0 7d0 Kd3 5d4",
            "win": -20,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "fishbutton",
            "orderIndex": 0,
            "hero": true,
            "dead": "7c1 7s2 Ts3 6h4",
            "rows": "9d2 Ac3 Jd4/Qd0 Qs0 3s2 3c3 Tc4/7h0 Jh0 Kh0 2h1 Th1",
            "win": 20,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "vivloc",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qc0 Kc3 8d4/2d0 5h0 2c1 5s2 Td3/4s0 Js0 Ks1 8s2 As4",
            "win": 0,
            "playerId": "vivloc"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:08:31",
    "roomId": "41b-1d7eb2e9"
}


{
    "stakes": 10,
    "handData": {"338219875": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "Kainyu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ks0 Kd2 Qd3/4d0 6s0 6d1 3s4 Jd4/3h0 7h0 Jh1 8h2 9h3",
            "win": -370,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "fishbutton",
            "orderIndex": 2,
            "hero": true,
            "dead": "2h1 Jc2 9c3 9s4",
            "rows": "Qc2 8d4 Ad4/8s0 Ts0 Th1 2s3 8c3/3d0 7d0 Td0 2d1 9d2",
            "win": -130,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": false,
            "result": 66,
            "playerName": "vivloc",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ah0 6h3 Ac4/3c0 7c0 5c1 2c2 Kc4/Js0 Qs0 4s1 5s2 As3",
            "win": 500,
            "playerId": "vivloc"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:13:00",
    "roomId": "41b-1d7eb2e9"
}


{
    "stakes": 10,
    "handData": {"338220690": [
        {
            "inFantasy": false,
            "result": 39,
            "playerName": "Kainyu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qs0 As1 Tc2/4h0 7s0 4c1 9c2 7h4/2d0 Jd0 3d3 6d3 9d4",
            "win": -130,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "fishbutton",
            "orderIndex": 1,
            "hero": true,
            "dead": "3c1 5s2 5c3 6h4",
            "rows": "Jc0 Qh2 Qd4/9h0 2h1 2s1 9s2 7d3/8d0 8s0 Td0 6s3 Ts4",
            "win": -140,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": true,
            "result": 39,
            "playerName": "vivloc",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Js0 Ad0 Ac0/4d0 5h0 6c0 7c0 8h0/3h0 3s0 Kh0 Kd0 Kc0",
            "win": 270,
            "playerId": "vivloc"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:16:33",
    "roomId": "41b-1d7eb2e9"
}


{
    "stakes": 10,
    "handData": {"338221354": [
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "fishbutton",
            "orderIndex": 0,
            "hero": true,
            "dead": "2c0",
            "rows": "Kc0 Ac0 As0/4s0 9s0 Qh0 Qc0 Qs0/3d0 4d0 6d0 7d0 Td0",
            "win": 120,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "vivloc",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "9c3 Ks3 8s4/5h1 5s1 4h2 4c2 3h4/2d0 5d0 8d0 9d0 Kd0",
            "win": -120,
            "playerId": "vivloc"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:17:25",
    "roomId": "41b-1d7eb2e9"
}


{
    "stakes": 10,
    "handData": {"338221509": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "fishbutton",
            "orderIndex": 1,
            "hero": true,
            "dead": "8s1 Jc2 Ac3 Kh4",
            "rows": "Ah0 As1 Kc2/3s0 7d0 7s2 2c3 9c4/4h0 Qh0 8h1 8d3 9h4",
            "win": 0,
            "playerId": "fishbutton"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "vivloc",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kd0 Ks0 7h4/5c0 6d0 3d3 6c3 Ts4/Qs0 Th1 Jh1 Tc2 Js2",
            "win": 0,
            "playerId": "vivloc"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:19:08",
    "roomId": "41b-1d7eb2e9"
}


