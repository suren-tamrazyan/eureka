{
    "stakes": 5,
    "handData": {"338196275": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "MTAAA",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qd2 Jh3 Ad4/6h0 7c0 Ks2 5d3 Kc4/4s0 Ts0 Js0 2s1 9s1",
            "win": 20,
            "playerId": "MTAAA"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Th1 As1 7s4/3d0 7d0 8c0 3s2 8d2/5h0 5s0 9d3 Qs3 Qh4",
            "win": -50,
            "playerId": "shubhamkumarjha75"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "fishbutton",
            "orderIndex": 1,
            "hero": true,
            "dead": "4c1 2d2 Jd3 4h4",
            "rows": "Ah0 Kh3 2h4/8h0 Td0 6c2 6s2 Kd4/Jc0 Qc0 9c1 Ac1 5c3",
            "win": 30,
            "playerId": "fishbutton"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 06:52:06",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338196468": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "MTAAA",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ts2 Qs3 3s4/3d0 8s0 7s1 Js2 Ah3/4c0 9c0 Jc0 Kc1 5c4",
            "win": 20,
            "playerId": "MTAAA"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qh1 Kd1 Ac3/4d0 4s0 8d0 2d2 9s4/Tc0 Jd0 7h2 9h3 8c4",
            "win": 10,
            "playerId": "shubhamkumarjha75"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "fishbutton",
            "orderIndex": 0,
            "hero": true,
            "dead": "6s1 3c2 Th3 3h4",
            "rows": "Kh0 Qd3 8h4/2s0 4h0 5d1 5h2 Jh3/7c0 9d0 7d1 6d2 Qc4",
            "win": -30,
            "playerId": "fishbutton"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 06:54:58",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338196742": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "MTAAA",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kh0 Kc2 4h4/2d0 5d0 Ac1 6d3 Ad3/9s0 Ts0 Jd1 8c2 9d4",
            "win": -30,
            "playerId": "MTAAA"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "As0 Kd1 Ks4/2s0 3d0 3c1 8s2 3h3/Td0 Qh0 9c2 Jc3 7h4",
            "win": -30,
            "playerId": "shubhamkumarjha75"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "fishbutton",
            "orderIndex": 2,
            "hero": true,
            "dead": "2c1 7d2 Qc3 2h4",
            "rows": "Ah0 9h3 Js4/6c0 6s1 7c1 8h3 7s4/Tc0 Jh0 Qd0 Th2 Qs2",
            "win": 60,
            "playerId": "fishbutton"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 06:57:38",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338196977": [
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "MTAAA",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "2c0 Kc3 2h4/8s0 5h1 5c2 Js3 9h4/4d0 7d0 Ad0 9d1 3d2",
            "win": 45,
            "playerId": "MTAAA"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ks0 Qs1 Ts4/Ah0 As0 4c1 4s2 4h3/8d0 8c0 8h2 Jh3 7s4",
            "win": -110,
            "playerId": "shubhamkumarjha75"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "fishbutton",
            "orderIndex": 1,
            "hero": true,
            "dead": "5s1 6h2 9s3 6d4",
            "rows": "Qh1 Kd2 Td4/3s0 7h0 3h1 Jd3 3c4/6c0 9c0 Jc0 Qc2 7c3",
            "win": 65,
            "playerId": "fishbutton"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:00:16",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338197208": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "MTAAA",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qh1 Jc2 Th3/3s0 6s0 9s2 3c3 Ac4/2d0 7d0 8d0 6d1 8s4",
            "win": -20,
            "playerId": "MTAAA"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ad1 Kd2 8c4/3h0 4h0 Jd1 Js2 5d4/7s0 Qs0 As0 2s3 5s3",
            "win": 100,
            "playerId": "shubhamkumarjha75"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "fishbutton",
            "orderIndex": 0,
            "hero": true,
            "dead": "9h1 5h2 Ts3 Ah4",
            "rows": "Qd0 Kh2 Qc3/2h0 4d0 3d1 4s2 2c3/8h0 9c0 7c1 4c4 Td4",
            "win": -80,
            "playerId": "fishbutton"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:02:29",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338197474": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "MTAAA",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ah2 7d3 Kd4/4c0 4s1 2h2 Ts3 Th4/9c0 9s0 Jc0 Js0 9d1",
            "win": 40,
            "playerId": "MTAAA"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Ks0 7c4/3h0 7s0 7h2 8s2 8d3/Qc0 6h1 6c1 As3 4h4",
            "win": -145,
            "playerId": "shubhamkumarjha75"
        },
        {
            "inFantasy": false,
            "result": 51,
            "playerName": "fishbutton",
            "orderIndex": 2,
            "hero": true,
            "dead": "9h1 Jh2 Ac3 4d4",
            "rows": "Kh0 Qs1 Qh2/2s0 Tc1 2d2 8c3 8h4/3d0 5d0 Qd0 Jd3 Ad4",
            "win": 105,
            "playerId": "fishbutton"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:04:58",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338197797": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "MTAAA",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kh1 Ac2 Js3/7c0 5c1 7h2 Th3 6h4/3d0 4d0 7d0 Qd0 2d4",
            "win": -60,
            "playerId": "MTAAA"
        },
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Jd3 8s4/4h0 8d0 Ad0 4c2 As3/Qs0 9d1 Qc1 9c2 Qh4",
            "win": 15,
            "playerId": "shubhamkumarjha75"
        },
        {
            "inFantasy": true,
            "result": 9,
            "playerName": "fishbutton",
            "orderIndex": 1,
            "hero": true,
            "dead": "9s0",
            "rows": "6d0 6s0 Ah0/3c0 8c0 Jh0 Jc0 Kd0/5h0 5d0 Td0 Tc0 Ts0",
            "win": 45,
            "playerId": "fishbutton"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:10:54",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338198559": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "Dularidevi",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "4d3 4c3 Qd4/Tc0 Jc0 7c1 3c2 Kc2/6h0 Jh0 Ah0 4h1 3h4",
            "win": 35,
            "playerId": "Dularidevi"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "fishbutton",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qc1 6c2 Ac3 9h4",
            "rows": "Ks1 Qh2 Js3/7d0 8d2 5d3 5c4 As4/2h0 2s0 9c0 9s0 2c1",
            "win": -35,
            "playerId": "fishbutton"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:12:45",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338198774": [
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "Dularidevi",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qh1 Jh2 5h4/8c0 Th0 3s1 Ah2 Ac4/4d0 5d0 Jd0 4c3 5s3",
            "win": -80,
            "playerId": "Dularidevi"
        },
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "fishbutton",
            "orderIndex": 1,
            "hero": true,
            "dead": "8s1 8d2 7d3 9c4",
            "rows": "Kd0 Kh1 Td4/As0 6d2 7h3 Ad3 Kc4/6c0 7s0 8h0 9d1 5c2",
            "win": 80,
            "playerId": "fishbutton"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:14:40",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338199033": [
        {
            "inFantasy": false,
            "result": 39,
            "playerName": "Dularidevi",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ah3 Ac3 As4/8h1 8c1 Jd2 Kd2 Tc4/3c0 4h0 5s0 6h0 7d0",
            "win": -155,
            "playerId": "Dularidevi"
        },
        {
            "inFantasy": true,
            "result": 51,
            "playerName": "fishbutton",
            "orderIndex": 0,
            "hero": true,
            "dead": "4d0 4s0",
            "rows": "7h0 7c0 7s0/Ts0 Js0 Qh0 Kh0 Ad0/2h0 2d0 2c0 9h0 9c0",
            "win": 155,
            "playerId": "fishbutton"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:15:42",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338199181": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "Dularidevi",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ks3 As3 Td4/4c1 4s1 3d2 3s2 6d4/7d0 7c0 8h0 Qh0 Qd0",
            "win": -15,
            "playerId": "Dularidevi"
        },
        {
            "inFantasy": true,
            "result": 9,
            "playerName": "fishbutton",
            "orderIndex": 1,
            "hero": true,
            "dead": "5s0",
            "rows": "7s0 Tc0 Ts0/5c0 6s0 7h0 8s0 9h0/3h0 3c0 Ah0 Ad0 Ac0",
            "win": 15,
            "playerId": "fishbutton"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:17:23",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338199424": [
        {
            "inFantasy": false,
            "result": 60,
            "playerName": "Mandy98",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kh1 7s2 Kd4/4h0 6s0 2h1 Ad3 As3/5h0 5s0 Tc0 Th2 Js4",
            "win": 140,
            "playerId": "Mandy98"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "3s2 6d2 Ks3/3h0 5c0 8h0 Ac1 7d4/9c0 Qs0 Jh1 9s3 6h4",
            "win": -40,
            "playerId": "shubhamkumarjha75"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "fishbutton",
            "orderIndex": 2,
            "hero": true,
            "dead": "Td1 3d2 Ah3 Ts4",
            "rows": "Qc0 Kc3 8c4/2s0 Jd1 2d2 9d2 2c3/5d0 6c0 9h0 8d1 3c4",
            "win": -100,
            "playerId": "fishbutton"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:19:30",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338199741": [
        {
            "inFantasy": true,
            "result": 66,
            "playerName": "Mandy98",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Jh0 Ad0 Ac0/4h0 5d0 6d0 7c0 8c0/9h0 Td0 Jd0 Qs0 Kh0",
            "win": 210,
            "playerId": "Mandy98"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kd0 Ks0 8d4/2c0 Ah0 4s1 5h1 3s3/Ts0 9d2 Th2 9s3 6c4",
            "win": -135,
            "playerId": "shubhamkumarjha75"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "fishbutton",
            "orderIndex": 1,
            "hero": true,
            "dead": "2s1 9c2 6s3 Tc4",
            "rows": "Jc1 2d2 2h3/6h0 7s0 4d1 5c2 7d3/3d0 Qh0 Qc0 Kc4 As4",
            "win": -75,
            "playerId": "fishbutton"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:21:48",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338200078": [
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "Mandy98",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ah2 8c3 Ad4/4h0 7s0 5s1 7h1 5h4/3h0 3s0 Qs0 9c2 3d3",
            "win": 40,
            "playerId": "Mandy98"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "fishbutton",
            "orderIndex": 1,
            "hero": true,
            "dead": "7d1 9d2 3c3 8d4",
            "rows": "Ac1 Qc2 Kd3/4d0 4s0 2h2 Js3 5c4/6d0 7c0 8s0 9h1 5d4",
            "win": -40,
            "playerId": "fishbutton"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:23:12",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338200288": [
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "Mandy98",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "8s0 9c0 Kc0/4d0 5d0 8d0 Jd0 Ad0/2h0 2c0 2s0 Tc0 Ts0",
            "win": 100,
            "playerId": "Mandy98"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "fishbutton",
            "orderIndex": 0,
            "hero": true,
            "dead": "Js1 Jc2 As3 Ac4",
            "rows": "Kd2 3s3 Kh3/4h0 8h0 Th2 6h4 7c4/2d0 3d0 6d0 9d1 Qd1",
            "win": -100,
            "playerId": "fishbutton"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:23:56",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338200393": [
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "Mandy98",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc1 4c3 Ah3/5c0 6c0 Jh2 Js2 Qs4/7d0 8d0 Jd0 Td1 Kd4",
            "win": -25,
            "playerId": "Mandy98"
        },
        {
            "inFantasy": false,
            "result": 60,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ad1 Ac1 9s3/3d0 5h0 5d0 6d2 6s3/Qd0 Qc0 7h2 7s4 Ts4",
            "win": 50,
            "playerId": "shubhamkumarjha75"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "fishbutton",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ks1 5s2 Qh3 7c4",
            "rows": "As1 Tc2 4d4/8s0 9c0 9d1 4s3 4h4/2h0 6h0 Th0 3h2 Kh3",
            "win": -25,
            "playerId": "fishbutton"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:26:26",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338200769": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "Mandy98",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kh0 Ad2 7c4/3d0 3c0 Jh1 8d2 3h3/9d0 Qd0 Qs1 9c3 2h4",
            "win": -145,
            "playerId": "Mandy98"
        },
        {
            "inFantasy": true,
            "result": 66,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kd0 Ah0 Ac0/2d0 3s0 4h0 5h0 6d0/2c0 6c0 8c0 Qc0 Kc0",
            "win": 230,
            "playerId": "shubhamkumarjha75"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "fishbutton",
            "orderIndex": 2,
            "hero": true,
            "dead": "4c1 7d2 7h3 9s4",
            "rows": "Ks2 As3 Js4/5d0 5s0 6h0 4d3 9h4/7s0 8s0 Th1 Tc1 Ts2",
            "win": -85,
            "playerId": "fishbutton"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:28:46",
    "roomId": "41b-1d52d67b"
}


