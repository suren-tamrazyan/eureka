{
    "stakes": 5,
    "handData": {"338183308": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "Sharkcatcher",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qd0 Qs2 8d3/2s0 5d0 7s1 As2 Ad3/9d0 Tc0 9c1 5h4 8s4",
            "win": -50,
            "playerId": "Sharkcatcher"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "micnike",
            "orderIndex": 0,
            "hero": true,
            "dead": "Kc1 Kh2 9h3 Ah4",
            "rows": "Ac0 Ks3 6h4/2d0 6d0 6c0 7c1 2h2/Js0 4s1 4c2 Td3 2c4",
            "win": -50,
            "playerId": "micnike"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "NikhilSegel",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Th0 Qh2 8h4/5c0 9s0 5s1 Jc3 3h4/4d0 Jd0 7d1 Kd2 3d3",
            "win": 100,
            "playerId": "NikhilSegel"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 05:07:05",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338183702": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "Sharkcatcher",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ac0 As1 Qd2/4s0 5d0 8c2 Ad3 8s4/6h0 Th0 3h1 3d3 Ts4",
            "win": -100,
            "playerId": "Sharkcatcher"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "micnike",
            "orderIndex": 2,
            "hero": true,
            "dead": "Kc1 5h2 3s3 6c4",
            "rows": "Kh0 9d4 Tc4/2d1 2c1 9c2 9h3 Jh3/4h0 5s0 7d0 8h0 6d2",
            "win": 15,
            "playerId": "micnike"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "NikhilSegel",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ah2 Qh3 9s4/5c0 3c1 4c1 4d3 Qc4/7h0 7s0 Jd0 Jc0 7c2",
            "win": 85,
            "playerId": "NikhilSegel"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 05:09:41",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338184042": [
        {
            "inFantasy": false,
            "result": 54,
            "playerName": "Sharkcatcher",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kd0 Js3 Kc3/2s0 7s0 2d1 7c2 Kh4/Th0 Td0 Tc1 4h2 9c4",
            "win": 50,
            "playerId": "Sharkcatcher"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "micnike",
            "orderIndex": 1,
            "hero": true,
            "dead": "4c1 6c2 2c3 2h4",
            "rows": "Ad0 9s4 Qh4/5c0 5d1 3h2 3c3 9h3/9d0 Ts0 Qs0 8h1 Jc2",
            "win": -50,
            "playerId": "micnike"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "NikhilSegel",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "As2 8c4 Jd4/3s0 5s0 Ah1 Ac1 4d2/6d0 8d0 8s0 6h3 6s3",
            "win": 0,
            "playerId": "NikhilSegel"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 05:12:01",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338184373": [
        {
            "inFantasy": true,
            "result": 27,
            "playerName": "Sharkcatcher",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kh0 Kd0 Ad0/4h0 4d0 8d0 Td0 Tc0/2s0 6h0 6d0 6c0 6s0",
            "win": 55,
            "playerId": "Sharkcatcher"
        },
        {
            "inFantasy": false,
            "result": 36,
            "playerName": "micnike",
            "orderIndex": 0,
            "hero": true,
            "dead": "4c1 3s2 9s3 Qd4",
            "rows": "9d2 Ah3 Ac3/2c0 7s0 7c1 7h4 Ks4/5h0 5s0 Jd0 5c1 Jc2",
            "win": 50,
            "playerId": "micnike"
        },
        {
            "inFantasy": false,
            "result": 45,
            "playerName": "NikhilSegel",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qs0 8c4 Kc4/3c0 5d0 As1 2d2 4s3/9h0 Th0 8h1 3h2 2h3",
            "win": -105,
            "playerId": "NikhilSegel"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 05:14:15",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338184683": [
        {
            "inFantasy": true,
            "result": 39,
            "playerName": "Sharkcatcher",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "3h0 Qc0 Qs0/3s0 4c0 5h0 6h0 7d0/7s0 8c0 9s0 Th0 Jd0",
            "win": 105,
            "playerId": "Sharkcatcher"
        },
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "micnike",
            "orderIndex": 2,
            "hero": true,
            "dead": "5c0 8d0 Qh0",
            "rows": "9d0 9c0 Ac0/2h0 3c0 4h0 5d0 6d0/2s0 4s0 8s0 Ts0 Ks0",
            "win": 40,
            "playerId": "micnike"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "NikhilSegel",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qd3 As3 6s4/Kh1 Kd1 7h2 Jh2 5s4/6c0 8h0 9h0 Td0 Tc0",
            "win": -145,
            "playerId": "NikhilSegel"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 05:15:47",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338184908": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Sharkcatcher",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Jc3 Ad3 Tc4/3d0 3c1 3s1 5c2 2s4/8d0 9d0 Jd0 Qd0 6d2",
            "win": 60,
            "playerId": "Sharkcatcher"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "micnike",
            "orderIndex": 0,
            "hero": true,
            "dead": "4h1 2h2 Kh3 Ah4",
            "rows": "Qc0 Kc1 Qh2/7c0 6c1 6h2 Ac3 6s4/8c0 8s0 9h0 9c3 5s4",
            "win": -60,
            "playerId": "micnike"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 05:17:13",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338185120": [
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "Sharkcatcher",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kd0 As1 Ks4/5d0 6c0 5h2 9d2 9s4/Td0 Ts0 8s1 7c3 7s3",
            "win": 70,
            "playerId": "Sharkcatcher"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "micnike",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qs1 9c2 Th3 Tc4",
            "rows": "Qh1 Kc2 8h3/5s0 4c2 Jh3 3h4 9h4/2d0 6d0 7d0 Qd0 8d1",
            "win": -70,
            "playerId": "micnike"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 05:18:28",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338185307": [
        {
            "inFantasy": true,
            "result": -30,
            "playerName": "Sharkcatcher",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "6c0 9s0 Qh0/2h0 2d0 2s0 Jh0 Js0/Tc0 Ts0 Kh0 Kd0 Ks0",
            "win": 20,
            "playerId": "Sharkcatcher"
        },
        {
            "inFantasy": false,
            "result": -24,
            "playerName": "micnike",
            "orderIndex": 0,
            "hero": true,
            "dead": "8s1 6s2 Kc3 8d4",
            "rows": "Ac0 Ad2 Qd4/3h0 7c0 7h1 6d2 3s4/5h0 5s0 Jc1 5d3 Jd3",
            "win": -20,
            "playerId": "micnike"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 05:19:15",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338185412": [
        {
            "inFantasy": false,
            "result": 51,
            "playerName": "Sharkcatcher",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ah3 Ac3 6h4/5d1 5c1 4c2 5s2 2s4/7d0 7s0 9h0 Jh0 Js0",
            "win": -160,
            "playerId": "Sharkcatcher"
        },
        {
            "inFantasy": true,
            "result": 57,
            "playerName": "micnike",
            "orderIndex": 1,
            "hero": true,
            "dead": "3c0 6c0 9d0",
            "rows": "Td0 Tc0 Ts0/2h0 3h0 4h0 5h0 8h0/4s0 6s0 9s0 Qs0 As0",
            "win": 160,
            "playerId": "micnike"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 05:19:53",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338185495": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "Sharkcatcher",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qc3 Kd3 9h4/2d1 2c1 2h2 Ad2 4c4/4d0 5d0 6s0 7d0 8h0",
            "win": -50,
            "playerId": "Sharkcatcher"
        },
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "micnike",
            "orderIndex": 0,
            "hero": true,
            "dead": "4h0",
            "rows": "Qs0 Ah0 As0/3h0 3d0 5s0 Td0 Tc0/8c0 9c0 Jc0 Kc0 Ac0",
            "win": 50,
            "playerId": "micnike"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 05:20:22",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338185559": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "Sharkcatcher",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "As1 Ad2 Js3/2s0 7d0 6s3 8c4 Ac4/3c0 3s0 Ts0 3h1 3d2",
            "win": -30,
            "playerId": "Sharkcatcher"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "micnike",
            "orderIndex": 1,
            "hero": true,
            "dead": "8d1 2d2 7c3 2c4",
            "rows": "Kc1 4d3 Qc3/9h0 9c0 5d1 Tc2 7s4/2h0 4h0 7h0 Jh2 Jc4",
            "win": 30,
            "playerId": "micnike"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 05:21:35",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338185724": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "Sharkcatcher",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "8d3 8s3 Js4/2h0 5h0 3d2 4h2 6h4/9s0 Td0 Jd0 8h1 Qc1",
            "win": 75,
            "playerId": "Sharkcatcher"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "micnike",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jh1 6s2 3s3 Kc4",
            "rows": "Ah0 Ac3 5d4/6d0 6c0 9h1 9d2 Jc2/7d0 Qd0 Qs1 2s3 4d4",
            "win": -75,
            "playerId": "micnike"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 05:22:56",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338185930": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Sharkcatcher",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ah1 9h3 As4/2d0 6s0 7c1 2h2 7d3/Tc0 Jh0 Js0 Jd2 Jc4",
            "win": 40,
            "playerId": "Sharkcatcher"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "micnike",
            "orderIndex": 1,
            "hero": true,
            "dead": "6h1 5h2 3c3 4d4",
            "rows": "Kd0 8h4 Ks4/Td0 9c1 Qc1 9d3 Qh3/4s0 9s0 Qs0 2s2 5s2",
            "win": -40,
            "playerId": "micnike"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 05:24:13",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338186126": [
        {
            "inFantasy": true,
            "result": -9,
            "playerName": "Sharkcatcher",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Jh0 Qh0 Qd0/2d0 5d0 7d0 8d0 Kd0/4s0 7s0 9s0 Ts0 As0",
            "win": 15,
            "playerId": "Sharkcatcher"
        },
        {
            "inFantasy": true,
            "result": -3,
            "playerName": "micnike",
            "orderIndex": 0,
            "hero": true,
            "dead": "2c0 4h0",
            "rows": "Qs0 Ah0 Ad0/6h0 6d0 8h0 8s0 Jc0/5c0 5s0 Kh0 Kc0 Ks0",
            "win": -15,
            "playerId": "micnike"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 05:25:10",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338186269": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "Sharkcatcher",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ad2 Ah3 Kd4/6d0 9h0 2s1 6c1 9d2/8h0 8d0 Ts0 8s3 3s4",
            "win": -25,
            "playerId": "Sharkcatcher"
        },
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "micnike",
            "orderIndex": 1,
            "hero": true,
            "dead": "8c1 5h2 Ac3 5d4",
            "rows": "Qh0 Qc2 Tc3/7d0 Kh0 4d1 7s4 Kc4/3h0 5c0 3c1 3d2 5s3",
            "win": 25,
            "playerId": "micnike"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 05:26:27",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338186461": [
        {
            "inFantasy": true,
            "result": -3,
            "playerName": "Sharkcatcher",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "2h0 2d0 2c0/4d0 5c0 Ah0 Ac0 As0/5s0 6c0 7h0 8h0 9h0",
            "win": -15,
            "playerId": "Sharkcatcher"
        },
        {
            "inFantasy": true,
            "result": -9,
            "playerName": "micnike",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ts0",
            "rows": "Jh0 Kh0 Kd0/2s0 3h0 4c0 5d0 6d0/3d0 7d0 8d0 Td0 Ad0",
            "win": 15,
            "playerId": "micnike"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 05:27:19",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338186594": [
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "Sharkcatcher",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kd0 Ah0 Ad0/7c0 7s0 9h0 9d0 Tc0/2h0 2c0 6s0 Jc0 Js0",
            "win": 30,
            "playerId": "Sharkcatcher"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "micnike",
            "orderIndex": 1,
            "hero": true,
            "dead": "2s1 3s2 6d3 4s4",
            "rows": "5c1 5d2 As3/9c0 Jd0 Qc1 Qd2 Kc4/7h0 8h0 Kh0 6h3 Jh4",
            "win": -30,
            "playerId": "micnike"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 05:28:01",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338186699": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Sharkcatcher",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Jh3 As3 Kc4/4c0 7s0 4s2 7c2 Ks4/6h0 9h0 Qh0 3h1 Th1",
            "win": 0,
            "playerId": "Sharkcatcher"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "micnike",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qd1 2h2 Ac3 4d4",
            "rows": "Kd1 8h3 8d3/6s0 Ts0 2d1 Td2 6d4/5c0 Jc0 Js0 5h2 3d4",
            "win": 0,
            "playerId": "micnike"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 05:29:26",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338186907": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "Sharkcatcher",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ah0 Ad0 7d3/Ts0 Qh1 2c2 Th2 5h4/9h0 Kh0 Kd1 Ks3 6h4",
            "win": -30,
            "playerId": "Sharkcatcher"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "micnike",
            "orderIndex": 1,
            "hero": true,
            "dead": "2s1 2h2 7s3 9d4",
            "rows": "9s1 Td2 6c3/4s0 5d0 4h1 8d2 8h4/3c0 Jc0 Js0 Jh3 As4",
            "win": 30,
            "playerId": "micnike"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 05:30:48",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338187114": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Sharkcatcher",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "4c2 4d3 Qs4/3h0 6d0 6s0 Jc1 9h4/7d0 8d0 5d1 9d2 2d3",
            "win": 50,
            "playerId": "Sharkcatcher"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "micnike",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jd1 7c2 6c3 Ts4",
            "rows": "Qd1 Qc1 8s4/8h0 Th0 Qh3 Ks3 4h4/3s0 5s0 As0 3c2 Ah2",
            "win": -50,
            "playerId": "micnike"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 05:32:15",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338187316": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "Sharkcatcher",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kc2 Jc3 As3/7c0 Ts0 8c1 Jh1 9c2/8d0 9d0 Kd0 9s4 Td4",
            "win": 0,
            "playerId": "Sharkcatcher"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "micnike",
            "orderIndex": 1,
            "hero": true,
            "dead": "Tc1 3d2 8h3 Ks4",
            "rows": "Ad0 6h3 7h4/2s0 5s1 Qh2 Qs2 5c3/5d0 6d0 7s0 8s1 2d4",
            "win": 0,
            "playerId": "micnike"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 05:33:31",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338187479": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "Sharkcatcher",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ac0 As0 5d2/3h0 4d1 8s1 Jh4 Ks4/Jc0 Kc0 7h2 7s3 Jd3",
            "win": -30,
            "playerId": "Sharkcatcher"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "micnike",
            "orderIndex": 0,
            "hero": true,
            "dead": "3d1 4s2 3s3 3c4",
            "rows": "Js1 Qh2 Ah4/2s0 6h1 5h2 8d3 8c3/9h0 9c0 9s0 Th0 Kd4",
            "win": 30,
            "playerId": "micnike"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 05:34:54",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338187673": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "Sharkcatcher",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ac0 2d3 Qc3/3h0 5s1 6h1 5c2 Kd4/5d0 6d0 7s0 9s2 8c4",
            "win": -40,
            "playerId": "Sharkcatcher"
        },
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "micnike",
            "orderIndex": 1,
            "hero": true,
            "dead": "Kc1 Jd2 9h3 3c4",
            "rows": "As0 Ah1 7c3/2h0 Js1 Jh2 2c3 Tc4/4h0 4s0 Qs0 4d2 8s4",
            "win": 40,
            "playerId": "micnike"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 05:36:18",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338187848": [
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "Sharkcatcher",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "3c3 3s3 Ah4/4h1 4c1 4s2 6d2 2c4/3h0 5h0 6h0 7h0 Qh0",
            "win": -80,
            "playerId": "Sharkcatcher"
        },
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "micnike",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h0 2s0 3d0",
            "rows": "5d0 Kh0 Ks0/7s0 8c0 9h0 Th0 Js0/6c0 9c0 Tc0 Kc0 Ac0",
            "win": 80,
            "playerId": "micnike"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 05:37:19",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338187968": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "Sharkcatcher",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ts2 Qd3 Kd3/5d0 6c0 4c2 5s4 Th4/9c0 Td0 Js0 Qh1 Kc1",
            "win": -35,
            "playerId": "Sharkcatcher"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "micnike",
            "orderIndex": 2,
            "hero": true,
            "dead": "7d1 7c2 6h3 4h4",
            "rows": "As0 4s3 8h3/3c0 6d0 6s1 5h2 Ah4/Qs0 Ks0 Qc1 2h2 3s4",
            "win": -80,
            "playerId": "micnike"
        },
        {
            "inFantasy": false,
            "result": 63,
            "playerName": "ProfHK",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ad2 9d3 Ac3/2s0 7s0 7h1 4d2 2d4/3h0 3d0 8d0 8c1 Kh4",
            "win": 115,
            "playerId": "ProfHK"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 05:39:39",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338188221": [
        {
            "inFantasy": false,
            "result": 45,
            "playerName": "Sharkcatcher",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "5d2 Qd4 Kc4/Td0 7c1 8s1 Ts2 8c3/3h0 3s0 Jd0 Js0 3c3",
            "win": -15,
            "playerId": "Sharkcatcher"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "micnike",
            "orderIndex": 1,
            "hero": true,
            "dead": "2c1 Tc2 2d3 5h4",
            "rows": "Ks0 Kh1 Jh4/3d0 Ah0 As0 Qh2 Th4/5s0 9s1 9h2 6d3 6s3",
            "win": -5,
            "playerId": "micnike"
        },
        {
            "inFantasy": true,
            "result": 36,
            "playerName": "ProfHK",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kd0 Ad0 Ac0/7h0 7s0 8h0 8d0 Qc0/4c0 4s0 9d0 9c0 Jc0",
            "win": 20,
            "playerId": "ProfHK"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 05:41:42",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338188423": [
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "Sharkcatcher",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ad0 As2 Qd3/4h0 5h0 7c2 7s4 Tc4/Jh0 Js0 9h1 9c1 Ac3",
            "win": -150,
            "playerId": "Sharkcatcher"
        },
        {
            "inFantasy": true,
            "result": 27,
            "playerName": "micnike",
            "orderIndex": 0,
            "hero": true,
            "dead": "5s0 8h0",
            "rows": "7h0 7d0 Qs0/2d0 3c0 9d0 9s0 Th0/4d0 4c0 6h0 6c0 6s0",
            "win": 55,
            "playerId": "micnike"
        },
        {
            "inFantasy": false,
            "result": 51,
            "playerName": "ProfHK",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ks0 5d3 Kh4/6d0 3h1 3d2 3s2 2h3/8d0 8c0 Jc0 8s1 5c4",
            "win": 95,
            "playerId": "ProfHK"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 05:43:44",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338188623": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Sharkcatcher",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Td2 7s3 Qd4/2c0 7d0 9c1 Ad2 9s3/6h0 6c0 8s0 8c1 5h4",
            "win": -50,
            "playerId": "Sharkcatcher"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "micnike",
            "orderIndex": 2,
            "hero": true,
            "dead": "2h1 4s2 Ks3 Qh4",
            "rows": "Kd0 Kc2 7h4/3c0 5s1 5c2 3h3 Kh3/9d0 Tc0 Jh0 Jd1 6s4",
            "win": -75,
            "playerId": "micnike"
        },
        {
            "inFantasy": true,
            "result": 27,
            "playerName": "ProfHK",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "8h0 8d0 Qc0/3d0 3s0 4h0 4d0 Jc0/2d0 2s0 Ah0 Ac0 As0",
            "win": 125,
            "playerId": "ProfHK"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 05:46:17",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338188869": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "Sharkcatcher",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ac0 8d2 9s4/2d0 7h0 9h1 8c3 8s3/3s0 Qs0 3d1 Qh2 7d4",
            "win": -90,
            "playerId": "Sharkcatcher"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "micnike",
            "orderIndex": 1,
            "hero": true,
            "dead": "Kh1 Qc2 3c3 Qd4",
            "rows": "Ad0 Ah1 Ks3/Jh0 8h1 9c2 7c4 9d4/Th0 Tc0 Ts0 2h2 Td3",
            "win": -150,
            "playerId": "micnike"
        },
        {
            "inFantasy": false,
            "result": 60,
            "playerName": "ProfHK",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kd2 As2 Kc4/4s0 6d0 2c1 4h1 2s3/5h0 5s0 Jd0 5d3 5c4",
            "win": 240,
            "playerId": "ProfHK"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 05:48:30",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338189116": [
        {
            "inFantasy": false,
            "result": 36,
            "playerName": "Sharkcatcher",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "7c3 6d4 7s4/6h0 8c0 3h1 3d1 8d2/Th0 Tc0 Jc0 Td2 Jd3",
            "win": -40,
            "playerId": "Sharkcatcher"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "micnike",
            "orderIndex": 0,
            "hero": true,
            "dead": "2s1 9h2 2c3 Ts4",
            "rows": "As0 Ah2 5h3/4c0 6s0 7d1 6c2 4s4/8h0 Qh0 Qd1 Qs3 Kd4",
            "win": -60,
            "playerId": "micnike"
        },
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "ProfHK",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Js0 Ad0 Ac0/5d0 5c0 7h0 Kc0 Ks0/2h0 2d0 9d0 9c0 9s0",
            "win": 100,
            "playerId": "ProfHK"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 05:50:25",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338189322": [
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "Sharkcatcher",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ks0 9d3 Qd3/2s0 4d0 Ac1 2c2 Kc4/7h0 9c0 Th1 Js2 8h4",
            "win": -75,
            "playerId": "Sharkcatcher"
        },
        {
            "inFantasy": true,
            "result": 26,
            "playerName": "micnike",
            "orderIndex": 2,
            "hero": true,
            "dead": "5s0 Jh0 Qs0",
            "rows": "8d0 8c0 Ah0/2h0 3h0 4s0 5c0 6s0/7c0 7s0 Td0 Tc0 Ts0",
            "win": 120,
            "playerId": "micnike"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "ProfHK",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qc0 Kh2 As3/4h0 Ad0 6h1 6d2 4c4/3d0 3s0 8s1 Jc3 3c4",
            "win": -45,
            "playerId": "ProfHK"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 05:52:32",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338189547": [
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "micnike",
            "orderIndex": 0,
            "hero": true,
            "dead": "3c1 6h2 8s3 8d4",
            "rows": "Ks0 Td4 Kd4/5c0 9h0 8h1 9d2 9s3/Jd0 Jc0 Qs1 Qh2 Js3",
            "win": 110,
            "playerId": "micnike"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "ProfHK",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ac2 Ah3 Kh4/2h0 3s0 2c1 7c1 3d2/6d0 6c0 Tc0 Qc3 4s4",
            "win": -110,
            "playerId": "ProfHK"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 05:54:15",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338189706": [
        {
            "inFantasy": true,
            "result": 24,
            "playerName": "micnike",
            "orderIndex": 1,
            "hero": true,
            "dead": "5c0 Kc0",
            "rows": "Jd0 Js0 Ah0/2c0 2s0 6h0 6d0 6c0/7h0 7c0 7s0 9d0 9c0",
            "win": 130,
            "playerId": "micnike"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "ProfHK",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "5h3 Kh3 2h4/Jc1 Kd1 8c2 Tc2 7d4/5s0 8s0 Ts0 Qs0 Ks0",
            "win": -130,
            "playerId": "ProfHK"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 05:55:07",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338189790": [
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "micnike",
            "orderIndex": 0,
            "hero": true,
            "dead": "4d1 6d2 3h3 Qh4",
            "rows": "5d3 9h3 Kh4/5c0 9d0 7c2 8d2 As4/3s0 6s0 Ks0 2s1 8s1",
            "win": -20,
            "playerId": "micnike"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "ProfHK",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qd0 Qs2 Ac3/8c0 8h1 4c3 4s4 Ad4/5s0 7s0 Js0 Jc1 7d2",
            "win": 20,
            "playerId": "ProfHK"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 05:56:40",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338189936": [
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "micnike",
            "orderIndex": 1,
            "hero": true,
            "dead": "3d1 Ks2 Qd3 6s4",
            "rows": "As0 Ad1 Kc4/5d0 4h2 5h2 4d3 6d4/9h0 9d0 Ts0 Td1 Th3",
            "win": 30,
            "playerId": "micnike"
        },
        {
            "inFantasy": true,
            "result": 24,
            "playerName": "ProfHK",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "5c0 Qh0 Kd0/5s0 6c0 7s0 8s0 9c0/2d0 2c0 2s0 Jh0 Js0",
            "win": -30,
            "playerId": "ProfHK"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 05:57:19",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338189997": [
        {
            "inFantasy": true,
            "result": 72,
            "playerName": "micnike",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h0 6d0 Ks0",
            "rows": "Ad0 Ac0 As0/9s0 Td0 Jc0 Qd0 Kh0/4h0 4d0 5d0 5c0 5s0",
            "win": 190,
            "playerId": "micnike"
        },
        {
            "inFantasy": false,
            "result": 60,
            "playerName": "ProfHK",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qh3 Qs3 Th4/Js1 Ah1 8s2 Tc2 7h4/2c0 3c0 4c0 7c0 Qc0",
            "win": -190,
            "playerId": "ProfHK"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 05:58:18",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338190078": [
        {
            "inFantasy": true,
            "result": 3,
            "playerName": "micnike",
            "orderIndex": 1,
            "hero": true,
            "dead": "3c0",
            "rows": "Jh0 Js0 Kd0/5d0 5c0 7h0 7c0 8s0/2h0 4h0 6h0 9h0 Th0",
            "win": -5,
            "playerId": "micnike"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "ProfHK",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kh3 Kc3 Ac4/Ad1 As1 Qh2 Qc2 9d4/5h0 6s0 7s0 8h0 9c0",
            "win": 5,
            "playerId": "ProfHK"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 05:58:49",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338190129": [
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "micnike",
            "orderIndex": 0,
            "hero": true,
            "dead": "2c1 6h2 4h3 Ks4",
            "rows": "As0 9s3 Ah3/6c0 8c0 Tc1 5c2 Jc4/3d0 9d0 Ad1 7d2 Td4",
            "win": 10,
            "playerId": "micnike"
        },
        {
            "inFantasy": true,
            "result": 24,
            "playerName": "ProfHK",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "8s0 Kd0 Ac0/3h0 3c0 3s0 Qh0 Qs0/7h0 7s0 Jh0 Jd0 Js0",
            "win": -10,
            "playerId": "ProfHK"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 05:59:42",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338190209": [
        {
            "inFantasy": true,
            "result": -3,
            "playerName": "micnike",
            "orderIndex": 1,
            "hero": true,
            "dead": "4s0 5c0 7s0",
            "rows": "8c0 Js0 As0/4d0 8d0 Td0 Jd0 Kd0/2h0 3h0 4h0 5h0 Ah0",
            "win": 45,
            "playerId": "micnike"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "ProfHK",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ks3 Ad3 Qh4/6h1 7h1 8h2 9d2 Ts4/2c0 3c0 7c0 Jc0 Ac0",
            "win": -45,
            "playerId": "ProfHK"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 06:00:31",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338190309": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "micnike",
            "orderIndex": 1,
            "hero": true,
            "dead": "5h1 Qs2 2c3 Ac4",
            "rows": "Ah0 Ad1 Jh3/4h0 6d0 6s1 4c3 9s4/7c0 Tc0 7d2 Kd2 5d4",
            "win": 0,
            "playerId": "micnike"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "ProfHK",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qc0 Qd1 8h3/Jc1 5c2 6c2 Qh3 6h4/2s0 4s0 7s0 Ts0 2h4",
            "win": 0,
            "playerId": "ProfHK"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 06:02:12",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338190525": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "micnike",
            "orderIndex": 0,
            "hero": true,
            "dead": "5d1 9s2 4c3 4s4",
            "rows": "Qh0 Qs2 5c3/6h0 2h1 2d1 2c3 Kd4/3s0 Tc0 Ts0 Td2 Jh4",
            "win": -55,
            "playerId": "micnike"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "ProfHK",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ks0 As1 Kc2/6c0 6s0 6d3 Qd4 Ad4/8h0 Th0 4h1 7h2 3h3",
            "win": 55,
            "playerId": "ProfHK"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 06:04:12",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338190790": [
        {
            "inFantasy": true,
            "result": 0,
            "playerName": "micnike",
            "orderIndex": 1,
            "hero": true,
            "dead": "2h0",
            "rows": "Js0 Qc0 Qs0/6c0 6s0 8h0 8c0 9d0/5h0 5d0 Th0 Tc0 Ts0",
            "win": -30,
            "playerId": "micnike"
        },
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "ProfHK",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Td0 Kh0 Ks0/2s0 3s0 4s0 5c0 As0/9h0 9c0 9s0 Jd0 Jc0",
            "win": 30,
            "playerId": "ProfHK"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 06:05:37",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338190960": [
        {
            "inFantasy": false,
            "result": 51,
            "playerName": "Seepoker",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qc0 Qd1 9c3/2h0 6d0 6c2 5s3 6h4/7c0 Ts0 7h1 7d2 9s4",
            "win": 125,
            "playerId": "Seepoker"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "micnike",
            "orderIndex": 1,
            "hero": true,
            "dead": "3d1 3h2 5d3 2c4",
            "rows": "Jh1 Kh2 Ad4/4c0 8c0 8d1 Jd3 Th4/Ah0 Ac0 As0 Td2 3s3",
            "win": -20,
            "playerId": "micnike"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "ProfHK",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kd0 Tc2 7s3/3c0 6s0 2d1 5c2 4h4/9h0 Qh0 9d1 8s3 Js4",
            "win": -105,
            "playerId": "ProfHK"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 06:08:39",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338191339": [
        {
            "inFantasy": true,
            "result": 54,
            "playerName": "Seepoker",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "5d0 Qd0 Qs0/3h0 8d0 9s0 Ah0 As0/6h0 6s0 Tc0 Ts0 Jc0",
            "win": 130,
            "playerId": "Seepoker"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "micnike",
            "orderIndex": 0,
            "hero": true,
            "dead": "4c1 Jh2 Qc3 Jd4",
            "rows": "Ad0 Ac0 5h4/3s0 5s0 5c1 2h2 3d3/8h0 8s1 Td2 Qh3 4d4",
            "win": -65,
            "playerId": "micnike"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "ProfHK",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kd0 Kc0 8c3/4h0 2c1 7c2 7s2 2s4/9d0 Js0 9c1 Th3 Ks4",
            "win": -65,
            "playerId": "ProfHK"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 06:11:43",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338191736": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "Seepoker",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ks2 8s3 Kd4/3d0 3s0 2h1 Tc2 2s3/6d0 7h0 8d0 5c1 9h4",
            "win": 65,
            "playerId": "Seepoker"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "micnike",
            "orderIndex": 2,
            "hero": true,
            "dead": "8c1 6h2 2c3 Td4",
            "rows": "Kc0 Qs1 Qc4/6s0 Ac0 As0 3c2 4d3/9d0 Js1 Th2 Jh3 Jc4",
            "win": -45,
            "playerId": "micnike"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "ProfHK",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qd1 Kh1 Qh2/3h0 5d0 7c0 5h3 7s4/4c0 4s0 4h2 9s3 Ah4",
            "win": -20,
            "playerId": "ProfHK"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 06:14:20",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338192073": [
        {
            "inFantasy": true,
            "result": 3,
            "playerName": "Seepoker",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qd0 Qs0 Kd0/4c0 5s0 6s0 7c0 8c0/4h0 7h0 Th0 Jh0 Ah0",
            "win": -15,
            "playerId": "Seepoker"
        },
        {
            "inFantasy": true,
            "result": -3,
            "playerName": "micnike",
            "orderIndex": 1,
            "hero": true,
            "dead": "2c0",
            "rows": "Td0 Qh0 Qc0/5d0 5c0 6c0 8h0 8d0/3d0 3s0 Ad0 Ac0 As0",
            "win": -45,
            "playerId": "micnike"
        },
        {
            "inFantasy": true,
            "result": -12,
            "playerName": "ProfHK",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Jd0 Jc0 Kh0/2s0 4s0 7s0 8s0 Ks0/6h0 6d0 9h0 9c0 9s0",
            "win": 60,
            "playerId": "ProfHK"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 06:15:16",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338192193": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "micnike",
            "orderIndex": 1,
            "hero": true,
            "dead": "Ts1 7c2 Ah3 Td4",
            "rows": "Kc0 Kd3 Qs4/5s0 6h0 6s1 8c2 8s4/Jd0 Jc0 Jh1 4s2 Js3",
            "win": 70,
            "playerId": "micnike"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "ProfHK",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ks0 Kh2 Tc4/Ac0 As0 9c2 7h3 8d4/5c0 7d0 6d1 9s1 8h3",
            "win": -70,
            "playerId": "ProfHK"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 06:16:53",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338192391": [
        {
            "inFantasy": true,
            "result": 3,
            "playerName": "micnike",
            "orderIndex": 0,
            "hero": true,
            "dead": "6d0 Kd0",
            "rows": "4d0 4s0 As0/5d0 6h0 7h0 8s0 9s0/2c0 5c0 8c0 9c0 Jc0",
            "win": -55,
            "playerId": "micnike"
        },
        {
            "inFantasy": true,
            "result": -3,
            "playerName": "ProfHK",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "6c0 9h0 Ks0/3h0 3c0 3s0 Ah0 Ad0/Td0 Ts0 Qh0 Qc0 Qs0",
            "win": 55,
            "playerId": "ProfHK"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 06:18:04",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338192543": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "micnike",
            "orderIndex": 1,
            "hero": true,
            "dead": "8d1 9c2 2c3 6s4",
            "rows": "Qs2 Th3 4c4/Ah0 As0 5h2 4s3 Ac4/3c0 4d0 5s0 6c1 7c1",
            "win": -15,
            "playerId": "micnike"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "ProfHK",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qh1 Jd3 5d4/2h0 7s0 8s1 7d2 8h2/9h0 9d0 Ts0 Tc3 Td4",
            "win": 15,
            "playerId": "ProfHK"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 06:19:55",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338192765": [
        {
            "inFantasy": false,
            "result": 39,
            "playerName": "MTAAA",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "4h1 9h3 Qd4/5s0 6h0 7h1 Ac3 7c4/8h0 8d0 Qs0 Th2 Ts2",
            "win": -165,
            "playerId": "MTAAA"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "micnike",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jh1 8s2 2c3 3s4",
            "rows": "Kd0 Kh2 Ad4/9s0 6d1 3c3 9c3 6c4/4c0 Qc0 Kc0 5c1 8c2",
            "win": 110,
            "playerId": "micnike"
        },
        {
            "inFantasy": false,
            "result": 33,
            "playerName": "ProfHK",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "As1 Ks3 Ah3/2d0 5d0 2h1 5h2 4d4/7s0 Jd0 Js0 7d2 Qh4",
            "win": 55,
            "playerId": "ProfHK"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 06:22:23",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338193067": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "MTAAA",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ad3 Ac3 Ah4/8h1 8c1 2d2 2s2 4d4/3c0 4h0 5c0 6c0 Qc0",
            "win": -85,
            "playerId": "MTAAA"
        },
        {
            "inFantasy": true,
            "result": 60,
            "playerName": "micnike",
            "orderIndex": 0,
            "hero": true,
            "dead": "2c0 Jc0",
            "rows": "Th0 Ts0 Kd0/3h0 3d0 7h0 7d0 7s0/6d0 6s0 9h0 9c0 9s0",
            "win": 55,
            "playerId": "micnike"
        },
        {
            "inFantasy": true,
            "result": 48,
            "playerName": "ProfHK",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qh0 Qd0 Qs0/6h0 7c0 8s0 9d0 Tc0/5h0 5d0 5s0 Kh0 Kc0",
            "win": 30,
            "playerId": "ProfHK"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 06:23:46",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338193225": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "micnike",
            "orderIndex": 1,
            "hero": true,
            "dead": "4h1 Qd2 Td3 Th4",
            "rows": "Kc0 Qh3 Kh3/6c0 8h0 9s1 8s2 3c4/5d0 Jd0 5h1 Jh2 3d4",
            "win": -100,
            "playerId": "micnike"
        },
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "ProfHK",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "3h0 5c0 7c0/2d0 4d0 6d0 9d0 Kd0/Jc0 Js0 Ah0 Ad0 As0",
            "win": 100,
            "playerId": "ProfHK"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 06:24:40",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338193332": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "MTAAA",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "5s2 Kh2 9s4/6s0 7s0 7d1 Th1 8s4/3c0 4c0 8c0 3s3 4s3",
            "win": 60,
            "playerId": "MTAAA"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "micnike",
            "orderIndex": 1,
            "hero": true,
            "dead": "8h1 9d2 6h3 Ad4",
            "rows": "Ah0 Qs1 As2/2s0 9c0 5h1 5c2 2c3/4d0 Jd0 Qc3 5d4 6c4",
            "win": -30,
            "playerId": "micnike"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "ProfHK",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qh0 Kc1 Kd3/6d0 Ac1 4h3 Qd4 Ks4/7h0 7c0 Tc0 Jh2 Js2",
            "win": -30,
            "playerId": "ProfHK"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 06:27:09",
    "roomId": "41b-1d52d67b"
}


