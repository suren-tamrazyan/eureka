{
    "stakes": 5,
    "handData": {"338149945": [
        {
            "inFantasy": false,
            "result": 54,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jh1 2s2 3h3 Ts4",
            "rows": "Qs0 Qc1 7s3/Kd0 Ks0 2d1 8s2 Qh3/9d0 9s0 Ad2 6h4 6d4",
            "win": 130,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "Raasta",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "9h0 Th3 As3/4d0 5s0 6s1 5c2 9c4/7d0 7c0 8c1 Js2 5h4",
            "win": -35,
            "playerId": "Raasta"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "Worner",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ac0 Td2 Ah3/3c0 Jd0 8d1 3d2 3s4/2h0 Kh0 8h1 7h3 4c4",
            "win": -95,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 21:50:55",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338150210": [
        {
            "inFantasy": true,
            "result": -6,
            "playerName": "serverinme",
            "orderIndex": 2,
            "hero": true,
            "dead": "5h0",
            "rows": "2h0 8s0 Js0/2c0 4c0 5c0 6c0 9c0/3d0 4d0 5d0 9d0 Td0",
            "win": 50,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Raasta",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qh1 Kh3 Ac4/3h0 5s0 6h0 6d2 3s3/7s0 Jd0 7h1 Jh2 7c4",
            "win": -20,
            "playerId": "Raasta"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kd0 8d3 Qd4/Ah0 Ad0 2s1 3c2 Qc4/Th0 Ts0 9h1 9s2 Tc3",
            "win": -30,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 21:56:26",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338150701": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jh1 Js2 Qs3 8d4",
            "rows": "Ad0 As2 8h4/3h0 5h0 4d1 6h1 2c4/6c0 9c0 Th2 Jc3 Qh3",
            "win": -50,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "Raasta",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kd0 Kh1 Ah3/6d0 Qc1 Jd3 7d4 8s4/3s0 5s0 9s0 9h2 9d2",
            "win": -50,
            "playerId": "Raasta"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "Worner",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ks0 Qd2 8c4/7s1 7h2 2h3 2s3 Ts4/3c0 5c0 7c0 Tc0 4c1",
            "win": 100,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 21:59:01",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338150842": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "serverinme",
            "orderIndex": 2,
            "hero": true,
            "dead": "7c1 Qd2 4h3 Kd4",
            "rows": "Qh0 Qs1 8s3/2s0 4d0 Ad2 5c3 Kh4/Td0 Jc0 Js1 6s2 7s4",
            "win": -70,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "Raasta",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ks0 9h3 Ac4/4s0 5d0 5h1 7d1 Jh4/2h0 2d0 Tc2 Ts2 3d3",
            "win": 15,
            "playerId": "Raasta"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc0 2c4 3h4/3c0 6d0 3s2 4c2 6c3/8h0 9s0 Th1 Jd1 Qc3",
            "win": 55,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:01:34",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338151020": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "Js1 5h2 4c3 Ah4",
            "rows": "Qh1 Qs2 Ac3/3d0 7d0 9c1 9h3 Kc4/6h0 6d0 Th0 8h2 2d4",
            "win": -80,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "Raasta",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qd0 As1 7h4/2s0 5d0 6c0 2h1 4s4/Jd0 8d2 8s2 4h3 8c3",
            "win": -20,
            "playerId": "Raasta"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Jh0 Kh1 Ad4/4d0 9d0 Ts2 Td3 5s4/3c0 5c0 7c1 Jc2 Qc3",
            "win": 100,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:04:21",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338151284": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ts1 5h2 Js3 Ah4",
            "rows": "Qd0 Qc2 8c4/3d0 3s0 Tc1 Td2 7h3/4s0 9s0 9d1 Ks3 3h4",
            "win": -125,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 66,
            "playerName": "Raasta",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ac3 7d4 As4/6s0 Jh0 Jc1 8s2 8h3/2c0 5c0 Kc0 6c1 3c2",
            "win": 190,
            "playerId": "Raasta"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "Worner",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Jd3 2h4 9c4/6h0 8d0 6d1 2d2 2s2/7c0 Qh0 Qs0 7s1 5s3",
            "win": -65,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:06:54",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338151526": [
        {
            "inFantasy": false,
            "result": 66,
            "playerName": "serverinme",
            "orderIndex": 2,
            "hero": true,
            "dead": "7c1 2d2 Ac3 2c4",
            "rows": "5s2 8h4 9d4/3h0 4h0 4d0 4c1 3d2/6c0 Jc0 Js1 6d3 Jh3",
            "win": -50,
            "playerId": "serverinme"
        },
        {
            "inFantasy": true,
            "result": 141,
            "playerName": "Raasta",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ah0 Ad0 As0/7d0 8c0 9h0 Th0 Jd0/6s0 7s0 9s0 Ts0 Qs0",
            "win": 235,
            "playerId": "Raasta"
        },
        {
            "inFantasy": false,
            "result": 57,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qc1 Qd3 Kc3/9c0 Td0 Tc1 7h2 5c4/2s0 4s0 8s0 Ks2 Qh4",
            "win": -185,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:08:52",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338151719": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "5c1 5h2 9h3 Js4",
            "rows": "As0 Ad2 Kd3/Th0 Ts1 4h2 Qc3 7h4/5d0 6c0 7s0 9s1 2d4",
            "win": -75,
            "playerId": "serverinme"
        },
        {
            "inFantasy": true,
            "result": 27,
            "playerName": "Raasta",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "6h0 Kc0 Ks0/3h0 7d0 7c0 9d0 9c0/2c0 3c0 4c0 8c0 Jc0",
            "win": 75,
            "playerId": "Raasta"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:09:42",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338151803": [
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "8d1 2c2 Ks3 3d4",
            "rows": "Kd1 Kc1 8h2/5c0 6h0 5h2 5d3 Ad4/Th0 Td0 Ts0 4s3 9s4",
            "win": 80,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qh0 9d2 Kh4/Ah0 8s1 Ac1 7s2 6s3/2h0 2d0 Jc0 4d3 Jd4",
            "win": -80,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:11:37",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338152006": [
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "2d0 8s0",
            "rows": "Qh0 Kh0 As0/4d0 4c0 6h0 6s0 Js0/3h0 3c0 7h0 7d0 7c0",
            "win": 60,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kd3 Ac3 Jc4/5d1 5c1 2h2 2s2 6d4/8h0 8d0 8c0 9h0 Qd0",
            "win": -60,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:12:37",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338152109": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "5h1 Td2 Jh3 7d4",
            "rows": "Qh0 9h1 Qd3/3c0 8c1 7c2 Kc3 6d4/Ts0 Js0 As0 Ks2 5s4",
            "win": 0,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "Deux",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kh0 8h3 Kd3/2c0 6s0 2d1 2h2 3s4/8s0 Th0 9c1 Jc2 3d4",
            "win": 0,
            "playerId": "Deux"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "Worner",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qs0 Ad2 Ac3/3h0 4c0 4s1 6h2 4d4/7h0 9d0 7s1 Tc3 5c4",
            "win": 0,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:15:04",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338152354": [
        {
            "inFantasy": false,
            "result": 57,
            "playerName": "serverinme",
            "orderIndex": 2,
            "hero": true,
            "dead": "Qh1 2c2 8s3 2s4",
            "rows": "Kc0 Kd2 8c3/4h0 5d1 5s1 9s2 9c4/Th0 Jh0 Jc0 Tc3 Ad4",
            "win": 75,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "Deux",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qs0 6d2 5h4/3c0 9d1 Ks2 3s3 3d4/2h0 7h0 8h0 Ah1 Kh3",
            "win": 55,
            "playerId": "Deux"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ac0 As1 6c3/4s0 5c0 6h0 7s2 6s4/Jd0 Qd1 7d2 4d3 8d4",
            "win": -130,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:17:30",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338152604": [
        {
            "inFantasy": true,
            "result": -27,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "6c0 8c0",
            "rows": "5h0 Ts0 Ah0/9d0 Tc0 Jc0 Qh0 Ks0/3h0 3s0 7d0 7c0 7s0",
            "win": -20,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": -33,
            "playerName": "Deux",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qc2 Jd3 Kc4/4d0 6d0 8d1 6h2 6s4/7h0 8h0 Jh0 Th1 9h3",
            "win": 75,
            "playerId": "Deux"
        },
        {
            "inFantasy": false,
            "result": -48,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ad0 As0 5d4/4c0 5s0 5c1 4h2 9c3/Qd0 Td1 Qs2 3d3 3c4",
            "win": -55,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:19:42",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338152832": [
        {
            "inFantasy": false,
            "result": 57,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "5s1 5c2 7s3 8d4",
            "rows": "7c1 Ts1 9s3/3h0 8h0 Jc2 9h3 9c4/4d0 5d0 Jd0 2d2 Td4",
            "win": -95,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 63,
            "playerName": "Deux",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ad0 Ac0 9d4/Ks1 Ah1 Tc3 As3 6c4/6d0 7d0 8s0 6h2 6s2",
            "win": -100,
            "playerId": "Deux"
        },
        {
            "inFantasy": true,
            "result": 78,
            "playerName": "Worner",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kh0 Kd0 Kc0/4h0 5h0 7h0 Th0 Qh0/3d0 3s0 Qd0 Qc0 Qs0",
            "win": 195,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:21:56",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338153059": [
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "serverinme",
            "orderIndex": 2,
            "hero": true,
            "dead": "8d1 3s2 2h3 2d4",
            "rows": "Qh0 Jc3 Js4/7s0 8h0 5d2 Ah3 Ad4/9d0 9c0 Td1 Ts1 9s2",
            "win": -15,
            "playerId": "serverinme"
        },
        {
            "inFantasy": true,
            "result": -3,
            "playerName": "Deux",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Jh0 Jd0 Ks0/5s0 6s0 7h0 8s0 9h0/3h0 3d0 3c0 4c0 4s0",
            "win": 65,
            "playerId": "Deux"
        },
        {
            "inFantasy": true,
            "result": 0,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qc0 Qs0 Kc0/2s0 4h0 Th0 Ac0 As0/4d0 5c0 6d0 7d0 8c0",
            "win": -50,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:23:52",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338153245": [
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qs1 6c2 6h3 8d4",
            "rows": "9c2 3s3 Kd4/2c0 4h0 4c0 7h2 Kc3/6s0 8s0 7d1 9d1 5s4",
            "win": -45,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "Deux",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qd1 Ks2 5h4/6d0 5c1 9h3 Ac3 9s4/3d0 3c0 Jh0 Js0 Jd2",
            "win": 75,
            "playerId": "Deux"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ad1 Kh3 2h4/4s0 8h0 Qh2 Qc2 4d4/Td0 Ts0 Jc0 Tc1 5d3",
            "win": -30,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:26:46",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338153525": [
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ah1 8d2 3s3 5c4",
            "rows": "Ts0 Kh1 5d4/2h0 Jh0 2s1 Qd2 Kc4/6c0 7c0 8c2 9d3 Td3",
            "win": -90,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 66,
            "playerName": "Deux",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ad0 Ac2 Jd4/4s0 6s1 3h2 5s3 7s3/7d0 Tc0 Js0 8s1 9h4",
            "win": 200,
            "playerId": "Deux"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "Worner",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qs0 Th3 Ks3/As0 2c1 2d2 8h2 4c4/3d0 3c0 9s0 9c1 6d4",
            "win": -110,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:29:19",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338153767": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "serverinme",
            "orderIndex": 2,
            "hero": true,
            "dead": "2s1 2h2 Ah3 Ad4",
            "rows": "Ks1 Kd3 Qs4/6h0 3s2 6d2 4d3 9s4/3c0 5c0 9c0 Tc0 Ac1",
            "win": -160,
            "playerId": "serverinme"
        },
        {
            "inFantasy": true,
            "result": 57,
            "playerName": "Deux",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "6c0 Kh0 Kc0/2d0 3d0 5d0 8d0 9d0/3h0 5h0 7h0 Jh0 Qh0",
            "win": 135,
            "playerId": "Deux"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "As0 Qd3 Td4/7c0 8s1 7s2 8c3 7d4/Th0 Ts0 Jd0 Jc1 Js2",
            "win": 25,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:32:09",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338154022": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qc1 Qd2 9h3 8c4",
            "rows": "Kh0 Kc2 8h4/7c0 4h1 6h1 6c3 3d4/4s0 Qs0 As0 Ts2 Js3",
            "win": -30,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "Deux",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ah2 Td3 Kd3/7d0 9d0 5h1 6s1 5d4/2c0 Jc0 Ac0 Tc2 2s4",
            "win": -30,
            "playerId": "Deux"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qh1 Ks2 2h3/7h0 8s0 5c1 8d2 7s4/3h0 Jh0 Jd0 3c3 Ad4",
            "win": 60,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:35:06",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338154288": [
        {
            "inFantasy": false,
            "result": 66,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "Kd1 Qs2 4c3 7s4",
            "rows": "Qd0 Ac1 Ad2/7h0 6c1 6d3 Ts3 6s4/3h0 3d0 Jc0 Jd2 3c4",
            "win": 210,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "Deux",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kh0 Qh2 Ah4/8h0 4d1 8s1 2h2 4s4/5s0 9s0 Js0 9h3 Jh3",
            "win": -130,
            "playerId": "Deux"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "Worner",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ks0 7d3 2d4/8d0 Th1 9d2 Tc3 3s4/5c0 Qc0 Kc0 9c1 8c2",
            "win": -80,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:37:49",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338154525": [
        {
            "inFantasy": true,
            "result": 60,
            "playerName": "serverinme",
            "orderIndex": 2,
            "hero": true,
            "dead": "3c0 4h0 6d0",
            "rows": "7c0 Kh0 Kd0/2c0 8h0 8c0 Jh0 Js0/2s0 9s0 Qs0 Ks0 As0",
            "win": 180,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "Deux",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ah0 Ad1 7d3/8s0 9d1 2h2 2d4 Th4/6h0 6s0 Qh0 Td2 6c3",
            "win": -120,
            "playerId": "Deux"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "9c2 8d3 Ac4/3h0 4s0 5h0 5d1 4d2/Ts0 Jc0 Jd1 Tc3 7s4",
            "win": -60,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:40:39",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338154761": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "Kh1 9s2 Qd3 3c4",
            "rows": "As2 8c3 Td4/5d0 5s1 Jh2 Jd3 Th4/4c0 6c0 9c0 Kc0 Qc1",
            "win": -30,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "Deux",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ac3 6h4 9d4/5c0 8d0 9h1 6s2 7h2/4s0 Ts0 Ks0 Qs1 8s3",
            "win": 40,
            "playerId": "Deux"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Worner",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kd1 Tc3 Ad4/3s0 7d0 Js1 3d2 4d4/2h0 8h0 Qh0 5h2 Ah3",
            "win": -10,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:43:20",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338154969": [
        {
            "inFantasy": false,
            "result": 54,
            "playerName": "serverinme",
            "orderIndex": 2,
            "hero": true,
            "dead": "7c1 8d2 6d3 5h4",
            "rows": "Kh0 Qh2 Qc4/2d0 Ah0 Ac0 Jh3 4s4/4c0 9c1 Tc1 9d2 4h3",
            "win": 130,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "Deux",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Jd1 Qs1 Ts3/2h0 6s0 6c2 9h2 Kd4/3h0 3s0 7s0 5s3 7h4",
            "win": -35,
            "playerId": "Deux"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "As0 Qd3 6h4/3c0 8c0 3d1 Jc2 Js3/Kc0 Ks0 Th1 5c2 8s4",
            "win": -95,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:46:01",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338155169": [
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "6c0",
            "rows": "8d0 Ah0 Ad0/2h0 5h0 5c0 9d0 9s0/6h0 7d0 7s0 Qd0 Qs0",
            "win": -20,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "Deux",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ks1 Kd3 Js4/3c0 3s0 6d1 6s2 8c4/4c0 4s0 Qc0 Jd2 Jc3",
            "win": -120,
            "playerId": "Deux"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ac0 As2 Kh3/3h0 3d0 7h1 7c4 9c4/4d0 Td0 Tc1 Th2 Ts3",
            "win": 140,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:48:22",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338155351": [
        {
            "inFantasy": false,
            "result": 60,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qc1 7h2 7d3 Td4",
            "rows": "As0 Kh2 Js3/2c0 5d0 4h1 5c4 Jh4/3h0 3s0 8s1 9s2 8c3",
            "win": -260,
            "playerId": "serverinme"
        },
        {
            "inFantasy": true,
            "result": 33,
            "playerName": "Deux",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "6h0 6d0 6c0/8h0 9h0 Tc0 Jd0 Qd0/3d0 3c0 4d0 4c0 4s0",
            "win": 75,
            "playerId": "Deux"
        },
        {
            "inFantasy": true,
            "result": 15,
            "playerName": "Worner",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Jc0 Ah0 Ad0/2h0 2d0 2s0 Qh0 Qs0/Th0 Ts0 Kd0 Kc0 Ks0",
            "win": 185,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:50:07",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338155505": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "serverinme",
            "orderIndex": 2,
            "hero": true,
            "dead": "3d1 8d2 2d3 Ad4",
            "rows": "Kh1 Kd2 7c3/4h0 6d0 9c1 6h3 8s4/5d0 5c0 Jc0 Jh2 7s4",
            "win": -75,
            "playerId": "serverinme"
        },
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "Deux",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "8h0 8c0 Jd0/6c0 7d0 Tc0 Ts0 As0/2h0 2c0 4d0 4c0 4s0",
            "win": 150,
            "playerId": "Deux"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc1 Ks3 9s4/2s0 3h0 3s1 Th3 Ac4/9d0 Qh0 Qs0 Qd2 Qc2",
            "win": -75,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:52:20",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338155684": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "6d1 2c2 8c3 4d4",
            "rows": "Ad0 Ah1 7h2/5c0 8s0 4s1 5s4 8d4/Td0 Qh0 Kc2 Jd3 Ac3",
            "win": -5,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qs0 As3 Qd4/7s1 Js1 2d2 Jh2 2h3/6c0 9c0 Tc0 Jc0 Qc4",
            "win": 5,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:54:03",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338155828": [
        {
            "inFantasy": true,
            "result": 39,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "3h0 Qc0 Ah0",
            "rows": "6d0 6c0 6s0/8h0 9d0 Td0 Jd0 Qh0/3s0 5s0 8s0 Ts0 Qs0",
            "win": 35,
            "playerId": "serverinme"
        },
        {
            "inFantasy": true,
            "result": 33,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "4c0 7c0 7s0/2d0 3d0 5d0 8d0 Kd0/4h0 5h0 6h0 Jh0 Kh0",
            "win": -35,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:54:50",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338155888": [
        {
            "inFantasy": true,
            "result": -6,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h0",
            "rows": "7c0 Js0 Ah0/3s0 5h0 5c0 5s0 6c0/9h0 9d0 Th0 Tc0 Ts0",
            "win": 40,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "6d3 6s3 Ad4/Jd1 Jc1 9c2 Td2 8s4/3h0 7h0 Jh0 Qh0 Qd0",
            "win": -40,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:55:32",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338155940": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "5d1 Ad2 9d3 Ks4",
            "rows": "Kd0 Kh3 Ah3/3c0 2c1 9c2 Qc2 5c4/7h0 7s0 Js0 Jd1 3d4",
            "win": 0,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qd0 Qs0 4s4/Kc0 2d1 Td1 Tc3 Ts3/5h0 6h0 3h2 Qh2 6s4",
            "win": 0,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:57:19",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338156044": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "3c1 5c2 2d3 Td4",
            "rows": "Kc0 6c2 4s4/Ts0 Qd1 9c2 8c3 Tc3/2h0 4h0 Jh0 5h1 3d4",
            "win": -50,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Th0 8h1 6s4/2c0 Jc1 Qh2 Ac3 7c4/7s0 9s0 Ks0 3s2 2s3",
            "win": 50,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:59:14",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338156146": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "8h1 4s2 5c3 9d4",
            "rows": "Kc0 Jh3 Jc4/2h0 2s0 6d1 6c1 6h4/Td0 Tc0 Th2 Ts2 7c3",
            "win": 80,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ks0 Ac2 Ad4/2c0 3h0 3c1 3d3 Ah4/4d0 6s0 5d1 8s2 7h3",
            "win": -80,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:00:46",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338156243": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "8c1 2s2 4d3 Qd4",
            "rows": "Ks0 Kc3 Jc4/6d0 2d1 8d1 2c2 4h4/3h0 5h0 Kh0 Th2 Jh3",
            "win": -100,
            "playerId": "serverinme"
        },
        {
            "inFantasy": true,
            "result": 24,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Jd0 Js0 Ac0/3d0 4s0 5d0 6h0 7s0/7h0 8h0 9h0 Qh0 Ah0",
            "win": 100,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:01:35",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338156299": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "6c1 4s2 Tc3 Th4",
            "rows": "Jh1 Qd3 Qs4/3d0 5s0 2h1 5c2 3h3/8h0 8s0 9s0 9d2 Kh4",
            "win": -70,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ah0 Td3 As4/3s0 Jc0 8d1 8c1 3c4/6d0 Kd0 6s2 Kc2 Ks3",
            "win": 70,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:03:12",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338156426": [
        {
            "inFantasy": true,
            "result": 18,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "8d0",
            "rows": "9s0 Ts0 Ks0/2c0 4c0 9c0 Tc0 Qc0/7d0 7c0 Ad0 Ac0 As0",
            "win": -60,
            "playerId": "serverinme"
        },
        {
            "inFantasy": true,
            "result": 24,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qh0 Qd0 Ah0/5h0 5d0 5s0 6d0 6c0/3d0 3s0 Jd0 Jc0 Js0",
            "win": 60,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:04:11",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338156511": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "Ad1 3c2 4d3 7h4",
            "rows": "Qd0 Kd1 Kh4/2h0 5c0 3h1 2c2 5h2/6h0 6s0 6c3 9h3 9c4",
            "win": 40,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Ks2 Qc3/Ac0 As0 7d2 5s3 2s4/Td0 Tc0 4h1 4c1 3s4",
            "win": -40,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:06:03",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338156658": [
        {
            "inFantasy": true,
            "result": 9,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "2d0 2s0",
            "rows": "6d0 Th0 Ts0/4c0 5d0 6h0 7c0 8c0/4s0 7s0 Js0 Qs0 Ks0",
            "win": 5,
            "playerId": "serverinme"
        },
        {
            "inFantasy": true,
            "result": 3,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "8h0 8s0 9h0/9s0 Tc0 Jc0 Qh0 Kd0/2c0 5c0 6c0 Qc0 Ac0",
            "win": -5,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:07:06",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338156738": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "4d1 9h2 Ts3 5c4",
            "rows": "Td2 Ac3 9c4/7h0 7d0 2c1 8c2 Js4/Kh0 Kd0 Kc0 6c1 Qh3",
            "win": -25,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Th1 9s3 6s4/4h0 4c0 8s0 3s1 3c2/6d0 9d0 2d2 5d3 3d4",
            "win": 25,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:08:59",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338156898": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "Td1 5d2 Jh3 3c4",
            "rows": "Ad0 8s2 8c4/2h0 Qs0 7h1 Qh1 2d2/9c0 Kc0 6d3 9d3 9h4",
            "win": -20,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qc0 Kh1 Kd3/5s0 8h0 5h1 7s2 8d3/4d0 Jd0 4h2 6h4 Js4",
            "win": 20,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:10:45",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338157040": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jh1 5c2 Ts3 4s4",
            "rows": "Qc0 9h2 4c4/6h0 Kc0 Ah1 2s2 4h4/2d0 3d0 7d1 6d3 8d3",
            "win": -30,
            "playerId": "serverinme"
        },
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kh0 Ad0 As0/2h0 3h0 3c0 8c0 8s0/5d0 7h0 7c0 7s0 Td0",
            "win": 30,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:11:41",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338157126": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "5c1 7s2 Td3 5s4",
            "rows": "2s1 Ad3 Jh4/4c0 6c0 8s0 4d2 8h3/3h0 9h0 9c1 3s2 5d4",
            "win": -95,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qh0 Qc3 2d4/3d0 Th1 Ts1 6h2 6s2/7h0 Kh0 Ks0 7d3 Kc4",
            "win": 95,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:13:25",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338157252": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "2s1 3h2 8h3 7s4",
            "rows": "Kc0 Ah3 9d4/4h0 4c0 6s1 6c3 7h4/8c0 Td0 Js1 8d2 Th2",
            "win": -95,
            "playerId": "serverinme"
        },
        {
            "inFantasy": true,
            "result": 33,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qh0 Ad0 Ac0/2c0 3d0 3c0 3s0 5h0/9c0 Ts0 Jh0 Qd0 Ks0",
            "win": 95,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:14:22",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338157324": [
        {
            "inFantasy": false,
            "result": 42,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "2c1 7d2 Ac3 7s4",
            "rows": "Ad0 As2 9d4/2d0 6h0 6s2 2h3 3h4/Th0 Qs0 Qh1 Qc1 Tc3",
            "win": 170,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 39,
            "playerName": "Deux",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kd0 Ks0 Ah3/3s0 7c1 8c2 3c4 9c4/5h0 5c0 Jh1 Js2 4s3",
            "win": -175,
            "playerId": "Deux"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "Worner",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kh0 Kc0 8s4/4c0 5s0 5d2 7h2 4h4/9s0 2s1 9h1 Jd3 Jc3",
            "win": 5,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:17:12",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338157523": [
        {
            "inFantasy": true,
            "result": -21,
            "playerName": "serverinme",
            "orderIndex": 2,
            "hero": true,
            "dead": "4s0 5h0 8h0",
            "rows": "Tc0 Ts0 Ah0/2h0 2d0 9h0 9d0 9c0/6d0 6c0 Jh0 Jd0 Js0",
            "win": 35,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "Deux",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "4h3 4c3 Ac4/6h1 6s1 2c2 2s2 5s4/4d0 7c0 7s0 Qh0 Qc0",
            "win": -75,
            "playerId": "Deux"
        },
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "3h0 3c0 3s0/8c0 Jc0 Kh0 Kd0 Kc0/5d0 7d0 8d0 Qd0 Ad0",
            "win": 40,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:18:34",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338157622": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "2s1 Tc2 7s3 Td4",
            "rows": "Ks0 Kh2 9c3/2h0 7d0 Ac2 Ah3 Jh4/3c0 3s0 Qc1 Qs1 Th4",
            "win": -25,
            "playerId": "serverinme"
        },
        {
            "inFantasy": true,
            "result": -9,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Jd0 Js0 Ad0/3d0 7h0 7c0 9h0 9s0/4d0 4c0 8h0 8d0 8c0",
            "win": 25,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:19:24",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338157690": [
        {
            "inFantasy": true,
            "result": 69,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "3s0 Qs0",
            "rows": "Kh0 Kd0 Ks0/3h0 4d0 5d0 6s0 7s0/2c0 3c0 Qc0 Kc0 Ac0",
            "win": 155,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 57,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qd3 As3 8c4/7d1 7c1 6d2 6c2 Jd4/2h0 4h0 5h0 6h0 8h0",
            "win": -155,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:20:10",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338157751": [
        {
            "inFantasy": true,
            "result": 0,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "6c0",
            "rows": "8d0 Td0 Tc0/7c0 Jh0 Js0 Qd0 Ah0/4s0 5s0 6s0 7s0 Ks0",
            "win": -40,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qc3 Qs3 9c4/Kd1 Kc1 8c2 Ac2 4h4/2d0 6d0 7d0 Jd0 Ad0",
            "win": 40,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:20:58",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338157813": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "9c1 6h2 7s3 Ah4",
            "rows": "Qd0 Ac2 9h4/Ad0 As0 2d1 Jc2 6s4/5h0 8h0 8c1 3c3 3s3",
            "win": -65,
            "playerId": "serverinme"
        },
        {
            "inFantasy": true,
            "result": 9,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "6d0 6c0 Kh0/3h0 3d0 5d0 5s0 Qc0/2h0 2s0 4h0 4d0 4s0",
            "win": 65,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:21:55",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338157895": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "6h1 Ad2 4h3 5c4",
            "rows": "Th1 7h3 Kd3/2s0 3d0 9h0 2c2 8c4/Jc0 Qc0 Jd1 Qs2 8d4",
            "win": -20,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "Deux",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ac0 7s3 7c4/5s0 Ts0 Kc1 Ah2 As2/2d0 Qd0 4d1 Td3 Tc4",
            "win": -80,
            "playerId": "Deux"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "Worner",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kh2 9d3 Qh4/3h0 6d0 5d1 6c2 7d4/4s0 8s0 Js0 9s1 Ks3",
            "win": 100,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:24:47",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338158150": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "serverinme",
            "orderIndex": 2,
            "hero": true,
            "dead": "Ts1 5s2 Qc3 Ah4",
            "rows": "Qs0 Jd3 Qd3/2c0 4c1 9c1 9d2 Kc4/3h0 7h0 8h0 2h2 6s4",
            "win": -95,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 66,
            "playerName": "Deux",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ac0 As2 Kh4/3d0 7c0 Td1 3s3 7s3/5h0 Qh0 9h1 Jh2 4h4",
            "win": 190,
            "playerId": "Deux"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Th2 Kd2 4s4/3c0 4d0 6h0 2d3 5d3/8s0 9s0 7d1 Tc1 5c4",
            "win": -95,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:27:16",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338158353": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "3c1 8c2 Ad3 Ah4",
            "rows": "Kc0 Ac2 3s3/4s0 Tc0 7c1 4c2 6h4/9d0 Jd0 Qh1 8s3 2s4",
            "win": -155,
            "playerId": "serverinme"
        },
        {
            "inFantasy": true,
            "result": 57,
            "playerName": "Deux",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qs0 Kh0 Kd0/Th0 Js0 Qc0 Ks0 As0/5d0 5c0 5s0 9h0 9c0",
            "win": 205,
            "playerId": "Deux"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qd0 8d4 9s4/2d0 6s0 6c2 7h3 7s3/4h0 8h0 3h1 Jh1 2h2",
            "win": -50,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:30:34",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338158598": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "4d1 9s2 7d3 6c4",
            "rows": "Kh0 Qd3 9h4/Jh0 Js1 3d2 5s2 7h4/3c0 4c0 5d0 2c1 6d3",
            "win": 80,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "Deux",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ah0 As1 Qh3/3s0 5h0 2s3 7s4 Ad4/Jc0 Qc0 7c1 Kc2 Ac2",
            "win": -40,
            "playerId": "Deux"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "Worner",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "9d1 Kd2 3h4/2h0 4s0 2d2 8h3 8d3/8c0 9c0 Ts0 6h1 Jd4",
            "win": -40,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:33:42",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338158826": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "serverinme",
            "orderIndex": 2,
            "hero": true,
            "dead": "Ah1 8c2 3c3 6s4",
            "rows": "Qd0 8s3 8d4/2h0 Kc1 Ks1 4s2 Jd4/7s0 8h0 9c0 6h2 5h3",
            "win": -30,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "Deux",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kh0 Tc3 9s4/2d0 5s0 Ad1 Ac1 As4/4h0 7h0 Th2 Qh2 Jh3",
            "win": -5,
            "playerId": "Deux"
        },
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Js0 Qs3 Kd4/3s0 6d0 5d2 2s3 4d4/5c0 7c0 6c1 Jc1 2c2",
            "win": 35,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:36:33",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338159010": [
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "3c1 8s2 5s3 9s4",
            "rows": "Kc0 5c3 Ac4/6c0 7h0 4d1 7d2 Td4/Jh0 Qs0 Tc1 8d2 8h3",
            "win": 35,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "Deux",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ad0 As0 Js1/8c0 6d2 6h3 2d4 3h4/Qh0 Qc0 Ks1 Ts2 Kh3",
            "win": -60,
            "playerId": "Deux"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "9h2 2s3 3d3/2h0 4c0 3s1 5h2 Kd4/7s0 9d0 Th0 Jc1 Jd4",
            "win": 25,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:39:48",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338159242": [
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "4d1 7s2 2c3 Qc4",
            "rows": "Ks1 Kd2 9c3/9s0 Jc1 Th2 Qd3 8c4/5h0 9h0 Qh0 Ah0 6s4",
            "win": -65,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Deux",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ad0 Jh3 Kh4/5d0 7c0 6c1 7h2 3s4/4c0 4s0 Tc1 Js2 4h3",
            "win": 20,
            "playerId": "Deux"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "Worner",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "6h3 6d3 9d4/2s0 5s0 2d1 Td2 Ts2/3h0 3d0 8d0 3c1 Qs4",
            "win": 45,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:42:59",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338159459": [
        {
            "inFantasy": false,
            "result": 66,
            "playerName": "serverinme",
            "orderIndex": 2,
            "hero": true,
            "dead": "Th1 3h2 8d3 4s4",
            "rows": "Ah2 5s4 As4/4d0 7d0 7c1 2c3 2s3/6s0 9s0 Ts0 8s1 7s2",
            "win": 300,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "Deux",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qs1 3d3 Kd3/2h0 4h1 9h2 Jh2 6h4/3c0 4c0 5c0 6c0 Tc4",
            "win": -150,
            "playerId": "Deux"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qd1 Qc1 Kc3/3s0 5h0 5d2 9d3 7h4/8h0 8c0 Jc0 Jd2 Kh4",
            "win": -150,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:45:58",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338159651": [
        {
            "inFantasy": true,
            "result": 39,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "2s0 4c0 7c0",
            "rows": "9c0 Ah0 As0/8h0 9d0 Td0 Js0 Qc0/2d0 4d0 5d0 Jd0 Qd0",
            "win": 150,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 36,
            "playerName": "Deux",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qs1 Jh3 Ad4/3s0 4h0 5c1 5s2 3c3/8s0 Tc0 Ts0 Th2 6d4",
            "win": -100,
            "playerId": "Deux"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kh0 Ks1 Qh4/4s0 6h0 6c1 7h2 7d4/3h0 3d0 Jc2 8d3 8c3",
            "win": -50,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:48:34",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338159797": [
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "8d1 9c2 8c3 5h4",
            "rows": "As0 Kd1 Ts4/2c0 6c0 2s1 4c2 9h4/7h0 7s0 Qd2 7d3 Jd3",
            "win": -50,
            "playerId": "serverinme"
        },
        {
            "inFantasy": true,
            "result": 24,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Js0 Qc0 Qs0/2d0 4d0 5d0 9d0 Ad0/3h0 4h0 Jh0 Kh0 Ah0",
            "win": 50,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:49:24",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338159846": [
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "serverinme",
            "orderIndex": 2,
            "hero": true,
            "dead": "Qd1 7h2 Qc3 3h4",
            "rows": "Ks0 Ac1 Qs4/4d0 6c0 3s2 Ts2 3c3/Jc0 Js0 2h1 2d3 9c4",
            "win": 25,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "Deux",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kc0 4c3 Jd4/As0 5d1 7d1 5s2 7s2/6d0 6s0 Qh0 6h3 Td4",
            "win": 35,
            "playerId": "Deux"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kh0 Kd1 9s4/Ah0 3d1 5c2 2c3 4s3/7c0 8s0 9d0 Th2 Tc4",
            "win": -60,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:52:09",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338159991": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qh1 9c2 3c3 2c4",
            "rows": "Ac0 Kh3 Td4/4h0 Ts0 5h1 5s2 Tc3/6d0 Kd0 9d1 8d2 Qd4",
            "win": 40,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "Deux",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ah2 Qc3 Ad3/4d0 6s0 5d1 7c2 4c4/3h0 3d0 Js0 Jc1 Jh4",
            "win": -115,
            "playerId": "Deux"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "As3 8h4 8c4/2h0 6h0 2d2 6c2 7h3/4s0 Qs0 Ks0 8s1 9s1",
            "win": 75,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:55:02",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338160131": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "3c1 Ac2 9c3 Kc4",
            "rows": "3d3 Jc3 3s4/5d0 8d0 8c0 6c1 5h4/4h0 Th0 9h1 4c2 Ts2",
            "win": 30,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "Deux",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kd0 Tc2 Qh3/2s0 7d0 As1 2d3 4d4/8h0 8s0 5s1 9s2 9d4",
            "win": -30,
            "playerId": "Deux"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:56:50",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338160221": [
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "6h1 Jd2 8c3 8h4",
            "rows": "Qd1 Ah3 6d4/3d0 3c0 4h0 9h2 3h3/2s0 7s0 Js1 8s2 4d4",
            "win": -80,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "Deux",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ks0 Kd2 Ac4/2d0 5d0 4c1 5s2 4s4/Ts0 Jh0 8d1 7h3 9d3",
            "win": 80,
            "playerId": "Deux"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:58:16",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338160292": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "9h1 7d2 Qs3 3c4",
            "rows": "Th1 9s4 As4/3s0 4h0 2h1 Jh2 Jd2/7c0 Jc0 Kc0 7s3 Ks3",
            "win": -125,
            "playerId": "serverinme"
        },
        {
            "inFantasy": true,
            "result": 27,
            "playerName": "Deux",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "9c0 Qd0 Qc0/2d0 4d0 5d0 8d0 Td0/3h0 6h0 8h0 Qh0 Ah0",
            "win": 125,
            "playerId": "Deux"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:59:03",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338160332": [
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "2d1 9c2 Qc3 5d4",
            "rows": "Kh0 Kc1 Ac3/9h0 3c1 9d2 4c3 4h4/Tc0 Ts0 Js0 Jh2 3d4",
            "win": 5,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 36,
            "playerName": "Deux",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ad0 As3 Qs4/2c0 Jd0 2s1 7c2 7s3/5s0 6h0 8s1 7d2 4s4",
            "win": 60,
            "playerId": "Deux"
        },
        {
            "inFantasy": false,
            "result": 45,
            "playerName": "Mickier",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Jc0 Ks3 3h4/6s0 6c1 4d2 3s3 8d4/5h0 Qh0 Ah0 Th1 7h2",
            "win": -65,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 00:01:55",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338160513": [
        {
            "inFantasy": true,
            "result": 60,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "7h0 9h0",
            "rows": "Kd0 Kc0 Ad0/4h0 4c0 5d0 5c0 Qc0/2s0 3s0 7s0 8s0 Ks0",
            "win": -30,
            "playerId": "serverinme"
        },
        {
            "inFantasy": true,
            "result": 99,
            "playerName": "Deux",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qh0 Qd0 Qs0/7d0 8c0 9s0 Th0 Js0/6h0 6c0 6s0 9d0 9c0",
            "win": 215,
            "playerId": "Deux"
        },
        {
            "inFantasy": false,
            "result": 69,
            "playerName": "Mickier",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ac3 As3 6d4/2d1 2c1 5h2 8d2 3c4/8h0 Tc0 Ts0 Jh0 Jc0",
            "win": -185,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 00:03:34",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338160626": [
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "5h1 4h2 8s3 2h4",
            "rows": "Kc0 Kd2 Tc4/8c0 9h0 9d2 4c3 8h3/4d0 6d0 7d1 Jd1 Qd4",
            "win": -60,
            "playerId": "serverinme"
        },
        {
            "inFantasy": true,
            "result": -27,
            "playerName": "Deux",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Js0 Qs0 Ad0/3h0 6h0 7c0 7s0 9c0/Th0 Jh0 Qh0 Kh0 Ah0",
            "win": 60,
            "playerId": "Deux"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 00:04:26",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338160696": [
        {
            "inFantasy": true,
            "result": -18,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "3h0 5h0",
            "rows": "Qc0 Qs0 Ah0/7h0 7s0 8d0 8s0 Jc0/2c0 2s0 4d0 4c0 4s0",
            "win": -10,
            "playerId": "serverinme"
        },
        {
            "inFantasy": true,
            "result": -24,
            "playerName": "Deux",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "5c0 Jd0 As0/4h0 6h0 Jh0 Qh0 Kh0/8h0 8c0 Th0 Td0 Tc0",
            "win": 10,
            "playerId": "Deux"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 00:05:07",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338160747": [
        {
            "inFantasy": false,
            "result": 51,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h1 4s2 Ah3 2s4",
            "rows": "Qs2 Qc4 Kd4/7d0 9s0 8d1 5s3 6h3/2c0 Jc0 Ac0 5c1 9c2",
            "win": 135,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "Deux",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ad1 5d3 3h4/3s0 Qh0 6d2 Kh3 Ks4/Th0 Td0 Ts0 Jd1 Tc2",
            "win": 25,
            "playerId": "Deux"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "Mickier",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Qd3 5h4/7c1 7s1 2d2 4h2 4c4/8c0 8s0 9h0 9d0 7h3",
            "win": -160,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 00:07:51",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338160928": [
        {
            "inFantasy": true,
            "result": 39,
            "playerName": "serverinme",
            "orderIndex": 2,
            "hero": true,
            "dead": "4d0",
            "rows": "Ks0 Ah0 As0/9h0 Tc0 Ts0 Qh0 Qd0/3c0 3s0 5h0 5c0 5s0",
            "win": 125,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 42,
            "playerName": "Deux",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ad3 4h4 4s4/2d0 3d0 7s1 3h2 7d2/7c0 8h0 9c0 6d1 Td3",
            "win": -140,
            "playerId": "Deux"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qc1 Kh1 Kd4/2h0 4c0 2s2 Th2 2c3/8s0 Jd0 Js0 6c3 Jc4",
            "win": 15,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 00:10:07",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338161096": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "5h1 9c2 4s3 Tc4",
            "rows": "Qs1 Ks3 Kc4/Jh0 Js0 Th1 Jc2 9d4/3c0 4d0 5s0 2c2 As3",
            "win": 20,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "Deux",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qd0 Qc1 3d2/6d0 Ts0 5d1 Kd3 5c4/4h0 7h0 8c2 7s3 6c4",
            "win": -135,
            "playerId": "Deux"
        },
        {
            "inFantasy": true,
            "result": -21,
            "playerName": "Mickier",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "9s0 Td0 Ac0/3h0 6h0 9h0 Kh0 Ah0/7d0 7c0 8h0 8d0 8s0",
            "win": 115,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 00:12:36",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338161275": [
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "6c0 8c0",
            "rows": "Jh0 Jd0 Ac0/2d0 4d0 7d0 9d0 Td0/3s0 4s0 8s0 Ts0 As0",
            "win": 115,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "6d3 6s3 Ks4/Th1 Tc1 7h2 7s2 4c4/8h0 8d0 Qh0 Qs0 Ad0",
            "win": -115,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 00:13:31",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338161344": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "serverinme",
            "orderIndex": 2,
            "hero": true,
            "dead": "2s1 6d2 3d3 6h4",
            "rows": "Ad3 3c4 9d4/5h0 5d0 3h1 5c2 4d3/8c0 9c0 Qc0 4c1 Jc2",
            "win": 10,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 54,
            "playerName": "Deux",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Ks2 Qh4/2h0 Ac0 Ah2 Ts3 Jd3/7d0 8s0 7s1 8h1 Kd4",
            "win": 30,
            "playerId": "Deux"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Js2 2c3 5s3/8d0 Qd0 2d2 6s4 7c4/7h0 Th0 Kh0 4h1 9h1",
            "win": -40,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 00:15:38",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338161489": [
        {
            "inFantasy": false,
            "result": 36,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "7h1 Qd2 Ah3 8s4",
            "rows": "Ad0 Qc1 As2/3d0 2d1 4s2 3h3 2c4/5h0 5c0 Jc0 6d3 5s4",
            "win": 40,
            "playerId": "serverinme"
        },
        {
            "inFantasy": true,
            "result": 45,
            "playerName": "Deux",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Tc0 Js0 Ac0/4d0 6c0 7d0 9c0 9s0/2h0 4h0 6h0 8h0 Kh0",
            "win": -55,
            "playerId": "Deux"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "Mickier",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Kd1 Ts3/9h0 Jd0 9d1 Jh2 8d3/7s0 Qs0 7c2 Td4 Qh4",
            "win": 15,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 00:17:44",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338161657": [
        {
            "inFantasy": true,
            "result": 81,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "3c0 4h0 Ad0",
            "rows": "9d0 9c0 9s0/2s0 3s0 6s0 Ts0 Js0/8h0 8d0 8s0 Qh0 Qd0",
            "win": 245,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 57,
            "playerName": "Deux",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "7d3 7s3 As4/2h1 3h1 4d2 5h2 6h4/2c0 4c0 6c0 7c0 Jc0",
            "win": -165,
            "playerId": "Deux"
        },
        {
            "inFantasy": true,
            "result": 42,
            "playerName": "Mickier",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kd0 Ah0 Ac0/9h0 Th0 Td0 Qc0 Qs0/5d0 5c0 5s0 Jh0 Jd0",
            "win": -80,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 00:18:49",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338161751": [
        {
            "inFantasy": true,
            "result": 0,
            "playerName": "serverinme",
            "orderIndex": 2,
            "hero": true,
            "dead": "4d0",
            "rows": "Jd0 Kd0 Kc0/2h0 9h0 9d0 Tc0 Ts0/8s0 Qd0 Qc0 Qs0 Ac0",
            "win": 0,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "Deux",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ks1 6h3 8h4/6s0 7c0 7d1 6d2 8c3/2d0 2c0 Js0 Jh2 3c4",
            "win": -60,
            "playerId": "Deux"
        },
        {
            "inFantasy": false,
            "result": 36,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qh1 Ah3 Ad4/5s0 9s0 3s1 9c2 3h3/4c0 4s0 Jc0 4h2 8d4",
            "win": 60,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 00:20:54",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338161917": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "2d1 4s2 4d3 9d4",
            "rows": "7s2 8d3 Ad4/5h0 Th0 Qh2 5s3 Ts4/3c0 7c0 Kc0 5c1 Qc1",
            "win": -75,
            "playerId": "serverinme"
        },
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "Mickier",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Jd0 Jc0 Ac0/2h0 3h0 7h0 8h0 Kh0/6s0 8s0 9s0 Js0 Ks0",
            "win": 75,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 00:21:56",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338162014": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "5h1 5s2 4h3 3d4",
            "rows": "As0 Ts3 Qs4/7h0 9d0 Jh1 7c3 2s4/2c0 Qc0 3c1 2h2 Qd2",
            "win": -150,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "Deux",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qh1 Jc3 Ad4/5c0 6c0 3h2 5d2 3s3/9h0 9c0 9s0 Th1 Ks4",
            "win": -90,
            "playerId": "Deux"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "Mickier",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Tc2 Ac2 Kd4/6d0 7d0 6h1 6s1 7s3/8h0 Kh0 Kc0 8s3 8c4",
            "win": 240,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 00:24:27",
    "roomId": "41b-1d1a0f20"
}


