{
    "stakes": 10,
    "handData": {"338150004": [
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "5c1 Kh2 9h3 6c4",
            "rows": "Kc0 Ks0 6h4/Jc0 Th1 Tc1 Jh2 8s3/8d0 Qd0 Kd2 Jd3 5d4",
            "win": 150,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "Santhoshkumarmu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "8c3 Qh3 Ac4/7c0 7s1 3s2 9s2 6d4/2d0 4s0 5h0 Ah0 3h1",
            "win": -270,
            "playerId": "Santhoshkumarmu"
        },
        {
            "inFantasy": false,
            "result": -30,
            "playerName": "Worner",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "7h1 2c4 9c4/Td0 4d1 7d2 3d3 Ad3/2s0 6s0 Js0 Qs0 As2",
            "win": 120,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 21:51:26",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338150261": [
        {
            "inFantasy": true,
            "result": 39,
            "playerName": "serverinme",
            "orderIndex": 2,
            "hero": true,
            "dead": "4s0 8d0",
            "rows": "Td0 Tc0 Ad0/3d0 3s0 6h0 6c0 6s0/7h0 7s0 9d0 9c0 9s0",
            "win": 380,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Santhoshkumarmu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qh1 Kh3 Kd3/Ah0 As0 Ac1 7d2 8h4/5s0 Js0 Ks0 Qs2 Qc4",
            "win": -230,
            "playerId": "Santhoshkumarmu"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ts0 2s2 8c4/5h0 7c0 4c1 3h3 Jc4/Jd0 Qd0 5d1 2d2 4d3",
            "win": -150,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 21:53:55",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338150504": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "4d1 Qd2 Qc3 Kh4",
            "rows": "Kc1 Ks1 Ac3/6h0 7d0 5d2 6s3 7c4/8d0 8c0 9c0 2c2 4c4",
            "win": -120,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qh0 5c2 6d3/3d0 4s1 9h1 Tc4 Kd4/Th0 Td0 Jd0 Jc2 Js3",
            "win": 120,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 21:55:43",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338150655": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "Tc1 3s2 Jh3 Td4",
            "rows": "Kc0 Ks0 Qc3/5h0 4c1 5d1 4h2 2h4/2d0 Qd0 4d2 6d3 Kd4",
            "win": 50,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kh0 9d4 9s4/7h0 9h2 9c2 4s3 7s3/6s0 8s0 Js0 5s1 Qs1",
            "win": -50,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 21:57:21",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338150747": [
        {
            "inFantasy": true,
            "result": -15,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "3d0 5d0",
            "rows": "9d0 Td0 Tc0/2c0 5c0 7c0 8c0 Jc0/2h0 9h0 Jh0 Qh0 Ah0",
            "win": 90,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ad3 Ac3 Kh4/8d1 8s1 7d2 7s2 6c4/4d0 4c0 5h0 Kd0 Kc0",
            "win": -90,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 21:58:10",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338150794": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "Tc1 8c2 2d3 2s4",
            "rows": "Th1 9s3 Qs4/5h0 Js0 7s2 Jh3 3h4/5d0 6d0 8d0 9d1 Ad2",
            "win": -120,
            "playerId": "serverinme"
        },
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Ac0 As0/3d0 3c0 3s0 4s0 7d0/2h0 6h0 7h0 8h0 9h0",
            "win": 120,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 21:59:02",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338150843": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "7s1 8c2 5h3 8h4",
            "rows": "Th3 As3 5s4/3d0 3c1 2d2 6s2 Qd4/9d0 Td0 Jc0 Qc0 8s1",
            "win": 80,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ad0 Ah1 3h2/4h0 8d0 2s2 4c4 9s4/9h0 9c0 Kh1 5d3 Kc3",
            "win": -80,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:00:58",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338150972": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "5h1 3c2 4h3 Th4",
            "rows": "Ks1 Td3 As4/8h0 2c2 7h2 Jh3 7s4/2h0 3d0 4d0 5c0 6s1",
            "win": 80,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kd0 6c3 Qd3/3s0 8d0 5s1 3h2 2s4/9h0 9s0 7d1 7c2 Ad4",
            "win": -80,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:02:53",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338151139": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "Kd1 6h2 6d3 7s4",
            "rows": "Td2 Ad2 7d4/2d0 4h0 Jh1 Jd1 Kh4/3s0 6s0 Js0 2s3 8s3",
            "win": 100,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "As0 Ah3 2h4/3h0 3d0 Ts1 Qh3 5d4/4c0 Kc0 9c1 4d2 Ks2",
            "win": -100,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:04:42",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338151316": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "2s1 5c2 3h3 Qh4",
            "rows": "5s3 Ad3 Ts4/3s0 6d0 6s0 4h1 3d2/7d0 7c0 Jc1 9d2 Th4",
            "win": 0,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kh0 Kd1 4d3/2c0 6c0 4c1 5h2 3c4/8d0 Jh0 Tc2 Qd3 7s4",
            "win": 0,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:06:26",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338151482": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "6c1 7h2 Ac3 9d4",
            "rows": "Ad0 Ah2 3d4/3h0 4d0 5s0 7c3 2s4/Jc0 8s1 Jh1 Qs2 6h3",
            "win": -60,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc0 8h3 Tc4/3c0 As0 Qh2 Qc2 2h3/7d0 7s0 9h1 9c1 Td4",
            "win": 60,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:08:12",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338151656": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "Th1 2c2 2h3 Tc4",
            "rows": "Qs0 Qd3 9s4/4h0 5h0 6h1 4c2 3s4/3d0 8d0 7d1 2d2 Td3",
            "win": 0,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ks0 Kh1 4d4/As0 8s1 4s2 Ac3 8c4/7h0 7s0 Jc0 Ts2 Jd3",
            "win": 0,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:10:04",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338151844": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "9h1 8d2 4s3 6d4",
            "rows": "Ah0 Kc1 9d4/3h0 5d0 6c2 7s2 3c3/Tc0 Qs0 Qc1 Ad3 5c4",
            "win": -90,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ac0 Kd1 3s4/6s0 8s0 4d2 7d3 5s4/2h0 Jh0 5h1 Qh2 4h3",
            "win": 90,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:11:50",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338152029": [
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "6s1 7d2 4h3 Tc4",
            "rows": "Kc0 5c3 Ks4/7h0 7c0 6h1 6d1 Th2/8s0 9h0 9c2 8c3 Ac4",
            "win": -10,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": -27,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kh1 9s2 8d3/7s0 Ts0 4d1 Ah2 3s3/2h0 2d0 Jh0 2c4 2s4",
            "win": 10,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:13:29",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338152202": [
        {
            "inFantasy": true,
            "result": 27,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "3h0 6c0",
            "rows": "Qd0 Qs0 Ac0/8h0 9c0 Jd0 Kh0 Ks0/5h0 5d0 5s0 Td0 Tc0",
            "win": 190,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ah3 As3 2c4/2d1 2s1 4c2 6h2 3c4/6d0 8d0 8c0 9h0 9s0",
            "win": -190,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:14:23",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338152295": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "serverinme",
            "orderIndex": 2,
            "hero": true,
            "dead": "Td1 6s2 Tc3 7s4",
            "rows": "As0 Th3 Ks3/7h0 7c0 3s1 9h2 Qc4/4d0 4c0 Jd1 4h2 2h4",
            "win": -110,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 54,
            "playerName": "nope112",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qs0 6c3 Qh4/Jh0 2s1 5s1 5h3 Jc4/3d0 7d0 8d0 6d2 Qd2",
            "win": 340,
            "playerId": "nope112"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ad0 Ac3 2d4/8h0 Ts0 8s1 6h3 8c4/5c0 Kc0 9c1 5d2 Kd2",
            "win": -230,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:16:39",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338152517": [
        {
            "inFantasy": false,
            "result": -27,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "6h1 8h2 Jc3 Js4",
            "rows": "Kd0 Ks1 Ac4/3h0 4c2 5s2 6c3 7s3/9s0 Tc0 Jd0 8d1 7h4",
            "win": 50,
            "playerId": "serverinme"
        },
        {
            "inFantasy": true,
            "result": -57,
            "playerName": "nope112",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "4s0 Th0 Kh0/2d0 4d0 9d0 Td0 Qd0/5h0 5d0 5c0 8c0 8s0",
            "win": 70,
            "playerId": "nope112"
        },
        {
            "inFantasy": false,
            "result": -24,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ah0 Kc1 Ad4/9c0 6s1 3c2 3s2 9h4/2h0 Qh0 Qs0 2s3 Jh3",
            "win": -120,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:18:47",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338152742": [
        {
            "inFantasy": true,
            "result": 87,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "6s0 8s0",
            "rows": "9h0 9c0 9s0/Jh0 Qh0 Qd0 Qc0 Kh0/2d0 2c0 2s0 Td0 Ts0",
            "win": 350,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 66,
            "playerName": "nope112",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Th3 Kd3 6d4/7d1 7c1 7h2 8d2 4s4/3c0 4d0 5h0 6h0 7s0",
            "win": -340,
            "playerId": "nope112"
        },
        {
            "inFantasy": true,
            "result": 51,
            "playerName": "Worner",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qs0 Kc0 Ks0/8h0 8c0 Tc0 Jd0 Jc0/2h0 Ah0 Ad0 Ac0 As0",
            "win": -10,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:20:00",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338152859": [
        {
            "inFantasy": true,
            "result": 33,
            "playerName": "serverinme",
            "orderIndex": 2,
            "hero": true,
            "dead": "4h0",
            "rows": "7d0 9h0 9s0/Ts0 Jc0 Qc0 Kd0 Ah0/6c0 6s0 8h0 8d0 8c0",
            "win": 250,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "nope112",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Jd3 Qd3 6h4/Jh1 Js1 4d2 4s2 Th4/2c0 3c0 7c0 9c0 Kc0",
            "win": -190,
            "playerId": "nope112"
        },
        {
            "inFantasy": true,
            "result": 12,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "5h0 5c0 9d0/3h0 7s0 Td0 Tc0 Qh0/2d0 2s0 Ad0 Ac0 As0",
            "win": -60,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:21:14",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338152978": [
        {
            "inFantasy": false,
            "result": 45,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "6d1 Qc2 2c3 Td4",
            "rows": "Ad0 Qh3 8d4/Js0 2h1 4s1 2d2 2s2/4c0 6h0 7d0 3h3 5h4",
            "win": -150,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "nope112",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ac0 Qs1 Ah3/6c0 6s0 4h1 3s2 4d4/8h0 8s0 Jd2 7s3 7h4",
            "win": -20,
            "playerId": "nope112"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ks1 Kd3 8c4/Ts0 Jh0 Th1 5d2 Jc2/9h0 9d0 9s0 3c3 3d4",
            "win": 170,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:24:22",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338153287": [
        {
            "inFantasy": false,
            "result": 42,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "8d1 3s2 4c3 6s4",
            "rows": "9d3 8c4 Jc4/5d0 5c1 Jh2 Jd2 7h3/2h0 3h0 9h0 Qh0 4h1",
            "win": -350,
            "playerId": "serverinme"
        },
        {
            "inFantasy": true,
            "result": 24,
            "playerName": "nope112",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qc0 Qs0 Ks0/6c0 8h0 Js0 Ah0 Ac0/7d0 7c0 7s0 9c0 9s0",
            "win": -100,
            "playerId": "nope112"
        },
        {
            "inFantasy": true,
            "result": 42,
            "playerName": "Worner",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qd0 Ad0 As0/2d0 2c0 2s0 6h0 6d0/Td0 Tc0 Ts0 Kh0 Kc0",
            "win": 450,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:26:38",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338153509": [
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "serverinme",
            "orderIndex": 2,
            "hero": true,
            "dead": "7c1 8c2 Jd3 8d4",
            "rows": "Ks1 8h2 3d4/4d0 6c0 5d1 Ad3 5c4/2h0 2d0 Qh0 Qs2 Qd3",
            "win": 110,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "nope112",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Kh3 Kd4/Jc1 Js1 Tc2 Ts2 As3/6s0 7d0 9s0 Th0 Ac4",
            "win": -260,
            "playerId": "nope112"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qc1 2c3 5s4/7s0 Td0 8s2 9c2 6d4/6h0 7h0 Jh0 9h1 Ah3",
            "win": 150,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:29:01",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338153735": [
        {
            "inFantasy": false,
            "result": 51,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qs1 Ts2 4h3 2s4",
            "rows": "Qc0 Qd1 5c4/5d0 Kh0 Ac2 Ah3 Qh4/8s0 9s0 8h1 2c2 2d3",
            "win": 170,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "nope112",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ad0 Kc2 Kd3/4s0 Td0 7h1 Tc3 6h4/3h0 3s0 3d1 2h2 As4",
            "win": -210,
            "playerId": "nope112"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ks1 5h3 Jh4/4c0 6d0 7d0 7s2 7c4/9h0 Th0 9c1 Jc2 9d3",
            "win": 40,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:31:45",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338153981": [
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jd0",
            "rows": "9c0 9s0 Ks0/3c0 4d0 5d0 6d0 7h0/5h0 8h0 Jh0 Qh0 Kh0",
            "win": 60,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "nope112",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ah3 4h4 4c4/3s0 5s0 2s1 4s2 Qs3/6c0 7c0 Kc0 Ac1 Qc2",
            "win": 130,
            "playerId": "nope112"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "Worner",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "7s0 Tc3 9h4/2c0 Jc0 2h2 5c2 2d4/9d0 Qd0 3d1 7d1 Ad3",
            "win": -190,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:34:06",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338154189": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qd1 7s2 Kd3 5s4",
            "rows": "Qs0 8h2 Kc4/3d0 Tc0 5h2 3h3 Ts3/6h0 Jh0 Jd1 Js1 2d4",
            "win": -100,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Th0 Kh4 Ac4/4s0 Ah2 Ad2 4d3 7h3/7c0 9c0 Qc0 6c1 8c1",
            "win": 100,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:35:53",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338154359": [
        {
            "inFantasy": false,
            "result": 60,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "Js1 Kh2 2s3 4c4",
            "rows": "As0 Kc1 Ks3/3h0 5s0 5c2 8c3 8d4/9h0 Tc0 9d1 9s2 Jd4",
            "win": 280,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "2Pac4life",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ad0 5d2 5h3/2c0 Jc0 7c1 6c2 6d3/Qh0 Qs0 4h1 4d4 Kd4",
            "win": -80,
            "playerId": "2Pac4life"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "Worner",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ts0 Ac2 2h4/4s0 7d0 3s1 7s1 3c2/6h0 8h0 7h3 9c3 Qd4",
            "win": -200,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:38:24",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338154570": [
        {
            "inFantasy": true,
            "result": 78,
            "playerName": "serverinme",
            "orderIndex": 2,
            "hero": true,
            "dead": "8s0 Kh0",
            "rows": "3d0 3c0 3s0/7s0 8d0 9d0 Tc0 Jd0/2h0 2d0 2s0 4c0 4s0",
            "win": 540,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "2Pac4life",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ac2 Kc3 5h4/5s0 7h0 6c1 7c1 7d2/9h0 9s0 Th0 8h3 Ts4",
            "win": -270,
            "playerId": "2Pac4life"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Jh0 Ah2 As3/8c0 Jc1 2c2 6h4 Qc4/6d0 Td0 Qd0 4d1 5d3",
            "win": -270,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:40:48",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338154771": [
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "8d0",
            "rows": "5d0 9d0 Ts0/2c0 5c0 7c0 8c0 Kc0/2h0 4h0 6h0 7h0 Ah0",
            "win": 180,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "2Pac4life",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "5s2 Qc3 Qs3/4d0 7s0 Jh1 Jd1 Js2/3d0 3c0 Tc0 9s4 Qh4",
            "win": -150,
            "playerId": "2Pac4life"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ks0 Kh1 Qd3/2d0 3h0 4c0 4s2 2s3/8s0 8h1 9c2 7d4 As4",
            "win": -30,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:43:05",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338154954": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qs1 Td2 Qc3 Ks4",
            "rows": "Ts0 As1 Th3/2c0 3c0 3d1 2h2 Kh4/5d0 7d0 6c2 8d3 Jc4",
            "win": -80,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Ac1 5h4/2d0 4d0 Kd2 4c3 7s4/6s0 7c0 9d1 5s2 8s3",
            "win": 80,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:44:53",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338155087": [
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "As1 2d2 5h3 9s4",
            "rows": "6d3 6h4 Kh4/3d0 7h0 Th1 Tc1 7c2/8h0 8d0 8s0 8c2 7s3",
            "win": 170,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ks2 Ad2 9c4/2s0 5c0 3c1 3s1 Kd4/4h0 4s0 Jc0 Qd3 Qs3",
            "win": -170,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:46:42",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338155222": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "8s1 Ks2 As3 8d4",
            "rows": "Ah1 Ad2 Qd3/3d0 6d0 7h0 7s2 5c4/2c0 Tc0 2s1 Kh3 4c4",
            "win": -130,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qc1 Qh2 Th3/2h0 5h0 2d1 8h2 8c4/4s0 Jd0 Jc0 9c3 Jh4",
            "win": 130,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:48:54",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338155401": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "3s1 3h2 Tc3 Kc4",
            "rows": "Qd1 9d3 9c3/6d0 8d0 5h1 6h2 Kd4/2c0 Jh0 Jd0 4d2 7s4",
            "win": -160,
            "playerId": "serverinme"
        },
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "6c0 7d0 Th0/9h0 Ts0 Jc0 Qs0 Kh0/4h0 4s0 Ah0 Ad0 As0",
            "win": 160,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:49:55",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338155483": [
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "Tc1 As2 Qs3 8h4",
            "rows": "Qh1 9h4 Ks4/5h0 6d0 2h1 Th3 Ts3/7c0 7s0 Js0 3h2 3s2",
            "win": -140,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Qd2 Kd4/3c0 Ad1 6c2 5d3 Ah3/4h0 4c0 9d0 9s1 8c4",
            "win": 140,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:51:44",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338155638": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "3h1 6d2 4h3 2c4",
            "rows": "Ks0 8c3 Kd4/7s0 9h1 9c1 7h2 6h3/5d0 5s0 Th0 5c2 9s4",
            "win": 20,
            "playerId": "serverinme"
        },
        {
            "inFantasy": true,
            "result": 0,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qd0 Qc0 Ah0/2s0 3d0 3s0 Tc0 Ts0/6s0 7d0 7c0 Jh0 Jd0",
            "win": -20,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:52:35",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338155701": [
        {
            "inFantasy": true,
            "result": 51,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "3c0 Ad0",
            "rows": "7h0 7c0 7s0/8s0 9d0 Tc0 Jh0 Qd0/3h0 4h0 5h0 9h0 Qh0",
            "win": 290,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 39,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ac3 As3 Td4/6d1 6c1 4s2 7d2 3s4/8d0 9c0 Jd0 Jc0 Ks0",
            "win": -290,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:53:20",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338155765": [
        {
            "inFantasy": true,
            "result": 33,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "4d0",
            "rows": "Qh0 Ah0 As0/5h0 5d0 8h0 8c0 Tc0/3h0 3d0 9s0 Kh0 Ks0",
            "win": 150,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qc3 Qs3 Kc4/Jh1 Jd1 2d2 2s2 Ts4/4h0 6c0 7s0 Td0 Kd0",
            "win": -150,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:54:04",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338155829": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "6s1 4c2 Th3 Jh4",
            "rows": "Jc2 Ad3 9s4/9d0 Ts0 9h1 9c1 2s3/4h0 6h0 7h0 3s2 2c4",
            "win": -130,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qh0 Jd1 Qs2/Kh0 Ks0 5d3 2d4 3h4/4d0 4s0 3d1 5h2 5s3",
            "win": 130,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:55:47",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338155957": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "7d1 2c2 4c3 3c4",
            "rows": "6s2 Qc2 Js3/Td0 Kd0 Qd1 2d3 3d4/6h0 9h0 Ah0 7h1 8h4",
            "win": -80,
            "playerId": "serverinme"
        },
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "6d0 Ac0 As0/2s0 5s0 7s0 8s0 Qs0/3h0 4h0 Jh0 Qh0 Kh0",
            "win": 80,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:56:38",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338156002": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ts1 9h2 Th3 6s4",
            "rows": "Qh0 Qc1 Js2/4s0 6h0 Ks1 Kh2 3h3/5d0 8d0 6c3 3d4 4h4",
            "win": -120,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Jd1 Kd3 3s4/2h0 2c0 9c1 4d3 8c4/7h0 7c0 7s0 5h2 5c2",
            "win": 120,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 22:58:25",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338156105": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "Ad1 Jd2 8h3 Ks4",
            "rows": "Qh0 6d3 Ts3/6s0 4s1 7s1 9s2 Js2/Jc0 Qc0 Kc0 4h4 Qd4",
            "win": -140,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "As0 2h4 3d4/7d0 9d0 8c1 5h3 6h3/Th0 Kh0 3h1 9h2 Jh2",
            "win": 140,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:00:16",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338156203": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qh1 5d2 Ac3 8c4",
            "rows": "As0 Qc2 Ah3/3d0 6c0 6d1 Tc2 7s4/8d0 Jh0 Js1 9h3 5h4",
            "win": -60,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kd0 2d1 2c2/3h0 Jd0 9c1 9d3 Td3/5s0 Qs0 Qd2 7h4 8s4",
            "win": 60,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:02:16",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338156358": [
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "4h1 Js2 Jc3 3s4",
            "rows": "Qc0 Kc2 Qd4/2d0 Ad0 2s1 7s2 7h3/6s0 8s0 8d1 Jh3 Jd4",
            "win": 130,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qs0 Ah2 Ac2/4s0 5d0 5h1 7d3 6c4/9h0 Tc0 Th1 Ks3 6d4",
            "win": -130,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:04:19",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338156523": [
        {
            "inFantasy": true,
            "result": 9,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "3s0",
            "rows": "6s0 Ah0 Ac0/5h0 6c0 7h0 8c0 9d0/2d0 5d0 Td0 Kd0 Ad0",
            "win": 150,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kh3 Ks3 Js4/Jh1 Jc1 6h2 6d2 7d4/4d0 4c0 Ts0 Qh0 Qc0",
            "win": -150,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:05:18",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338156601": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "Js1 2d2 6s3 Qs4",
            "rows": "Kc0 6c2 As4/Ad0 3d1 8s1 5c3 Ks3/2h0 7h0 Jh0 9h2 9s4",
            "win": -150,
            "playerId": "serverinme"
        },
        {
            "inFantasy": true,
            "result": 15,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "6h0 8d0 8c0/2c0 3s0 4c0 5s0 6d0/Ts0 Jc0 Qc0 Kh0 Ac0",
            "win": 150,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:06:15",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338156675": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jh1 7c2 Th3 3d4",
            "rows": "Kc0 Ad1 Td4/2c0 2s0 5c1 3s2 5s3/6h0 6s0 8d2 Qd3 Qc4",
            "win": -160,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "9h2 9c2 6d4/2d0 3h0 9d1 9s1 3c4/7h0 7d0 Tc0 7s3 Ts3",
            "win": 160,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:08:01",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338156817": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jc1 Ks2 6c3 6h4",
            "rows": "Ah0 8c2 5s3/2h1 Th1 As2 3h4 Qd4/3d0 Td0 Jd0 Kd0 5d3",
            "win": 100,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qc0 Qh2 Ac3/7c0 2s1 8d1 8s3 3s4/9h0 9c0 Ts0 9s2 6d4",
            "win": -100,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:09:44",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338156961": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "6h1 8d2 6d3 4c4",
            "rows": "Kc1 Ad3 5d4/3c0 5s0 Th0 5c1 6s4/7d0 Jd0 9c2 Jc2 7s3",
            "win": -130,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qh0 Qd3 Ks4/2s0 3h0 4s1 4h2 3s3/7c0 8c0 Ac1 Ah2 7h4",
            "win": 130,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:11:32",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338157113": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "5c1 6s2 3c3 8s4",
            "rows": "Js0 9c2 5d3/6d0 9d1 Jd1 Td2 3d3/2h0 8h0 Ah0 5h4 5s4",
            "win": -110,
            "playerId": "serverinme"
        },
        {
            "inFantasy": true,
            "result": 15,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "8d0 8c0 Ad0/4c0 4s0 6h0 7h0 7d0/Ts0 Jh0 Qc0 Kd0 As0",
            "win": 110,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:12:22",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338157174": [
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "4d1 8s2 2s3 5d4",
            "rows": "9s2 Td2 9d3/Tc0 Jh0 2d1 Jc1 6s4/3s0 Qh0 Qd0 2c3 7c4",
            "win": -110,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ah0 Ac3 5c4/3h0 3d0 Jd2 7s3 7d4/4c0 6c0 Kd1 Ks1 4h2",
            "win": 110,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:14:05",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338157297": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "8d1 5s2 2s3 4h4",
            "rows": "Kd0 Qc1 Ts4/Ad0 As0 7c3 9d3 Ah4/3h0 3d0 Td1 3c2 Th2",
            "win": -100,
            "playerId": "serverinme"
        },
        {
            "inFantasy": true,
            "result": 12,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "7d0 7s0 Ac0/9h0 Tc0 Jd0 Qd0 Kc0/4d0 4c0 4s0 6h0 6d0",
            "win": 100,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:15:07",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338157373": [
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "5d1 Js2 Jd3 5s4",
            "rows": "Kh1 Qd2 Ac3/2s0 4h0 4s0 Kd3 Tc4/7h0 9h0 6d1 7d2 Ks4",
            "win": 10,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "nope112",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qs1 8d3 6h4/8s0 Ah0 As0 9s2 Td2/4c0 5c0 Jc1 3c3 Qc4",
            "win": 150,
            "playerId": "nope112"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "Worner",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Jh0 Th1 3h4/7c0 8c0 2c2 6c3 9c3/9d0 Ad0 4d1 2d2 8h4",
            "win": -160,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:17:29",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338157544": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "serverinme",
            "orderIndex": 2,
            "hero": true,
            "dead": "6h1 Ts2 6s3 Kc4",
            "rows": "Ks0 Jh3 Qs4/Ah0 Ad0 6d2 Jc2 7d3/2c0 4h0 2s1 9d1 5d4",
            "win": -120,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "nope112",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qh0 Qc2 Jd4/2h0 3s1 6c1 3c2 7c4/8h0 8c0 Js0 Kh3 Kd3",
            "win": -120,
            "playerId": "nope112"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "3d3 3h4 5s4/7h0 9h0 5c1 9c2 9s3/2d0 4d0 Td0 8d1 Qd2",
            "win": 240,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:20:06",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338157743": [
        {
            "inFantasy": false,
            "result": 57,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "9d1 Js2 Tc3 7d4",
            "rows": "Kd0 Kc2 Qd4/3s0 4s0 4h1 5d3 4d4/6h0 8h0 Th1 2h2 7h3",
            "win": 210,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "nope112",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ac0 Ah1 9c2/5s0 6c0 2s1 3h3 Ks3/Jh0 Jc0 Qs2 9s4 Qc4",
            "win": -380,
            "playerId": "nope112"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Jd2 Qh3 Kh4/7c0 3c1 4c1 2c3 5c4/7s0 8s0 Ts0 As0 6s2",
            "win": 170,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:22:32",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338157950": [
        {
            "inFantasy": true,
            "result": -18,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "3d0 Th0",
            "rows": "9c0 Jd0 Qc0/4h0 4d0 4c0 5h0 5d0/6c0 6s0 7h0 7c0 7s0",
            "win": 220,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "nope112",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ks0 Qs1 Qd2/As0 5c1 Ad2 9d4 Ts4/2h0 2c0 2s0 2d3 9s3",
            "win": 120,
            "playerId": "nope112"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "Worner",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "8s1 4s2 Jc2/6d0 7d0 Td1 3h4 Js4/Jh0 Qh0 Kh0 Tc3 Ac3",
            "win": -340,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:24:52",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338158161": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "serverinme",
            "orderIndex": 2,
            "hero": true,
            "dead": "Ah1 4c2 7d3 2d4",
            "rows": "Ts2 Kd3 4h4/3h0 5h0 3d1 5d2 Jd3/6h0 6d0 8h0 8s1 6c4",
            "win": -20,
            "playerId": "serverinme"
        },
        {
            "inFantasy": true,
            "result": 48,
            "playerName": "nope112",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ks0 Ac0 As0/5c0 5s0 9h0 9c0 Jh0/2h0 2s0 8d0 Qd0 Qc0",
            "win": 140,
            "playerId": "nope112"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qs0 Tc2 Td4/Kh0 Th1 Ad1 6s3 Kc3/7h0 7s0 9d0 9s2 Jc4",
            "win": -120,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:27:55",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338158402": [
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "Ts1 Td2 Tc3 5d4",
            "rows": "Ac0 Js3 Qh4/6c0 4c1 9c1 6h2 Ah4/8c0 8s0 Kd0 3h2 8h3",
            "win": 10,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "nope112",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "9s3 4d4 9h4/4s0 Th0 5s1 7h2 7c2/6d0 8d0 9d0 2d1 Ad3",
            "win": -180,
            "playerId": "nope112"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kc0 3c3 4h3/5h0 7d1 As2 5c4 6s4/Jh0 Jc0 Qc0 Qd1 Qs2",
            "win": 170,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:30:26",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338158591": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "9h1 7h2 Ts3 2c4",
            "rows": "Kc0 9s2 Jc3/As0 3s1 6h1 5s3 Js4/4d0 7d0 8d0 Ad2 Qh4",
            "win": -130,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "3d1 Kd3 2d4/7c0 9c0 3c2 5c2 8c4/2h0 Th0 Kh0 5h1 8h3",
            "win": 130,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:32:17",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338158734": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "4c1 3h2 3c3 Tc4",
            "rows": "Qh0 4h2 4s2/7c0 9h0 6s1 8s1 8h3/5d0 Jd0 5s3 Jc4 Kh4",
            "win": -50,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "As1 2h4 7h4/Td0 4d2 Th2 Jh3 Js3/6c0 8c0 Qc0 Kc0 2c1",
            "win": 50,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:33:59",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338158850": [
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "3c1 Th2 8h3 9h4",
            "rows": "Kh0 Ah1 Ks3/8c0 5c1 5d2 8d2 7c3/6c0 6s0 Qh0 Js4 Qd4",
            "win": 30,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Qs2 5h3/6h0 Jc0 3h2 8s4 Jd4/2s0 7s0 2h1 2c1 7h3",
            "win": -30,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:35:52",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338158968": [
        {
            "inFantasy": true,
            "result": 12,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "3c0 4d0",
            "rows": "5d0 7h0 7d0/9s0 Th0 Jh0 Qs0 Kh0/5c0 8c0 Tc0 Kc0 Ac0",
            "win": 0,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qh3 Qd3 Td4/9h1 9c1 2d2 2c2 8d4/2s0 4s0 7s0 Ks0 As0",
            "win": 0,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:36:39",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338159016": [
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "6c1 6d2 7s3 Ac4",
            "rows": "Qd0 Qs2 9c3/2c0 5c1 Kc2 Ks3 Ad4/3h0 6h0 Kh0 9h1 7h4",
            "win": -120,
            "playerId": "serverinme"
        },
        {
            "inFantasy": true,
            "result": -24,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "6s0 9d0 Tc0/3d0 3c0 3s0 Jd0 Jc0/2h0 4h0 4d0 4c0 4s0",
            "win": 120,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:37:22",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338159070": [
        {
            "inFantasy": true,
            "result": 12,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "3d0",
            "rows": "6s0 7d0 7s0/5s0 Jh0 Jd0 Jc0 Js0/8d0 Kh0 Kd0 Kc0 Ks0",
            "win": 240,
            "playerId": "serverinme"
        },
        {
            "inFantasy": true,
            "result": 0,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "5d0 9c0 Qd0/3h0 6h0 7h0 Th0 Ah0/4h0 4c0 4s0 8h0 8s0",
            "win": -240,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:38:18",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338159133": [
        {
            "inFantasy": true,
            "result": 33,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h0",
            "rows": "Js0 Ad0 As0/9s0 Ts0 Jc0 Qh0 Kh0/5h0 5d0 5c0 6d0 6s0",
            "win": 210,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "8d3 9h3 2d4/4c1 4s1 3c2 5s2 2c4/4d0 7d0 Td0 Jd0 Kd0",
            "win": -210,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:39:07",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338159189": [
        {
            "inFantasy": false,
            "result": 33,
            "playerName": "serverinme",
            "orderIndex": 2,
            "hero": true,
            "dead": "Jd1 2d2 7h3 8s4",
            "rows": "Ad1 5d2 Ks4/6h0 9s0 6c1 3h2 3s3/3c0 8c0 Jc0 9c3 7c4",
            "win": -130,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 39,
            "playerName": "boombooomboooomer",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kh2 Kc3 Ac4/2h0 4d0 6d1 4c2 6s3/7d0 9h0 Ts0 Js1 8h4",
            "win": 90,
            "playerId": "boombooomboooomer"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "As1 Td3 Tc3/2s0 8d0 Qc2 Qs2 Kd4/4h0 5h0 Jh0 Ah1 Th4",
            "win": 40,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:41:16",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338159336": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "5s1 4h2 Ts3 Qc4",
            "rows": "Qh0 Qd3 Tc4/3d0 5c0 Kd1 Kc1 6d2/9s0 Jh0 Js2 Ac3 9d4",
            "win": -100,
            "playerId": "serverinme"
        },
        {
            "inFantasy": true,
            "result": 42,
            "playerName": "boombooomboooomer",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kh0 Ah0 Ad0/4d0 4s0 7d0 7s0 Th0/2c0 7c0 8c0 9c0 Jc0",
            "win": 220,
            "playerId": "boombooomboooomer"
        },
        {
            "inFantasy": false,
            "result": 42,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "As0 Jd4 Ks4/2s1 3s1 Td2 2h3 2d3/5h0 6c0 7h0 8d0 4c2",
            "win": -120,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:43:17",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338159474": [
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "8d0",
            "rows": "6h0 6c0 Kc0/3d0 3s0 4h0 5c0 5s0/Tc0 Jh0 Qs0 Ks0 Ad0",
            "win": 20,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 60,
            "playerName": "boombooomboooomer",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "As1 Qh3 Ah3/6s0 7d0 7s1 6d4 Qd4/8h0 8s0 9s0 Th2 Ts2",
            "win": 220,
            "playerId": "boombooomboooomer"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "Worner",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "9h0 Qc1 Jd3/3c0 8c0 Kd1 Td2 9c3/2d0 2s0 5h2 4d4 4s4",
            "win": -240,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:45:17",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338159603": [
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "serverinme",
            "orderIndex": 2,
            "hero": true,
            "dead": "2c1 2s2 Kc3 8s4",
            "rows": "Kd1 4c3 8h4/5s0 Js0 Jd2 3s3 3d4/5c0 6c0 9c0 7c1 8c2",
            "win": 30,
            "playerId": "serverinme"
        },
        {
            "inFantasy": true,
            "result": -9,
            "playerName": "boombooomboooomer",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "7d0 7s0 As0/4h0 5h0 6h0 Qh0 Kh0/2h0 2d0 Th0 Td0 Tc0",
            "win": 100,
            "playerId": "boombooomboooomer"
        },
        {
            "inFantasy": false,
            "result": -30,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ks1 Qd2 Qs3/9h0 Ac2 9s3 Qc4 Ad4/3h0 4d0 5d0 6s0 7h1",
            "win": -130,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:47:25",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338159738": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "4h1 6d2 Qd3 4c4",
            "rows": "9d3 9c3 Qs4/7d0 Tc0 3d1 3s1 3h2/5h0 5s0 Js0 5d2 Jh4",
            "win": 20,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "boombooomboooomer",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "8c3 Kh3 Kc4/4d0 4s0 6h1 6c2 Qc4/Ad0 Ac0 As0 9h1 9s2",
            "win": 30,
            "playerId": "boombooomboooomer"
        },
        {
            "inFantasy": true,
            "result": 9,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "2h0 2c0 8s0/3c0 6s0 7c0 8h0 8d0/Td0 Ts0 Jd0 Qh0 Ks0",
            "win": -50,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:49:30",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338159852": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qs1 Kc2 4s3 2h4",
            "rows": "Ad1 8h4 Jd4/2d0 8c0 8d2 6c3 6s3/2s0 3s0 5s0 As1 9s2",
            "win": -50,
            "playerId": "serverinme"
        },
        {
            "inFantasy": true,
            "result": 3,
            "playerName": "boombooomboooomer",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "5d0 5c0 8s0/9h0 Ts0 Js0 Qd0 Kh0/3c0 4c0 7c0 Jc0 Qc0",
            "win": 50,
            "playerId": "boombooomboooomer"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:50:27",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338159902": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "serverinme",
            "orderIndex": 2,
            "hero": true,
            "dead": "7d1 Js2 3c3 4d4",
            "rows": "Ks2 9h3 Kd4/4s0 7c0 7h1 Qc3 Qs4/2d0 2s0 9d0 2c1 9c2",
            "win": 220,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 42,
            "playerName": "boombooomboooomer",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "As0 6s4 Kc4/3d0 6c0 5d1 7s2 5c3/4h0 Qh0 Th1 2h2 Kh3",
            "win": -220,
            "playerId": "boombooomboooomer"
        },
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "6d3 Ac3 Ad4/3h0 4c0 8h1 8s1 3s2/Td0 Tc0 Jd0 Jh2 Qd4",
            "win": 0,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:52:50",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338160021": [
        {
            "inFantasy": true,
            "result": 5,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "3d0 9s0",
            "rows": "Qs0 Kh0 Kc0/2h0 3h0 4d0 5c0 Ah0/5d0 7d0 Td0 Qd0 Ad0",
            "win": 110,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "boombooomboooomer",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kd3 Ks3 Th4/4h1 4s1 3c2 3s2 5h4/7h0 8c0 8s0 Jh0 Jc0",
            "win": -280,
            "playerId": "boombooomboooomer"
        },
        {
            "inFantasy": true,
            "result": 15,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Jd0 Ac0 As0/8d0 9c0 Tc0 Js0 Qh0/2s0 5s0 6s0 7s0 Ts0",
            "win": 170,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:54:15",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338160092": [
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "5d1 4d2 6s3 5s4",
            "rows": "6h2 2d3 8s4/7c0 Td0 Jd2 Ah3 5c4/2h0 4h0 Jh0 8h1 Kh1",
            "win": -120,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "boombooomboooomer",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc2 4c4 Qc4/7s0 9d0 5h1 9h3 9s3/2c0 3c0 6c0 Jc1 Tc2",
            "win": -40,
            "playerId": "boombooomboooomer"
        },
        {
            "inFantasy": false,
            "result": 54,
            "playerName": "Worner",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ks0 Qs1 Kd3/Ac0 As0 Ad3 2s4 7d4/6d0 7h0 8c1 9c2 Th2",
            "win": 160,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:56:34",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338160206": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "serverinme",
            "orderIndex": 2,
            "hero": true,
            "dead": "4s1 5c2 Qs3 9c4",
            "rows": "Kc1 Ah2 Ks4/8h0 8c0 8s1 5h2 Jd4/2d0 3d0 Td0 4d3 9d3",
            "win": 240,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 39,
            "playerName": "boombooomboooomer",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "As0 Kh2 Qd4/3c0 4h0 3h1 7s1 Th4/Jc0 Qh0 Qc2 2c3 2s3",
            "win": -370,
            "playerId": "boombooomboooomer"
        },
        {
            "inFantasy": true,
            "result": 33,
            "playerName": "Worner",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Js0 Ad0 Ac0/7h0 7c0 Tc0 Ts0 Kd0/2h0 3s0 4c0 5s0 6h0",
            "win": 130,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-19 23:58:40",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338160311": [
        {
            "inFantasy": true,
            "result": 45,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "4c0 Jc0",
            "rows": "Th0 Qh0 Ks0/4d0 5h0 6d0 7s0 8d0/3h0 3d0 3c0 6c0 6s0",
            "win": -90,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "boombooomboooomer",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kd0 Kc2 7c4/2s0 Ah0 Ad0 9s2 9h4/Td0 5c1 Ts1 5d3 Tc3",
            "win": 50,
            "playerId": "boombooomboooomer"
        },
        {
            "inFantasy": false,
            "result": 36,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "As0 Ac2 Js3/8s0 7d1 8h1 7h2 5s4/2d0 Qc0 Qs0 2h3 2c4",
            "win": 40,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 00:00:53",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338160449": [
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "4s1 9c2 8c3 4d4",
            "rows": "Qs0 Qc2 Kh4/7d0 Td0 7s3 Ts3 Qh4/Jd0 Jc0 6h1 6d1 Js2",
            "win": 20,
            "playerId": "serverinme"
        },
        {
            "inFantasy": true,
            "result": 12,
            "playerName": "boombooomboooomer",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "5d0 5s0 Ad0/6c0 6s0 Th0 Jh0 Kc0/2h0 2d0 2s0 3h0 3d0",
            "win": -140,
            "playerId": "boombooomboooomer"
        },
        {
            "inFantasy": true,
            "result": 12,
            "playerName": "Worner",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qd0 Ac0 As0/4h0 5h0 7h0 8h0 Ah0/3c0 3s0 9h0 9d0 9s0",
            "win": 120,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 00:02:39",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338160561": [
        {
            "inFantasy": true,
            "result": 12,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "2d0",
            "rows": "7s0 8c0 8s0/5h0 Qs0 Kd0 Kc0 Ac0/6d0 6s0 9d0 9c0 9s0",
            "win": 100,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Worner",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kh3 As3 Qc4/Jd1 Jc1 4d2 4s2 5d4/2h0 2c0 2s0 6h0 7h0",
            "win": -100,
            "playerId": "Worner"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 00:03:37",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338160631": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "4d1 Kd2 3c3 7c4",
            "rows": "9s3 Ah3 2d4/5c0 7s0 8c1 4s2 6h4/4h0 5h0 8h0 3h1 Kh2",
            "win": 30,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "boombooomboooomer",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc3 Ac3 9c4/7d0 Td0 8d1 Qd2 Qc4/5s0 8s0 Ks0 Ts1 As2",
            "win": -30,
            "playerId": "boombooomboooomer"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 00:05:13",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338160753": [
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "serverinme",
            "orderIndex": 2,
            "hero": true,
            "dead": "5d1 Qd2 Qs3 6s4",
            "rows": "Kd0 9d2 Ah3/3h0 8h1 Td1 Th2 9s4/2c0 2s0 Jc0 2h3 Tc4",
            "win": 30,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "boombooomboooomer",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kc2 9h3 8d4/5c0 6h0 4d1 3d2 6c4/4s0 8s0 As0 3s1 Ks3",
            "win": 130,
            "playerId": "boombooomboooomer"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ac2 Ad3 2d4/7c0 9c0 Qc1 3c3 7s4/5h0 Jh0 Kh0 Qh1 7h2",
            "win": -160,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 00:07:23",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338160890": [
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jd1 4c2 3h3 9h4",
            "rows": "Ac0 Qs2 4s4/2s0 3c1 Kd1 4d3 Ks3/5s0 7c0 8d0 5d2 7s4",
            "win": -210,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 48,
            "playerName": "boombooomboooomer",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Jh3 Jc3 As4/2d0 3s0 2h1 3d2 9s4/6h0 6s0 Td0 6d1 6c2",
            "win": 440,
            "playerId": "boombooomboooomer"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "Mickier",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kh1 Ad1 7h3/4h0 5h0 9c2 Ah3 5c4/8h0 8s0 Js0 Th2 9d4",
            "win": -230,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 00:10:02",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338161089": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "Kh1 2s2 Kd3 9s4",
            "rows": "As0 4h3 Js3/5d0 7c0 9d1 6s2 8c2/Tc0 Ts0 3h1 8s4 9c4",
            "win": 0,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qs0 Qh1 3s4/5s0 Kc0 Ks0 3c2 6d2/7h0 2h1 4d3 4s3 6c4",
            "win": 0,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 00:11:53",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338161223": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "serverinme",
            "orderIndex": 2,
            "hero": true,
            "dead": "Th1 4h2 Ts3 2h4",
            "rows": "Qc3 8c4 9d4/3d0 5c0 3h1 2c2 3c3/9h0 Tc0 Js0 8h1 Qd2",
            "win": -10,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "boombooomboooomer",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ah1 8s3 Ks4/4c0 2s1 5s2 6s3 4s4/7s0 8d0 Td0 Jc0 9c2",
            "win": -110,
            "playerId": "boombooomboooomer"
        },
        {
            "inFantasy": false,
            "result": 60,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "As0 Ad1 3s3/7d0 7c0 4d2 6c3 6d4/Jh0 Kd0 Jd1 Qs2 Kc4",
            "win": 120,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 00:14:27",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338161403": [
        {
            "inFantasy": false,
            "result": 63,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "4s1 5s2 6s3 Js4",
            "rows": "Kh0 Ks1 Ah3/3d0 7h0 2s1 2c2 8h4/Jc0 Qc0 5c2 Jh3 5h4",
            "win": -480,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 48,
            "playerName": "boombooomboooomer",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qh0 Qs0 Th4/4d0 Kd1 Qd2 4h3 4c3/6h0 6d0 6c1 8c2 Td4",
            "win": -170,
            "playerId": "boombooomboooomer"
        },
        {
            "inFantasy": true,
            "result": 93,
            "playerName": "Mickier",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "9h0 9d0 9c0/2d0 5d0 7d0 8d0 Ad0/3h0 3c0 3s0 Tc0 Ts0",
            "win": 650,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 00:16:38",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338161569": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "7d1 9d2 7s3 Td4",
            "rows": "Ad0 Qd1 5c2/3s0 8s1 As2 Jc3 Kh4/5h0 8h0 9h0 4h3 5d4",
            "win": -10,
            "playerId": "serverinme"
        },
        {
            "inFantasy": true,
            "result": 18,
            "playerName": "boombooomboooomer",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ts0 Js0 Qc0/2d0 3d0 4s0 5s0 6c0/2h0 3h0 7h0 Qh0 Ah0",
            "win": 0,
            "playerId": "boombooomboooomer"
        },
        {
            "inFantasy": true,
            "result": 27,
            "playerName": "Mickier",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Ks0 Ac0/2s0 4d0 4c0 6h0 6d0/8c0 9s0 Th0 Jh0 Qs0",
            "win": 10,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 00:18:34",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338161727": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "serverinme",
            "orderIndex": 2,
            "hero": true,
            "dead": "Tc1 8d2 Ac3 9d4",
            "rows": "Qd1 Kd1 4c4/3h0 2c2 4d2 Ad3 5h4/6s0 9s0 Ks0 As0 2s3",
            "win": 230,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "boombooomboooomer",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ah1 Jh3 9h4/5c0 6h0 6c1 5d2 8h3/Th0 Ts0 Qh0 Qc2 7h4",
            "win": -30,
            "playerId": "boombooomboooomer"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc0 3s3 2h4/4s0 5s1 8c1 7c3 9c4/2d0 6d0 Td0 7d2 Jd2",
            "win": -200,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 00:21:00",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338161928": [
        {
            "inFantasy": false,
            "result": 63,
            "playerName": "serverinme",
            "orderIndex": 1,
            "hero": true,
            "dead": "4d1 3s2 Qd3 9d4",
            "rows": "Ac0 Ad2 Ks4/2d1 Kc1 Kh2 Kd3 8c4/6h0 7h0 Th0 Jh0 5h3",
            "win": 310,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "boombooomboooomer",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qh0 7s3 Ts4/3c0 5d0 6c2 5s3 Qc4/4s0 Js0 4c1 Jd1 Jc2",
            "win": 20,
            "playerId": "boombooomboooomer"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "Mickier",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "As0 Ah2 Qs3/4h0 3d1 2c3 2s4 5c4/8d0 9h0 Td0 8s1 9c2",
            "win": -330,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 00:23:31",
    "roomId": "41b-1cff2ad9"
}


{
    "stakes": 10,
    "handData": {"338162135": [
        {
            "inFantasy": true,
            "result": 11,
            "playerName": "serverinme",
            "orderIndex": 0,
            "hero": true,
            "dead": "3c0 4c0 6d0",
            "rows": "2d0 9c0 Qd0/3h0 6h0 9h0 Th0 Qh0/4s0 Js0 Qs0 Ks0 As0",
            "win": 350,
            "playerId": "serverinme"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "boombooomboooomer",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kh0 5c3 Tc4/4d0 5d0 4h1 2h2 2c2/8c0 Jh0 Ts1 9s3 5h4",
            "win": -180,
            "playerId": "boombooomboooomer"
        },
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "Mickier",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ad0 Ac0 Jd2/2s0 7d0 3d1 3s3 7s4/Qc0 6c1 Kc2 7c3 Td4",
            "win": -170,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 00:25:50",
    "roomId": "41b-1cff2ad9"
}


