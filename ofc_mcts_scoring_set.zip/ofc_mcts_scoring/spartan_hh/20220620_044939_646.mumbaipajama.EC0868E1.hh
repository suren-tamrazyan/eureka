{
    "stakes": 5,
    "handData": {"338167059": [
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "mumbaipajama",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qd1 3c2 2h3 9c4",
            "rows": "Qs0 Ac2 Qh3/3h0 3s1 4c2 4d3 Ah4/6c0 6s0 Jc0 Jd1 Kh4",
            "win": 15,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 45,
            "playerName": "Kainyu",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ad3 As3 8s4/2d0 2s0 5c1 5s2 8c4/9d0 Th0 Js0 7h1 8h2",
            "win": 135,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 36,
            "playerName": "Mickier",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qc1 8d2 4s4/7s0 Kc1 9s2 6h3 Kd3/5h0 5d0 Tc0 Ts0 9h4",
            "win": -150,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 01:49:39",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338167182": [
        {
            "inFantasy": true,
            "result": 68,
            "playerName": "mumbaipajama",
            "orderIndex": 0,
            "hero": true,
            "dead": "7c0",
            "rows": "6c0 6s0 Qc0/3h0 4h0 5h0 7h0 Th0/2c0 2s0 8h0 8d0 8s0",
            "win": 30,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": true,
            "result": 66,
            "playerName": "Kainyu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ah0 Ad0 As0/4c0 5c0 6h0 7s0 8c0/5d0 9d0 Td0 Jd0 Kd0",
            "win": 70,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": -2,
            "playerName": "Mickier",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qd3 Kh3 2d4/9h1 9c1 9s2 Ac2 3c4/2h0 Tc0 Ts0 Jh0 Js0",
            "win": -100,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 01:51:02",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338167270": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "mumbaipajama",
            "orderIndex": 1,
            "hero": true,
            "dead": "6h1 2h2 Jh3 3c4",
            "rows": "5h2 Ks2 5s4/7s0 8h0 8s0 2d1 2s1/9c0 Qc0 2c3 5c3 8c4",
            "win": -105,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": true,
            "result": 33,
            "playerName": "Kainyu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "6d0 Ah0 As0/8d0 9s0 Td0 Js0 Qs0/Qh0 Qd0 Kh0 Kd0 Kc0",
            "win": 105,
            "playerId": "Kainyu"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 01:52:00",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338167333": [
        {
            "inFantasy": false,
            "result": 33,
            "playerName": "mumbaipajama",
            "orderIndex": 1,
            "hero": true,
            "dead": "7d1 5h2 7s3 Ad4",
            "rows": "Jh2 8d3 Js3/3d0 3c0 4d0 Qd4 Qs4/6h0 6s0 9h1 9d1 9s2",
            "win": 155,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "Kainyu",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "As0 Kd2 Th4/2d0 5c0 5s1 2h2 2s3/8h0 8c0 7h1 8s3 Ah4",
            "win": -145,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "Mickier",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qh0 Tc1 Td2/2c0 Jd0 5d1 Jc3 4s4/3s0 Ks0 Ts2 Kc3 9c4",
            "win": -10,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 01:54:37",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338167493": [
        {
            "inFantasy": false,
            "result": -27,
            "playerName": "mumbaipajama",
            "orderIndex": 0,
            "hero": true,
            "dead": "4s1 5d2 As3 5h4",
            "rows": "8h2 Kh2 Qh4/2d0 4d0 5s0 3d1 6c3/Tc0 Qc0 3c1 2c3 8c4",
            "win": 15,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Kainyu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Qd3 Qs4/3s0 6s0 3h2 6h2 Js3/7d0 Ad0 7s1 Ah1 9s4",
            "win": -10,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "Mickier",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ks0 Ac2 2s4/4h0 7c0 7h1 4c3 5c3/9h0 9c0 Jh1 Jd2 Jc4",
            "win": -5,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 01:56:55",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338167618": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "mumbaipajama",
            "orderIndex": 2,
            "hero": true,
            "dead": "4c1 5s2 3s3 8c4",
            "rows": "5c2 Ks2 4d3/7h0 Th0 9c1 Ts3 Qd4/6c0 Jd0 Jc0 6s1 6d4",
            "win": 45,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": true,
            "result": 9,
            "playerName": "Kainyu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "5d0 Kd0 Ac0/8d0 9s0 Td0 Js0 Qs0/3h0 6h0 8h0 9h0 Kh0",
            "win": 85,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc0 As2 Ah3/4h0 2c1 5h1 2d2 4s3/8s0 Qh0 Qc0 Jh4 Ad4",
            "win": -130,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:01:27",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338167894": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "mumbaipajama",
            "orderIndex": 2,
            "hero": true,
            "dead": "6d1 Ks2 Qh3 Js4",
            "rows": "Kh0 Kc2 Ah3/2h0 5d0 3h1 3c2 5c3/7c0 8c0 6c1 7s4 Jd4",
            "win": -30,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "Kainyu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kd1 Ad2 9c4/2s0 8s0 6h1 6s2 8d3/Td0 Qd0 Qs0 Qc3 4d4",
            "win": 60,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ac0 As1 2c3/3s0 5h0 3d2 Jh3 4h4/9s0 Jc0 8h1 Ts2 5s4",
            "win": -30,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:04:00",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338168054": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "mumbaipajama",
            "orderIndex": 1,
            "hero": true,
            "dead": "8d1 6h2 4c3 Kc4",
            "rows": "Kh0 Tc2 4s4/Jc0 Qd1 Qc1 4d2 4h3/2s0 5s0 As0 2h3 3d4",
            "win": -65,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 54,
            "playerName": "Kainyu",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Td0 Qs0 Qh1/6s0 6c1 7d2 7c3 Jd4/3h0 3c0 9h2 9d3 8c4",
            "win": 130,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "Mickier",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kd0 Ac1 Ks3/6d0 7h0 9s2 7s3 5d4/Th0 Ts0 8h1 8s2 5h4",
            "win": -65,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:06:27",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338168209": [
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "mumbaipajama",
            "orderIndex": 0,
            "hero": true,
            "dead": "Js1 3h2 Jc3 2c4",
            "rows": "Ks0 Jh1 Kd1/7c0 7s2 5h3 5d3 Ac4/9d0 9c0 Tc0 Td2 Ts4",
            "win": 80,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": true,
            "result": 27,
            "playerName": "Kainyu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Jd0 Kh0 Kc0/5s0 6d0 7h0 8h0 9s0/2h0 2d0 2s0 4d0 4s0",
            "win": 105,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 39,
            "playerName": "Mickier",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ad0 Ah2 Qh3/3d0 3s1 5c1 4h2 8s4/6h0 6c0 Th0 6s3 Qc4",
            "win": -185,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:08:49",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338168383": [
        {
            "inFantasy": true,
            "result": 9,
            "playerName": "mumbaipajama",
            "orderIndex": 1,
            "hero": true,
            "dead": "Tc0 Qh0",
            "rows": "Kc0 Ah0 Ad0/2d0 3s0 4c0 5d0 6h0/5s0 6s0 9s0 Ks0 As0",
            "win": 25,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "Kainyu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qd3 Qs3 Kd4/Jh1 Jc1 2h2 2c2 Ac4/8h0 8c0 8s0 9d0 9c0",
            "win": -25,
            "playerId": "Kainyu"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:09:40",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338168452": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "mumbaipajama",
            "orderIndex": 0,
            "hero": true,
            "dead": "6h1 4h2 4s3 7d4",
            "rows": "Ah2 Ac2 8h3/Jd0 5s1 9c1 6d4 6s4/7h0 7s0 Qh0 Qd0 Qs3",
            "win": -75,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": true,
            "result": 15,
            "playerName": "Kainyu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "8d0 8c0 As0/4c0 9h0 9d0 Th0 Kd0/3h0 3d0 3c0 5h0 5c0",
            "win": 75,
            "playerId": "Kainyu"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:10:42",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338168527": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "mumbaipajama",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qd1 6s2 2d3 7d4",
            "rows": "4s3 Kd3 8d4/4c0 Jc0 Qc1 3c2 Qs4/2h0 7h0 Ah0 9h1 Kh2",
            "win": 75,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "Kainyu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "8h2 8s2 8c3/Td1 Tc1 Ks3 7c4 Ad4/2c0 3d0 4d0 5s0 6h0",
            "win": -80,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "Mickier",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "3h0 Js2 Kc4/6d0 9d1 9s1 2s2 Th4/5c0 9c0 Ac0 5h3 As3",
            "win": 5,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:15:00",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338168908": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "mumbaipajama",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qd1 8c2 Tc3 Th4",
            "rows": "Ac1 Jd3 Kd4/3h0 4c0 6h0 6d2 6c2/Ts0 Ks0 Qs1 4s3 As4",
            "win": 100,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "Kainyu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "5c2 Kh2 Ad4/2d0 8d1 2c3 5d3 8s4/2h0 7h0 8h0 Qh0 Ah1",
            "win": 10,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "Mickier",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kc0 9s2 2s4/5s0 7c0 4h1 6s2 3s3/9d0 Td0 7d1 Jc3 4d4",
            "win": -110,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:17:37",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338169143": [
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "mumbaipajama",
            "orderIndex": 2,
            "hero": true,
            "dead": "Th1 Qc2 As3 Qh4",
            "rows": "Ks0 Qd2 Qs3/4s0 5h0 6s1 6h3 5c4/8s0 Jd0 8d1 8c2 Kd4",
            "win": -45,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "Kainyu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ah1 Kh3 Ac4/4c0 Js0 Jh1 2c2 4h4/2d0 7d0 Ad0 9d2 3d3",
            "win": 130,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Td1 4d3 Ts4/6d0 7s0 5d1 7c2 6c3/3h0 9h0 9s0 3c2 Kc4",
            "win": -85,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:20:05",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338169371": [
        {
            "inFantasy": true,
            "result": 9,
            "playerName": "mumbaipajama",
            "orderIndex": 1,
            "hero": true,
            "dead": "2h0",
            "rows": "9h0 Jh0 Jc0/4d0 7c0 Kc0 Ah0 Ad0/3d0 3s0 6c0 8h0 8s0",
            "win": -5,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": true,
            "result": -18,
            "playerName": "Kainyu",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Jd0 Ks0 As0/5h0 5d0 5c0 8d0 8c0/9c0 9s0 Qh0 Qd0 Qs0",
            "win": 170,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "Mickier",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "7d3 7s3 Qc4/Td1 Ts1 4s2 5s2 2s4/3h0 6h0 7h0 9d0 Kh0",
            "win": -165,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:21:43",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338169512": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "mumbaipajama",
            "orderIndex": 0,
            "hero": true,
            "dead": "7d1 8d2 7c3 8c4",
            "rows": "As0 Ad1 Qd3/3c0 5c0 6d0 3h4 4d4/Th0 Jh1 Kd2 Ks2 Jd3",
            "win": -110,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "Kainyu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Qc4 Ac4/Ah0 5s1 7s1 9h3 9s3/2h0 2c0 Td0 Tc2 Ts2",
            "win": 100,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "Mickier",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qh2 9c3 3s4/4c0 6h0 5h2 3d3 4s4/2s0 8s0 Js0 6s1 Qs1",
            "win": 10,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:24:07",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338169717": [
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "mumbaipajama",
            "orderIndex": 2,
            "hero": true,
            "dead": "5c1 Qd2 Td3 4c4",
            "rows": "6s2 Js3 Ks4/4d0 6c0 7c0 3s2 5h4/3h0 9h0 7h1 Kh1 6h3",
            "win": 85,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "Kainyu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ad0 Qs2 Ac3/7s0 Tc0 7d1 Th2 9s4/Kd0 Kc0 2h1 Jc3 5d4",
            "win": -130,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qc0 Jh1 2d4/Ah0 As0 3c2 Ts2 6d3/8s0 9d0 8c1 9c3 8d4",
            "win": 45,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:26:26",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338169934": [
        {
            "inFantasy": false,
            "result": 60,
            "playerName": "mumbaipajama",
            "orderIndex": 1,
            "hero": true,
            "dead": "8s1 Kd2 Qh3 Ah4",
            "rows": "Ac0 Ad1 7d4/2h0 4d0 6s0 2d3 2c3/9c0 Jh1 8d2 Th2 Qc4",
            "win": 80,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "Kainyu",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "As0 Qs3 Jc4/4s0 6h0 5s1 3c3 7h4/9h0 Jd0 Qd1 Td2 Ks2",
            "win": -15,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "Mickier",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kc0 3h3 9d4/5c0 6d0 6c1 8h2 4h3/7s0 9s0 Ts1 2s2 Js4",
            "win": -65,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:29:15",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338170201": [
        {
            "inFantasy": true,
            "result": 18,
            "playerName": "mumbaipajama",
            "orderIndex": 0,
            "hero": true,
            "dead": "3d0 4d0 8d0",
            "rows": "6h0 6d0 9c0/6s0 9s0 Js0 Qs0 Ks0/4h0 5h0 7h0 Kh0 Ah0",
            "win": 140,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "Kainyu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kd1 Ac2 Qc4/2h0 2d2 2s3 Th3 5d4/3c0 7c0 Tc0 Kc0 8c1",
            "win": -50,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "Mickier",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "4s2 Ad3 4c4/7d0 9d0 Jd1 Jc3 As4/9h0 Jh0 Qh0 3h1 8h2",
            "win": -90,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:31:22",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338170430": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "mumbaipajama",
            "orderIndex": 2,
            "hero": true,
            "dead": "Tc1 Kh2 9h3 Js4",
            "rows": "Ah0 Ac2 9s4/4d0 5h0 4h1 2c2 7c4/Qd0 Qc0 8s1 8d3 Qs3",
            "win": -160,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 60,
            "playerName": "Kainyu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Jc2 Kc2 Ks3/3h0 7d0 3d1 8c3 8h4/6h0 6c0 Th0 Td1 6s4",
            "win": 170,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qh0 Jh3 2d4/2s0 3c0 3s1 9c2 2h4/5d0 Ad0 5s1 As2 5c3",
            "win": -10,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:33:49",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338170718": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "mumbaipajama",
            "orderIndex": 1,
            "hero": true,
            "dead": "7h1 6s2 3s3 4d4",
            "rows": "Ad0 2s2 7s3/5h0 Jh0 5s1 9d1 8s4/3c0 Kc0 Qc2 9c3 5c4",
            "win": -35,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": true,
            "result": 42,
            "playerName": "Kainyu",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "5d0 Th0 Tc0/9h0 Ts0 Jc0 Qd0 Kh0/6h0 6d0 Ah0 Ac0 As0",
            "win": 190,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "Mickier",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qs2 8d3 6c4/3h0 Jd0 3d1 7c1 Js2/4c0 Kd0 Ks0 Td3 8c4",
            "win": -155,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:36:07",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338170923": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "mumbaipajama",
            "orderIndex": 0,
            "hero": true,
            "dead": "6h1 Th2 Ts3 Jd4",
            "rows": "Qh1 Ks2 7d4/7s0 Jh0 8h1 5d3 8d3/2c0 5c0 9c0 3c2 4s4",
            "win": -30,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "Kainyu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Kd1 7c3/9h0 4c2 8s2 9s3 Ac4/2d0 3d0 Td0 Qd1 4d4",
            "win": -30,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "Mickier",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qc0 Tc1 3h3/5h0 Kh0 Jc1 5s2 Qs2/6d0 9d0 Ad3 Js4 As4",
            "win": 60,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:38:43",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338171120": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "mumbaipajama",
            "orderIndex": 2,
            "hero": true,
            "dead": "4h1 Th2 2d3 As4",
            "rows": "7d1 Ah2 Ad3/8c0 Jc0 Js2 6c4 9s4/6h0 6d0 Qd0 Qc1 Qs3",
            "win": -120,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 57,
            "playerName": "Kainyu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ks2 Kc3 3h4/5c0 7c0 5d1 7h1 3s2/4d0 Td0 Tc0 2s3 Ts4",
            "win": 95,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kd1 Ac3 2h4/4c0 5s0 2c2 4s2 3d4/5h0 8h0 Jh0 9h1 Qh3",
            "win": 25,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:40:54",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338171287": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "mumbaipajama",
            "orderIndex": 1,
            "hero": true,
            "dead": "4s1 Qs2 Qd3 2s4",
            "rows": "Ks0 Kc2 6h4/Ac0 As0 5h1 2c3 2d4/9c0 Tc0 Jd1 Qc2 8d3",
            "win": 10,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": true,
            "result": 36,
            "playerName": "Kainyu",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Jc0 Kh0 Kd0/4d0 5c0 6d0 7c0 8h0/9h0 9d0 9s0 Th0 Ts0",
            "win": 190,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 36,
            "playerName": "Mickier",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "8c1 7s2 Qh3/2h0 5d0 4c1 Ah2 8s3/3h0 3c0 Td0 Js4 Ad4",
            "win": -200,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:43:13",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338171447": [
        {
            "inFantasy": true,
            "result": -19,
            "playerName": "mumbaipajama",
            "orderIndex": 0,
            "hero": true,
            "dead": "2c0 9s0",
            "rows": "8s0 Ks0 Ac0/2d0 3d0 4c0 5h0 6h0/5c0 5s0 7h0 7d0 7s0",
            "win": 95,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "Kainyu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qc1 Kh1 Qd3/Ah0 Ad0 Ts2 4d3 4h4/3h0 3s0 Jd0 3c2 9d4",
            "win": -20,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "Mickier",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qs0 Kd1 Kc3/6d0 5d1 8c2 6c3 2s4/9h0 9c0 Jc0 As2 7c4",
            "win": -75,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:45:31",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338171607": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "mumbaipajama",
            "orderIndex": 1,
            "hero": true,
            "dead": "8d1 8h2 Kh3 Ts4",
            "rows": "Kc0 Ks0 Tc4/4d0 4h2 7d2 Jc3 2s4/2h0 6h0 6c1 6s1 2c3",
            "win": -95,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": true,
            "result": 27,
            "playerName": "Kainyu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qh0 Qd0 Kd0/8c0 9h0 Jh0 Ah0 Ad0/5h0 5d0 5s0 7c0 7s0",
            "win": 95,
            "playerId": "Kainyu"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:46:47",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338171698": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "mumbaipajama",
            "orderIndex": 1,
            "hero": true,
            "dead": "Js1 8s2 Kd3 4c4",
            "rows": "Qd0 9c3 7c4/2d0 Ah0 Ad0 Td3 3d4/Ts0 8d1 9d1 6c2 7s2",
            "win": -5,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "Kainyu",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kh0 2h2 As3/5s0 7h1 8c1 5c2 Qs4/6h0 6d0 Th0 Tc3 Jh4",
            "win": -80,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 51,
            "playerName": "Mickier",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qh1 Ac2 Qc4/2c0 5d0 Ks1 Jd3 Kc3/3c0 3s0 6s0 3h2 7d4",
            "win": 85,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:49:39",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338171902": [
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "mumbaipajama",
            "orderIndex": 0,
            "hero": true,
            "dead": "3d1 9h2 3s3 4s4",
            "rows": "Kh0 Ts3 Th4/2d0 6d0 6h1 4c2 4d3/5d0 5c0 7d1 8h2 5s4",
            "win": 0,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "Kainyu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ad0 As2 6c3/2h0 Jh0 9d1 7s4 8s4/3c0 Qc0 Qh1 Td2 Qs3",
            "win": -135,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": true,
            "result": 33,
            "playerName": "Mickier",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "3h0 Jc0 Js0/4h0 7h0 Kd0 Kc0 Ks0/8c0 9s0 Tc0 Jd0 Qd0",
            "win": 135,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:51:47",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338172053": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "mumbaipajama",
            "orderIndex": 2,
            "hero": true,
            "dead": "6h1 4h2 7c3 5h4",
            "rows": "Qc0 Qh1 9s3/8s0 5s1 2c2 8h2 2d3/Td0 Tc0 Jh0 Jd4 Kc4",
            "win": 10,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 33,
            "playerName": "Kainyu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ks0 Kd1 9c3/Ah0 Ac0 4d1 5c2 8d3/6c0 Ts0 6s2 3h4 3d4",
            "win": 15,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 39,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kh0 Qd1 3c4/8c0 9h0 6d1 9d3 4c4/7s0 Js0 7h2 Jc2 7d3",
            "win": -25,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:54:04",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338172197": [
        {
            "inFantasy": true,
            "result": 18,
            "playerName": "mumbaipajama",
            "orderIndex": 1,
            "hero": true,
            "dead": "8c0",
            "rows": "Jh0 Kh0 Ks0/4h0 4c0 7c0 7s0 Tc0/2d0 2c0 Qd0 Qc0 Qs0",
            "win": -30,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": true,
            "result": 60,
            "playerName": "Kainyu",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "9h0 9c0 9s0/4s0 5d0 6h0 7d0 8s0/3d0 4d0 Jd0 Kd0 Ad0",
            "win": 170,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "Mickier",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ah3 Ac3 Ts4/6c1 6s1 2h2 2s2 5c4/3h0 3c0 3s0 7h0 9d0",
            "win": -140,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:55:46",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338172298": [
        {
            "inFantasy": false,
            "result": 42,
            "playerName": "mumbaipajama",
            "orderIndex": 0,
            "hero": true,
            "dead": "7c1 7s2 2h3 4s4",
            "rows": "Ts3 Jh3 Kh4/2d0 8d0 5d1 6d2 7d2/5c0 Jc0 Qc0 Tc1 Kc4",
            "win": -170,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": true,
            "result": 27,
            "playerName": "Kainyu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "3h0 3d0 3c0/6h0 7h0 8h0 Th0 Ah0/2s0 6s0 8s0 Qs0 As0",
            "win": 55,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": true,
            "result": 3,
            "playerName": "Mickier",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Jd0 Js0 Qd0/4h0 4d0 4c0 5h0 5s0/2c0 9h0 9d0 9c0 9s0",
            "win": 115,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:57:41",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338172399": [
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "mumbaipajama",
            "orderIndex": 2,
            "hero": true,
            "dead": "2h1 2s2 7c3 7h4",
            "rows": "6d3 6s3 Kh4/3d0 Td0 Jd1 3c2 Tc2/Ah0 Ad0 Ac0 5s1 9h4",
            "win": -60,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": true,
            "result": 12,
            "playerName": "Kainyu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "5h0 5c0 As0/3h0 3s0 4d0 4s0 9s0/8h0 9d0 Th0 Jh0 Qc0",
            "win": -110,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": true,
            "result": 54,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "7d0 Kd0 Ks0/6h0 7s0 8c0 9c0 Ts0/Jc0 Js0 Qh0 Qd0 Qs0",
            "win": 170,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 02:59:47",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338172519": [
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "mumbaipajama",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jd1 9c2 7d3 5c4",
            "rows": "Ks0 Td2 Qd2/7c0 3d1 6d1 Ad3 Qs4/4h0 Jh0 Ah0 6h3 2h4",
            "win": 15,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "Kainyu",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kh0 4c4 Qh4/3s1 Js1 5s2 Ts2 6s3/2c0 3c0 Jc0 Qc0 Kc3",
            "win": 125,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "Mickier",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kd0 9h3 5h4/8s0 Tc0 Ac1 As1 Th3/3h0 7h0 4s2 5d2 8d4",
            "win": -140,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 03:02:25",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338172722": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "mumbaipajama",
            "orderIndex": 0,
            "hero": true,
            "dead": "Kc1 6c2 3c3 7d4",
            "rows": "Ac0 Js3 4d4/4c0 7c0 7s0 2d2 7h4/9s0 8c1 9c1 9h2 8s3",
            "win": 70,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "Kainyu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qd0 Ad1 Td4/Jc0 Tc1 9d2 Qc3 Jd4/3s0 4s0 Ks0 Qs2 6s3",
            "win": 0,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Mickier",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qh0 Kd1 As4/3d0 6h0 8h2 8d2 Ah4/5h0 5c0 5s1 2s3 Ts3",
            "win": -70,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 03:05:12",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338172957": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "mumbaipajama",
            "orderIndex": 2,
            "hero": true,
            "dead": "6c1 6d2 6h3 8d4",
            "rows": "Qd0 Ts2 9c3/5c0 Kc0 4h2 Td3 Ac4/3d0 3c0 2c1 2s1 7h4",
            "win": 60,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "Kainyu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qc0 Ad1 Ah2/2d0 4d0 4c3 Jc3 7c4/6s0 Ks0 5s1 7s2 5h4",
            "win": -30,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "As0 3s3 4s3/5d0 9s1 7d2 8s2 Tc4/9d0 Th0 Qs0 8h1 Js4",
            "win": -30,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 03:07:44",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338173175": [
        {
            "inFantasy": false,
            "result": 57,
            "playerName": "mumbaipajama",
            "orderIndex": 1,
            "hero": true,
            "dead": "7c1 8s2 Kh3 Ks4",
            "rows": "Kc0 Kd1 5h3/4s0 5d0 5c1 4d2 Ac2/Td0 Qd0 6d3 Ts4 Qc4",
            "win": 85,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "Kainyu",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qs1 As3 9c4/2s0 3s0 3c1 2c2 9d2/4h0 8h0 Th0 Jh3 6s4",
            "win": -120,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "Mickier",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Js0 7h3 Qh4/Ah0 Ad0 9s1 2h2 9h3/3d0 8d0 2d1 Jd2 7d4",
            "win": 35,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 03:10:15",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338173400": [
        {
            "inFantasy": true,
            "result": 66,
            "playerName": "mumbaipajama",
            "orderIndex": 0,
            "hero": true,
            "dead": "2c0 6c0",
            "rows": "Qs0 Ah0 As0/9d0 Th0 Js0 Qd0 Kh0/5d0 5s0 7h0 7c0 7s0",
            "win": 240,
            "playerId": "mumbaipajama"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "Kainyu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kd0 Ks0 4h3/3s0 Ac0 7d2 3d3 Ts4/8d0 Jh1 Jc1 8h2 6h4",
            "win": -130,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "Mickier",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ad2 Tc3 Kc3/2s0 4c0 5h1 5c1 8s4/8c0 Td0 Jd0 9h2 Qh4",
            "win": -110,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 03:12:40",
    "roomId": "41b-1d1a0f20"
}


