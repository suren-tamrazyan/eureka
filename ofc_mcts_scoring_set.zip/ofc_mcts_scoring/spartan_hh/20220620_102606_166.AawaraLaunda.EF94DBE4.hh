{
    "stakes": 10,
    "handData": {"338200461": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "Kainyu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ks0 7h3 Th3/5d0 7c0 4d1 6s2 6h4/Td0 Jh0 Qd1 Kc2 9s4",
            "win": 10,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "AawaraLaunda",
            "orderIndex": 0,
            "hero": true,
            "dead": "4c1 5s2 Tc3 5c4",
            "rows": "Kd1 2d2 Qs3/6d0 8c0 9d2 Ad3 8d4/3d0 3s0 Jd0 Jc1 5h4",
            "win": -10,
            "playerId": "AawaraLaunda"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:26:06",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338200751": [
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "Kainyu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "As0 Ac1 Qs3/8h0 Tc1 Kc2 8s3 Qc4/2h0 2s0 Jd0 2d2 4s4",
            "win": -150,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "AawaraLaunda",
            "orderIndex": 1,
            "hero": true,
            "dead": "Ah1 5s2 4h3 8d4",
            "rows": "Ts3 Td4 Qd4/3h0 6c1 6s1 9c2 9s2/5d0 7d0 9d0 Ad0 6d3",
            "win": 150,
            "playerId": "AawaraLaunda"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:27:44",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338200996": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Kainyu",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "6s0 Qc2 Qh3/2d0 4d0 2h1 3d1 3c2/8h0 8c0 Jc3 9d4 9s4",
            "win": 40,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "AawaraLaunda",
            "orderIndex": 0,
            "hero": true,
            "dead": "6d1 8s2 Ad3 Tc4",
            "rows": "Ks0 As2 Jd4/4s0 7c0 7s1 Qd2 7d3/6h0 Jh0 Kh1 9h3 4h4",
            "win": 30,
            "playerId": "AawaraLaunda"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "vivloc",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Th3 Kc3 Ah4/3h0 3s0 2s1 5h1 Ts4/5c0 6c0 Ac0 2c2 9c2",
            "win": -70,
            "playerId": "vivloc"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:30:58",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338201621": [
        {
            "inFantasy": true,
            "result": 60,
            "playerName": "Kainyu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Td0 Kh0 Kd0/5h0 9d0 Jh0 Jd0 Jc0/2c0 7c0 8c0 Tc0 Ac0",
            "win": 400,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "AawaraLaunda",
            "orderIndex": 2,
            "hero": true,
            "dead": "7s1 5s2 6d3 Qd4",
            "rows": "Qh0 Qs0 As3/2h0 4s0 2d1 3c2 Js4/9c0 8s1 Ts2 Th3 4c4",
            "win": -200,
            "playerId": "AawaraLaunda"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "vivloc",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ah0 Ad0 Ks2/3h1 6h1 4d2 6s3 8h4/5d0 5c0 Qc0 9s3 8d4",
            "win": -200,
            "playerId": "vivloc"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:33:39",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338202239": [
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "Kainyu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "7c3 As3 Kc4/5d0 6h0 8h0 5s1 8d4/9c0 Jc0 Qc1 2c2 4c2",
            "win": 50,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "AawaraLaunda",
            "orderIndex": 1,
            "hero": true,
            "dead": "7s1 8c2 9h3 Qs4",
            "rows": "Kh0 Ks1 Jh4/4s0 Ac0 5h2 Js3 Ad3/2d0 6d0 7d1 6c2 3s4",
            "win": -260,
            "playerId": "AawaraLaunda"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "vivloc",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "7h3 Jd3 8s4/2h0 3d0 4h0 3h1 4d4/9d0 Tc0 Th1 Td2 Ts2",
            "win": 210,
            "playerId": "vivloc"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:36:21",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338202846": [
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "Kainyu",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kd0 7c4 9d4/2h0 5c1 4d2 5s2 4c3/7d0 9s0 Jc0 8d1 Ts3",
            "win": 0,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 63,
            "playerName": "AawaraLaunda",
            "orderIndex": 0,
            "hero": true,
            "dead": "3c1 Ks2 2c3 Jh4",
            "rows": "Ah0 Ad1 Tc4/6h0 6c0 Th2 Td2 8c4/8s0 9c0 8h1 Qc3 Qs3",
            "win": 230,
            "playerId": "AawaraLaunda"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "vivloc",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kh0 Qh1 Qd1/2d0 3d0 3s2 9h3 Js4/5h0 7s0 As2 Ac3 5d4",
            "win": -230,
            "playerId": "vivloc"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:39:37",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338203531": [
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "Kainyu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qc0 Qd2 Kc3/4h0 4d1 5d1 4s2 6c3/Ts0 Jd0 Js0 9d4 Jh4",
            "win": -40,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": true,
            "result": -21,
            "playerName": "AawaraLaunda",
            "orderIndex": 2,
            "hero": true,
            "dead": "7d0 9h0 Qs0",
            "rows": "4c0 Jc0 Kh0/3h0 3d0 3c0 6h0 6d0/5s0 6s0 7s0 8s0 9s0",
            "win": 310,
            "playerId": "AawaraLaunda"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "vivloc",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ad0 As1 Ks2/2c0 2d1 9c2 3s4 Th4/7h0 8d0 8c0 2h3 2s3",
            "win": -270,
            "playerId": "vivloc"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:43:03",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338204273": [
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "Kainyu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qd0 Kc0 Ac0/2h0 2s0 5c0 6c0 9s0/6h0 7d0 8d0 9d0 Th0",
            "win": -170,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": true,
            "result": 33,
            "playerName": "AawaraLaunda",
            "orderIndex": 1,
            "hero": true,
            "dead": "8s0",
            "rows": "Kh0 Ah0 As0/7h0 7c0 9h0 9c0 Qc0/2d0 4d0 5d0 6d0 Kd0",
            "win": 170,
            "playerId": "AawaraLaunda"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:44:06",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338204489": [
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "Kainyu",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Tc1 Qs2 Ah4/6h0 8d0 8s2 4h3 4d3/7h0 7s0 Jc0 Jd1 Kc4",
            "win": 50,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "AawaraLaunda",
            "orderIndex": 0,
            "hero": true,
            "dead": "9c1 7c2 5s3 9s4",
            "rows": "Kd0 Ks0 Qd3/3h0 6c1 6s1 2s2 9d4/Th0 Js0 Ac2 Qh3 6d4",
            "win": -140,
            "playerId": "AawaraLaunda"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "vivloc",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "5h2 Qc2 Ad4/9h0 7d1 Ts1 Kh3 Td4/2d0 3s0 4c0 5c0 As3",
            "win": 90,
            "playerId": "vivloc"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:47:04",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338205070": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "Kainyu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qd0 Qh1 Kd3/2h0 4d0 3s2 Ad2 5h3/9d0 Js0 9h1 2s4 9c4",
            "win": -120,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "AawaraLaunda",
            "orderIndex": 2,
            "hero": true,
            "dead": "Jh1 8c2 9s3 8h4",
            "rows": "Kc0 Td3 Jc4/3d0 5c0 7c1 Ac3 3h4/6c0 6s0 Th1 6d2 Tc2",
            "win": 240,
            "playerId": "AawaraLaunda"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "vivloc",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ah2 As2 Ks3/Jd0 4s1 8s3 Qc4 Qs4/3c0 4c0 5s0 7h0 6h1",
            "win": -120,
            "playerId": "vivloc"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:49:54",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338205623": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "Kainyu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qc0 9c3 3d4/Kc0 Jc1 Jd2 7s3 Kd4/5s0 Js0 As0 2s1 Ks2",
            "win": 50,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "AawaraLaunda",
            "orderIndex": 0,
            "hero": true,
            "dead": "6s1 Qh2 7h3 5h4",
            "rows": "Kh0 Ad1 Qs3/4c0 8h0 6d2 8c2 9d3/Th0 Tc0 3c1 7d4 9h4",
            "win": -50,
            "playerId": "AawaraLaunda"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:51:29",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338205953": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "Kainyu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "8d3 8c3 Jh4/Ts0 Tc1 3d2 3s2 5d4/3h0 3c0 9d0 9s0 9c1",
            "win": -180,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "AawaraLaunda",
            "orderIndex": 1,
            "hero": true,
            "dead": "Js1 Qc2 2h3 5h4",
            "rows": "As0 Ah1 Qs4/2s0 6s0 6h2 6d3 8h4/7h0 Kh0 7c1 7d2 7s3",
            "win": 180,
            "playerId": "AawaraLaunda"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:52:51",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338206247": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "Kainyu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kh3 Kd3 Jh4/5d1 5s1 3d2 3s2 4d4/7d0 7s0 8h0 8c0 As0",
            "win": -80,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": true,
            "result": -12,
            "playerName": "AawaraLaunda",
            "orderIndex": 0,
            "hero": true,
            "dead": "2s0 4s0 5c0",
            "rows": "Th0 Tc0 Jd0/2h0 3h0 4h0 5h0 Ad0/8d0 8s0 9h0 9d0 9s0",
            "win": 80,
            "playerId": "AawaraLaunda"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:53:51",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338206465": [
        {
            "inFantasy": true,
            "result": 27,
            "playerName": "Kainyu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qd0 Qc0 Kd0/2d0 3d0 4s0 5c0 6h0/2h0 2c0 Th0 Tc0 Ts0",
            "win": 230,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "AawaraLaunda",
            "orderIndex": 1,
            "hero": true,
            "dead": "Ad1 Qh2 5s3 Kc4",
            "rows": "9c2 9s2 9d3/8c0 Jc0 Js1 Jd3 8h4/5d0 7d0 8d0 4d1 2s4",
            "win": -230,
            "playerId": "AawaraLaunda"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:54:36",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338206614": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "Kainyu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ks1 4h4 8d4/5d0 6d0 3s2 4c3 7c3/6h0 7h0 8h0 Qh1 Jh2",
            "win": 90,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "AawaraLaunda",
            "orderIndex": 0,
            "hero": true,
            "dead": "4s1 Jc2 6c3 Ah4",
            "rows": "Kd2 Ac2 6s4/3d0 5s0 3c1 5c3 Jd3/9h0 9d0 Tc0 Th1 As4",
            "win": -90,
            "playerId": "AawaraLaunda"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 07:58:51",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338207437": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "Kainyu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ks0 Kc1 5h4/2s0 Qd2 2c3 Qc3 Kh4/5c0 6h0 8d0 7c1 9c2",
            "win": -60,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "AawaraLaunda",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qh1 4h2 Tc3 6d4",
            "rows": "As2 8c4 Ac4/2d0 9d0 2h1 9s1 7h2/8h0 8s0 Js0 Jh3 Jc3",
            "win": 60,
            "playerId": "AawaraLaunda"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:00:39",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338207788": [
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "Kainyu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "9c0 Td0 Jh0/2d0 3c0 4c0 5s0 6s0/7d0 7s0 Ah0 Ac0 As0",
            "win": -130,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": true,
            "result": 27,
            "playerName": "AawaraLaunda",
            "orderIndex": 1,
            "hero": true,
            "dead": "3s0 4h0 6c0",
            "rows": "Ts0 Kc0 Ks0/4d0 6d0 Jd0 Qd0 Ad0/2h0 2c0 2s0 7h0 7c0",
            "win": 130,
            "playerId": "AawaraLaunda"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:01:55",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338208021": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "Kainyu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kd0 Qd1 Jc3/4h0 2d2 Ad2 Tc3 Td4/5h0 5s0 8s0 8d1 9h4",
            "win": -210,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 33,
            "playerName": "AawaraLaunda",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ks1 4d2 3c3 Kh4",
            "rows": "Ah1 Qc2 Ac3/2s0 3s0 6h0 2h2 3d3/9d0 Th0 9c1 9s4 Ts4",
            "win": 210,
            "playerId": "AawaraLaunda"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:03:34",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338208318": [
        {
            "inFantasy": false,
            "result": 17,
            "playerName": "Kainyu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ad3 As3 Qs4/6s1 9c1 4c2 5s2 2d4/6d0 9h0 Jh0 Jd0 Jc0",
            "win": -290,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": true,
            "result": 25,
            "playerName": "AawaraLaunda",
            "orderIndex": 1,
            "hero": true,
            "dead": "3h0 3d0 7d0",
            "rows": "Qh0 Qd0 Ah0/4d0 4s0 5h0 5d0 5c0/8h0 8d0 8c0 Tc0 Ts0",
            "win": 290,
            "playerId": "AawaraLaunda"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:04:36",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338208498": [
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "Kainyu",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Js2 Kd3 Ah4/9h0 9c0 8s1 Th2 8c4/2d0 3d0 Ad0 Jd1 8d3",
            "win": 30,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "AawaraLaunda",
            "orderIndex": 0,
            "hero": true,
            "dead": "6h1 2h2 7h3 5c4",
            "rows": "Ks1 Ac3 9d4/4c0 8h0 4h2 Qd2 Kc4/5s0 6s0 9s0 7s1 2s3",
            "win": -90,
            "playerId": "AawaraLaunda"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "As1 Jc3 7d4/4d0 Td0 4s1 7c2 Ts3/3c0 3s0 Qs0 Qh2 Qc4",
            "win": 60,
            "playerId": "shubhamkumarjha75"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:07:37",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338209033": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Kainyu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kd0 5s2 9s4/2c0 5c0 2s1 5h1 8s2/6h0 6s0 4d3 Qc3 4c4",
            "win": 60,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "AawaraLaunda",
            "orderIndex": 1,
            "hero": true,
            "dead": "9c1 6c2 9h3 3c4",
            "rows": "Qd0 9d2 7h4/2d0 7c0 Kc1 Ad2 7d3/8d0 8c0 Jh1 4s3 3h4",
            "win": -60,
            "playerId": "AawaraLaunda"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:09:24",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338209414": [
        {
            "inFantasy": false,
            "result": 63,
            "playerName": "Kainyu",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ac0 Ah1 8s4/5s0 6c0 6h1 5h2 7d3/9d0 Jh0 2c2 Jc3 2s4",
            "win": 230,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "AawaraLaunda",
            "orderIndex": 0,
            "hero": true,
            "dead": "3d1 Qc2 9h3 2d4",
            "rows": "Kd0 Ad3 Tc4/5d0 3h2 3c2 7s3 7h4/8h0 Th0 Js0 Td1 Ts1",
            "win": -20,
            "playerId": "AawaraLaunda"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "MUKSNOLE",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kh2 Kc2 3s3/7c0 6s1 9c1 9s3 Jd4/8d0 8c0 Qh0 Qs0 As4",
            "win": -210,
            "playerId": "MUKSNOLE"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:11:41",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338209821": [
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "Kainyu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "6d0 6c0 Kd0/3h0 3d0 4c0 4s0 Qc0/2d0 2s0 Jh0 Jd0 Jc0",
            "win": 100,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "AawaraLaunda",
            "orderIndex": 2,
            "hero": true,
            "dead": "5d1 2h2 5c3 3c4",
            "rows": "Qs0 9s3 Ts4/4d0 Kc1 Ks1 Ac2 5h4/7s0 8d0 9c0 7h2 7d3",
            "win": -230,
            "playerId": "AawaraLaunda"
        },
        {
            "inFantasy": false,
            "result": 57,
            "playerName": "MUKSNOLE",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ad1 Kh2 Ah4/6h0 6s0 8h0 7c2 8s3/9d0 Td0 Tc1 Qd3 Qh4",
            "win": 130,
            "playerId": "MUKSNOLE"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:13:55",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338210257": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "Kainyu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qc0 4c1 Qh1/3c0 6s0 Kd3 Ks3 Kc4/8h0 Jh0 9d2 Tc2 6d4",
            "win": -270,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 23,
            "playerName": "AawaraLaunda",
            "orderIndex": 1,
            "hero": true,
            "dead": "6h1 2d2 2c3 8s4",
            "rows": "Ah0 5c2 8d3/4s0 Td0 9s1 5d3 8c4/Qd0 Qs0 7c1 7s2 2s4",
            "win": -250,
            "playerId": "AawaraLaunda"
        },
        {
            "inFantasy": true,
            "result": 64,
            "playerName": "MUKSNOLE",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Jd0 Ad0 Ac0/2h0 5h0 9h0 Th0 Kh0/3s0 5s0 Ts0 Js0 As0",
            "win": 520,
            "playerId": "MUKSNOLE"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:16:16",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338210703": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "Kainyu",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qd0 As0 Qh1/3h0 3s0 4d2 2c3 Kc4/Jh0 7h1 Jd2 9c3 9d4",
            "win": 0,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "AawaraLaunda",
            "orderIndex": 0,
            "hero": true,
            "dead": "9s1 9h2 4c3 Ts4",
            "rows": "Qc0 Qs0 6c4/Kd0 7c2 Ac2 2s3 6h4/5h0 Th0 8d1 8c1 Td3",
            "win": 0,
            "playerId": "AawaraLaunda"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "MUKSNOLE",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kh0 Ah3 Ks4/8s0 6s1 7s2 Js2 4s3/3c0 5c0 Tc0 Jc1 2d4",
            "win": 0,
            "playerId": "MUKSNOLE"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:18:57",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338211173": [
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "Kainyu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ad0 Jd1 7c2/6h0 Qh0 4h2 Ac3 6s4/9s0 Ks0 Kc1 Kh3 2h4",
            "win": 30,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "AawaraLaunda",
            "orderIndex": 2,
            "hero": true,
            "dead": "3s1 Kd2 3h3 Jc4",
            "rows": "Ah0 As0 Tc3/9h0 9c0 7d1 5d4 Td4/Js0 Qc1 8d2 8s2 Qs3",
            "win": -160,
            "playerId": "AawaraLaunda"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "MUKSNOLE",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ts0 Qd3 9d4/2d0 3d0 4s1 5c2 3c4/5h0 8h0 Jh1 7h2 Th3",
            "win": 130,
            "playerId": "MUKSNOLE"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:21:23",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338211619": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "Kainyu",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qh2 Kc2 Qc4/4s0 6h0 6c1 8h3 8c3/Jh0 Jc0 Js0 9h1 Ac4",
            "win": -10,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "AawaraLaunda",
            "orderIndex": 0,
            "hero": true,
            "dead": "3h1 9c2 9s3 Kd4",
            "rows": "As0 3s2 Ah2/2d0 4c0 6d0 4d3 2h4/Th0 7h1 Ts1 7s3 5h4",
            "win": 10,
            "playerId": "AawaraLaunda"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:22:55",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338211890": [
        {
            "inFantasy": true,
            "result": 18,
            "playerName": "Kainyu",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "8c0 Tc0 Qh0/4s0 5c0 6h0 7c0 8d0/2h0 2s0 Jh0 Jd0 Js0",
            "win": -180,
            "playerId": "Kainyu"
        },
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "AawaraLaunda",
            "orderIndex": 1,
            "hero": true,
            "dead": "3c0 6c0 9c0",
            "rows": "Ts0 Kh0 Ks0/3d0 5d0 6d0 7d0 Td0/Qc0 Qs0 Ah0 Ad0 Ac0",
            "win": 180,
            "playerId": "AawaraLaunda"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:30:39",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338213250": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "Dularidevi",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kh0 Kc3 3d4/7h0 4s1 8d2 8c2 3s4/3c0 5c0 Ac0 2c1 Qc3",
            "win": -120,
            "playerId": "Dularidevi"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "AawaraLaunda",
            "orderIndex": 1,
            "hero": true,
            "dead": "9s1 3h2 8h3 5s4",
            "rows": "Ah1 7s3 7d4/5h0 6c0 6h1 Jh3 6d4/9d0 Td0 Kd0 Js2 Qh2",
            "win": 120,
            "playerId": "AawaraLaunda"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:33:00",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338213704": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "Dularidevi",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ah0 Ks1 8c3/4c0 Jh1 8d2 8s2 Kd4/6h0 6d0 Qd0 9s3 9c4",
            "win": -100,
            "playerId": "Dularidevi"
        },
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "AawaraLaunda",
            "orderIndex": 0,
            "hero": true,
            "dead": "5d1 As2 7c3 Qc4",
            "rows": "Ad0 Ac1 Kc4/2c0 3c1 2d2 7h3 7d3/5h0 8h0 9h0 5s2 9d4",
            "win": 100,
            "playerId": "AawaraLaunda"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:35:35",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338214206": [
        {
            "inFantasy": false,
            "result": 60,
            "playerName": "Dularidevi",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Jh3 Kd3 8h4/4h1 4c1 4s2 6h2 3h4/2c0 5c0 6c0 Tc0 Qc0",
            "win": -300,
            "playerId": "Dularidevi"
        },
        {
            "inFantasy": true,
            "result": 72,
            "playerName": "AawaraLaunda",
            "orderIndex": 1,
            "hero": true,
            "dead": "3c0 4d0 5h0",
            "rows": "Ah0 Ad0 As0/7d0 8c0 9c0 Ts0 Jc0/7h0 9h0 Th0 Qh0 Kh0",
            "win": 300,
            "playerId": "AawaraLaunda"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:36:32",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338214393": [
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "Dularidevi",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kd3 Kc3 Qc4/Jd1 Jc1 4d2 4s2 7s4/6h0 8h0 Qh0 Kh0 Ah0",
            "win": -30,
            "playerId": "Dularidevi"
        },
        {
            "inFantasy": true,
            "result": -27,
            "playerName": "AawaraLaunda",
            "orderIndex": 0,
            "hero": true,
            "dead": "4c0",
            "rows": "7d0 8d0 9c0/3s0 5s0 8s0 Qs0 As0/2h0 2d0 6d0 6c0 6s0",
            "win": 30,
            "playerId": "AawaraLaunda"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:37:06",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338214507": [
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "Dularidevi",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "2h0 2d0 2c0/Qs0 Kh0 Kc0 Ks0 Ah0/3h0 3d0 3s0 4h0 4d0",
            "win": 40,
            "playerId": "Dularidevi"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "AawaraLaunda",
            "orderIndex": 1,
            "hero": true,
            "dead": "7h1 Qc2 Jc3 5c4",
            "rows": "As0 Ad2 Js4/3c0 5h0 4c3 7d3 6h4/8h0 Jd0 Tc1 Qh1 9s2",
            "win": -40,
            "playerId": "AawaraLaunda"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:38:07",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338214700": [
        {
            "inFantasy": true,
            "result": 12,
            "playerName": "Dularidevi",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "6d0 9d0 9s0/3s0 5d0 5s0 8d0 8s0/4c0 7c0 Tc0 Qc0 Kc0",
            "win": -110,
            "playerId": "Dularidevi"
        },
        {
            "inFantasy": true,
            "result": 18,
            "playerName": "AawaraLaunda",
            "orderIndex": 0,
            "hero": true,
            "dead": "3d0 4d0 6c0",
            "rows": "Ks0 Ac0 As0/4h0 5h0 8h0 Th0 Kh0/7h0 7d0 7s0 Jh0 Jd0",
            "win": 110,
            "playerId": "AawaraLaunda"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:39:36",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338214936": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Dularidevi",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "4h3 4c3 Qc4/6d0 8h0 Jh2 Js2 Th4/5c0 7c0 Tc0 3c1 Jc1",
            "win": 100,
            "playerId": "Dularidevi"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "AawaraLaunda",
            "orderIndex": 1,
            "hero": true,
            "dead": "6h1 9d2 Ts3 8d4",
            "rows": "Ah0 Kd3 Ad3/5h0 5d0 7h0 4d2 6c4/Qd0 2c1 Qh1 2s2 3h4",
            "win": -100,
            "playerId": "AawaraLaunda"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:41:35",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338215273": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "Dularidevi",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qc0 Js1 Qd1/2d0 8s0 6c3 2s4 7s4/5h0 Kh0 6h2 Ah2 Ac3",
            "win": -200,
            "playerId": "Dularidevi"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "AawaraLaunda",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qs1 Td2 9c3 8h4",
            "rows": "Ad1 9h2 Qh3/4h1 5c2 8d3 6d4 7h4/3c0 7c0 Tc0 Jc0 Kc0",
            "win": 230,
            "playerId": "AawaraLaunda"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "RaghSaiAyy",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kd0 As1 6s4/3h0 4s0 4c1 2h2 2c3/9d0 Ts0 9s2 Jh3 Th4",
            "win": -30,
            "playerId": "RaghSaiAyy"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:45:12",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338215947": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "AawaraLaunda",
            "orderIndex": 1,
            "hero": true,
            "dead": "8c1 6c2 8s3 Jc4",
            "rows": "8d2 Ad3 Kd4/3c0 Qc0 3h1 2c3 Qd4/7h0 8h0 Qh0 6h1 Kh2",
            "win": -80,
            "playerId": "AawaraLaunda"
        },
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "RaghSaiAyy",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ah0 Ks2 Ac4/9c1 Jh2 7c3 7s3 Js4/2d0 3d0 6d0 9d0 5d1",
            "win": 80,
            "playerId": "RaghSaiAyy"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:47:04",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338216270": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "AawaraLaunda",
            "orderIndex": 0,
            "hero": true,
            "dead": "2d1 Ad2 3s3 5c4",
            "rows": "Qh0 Qc1 Tc4/Ah0 Ac0 Ks2 3c3 4c3/6h0 7h0 5s1 6c2 5d4",
            "win": -100,
            "playerId": "AawaraLaunda"
        },
        {
            "inFantasy": true,
            "result": -6,
            "playerName": "RaghSaiAyy",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Jd0 Jc0 Kc0/2c0 3h0 4s0 5h0 As0/4h0 4d0 9d0 9c0 9s0",
            "win": 100,
            "playerId": "RaghSaiAyy"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:47:49",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338216408": [
        {
            "inFantasy": true,
            "result": 27,
            "playerName": "AawaraLaunda",
            "orderIndex": 1,
            "hero": true,
            "dead": "7c0",
            "rows": "Kd0 Ks0 Ad0/2h0 2c0 8h0 8c0 Jd0/5s0 7s0 Ts0 Js0 Qs0",
            "win": 130,
            "playerId": "AawaraLaunda"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "RaghSaiAyy",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "5d3 Td3 3h4/Jh1 Jc1 9d2 9s2 8s4/7h0 7d0 Tc0 Qh0 Qd0",
            "win": -130,
            "playerId": "RaghSaiAyy"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:48:47",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338216576": [
        {
            "inFantasy": false,
            "result": -30,
            "playerName": "AawaraLaunda",
            "orderIndex": 0,
            "hero": true,
            "dead": "8s1 4c2 7c3 4s4",
            "rows": "Kd0 Ah3 Tc4/Qs0 Qd1 9d2 9c2 2h4/Jd0 Jc0 Js0 Jh1 8h3",
            "win": 0,
            "playerId": "AawaraLaunda"
        },
        {
            "inFantasy": false,
            "result": -24,
            "playerName": "RaghSaiAyy",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ks0 Ad4 Ac4/2s1 7h1 2d2 Ts2 Td3/5h0 6d0 7d0 8d0 9h3",
            "win": 0,
            "playerId": "RaghSaiAyy"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:50:35",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338216898": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "AawaraLaunda",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jd1 9c2 9s3 3s4",
            "rows": "Qc1 Td2 Kc3/4s0 8c0 7d1 5d2 6d3/3h0 6h0 Kh0 3d4 3c4",
            "win": -180,
            "playerId": "AawaraLaunda"
        },
        {
            "inFantasy": true,
            "result": 12,
            "playerName": "RaghSaiAyy",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "7h0 7c0 Kd0/Tc0 Js0 Qh0 Ks0 Ad0/2d0 2s0 5h0 5c0 5s0",
            "win": 180,
            "playerId": "RaghSaiAyy"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:52:27",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338217202": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "AawaraLaunda",
            "orderIndex": 0,
            "hero": true,
            "dead": "9d1 5s2 8s3 3h4",
            "rows": "Ah3 Qd4 Kc4/Kh0 Kd0 6s1 2c2 6h3/5c0 6c0 7c0 4s1 8c2",
            "win": -140,
            "playerId": "AawaraLaunda"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "RaghSaiAyy",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ks3 9c4 9s4/2d0 3d0 5h0 4d2 6d3/9h0 Tc0 7h1 8h1 Jc2",
            "win": 140,
            "playerId": "RaghSaiAyy"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:54:44",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338217572": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "AawaraLaunda",
            "orderIndex": 1,
            "hero": true,
            "dead": "2h1 Jd2 9s3 5h4",
            "rows": "Qd2 Ks3 Ts4/6s0 5d1 5s2 6c3 3d4/3h0 4h0 9h0 Jh0 8h1",
            "win": 30,
            "playerId": "AawaraLaunda"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "RaghSaiAyy",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kc1 5c3 As4/8s0 Td0 Tc0 8c1 7s2/Qc0 Qs0 Js2 Jc3 4c4",
            "win": -30,
            "playerId": "RaghSaiAyy"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:57:44",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338218015": [
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "AawaraLaunda",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jc1 Kh2 3c3 6c4",
            "rows": "As1 Ad2 Th4/5h0 6s0 8d1 5s3 6d4/7d0 9h0 9d0 3d2 7c3",
            "win": 60,
            "playerId": "AawaraLaunda"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "RaghSaiAyy",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kd2 Qh3 Jh4/7h0 9s0 6h2 8h3 8s4/4c0 Tc0 Kc0 2c1 8c1",
            "win": -60,
            "playerId": "RaghSaiAyy"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 08:59:38",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338218264": [
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "AawaraLaunda",
            "orderIndex": 1,
            "hero": true,
            "dead": "4s0 6d0 9s0",
            "rows": "2d0 2s0 Kd0/5c0 7c0 9c0 Qc0 Kc0/3h0 7h0 8h0 Jh0 Ah0",
            "win": 180,
            "playerId": "AawaraLaunda"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "RaghSaiAyy",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ks3 As3 9d4/Td1 Ts1 4h2 4d2 6h4/3d0 3c0 4c0 8d0 Jc0",
            "win": -180,
            "playerId": "RaghSaiAyy"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:02:15",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338218753": [
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "Honey17890",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qc3 8c4 Kh4/3d0 7d1 7h2 9h2 9c3/2h0 2c0 Jh0 Jc0 2s1",
            "win": 40,
            "playerId": "Honey17890"
        },
        {
            "inFantasy": false,
            "result": 63,
            "playerName": "AawaraLaunda",
            "orderIndex": 1,
            "hero": true,
            "dead": "2d1 5d2 4d3 As4",
            "rows": "Kc0 Ah3 Ac3/3c0 3s0 8s2 Qd4 Qs4/Ts0 Js0 4s1 9s1 5s2",
            "win": 270,
            "playerId": "AawaraLaunda"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "RaghSaiAyy",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Th1 Ad2 6d3/4c0 6s0 7c1 Kd2 Ks3/5h0 5c0 Qh0 3h4 Td4",
            "win": -310,
            "playerId": "RaghSaiAyy"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:05:00",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338219272": [
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "Honey17890",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qd1 Kh2 Qc3/4c0 4s0 Th2 4d3 Ad4/8s0 9d0 Ts0 7s1 6s4",
            "win": -40,
            "playerId": "Honey17890"
        },
        {
            "inFantasy": true,
            "result": -19,
            "playerName": "AawaraLaunda",
            "orderIndex": 0,
            "hero": true,
            "dead": "2s0 5h0 9s0",
            "rows": "6d0 Qh0 As0/2c0 3c0 5c0 6c0 Jc0/7h0 7d0 7c0 8h0 8d0",
            "win": 230,
            "playerId": "AawaraLaunda"
        },
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "RaghSaiAyy",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc1 Js2 Kd3/3s0 5d1 9c2 Ac3 Ks4/2h0 4h0 Jh0 Ah0 6h4",
            "win": -190,
            "playerId": "RaghSaiAyy"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:07:35",
    "roomId": "41b-1d515c57"
}


{
    "stakes": 10,
    "handData": {"338219727": [
        {
            "inFantasy": true,
            "result": 18,
            "playerName": "Honey17890",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "5h0 Th0 Tc0/2h0 3c0 4s0 5c0 Ac0/5d0 8d0 9d0 Jd0 Ad0",
            "win": 20,
            "playerId": "Honey17890"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "AawaraLaunda",
            "orderIndex": 1,
            "hero": true,
            "dead": "Td1 2d2 2c3 7s4",
            "rows": "Ah0 8c4 Ks4/8h0 9h0 5s2 6h3 7h3/Qc0 Qs0 Jh1 Js1 Qd2",
            "win": -20,
            "playerId": "AawaraLaunda"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:08:40",
    "roomId": "41b-1d515c57"
}


