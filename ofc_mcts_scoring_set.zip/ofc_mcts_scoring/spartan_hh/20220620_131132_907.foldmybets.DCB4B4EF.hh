{
    "stakes": 5,
    "handData": {"338231300": [
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "2Pac4life",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ad1 Kc3 8c4/5d0 Td0 4c2 4h3 As4/2s0 7s0 9s0 6s1 Js2",
            "win": 55,
            "playerId": "2Pac4life"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "foldmybets",
            "orderIndex": 1,
            "hero": true,
            "dead": "5s1 5c2 4d3 9h4",
            "rows": "Kd0 Kh1 5h4/7c0 7h1 6h2 8s2 2c4/Jd0 Jc0 Qd0 Jh3 Qh3",
            "win": -100,
            "playerId": "foldmybets"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "CMPUNK2412",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ah0 Qc3 9c4/3d0 3h1 8h1 Th3 Ac4/4s0 Ts0 Qs0 3s2 Ks2",
            "win": 45,
            "playerId": "CMPUNK2412"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:11:32",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338231862": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "2Pac4life",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "5s1 Js3 Qh4/3c0 6c0 9d1 Ah3 As4/4h0 4c0 Qs0 4d2 4s2",
            "win": 125,
            "playerId": "2Pac4life"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "foldmybets",
            "orderIndex": 0,
            "hero": true,
            "dead": "3s1 3h2 7d3 5d4",
            "rows": "Ks2 7h3 Jd4/6d0 8h1 8s1 Ts2 3d4/Td0 Jh0 Qc0 Kh0 9s3",
            "win": -5,
            "playerId": "foldmybets"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "CMPUNK2412",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Kd3 7s4/6s0 Ad1 2d2 2s2 Ac3/5h0 9h0 Th0 6h1 Qd4",
            "win": -120,
            "playerId": "CMPUNK2412"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:14:08",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338232279": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "2Pac4life",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "As0 Jh3 6s4/6h0 8h1 9c1 6c2 9s2/Td0 Ts0 Kd0 Kh3 4s4",
            "win": 35,
            "playerId": "2Pac4life"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "foldmybets",
            "orderIndex": 2,
            "hero": true,
            "dead": "Js1 4h2 7d3 Qh4",
            "rows": "Ac1 Ah2 Jd3/5s0 8d0 5h1 4c3 7h4/3h0 3s0 9d0 9h2 2d4",
            "win": -60,
            "playerId": "foldmybets"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "CMPUNK2412",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ks0 8c3 Ad3/2s0 6d0 7c2 7s2 2c4/Tc0 Qd0 Th1 Qs1 Kc4",
            "win": 25,
            "playerId": "CMPUNK2412"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:16:35",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338232724": [
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "2Pac4life",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qs2 6d3 Ac4/5d0 6c0 2h1 2c1 5c3/8h0 8c0 Jh0 9c2 9d4",
            "win": -25,
            "playerId": "2Pac4life"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "foldmybets",
            "orderIndex": 1,
            "hero": true,
            "dead": "2s1 9h2 8s3 Th4",
            "rows": "Kh0 Ks2 Ad3/7h0 7c1 Jd1 3h2 8d4/Td0 Tc0 Qh0 Qd3 4s4",
            "win": -110,
            "playerId": "foldmybets"
        },
        {
            "inFantasy": false,
            "result": 57,
            "playerName": "CMPUNK2412",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qc1 Kd3 Kc4/Jc0 As1 4c2 6s3 Ah4/2d0 4d0 5s0 6h0 3d2",
            "win": 135,
            "playerId": "CMPUNK2412"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:19:32",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338233275": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "2Pac4life",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ac0 Kd2 As4/2d0 6d0 2s3 3s3 2c4/4s0 Ts0 5s1 7s1 9s2",
            "win": 10,
            "playerId": "2Pac4life"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "foldmybets",
            "orderIndex": 0,
            "hero": true,
            "dead": "9d1 Qs2 3c3 4c4",
            "rows": "Qh0 Qd0 Ad4/Kc0 Ks0 8c2 8h3 Jh4/Ah0 5h1 6h1 2h2 9h3",
            "win": -50,
            "playerId": "foldmybets"
        },
        {
            "inFantasy": true,
            "result": -24,
            "playerName": "CMPUNK2412",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Th0 Td0 Kh0/3d0 4d0 7d0 8d0 Jd0/5c0 6c0 9c0 Jc0 Qc0",
            "win": 40,
            "playerId": "CMPUNK2412"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:21:52",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338233714": [
        {
            "inFantasy": true,
            "result": 57,
            "playerName": "2Pac4life",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qs0 Kh0 Ks0/6c0 7c0 9c0 Tc0 Qc0/2d0 6d0 8d0 9d0 Ad0",
            "win": 125,
            "playerId": "2Pac4life"
        },
        {
            "inFantasy": true,
            "result": 24,
            "playerName": "foldmybets",
            "orderIndex": 2,
            "hero": true,
            "dead": "4d0",
            "rows": "Jc0 Kc0 As0/2c0 2s0 5d0 6h0 6s0/5h0 7h0 9h0 Qh0 Ah0",
            "win": -90,
            "playerId": "foldmybets"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "CMPUNK2412",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "8c3 Ac3 7d4/Th1 Jh1 4h2 8h2 2h4/3d0 Td0 Jd0 Qd0 Kd0",
            "win": -35,
            "playerId": "CMPUNK2412"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:23:21",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338233984": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "2Pac4life",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "4s3 9c4 Jh4/6h0 2s1 4c1 3c2 5s3/9h0 Tc0 Jd0 Qs0 8h2",
            "win": 95,
            "playerId": "2Pac4life"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "foldmybets",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qh1 7c2 2c3 7s4",
            "rows": "Ah1 4h2 8c3/3d0 9d0 5h1 5c2 6d4/9s0 Ts0 Ks0 Th3 3s4",
            "win": -5,
            "playerId": "foldmybets"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "CMPUNK2412",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ac0 Kh1 As3/6s0 7d0 7h1 4d2 Kd4/Td0 Qc0 Js2 8s3 Ad4",
            "win": -90,
            "playerId": "CMPUNK2412"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:25:49",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338234430": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "2Pac4life",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ah0 2h3 Ad3/7h0 4h1 7c1 9d2 Tc4/Jd0 Qh0 Qc0 Kd2 Kc4",
            "win": -140,
            "playerId": "2Pac4life"
        },
        {
            "inFantasy": false,
            "result": 57,
            "playerName": "foldmybets",
            "orderIndex": 0,
            "hero": true,
            "dead": "5h1 8h2 5d3 4c4",
            "rows": "Ks1 6s4 Kh4/8d0 Td0 3d1 3h2 8s3/5c0 8c0 9c0 2c2 6c3",
            "win": 135,
            "playerId": "foldmybets"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "CMPUNK2412",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Th2 Jc2 4d4/2d0 6d0 Qd1 6h3 2s4/5s0 7s0 As0 Js1 Ts3",
            "win": 5,
            "playerId": "CMPUNK2412"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:29:05",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338235048": [
        {
            "inFantasy": false,
            "result": 33,
            "playerName": "2Pac4life",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "9s2 9d4 Tc4/2d0 Qd0 8d1 2c3 Qc3/3h0 6h0 8h0 Kh1 Ah2",
            "win": 75,
            "playerId": "2Pac4life"
        },
        {
            "inFantasy": true,
            "result": 15,
            "playerName": "foldmybets",
            "orderIndex": 2,
            "hero": true,
            "dead": "2s0 Jd0",
            "rows": "9c0 Ks0 Ad0/3c0 4d0 5c0 6c0 7d0/2h0 5h0 9h0 Jh0 Qh0",
            "win": 65,
            "playerId": "foldmybets"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "CMPUNK2412",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kc0 As1 Kd3/6s0 8c0 7c2 7s2 7h3/Td0 Ts0 Jc1 4h4 5d4",
            "win": -140,
            "playerId": "CMPUNK2412"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:30:49",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338235400": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "2Pac4life",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ac3 7h4 Tc4/2h0 2c0 5c1 Jc1 Jh2/8d0 9d0 Kd0 Kh2 8c3",
            "win": 60,
            "playerId": "2Pac4life"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "foldmybets",
            "orderIndex": 1,
            "hero": true,
            "dead": "6d1 6s2 4c3 As4",
            "rows": "Qd3 Qc3 Js4/Jd0 3c1 3s1 3d2 9c2/4s0 5h0 6c0 7c0 4d4",
            "win": -60,
            "playerId": "foldmybets"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "CMPUNK2412",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qs2 6h3 Kc3/4h0 9h1 9s1 7s2 Ks4/2d0 7d0 Td0 Ad0 Ah4",
            "win": 0,
            "playerId": "CMPUNK2412"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:32:59",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338235836": [
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "2Pac4life",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qh1 Kh3 Ks4/3c0 8d0 8s1 Js3 3s4/Td0 Ts0 Jh0 Th2 Jc2",
            "win": 35,
            "playerId": "2Pac4life"
        },
        {
            "inFantasy": false,
            "result": 45,
            "playerName": "foldmybets",
            "orderIndex": 0,
            "hero": true,
            "dead": "8h1 5d2 9d3 4c4",
            "rows": "Kc3 As3 Jd4/9c0 6s1 6d2 9h2 7h4/4d0 4s0 5h0 5s0 4h1",
            "win": -95,
            "playerId": "foldmybets"
        },
        {
            "inFantasy": false,
            "result": 36,
            "playerName": "CMPUNK2412",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ah1 Kd3 Ad3/3d0 9s1 Qd2 Qs2 Qc4/2c0 5c0 8c0 Ac0 6c4",
            "win": 60,
            "playerId": "CMPUNK2412"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:35:26",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338236264": [
        {
            "inFantasy": true,
            "result": 45,
            "playerName": "2Pac4life",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kd0 Ah0 Ac0/5c0 5s0 6d0 6c0 Jc0/8s0 9h0 9d0 9c0 9s0",
            "win": 55,
            "playerId": "2Pac4life"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "foldmybets",
            "orderIndex": 2,
            "hero": true,
            "dead": "3d1 Jh2 5d3 3s4",
            "rows": "Qd2 8c3 Tc4/2d0 3c0 6h0 2c1 3h1/4s0 7s0 Js2 7d3 4h4",
            "win": -155,
            "playerId": "foldmybets"
        },
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "CMPUNK2412",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "8h0 8d0 Ad0/2s0 6s0 Ts0 Qs0 As0/4d0 4c0 Kh0 Kc0 Ks0",
            "win": 100,
            "playerId": "CMPUNK2412"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:37:26",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338236647": [
        {
            "inFantasy": true,
            "result": 24,
            "playerName": "2Pac4life",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "9s0 Jh0 Jd0/2c0 3c0 5c0 6c0 Jc0/2d0 6d0 8d0 Kd0 Ad0",
            "win": 120,
            "playerId": "2Pac4life"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "CMPUNK2412",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc3 As3 Qd4/5h1 5s1 4c2 4s2 3h4/7d0 7c0 7s0 9c0 Td0",
            "win": -120,
            "playerId": "CMPUNK2412"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": false,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:38:14",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338236803": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "2Pac4life",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kh0 Kc1 As4/6c0 7c0 Ad1 Jh3 Ac3/8d0 Qs0 8h2 Ts2 Jd4",
            "win": -60,
            "playerId": "2Pac4life"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "foldmybets",
            "orderIndex": 0,
            "hero": true,
            "dead": "3s1 Qh2 4c3 2h4",
            "rows": "Tc3 9s4 Kd4/2s0 5d0 5c0 3c2 5s3/7d0 Td0 9d1 Qd1 3d2",
            "win": 120,
            "playerId": "foldmybets"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "CMPUNK2412",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ah0 Qc1 9c3/2d0 7s0 Ks3 8c4 Th4/4h0 4d0 Js1 4s2 Jc2",
            "win": -60,
            "playerId": "CMPUNK2412"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:40:59",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338237283": [
        {
            "inFantasy": false,
            "result": 63,
            "playerName": "2Pac4life",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ah0 Kd1 As2/2c0 3s0 2h1 7s3 3h4/6h0 Jh0 Js2 6d3 Ks4",
            "win": 125,
            "playerId": "2Pac4life"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "foldmybets",
            "orderIndex": 2,
            "hero": true,
            "dead": "2d1 Jd2 5d3 Kc4",
            "rows": "Qh0 Kh2 Qd4/9c0 Ad0 Ac0 Tc1 5h3/6s0 9s1 7h2 7c3 Jc4",
            "win": -105,
            "playerId": "foldmybets"
        },
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "CMPUNK2412",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qc3 5c4 5s4/3d0 8d0 3c1 8c1 4h2/9h0 9d0 Ts0 Th2 8h3",
            "win": -20,
            "playerId": "CMPUNK2412"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:43:48",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338237809": [
        {
            "inFantasy": true,
            "result": 9,
            "playerName": "2Pac4life",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "3h0 3s0 As0/4h0 5h0 Th0 Jh0 Qh0/2c0 6c0 8c0 Tc0 Kc0",
            "win": 135,
            "playerId": "2Pac4life"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "foldmybets",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jc1 Js2 7s3 2h4",
            "rows": "5s3 9h3 Ah4/4d0 5d1 6d2 Qd2 6s4/4s0 8s0 Ts0 Ks0 Qs1",
            "win": 5,
            "playerId": "foldmybets"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "CMPUNK2412",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ac0 Qc2 Ad3/7h0 4c2 7c3 3c4 Kh4/2d0 Td0 Jd0 9d1 Kd1",
            "win": -140,
            "playerId": "CMPUNK2412"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:46:04",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338238202": [
        {
            "inFantasy": false,
            "result": 75,
            "playerName": "2Pac4life",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ah3 6s4 Ts4/3s0 6d0 6h1 9c1 3h2/Jh0 Kc0 Ks0 Kd2 Kh3",
            "win": -165,
            "playerId": "2Pac4life"
        },
        {
            "inFantasy": false,
            "result": 90,
            "playerName": "foldmybets",
            "orderIndex": 0,
            "hero": true,
            "dead": "4s1 9s2 Qs3 Ad4",
            "rows": "Td3 Th4 Tc4/7h0 8d0 7d1 7c2 8h3/2d0 Qh0 Qc0 2s1 Qd2",
            "win": 270,
            "playerId": "foldmybets"
        },
        {
            "inFantasy": false,
            "result": 51,
            "playerName": "CMPUNK2412",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "As0 7s3 Ac3/6c0 8s0 8c1 2h4 2c4/3d0 3c0 Js1 Jd2 Jc2",
            "win": -105,
            "playerId": "CMPUNK2412"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:48:56",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338238695": [
        {
            "inFantasy": false,
            "result": 45,
            "playerName": "2Pac4life",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc3 Ah3 8h4/Th1 Tc1 Jd2 Ac2 4d4/2h0 3h0 5h0 6h0 7h0",
            "win": -85,
            "playerId": "2Pac4life"
        },
        {
            "inFantasy": true,
            "result": 45,
            "playerName": "foldmybets",
            "orderIndex": 2,
            "hero": true,
            "dead": "4h0 6s0 Jh0 Ks0",
            "rows": "9h0 9d0 As0/2c0 4c0 5c0 8c0 Jc0/2d0 5d0 6d0 Td0 Qd0",
            "win": -85,
            "playerId": "foldmybets"
        },
        {
            "inFantasy": true,
            "result": 102,
            "playerName": "CMPUNK2412",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qh0 Qc0 Qs0/3s0 4s0 7s0 9s0 Ts0/3d0 7d0 8d0 Kd0 Ad0",
            "win": 170,
            "playerId": "CMPUNK2412"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:51:05",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338239034": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "foldmybets",
            "orderIndex": 0,
            "hero": true,
            "dead": "Kh1 Jc2 2c3 5d4",
            "rows": "Ks2 Ac3 4d4/6d0 8s0 5h1 5c1 6c2/9h0 9c0 Ts0 Qc3 2h4",
            "win": -55,
            "playerId": "foldmybets"
        },
        {
            "inFantasy": true,
            "result": 9,
            "playerName": "CMPUNK2412",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "4c0 6h0 6s0/7s0 8h0 8c0 Qs0 As0/2d0 7d0 Td0 Kd0 Ad0",
            "win": 55,
            "playerId": "CMPUNK2412"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:52:26",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338239261": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "foldmybets",
            "orderIndex": 1,
            "hero": true,
            "dead": "7h1 Tc2 5d3 3c4",
            "rows": "Kd0 Th3 3h4/2h0 9s2 Jh2 2s3 Kh4/6h0 6s0 Qd0 6d1 Qs1",
            "win": 60,
            "playerId": "foldmybets"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "CMPUNK2412",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qc1 Ks3 Kc4/4c0 7d0 7c1 5c2 5s2/8c0 8s0 Ts0 3d3 Jc4",
            "win": -60,
            "playerId": "CMPUNK2412"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:54:20",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338239595": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "2Pac4life",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ah0 Ac1 6h4/3s0 7c1 7d2 Th3 4s4/4h0 5h0 Qh0 Qc2 4d3",
            "win": -220,
            "playerId": "2Pac4life"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "foldmybets",
            "orderIndex": 1,
            "hero": true,
            "dead": "8s1 7s2 2h3 8h4",
            "rows": "Kh1 Kd2 9d3/5c0 6d0 5s2 Td3 Tc4/3d0 3c0 Jh0 3h1 Js4",
            "win": 75,
            "playerId": "foldmybets"
        },
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "CMPUNK2412",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qd2 Ad2 Ks4/2d0 2s0 8d1 8c1 2c3/9c0 9s0 Jc0 9h3 Jd4",
            "win": 145,
            "playerId": "CMPUNK2412"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:56:47",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338239954": [
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "2Pac4life",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "5h1 3c3 4s3/9h0 Ts0 8h1 Jd4 Qh4/6c0 7c0 Kc0 9c2 Qc2",
            "win": -30,
            "playerId": "2Pac4life"
        },
        {
            "inFantasy": true,
            "result": 93,
            "playerName": "foldmybets",
            "orderIndex": 0,
            "hero": true,
            "dead": "3d0 Kd0",
            "rows": "Ad0 Ac0 As0/7h0 8c0 9d0 Th0 Js0/6s0 7s0 8s0 9s0 Qs0",
            "win": 155,
            "playerId": "foldmybets"
        },
        {
            "inFantasy": false,
            "result": 63,
            "playerName": "CMPUNK2412",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ks0 Ah3 6h4/3s0 4c0 5s2 5c3 4d4/Td0 Tc0 2c1 2s1 2h2",
            "win": -125,
            "playerId": "CMPUNK2412"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:58:50",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338240270": [
        {
            "inFantasy": true,
            "result": -3,
            "playerName": "foldmybets",
            "orderIndex": 1,
            "hero": true,
            "dead": "2s0",
            "rows": "Td0 Jd0 Ks0/3h0 4d0 5s0 6s0 7d0/5c0 6c0 9c0 Jc0 Ac0",
            "win": 35,
            "playerId": "foldmybets"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "CMPUNK2412",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kc3 Ad3 Th4/3c1 3s1 6d2 Kh2 2d4/8s0 9h0 Ts0 Js0 Qh0",
            "win": -35,
            "playerId": "CMPUNK2412"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:59:36",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338240381": [
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "foldmybets",
            "orderIndex": 0,
            "hero": true,
            "dead": "9c1 Tc2 2d3 As4",
            "rows": "Ad0 Ah3 Ac4/3d0 5d1 3h2 Jd3 Qs4/7c0 7s0 Qc0 Qh1 7h2",
            "win": -70,
            "playerId": "foldmybets"
        },
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "CMPUNK2412",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc2 Kh3 9s4/2c0 2s0 3s1 6s1 3c2/4h0 4s0 Th0 Ts3 8c4",
            "win": 70,
            "playerId": "CMPUNK2412"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:01:27",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338240656": [
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "foldmybets",
            "orderIndex": 1,
            "hero": true,
            "dead": "9h1 Jc2 3h3 8c4",
            "rows": "7h3 9c4 Ah4/4h0 6h0 4d2 5d2 6s3/3s0 8s0 Ts0 4s1 Js1",
            "win": -85,
            "playerId": "foldmybets"
        },
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "CMPUNK2412",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Th0 Td0 Jd0/5c0 6c0 7c0 8h0 9d0/2c0 2s0 Kd0 Kc0 Ks0",
            "win": 85,
            "playerId": "CMPUNK2412"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:02:22",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338240814": [
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "foldmybets",
            "orderIndex": 0,
            "hero": true,
            "dead": "3h1 3d2 Js3 7c4",
            "rows": "Kc0 Ks1 Qh4/5h0 6h1 4d2 6d3 4h4/9s0 Tc0 Qd0 Ts2 9d3",
            "win": 70,
            "playerId": "foldmybets"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "CMPUNK2412",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ah0 Ac0 5d2/3c0 2d1 4s1 2s3 Ad4/7d0 7s0 8d2 7h3 5s4",
            "win": -70,
            "playerId": "CMPUNK2412"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:03:55",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338241036": [
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "foldmybets",
            "orderIndex": 1,
            "hero": true,
            "dead": "2d0 9s0",
            "rows": "Kh0 Ks0 As0/3d0 4c0 5d0 6h0 7c0/6c0 7s0 8c0 9c0 Ts0",
            "win": 10,
            "playerId": "foldmybets"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "CMPUNK2412",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qd3 Qs3 Ac4/5c1 5s1 2h2 2c2 7h4/8h0 8s0 Jd0 Jc0 Js0",
            "win": -10,
            "playerId": "CMPUNK2412"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:04:50",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338241171": [
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "foldmybets",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qc1 4c2 5d3 6c4",
            "rows": "Kd2 Th4 Kh4/8s0 Ts0 Tc2 3d3 3s3/2h0 2d0 Jc0 2s1 Jd1",
            "win": 75,
            "playerId": "foldmybets"
        },
        {
            "inFantasy": true,
            "result": 15,
            "playerName": "CMPUNK2412",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "5h0 6d0 6s0/9d0 Td0 Ks0 Ac0 As0/3c0 5c0 7c0 8c0 9c0",
            "win": -75,
            "playerId": "CMPUNK2412"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:05:57",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338241349": [
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "foldmybets",
            "orderIndex": 1,
            "hero": true,
            "dead": "3d0 5d0",
            "rows": "8d0 9c0 Jd0/5s0 6s0 8s0 Qs0 Ks0/2h0 7h0 Qh0 Kh0 Ah0",
            "win": 90,
            "playerId": "foldmybets"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "CMPUNK2412",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ad3 As3 4h4/Jh1 Jc1 9h2 Js2 3s4/2d0 4d0 9d0 9s0 Td0",
            "win": -90,
            "playerId": "CMPUNK2412"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:06:43",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338241490": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "saro56",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qd0 Qs1 6d3/4s0 5d0 Kc2 Qc3 Qh4/8s0 Jh0 8h1 8c2 Jd4",
            "win": 95,
            "playerId": "saro56"
        },
        {
            "inFantasy": false,
            "result": 33,
            "playerName": "foldmybets",
            "orderIndex": 1,
            "hero": true,
            "dead": "9h1 8d2 6h3 Ad4",
            "rows": "Ac0 As1 Js3/2s0 Th2 Td2 Kh3 7h4/4d0 5s0 6s0 7d1 3s4",
            "win": -185,
            "playerId": "foldmybets"
        },
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "CMPUNK2412",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ks3 9s4 Kd4/Ts0 7s1 7c2 Tc2 9d3/2c0 3c0 5c0 Jc0 4c1",
            "win": 90,
            "playerId": "CMPUNK2412"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:09:07",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338241862": [
        {
            "inFantasy": true,
            "result": 0,
            "playerName": "saro56",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qc0 Qs0 Ah0/5d0 Th0 Jc0 Kd0 Kc0/4s0 6s0 8s0 9s0 Js0",
            "win": -60,
            "playerId": "saro56"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "foldmybets",
            "orderIndex": 0,
            "hero": true,
            "dead": "4c1 5c2 3s3 9h4",
            "rows": "Jd2 6c3 Ts3/7c0 9d0 7h1 8d2 7s4/4h0 6h0 Qh0 5h1 Kh4",
            "win": -65,
            "playerId": "foldmybets"
        },
        {
            "inFantasy": true,
            "result": 42,
            "playerName": "CMPUNK2412",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "5s0 Ac0 As0/9c0 Tc0 Jh0 Qd0 Ks0/3d0 4d0 7d0 Td0 Ad0",
            "win": 125,
            "playerId": "CMPUNK2412"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:11:10",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338242133": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "saro56",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "8h1 5c4 6c4/7h0 7d0 Jh1 8c2 8d3/Th0 Ts0 Qc0 9s2 Qd3",
            "win": -5,
            "playerId": "saro56"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "foldmybets",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jd1 5d2 5s3 3s4",
            "rows": "8s2 Kc2 Ac4/2h0 6h0 9h1 6s3 Jc4/Ah0 Ad0 As0 4c1 7c3",
            "win": 5,
            "playerId": "foldmybets"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:13:38",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338242435": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "saro56",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Tc1 Ah3 Jh4/2h0 6h0 2c2 6s2 Jd4/3d0 Qd0 Ad0 2d1 Kd3",
            "win": 50,
            "playerId": "saro56"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "foldmybets",
            "orderIndex": 0,
            "hero": true,
            "dead": "2s1 3s2 3c3 Ac4",
            "rows": "Kc0 6d3 7s4/5d0 7c0 7d1 8h2 8c3/Ts0 Qh0 9h1 Td2 5s4",
            "win": -50,
            "playerId": "foldmybets"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:15:17",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338242672": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "saro56",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "2s2 Ad3 2c4/4h0 Jd0 Ts1 Jh1 Tc2/3h0 3c0 Qh0 Qd3 Qc4",
            "win": 30,
            "playerId": "saro56"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "foldmybets",
            "orderIndex": 1,
            "hero": true,
            "dead": "Td1 Ac2 4d3 5c4",
            "rows": "Qs0 8h4 Ks4/5d0 8c0 4c1 8s2 5h3/9c0 9s0 6h1 9h2 6s3",
            "win": -30,
            "playerId": "foldmybets"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:17:06",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338242915": [
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "saro56",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ac0 Qh1 9d3/3h0 7h0 Jh1 3c2 8h4/2s0 8s0 9s2 5s3 Ts4",
            "win": -20,
            "playerId": "saro56"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "foldmybets",
            "orderIndex": 0,
            "hero": true,
            "dead": "Td1 Ks2 9c3 5c4",
            "rows": "Qc1 Qs3 7d4/2d0 Jc0 2c1 6c3 6d4/4h0 5h0 Th0 4d2 4c2",
            "win": 20,
            "playerId": "foldmybets"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:18:59",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338243151": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "saro56",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kh3 Kd3 Ad4/5h1 5d1 7d2 Tc2 2c4/6h0 6d0 6c0 9h0 9c0",
            "win": -85,
            "playerId": "saro56"
        },
        {
            "inFantasy": true,
            "result": 27,
            "playerName": "foldmybets",
            "orderIndex": 1,
            "hero": true,
            "dead": "2s0",
            "rows": "9d0 Qh0 Qd0/4h0 7s0 8h0 8d0 8c0/2d0 3s0 4s0 5c0 Ah0",
            "win": 85,
            "playerId": "foldmybets"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:20:11",
    "roomId": "41b-1d653b5e"
}


{
    "stakes": 5,
    "handData": {"338243301": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "saro56",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kh0 Ks0 6h3/4d0 4s1 3c2 3h3 3d4/5d0 5c0 Td1 Tc2 5h4",
            "win": 55,
            "playerId": "saro56"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "foldmybets",
            "orderIndex": 0,
            "hero": true,
            "dead": "6s1 4c2 5s3 7h4",
            "rows": "Kc0 Kd1 Qh2/8c0 9c1 Th2 8h3 9h4/2s0 Jh0 Js0 2h3 Jc4",
            "win": -55,
            "playerId": "foldmybets"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:21:59",
    "roomId": "41b-1d653b5e"
}





