{
    "stakes": 5,
    "handData": {"338176432": [
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "micnike",
            "orderIndex": 1,
            "hero": true,
            "dead": "8h1 Jh2 Qh3 Ah4",
            "rows": "Qs0 8d2 Tc3/4c0 7s1 5s2 6c3 8c4/2h0 2d0 9h0 9s1 9d4",
            "win": 20,
            "playerId": "micnike"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "Dularidevi",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ac0 8s3 Th4/4h0 9c0 3d1 4d1 3c2/Jc0 Js0 5h2 5d3 5c4",
            "win": -60,
            "playerId": "Dularidevi"
        },
        {
            "inFantasy": false,
            "result": 54,
            "playerName": "anantv",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ad0 Kc1 Ks1/3h0 6h0 6s2 6d4 Td4/Jd0 Qd0 Kh2 Ts3 As3",
            "win": 40,
            "playerId": "anantv"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 03:50:37",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338176688": [
        {
            "inFantasy": false,
            "result": 54,
            "playerName": "micnike",
            "orderIndex": 0,
            "hero": true,
            "dead": "8h1 Jc2 7h3 3d4",
            "rows": "Kc0 Kd3 Ts4/8d0 Ad0 Js1 3h2 Ac3/4h0 5s0 4c1 5h2 9c4",
            "win": 50,
            "playerId": "micnike"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "Dularidevi",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "8s1 4s3 Qd4/3c0 7s0 6s1 7c2 6d3/9h0 9d0 Jd0 9s2 Qh4",
            "win": -85,
            "playerId": "Dularidevi"
        },
        {
            "inFantasy": true,
            "result": 27,
            "playerName": "anantv",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "7d0 Tc0 As0/5d0 5c0 8c0 Qc0 Qs0/6h0 Th0 Jh0 Kh0 Ah0",
            "win": 35,
            "playerId": "anantv"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 03:54:17",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338176986": [
        {
            "inFantasy": true,
            "result": 15,
            "playerName": "micnike",
            "orderIndex": 2,
            "hero": true,
            "dead": "2d0 9d0",
            "rows": "Kc0 Ac0 As0/4c0 8c0 9c0 Tc0 Qc0/3h0 5h0 6h0 Qh0 Kh0",
            "win": 55,
            "playerId": "micnike"
        },
        {
            "inFantasy": false,
            "result": 33,
            "playerName": "Dularidevi",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Jc1 7h3 Qd4/7s0 Ts0 7d2 Th2 9s4/6d0 6c0 6s0 2c1 Td3",
            "win": -105,
            "playerId": "Dularidevi"
        },
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "anantv",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kd1 Ad2 Ah4/4s0 5c0 4h3 5s3 Ks4/3d0 3c0 8s0 3s1 8h2",
            "win": 50,
            "playerId": "anantv"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 03:57:09",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338177174": [
        {
            "inFantasy": false,
            "result": 51,
            "playerName": "micnike",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jh1 8c2 4s3 Ah4",
            "rows": "Ac0 As0 4d3/5c0 7d1 8h2 3h4 8s4/9d0 Qh0 Qd1 Qs2 Th3",
            "win": -165,
            "playerId": "micnike"
        },
        {
            "inFantasy": true,
            "result": 63,
            "playerName": "anantv",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Jd0 Jc0 Js0/2d0 3s0 4c0 5h0 6h0/2s0 5s0 6s0 Ts0 Ks0",
            "win": 165,
            "playerId": "anantv"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 03:58:42",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338177265": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "micnike",
            "orderIndex": 0,
            "hero": true,
            "dead": "Th1 9h2 4s3 8d4",
            "rows": "Kh0 Qd1 8h4/As0 3s2 3d3 Tc3 7h4/7c0 Jc0 Qc0 6c1 4c2",
            "win": -5,
            "playerId": "micnike"
        },
        {
            "inFantasy": true,
            "result": 3,
            "playerName": "anantv",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qh0 Kd0 Ad0/4d0 8c0 9d0 9s0 Jh0/2s0 6s0 7s0 Js0 Qs0",
            "win": 5,
            "playerId": "anantv"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 03:59:34",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338177318": [
        {
            "inFantasy": false,
            "result": 33,
            "playerName": "micnike",
            "orderIndex": 1,
            "hero": true,
            "dead": "Ts1 9h2 5d3 3s4",
            "rows": "As2 Kd4 Ac4/4d0 2s1 3d1 3c2 2h3/7h0 7d0 Jh0 Jd0 Js3",
            "win": 75,
            "playerId": "micnike"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "anantv",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "9d2 Qd2 8s3/8c0 Th1 Tc1 7s3 4h4/4c0 4s0 6h0 6c0 6d4",
            "win": -75,
            "playerId": "anantv"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 04:01:28",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338177485": [
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "micnike",
            "orderIndex": 0,
            "hero": true,
            "dead": "2d0 7s0 8h0",
            "rows": "Jh0 Qd0 Kd0/2c0 4c0 6c0 Qc0 Ac0/3d0 3s0 5h0 5d0 5s0",
            "win": 100,
            "playerId": "micnike"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "anantv",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kh3 Ks3 Jd4/6h1 6d1 5c2 6s2 4s4/7h0 7d0 Tc0 Ts0 Jc0",
            "win": -100,
            "playerId": "anantv"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 04:02:17",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338177557": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "micnike",
            "orderIndex": 1,
            "hero": true,
            "dead": "9s1 8d2 2c3 3d4",
            "rows": "As2 5s3 7c4/4h0 4c0 9d0 9h1 2h3/Th0 Jh0 Js1 3c2 Td4",
            "win": -75,
            "playerId": "micnike"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "anantv",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kd2 8c4 Kc4/4d0 4s1 7s2 7h3 Ts3/6d0 6s0 Qh0 Qs0 Qc1",
            "win": 75,
            "playerId": "anantv"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 04:03:51",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338177714": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "micnike",
            "orderIndex": 0,
            "hero": true,
            "dead": "8d1 5c2 5d3 Ks4",
            "rows": "Qh0 Kc0 Kd3/2d0 Ah0 2h2 9s3 Qc4/6s0 Th1 Td1 Tc2 3d4",
            "win": -85,
            "playerId": "micnike"
        },
        {
            "inFantasy": true,
            "result": 33,
            "playerName": "anantv",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qd0 Ad0 Ac0/2c0 2s0 8h0 8s0 9d0/3c0 4s0 5s0 6c0 7d0",
            "win": 85,
            "playerId": "anantv"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 04:04:55",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338177823": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "micnike",
            "orderIndex": 1,
            "hero": true,
            "dead": "8d1 4c2 7c3 5c4",
            "rows": "9c0 Td1 Ts2/3s0 Js0 Jd2 Qs3 Qc4/Qh0 Kh0 3h1 Ah3 Th4",
            "win": 75,
            "playerId": "micnike"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "anantv",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "6c1 Ad2 Ac3/3c0 9h0 Jh1 Jc2 Qd4/4s0 6s0 Ks0 4d3 7s4",
            "win": -75,
            "playerId": "anantv"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 04:13:15",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338178571": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "micnike",
            "orderIndex": 1,
            "hero": true,
            "dead": "4s1 7d2 8s3 3h4",
            "rows": "Kc0 Ad1 7s4/2h0 5h0 6c1 3s2 5d3/9s0 Jc0 Qs2 Qh3 Qc4",
            "win": -45,
            "playerId": "micnike"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "Seepoker",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kd0 Kh1 Jh4/2c0 4h0 Ah0 4c1 2s4/Js0 8d2 8c2 3d3 3c3",
            "win": 45,
            "playerId": "Seepoker"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 04:15:18",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338178736": [
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "micnike",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h1 Jd2 7d3 2c4",
            "rows": "Qh0 Qc1 Kc4/4c0 6d0 8h2 6h3 8s4/7s0 9s0 5s1 9c2 7h3",
            "win": 5,
            "playerId": "micnike"
        },
        {
            "inFantasy": true,
            "result": 3,
            "playerName": "Seepoker",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Td0 Tc0 As0/2d0 2s0 4h0 4s0 Qs0/5h0 6c0 7c0 8d0 9h0",
            "win": -5,
            "playerId": "Seepoker"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 04:16:05",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338178808": [
        {
            "inFantasy": true,
            "result": 18,
            "playerName": "micnike",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jc0",
            "rows": "Th0 Td0 Ah0/4h0 5c0 6s0 7h0 8h0/2h0 2d0 2c0 8d0 8s0",
            "win": 40,
            "playerId": "micnike"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "Seepoker",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qd3 Ad3 Jd4/Kh1 Kd1 Tc2 Ks2 9s4/3h0 3d0 3s0 7d0 7c0",
            "win": -40,
            "playerId": "Seepoker"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 04:16:58",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338178893": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "micnike",
            "orderIndex": 0,
            "hero": true,
            "dead": "6c1 Ah2 2h3 5c4",
            "rows": "Kd0 Qd4 Ac4/3h0 7h1 7d1 4h2 4c2/6s0 8s0 Js0 7s3 Qs3",
            "win": -5,
            "playerId": "micnike"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "Seepoker",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kh0 Jd2 7c4/2s0 6h0 3s2 Td3 Ts3/8c0 9s0 8d1 9h1 8h4",
            "win": 5,
            "playerId": "Seepoker"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 04:19:20",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338179095": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "micnike",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qs1 7d2 4d3 4s4",
            "rows": "As0 Kh3 5h4/5c0 6c0 2h1 5d2 8d4/Td0 Jd0 Js1 9d2 9h3",
            "win": -35,
            "playerId": "micnike"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "Seepoker",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kc1 Jc3 6s4/4c0 8c0 8s0 7s3 8h4/Th0 Jh0 Qh1 3h2 7h2",
            "win": 35,
            "playerId": "Seepoker"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 04:21:05",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338179244": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "micnike",
            "orderIndex": 0,
            "hero": true,
            "dead": "4s1 Qc2 2s3 Ts4",
            "rows": "Qs3 7d4 7c4/7s0 8h0 5c1 8d2 5s3/3d0 4d0 Kd0 2d1 Jd2",
            "win": 40,
            "playerId": "micnike"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "Seepoker",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ah0 Js2 7h3/8c0 Tc1 2c2 Ad4 Ac4/6d0 9d0 Td0 Qd1 5d3",
            "win": -40,
            "playerId": "Seepoker"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 04:23:38",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338179459": [
        {
            "inFantasy": false,
            "result": 63,
            "playerName": "micnike",
            "orderIndex": 2,
            "hero": true,
            "dead": "2c1 2h2 2d3 5s4",
            "rows": "Ks2 Ah2 Ad3/7s0 Jh0 3d1 Js3 3c4/8d0 Qc0 Qs0 8s1 9d4",
            "win": 125,
            "playerId": "micnike"
        },
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "Seepoker",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qd0 8c3 As4/5d0 5c0 4h1 6d2 4d4/9c0 Tc0 Td1 8h2 Th3",
            "win": -20,
            "playerId": "Seepoker"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "NikhilSegel",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qh0 7d3 Kd4/4s0 7h0 Kh1 Kc2 5h3/6c0 Jc0 Jd1 6h2 9h4",
            "win": -105,
            "playerId": "NikhilSegel"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 04:28:07",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338179894": [
        {
            "inFantasy": true,
            "result": 60,
            "playerName": "micnike",
            "orderIndex": 1,
            "hero": true,
            "dead": "3d0 6s0 Js0",
            "rows": "Qd0 Kh0 Kd0/4h0 5h0 6c0 7h0 8c0/9h0 9c0 Th0 Td0 Tc0",
            "win": 200,
            "playerId": "micnike"
        },
        {
            "inFantasy": false,
            "result": 13,
            "playerName": "Seepoker",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ah0 Ad1 4s3/4d0 5s0 6d0 As2 4c4/Jh0 7d1 Jd2 7c3 Qh4",
            "win": -185,
            "playerId": "Seepoker"
        },
        {
            "inFantasy": false,
            "result": 23,
            "playerName": "NikhilSegel",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ts1 Qc2 Ac4/8s0 6h1 Ks2 8d3 8h4/2h0 2s0 3c0 3s0 3h3",
            "win": -15,
            "playerId": "NikhilSegel"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 04:31:40",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338180243": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "micnike",
            "orderIndex": 0,
            "hero": true,
            "dead": "5h1 4c2 Ac3 Ks4",
            "rows": "Jd1 Jc2 7c4/2d0 3c0 3h1 9h2 4d4/8s0 Td0 Ts0 8d3 Th3",
            "win": -65,
            "playerId": "micnike"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "NikhilSegel",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qd0 Qh2 9c3/6s0 7s1 Kc1 7d2 6d4/5d0 5s0 8h0 Tc3 8c4",
            "win": 65,
            "playerId": "NikhilSegel"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 04:33:44",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338180456": [
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "micnike",
            "orderIndex": 1,
            "hero": true,
            "dead": "3c1 3d2 7h3 7d4",
            "rows": "Kd0 Qc1 8s3/As0 2d2 5d2 Tc3 8d4/4c0 6h0 6c0 4s1 Jh4",
            "win": -105,
            "playerId": "micnike"
        },
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "NikhilSegel",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Th0 Ts0 Kc0/3h0 4d0 5c0 6s0 7c0/2h0 2c0 9h0 9c0 9s0",
            "win": 105,
            "playerId": "NikhilSegel"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 04:34:36",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338180545": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "micnike",
            "orderIndex": 0,
            "hero": true,
            "dead": "2d1 Tc2 7c3 2s4",
            "rows": "Ac0 Qs2 Jh4/3d0 4s0 3h2 5d3 5c3/Jd0 Qh0 Th1 Ks1 9h4",
            "win": -5,
            "playerId": "micnike"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "NikhilSegel",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Jc2 9d3 Ts4/3c0 6h0 Kc1 Ah3 8h4/5s0 9s0 As0 8s1 Js2",
            "win": 5,
            "playerId": "NikhilSegel"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 04:36:20",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338180699": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "micnike",
            "orderIndex": 2,
            "hero": true,
            "dead": "Js1 Ah2 8s3 4c4",
            "rows": "Qh0 Ks1 As4/5d0 4d1 4s2 7d2 7c3/8h0 9h0 9c0 9s3 Ts4",
            "win": -10,
            "playerId": "micnike"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Honey17890",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "2s2 2h3 Kh4/3d0 4h0 7h1 6h2 6s3/Tc0 Jc0 Qc0 6c1 Td4",
            "win": -20,
            "playerId": "Honey17890"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "NikhilSegel",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qs0 5c2 8c3/Th0 Jh1 Kc1 3h2 3s3/6d0 Jd0 Ad0 Qd4 Kd4",
            "win": 30,
            "playerId": "NikhilSegel"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 04:38:39",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338180904": [
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "micnike",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jc1 9d2 As3 Tc4",
            "rows": "Ah0 Ad1 Qs3/3h0 5c0 4d2 5d3 8d4/7s0 8h0 8s1 Ts2 7d4",
            "win": -145,
            "playerId": "micnike"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "Honey17890",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "6h1 6d4 Qh4/8c0 Qc0 2c1 Kc2 4c3/3d0 Qd0 Kd0 Td2 2d3",
            "win": 170,
            "playerId": "Honey17890"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "NikhilSegel",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Th2 Kh3 9c4/Jh0 Ac0 Jd1 7c2 3c4/4s0 9s0 Ks0 5s1 Js3",
            "win": -25,
            "playerId": "NikhilSegel"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 04:41:25",
    "roomId": "41b-1d52d67b"
}


{
    "stakes": 5,
    "handData": {"338181145": [
        {
            "inFantasy": false,
            "result": 48,
            "playerName": "micnike",
            "orderIndex": 0,
            "hero": true,
            "dead": "5s1 Ad2 Td3 2d4",
            "rows": "Qh2 Ks2 Qc3/4s0 Ah1 As1 7h3 Kh4/3c0 3s0 8h0 8d0 5c4",
            "win": 20,
            "playerId": "micnike"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "Honey17890",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "9c1 2c4 2s4/3d0 4h0 5h2 6h3 7s3/8c0 Th0 Jd0 9d1 7d2",
            "win": 15,
            "playerId": "Honey17890"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "NikhilSegel",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qd2 9h3 6s4/Jh0 Kd0 6c2 7c3 Js4/4c0 Tc0 Kc0 Jc1 Ac1",
            "win": -35,
            "playerId": "NikhilSegel"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 04:44:11",
    "roomId": "41b-1d52d67b"
}





