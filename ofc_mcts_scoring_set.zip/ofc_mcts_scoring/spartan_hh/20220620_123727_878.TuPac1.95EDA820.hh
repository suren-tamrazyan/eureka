{
    "stakes": 10,
    "handData": {"338225031": [
        {
            "inFantasy": false,
            "result": 33,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qh1 3s2 8d3 5d4",
            "rows": "Ah0 Ad2 5h4/9c0 9s0 Td1 Ts1 2s3/Jh0 Jc0 Qc2 6s3 6d4",
            "win": 150,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "Mayur2217",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Jd2 Qs2 Th4/2h0 7h0 4d1 4s1 2d4/3h0 3c0 9d0 6c3 9h3",
            "win": -150,
            "playerId": "Mayur2217"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:37:27",
    "roomId": "41b-1d7eb2e9"
}


{
    "stakes": 10,
    "handData": {"338225341": [
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "5d0 7d0 9s0",
            "rows": "Kh0 Ad0 As0/8c0 8s0 Jh0 Qh0 Qs0/2c0 5c0 9c0 Jc0 Ac0",
            "win": 20,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "Mayur2217",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kc3 Ks3 9d4/4h1 4d1 4s2 7c2 6h4/8d0 9h0 Td0 Jd0 Qc0",
            "win": -20,
            "playerId": "Mayur2217"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:38:21",
    "roomId": "41b-1d7eb2e9"
}


{
    "stakes": 10,
    "handData": {"338225533": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "2d1 Js2 8h3 4h4",
            "rows": "Ac1 Kh2 Kc3/4s0 5c0 5s1 Qs2 5d3/9h0 9c0 9s0 Th4 Ad4",
            "win": -70,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": true,
            "result": -9,
            "playerName": "Mayur2217",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Tc0 Jh0 Jc0/4d0 5h0 6c0 7d0 8s0/3d0 3c0 Qh0 Qd0 Qc0",
            "win": 70,
            "playerId": "Mayur2217"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:39:00",
    "roomId": "41b-1d7eb2e9"
}


{
    "stakes": 10,
    "handData": {"338225645": [
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "3c0 5d0",
            "rows": "8s0 Kc0 Ah0/4h0 4s0 6h0 6c0 6s0/7d0 Qh0 Qd0 Qc0 Qs0",
            "win": 280,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "Mayur2217",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kd3 Ks3 Js4/4d1 4c1 3h2 9h2 2h4/5c0 9c0 9s0 Ad0 Ac0",
            "win": -280,
            "playerId": "Mayur2217"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:39:31",
    "roomId": "41b-1d7eb2e9"
}


{
    "stakes": 10,
    "handData": {"338225739": [
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "3s0",
            "rows": "Kc0 Ad0 As0/4h0 4d0 Js0 Qd0 Qc0/3h0 8h0 9h0 Th0 Ah0",
            "win": 120,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "Mayur2217",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Jc3 Ks3 9c4/Tc1 Ac1 6d2 7s2 5c4/2h0 5h0 7h0 Jh0 Qh0",
            "win": -120,
            "playerId": "Mayur2217"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:40:56",
    "roomId": "41b-1d7eb2e9"
}


{
    "stakes": 10,
    "handData": {"338226007": [
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "9d1 6d2 3h3 8d4",
            "rows": "Ad0 Js3 6s4/6c0 2d1 2c1 2s2 3d2/9s0 Tc0 Jh0 8s3 2h4",
            "win": -160,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "Mayur2217",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "5d2 Kc2 Ks3/4h0 4d0 5s0 5c1 Jd4/9c0 Ts0 Jc1 8h3 Qs4",
            "win": 160,
            "playerId": "Mayur2217"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:42:20",
    "roomId": "41b-1d7eb2e9"
}


{
    "stakes": 10,
    "handData": {"338226274": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "3h1 2s2 8d3 Tc4",
            "rows": "Qd0 8s2 Qs3/7c0 9c0 Kc1 Ad2 6s4/6h0 Jh0 Jd1 Js3 5c4",
            "win": -140,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "Mayur2217",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Jc0 Ks0 As0/2c0 3d0 4h0 5s0 6c0/5h0 7h0 Th0 Kh0 Ah0",
            "win": 140,
            "playerId": "Mayur2217"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:43:21",
    "roomId": "41b-1d7eb2e9"
}


{
    "stakes": 10,
    "handData": {"338226462": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "5d1 Qh2 Td3 Kc4",
            "rows": "Ah0 Ad1 Js4/7s0 6h1 3c2 6d2 Jh4/8h0 8d0 9h0 2h3 2s3",
            "win": 0,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "Mayur2217",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qs0 Kh0 Qc2/5h0 Ac0 4s1 4h2 4d3/Jd0 Tc1 3h3 4c4 Qd4",
            "win": 0,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "vivloc",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ts2 9s3 Jc3/7h0 9c0 7d1 9d1 Th2/2d0 3s0 5s0 3d4 As4",
            "win": 0,
            "playerId": "vivloc"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:45:49",
    "roomId": "41b-1d7eb2e9"
}


{
    "stakes": 10,
    "handData": {"338226935": [
        {
            "inFantasy": false,
            "result": 57,
            "playerName": "TuPac1",
            "orderIndex": 2,
            "hero": true,
            "dead": "4h1 Kh2 Js3 8h4",
            "rows": "9s0 Ah2 As4/5c0 Jc0 Tc1 Td2 Th4/6d0 6s0 6h1 4d3 4s3",
            "win": 310,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "Mayur2217",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "5s0 7d4 7s4/9d0 Jd1 Ts2 8s3 Qh3/Qc0 Kc0 Ac0 9c1 4c2",
            "win": 80,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "vivloc",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qs0 Ks1 Qd2/5h0 Ad2 3d3 5d4 7c4/2c0 2s0 Jh0 2d1 8c3",
            "win": -390,
            "playerId": "vivloc"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:47:50",
    "roomId": "41b-1d7eb2e9"
}


{
    "stakes": 10,
    "handData": {"338227312": [
        {
            "inFantasy": true,
            "result": 72,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "5s0 Tc0 Qs0",
            "rows": "3h0 3c0 3s0/2h0 4h0 7h0 9h0 Th0/3d0 5d0 6d0 9d0 Jd0",
            "win": 400,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "Mayur2217",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ah0 As1 8h4/6c0 9c1 4c2 Kc3 4s4/2d0 4d0 Td0 Ad2 Kd3",
            "win": -290,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "vivloc",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ac0 7c1 8d3/Qd0 Jc1 Kh2 Js3 Qc4/6h0 7s0 8s0 9s2 Ts4",
            "win": -110,
            "playerId": "vivloc"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:50:14",
    "roomId": "41b-1d7eb2e9"
}


{
    "stakes": 10,
    "handData": {"338227745": [
        {
            "inFantasy": true,
            "result": 3,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "5d0",
            "rows": "Td0 Tc0 Qs0/6d0 8h0 Jc0 Js0 Kc0/3c0 3s0 4h0 4d0 4c0",
            "win": -10,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "Mayur2217",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qd3 Qc3 8d4/9h1 9s1 5h2 5c2 7c4/4s0 5s0 7s0 8s0 Ts0",
            "win": 10,
            "playerId": "Mayur2217"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:50:52",
    "roomId": "41b-1d7eb2e9"
}


{
    "stakes": 10,
    "handData": {"338227858": [
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "2h1 Js2 3s3 8s4",
            "rows": "Ah0 Ac0 Kd3/5h0 5s0 9d1 Ts3 8c4/Qd0 Qs1 6d2 Qc2 6c4",
            "win": -200,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "Mayur2217",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Jc0 Kh0 Ks0/5d0 7s0 Th0 Ad0 As0/3h0 3d0 4h0 4d0 4s0",
            "win": 200,
            "playerId": "Mayur2217"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:51:46",
    "roomId": "41b-1d7eb2e9"
}


{
    "stakes": 10,
    "handData": {"338228024": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ah1 Kd2 7h3 Qc4",
            "rows": "Ac0 As0 5d4/2h0 2c0 6s2 8d2 8s3/9c0 9d1 Tc1 3d3 4h4",
            "win": -100,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "vivloc",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "6d1 Ks2 Ad4/7d0 Jc0 Td1 Ts2 Jd4/8h0 9h0 Kh0 5h3 Jh3",
            "win": 100,
            "playerId": "vivloc"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:54:20",
    "roomId": "41b-1d7eb2e9"
}


{
    "stakes": 10,
    "handData": {"338228528": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "Js1 Jd2 8d3 7d4",
            "rows": "Kd0 Tc2 7h3/9d0 6s1 Ah1 6d3 9h4/3h0 Qd0 Qs0 3c2 Ks4",
            "win": -80,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "vivloc",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "As1 4s3 Ad4/4c0 6h0 5h1 5d2 6c2/9c0 Jh0 Jc0 9s3 Qh4",
            "win": 80,
            "playerId": "vivloc"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:55:54",
    "roomId": "41b-1d7eb2e9"
}


{
    "stakes": 10,
    "handData": {"338228805": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "Js1 3h2 Jh3 7c4",
            "rows": "Jc2 Ks2 4c3/5h0 6s0 8c1 9s1 Ac4/8d0 Td0 Jd0 4d3 4s4",
            "win": -230,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": true,
            "result": 27,
            "playerName": "vivloc",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Th0 Qh0 Qd0/2h0 3c0 4h0 5c0 As0/7h0 7d0 9h0 9d0 9c0",
            "win": 230,
            "playerId": "vivloc"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:57:28",
    "roomId": "41b-1d7eb2e9"
}


{
    "stakes": 10,
    "handData": {"338229096": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "Js1 Qd2 5s3 Ah4",
            "rows": "Ks2 Ad3 Qs4/6d0 9h0 9s1 8d2 6s3/2c0 7c0 Tc0 5c1 5d4",
            "win": -100,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "vivloc",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Jc3 As3 Th4/2s0 4s0 2d1 9c2 8c4/4h0 Qh0 Kh0 2h1 3h2",
            "win": 100,
            "playerId": "vivloc"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 09:59:43",
    "roomId": "41b-1d7eb2e9"
}


{
    "stakes": 10,
    "handData": {"338229549": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "6c1 Qd2 3s3 Ad4",
            "rows": "Ah2 7s3 9c4/3d0 Kh1 Ks1 Kd2 Tc3/2h0 5h0 6h0 8h0 6d4",
            "win": 0,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "vivloc",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qs1 8d2 Qh2/5d0 9d0 4s1 7h3 9h4/Td0 Ts0 Js0 8c3 2c4",
            "win": 0,
            "playerId": "vivloc"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:03:00",
    "roomId": "41b-1d7eb2e9"
}


{
    "stakes": 10,
    "handData": {"338230233": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "7d1 6c2 4h3 2c4",
            "rows": "8d0 4c4 9c4/3s0 Jd1 Jc1 5d2 2d3/Th0 Jh0 Kh0 Qc2 Kd3",
            "win": -50,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "Dularidevi",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Qs1 9d4/6d0 7c0 Ad1 8s3 7h4/3h0 8h0 5h2 6h2 9h3",
            "win": 50,
            "playerId": "Dularidevi"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:05:15",
    "roomId": "41b-1d7eb2e9"
}


{
    "stakes": 10,
    "handData": {"338230668": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "6s1 8s2 5d3 3s4",
            "rows": "Kh0 Ad3 5c4/2h0 Tc0 6c1 Td2 Ah4/7d0 Jd0 8d1 Kd2 Qd3",
            "win": 90,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Dularidevi",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ks1 8h4 Ac4/4s0 6h1 2s2 4d2 6d3/8c0 9h0 Th0 Jc0 7h3",
            "win": 0,
            "playerId": "Dularidevi"
        },
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "vivloc",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "As0 7s3 Qh4/3d0 5h0 4h1 3h3 Js4/9s0 Jh0 Ts1 Qc2 Kc2",
            "win": -90,
            "playerId": "vivloc"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:08:26",
    "roomId": "41b-1d7eb2e9"
}


{
    "stakes": 10,
    "handData": {"338231263": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "Js1 9d2 Jh3 7s4",
            "rows": "Ac0 Kc2 Jc4/2d0 2c0 7h1 Td3 Th4/6s0 Qs0 6d1 6c2 9h3",
            "win": 70,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "Dularidevi",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qh1 Ks4 Ad4/2h0 Ah0 As0 6h1 9c2/3d0 8d0 8s2 Qd3 Qc3",
            "win": 50,
            "playerId": "Dularidevi"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "vivloc",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kd1 Ts3 3s4/3h0 4d0 7d1 5d2 5h3/3c0 4c0 8c0 5c2 8h4",
            "win": -120,
            "playerId": "vivloc"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:11:45",
    "roomId": "41b-1d7eb2e9"
}


{
    "stakes": 10,
    "handData": {"338231866": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "Ts1 2h2 8h3 Kd4",
            "rows": "Ks0 Kc1 Jc4/4d0 As0 Ad2 2d3 Th3/3h0 7h0 3d1 Qh2 6s4",
            "win": -100,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "vivloc",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Td1 Qd3 6d4/5s0 Jd0 3s1 Tc3 Js4/2c0 5c0 7c0 4c2 9c2",
            "win": 100,
            "playerId": "vivloc"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:13:54",
    "roomId": "41b-1d7eb2e9"
}


{
    "stakes": 10,
    "handData": {"338232223": [
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ks1 3c2 Th3 2h4",
            "rows": "Ac0 Kd3 As4/5h0 4h1 6s1 5d2 6c3/8d0 9h0 Jc0 8c2 9d4",
            "win": 60,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "vivloc",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Td1 Qc1 4d4/3h0 7h0 5s3 Ad3 7c4/3s0 9s0 Js0 4s2 8s2",
            "win": -60,
            "playerId": "vivloc"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:16:38",
    "roomId": "41b-1d7eb2e9"
}


{
    "stakes": 10,
    "handData": {"338232687": [
        {
            "inFantasy": true,
            "result": 33,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "3d0 5s0 6h0",
            "rows": "Kd0 Ad0 Ac0/8h0 9h0 Th0 Jc0 Qs0/3c0 4c0 9c0 Tc0 Kc0",
            "win": 230,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "vivloc",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "2h3 2c3 Ks4/8c1 8s1 5h2 5d2 7d4/4h0 4s0 6s0 Td0 Ts0",
            "win": -230,
            "playerId": "vivloc"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:18:15",
    "roomId": "41b-1d7eb2e9"
}


{
    "stakes": 10,
    "handData": {"338232990": [
        {
            "inFantasy": false,
            "result": 33,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ac1 9d2 4h3 2s4",
            "rows": "Ah0 As0 4c4/7d0 8d1 8h2 5h3 5c3/9h0 Ts0 Td1 Th2 9s4",
            "win": 210,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "vivloc",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kh0 8s1 Kc2/2d0 7h0 Ad1 7c3 Jh4/Js0 Qd0 Qs2 Kd3 Ks4",
            "win": -210,
            "playerId": "vivloc"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:20:20",
    "roomId": "41b-1d7eb2e9"
}


{
    "stakes": 10,
    "handData": {"338233390": [
        {
            "inFantasy": true,
            "result": 12,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "3c0 8s0 Qc0",
            "rows": "2h0 2d0 2c0/Jd0 Ks0 Ah0 Ac0 As0/5d0 6h0 7h0 8h0 9c0",
            "win": 20,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "vivloc",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qh3 Qd3 Kc4/4d1 4c1 4s2 6s2 5c4/3d0 7d0 9d0 Td0 Kd0",
            "win": -20,
            "playerId": "vivloc"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:21:29",
    "roomId": "41b-1d7eb2e9"
}


{
    "stakes": 10,
    "handData": {"338233617": [
        {
            "inFantasy": true,
            "result": -12,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "4h0",
            "rows": "6h0 Jh0 Ad0/3s0 5s0 8s0 9s0 Ks0/Td0 Tc0 Qh0 Qd0 Qs0",
            "win": 100,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": true,
            "result": -6,
            "playerName": "vivloc",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "8h0 8d0 Qc0/7d0 9c0 Th0 Kh0 Kd0/2d0 3c0 4d0 5h0 As0",
            "win": -100,
            "playerId": "vivloc"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:22:47",
    "roomId": "41b-1d7eb2e9"
}


{
    "stakes": 10,
    "handData": {"338233850": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "7h1 2d2 Qd3 Jh4",
            "rows": "Ad0 Kc2 Ah3/8d0 8c0 5h1 5s3 5c4/4d0 9d0 4h1 Qh2 5d4",
            "win": -100,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "vivloc",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Jd1 Ks2 Td4/6s0 8s0 4s1 8h2 3s4/2c0 7c0 Tc0 3c3 Jc3",
            "win": 100,
            "playerId": "vivloc"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:25:09",
    "roomId": "41b-1d7eb2e9"
}


{
    "stakes": 10,
    "handData": {"338234284": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "4h1 2h2 2s3 6d4",
            "rows": "Qc0 Qs3 Ad3/9s0 7d1 Kh2 Kd2 Qh4/Td0 Ts0 Jh0 Th1 4d4",
            "win": 40,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "vivloc",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "As0 7h4 Ks4/3s1 5c2 7c2 Jd3 Js3/3c0 4c0 Jc0 Kc0 Tc1",
            "win": -40,
            "playerId": "vivloc"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:26:59",
    "roomId": "41b-1d7eb2e9"
}


{
    "stakes": 10,
    "handData": {"338234600": [
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "5s0",
            "rows": "7s0 9c0 Ts0/4h0 5h0 6h0 Qh0 Kh0/2d0 4d0 Qd0 Kd0 Ad0",
            "win": 180,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "vivloc",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Jd3 Ah3 Td4/9h1 9s1 7h2 7d2 Th4/8d0 9d0 Qc0 Qs0 Ks0",
            "win": -180,
            "playerId": "vivloc"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:28:05",
    "roomId": "41b-1d7eb2e9"
}


{
    "stakes": 10,
    "handData": {"338234795": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "4d1 Ah2 Qh3 As4",
            "rows": "Kh1 Ks3 Ts4/8s0 Js0 7s1 Qs2 4s3/2c0 9c0 Ac0 3c2 9d4",
            "win": -140,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "TheRattleSnake",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "4c2 Qc4 Kc4/5s0 9s0 Jc1 5c2 9h3/4h0 5d0 7d0 6s1 8d3",
            "win": 110,
            "playerId": "TheRattleSnake"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "vivloc",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qd2 Ad3 Jh4/2s0 7c0 3h1 3s1 2d4/8c0 Td0 Tc0 8h2 6d3",
            "win": 30,
            "playerId": "vivloc"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:30:51",
    "roomId": "41b-1d7eb2e9"
}


{
    "stakes": 10,
    "handData": {"338235367": [
        {
            "inFantasy": false,
            "result": 66,
            "playerName": "TuPac1",
            "orderIndex": 2,
            "hero": true,
            "dead": "Td1 Jh2 Kh3 Tc4",
            "rows": "As0 Ks1 Ah3/3s0 4d0 4c3 3d4 6s4/5h0 8c0 7d1 4s2 6c2",
            "win": 340,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "TheRattleSnake",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qc2 Kd3 Jd4/2h0 2s0 9d1 7s2 5c4/9s0 Jc0 Qh0 8s1 Qd3",
            "win": -110,
            "playerId": "TheRattleSnake"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "vivloc",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc0 3h2 9c4/Js0 Ts1 Ad1 Ac2 5d3/7h0 7c0 Qs0 6h3 Th4",
            "win": -230,
            "playerId": "vivloc"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:33:52",
    "roomId": "41b-1d7eb2e9"
}


{
    "stakes": 10,
    "handData": {"338235965": [
        {
            "inFantasy": true,
            "result": 60,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "3c0 4h0 4d0",
            "rows": "7s0 Kh0 Ks0/6s0 7d0 8h0 9d0 Th0/Jh0 Jd0 Jc0 Js0 Qs0",
            "win": 540,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "TheRattleSnake",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "As0 Ah1 Kc3/5h0 5s1 Ts2 8d3 3s4/9c0 Qh0 Qd0 6d2 6c4",
            "win": -290,
            "playerId": "TheRattleSnake"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "vivloc",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kd0 Qc2 Td3/2d0 4c0 3d3 2s4 3h4/6h0 8s0 7h1 9h1 5c2",
            "win": -250,
            "playerId": "vivloc"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:36:05",
    "roomId": "41b-1d7eb2e9"
}


{
    "stakes": 10,
    "handData": {"338236353": [
        {
            "inFantasy": true,
            "result": 24,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "Kd0",
            "rows": "Tc0 Ts0 Ad0/4h0 5h0 6c0 7h0 8s0/3d0 3c0 Jh0 Jd0 Js0",
            "win": 120,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "TheRattleSnake",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Th1 Qc2 Qh3/4d0 7d0 2d1 9d3 Kh4/3s0 6s0 As0 Qs2 2s4",
            "win": -100,
            "playerId": "TheRattleSnake"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "vivloc",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Td2 Jc3/Ac0 2c1 7s2 8d3 Ks4/2h0 4s0 5d0 6h1 5c4",
            "win": -20,
            "playerId": "vivloc"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 10:46:05",
    "roomId": "41b-1d7eb2e9"
}


