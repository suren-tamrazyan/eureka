{
    "stakes": 5,
    "handData": {"338259708": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "CMPUNK2412",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kd3 5h4 Th4/2d0 Jh0 8h1 8d1 2h2/4s0 6s0 8s0 9s2 3s3",
            "win": 50,
            "playerId": "CMPUNK2412"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "2c1 6c2 Jd3 Kh4",
            "rows": "Ac1 Ah2 Ks3/3h0 4d0 6d2 7s3 9c4/9h0 Js0 Qd0 Kc1 7c4",
            "win": -50,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 13:01:27",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338259937": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "CMPUNK2412",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ad1 3d3 6c4/4d0 7h0 Jh1 7s2 As4/6s0 Ts0 Qs0 Tc2 6d3",
            "win": -50,
            "playerId": "CMPUNK2412"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "3h1 Jc2 7c3 4s4",
            "rows": "Qc0 2d4 2s4/5d0 8d1 Td1 8c2 5h3/8s0 9s0 Ks0 3s2 Js3",
            "win": 50,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 13:02:51",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338260181": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "CMPUNK2412",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ad0 Kc3 Qs4/4c0 7c0 5s1 8d2 5d3/9s0 Qh0 8c1 Th2 Td4",
            "win": -25,
            "playerId": "CMPUNK2412"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "7s1 9d2 2s3 Js4",
            "rows": "As0 Kd3 Tc4/6c0 4s1 5c1 5h3 6s4/4h0 8h0 9h0 Kh2 Ah2",
            "win": 25,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 13:04:16",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338260395": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "CMPUNK2412",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Tc1 Jc2 9d3/3d0 4h0 5h1 Kd2 Th4/7s0 8s0 Qs0 Qd3 7h4",
            "win": -40,
            "playerId": "CMPUNK2412"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "2s1 Jd2 5c3 4s4",
            "rows": "Ac0 Ts3 Qh4/Kh1 Jh2 Kc2 9s3 3h4/4c0 5d0 6h0 7d0 3s1",
            "win": 40,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 13:05:44",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338260641": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "CMPUNK2412",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "As0 Ac2 Ts4/2d0 6h0 4d1 6d1 2c3/8d0 9c0 9d2 Jh3 7c4",
            "win": 0,
            "playerId": "CMPUNK2412"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "4s1 9s2 5d3 Kh4",
            "rows": "Ad0 Tc3 Js4/Jd0 5s1 Qd2 Qc2 Jc3/5h0 6s0 7d0 4c1 Th4",
            "win": 0,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 13:07:15",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338260897": [
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "CMPUNK2412",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ah2 Qd3 As4/3s0 6s0 4s1 5s2 Ts4/2d0 2s0 Th0 2h1 Td3",
            "win": 45,
            "playerId": "CMPUNK2412"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "3c1 4d2 6d3 8c4",
            "rows": "Kh2 8d3 Jc3/Tc0 Js0 Qs1 Kc1 2c4/4h0 5h0 7h0 6h2 3h4",
            "win": -45,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 13:08:48",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338261130": [
        {
            "inFantasy": true,
            "result": 63,
            "playerName": "CMPUNK2412",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Jh0 Jc0 Js0/2h0 3d0 4h0 5s0 Ah0/7c0 7s0 9d0 9c0 9s0",
            "win": 155,
            "playerId": "CMPUNK2412"
        },
        {
            "inFantasy": false,
            "result": 51,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "5d1 8d2 8c3 6s4",
            "rows": "Kd0 Tc2 Qc4/3c0 Ad0 3s1 As2 Jd3/7h0 Qh0 5h1 3h3 8h4",
            "win": -155,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 13:09:28",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338261241": [
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "CMPUNK2412",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qc0 Ks0 Ad0/5c0 6h0 6d0 7s0 Ts0/3h0 3c0 4d0 4c0 4s0",
            "win": 50,
            "playerId": "CMPUNK2412"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "Kd1 Tc2 3s3 2d4",
            "rows": "As0 Jh2 Th4/5d1 Qh2 8s3 Ah3 Jd4/Td0 Jc0 Qs0 Kc0 9d1",
            "win": -50,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 13:10:50",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338261481": [
        {
            "inFantasy": false,
            "result": 39,
            "playerName": "CMPUNK2412",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Tc2 Kc3 4d4/5d0 2h1 6c1 6s3 Ks4/3s0 9s0 Js0 Qs0 7s2",
            "win": -105,
            "playerId": "CMPUNK2412"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "MukeshGiri33",
            "orderIndex": 2,
            "hero": true,
            "dead": "3c1 7h2 2c3 Jh4",
            "rows": "Qh0 Qd1 Ad4/4s0 2s1 Kd2 2d3 4h3/5h0 5s0 Ts0 Jc2 5c4",
            "win": -50,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": false,
            "result": 45,
            "playerName": "Nik9",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ac0 As1 Td3/8s1 4c2 8c2 8d3 9c4/3h0 6h0 8h0 9h0 Kh4",
            "win": 155,
            "playerId": "Nik9"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 13:12:49",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338261821": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "CMPUNK2412",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ks3 Ac3 Js4/4h1 4c1 9c2 Ts2 7c4/3d0 5d0 7d0 Kd0 Ad0",
            "win": -145,
            "playerId": "CMPUNK2412"
        },
        {
            "inFantasy": true,
            "result": 12,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "2d0",
            "rows": "5h0 6c0 Tc0/Td0 Jd0 Qs0 Kh0 Ah0/3s0 4s0 6s0 7s0 9s0",
            "win": -125,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": true,
            "result": 51,
            "playerName": "Nik9",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "9d0 Qd0 Qc0/3c0 5c0 8c0 Jc0 Kc0/8h0 9h0 Th0 Jh0 Qh0",
            "win": 270,
            "playerId": "Nik9"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 13:14:05",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338262043": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "8h1 8d2 Th3 7s4",
            "rows": "Ah0 Ks3 9d4/2s0 3d0 5s0 2c1 5h4/Tc0 Kc1 4c2 6c2 7c3",
            "win": -70,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": true,
            "result": 24,
            "playerName": "Nik9",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "4h0 Jd0 Js0/2d0 9h0 9s0 Td0 Ts0/5d0 5c0 Qh0 Qc0 Qs0",
            "win": 70,
            "playerId": "Nik9"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 13:14:53",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338262153": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "CMPUNK2412",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Js1 2s2 8s3/6h0 8c0 4c1 7h3 Jh4/2d0 9d0 Kd0 Td2 6s4",
            "win": -35,
            "playerId": "CMPUNK2412"
        },
        {
            "inFantasy": false,
            "result": 54,
            "playerName": "MukeshGiri33",
            "orderIndex": 2,
            "hero": true,
            "dead": "Jd1 7c2 2h3 2c4",
            "rows": "Qc0 Th4 Qs4/8d0 Ad0 Ah1 4d2 6c3/5s0 Ts0 9s1 As2 Ac3",
            "win": 130,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "Nik9",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kc2 Ks2 6d3/7s0 8h0 5d1 7d3 9c4/3h0 3s0 9h0 3d1 3c4",
            "win": -95,
            "playerId": "Nik9"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 13:17:18",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338262541": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "CMPUNK2412",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Kd2 Js3/2c0 Ts0 3c1 3h2 5s4/8h0 Qh0 8c1 Ah3 As4",
            "win": -180,
            "playerId": "CMPUNK2412"
        },
        {
            "inFantasy": true,
            "result": 3,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "8d0",
            "rows": "7h0 Tc0 Ac0/2h0 2d0 5h0 5d0 5c0/6d0 6c0 Qd0 Qc0 Qs0",
            "win": 185,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "Nik9",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ad0 Kh1 4s3/8s0 Th0 6h1 9h4 9c4/7d0 7s0 Jd2 Jc2 7c3",
            "win": -5,
            "playerId": "Nik9"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 13:19:34",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338262936": [
        {
            "inFantasy": false,
            "result": 54,
            "playerName": "CMPUNK2412",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ah0 Kh3 Kd3/7h0 5h1 9h1 2h2 4h2/9s0 Ts0 Js0 2s4 3s4",
            "win": 170,
            "playerId": "CMPUNK2412"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "6s1 4d2 2d3 Qh4",
            "rows": "Qd0 5s3 8h4/Jh0 Ks0 6d1 Ad2 Jc4/4c0 7c0 2c1 Ac2 6c3",
            "win": -80,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "Nik9",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qs1 As3 4s4/3d0 6h0 7s1 3h3 5c4/8c0 9c0 Tc0 3c2 Qc2",
            "win": -90,
            "playerId": "Nik9"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 13:21:31",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338263278": [
        {
            "inFantasy": true,
            "result": 126,
            "playerName": "CMPUNK2412",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qh0 Qd0 Qs0/5h0 6d0 7s0 8c0 9d0/2h0 2d0 2s0 4d0 4s0",
            "win": 215,
            "playerId": "CMPUNK2412"
        },
        {
            "inFantasy": false,
            "result": 57,
            "playerName": "MukeshGiri33",
            "orderIndex": 2,
            "hero": true,
            "dead": "7c1 8h2 Ts3 Js4",
            "rows": "Ks2 4c3 Jd4/3d0 3c1 6s1 6h2 6c4/9h0 9c0 9s0 Th0 Td3",
            "win": -55,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": false,
            "result": 57,
            "playerName": "Nik9",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kd0 Kc0 Ac2/3h0 5c0 As1 Ad2 4h3/8s0 7d1 Tc3 7h4 Jc4",
            "win": -160,
            "playerId": "Nik9"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 13:23:57",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338263665": [
        {
            "inFantasy": true,
            "result": 3,
            "playerName": "CMPUNK2412",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Js0 Kh0 Kd0/2d0 2s0 3h0 3d0 3c0/6h0 6c0 8d0 8c0 8s0",
            "win": 35,
            "playerId": "CMPUNK2412"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "7h1 Ad2 Jc3 2h4",
            "rows": "Kc0 Ks0 6d4/4c0 3s1 4s2 4d3 5c4/Th0 Tc0 9h1 Td2 Ts3",
            "win": -35,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 13:24:41",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338263772": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "CMPUNK2412",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kh3 As3 Th4/3d1 3c1 6s2 Kc2 5s4/7h0 7c0 7s0 Td0 Ts0",
            "win": 5,
            "playerId": "CMPUNK2412"
        },
        {
            "inFantasy": true,
            "result": 3,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h0 5h0",
            "rows": "3h0 3s0 9s0/7d0 8h0 8d0 Jd0 Ks0/2c0 4c0 5c0 9c0 Tc0",
            "win": -5,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 13:25:24",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338263877": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "CMPUNK2412",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ac1 Kc2 6c4/2d0 7h0 7c1 4d2 7d3/5s0 Ts0 Js0 2s3 8h4",
            "win": -50,
            "playerId": "CMPUNK2412"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "9s1 4s2 Qd3 Jc4",
            "rows": "Qs0 4c3 Jh4/3c0 7s0 8s1 Ks2 Kd4/2h0 Kh0 9h1 Qh2 Ah3",
            "win": 50,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 13:26:46",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338264093": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "CMPUNK2412",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ad0 Ac0 Jd4/4s0 4d2 4c2 7s3 Td3/8d0 9s0 7h1 Th1 Js4",
            "win": 60,
            "playerId": "CMPUNK2412"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "9d1 Jh2 9c3 8c4",
            "rows": "Kd0 Qc1 Qh3/2c0 7d0 3h2 3c2 2d4/6s0 Ts0 6h1 6d3 Kh4",
            "win": -60,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 13:28:04",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338264301": [
        {
            "inFantasy": true,
            "result": -12,
            "playerName": "CMPUNK2412",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Jd0 Jc0 Qh0/2s0 3s0 5s0 9s0 Ts0/4h0 4d0 4c0 7h0 7c0",
            "win": 10,
            "playerId": "CMPUNK2412"
        },
        {
            "inFantasy": true,
            "result": -6,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "3c0",
            "rows": "Js0 Ad0 Ac0/5h0 5d0 5c0 6d0 Th0/Qd0 Qc0 Qs0 Kd0 Ks0",
            "win": -10,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 13:28:55",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338264431": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "CMPUNK2412",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Tc2 Js3 Ks4/3d0 5s0 5c1 6s2 6h3/8h0 9d0 Jh0 Ts1 8s4",
            "win": -105,
            "playerId": "CMPUNK2412"
        },
        {
            "inFantasy": false,
            "result": 33,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jc1 2d2 2c3 4h4",
            "rows": "Ac1 Td3 Ad4/6c0 9s0 7d2 9h3 9c4/2h0 5h0 7h0 Ah1 Th2",
            "win": 105,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 13:30:32",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338264720": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "CMPUNK2412",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ks3 Ah3 4d4/7h1 7d1 Td2 Jh2 8s4/2c0 4c0 7c0 9c0 Jc0",
            "win": -115,
            "playerId": "CMPUNK2412"
        },
        {
            "inFantasy": true,
            "result": 27,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "2h0 4s0 8c0",
            "rows": "Qh0 Qs0 Kc0/2s0 7s0 9s0 Ts0 As0/5h0 5s0 6h0 6c0 6s0",
            "win": 115,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 13:31:23",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338264871": [
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "CMPUNK2412",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ac0 Ah1 Td4/5c0 7h0 5d1 3s2 7d3/8s0 Js0 8h2 Jc3 Ad4",
            "win": 20,
            "playerId": "CMPUNK2412"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "7c1 As2 2c3 Tc4",
            "rows": "Ks1 Jd3 3c4/8d0 4h2 Qd2 6s3 6h4/2h0 2d0 9c0 9s0 9d1",
            "win": -20,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 13:32:56",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338265140": [
        {
            "inFantasy": true,
            "result": 72,
            "playerName": "CMPUNK2412",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ad0 Ac0 As0/2c0 3c0 4h0 5d0 6c0/Th0 Ts0 Jd0 Jc0 Js0",
            "win": 190,
            "playerId": "CMPUNK2412"
        },
        {
            "inFantasy": false,
            "result": 60,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "7s1 2s2 4s3 Jh4",
            "rows": "Qs0 Qc1 9s3/5h0 6h0 8h1 3h2 Kh2/9d0 Td0 Kd3 5c4 5s4",
            "win": -190,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 13:33:45",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338265268": [
        {
            "inFantasy": true,
            "result": -9,
            "playerName": "CMPUNK2412",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "3s0 Qd0 Qs0/4c0 7c0 8c0 Tc0 Jc0/2h0 4h0 6h0 8h0 Qh0",
            "win": 25,
            "playerId": "CMPUNK2412"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "3h1 Jh2 As3 3d4",
            "rows": "Ah1 Ac2 Jd4/7s0 9s0 7h2 8d3 8s3/4d0 Kd0 Ad0 Td1 7d4",
            "win": -25,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 13:34:26",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338265375": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "CMPUNK2412",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kd3 Kc3 3d4/9h1 9c1 8s2 Qh2 7d4/Th0 Td0 Ah0 Ac0 As0",
            "win": -15,
            "playerId": "CMPUNK2412"
        },
        {
            "inFantasy": true,
            "result": 9,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "6c0 7c0 Kh0",
            "rows": "Qd0 Qc0 Qs0/4d0 5d0 6d0 7h0 8c0/3s0 5s0 7s0 9s0 Js0",
            "win": 15,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 13:34:56",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338265454": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "CMPUNK2412",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kh3 Ac3 5s4/9d1 9s1 5h2 5c2 3s4/6h0 6c0 6s0 9h0 Ts0",
            "win": -30,
            "playerId": "CMPUNK2412"
        },
        {
            "inFantasy": true,
            "result": -3,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "2d0",
            "rows": "4s0 7h0 Td0/3h0 3c0 Jd0 Jc0 Js0/Qd0 Qc0 Ah0 Ad0 As0",
            "win": 30,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 13:35:31",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338265564": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "CMPUNK2412",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ah0 Kd2 8d4/Td0 Jh1 Jc1 7d2 3c4/3s0 4s0 Qs0 6s3 Ts3",
            "win": 50,
            "playerId": "CMPUNK2412"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "4d1 5s2 2s3 6h4",
            "rows": "Ks0 Kh1 5c4/3h0 6d0 Ad2 Ac2 2h3/4c0 Qc0 Tc1 Qh3 3d4",
            "win": -50,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 13:36:46",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338265774": [
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "CMPUNK2412",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kd1 Kh2 Ad4/2d0 5c0 6c0 5s3 6h3/8d0 8s0 3s1 Qc2 As4",
            "win": -135,
            "playerId": "CMPUNK2412"
        },
        {
            "inFantasy": false,
            "result": 54,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "3c1 8c2 Tc3 7c4",
            "rows": "Td3 Qd4 Qs4/4c0 Jc0 Jd1 2c2 2s2/5h0 Th0 Qh0 7h1 3h3",
            "win": 150,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ks0 9d3 6s4/5d0 4s1 Ac2 4d3 Ts4/2h0 9h0 Jh0 4h1 8h2",
            "win": -15,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 13:38:59",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338266151": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "CMPUNK2412",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "7d2 Jc3/2d1 3s2 2c3/9s0 Ts0 8d1",
            "win": -5,
            "playerId": "CMPUNK2412"
        },
        {
            "inFantasy": true,
            "result": -9,
            "playerName": "MukeshGiri33",
            "orderIndex": 2,
            "hero": true,
            "dead": "Kh0",
            "rows": "4d0 Qc0 Ah0/4s0 5d0 9h0 Js0 Ks0/3d0 7h0 Th0 Kc0 Ad0",
            "win": -95,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ac0 6h3 6d3/7s0 9d0 7c1 9c2 Td2/2h0 4h0 5h1",
            "win": 100,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 13:44:34",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338267048": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "6h1 3c2 Qs3 2h4",
            "rows": "As0 Kc1 Jh3/7d0 4d1 5d2 7c3 4h4/8d0 8s0 Tc0 8h2 Ts4",
            "win": 60,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kd0 2c2 Qc3/6d0 Ac0 7h1 9h3 5c4/4s0 Js0 7s1 2s2 Ah4",
            "win": -60,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 13:46:16",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338267316": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "ameya1049",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "3s1 3d2 Ts4/4d0 8h0 5h1 7h2 4h3/6c0 Tc0 Qc0 6d3 Ac4",
            "win": -85,
            "playerId": "ameya1049"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "MukeshGiri33",
            "orderIndex": 2,
            "hero": true,
            "dead": "5d1 Jc2 2c3 As4",
            "rows": "Ah0 8d3 3c4/3h0 7d0 Qh2 Td3 Qs4/8s0 9c0 7c1 Js1 Th2",
            "win": -20,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": false,
            "result": 57,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Ks3 4s4/4c0 9d1 9s1 2d2 2h3/6h0 6s0 Jd0 Jh2 8c4",
            "win": 105,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 13:49:00",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338267741": [
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "ameya1049",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "4s1 Qs2 Qh4/6h0 Ks0 6d1 Kd3 Jc4/2c0 9c0 Ac0 Kc2 6c3",
            "win": -55,
            "playerId": "ameya1049"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "Kh1 9d2 6s3 2h4",
            "rows": "As0 Ah1 5s4/3d0 5h0 5d2 3c3 7h3/7c0 9h0 8h1 Jd2 Th4",
            "win": -40,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": true,
            "result": -3,
            "playerName": "Tgomegan",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "8d0 Qd0 Qc0/2s0 3h0 4c0 5c0 Ad0/Td0 Tc0 Ts0 Jh0 Js0",
            "win": 95,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 13:51:04",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338268073": [
        {
            "inFantasy": true,
            "result": 33,
            "playerName": "ameya1049",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "4h0 4s0 5s0/6s0 9d0 Tc0 Qd0 Qc0/5h0 6h0 8h0 Jh0 Kh0",
            "win": -110,
            "playerId": "ameya1049"
        },
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h0 6c0 7h0",
            "rows": "9h0 Kc0 Ks0/5d0 7d0 8d0 Td0 Jd0/3s0 8s0 9s0 Ts0 Js0",
            "win": 115,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ah3 As3 Kd4/3d1 3c1 3h2 9c2 6d4/2c0 4c0 5c0 8c0 Jc0",
            "win": -5,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 13:52:23",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338268280": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "6s1 3c2 Kd3 7c4",
            "rows": "Ac1 8d4 Qh4/2d0 4c0 4s0 2h2 6c2/8s0 Ts0 Tc1 7d3 7s3",
            "win": -105,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": true,
            "result": 33,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qd0 Ah0 As0/5c0 5s0 6d0 Kh0 Ks0/3h0 3d0 Jh0 Jd0 Jc0",
            "win": 105,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 13:53:19",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338268423": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jd1 Jh2 Th3 Tc4",
            "rows": "Qs0 Ad3 As3/2c0 Kd0 Kc0 2s2 7c4/6h0 5d1 7s1 4d2 2h4",
            "win": -115,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ac1 Qc3 Qd4/3d0 5h0 3s1 8s2 5s4/9h0 9c0 Td0 9d2 9s3",
            "win": 115,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 13:55:12",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338268694": [
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "7d1 9d2 3c3 Th4",
            "rows": "9h1 4d2 7h2/4c0 6c0 Ac1 3h3 6h3/2s0 Qs0 As0 4s4 7s4",
            "win": -90,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Js0 Kc0 Ks0/2c0 3d0 4h0 5c0 Ah0/8d0 Jd0 Qd0 Kd0 Ad0",
            "win": 90,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 13:56:11",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338268830": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "7c1 Ad2 Qc3/4s0 6c0 9h0 9c1 2s4/5d0 5s0 Th2 Td3 5c4",
            "win": -10,
            "playerId": "shubhamkumarjha75"
        },
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "9s1 7d2 Jd3 4h4",
            "rows": "Kc2 Jh3 6s4/Ac0 As0 2c2 Tc3 3c4/2d0 8d0 9d0 8h1 8s1",
            "win": -135,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "Tgomegan",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kd1 Jc3 Ts4/5h0 6h0 7h2 Ah2 Kh4/3d0 Qh0 Qd0 3h1 Qs3",
            "win": 145,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 13:58:32",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338269144": [
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ah3 7h4 7s4/6h0 8c0 6d1 8s1 5c2/3d0 Jd0 Qd0 Ad2 7d3",
            "win": -145,
            "playerId": "shubhamkumarjha75"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "5d1 Jh2 6s3 Ks4",
            "rows": "Kc0 4d4 Kh4/Ts0 9d1 9c1 4h2 4s3/3h0 3c0 Qh0 Qc2 3s3",
            "win": 35,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": false,
            "result": 36,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "As0 Ac1 Qs4/4c0 5h0 Jc2 5s3 Js3/9s0 Tc0 Td1 Th2 9h4",
            "win": 110,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:01:01",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338269513": [
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ad3 Ac3 7d4/6c1 6s1 4h2 4d2 3d4/8d0 8s0 Jd0 Kc0 Ks0",
            "win": -105,
            "playerId": "shubhamkumarjha75"
        },
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "MukeshGiri33",
            "orderIndex": 2,
            "hero": true,
            "dead": "2d0 4c0",
            "rows": "Tc0 Qs0 Kd0/6h0 8h0 9h0 Kh0 Ah0/3c0 3s0 Jh0 Jc0 Js0",
            "win": -15,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": true,
            "result": 60,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "5h0 5d0 5c0/6d0 7h0 8c0 9d0 Th0/2s0 7s0 9s0 Ts0 As0",
            "win": 120,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:02:26",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338269749": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "9d1 7d2 8d3 8h4",
            "rows": "Kc0 Th3 9s4/4d0 5s1 3d2 7c3 Ac4/9h0 Ts0 Jd0 8c1 Qd2",
            "win": -60,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Js0 Qs0 Kd0/3s0 4c0 5h0 6d0 7s0/2h0 4h0 7h0 Kh0 Ah0",
            "win": 60,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:03:24",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338269908": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Jc2 9h3 9d3/3s0 4h0 3c1 4s1 Kh4/Tc0 Ts0 Qs0 Qc2 7s4",
            "win": 5,
            "playerId": "shubhamkumarjha75"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "Kc1 Ks2 6d3 4d4",
            "rows": "Ad1 6s2 5d3/9c0 Jd0 Td1 Ac2 9s4/8h0 Qh0 Ah0 2h3 6h4",
            "win": -5,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:05:17",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338270248": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kh0 Kc2 6d4/3h0 4s0 3c1 9c3 6c4/7d0 Td0 Th1 Ts2 7h3",
            "win": -120,
            "playerId": "shubhamkumarjha75"
        },
        {
            "inFantasy": false,
            "result": 33,
            "playerName": "MukeshGiri33",
            "orderIndex": 2,
            "hero": true,
            "dead": "6h1 8d2 9s3 8h4",
            "rows": "Ks0 9d3 9h4/3s0 5c0 5d1 3d2 Ac4/Qd0 Qc0 Jd1 Jc2 Js3",
            "win": 125,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qs0 Kd0 Tc4/Ah0 As0 2h2 4c3 2s4/5h0 4h1 6s1 7c2 8c3",
            "win": -5,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:07:58",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338270690": [
        {
            "inFantasy": false,
            "result": 45,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "4c2 3c4 3s4/Tc0 Qd0 Qs1 2d2 Qc3/6h0 7h0 Ah0 5h1 Qh3",
            "win": -55,
            "playerId": "shubhamkumarjha75"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "Th1 8s2 9c3 4s4",
            "rows": "Kh1 Kd3 8d4/3h0 5d0 5s2 2c3 2s4/9s0 Jh0 Js0 Jd1 9h2",
            "win": 65,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "Tgomegan",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "As0 Ad1 9d4/5c0 6c1 4d2 6s2 4h4/Ts0 Kc0 Ks0 7c3 7s3",
            "win": -10,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:10:30",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338271075": [
        {
            "inFantasy": false,
            "result": 72,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "5d3 Qh3 3d4/8c1 Ah1 4h2 5h2 3h4/2s0 4s0 6s0 7s0 9s0",
            "win": -195,
            "playerId": "shubhamkumarjha75"
        },
        {
            "inFantasy": true,
            "result": 54,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "2c0 4c0",
            "rows": "Qd0 Ac0 As0/7h0 7d0 7c0 9d0 Ts0/6d0 6c0 Jh0 Jd0 Js0",
            "win": -50,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": true,
            "result": 90,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Th0 Td0 Tc0/8h0 8d0 8s0 9h0 9c0/3s0 Kh0 Kd0 Kc0 Ks0",
            "win": 245,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:12:18",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338271349": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "7d1 Kh2 3d3 Ks4",
            "rows": "9s1 Kd1 Qh4/2h0 5h0 3h2 7h2 9h3/2c0 6c0 Qc0 Ac3 3s4",
            "win": -70,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Td0 Kc0 Ad0/3c0 4d0 5c0 6d0 7s0/2s0 4s0 8s0 Js0 Qs0",
            "win": 70,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:13:20",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338271502": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "6h2 8s2 Qs3/9s0 Js0 4h1 Ks3 Kh4/3d0 4d0 Ad0 7d1 5d4",
            "win": -25,
            "playerId": "shubhamkumarjha75"
        },
        {
            "inFantasy": false,
            "result": 60,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "8d1 2c2 2d3 4s4",
            "rows": "As0 Kc2 Ac4/9h0 9d0 5c1 3s3 5h3/Th0 Jc0 Tc1 Td2 Qh4",
            "win": 60,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "Tgomegan",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kd0 Jd1 Qd2/2h0 8h0 Ah2 3h3 6s3/4c0 7c0 9c1 6c4 Qc4",
            "win": -35,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:16:01",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338271896": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "As0 Ac2 2c3/5c0 8d0 9d1 9c1 5d2/Th0 Jh0 7h3 2h4 Tc4",
            "win": -120,
            "playerId": "shubhamkumarjha75"
        },
        {
            "inFantasy": true,
            "result": 9,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "2d0 3d0 4h0",
            "rows": "Qd0 Kh0 Ah0/5s0 6s0 7s0 8s0 9h0/3c0 4c0 7c0 8c0 Qc0",
            "win": 95,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Qh3 7d4/5h0 Td0 Ts1 Jd1 Js4/3s0 Qs0 4s2 Ks2 9s3",
            "win": 25,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:19:00",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338272331": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "As0 3s3 3h4/4h0 5c0 8h1 8d2 8c2/9s0 Qd0 9h1 9d3 Kd4",
            "win": 40,
            "playerId": "shubhamkumarjha75"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "7d1 Qh2 9c3 8s4",
            "rows": "Ac0 Ah2 Qs3/Th0 Js0 Jh1 4s2 6s4/Kh0 Kc0 6c1 7c3 2s4",
            "win": -40,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:20:50",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338272599": [
        {
            "inFantasy": false,
            "result": -24,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "As2 9c3 Ah3/2s0 Qd0 2h1 2c2 6h4/4h0 4d0 4c0 Jc1 6s4",
            "win": -40,
            "playerId": "shubhamkumarjha75"
        },
        {
            "inFantasy": false,
            "result": -30,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "4s1 8d2 6c3 Ad4",
            "rows": "Qs3 3d4 3s4/7c0 8c0 7d1 8h2 7s3/Th0 Td0 Tc0 3c1 3h2",
            "win": 40,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:22:21",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338272814": [
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Ks0 Ad0/2c0 2s0 3d0 3c0 Js0/4h0 5h0 6h0 7h0 Jh0",
            "win": 90,
            "playerId": "shubhamkumarjha75"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "4d1 3h2 9c3 7d4",
            "rows": "9s2 Kd3 As3/8s0 Jc0 6d1 6s1 Th4/2d0 Qh0 Qs0 Qd2 Kh4",
            "win": -90,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:23:05",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338272912": [
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Ks2 6c4/5h0 As0 Ac1 7c3 8c3/Td0 Js0 Ts1 3h2 Tc4",
            "win": 70,
            "playerId": "shubhamkumarjha75"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jd1 Jc2 3c3 9h4",
            "rows": "Qh0 Qs2 Kh3/4c0 6d2 4d3 2c4 3s4/5d0 5c0 9d0 9c1 9s1",
            "win": -70,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:24:40",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338273135": [
        {
            "inFantasy": true,
            "result": -3,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "9s0 Ad0 As0/6h0 7h0 7d0 7s0 Ts0/Jd0 Jc0 Qh0 Qc0 Qs0",
            "win": 25,
            "playerId": "shubhamkumarjha75"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jh1 Js2 Th3 8h4",
            "rows": "Kh3 Ah3 Ac4/3d0 3s0 5h0 5c2 9d4/2c0 Tc0 4c1 8c1 9c2",
            "win": -25,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:25:24",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338273269": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kh3 Kc3 9c4/6d1 6c1 3h2 3d2 8d4/7d0 Th0 Ts0 Ah0 Ad0",
            "win": -65,
            "playerId": "shubhamkumarjha75"
        },
        {
            "inFantasy": true,
            "result": 9,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h0 4c0 5d0",
            "rows": "Qd0 Ac0 As0/4d0 5h0 6h0 7c0 8c0/9d0 Tc0 Jh0 Qs0 Ks0",
            "win": 65,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:26:14",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338273397": [
        {
            "inFantasy": true,
            "result": -27,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "4h0 Jd0 Ah0/8s0 9h0 Tc0 Jc0 Qh0/2d0 5d0 6d0 Td0 Kd0",
            "win": 5,
            "playerId": "shubhamkumarjha75"
        },
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "3h1 4c2 3c3 Js4",
            "rows": "Qs0 Ks1 Kc3/2c0 7d0 Ac1 As2 Kh3/8h0 8c0 9s2 7h4 7s4",
            "win": -5,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:27:52",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338273626": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "6h3 6s3 Ad4/9h1 9d1 5d2 5c2 3h4/4s0 Js0 Qh0 Qc0 Qs0",
            "win": -70,
            "playerId": "shubhamkumarjha75"
        },
        {
            "inFantasy": true,
            "result": -6,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h0 5h0",
            "rows": "Jh0 Kd0 As0/3c0 6c0 9c0 Tc0 Jc0/7h0 7d0 7s0 Th0 Ts0",
            "win": 70,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:28:36",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338273731": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "7s2 8d3 8s4/4d0 Jc0 Th1 Jd1 9h4/6d0 6s0 Qs0 6h2 6c3",
            "win": 50,
            "playerId": "shubhamkumarjha75"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "Js1 Jh2 8h3 7h4",
            "rows": "Kh0 Td3 Ad4/5s0 9d1 As2 5c3 Ah4/2c0 4c0 Kc0 9c1 3c2",
            "win": -50,
            "playerId": "MukeshGiri33"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:30:21",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338273979": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ah2 Qc3 Kd4/2c0 9d0 2d1 5c1 Jc4/3s0 6s0 8s0 9s2 7s3",
            "win": 20,
            "playerId": "shubhamkumarjha75"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "8d1 2h2 6d3 Js4",
            "rows": "Ks3 Th4 Qh4/4s0 7h0 4d1 4c1 5d2/Tc0 Jh0 Qd0 Kh2 Ac3",
            "win": 10,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "As0 9h2 Kc4/2s0 3d0 4h1 6c3 3h4/7d0 9c0 8h1 Jd2 Ts3",
            "win": -30,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:33:22",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338274382": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "As0 Ah1 Js2/3s0 5h0 Qc2 6s3 Qs3/2d0 8d0 7d1 Ts4 Qh4",
            "win": -50,
            "playerId": "shubhamkumarjha75"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "MukeshGiri33",
            "orderIndex": 2,
            "hero": true,
            "dead": "Ad1 6c2 2h3 Qd4",
            "rows": "Kh1 Kd1 6h3/Jh0 8s2 8c3 4d4 Tc4/2s0 4s0 7s0 Ks0 9s2",
            "win": -50,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Td3 3h4/4h0 7c1 9c1 9h2 8h4/5d0 9d0 Jd0 6d2 3d3",
            "win": 100,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:35:56",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338274721": [
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ac2 Ks3 Th4/6c0 9h0 9d1 6h2 8d3/8s0 Qs0 As0 6s1 Ts4",
            "win": -45,
            "playerId": "shubhamkumarjha75"
        },
        {
            "inFantasy": false,
            "result": 66,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qc1 7c2 7h3 2d4",
            "rows": "Kd0 Ad1 Ah2/4d0 4c0 3c2 4s3 9c3/5h0 5d0 5c1 Jh4 Jc4",
            "win": 210,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "Tgomegan",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "2s3 Kc3 3s4/6d0 Qd0 Td1 3d2 7d2/4h0 8h0 Kh0 Qh1 Tc4",
            "win": -165,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:38:48",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338275089": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Ad0 3c2 9d3/8c0 2s1 6c2 2h3 Ks4/5h0 5d0 Jc0 Js1 3h4",
            "win": -145,
            "playerId": "shubhamkumarjha75"
        },
        {
            "inFantasy": true,
            "result": 64,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "7h0 8d0 9c0",
            "rows": "Jh0 Ah0 As0/2d0 6d0 7d0 Td0 Jd0/Qh0 Qc0 Qs0 Kh0 Kc0",
            "win": 230,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": false,
            "result": 23,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ac1 Kd2 4d4/3d0 4c0 5s2 6s3 7c3/8s0 Tc0 Ts0 8h1 Th4",
            "win": -85,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:41:12",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338275414": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ks0 Ac3 9c4/3c0 4h0 6c0 4c1 6s2/Qd0 8d1 Jd2 Qs3 2h4",
            "win": -30,
            "playerId": "shubhamkumarjha75"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "MukeshGiri33",
            "orderIndex": 2,
            "hero": true,
            "dead": "8c1 3h2 4s3 Kh4",
            "rows": "Qc0 Kd0 7d4/2d0 2c1 2s1 3d3 Th3/9s0 Jc0 9h2 Jh2 4d4",
            "win": -30,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "9d1 Qh2 5d4/3s0 6d0 Ah2 7s3 Js3/7c0 Tc0 Kc0 5c1 5h4",
            "win": 60,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:44:15",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338275824": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Th2 5h4 Ts4/5c0 7c0 3d1 3c1 7d3/4s0 Qs0 Ks0 2s2 As3",
            "win": 20,
            "playerId": "shubhamkumarjha75"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "4c1 5d2 Tc3 Js4",
            "rows": "9c2 Qd2 9d3/2d0 2c0 3h0 7s1 2h3/6s0 8s0 8h1 8d4 Jd4",
            "win": -45,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "Tgomegan",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kd0 5s3 Kc4/3s0 4h0 Ah1 Ac1 6c3/9s0 Qc0 8c2 Td2 Jh4",
            "win": 25,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:46:51",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338276166": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "9c3 9s3 5c4/Th0 4d1 Ts1 Jh2 Jd2/4c0 5d0 6h0 7c0 3d4",
            "win": -85,
            "playerId": "shubhamkumarjha75"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "Js1 4h2 Ah3 3s4",
            "rows": "Kh0 Kc1 6s4/2h0 Ac0 5s2 As2 3c4/8d0 Td0 6d1 Qd3 Ad3",
            "win": 40,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "7s0 Kd0 Ks0/4s0 8c0 8s0 Qh0 Qc0/7h0 8h0 9h0 Tc0 Jc0",
            "win": 45,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:49:02",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338276421": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "6c2 Jd3 5h4/2c0 7d0 8d1 Ad3 2s4/3h0 9h0 Kh0 7h1 Qh2",
            "win": -25,
            "playerId": "shubhamkumarjha75"
        },
        {
            "inFantasy": true,
            "result": 45,
            "playerName": "MukeshGiri33",
            "orderIndex": 2,
            "hero": true,
            "dead": "2d0 4d0",
            "rows": "Jh0 Js0 Ah0/3c0 4c0 7c0 8c0 9c0/5s0 8s0 9s0 Ts0 Ks0",
            "win": 195,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ac0 8h2 9d3/5c0 Qd1 Tc2 Jc3 4h4/3s0 7s0 Qs0 As1 Td4",
            "win": -170,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:51:31",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338276725": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "4h1 4s2 Jd3 Qs4",
            "rows": "Ah1 8h2 Ac3/2c0 7d0 6d2 2d3 Jc4/5h0 5s0 9h0 Qc1 8s4",
            "win": 0,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "As1 Kh3 Ts4/4c0 5d0 3h2 6c2 Js4/9c0 Td0 Jh0 8d1 7c3",
            "win": 0,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:53:21",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338276944": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "4s1 Ah2 Tc3 Kh4",
            "rows": "Kd0 Ks2 6c3/3d0 7h0 2d1 Kc3 6d4/9s0 Jc0 8s1 9c2 4c4",
            "win": -85,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": false,
            "result": 33,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ad0 As2 9h3/5d0 5c0 4h1 6h3 5h4/8c0 Js0 8d1 8h2 Ac4",
            "win": 85,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:54:59",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338277152": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "2d1 Jc2 6h3 6d4",
            "rows": "Qs0 As1 4d4/3d0 5d1 3c2 7h2 7c3/8s0 Th0 Ts0 9d3 4h4",
            "win": -100,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": true,
            "result": 12,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "7d0 7s0 Kd0/2h0 5h0 8h0 9h0 Jh0/2c0 5c0 6c0 8c0 Ac0",
            "win": 100,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:55:48",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338277237": [
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "Pro1995",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "As0 Ts1 8s4/5s0 8d1 6c2 8h2 5c3/9c0 Jd0 Jc0 4d3 4s4",
            "win": -25,
            "playerId": "Pro1995"
        },
        {
            "inFantasy": false,
            "result": 57,
            "playerName": "MukeshGiri33",
            "orderIndex": 2,
            "hero": true,
            "dead": "2s1 7h2 2c3 Kh4",
            "rows": "Kd0 Kc3 4h4/3d0 3c0 2h1 6h2 6s2/Th0 Js0 Qs1 8c3 9h4",
            "win": 135,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ah0 Ad1 3s3/7c0 6d1 9d3 7d4 Qh4/Td0 Tc0 Jh0 5h2 5d2",
            "win": -110,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 14:58:07",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338277457": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Pro1995",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ad0 Qs2 Ks3/8c0 9s1 Jd1 7d2 9h4/6h0 Jh0 Qh0 3h3 7h4",
            "win": 0,
            "playerId": "Pro1995"
        },
        {
            "inFantasy": true,
            "result": -6,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "6c0 Jc0",
            "rows": "Ts0 Qc0 Kd0/4c0 5d0 6d0 7s0 8s0/4h0 5h0 Th0 Kh0 Ah0",
            "win": 70,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "Tgomegan",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "As1 Td3 7c4/3d0 5c0 3c1 8d2 5s4/2h0 2c0 9d0 Tc2 2d3",
            "win": -70,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 15:00:35",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338277740": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "5c1 8s2 As3 Ks4",
            "rows": "Kd0 Ad1 Ac3/3h0 9h0 3c1 Js2 Jc3/Qd0 Qs0 6d2 4s4 Tc4",
            "win": -30,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "8h1 2s3 2d4/3s0 4d0 6s0 7c2 4c3/9c0 Kc0 Kh1 9d2 8c4",
            "win": 30,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 15:02:22",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338277967": [
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "7c1 7s2 2h3 9c4",
            "rows": "Kh0 5s3 Kd3/Ah0 As1 4d2 6h2 9d4/3h0 3s0 Jd0 3d1 Ac4",
            "win": 70,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qd0 Qc3 8s4/Td0 2d1 2s1 4c2 4s2/7h0 8h0 Jh0 4h3 8c4",
            "win": -70,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 15:04:06",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338278210": [
        {
            "inFantasy": true,
            "result": 27,
            "playerName": "MukeshGiri33",
            "orderIndex": 1,
            "hero": true,
            "dead": "2h0 7h0",
            "rows": "Th0 Kd0 Kc0/3d0 3s0 6d0 6c0 8d0/Tc0 Jc0 Qs0 Ks0 As0",
            "win": 55,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "Tgomegan",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qd3 Ad3 Js4/Td1 Ts1 5d2 5c2 6h4/4h0 4d0 4s0 7s0 Jh0",
            "win": -55,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 15:05:04",
    "roomId": "41b-1da27839"
}


{
    "stakes": 5,
    "handData": {"338278343": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "MukeshGiri33",
            "orderIndex": 0,
            "hero": true,
            "dead": "9h1 4c2 4s3 8c4",
            "rows": "Qh0 3c3 Qc3/5c0 2h1 Ah1 2c2 7s4/6s0 8s0 Ts0 7h2 2d4",
            "win": -60,
            "playerId": "MukeshGiri33"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Tgomegan",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "As1 4h4 Tc4/4d0 5d1 Qd2 Qs2 5s3/3h0 3s0 Jd0 Js0 Jh3",
            "win": 60,
            "playerId": "Tgomegan"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 15:06:46",
    "roomId": "41b-1da27839"
}


