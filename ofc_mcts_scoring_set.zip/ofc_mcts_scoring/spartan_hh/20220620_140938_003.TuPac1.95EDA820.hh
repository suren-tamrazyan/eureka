{
    "stakes": 10,
    "handData": {"338241656": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "Mayur2217",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qd0 Qc1 Js4/4s0 Ts2 Td3 As3 8h4/6h0 Jh0 Kh0 3h1 9h2",
            "win": -80,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "9c1 7c2 2d3 5d4",
            "rows": "Ks0 7d2 8d4/Ad0 3d1 Jc3 Qh3 4d4/4c0 6d0 7h0 8s1 5s2",
            "win": 80,
            "playerId": "TuPac1"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:09:38",
    "roomId": "41b-1d992869"
}


{
    "stakes": 10,
    "handData": {"338241909": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Mayur2217",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Jc1 Td3 Ks3/3c0 Ad0 2d1 9h2 Qc4/5d0 6d0 6c0 6s2 8d4",
            "win": 60,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "4s1 7s2 Js3 Kc4",
            "rows": "Kd0 Ac1 7d4/7c0 7h1 9d2 9s2 Jd3/5h0 8h0 Th0 Qh3 2s4",
            "win": -60,
            "playerId": "TuPac1"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:11:17",
    "roomId": "41b-1d992869"
}


{
    "stakes": 10,
    "handData": {"338242121": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Mayur2217",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Jh3 Kh3 As4/4h0 5c0 2h1 2d1 4s4/6s0 Js0 Qs0 Ts2 Ks2",
            "win": 100,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "8h1 6c2 Qh3 Tc4",
            "rows": "Kc1 Ah2 7c4/9c0 9s1 7s2 3h3 3s3/3d0 5d0 Jd0 Ad0 5s4",
            "win": -100,
            "playerId": "TuPac1"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:12:55",
    "roomId": "41b-1d992869"
}


{
    "stakes": 10,
    "handData": {"338242335": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "Mayur2217",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "As1 6s3 Ad4/6d0 7d0 5h1 5c2 7h3/3s0 Jc0 Js0 3h2 Kc4",
            "win": -20,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "2h1 Td2 4h3 2d4",
            "rows": "Ks0 Kd2 Jd4/3d0 Ah0 3c1 2s3 Ac3/9d0 Th0 Jh1 Qh2 8c4",
            "win": 20,
            "playerId": "TuPac1"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:14:39",
    "roomId": "41b-1d992869"
}


{
    "stakes": 10,
    "handData": {"338242562": [
        {
            "inFantasy": true,
            "result": -24,
            "playerName": "Mayur2217",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "7h0 7d0 7s0/8s0 9h0 Ts0 Jc0 Qs0/2s0 3s0 4s0 5s0 Ks0",
            "win": -20,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": true,
            "result": -30,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h0 7c0",
            "rows": "Td0 Jh0 Js0/4h0 4d0 Kh0 Kd0 Kc0/5h0 5c0 Ah0 Ac0 As0",
            "win": 20,
            "playerId": "TuPac1"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:15:30",
    "roomId": "41b-1d992869"
}


{
    "stakes": 10,
    "handData": {"338242676": [
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "Mayur2217",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Tc0 Ts0 Ac0/5h0 7c0 Jh0 Kh0 Ks0/4d0 6d0 Qd0 Kd0 Ad0",
            "win": 150,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "6s1 3d2 7d3 Jd4",
            "rows": "Ah0 9h1 4s2/7h0 Js0 Th1 As2 3s3/8c0 Kc0 2c3 3c4 9s4",
            "win": -150,
            "playerId": "TuPac1"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:16:27",
    "roomId": "41b-1d992869"
}


{
    "stakes": 10,
    "handData": {"338242801": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "Mayur2217",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "5d3 9s3 4h4/8h0 Th0 7d2 9h2 Jd4/5s0 Js0 Ks0 2s1 4s1",
            "win": 30,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "2d1 9d2 7h3 7s4",
            "rows": "Kd0 Qs2 8c4/Ad0 As0 6s3 Jh3 6c4/7c0 Tc0 4c1 9c1 Ac2",
            "win": -30,
            "playerId": "TuPac1"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:17:51",
    "roomId": "41b-1d992869"
}


{
    "stakes": 10,
    "handData": {"338242987": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "Mayur2217",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kd0 Th2 6s4/3s0 5c0 2c1 3c3 Kc4/4d0 4s0 4c1 6h2 6d3",
            "win": 50,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jc1 8d2 3d3 8c4",
            "rows": "Ks2 9c3 Ad3/2d0 5d0 Tc0 Ts1 Ac4/Jh0 Qh0 9h1 4h2 Qs4",
            "win": -50,
            "playerId": "TuPac1"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:19:22",
    "roomId": "41b-1d992869"
}


{
    "stakes": 10,
    "handData": {"338243173": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "Mayur2217",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Jd1 Ac1 Qh3/2c0 9c0 8c2 2h3 Ad4/5s0 6s0 Ks0 3s2 5c4",
            "win": -60,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "7d1 Jc2 Ts3 4h4",
            "rows": "Ah0 Kh3 6h4/2d0 5h0 5d0 2s2 Th3/8h0 9d1 9s1 8d2 3c4",
            "win": 60,
            "playerId": "TuPac1"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:20:50",
    "roomId": "41b-1d992869"
}


{
    "stakes": 10,
    "handData": {"338243368": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "Mayur2217",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qd0 Ac2 As3/3s0 Kd0 3d1 8h2 3c3/2c0 Tc0 Td1 Jd4 Qh4",
            "win": 0,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "3h1 Js2 4s3 Kh4",
            "rows": "Ah0 Ts3 4h4/4d0 4c0 6d0 6h2 Jc2/8s0 7h1 7s1 5h3 2s4",
            "win": 0,
            "playerId": "TuPac1"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:22:22",
    "roomId": "41b-1d992869"
}


{
    "stakes": 10,
    "handData": {"338243596": [
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "Mayur2217",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qc2 9d3 Qd4/5s0 7c0 Ad1 Ac1 9c4/3h0 9h0 Ah0 Jh2 8h3",
            "win": 170,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "6d1 6s2 3s3 Kd4",
            "rows": "Ks1 6c3 6h4/4d0 5d0 5c0 2d1 2c2/7h0 Th0 Jc2 Ts3 3d4",
            "win": -170,
            "playerId": "TuPac1"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:24:11",
    "roomId": "41b-1d992869"
}


{
    "stakes": 10,
    "handData": {"338243831": [
        {
            "inFantasy": true,
            "result": 18,
            "playerName": "Mayur2217",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "7h0 7s0 Ks0/3c0 5s0 Jh0 Jd0 Qd0/6h0 6d0 9d0 9c0 9s0",
            "win": -20,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qc1 8c2 8d3 3s4",
            "rows": "As1 Ad3 Kh4/3h0 4d0 4s1 3d2 Tc2/2c0 2s0 Js0 2d3 Qh4",
            "win": 20,
            "playerId": "TuPac1"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:24:57",
    "roomId": "41b-1d992869"
}


{
    "stakes": 10,
    "handData": {"338243945": [
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "Mayur2217",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qh3 Qd3 9s4/Kh1 Ks1 3c2 7c2 2c4/6s0 8h0 8d0 8c0 Jh0",
            "win": -170,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": true,
            "result": -24,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "3h0 4h0 5h0",
            "rows": "6c0 7h0 Qc0/2d0 3d0 4d0 7d0 Kd0/2s0 3s0 4s0 5s0 As0",
            "win": 170,
            "playerId": "TuPac1"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:25:24",
    "roomId": "41b-1d992869"
}


{
    "stakes": 10,
    "handData": {"338243993": [
        {
            "inFantasy": true,
            "result": -3,
            "playerName": "Mayur2217",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Jh0 Jd0 Qc0/6c0 7s0 9h0 Ad0 As0/2d0 2s0 5s0 Th0 Tc0",
            "win": -170,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": true,
            "result": 9,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "7d0",
            "rows": "9d0 Qh0 Qs0/2c0 3s0 4s0 5d0 Ac0/6h0 6d0 6s0 8h0 8s0",
            "win": 170,
            "playerId": "TuPac1"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:25:52",
    "roomId": "41b-1d992869"
}


{
    "stakes": 10,
    "handData": {"338244056": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "Mayur2217",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qd3 Ah3 Qh4/4h0 4d0 9d1 5h2 5s4/3s0 6s0 As0 4s1 Qs2",
            "win": 60,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "5d1 5c2 8d3 Js4",
            "rows": "Kh1 7d3 Jc4/3d0 6c0 6d1 9h2 Kc4/8c0 8s0 Th0 Ts2 Td3",
            "win": -60,
            "playerId": "TuPac1"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:27:21",
    "roomId": "41b-1d992869"
}


{
    "stakes": 10,
    "handData": {"338244243": [
        {
            "inFantasy": true,
            "result": -6,
            "playerName": "Mayur2217",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qs0 Kh0 Ks0/8d0 9d0 Th0 Jh0 Qd0/3c0 4c0 5c0 8c0 Tc0",
            "win": 80,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "8s1 2d2 2h3 Td4",
            "rows": "As1 Qc2 Ah3/6d0 6s0 9s1 9c2 Kc4/5h0 5d0 5s0 3d3 Ac4",
            "win": -80,
            "playerId": "TuPac1"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:28:01",
    "roomId": "41b-1d992869"
}


{
    "stakes": 10,
    "handData": {"338244344": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "Mayur2217",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kh3 Kd3 Qh4/8c1 8s1 3d2 Ac2 2s4/6h0 7c0 8h0 9c0 Th0",
            "win": -180,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "3c0 4d0 5d0",
            "rows": "2d0 2c0 6d0/3h0 4h0 5h0 7h0 9h0/5s0 9s0 Ts0 Ks0 As0",
            "win": 180,
            "playerId": "TuPac1"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:28:45",
    "roomId": "41b-1d992869"
}


{
    "stakes": 10,
    "handData": {"338244449": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "Mayur2217",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kh1 Kc3 Qc4/3h0 4c0 8s0 4h1 Qs4/5d0 Td0 8d2 Jd2 4d3",
            "win": 0,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "3c1 3s2 3d3 Ac4",
            "rows": "Kd0 Ks0 8c2/6d0 7c1 As1 8h3 Ad4/2h0 Qh0 Js2 2d3 9h4",
            "win": 0,
            "playerId": "TuPac1"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:30:13",
    "roomId": "41b-1d992869"
}


{
    "stakes": 10,
    "handData": {"338244688": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "Mayur2217",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qs2 Qc3 Kc4/4d0 Ac0 2d1 As1 8d4/7h0 7c0 8c0 9c2 7d3",
            "win": 40,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ad1 3s2 6d3 3d4",
            "rows": "Qd2 Ah3 4c4/2s0 Jc0 Js2 5s3 7s4/8h0 9h0 Kh0 6h1 Qh1",
            "win": -40,
            "playerId": "TuPac1"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:31:54",
    "roomId": "41b-1d992869"
}


{
    "stakes": 10,
    "handData": {"338245043": [
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "Mayur2217",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "2h0 2c0 Ac0/5c0 6d0 7s0 8d0 9s0/Td0 Js0 Qs0 Kd0 Ah0",
            "win": 120,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "7d1 Kc2 6h3 9h4",
            "rows": "Qd0 Ad2 Jh4/2d0 3s0 2s1 3h3 7c3/5h0 Th0 4h1 5d2 4d4",
            "win": -120,
            "playerId": "TuPac1"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:32:41",
    "roomId": "41b-1d992869"
}


{
    "stakes": 10,
    "handData": {"338245185": [
        {
            "inFantasy": false,
            "result": 60,
            "playerName": "Mayur2217",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kd0 Qh2 Kh3/2c0 Ad0 4h1 2d2 4s3/5s0 Ts0 Td1 3h4 3d4",
            "win": 280,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jd1 As2 5c3 Js4",
            "rows": "Kc0 Ks1 5h3/3s0 4d0 Jh2 9h4 Tc4/6d0 7c0 Qc1 Qs2 7s3",
            "win": -140,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "Honey17890",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ah0 Ac2 3c4/2h1 4c1 2s2 6h3 6s3/7d0 8h0 9s0 Th0 9c4",
            "win": -140,
            "playerId": "Honey17890"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:35:06",
    "roomId": "41b-1d992869"
}


{
    "stakes": 10,
    "handData": {"338245635": [
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "Mayur2217",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "6s0 8d0 8c0/Td0 Jh0 Qc0 Kh0 Ac0/2h0 2s0 5h0 5d0 5c0",
            "win": 380,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "TuPac1",
            "orderIndex": 2,
            "hero": true,
            "dead": "Ks1 9d2 5s3 Jd4",
            "rows": "Qh0 As2 7h4/3d0 7d0 3s1 8h2 3h3/6c0 Jc0 7c1 2c3 2d4",
            "win": -190,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "Honey17890",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qd0 Kc1 Qs3/8s0 Ts1 Tc2 6d3 Ad4/9h0 9s0 Js0 9c2 4c4",
            "win": -190,
            "playerId": "Honey17890"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:37:08",
    "roomId": "41b-1d992869"
}


{
    "stakes": 10,
    "handData": {"338246007": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "Mayur2217",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kh1 Ah1 2c3/7s0 9h0 8s2 Ad3 6s4/Jh0 Jd0 Jc0 Qs2 5d4",
            "win": -220,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "3d1 Td2 Kd3 7d4",
            "rows": "Ac2 Ts4 Kc4/3h0 3c0 6h0 7h1 6d3/4d0 4s0 8h1 8d2 8c3",
            "win": 200,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "Honey17890",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "9c2 As3 Qc4/4h0 5h0 Th0 2h3 5c4/5s0 Js0 3s1 9s1 2s2",
            "win": 20,
            "playerId": "Honey17890"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:40:15",
    "roomId": "41b-1d992869"
}


{
    "stakes": 10,
    "handData": {"338246569": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "Mayur2217",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "4h3 Qh3 8s4/2c0 4s0 4c1 4d2 2s4/8c0 Th0 Tc0 8h1 8d2",
            "win": 480,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "7h1 6s2 Ts3 9d4",
            "rows": "Ac1 Ah2 9h4/3s0 5c0 3d1 9s2 5s3/2d0 Kh0 Kc0 Jh3 3c4",
            "win": -240,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "Honey17890",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "As0 Ad2 Jd4/9c0 7c1 Qc2 Qs3 6h4/5d0 6d0 Td0 Qd1 Kd3",
            "win": -240,
            "playerId": "Honey17890"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:42:32",
    "roomId": "41b-1d992869"
}


{
    "stakes": 10,
    "handData": {"338246973": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "Mayur2217",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Js1 4c3 Qc4/2s0 4h0 3s1 5c2 5h3/8d0 8s0 Tc0 Th2 8c4",
            "win": 240,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "TuPac1",
            "orderIndex": 2,
            "hero": true,
            "dead": "2c1 3d2 3h3 Jd4",
            "rows": "Qs0 As1 Qh2/Kd0 Ks0 Kh1 2h3 Jh4/7d0 8h0 4s2 5d3 9s4",
            "win": -120,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "Honey17890",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ad2 6s3 Ac4/7s0 6h1 6d1 7h2 Td3/9d0 Ts0 Jc0 Qd0 9h4",
            "win": -120,
            "playerId": "Honey17890"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:44:46",
    "roomId": "41b-1d992869"
}


{
    "stakes": 10,
    "handData": {"338247393": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "Mayur2217",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kh2 Jd3 Ah4/7d0 7s1 3h2 3s3 Ts4/5d0 6c0 7c0 8h0 4s1",
            "win": -140,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "4d1 Kc2 9s3 5c4",
            "rows": "Qh0 Kd0 Ks1/As0 Jc2 4c3 Js3 Ac4/2h0 2s0 3d1 2c2 7h4",
            "win": 60,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": -30,
            "playerName": "Honey17890",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qc0 3c4 Ad4/5h0 6s1 6h2 6d3 Jh3/8d0 8s0 9d0 9h1 9c2",
            "win": 80,
            "playerId": "Honey17890"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:46:57",
    "roomId": "41b-1d992869"
}


{
    "stakes": 10,
    "handData": {"338247755": [
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "Mayur2217",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kd0 Ks0 Jd2/Ac0 6c1 8d3 9d3 As4/5h0 Qh0 8h1 Jh2 Qs4",
            "win": -330,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": true,
            "result": 54,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "2d0 6d0",
            "rows": "9h0 Qd0 Qc0/2s0 3s0 5s0 8s0 9s0/4h0 4c0 4s0 Th0 Tc0",
            "win": 540,
            "playerId": "TuPac1"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "Honey17890",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Jc2 Ts3 9c4/2c0 4d0 3d1 2h2 3c3/7s0 Kh0 Kc0 7h1 6s4",
            "win": -210,
            "playerId": "Honey17890"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:48:49",
    "roomId": "41b-1d992869"
}


{
    "stakes": 10,
    "handData": {"338248036": [
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "Mayur2217",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Qc2 Ks4/4h0 6h0 2h1 2c2 4c3/9h0 9s0 7c1 5d3 5s4",
            "win": 140,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "6d1 5c2 Tc3 Ah4",
            "rows": "Kh0 Ad2 Ac2/Jc0 Td1 Ts1 6s3 9c4/8d0 8s0 Qs0 As3 3c4",
            "win": -140,
            "playerId": "TuPac1"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:50:12",
    "roomId": "41b-1d992869"
}


{
    "stakes": 10,
    "handData": {"338248254": [
        {
            "inFantasy": true,
            "result": -15,
            "playerName": "Mayur2217",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "9d0 9s0 Qd0/3c0 4c0 5c0 6s0 7c0/8c0 9c0 Tc0 Jc0 Qc0",
            "win": 160,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "5h1 Jd2 Ks3 2d4",
            "rows": "Kd0 Kh3 Ts4/6h0 6c0 7h1 8h1 8d2/4s0 Qs0 Qh2 4d3 2h4",
            "win": -160,
            "playerId": "TuPac1"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:50:54",
    "roomId": "41b-1d992869"
}


{
    "stakes": 10,
    "handData": {"338248356": [
        {
            "inFantasy": true,
            "result": -18,
            "playerName": "Mayur2217",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Qd0 Qs0 Ah0/6d0 6s0 7h0 7d0 Jh0/2c0 3c0 5c0 7c0 8c0",
            "win": -80,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": true,
            "result": -24,
            "playerName": "TuPac1",
            "orderIndex": 1,
            "hero": true,
            "dead": "6c0 Td0",
            "rows": "Jc0 Ks0 Ac0/2h0 2d0 2s0 4c0 4s0/8d0 8s0 9d0 9c0 9s0",
            "win": 80,
            "playerId": "TuPac1"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:51:36",
    "roomId": "41b-1d992869"
}


{
    "stakes": 10,
    "handData": {"338248452": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "Mayur2217",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Kc0 Qh1 Th2/2h0 3d0 4d1 7h4 7d4/6s0 Js0 4s2 5s3 Qs3",
            "win": 100,
            "playerId": "Mayur2217"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "TuPac1",
            "orderIndex": 0,
            "hero": true,
            "dead": "5d1 2c2 5h3 Kd4",
            "rows": "Ah0 Ad1 4c3/7s0 Tc2 As2 3c3 8s4/9s0 Td0 Jc0 8d1 5c4",
            "win": -100,
            "playerId": "TuPac1"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 11:53:19",
    "roomId": "41b-1d992869"
}


