{
    "stakes": 5,
    "handData": {"338175690": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "daretocall",
            "orderIndex": 0,
            "hero": true,
            "dead": "7c1 5c2 2d3 Td4",
            "rows": "Kc0 Kd1 5h3/Jh0 9h2 Th2 3d4 7h4/8s0 9s0 Ts0 3s1 6s3",
            "win": 0,
            "playerId": "daretocall"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ah0 Ac0 4s4/2h0 2c0 5d1 5s3 9c3/Js0 9d1 Qc2 Ks2 6d4",
            "win": 0,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 03:39:59",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338175858": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "daretocall",
            "orderIndex": 2,
            "hero": true,
            "dead": "9d1 Qc2 Kc3 Ad4",
            "rows": "Kh0 Ks2 2d3/5c0 6c0 3h1 6h1 Ts4/7d0 7c0 Jc2 As3 7s4",
            "win": -115,
            "playerId": "daretocall"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ac2 6s3 Ah4/9c0 9h1 Jd1 Th2 Js3/3d0 3s0 8h0 8c0 Kd4",
            "win": -115,
            "playerId": "shubhamkumarjha75"
        },
        {
            "inFantasy": false,
            "result": 54,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qh2 Qd3 9s4/2s0 Td0 5h2 Tc3 5s4/4h0 4c0 4s0 4d1 7h1",
            "win": 230,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 03:43:19",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338176123": [
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "daretocall",
            "orderIndex": 1,
            "hero": true,
            "dead": "4h1 Ah2 5c3 6d4",
            "rows": "Kh1 Jc4 Ad4/3d0 3c0 Jd0 2h1 2d3/9s0 Qs0 3s2 Js2 2s3",
            "win": -25,
            "playerId": "daretocall"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Qd0 Kc3 9c4/4c0 7c0 7d1 5s3 7h4/8h0 9h0 6h1 8d2 8s2",
            "win": -65,
            "playerId": "shubhamkumarjha75"
        },
        {
            "inFantasy": true,
            "result": 60,
            "playerName": "Mickier",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "6s0 Ac0 As0/Th0 Tc0 Jh0 Kd0 Ks0/3h0 4d0 5h0 6c0 7s0",
            "win": 90,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 03:46:18",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338176339": [
        {
            "inFantasy": false,
            "result": 54,
            "playerName": "daretocall",
            "orderIndex": 0,
            "hero": true,
            "dead": "8c1 Th2 3d3 8s4",
            "rows": "Kh1 Qd3 Qs4/7s0 5s2 Ks2 7h3 5h4/Td0 Ts0 Jh0 Jd0 Js1",
            "win": 170,
            "playerId": "daretocall"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "9s2 Ac3 Qc4/2s0 4d0 7d0 4c1 2c2/6h0 9h0 3h1 Ah3 5c4",
            "win": -145,
            "playerId": "shubhamkumarjha75"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "Mickier",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "As1 Qh3 2d4/4h0 5d0 6d2 6c2 8d4/7c0 Tc0 Jc0 9c1 3c3",
            "win": -25,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 03:48:45",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338176558": [
        {
            "inFantasy": true,
            "result": 51,
            "playerName": "daretocall",
            "orderIndex": 2,
            "hero": true,
            "dead": "4c0",
            "rows": "8c0 Kh0 Kd0/2h0 2d0 2s0 6h0 7d0/8s0 9s0 Tc0 Jd0 Qd0",
            "win": 115,
            "playerId": "daretocall"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ks2 7c4 7s4/4d0 6c0 Jh1 Jc2 6s3/3d0 3s0 Qc0 Qs1 3h3",
            "win": 45,
            "playerId": "shubhamkumarjha75"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "Mickier",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "As0 Ad1 Qh3/4h0 5s0 2c1 5h2 5c4/8d0 9c0 Js2 8h3 5d4",
            "win": -160,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 03:51:43",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338176795": [
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "daretocall",
            "orderIndex": 1,
            "hero": true,
            "dead": "Tc1 2c2 6d3 6s4",
            "rows": "Qh0 4c3 9c3/5h0 7d0 Jd2 Qd4 Kd4/3d0 3s0 8d1 8c1 3c2",
            "win": 45,
            "playerId": "daretocall"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "Kh1 Ac1 Ah2/2d0 7c0 7s0 6h2 2h4/4d0 4s0 Td3 Js3 Qc4",
            "win": -130,
            "playerId": "shubhamkumarjha75"
        },
        {
            "inFantasy": false,
            "result": 57,
            "playerName": "Mickier",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Ks0 5d2 Kc3/Ad0 6c1 Ts1 As3 Th4/9h0 9d0 Jh0 9s2 8h4",
            "win": 85,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 03:55:48",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338177106": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "daretocall",
            "orderIndex": 0,
            "hero": true,
            "dead": "5c1 3s2 3c3 Qd4",
            "rows": "Ah0 Ad1 Qs3/7d0 Jh1 Ts2 Td3 Tc4/4h0 Kh0 Kd0 6d2 6h4",
            "win": -120,
            "playerId": "daretocall"
        },
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "9d2 As2 7s3/2h0 4s0 2d1 3d1 2s4/7c0 8c0 Kc0 Qc3 Ac4",
            "win": 65,
            "playerId": "shubhamkumarjha75"
        },
        {
            "inFantasy": true,
            "result": 9,
            "playerName": "Mickier",
            "orderIndex": 2,
            "hero": false,
            "dead": "",
            "rows": "9c0 Jd0 Jc0/4d0 4c0 5h0 5s0 Th0/6c0 6s0 8h0 8s0 Ks0",
            "win": 55,
            "playerId": "Mickier"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 03:58:29",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338177263": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "daretocall",
            "orderIndex": 1,
            "hero": true,
            "dead": "9s1 9h2 8d3 5s4",
            "rows": "Qc0 Ks1 Jh4/2h0 4s0 4c2 5h3 5d4/7c0 9d0 8c1 Td2 6h3",
            "win": 40,
            "playerId": "daretocall"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "4h1 Kd2 Jc4/5c0 9c0 7s1 Ac3 3c4/8h0 Qd0 Qs0 2c2 Qh3",
            "win": -40,
            "playerId": "shubhamkumarjha75"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 04:00:36",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338177425": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "daretocall",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ks1 Ts2 6s3 2c4",
            "rows": "Qs0 Kd3 Qc4/2d0 4s0 As2 3d3 5d4/9c0 Tc0 8h1 Jh1 Qh2",
            "win": -15,
            "playerId": "daretocall"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ac3 5h4 Ah4/4c0 7d0 3c1 3s1 7h3/8d0 8s0 9h0 9d2 9s2",
            "win": 15,
            "playerId": "shubhamkumarjha75"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 04:02:04",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338177555": [
        {
            "inFantasy": true,
            "result": 36,
            "playerName": "daretocall",
            "orderIndex": 1,
            "hero": true,
            "dead": "3h0",
            "rows": "9h0 9c0 Kh0/6d0 6s0 7c0 7s0 Qs0/2h0 2c0 2s0 5d0 5c0",
            "win": -140,
            "playerId": "daretocall"
        },
        {
            "inFantasy": true,
            "result": 48,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 0,
            "hero": false,
            "dead": "",
            "rows": "Td0 Tc0 Ts0/2d0 3d0 7d0 8d0 Jd0/4h0 4d0 4c0 6h0 6c0",
            "win": 140,
            "playerId": "shubhamkumarjha75"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 04:02:56",
    "roomId": "41b-1d1a0f20"
}


{
    "stakes": 5,
    "handData": {"338177638": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "daretocall",
            "orderIndex": 0,
            "hero": true,
            "dead": "Td1 4h2 Jc3 Ts4",
            "rows": "Kd3 As3 7d4/4c0 6d0 6c0 4d1 2c2/8s0 9s0 9h1 3s2 6s4",
            "win": -75,
            "playerId": "daretocall"
        },
        {
            "inFantasy": true,
            "result": 27,
            "playerName": "shubhamkumarjha75",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qh0 Qd0 Ac0/2h0 2s0 3h0 3c0 Kc0/7s0 8d0 9c0 Th0 Js0",
            "win": 75,
            "playerId": "shubhamkumarjha75"
        }
    ]},
    "appName": "Spartan",
    "price": "1INR",
    "joined": true,
    "clubId": "0",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-06-20 04:04:04",
    "roomId": "41b-1d1a0f20"
}


