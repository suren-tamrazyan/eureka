{
    "stakes": 1,
    "handData": {"200528022019-6850375-0000001-1": [
        {
            "inFantasy": true,
            "playerName": "pid433557",
            "orderIndex": 0,
            "hero": false,
            "dead": "Td0 Jc1 2d2",
            "rows": "Ah0 Ad0 As0/4h0 5s0 6d0 7c0 8c0/8s0 9s0 Ts0 Js0 Ks0",
            "playerId": "pid433557"
        },
        {
            "inFantasy": false,
            "playerName": "pid2501465",
            "orderIndex": 1,
            "hero": false,
            "dead": "2c1 Ac2 3s3 9c4",
            "rows": "Kd3 Qd4 Kh4/6c0 4d1 8d1 5c2 7s2/2h0 3h0 5h0 Jh0 8h3",
            "playerId": "pid2501465"
        }
    ]},
    "joined": false,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 23:02:24",
    "roomId": "6850375"
}


{
    "stakes": 1,
    "handData": {"200528022019-6850375-0000002-1": [
        {
            "inFantasy": true,
            "playerName": "pid433557",
            "orderIndex": 1,
            "hero": false,
            "dead": "6d0 2s1 5d2",
            "rows": "Kc0 Ah0 Ad0/4h0 4c0 4s0 8h0 8s0/9h0 9d0 9s0 Th0 Td0",
            "playerId": "pid433557"
        },
        {
            "inFantasy": true,
            "playerName": "pid2501465",
            "orderIndex": 0,
            "hero": false,
            "dead": "Kh0 9c1",
            "rows": "Qh0 Qd0 Qc0/3d0 4d0 5s0 6h0 7d0/3s0 6s0 Js0 Ks0 As0",
            "playerId": "pid2501465"
        }
    ]},
    "joined": false,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 23:03:41",
    "roomId": "6850375"
}


{
    "stakes": 1,
    "handData": {"200528022019-6850375-0000003-1": [
        {
            "inFantasy": false,
            "playerName": "pid433557",
            "orderIndex": 0,
            "hero": false,
            "dead": "3c1 8h2 2c3 Qs4",
            "rows": "Qd1 Kd2 Js4/7d0 9d0 5d1 Jd2 Ad3/5s0 6s0 8s0 6c3 4s4",
            "playerId": "pid433557"
        },
        {
            "inFantasy": true,
            "playerName": "pid2501465",
            "orderIndex": 1,
            "hero": false,
            "dead": "2h0 2s1",
            "rows": "Td0 Ah0 Ac0/3d0 3s0 5c0 Kh0 Ks0/7h0 8d0 9s0 Th0 Jc0",
            "playerId": "pid2501465"
        }
    ]},
    "joined": false,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 23:04:40",
    "roomId": "6850375"
}


{
    "stakes": 1,
    "handData": {"200528022019-6850375-0000004-1": [
        {
            "inFantasy": false,
            "playerName": "pid433557",
            "orderIndex": 2,
            "hero": false,
            "dead": "2d1 7h2 7d3 Jh4",
            "rows": "Ah0 Qd3 Qh4/Ts0 5h1 5d1 8d3 8c4/2c0 7c0 Qc0 4c2 Kc2",
            "playerId": "pid433557"
        },
        {
            "inFantasy": false,
            "playerName": "pid4009851",
            "orderIndex": 0,
            "hero": true,
            "dead": "6c1 Th2 Td3 8h4",
            "rows": "Kd0 Ad1 Ac2/3h0 3s0 4h2 3c3 6s4/9d0 Jc0 Jd1 9h3 5c4",
            "playerId": "pid4009851"
        },
        {
            "inFantasy": false,
            "playerName": "pid2501465",
            "orderIndex": 1,
            "hero": false,
            "dead": "6h1 Js2 4d3 6d4",
            "rows": "As0 Qs2 Kh3/Tc0 2s2 3d3 9c4 9s4/7s0 8s0 Ks0 4s1 5s1",
            "playerId": "pid2501465"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 23:05:41",
    "roomId": "6850375"
}


{
    "stakes": 1,
    "handData": {"200528022019-6850375-0000005-1": [
        {
            "inFantasy": true,
            "playerName": "pid433557",
            "orderIndex": 1,
            "hero": false,
            "dead": "2d0",
            "rows": "Jc0 Js0 Ad0/5h0 5c0 6d0 6s0 Kh0/3h0 3s0 7s0 Td0 Tc0",
            "playerId": "pid433557"
        },
        {
            "inFantasy": false,
            "playerName": "pid4009851",
            "orderIndex": 2,
            "hero": true,
            "dead": "6c1 2s2 Qs3 4s4",
            "rows": "9d2 Ac2 Qc3/3c0 4d0 7h0 8c4 8s4/Ts0 Jh0 9c1 Qh1 Kc3",
            "playerId": "pid4009851"
        },
        {
            "inFantasy": false,
            "playerName": "pid2501465",
            "orderIndex": 0,
            "hero": false,
            "dead": "Kd1 Jd2 8d3 4c4",
            "rows": "Ah1 As2 Qd3/2c0 7c0 5s3 2h4 Ks4/6h0 9h0 Th0 8h1 4h2",
            "playerId": "pid2501465"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 23:07:37",
    "roomId": "6850375"
}


{
    "stakes": 1,
    "handData": {"200528022019-6850375-0000006-1": [
        {
            "inFantasy": false,
            "playerName": "pid433557",
            "orderIndex": 1,
            "hero": false,
            "dead": "Ts1 6h2 4c3 2h4",
            "rows": "Qd0 Qs1 5h3/3d0 7s2 9d2 8c4 9h4/2d0 2c0 Jc0 2s1 Qc3",
            "playerId": "pid433557"
        },
        {
            "inFantasy": false,
            "playerName": "pid4009851",
            "orderIndex": 0,
            "hero": true,
            "dead": "3h1 Ks2 3s3 7h4",
            "rows": "Ac0 Kd2 Ad4/6c0 6s0 4s3 5d3 6d4/7c0 9c0 8h1 Th1 Js2",
            "playerId": "pid4009851"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 23:08:39",
    "roomId": "6850375"
}


{
    "stakes": 1,
    "handData": {"200528022019-6850375-0000007-1": [
        {
            "inFantasy": false,
            "playerName": "pid433557",
            "orderIndex": 0,
            "hero": false,
            "dead": "2h1 2s2 2d3 7s4",
            "rows": "Ks0 Ac2 8h4/4d0 Jd0 Js1 5s2 5h4/Qh0 Qc0 Td1 8c3 8s3",
            "playerId": "pid433557"
        },
        {
            "inFantasy": true,
            "playerName": "pid4009851",
            "orderIndex": 1,
            "hero": true,
            "dead": "4h0 Tc0 8d0",
            "rows": "Kh0 Ad0 As0/7h0 7d0 7c0 9h0 9d0/3h0 3d0 3c0 3s0 Kd0",
            "playerId": "pid4009851"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 23:09:25",
    "roomId": "6850375"
}


{
    "stakes": 1,
    "handData": {"200528022019-6850375-0000008-1": [
        {
            "inFantasy": false,
            "playerName": "pid433557",
            "orderIndex": 1,
            "hero": false,
            "dead": "9s1 5d2 2h3 9h4",
            "rows": "7s0 7h1 4s3/2c0 5c0 2d1 8s3 2s4/Td0 Jh0 Qd2 Qs2 Kd4",
            "playerId": "pid433557"
        },
        {
            "inFantasy": true,
            "playerName": "pid4009851",
            "orderIndex": 0,
            "hero": true,
            "dead": "3s0 4d0 9d0",
            "rows": "Th0 Ts0 Ks0/4c0 6c0 7c0 Qc0 Kc0/3h0 4h0 6h0 Qh0 Ah0",
            "playerId": "pid4009851"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 23:10:31",
    "roomId": "6850375"
}


{
    "stakes": 1,
    "handData": {"200528022019-6850375-0000009-1": [
        {
            "inFantasy": false,
            "playerName": "pid433557",
            "orderIndex": 0,
            "hero": false,
            "dead": "As1 Qh2 8h3 Qc4",
            "rows": "Ad0 Qd3 Kd3/4h0 5s0 3s2 7s2 2d4/6c0 8d0 7h1 9h1 5h4",
            "playerId": "pid433557"
        },
        {
            "inFantasy": false,
            "playerName": "pid4009851",
            "orderIndex": 1,
            "hero": true,
            "dead": "4c1 5c2 8s3 4d4",
            "rows": "Ah0 Ts2 3c3/2c0 6s0 7d0 7c4 Td4/Th0 Qs1 Kc1 Jd2 9s3",
            "playerId": "pid4009851"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 23:12:22",
    "roomId": "6850375"
}


{
    "stakes": 1,
    "handData": {"200528022019-6850375-0000010-1": [
        {
            "inFantasy": false,
            "playerName": "pid433557",
            "orderIndex": 1,
            "hero": false,
            "dead": "Ks1 8d2 As3 Tc4",
            "rows": "Qh0 Ah0 Kc3/2d0 5s1 3h2 7c3 5d4/6d0 9c0 6h1 Jd2 6s4",
            "playerId": "pid433557"
        },
        {
            "inFantasy": false,
            "playerName": "pid4009851",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jc1 4c2 5h3 4h4",
            "rows": "Ac0 Ts3 8s4/Qd0 Qs0 3c1 8h3 8c4/2h0 Kh0 9h1 9s2 Kd2",
            "playerId": "pid4009851"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 23:13:41",
    "roomId": "6850375"
}


{
    "stakes": 1,
    "handData": {"200528022019-6850375-0000011-1": [
        {
            "inFantasy": false,
            "playerName": "pid433557",
            "orderIndex": 0,
            "hero": false,
            "dead": "4s1 7c2 8c3 4c4",
            "rows": "Ad0 Kc1 Qd3/2h0 3s0 5s0 6d3 5d4/8d0 Jd1 7d2 Tc2 Js4",
            "playerId": "pid433557"
        },
        {
            "inFantasy": false,
            "playerName": "pid4009851",
            "orderIndex": 1,
            "hero": true,
            "dead": "5c1 4h2 Ac3 9s4",
            "rows": "As0 Ks1 Ah2/2c0 7s0 2d2 8h3 9c4/Jc0 Qh0 Qs1 Kh3 3c4",
            "playerId": "pid4009851"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 23:15:46",
    "roomId": "6850375"
}


{
    "stakes": 1,
    "handData": {"200528022019-6850375-0000012-1": [
        {
            "inFantasy": false,
            "playerName": "pid433557",
            "orderIndex": 1,
            "hero": false,
            "dead": "Ts1 4s2 4h3 7s4",
            "rows": "Ac0 Kc3 Qc4/2d0 5d0 Td1 Tc2 5h4/6s0 7h0 7c1 7d2 4d3",
            "playerId": "pid433557"
        },
        {
            "inFantasy": false,
            "playerName": "pid4009851",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h1 5c2 8s3 6c4",
            "rows": "As1 9c2 2c4/Qd0 Kd1 Qh2 Qs3 Kh3/3h0 3d0 3c0 3s0 Jd4",
            "playerId": "pid4009851"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 23:17:27",
    "roomId": "6850375"
}


{
    "stakes": 1,
    "handData": {"200528022019-6850375-0000013-1": [
        {
            "inFantasy": false,
            "playerName": "pid4009851",
            "orderIndex": 1,
            "hero": true,
            "dead": "6c1 Jc2 Ts3 7c4",
            "rows": "Ks0 Kd1 8s4/4h0 9h2 9d2 3s3 4s4/8c0 Th0 Qd0 Qs1 Td3",
            "playerId": "pid4009851"
        },
        {
            "inFantasy": false,
            "playerName": "pid2049747",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jh1 7h2 3h3 4c4",
            "rows": "Qh0 Kh0 5c4/As0 9s1 2c2 Ac3 2h4/5d0 8d0 7d1 Jd2 2d3",
            "playerId": "pid2049747"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 23:19:07",
    "roomId": "6850375"
}


{
    "stakes": 1,
    "handData": {"200528022019-6850375-0000014-1": [
        {
            "inFantasy": true,
            "playerName": "pid4009851",
            "orderIndex": 0,
            "hero": true,
            "dead": "4s0 4h0",
            "rows": "Qs0 Kd0 Ks0/6s0 7h0 8c0 9h0 Tc0/3h0 3d0 3c0 5h0 5c0",
            "playerId": "pid4009851"
        },
        {
            "inFantasy": false,
            "playerName": "pid2049747",
            "orderIndex": 1,
            "hero": false,
            "dead": "8d1 Td2 2c3 Js4",
            "rows": "Ac0 Ah1 Jh4/4d0 2d1 Qd3 Qc3 4c4/8h0 Th0 Jc0 9s2 Qh2",
            "playerId": "pid2049747"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 23:20:11",
    "roomId": "6850375"
}


{
    "stakes": 1,
    "handData": {"200528022019-6850375-0000015-1": [
        {
            "inFantasy": false,
            "playerName": "pid4009851",
            "orderIndex": 1,
            "hero": true,
            "dead": "6s1 4d2 Ts3 5s4",
            "rows": "Kc2 9h4 9d4/3d0 8s0 Jh0 3s1 Jd1/7c0 Qc0 7d2 Qh3 Qd3",
            "playerId": "pid4009851"
        },
        {
            "inFantasy": true,
            "playerName": "pid2049747",
            "orderIndex": 0,
            "hero": false,
            "dead": "9s0 6c1 2h2",
            "rows": "8h0 8d0 8c0/Th0 Js0 Qs0 Kh0 Ad0/4h0 4c0 4s0 5h0 5d0",
            "playerId": "pid2049747"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 23:20:52",
    "roomId": "6850375"
}


{
    "stakes": 1,
    "handData": {"200528022019-6850375-0000016-1": [
        {
            "inFantasy": false,
            "playerName": "pid4009851",
            "orderIndex": 0,
            "hero": true,
            "dead": "2d1 7c2 2h3 7d4",
            "rows": "Kc0 Ks1 Qc4/6h0 9c0 5c1 9h2 6s4/4s0 Qs0 Jc2 4c3 Qh3",
            "playerId": "pid4009851"
        },
        {
            "inFantasy": true,
            "playerName": "pid2049747",
            "orderIndex": 1,
            "hero": false,
            "dead": "3c0 2c1 3h2",
            "rows": "8c0 Ah0 As0/5h0 7h0 Th0 Jh0 Kh0/4d0 8d0 9d0 Qd0 Kd0",
            "playerId": "pid2049747"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 23:21:34",
    "roomId": "6850375"
}


{
    "stakes": 1,
    "handData": {"200528022019-6850375-0000017-1": [
        {
            "inFantasy": true,
            "playerName": "pid4009851",
            "orderIndex": 1,
            "hero": true,
            "dead": "8s0 4s0",
            "rows": "9s0 Jd0 Kd0/6h0 7c0 8c0 9c0 Th0/2c0 2s0 5h0 5d0 5s0",
            "playerId": "pid4009851"
        },
        {
            "inFantasy": false,
            "playerName": "pid2049747",
            "orderIndex": 0,
            "hero": false,
            "dead": "6s1 8h2 7s3 2d4",
            "rows": "Kh0 Qc3 9d4/Ah0 Ad0 Jh2 3c3 Jc4/3d0 7d0 4h1 4d1 4c2",
            "playerId": "pid2049747"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 23:22:24",
    "roomId": "6850375"
}


{
    "stakes": 1,
    "handData": {"200528022019-6850375-0000018-1": [
        {
            "inFantasy": false,
            "playerName": "pid433557",
            "orderIndex": 0,
            "hero": false,
            "dead": "Kd1 7h2 3c3 5s4",
            "rows": "Ts2 8c4 9d4/5h0 8h0 5c1 3h2 5d3/Jd0 Qd0 Qc0 Jh1 Qs3",
            "playerId": "pid433557"
        },
        {
            "inFantasy": false,
            "playerName": "pid4009851",
            "orderIndex": 1,
            "hero": true,
            "dead": "6c1 Qh2 As3 6h4",
            "rows": "Kh2 Ks3 9s4/7c0 Th0 9c1 7s2 Td3/4d0 4c0 4s0 8d1 9h4",
            "playerId": "pid4009851"
        },
        {
            "inFantasy": false,
            "playerName": "pid2049747",
            "orderIndex": 2,
            "hero": false,
            "dead": "Tc1 3d2 Kc3 3s4",
            "rows": "4h0 Ac2 Ah3/7d0 2d1 8s1 2h2 2s3/6d0 6s0 Jc0 Js4 Ad4",
            "playerId": "pid2049747"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 23:24:09",
    "roomId": "6850375"
}


{
    "stakes": 1,
    "handData": {"200528022019-6850375-0000019-1": [
        {
            "inFantasy": false,
            "playerName": "pid433557",
            "orderIndex": 2,
            "hero": false,
            "dead": "8d1 8s2 3d3 6s4",
            "rows": "Qc0 Qh1 7h3/6d0 6c0 3c1 5c2 5d3/Td0 Tc0 Jh2 3h4 Qs4",
            "playerId": "pid433557"
        },
        {
            "inFantasy": true,
            "playerName": "pid4009851",
            "orderIndex": 0,
            "hero": true,
            "dead": "6h0 5h0",
            "rows": "9h0 Ac0 As0/4d0 4s0 7s0 Jc0 Js0/2h0 2d0 Kh0 Kd0 Ks0",
            "playerId": "pid4009851"
        },
        {
            "inFantasy": false,
            "playerName": "pid2049747",
            "orderIndex": 1,
            "hero": false,
            "dead": "9s1 Qd2 Th3 7d4",
            "rows": "Ah0 Ad1 9d3/3s0 2c2 5s2 4c3 Kc4/7c0 8c0 9c0 Ts1 Jd4",
            "playerId": "pid2049747"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 23:25:55",
    "roomId": "6850375"
}


{
    "stakes": 1,
    "handData": {"200528022019-6850375-0000020-1": [
        {
            "inFantasy": false,
            "playerName": "pid433557",
            "orderIndex": 1,
            "hero": false,
            "dead": "4h1 Kd2 3h3 7d4",
            "rows": "Jd1 5s3 Qh4/Tc0 3c1 Ac2 6c3 3d4/2s0 8s0 Qs0 As0 Ks2",
            "playerId": "pid433557"
        },
        {
            "inFantasy": false,
            "playerName": "pid4009851",
            "orderIndex": 2,
            "hero": true,
            "dead": "Kh1 2h2 5c3 Kc4",
            "rows": "Jc2 Ad2 Ah3/4s0 7h0 5h3 4c4 5d4/9h0 Ts0 Js0 7c1 8h1",
            "playerId": "pid4009851"
        },
        {
            "inFantasy": false,
            "playerName": "pid2049747",
            "orderIndex": 0,
            "hero": false,
            "dead": "2d1 9d2 Td3 2c4",
            "rows": "9s2 6d3 Qc4/3s0 6h0 7s1 4d3 6s4/9c0 Th0 Qd0 Jh1 8d2",
            "playerId": "pid2049747"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 23:28:26",
    "roomId": "6850375"
}


{
    "stakes": 1,
    "handData": {"200528022019-6850375-0000021-1": [
        {
            "inFantasy": false,
            "playerName": "pid433557",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jh1 Jd2 2s3 5d4",
            "rows": "Qs0 Ks2 9s3/3s0 5h0 4c1 5c3 9h4/6d0 7d0 Th1 Td2 Ad4",
            "playerId": "pid433557"
        },
        {
            "inFantasy": true,
            "playerName": "pid4009851",
            "orderIndex": 1,
            "hero": true,
            "dead": "4d0 3c0 5s0",
            "rows": "9d0 Ah0 Ac0/6c0 Jc0 Js0 Qd0 Qc0/8c0 8s0 Kh0 Kd0 Kc0",
            "playerId": "pid4009851"
        },
        {
            "inFantasy": false,
            "playerName": "pid2049747",
            "orderIndex": 2,
            "hero": false,
            "dead": "3h1 3d2 Tc3 4s4",
            "rows": "As0 Ts3 4h4/2c0 6h0 9c1 6s2 2d4/7h0 7c0 Qh1 7s2 8h3",
            "playerId": "pid2049747"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 23:30:43",
    "roomId": "6850375"
}


