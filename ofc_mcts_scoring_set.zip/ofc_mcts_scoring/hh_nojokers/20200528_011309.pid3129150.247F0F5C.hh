{
    "stakes": 10,
    "handData": {"200528045612-6861740-0000000-1": [
        {
            "inFantasy": false,
            "playerName": "pid4004731",
            "orderIndex": 2,
            "hero": false,
            "dead": "8h1 5s2 Jc3 8c4",
            "rows": "2c2 As3 Td4/4c0 5h0 5c0 6s1 6c4/3h0 3d0 Qc1 9c2 3c3",
            "playerId": "pid4004731"
        },
        {
            "inFantasy": false,
            "playerName": "pid294603",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jh1 2s2 4s3 Ac4",
            "rows": "Kh1 Qh3 Ks3/7c0 Ts0 7d1 Th2 7h4/9d0 Jd0 Kd0 Qd2 Kc4",
            "playerId": "pid294603"
        },
        {
            "inFantasy": false,
            "playerName": "pid3129150",
            "orderIndex": 1,
            "hero": true,
            "dead": "8d1 4d2 4h3 3s4",
            "rows": "Ah0 Ad3 Tc4/2h0 5d0 2d2 6d2 6h3/8s0 Js0 7s1 9s1 Qs4",
            "playerId": "pid3129150"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 22:13:09",
    "roomId": "6861740"
}


{
    "stakes": 10,
    "handData": {"200528045612-6861740-0000001-1": [
        {
            "inFantasy": false,
            "playerName": "pid4004731",
            "orderIndex": 1,
            "hero": false,
            "dead": "7c1 4c2 3h3 2c4",
            "rows": "Kh0 As2 Qd4/2d0 6s0 5d1 5s2 6c3/8h0 8c0 Jd1 8s3 Js4",
            "playerId": "pid4004731"
        },
        {
            "inFantasy": false,
            "playerName": "pid294603",
            "orderIndex": 2,
            "hero": false,
            "dead": "4h1 Jc2 7s3 4d4",
            "rows": "6d3 Kd3 Ad4/2h0 3c0 7h0 2s2 7d2/Ts0 Jh0 8d1 Qc1 Ah4",
            "playerId": "pid294603"
        },
        {
            "inFantasy": true,
            "playerName": "pid3129150",
            "orderIndex": 0,
            "hero": true,
            "dead": "3s0 3d0 4s0",
            "rows": "Kc0 Ks0 Ac0/5h0 5c0 6h0 Th0 Td0/9h0 9d0 9c0 9s0 Qh0",
            "playerId": "pid3129150"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 22:14:30",
    "roomId": "6861740"
}


{
    "stakes": 10,
    "handData": {"200528045612-6861740-0000002-1": [
        {
            "inFantasy": false,
            "playerName": "pid4004731",
            "orderIndex": 0,
            "hero": false,
            "dead": "Tc1 2s2 3d3 5h4",
            "rows": "Qs2 Ah2 9h4/3s0 5d0 3h1 7c1 7h3/4h0 4d0 Jc0 Kc3 8d4",
            "playerId": "pid4004731"
        },
        {
            "inFantasy": true,
            "playerName": "pid3129150",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qc0 Kd0 8h0",
            "rows": "Jh0 Jd0 Ac0/4s0 5s0 7s0 8s0 Ks0/6h0 6d0 9d0 9c0 9s0",
            "playerId": "pid3129150"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 22:15:27",
    "roomId": "6861740"
}


{
    "stakes": 10,
    "handData": {"200528045612-6861740-0000003-1": [
        {
            "inFantasy": false,
            "playerName": "pid348217",
            "orderIndex": 0,
            "hero": false,
            "dead": "6h1 9c2 5s3 8s4",
            "rows": "Ac0 Tc2 9d3/7d0 7s0 8d1 5c2 2d3/Jh0 Qd0 Qh1 Jd4 Jc4",
            "playerId": "pid348217"
        },
        {
            "inFantasy": false,
            "playerName": "pid3129150",
            "orderIndex": 1,
            "hero": true,
            "dead": "6c1 8c2 Ah3 2c4",
            "rows": "Ad1 As2 9s4/4d0 4c0 6s0 4h3 Qc3/8h0 9h0 7h1 Ts2 Js4",
            "playerId": "pid3129150"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 22:17:16",
    "roomId": "6861740"
}


{
    "stakes": 10,
    "handData": {"200528045612-6861740-0000004-1": [
        {
            "inFantasy": false,
            "playerName": "pid348217",
            "orderIndex": 1,
            "hero": false,
            "dead": "7s1 6c2 2c3 6d4",
            "rows": "Kd0 Ah2 9h3/5c0 3h1 5h1 4h3 3s4/Ts0 Qc0 Qs0 Qd2 8s4",
            "playerId": "pid348217"
        },
        {
            "inFantasy": true,
            "playerName": "pid3129150",
            "orderIndex": 0,
            "hero": true,
            "dead": "9s0 5s0 8c0",
            "rows": "Tc0 Jh0 Jc0/2h0 7h0 8h0 Th0 Qh0/4d0 5d0 7d0 9d0 Ad0",
            "playerId": "pid3129150"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 22:18:14",
    "roomId": "6861740"
}


{
    "stakes": 10,
    "handData": {"200528045612-6861740-0000005-1": [
        {
            "inFantasy": false,
            "playerName": "pid348217",
            "orderIndex": 0,
            "hero": false,
            "dead": "5c1 Js2 3h3 5s4",
            "rows": "Ac0 Jh1 Ah2/2d0 Td0 8h2 Ts3 6c4/Kh0 Ks0 9s1 3d3 Jc4",
            "playerId": "pid348217"
        },
        {
            "inFantasy": false,
            "playerName": "pid3129150",
            "orderIndex": 1,
            "hero": true,
            "dead": "8c1 9h2 Tc3 Qd4",
            "rows": "Kc0 Ad2 Kd3/2h0 4h1 4d1 7h2 3s4/6h0 6d0 Jd0 6s3 3c4",
            "playerId": "pid3129150"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 22:20:14",
    "roomId": "6861740"
}


{
    "stakes": 10,
    "handData": {"200528045612-6861740-0000006-1": [
        {
            "inFantasy": false,
            "playerName": "pid348217",
            "orderIndex": 1,
            "hero": false,
            "dead": "2h1 5h2 Jc3 8d4",
            "rows": "Ks0 Th4 Kh4/8h0 6s1 9c2 9s2 9h3/2d0 4d0 7d0 6d1 3d3",
            "playerId": "pid348217"
        },
        {
            "inFantasy": false,
            "playerName": "pid3129150",
            "orderIndex": 0,
            "hero": true,
            "dead": "2s1 5s2 2c3 6h4",
            "rows": "Ah0 As0 Tc4/4h0 7h0 3s1 4c2 7c4/Qc0 Qh1 5d2 Jh3 Jd3",
            "playerId": "pid3129150"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 22:21:14",
    "roomId": "6861740"
}


{
    "stakes": 10,
    "handData": {"200528045612-6861740-0000007-1": [
        {
            "inFantasy": true,
            "playerName": "pid348217",
            "orderIndex": 0,
            "hero": false,
            "dead": "5d0 4d1",
            "rows": "3h0 3d0 3s0/7h0 7d0 7c0 8d0 Qc0/2h0 2d0 2c0 2s0 Jc0",
            "playerId": "pid348217"
        },
        {
            "inFantasy": true,
            "playerName": "pid3129150",
            "orderIndex": 1,
            "hero": true,
            "dead": "Tc0 5c0 4c0",
            "rows": "Ah0 Ad0 Ac0/8h0 9d0 Th0 Jh0 Qd0/5s0 7s0 Js0 Qs0 As0",
            "playerId": "pid3129150"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 22:22:08",
    "roomId": "6861740"
}


{
    "stakes": 10,
    "handData": {"200528045612-6861740-0000008-1": [
        {
            "inFantasy": true,
            "playerName": "pid348217",
            "orderIndex": 1,
            "hero": false,
            "dead": "Td0 5c1",
            "rows": "8d0 8s0 Kd0/2s0 3s0 4s0 5s0 7s0/3h0 5h0 9h0 Kh0 Ah0",
            "playerId": "pid348217"
        },
        {
            "inFantasy": true,
            "playerName": "pid3129150",
            "orderIndex": 0,
            "hero": true,
            "dead": "4d0 6h0 4h0",
            "rows": "Qs0 Ad0 As0/7c0 8h0 9s0 Tc0 Jc0/2c0 6c0 8c0 Qc0 Kc0",
            "playerId": "pid3129150"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 22:23:13",
    "roomId": "6861740"
}


{
    "stakes": 10,
    "handData": {"200528045612-6861740-0000009-1": [
        {
            "inFantasy": false,
            "playerName": "pid348217",
            "orderIndex": 0,
            "hero": false,
            "dead": "7s1 Kd2 8s3 2s4",
            "rows": "Kc3 Ad3 Qc4/4c0 4s0 3c1 Td2 Ts2/5h0 8h0 Th0 3h1 6s4",
            "playerId": "pid348217"
        },
        {
            "inFantasy": false,
            "playerName": "pid3129150",
            "orderIndex": 1,
            "hero": true,
            "dead": "2c1 Qs2 9h3 7d4",
            "rows": "6h1 Ac2 6c4/7c0 9c0 Jh0 Js3 Jd4/8d0 Qd0 4d1 2d2 6d3",
            "playerId": "pid3129150"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 22:24:57",
    "roomId": "6861740"
}


{
    "stakes": 10,
    "handData": {"200528045612-6861740-0000010-1": [
        {
            "inFantasy": false,
            "playerName": "pid348217",
            "orderIndex": 1,
            "hero": false,
            "dead": "4h1 Tc2 5h3 8c4",
            "rows": "Kd0 8h3 Td3/3d0 6c0 6s1 2d2 Jc4/8s0 Js0 Qs1 As2 7s4",
            "playerId": "pid348217"
        },
        {
            "inFantasy": false,
            "playerName": "pid3129150",
            "orderIndex": 0,
            "hero": true,
            "dead": "4s1 Kh2 2h3 4c4",
            "rows": "Ac1 7d3 Jd4/8d0 Ts1 Qh2 Th3 Ad4/7c0 9c0 Qc0 Kc0 2c2",
            "playerId": "pid3129150"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 22:26:08",
    "roomId": "6861740"
}


{
    "stakes": 10,
    "handData": {"200528045612-6861740-0000011-1": [
        {
            "inFantasy": false,
            "playerName": "pid348217",
            "orderIndex": 0,
            "hero": false,
            "dead": "7h1 Ts2 Tc3 8h4",
            "rows": "Kh1 Kc3 Kd4/2d0 3c0 4c0 6h2 As4/9h0 Js0 Th1 Qh2 8c3",
            "playerId": "pid348217"
        },
        {
            "inFantasy": false,
            "playerName": "pid3129150",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jc1 3d2 Jd3 4s4",
            "rows": "5h2 Ac3 Ad4/2c0 9c0 9s1 9d2 7c4/6s0 7s0 Qs0 5s1 3s3",
            "playerId": "pid3129150"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 22:27:40",
    "roomId": "6861740"
}


{
    "stakes": 10,
    "handData": {"200528045612-6861740-0000012-1": [
        {
            "inFantasy": false,
            "playerName": "pid348217",
            "orderIndex": 1,
            "hero": false,
            "dead": "8s1 8h2 8c3 Kd4",
            "rows": "Ks1 Kh3 As3/3h0 3c0 5s0 2s2 6c4/4d0 7d0 7h1 4c2 7c4",
            "playerId": "pid348217"
        },
        {
            "inFantasy": true,
            "playerName": "pid3129150",
            "orderIndex": 0,
            "hero": true,
            "dead": "8d0 2h0 7s0",
            "rows": "9c0 Qs0 Ac0/4h0 4s0 Th0 Td0 Ts0/6h0 6s0 Jd0 Jc0 Js0",
            "playerId": "pid3129150"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 22:28:37",
    "roomId": "6861740"
}


{
    "stakes": 10,
    "handData": {"200528045612-6861740-0000013-1": [
        {
            "inFantasy": false,
            "playerName": "pid348217",
            "orderIndex": 0,
            "hero": false,
            "dead": "2s1 3s2 2c3 8c4",
            "rows": "Ad2 4h3 Ks4/5c0 7h0 7s0 Ts3 Jh4/6d0 9d0 2d1 Qd1 4d2",
            "playerId": "pid348217"
        },
        {
            "inFantasy": false,
            "playerName": "pid3129150",
            "orderIndex": 1,
            "hero": true,
            "dead": "5d1 Qh2 6h3 7d4",
            "rows": "Ah0 Ac3 9c4/Tc0 7c1 Kc1 Kh3 Kd4/4s0 Js0 Qs0 9s2 As2",
            "playerId": "pid3129150"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 22:30:25",
    "roomId": "6861740"
}


{
    "stakes": 10,
    "handData": {"200528045612-6861740-0000014-1": [
        {
            "inFantasy": false,
            "playerName": "pid348217",
            "orderIndex": 1,
            "hero": false,
            "dead": "3h1 4h2 8d3 6d4",
            "rows": "Qd1 9d2 Ah3/8c0 Jh0 Jc1 5h2 2h3/7s0 8s0 As0 Qc4 Qs4",
            "playerId": "pid348217"
        },
        {
            "inFantasy": true,
            "playerName": "pid3129150",
            "orderIndex": 0,
            "hero": true,
            "dead": "4d0 2s0 6s0",
            "rows": "Td0 Kh0 Ks0/6h0 7h0 8h0 Th0 Qh0/2c0 3c0 7c0 Kc0 Ac0",
            "playerId": "pid3129150"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 22:31:16",
    "roomId": "6861740"
}


{
    "stakes": 10,
    "handData": {"200528045612-6861740-0000015-1": [
        {
            "inFantasy": false,
            "playerName": "pid3824990",
            "orderIndex": 0,
            "hero": false,
            "dead": "7d1 Qh2 3s3 2d4",
            "rows": "As0 Ac2 8d4/5d0 5h2 3d3 Ad3 Ah4/2h0 6h0 7h0 6c1 6s1",
            "playerId": "pid3824990"
        },
        {
            "inFantasy": false,
            "playerName": "pid3129150",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qs1 4d2 5c3 8h4",
            "rows": "Ks0 Kd2 5s4/Td0 Js0 9h3 Ts3 4s4/3c0 8c0 9c1 Qc1 Kc2",
            "playerId": "pid3129150"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 22:32:59",
    "roomId": "6861740"
}


{
    "stakes": 10,
    "handData": {"200528045612-6861740-0000016-1": [
        {
            "inFantasy": true,
            "playerName": "pid3824990",
            "orderIndex": 1,
            "hero": false,
            "dead": "6h0 7c1 5c2",
            "rows": "3d0 3c0 Qd0/5s0 6s0 7s0 Ks0 As0/2d0 2c0 4h0 4d0 4c0",
            "playerId": "pid3824990"
        },
        {
            "inFantasy": false,
            "playerName": "pid3129150",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qh1 8s2 Ah3 Ts4",
            "rows": "Ac1 Kc2 Td3/2h0 7h0 4s1 8d3 Tc4/9h0 9d0 Jd0 5d2 3h4",
            "playerId": "pid3129150"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 22:33:51",
    "roomId": "6861740"
}


{
    "stakes": 10,
    "handData": {"200528045612-6861740-0000017-1": [
        {
            "inFantasy": false,
            "playerName": "pid3824990",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jd1 Qd2 5d3 5h4",
            "rows": "Ad0 Js2 7s3/3h1 4c1 Ks2 3d4 Qh4/6h0 7c0 8c0 9h0 Td3",
            "playerId": "pid3824990"
        },
        {
            "inFantasy": false,
            "playerName": "pid3744876",
            "orderIndex": 1,
            "hero": false,
            "dead": "2h1 7h2 Tc3 2d4",
            "rows": "Kc0 3c1 2s4/5s0 6s0 4h1 6c2 5c4/Th0 Jc0 Qs2 8s3 9c3",
            "playerId": "pid3744876"
        },
        {
            "inFantasy": false,
            "playerName": "pid3129150",
            "orderIndex": 2,
            "hero": true,
            "dead": "Kh1 4s2 2c3 Ah4",
            "rows": "Ac0 As2 Ts4/9s0 9d1 Qc1 8h2 8d3/6d0 7d0 Kd0 4d3 3s4",
            "playerId": "pid3129150"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 22:35:47",
    "roomId": "6861740"
}


{
    "stakes": 10,
    "handData": {"200528045612-6861740-0000018-1": [
        {
            "inFantasy": false,
            "playerName": "pid3824990",
            "orderIndex": 2,
            "hero": false,
            "dead": "4h1 Qs2 5d3 3h4",
            "rows": "Ac2 7c3 7s4/6h0 6s0 2s1 2c3 9s4/3c0 Jh0 Js0 3s1 Jc2",
            "playerId": "pid3824990"
        },
        {
            "inFantasy": false,
            "playerName": "pid3744876",
            "orderIndex": 0,
            "hero": false,
            "dead": "2h1 Qc2 Kc3 Ah4",
            "rows": "Ks1 Kd2 8s3/4s0 Qh0 5s1 5c2 8d4/Td0 Tc0 Ts0 7h3 Ad4",
            "playerId": "pid3744876"
        },
        {
            "inFantasy": false,
            "playerName": "pid3129150",
            "orderIndex": 1,
            "hero": true,
            "dead": "6c1 Th2 4c3 2d4",
            "rows": "Kh0 As2 9h4/8h1 9c1 8c3 9d3 5h4/3d0 4d0 6d0 Qd0 Jd2",
            "playerId": "pid3129150"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 22:38:06",
    "roomId": "6861740"
}


{
    "stakes": 10,
    "handData": {"200528045612-6861740-0000019-1": [
        {
            "inFantasy": false,
            "playerName": "pid3824990",
            "orderIndex": 1,
            "hero": false,
            "dead": "3c1 Js2 2h3 7c4",
            "rows": "As1 5c3 9c4/9s0 4h1 9d2 4s3 8c4/5d0 7d0 8d0 Qd0 2d2",
            "playerId": "pid3824990"
        },
        {
            "inFantasy": false,
            "playerName": "pid3744876",
            "orderIndex": 2,
            "hero": false,
            "dead": "9h1 Th2 Ad3 2s4",
            "rows": "Qs0 Kd0 Ks1/Ac0 2c1 Ah2 8s3 5s4/Jd0 Jc0 7h2 6h3 6d4",
            "playerId": "pid3744876"
        },
        {
            "inFantasy": false,
            "playerName": "pid3129150",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jh1 7s2 4d3 6s4",
            "rows": "Kh1 8h3 4c4/Qc0 Tc1 6c2 Qh2 Td3/3h0 3d0 3s0 5h0 Ts4",
            "playerId": "pid3129150"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 22:39:56",
    "roomId": "6861740"
}


{
    "stakes": 10,
    "handData": {"200528045612-6861740-0000020-1": [
        {
            "inFantasy": false,
            "playerName": "pid3824990",
            "orderIndex": 0,
            "hero": false,
            "dead": "7h1 As2 5h3 4c4",
            "rows": "Kd0 Kc1 5d2/2h0 3s0 2d1 4d2 3h3/9c0 Ts0 9d3 Th4 Ad4",
            "playerId": "pid3824990"
        },
        {
            "inFantasy": true,
            "playerName": "pid3744876",
            "orderIndex": 1,
            "hero": false,
            "dead": "4s0 7d1",
            "rows": "6h0 6d0 6s0/8h0 8d0 8s0 9s0 Jd0/4h0 9h0 Jh0 Qh0 Kh0",
            "playerId": "pid3744876"
        },
        {
            "inFantasy": false,
            "playerName": "pid3129150",
            "orderIndex": 2,
            "hero": true,
            "dead": "Qd1 Td2 Qc3 2c4",
            "rows": "Ks0 5c4 Tc4/2s0 5s2 Js2 Ah3 Ac3/7c0 8c0 Jc0 3c1 6c1",
            "playerId": "pid3129150"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 22:41:56",
    "roomId": "6861740"
}


{
    "stakes": 10,
    "handData": {"200528045612-6861740-0000021-1": [
        {
            "inFantasy": true,
            "playerName": "pid3824990",
            "orderIndex": 2,
            "hero": false,
            "dead": "4c0 2d1",
            "rows": "Td0 Tc0 Qd0/7h0 7d0 8c0 9h0 9c0/5s0 6s0 Js0 Ks0 As0",
            "playerId": "pid3824990"
        },
        {
            "inFantasy": true,
            "playerName": "pid3744876",
            "orderIndex": 0,
            "hero": false,
            "dead": "9d0 2h1",
            "rows": "Ts0 Ah0 Ad0/2c0 3c0 6c0 7c0 Jc0/3h0 8h0 Jh0 Qh0 Kh0",
            "playerId": "pid3744876"
        },
        {
            "inFantasy": false,
            "playerName": "pid3129150",
            "orderIndex": 1,
            "hero": true,
            "dead": "2s1 Kc2 7s3 6d4",
            "rows": "Kd2 9s3 Ac4/4h0 8d0 3s1 4s2 3d3/5h0 5d0 Qc0 Qs1 Jd4",
            "playerId": "pid3129150"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 22:43:30",
    "roomId": "6861740"
}


