{
    "stakes": 4,
    "handData": {"200528041105-6858464-0000000-1": [
        {
            "inFantasy": false,
            "playerName": "pid2918116",
            "orderIndex": 1,
            "hero": false,
            "dead": "2c1 6s2 Ad3 7d4",
            "rows": "As0 Ah2 4s3/9s0 Qd0 5s2 Qc3 6h4/Jc0 Kc0 Kh1 Kd1 2h4",
            "playerId": "pid2918116"
        },
        {
            "inFantasy": false,
            "playerName": "pid3999663",
            "orderIndex": 0,
            "hero": true,
            "dead": "Js1 Qs2 9d3 5h4",
            "rows": "Ac0 Ks1 9h4/2d0 2s0 3d0 3c2 4h3/8c0 6d1 8h2 6c3 3h4",
            "playerId": "pid3999663"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 21:22:38",
    "roomId": "6858464"
}


{
    "stakes": 4,
    "handData": {"200528041105-6858464-0000001-1": [
        {
            "inFantasy": false,
            "playerName": "pid2918116",
            "orderIndex": 0,
            "hero": false,
            "dead": "5s1 2d2 2s3 8d4",
            "rows": "Kh1 Qs2 5h4/7d0 9h0 8s2 Ad3 Ac3/Tc0 Ts0 Js0 Td1 Jc4",
            "playerId": "pid2918116"
        },
        {
            "inFantasy": false,
            "playerName": "pid3280840",
            "orderIndex": 1,
            "hero": false,
            "dead": "7h1 3d2 Kc3 4d4",
            "rows": "Ks0 Kd2 9s3/3h0 3s1 6s1 Qh3 8h4/6h0 7c0 9d0 8c2 4h4",
            "playerId": "pid3280840"
        },
        {
            "inFantasy": false,
            "playerName": "pid3999663",
            "orderIndex": 2,
            "hero": true,
            "dead": "2c1 2h2 Jh3 3c4",
            "rows": "Ah0 5d3 6c3/4s0 5c0 6d2 7s2 As4/Th0 Jd0 9c1 Qc1 Qd4",
            "playerId": "pid3999663"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 21:24:38",
    "roomId": "6858464"
}


{
    "stakes": 4,
    "handData": {"200528041105-6858464-0000002-1": [
        {
            "inFantasy": false,
            "playerName": "pid2918116",
            "orderIndex": 2,
            "hero": false,
            "dead": "Jh1 2c2 6s3 2d4",
            "rows": "Qh0 Ks1 Kc2/5c0 5d1 7d2 Jd3 Js3/3h0 3d0 9s0 7h4 Kh4",
            "playerId": "pid2918116"
        },
        {
            "inFantasy": false,
            "playerName": "pid3280840",
            "orderIndex": 0,
            "hero": false,
            "dead": "Ac1 4c2 8d3 4d4",
            "rows": "9c3 9h4 Tc4/5s0 6h0 6c1 5h2 3s3/6d0 Qd0 Kd0 9d1 Td2",
            "playerId": "pid3280840"
        },
        {
            "inFantasy": false,
            "playerName": "pid3999663",
            "orderIndex": 1,
            "hero": true,
            "dead": "Th1 Ah2 3c3 Ts4",
            "rows": "Qs0 Qc1 Ad4/4h0 2s1 4s2 Jc3 2h4/8h0 8c0 8s0 7s2 7c3",
            "playerId": "pid3999663"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 21:26:36",
    "roomId": "6858464"
}


{
    "stakes": 4,
    "handData": {"200528041105-6858464-0000003-1": [
        {
            "inFantasy": false,
            "playerName": "pid2918116",
            "orderIndex": 1,
            "hero": false,
            "dead": "8d1 5d2 2c3 Qd4",
            "rows": "Kd0 Kh2 5h4/4s0 6d0 6c1 Ts2 9d4/Jc0 Qh0 Js1 9c3 9s3",
            "playerId": "pid2918116"
        },
        {
            "inFantasy": false,
            "playerName": "pid3280840",
            "orderIndex": 2,
            "hero": false,
            "dead": "Tc1 Qc2 7d3 3d4",
            "rows": "Ks0 Kc2 Td3/4d0 5s0 6h1 6s1 3s4/8c0 9h0 As2 Qs3 8s4",
            "playerId": "pid3280840"
        },
        {
            "inFantasy": true,
            "playerName": "pid3999663",
            "orderIndex": 0,
            "hero": true,
            "dead": "3c0",
            "rows": "5c0 Jd0 Ac0/3h0 4h0 8h0 Th0 Ah0/2d0 2s0 7h0 7c0 7s0",
            "playerId": "pid3999663"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 21:28:13",
    "roomId": "6858464"
}


{
    "stakes": 4,
    "handData": {"200528041105-6858464-0000004-1": [
        {
            "inFantasy": false,
            "playerName": "pid3280840",
            "orderIndex": 0,
            "hero": false,
            "dead": "7d1 Kd2 5s3 4h4",
            "rows": "Ks0 5h2 7h2/4c0 2s1 6s1 Kh3 6d4/9h0 9s0 Th0 3h3 Ah4",
            "playerId": "pid3280840"
        },
        {
            "inFantasy": false,
            "playerName": "pid3999663",
            "orderIndex": 1,
            "hero": true,
            "dead": "9d1 3d2 4s3 As4",
            "rows": "Kc2 Qc3 6c4/2c0 5d0 5c1 8d1 8s2/7c0 7s0 Jh0 Td3 4d4",
            "playerId": "pid3999663"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 21:29:46",
    "roomId": "6858464"
}


{
    "stakes": 4,
    "handData": {"200528041105-6858464-0000005-1": [
        {
            "inFantasy": false,
            "playerName": "pid2119179",
            "orderIndex": 1,
            "hero": false,
            "dead": "4h1 Qs2 3d3 9s4",
            "rows": "Kh0 Kc1 4s3/Js1 8h2 8s2 7d3 Jh4/2c0 4c0 7c0 8c0 3c4",
            "playerId": "pid2119179"
        },
        {
            "inFantasy": false,
            "playerName": "pid3280840",
            "orderIndex": 2,
            "hero": false,
            "dead": "Ts1 Jd2 2h3 6d4",
            "rows": "Ks0 Ad2 As4/4d1 5s1 5h3 Qh3 Qd4/6c0 7h0 8d0 Th0 9c2",
            "playerId": "pid3280840"
        },
        {
            "inFantasy": false,
            "playerName": "pid3999663",
            "orderIndex": 0,
            "hero": true,
            "dead": "7s1 5c2 5d3 Td4",
            "rows": "Ah0 Ac1 9d4/3h0 3s0 2s1 6s2 6h3/Tc0 Jc0 Kd2 Qc3 9h4",
            "playerId": "pid3999663"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 21:31:02",
    "roomId": "6858464"
}


{
    "stakes": 4,
    "handData": {"200528041105-6858464-0000006-1": [
        {
            "inFantasy": true,
            "playerName": "pid2119179",
            "orderIndex": 0,
            "hero": false,
            "dead": "5c0 2d1",
            "rows": "9h0 9d0 Ah0/3c0 3s0 6h0 7d0 7c0/Tc0 Kh0 Kd0 Kc0 Ks0",
            "playerId": "pid2119179"
        },
        {
            "inFantasy": true,
            "playerName": "pid3280840",
            "orderIndex": 1,
            "hero": false,
            "dead": "4d0 3d1 4c2",
            "rows": "8c0 Qd0 Qc0/2h0 3h0 5h0 7h0 Jh0/2s0 5s0 6s0 9s0 Js0",
            "playerId": "pid3280840"
        },
        {
            "inFantasy": true,
            "playerName": "pid3999663",
            "orderIndex": 2,
            "hero": true,
            "dead": "2c0 6c0 4s0",
            "rows": "8d0 Ad0 Ac0/4h0 5d0 6d0 7s0 8h0/Th0 Td0 Ts0 Jd0 Jc0",
            "playerId": "pid3999663"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 21:31:55",
    "roomId": "6858464"
}


{
    "stakes": 4,
    "handData": {"200528041105-6858464-0000007-1": [
        {
            "inFantasy": true,
            "playerName": "pid2119179",
            "orderIndex": 2,
            "hero": false,
            "dead": "5d0 4c1",
            "rows": "Qd0 Ad0 As0/3h0 3c0 9c0 Kd0 Kc0/2s0 3s0 4s0 8s0 Ts0",
            "playerId": "pid2119179"
        },
        {
            "inFantasy": false,
            "playerName": "pid3280840",
            "orderIndex": 0,
            "hero": false,
            "dead": "8c1 Jd2 8h3 Jh4",
            "rows": "Kh2 Tc3 Jc4/2h0 6h0 6c0 4h1 4d3/7d0 9d0 7h1 7s2 9s4",
            "playerId": "pid3280840"
        },
        {
            "inFantasy": false,
            "playerName": "pid3999663",
            "orderIndex": 1,
            "hero": true,
            "dead": "7c1 8d2 Ks3 Qc4",
            "rows": "Ac0 Ah2 Th4/Td1 Qs1 Js2 6s3 2d4/2c0 3d0 5s0 6d0 5h3",
            "playerId": "pid3999663"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 21:33:26",
    "roomId": "6858464"
}


