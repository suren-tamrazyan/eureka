{
    "stakes": 5,
    "handData": {"200528024029-6851785-0000000-1": [
        {
            "inFantasy": false,
            "playerName": "pid2918116",
            "orderIndex": 1,
            "hero": false,
            "dead": "9c1 8h2 3s3 4s4",
            "rows": "Kc0 Kh2 Ts4/2c0 Tc2 2h3 6s3 Td4/6h0 7h0 Qh0 Qd1 Qs1",
            "playerId": "pid2918116"
        },
        {
            "inFantasy": false,
            "playerName": "pid3654459",
            "orderIndex": 0,
            "hero": true,
            "dead": "Js1 4d2 2d3 4c4",
            "rows": "Jh1 Th2 7s3/5c0 8c0 Qc2 8s3 Kd4/3d0 9h0 9s0 3h1 9d4",
            "playerId": "pid3654459"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 21:18:59",
    "roomId": "6851785"
}


{
    "stakes": 5,
    "handData": {"200528024029-6851785-0000001-1": [
        {
            "inFantasy": true,
            "playerName": "pid2918116",
            "orderIndex": 0,
            "hero": false,
            "dead": "4s0 As1",
            "rows": "9c0 Ts0 Jc0/7h0 8h0 9h0 Th0 Qh0/5d0 8d0 9d0 Jd0 Kd0",
            "playerId": "pid2918116"
        },
        {
            "inFantasy": false,
            "playerName": "pid3654459",
            "orderIndex": 1,
            "hero": true,
            "dead": "2s1 7d2 2d3 8c4",
            "rows": "Kc2 Tc3 Ah3/2c0 3d0 3c0 4d1 4c1/5s0 9s0 Js2 6c4 7c4",
            "playerId": "pid3654459"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 21:20:07",
    "roomId": "6851785"
}


