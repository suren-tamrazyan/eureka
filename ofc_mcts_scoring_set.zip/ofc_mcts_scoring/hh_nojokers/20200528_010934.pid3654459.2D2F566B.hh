{
    "stakes": 5,
    "handData": {"200528054448-6865599-0000000-1": [
        {
            "inFantasy": false,
            "playerName": "pid3317301",
            "orderIndex": 1,
            "hero": false,
            "dead": "9c1 8s2 4d3 4c4",
            "rows": "Kd0 3h3 3c3/6s0 7h0 5d1 7d2 As4/2h0 2c0 Jc1 Js2 Qs4",
            "playerId": "pid3317301"
        },
        {
            "inFantasy": false,
            "playerName": "pid3654459",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qc1 Jh2 Td3 2s4",
            "rows": "Ad0 Kc1 Ah4/2d0 3s0 9d2 3d3 9h3/7c0 8h0 8d1 8c2 Tc4",
            "playerId": "pid3654459"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:09:34",
    "roomId": "6865599"
}


{
    "stakes": 5,
    "handData": {"200528054448-6865599-0000001-1": [
        {
            "inFantasy": false,
            "playerName": "pid3317301",
            "orderIndex": 0,
            "hero": false,
            "dead": "Ts1 3c2 Jc3 Ks4",
            "rows": "Kh0 Ah3 Kd4/2h0 3s0 4c1 4d2 3h4/6h0 9s0 9d1 6d2 7h3",
            "playerId": "pid3317301"
        },
        {
            "inFantasy": true,
            "playerName": "pid3654459",
            "orderIndex": 1,
            "hero": true,
            "dead": "5s0 4s0 4h0",
            "rows": "Jd0 Js0 Qs0/2c0 5c0 8c0 9c0 Kc0/2d0 3d0 5d0 7d0 Ad0",
            "playerId": "pid3654459"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:10:34",
    "roomId": "6865599"
}


{
    "stakes": 5,
    "handData": {"200528054448-6865599-0000002-1": [
        {
            "inFantasy": true,
            "playerName": "pid3317301",
            "orderIndex": 1,
            "hero": false,
            "dead": "3s0 6c1",
            "rows": "Kh0 Kc0 Ad0/2c0 2s0 8d0 Jd0 Js0/5h0 6s0 7d0 8h0 9c0",
            "playerId": "pid3317301"
        },
        {
            "inFantasy": false,
            "playerName": "pid3654459",
            "orderIndex": 0,
            "hero": true,
            "dead": "8s1 4s2 2d3 Ah4",
            "rows": "9d2 Qc2 Qh3/6h0 9s0 9h1 Tc1 5s4/5d0 5c0 Jc0 7h3 3c4",
            "playerId": "pid3654459"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:11:29",
    "roomId": "6865599"
}


{
    "stakes": 5,
    "handData": {"200528054448-6865599-0000003-1": [
        {
            "inFantasy": false,
            "playerName": "pid3317301",
            "orderIndex": 0,
            "hero": false,
            "dead": "5h1 Ts2 4h3 4s4",
            "rows": "Qd0 7s4 Qh4/Js0 Td1 Ks1 Kc2 Jd3/2c0 7c0 9c0 3c2 Ac3",
            "playerId": "pid3317301"
        },
        {
            "inFantasy": false,
            "playerName": "pid3654459",
            "orderIndex": 1,
            "hero": true,
            "dead": "8d1 5c2 7d3 4d4",
            "rows": "Qc0 As3 Jh4/5s0 6d0 5d1 6c2 4c3/3h0 Kh0 3d1 9h2 9d4",
            "playerId": "pid3654459"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:12:58",
    "roomId": "6865599"
}


{
    "stakes": 5,
    "handData": {"200528054448-6865599-0000004-1": [
        {
            "inFantasy": true,
            "playerName": "pid3317301",
            "orderIndex": 1,
            "hero": false,
            "dead": "3c0",
            "rows": "2h0 2c0 Th0/4d0 5d0 8d0 9d0 Jd0/9c0 Kh0 Kd0 Kc0 Ks0",
            "playerId": "pid3317301"
        },
        {
            "inFantasy": false,
            "playerName": "pid3654459",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qh1 4c2 3s3 Tc4",
            "rows": "Ad0 Qd2 3d3/8h0 9s0 6s1 6d3 8c4/Jh0 Js0 2d1 Td2 Jc4",
            "playerId": "pid3654459"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:13:44",
    "roomId": "6865599"
}


{
    "stakes": 5,
    "handData": {"200528054448-6865599-0000005-1": [
        {
            "inFantasy": true,
            "playerName": "pid3317301",
            "orderIndex": 0,
            "hero": false,
            "dead": "2s0",
            "rows": "Jh0 Qd0 Qc0/5s0 7d0 7s0 9d0 9c0/2h0 3d0 4d0 5c0 Ah0",
            "playerId": "pid3317301"
        },
        {
            "inFantasy": false,
            "playerName": "pid3654459",
            "orderIndex": 1,
            "hero": true,
            "dead": "2d1 7c2 Kc3 3c4",
            "rows": "Kd0 7h2 8d4/4c0 Tc0 5d1 Ad2 Td3/9s0 Js0 6s1 Qs3 4s4",
            "playerId": "pid3654459"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:14:39",
    "roomId": "6865599"
}


{
    "stakes": 5,
    "handData": {"200528054448-6865599-0000006-1": [
        {
            "inFantasy": false,
            "playerName": "pid2092229",
            "orderIndex": 1,
            "hero": false,
            "dead": "2s1 4d2 Ad3 Td4",
            "rows": "As1 7c3 9s3/5h0 9h0 Tc1 8h2 8c2/6c0 6s0 Qc0 4h4 6h4",
            "playerId": "pid2092229"
        },
        {
            "inFantasy": false,
            "playerName": "pid3317301",
            "orderIndex": 2,
            "hero": false,
            "dead": "3h1 6d2 Ts3 3d4",
            "rows": "Ac0 5s1 Ah2/4c0 9d0 7h1 4s2 9c4/Jh0 Qs0 Qh3 Qd3 5d4",
            "playerId": "pid3317301"
        },
        {
            "inFantasy": false,
            "playerName": "pid3654459",
            "orderIndex": 0,
            "hero": true,
            "dead": "5c1 Kc2 Ks3 2h4",
            "rows": "Kh1 Kd2 7s4/2d0 8s0 2c1 7d3 8d4/3c0 3s0 Th0 Js2 Jd3",
            "playerId": "pid3654459"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:15:43",
    "roomId": "6865599"
}


{
    "stakes": 5,
    "handData": {"200528054448-6865599-0000007-1": [
        {
            "inFantasy": false,
            "playerName": "pid2092229",
            "orderIndex": 0,
            "hero": false,
            "dead": "9d1 Kc2 3d3 5s4",
            "rows": "Qd3 Ah3 Kh4/3c0 8s0 7d1 7s1 8d2/6d0 6c0 Jd0 6s2 7c4",
            "playerId": "pid2092229"
        },
        {
            "inFantasy": true,
            "playerName": "pid3317301",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qh0 9h1 3h2",
            "rows": "Td0 Tc0 Ts0/2c0 4c0 5c0 Qc0 Ac0/3s0 4s0 9s0 Ks0 As0",
            "playerId": "pid3317301"
        },
        {
            "inFantasy": true,
            "playerName": "pid3654459",
            "orderIndex": 2,
            "hero": true,
            "dead": "7h0 5d0",
            "rows": "Th0 Qs0 Ad0/2h0 2d0 2s0 4h0 4d0/8h0 8c0 Jh0 Jc0 Js0",
            "playerId": "pid3654459"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:16:40",
    "roomId": "6865599"
}


{
    "stakes": 5,
    "handData": {"200528054448-6865599-0000008-1": [
        {
            "inFantasy": true,
            "playerName": "pid3317301",
            "orderIndex": 1,
            "hero": false,
            "dead": "6c0",
            "rows": "Td0 Qd0 Ac0/4h0 4s0 7h0 9d0 9s0/2h0 2s0 5h0 5d0 5s0",
            "playerId": "pid3317301"
        },
        {
            "inFantasy": false,
            "playerName": "pid3654459",
            "orderIndex": 0,
            "hero": true,
            "dead": "7c1 9c2 5c3 4d4",
            "rows": "Kd0 Ks1 3s4/9h0 Ah0 Th3 Kc3 2d4/6s0 Qs0 Qc1 8h2 8d2",
            "playerId": "pid3654459"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:17:28",
    "roomId": "6865599"
}


{
    "stakes": 5,
    "handData": {"200528054448-6865599-0000009-1": [
        {
            "inFantasy": false,
            "playerName": "pid2092229",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jd1 Qc2 3h3 Kh4",
            "rows": "Kd0 6h3 Td3/7h0 8d0 Ah1 8h2 9h4/Ts0 Qs0 3s1 As2 Tc4",
            "playerId": "pid2092229"
        },
        {
            "inFantasy": false,
            "playerName": "pid3654459",
            "orderIndex": 1,
            "hero": true,
            "dead": "Ac1 3c2 5d3 Th4",
            "rows": "Qh0 6d3 Ad3/4s0 7c1 7s1 5c2 5s2/2h0 2c0 Jc0 4h4 9d4",
            "playerId": "pid3654459"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:18:52",
    "roomId": "6865599"
}


{
    "stakes": 5,
    "handData": {"200528054448-6865599-0000010-1": [
        {
            "inFantasy": false,
            "playerName": "pid2092229",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qs1 9h2 7h3 Ac4",
            "rows": "Ah0 Td3 Qh4/2c0 3c0 5s1 5h2 8s4/4d0 7d0 4h1 4c2 7c3",
            "playerId": "pid2092229"
        },
        {
            "inFantasy": false,
            "playerName": "pid3654459",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qd1 3d2 8h3 9c4",
            "rows": "Kh0 Kc3 8d4/8c0 Jd1 Jh2 Js2 Ts4/3s0 4s0 6s0 2s1 9s3",
            "playerId": "pid3654459"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:19:48",
    "roomId": "6865599"
}


{
    "stakes": 5,
    "handData": {"200528054448-6865599-0000011-1": [
        {
            "inFantasy": false,
            "playerName": "pid2092229",
            "orderIndex": 0,
            "hero": false,
            "dead": "5c1 As2 Js3 2h4",
            "rows": "Kh1 Kc2 5s4/3s0 Qd1 Th3 Tc3 4c4/5h0 6c0 8d0 9d0 7s2",
            "playerId": "pid2092229"
        },
        {
            "inFantasy": true,
            "playerName": "pid3654459",
            "orderIndex": 1,
            "hero": true,
            "dead": "3c0 5d0",
            "rows": "Qs0 Ah0 Ad0/2c0 2s0 4h0 4s0 8h0/7d0 8s0 9c0 Td0 Jc0",
            "playerId": "pid3654459"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:20:41",
    "roomId": "6865599"
}


{
    "stakes": 5,
    "handData": {"200528054448-6865599-0000012-1": [
        {
            "inFantasy": false,
            "playerName": "pid2092229",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qh1 2c2 2d3 7d4",
            "rows": "Ac1 Qc3 Kh3/6h0 8d0 7c2 9c2 8h4/3c0 Jh0 Jd0 Js1 Kc4",
            "playerId": "pid2092229"
        },
        {
            "inFantasy": false,
            "playerName": "pid3654459",
            "orderIndex": 0,
            "hero": true,
            "dead": "5c1 Jc2 9d3 4s4",
            "rows": "Ah1 5h3 8s3/6c0 2s2 7s2 7h4 Kd4/3s0 5s0 9s0 Ts0 Ks1",
            "playerId": "pid3654459"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:21:35",
    "roomId": "6865599"
}


{
    "stakes": 5,
    "handData": {"200528054448-6865599-0000013-1": [
        {
            "inFantasy": false,
            "playerName": "pid2092229",
            "orderIndex": 0,
            "hero": false,
            "dead": "3d1 Ac2 Ts3 5h4",
            "rows": "Kd0 Kh2 Td4/6h0 Jc0 2c1 Js2 3s4/7s0 Qs0 Qd1 9h3 9c3",
            "playerId": "pid2092229"
        },
        {
            "inFantasy": false,
            "playerName": "pid3654459",
            "orderIndex": 1,
            "hero": true,
            "dead": "Ks1 7c2 Qc3 Ad4",
            "rows": "As0 7h2 4c4/3c0 4s0 8s1 Th3 8h4/5d0 9d0 6d1 Jd2 7d3",
            "playerId": "pid3654459"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:23:13",
    "roomId": "6865599"
}


{
    "stakes": 5,
    "handData": {"200528054448-6865599-0000014-1": [
        {
            "inFantasy": false,
            "playerName": "pid132095",
            "orderIndex": 0,
            "hero": false,
            "dead": "8s1 8c2 7c3 Ks4",
            "rows": "Kc0 Ah1 Ad3/4s0 Jh0 4h2 5h2 9d4/Td0 Qd0 Tc1 Qh3 9h4",
            "playerId": "pid132095"
        },
        {
            "inFantasy": false,
            "playerName": "pid3654459",
            "orderIndex": 1,
            "hero": true,
            "dead": "2d1 2c2 3d3 Jd4",
            "rows": "Kd0 3c2 Th4/4c0 7h0 8h2 5s3 6h3/3s0 Qs0 7s1 9s1 6c4",
            "playerId": "pid3654459"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:24:51",
    "roomId": "6865599"
}


{
    "stakes": 5,
    "handData": {"200528054448-6865599-0000015-1": [
        {
            "inFantasy": false,
            "playerName": "pid132095",
            "orderIndex": 1,
            "hero": false,
            "dead": "4d1 7d2 4c3 3d4",
            "rows": "As0 Ac1 Jh3/2c0 5d0 2d2 8s3 2s4/9c0 Qs0 Qd1 9s2 Js4",
            "playerId": "pid132095"
        },
        {
            "inFantasy": false,
            "playerName": "pid3654459",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ks1 5s2 8h3 9h4",
            "rows": "Ad0 7s2 Qh4/4s0 6h0 6s1 3h2 3s3/Th0 Jd0 Jc1 Ts3 Td4",
            "playerId": "pid3654459"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:26:02",
    "roomId": "6865599"
}


{
    "stakes": 5,
    "handData": {"200528054448-6865599-0000016-1": [
        {
            "inFantasy": false,
            "playerName": "pid132095",
            "orderIndex": 0,
            "hero": false,
            "dead": "Tc1 4h2 4c3 Th4",
            "rows": "Kd2 5h3 Td3/3h0 7c0 7h1 2d2 Kc4/4s0 6s0 Qs0 5s1 Jc4",
            "playerId": "pid132095"
        },
        {
            "inFantasy": false,
            "playerName": "pid3654459",
            "orderIndex": 1,
            "hero": true,
            "dead": "8d1 7s2 8h3 7d4",
            "rows": "Ts1 9d3 9s4/4d0 6h0 Jh1 Ah3 Ad4/2c0 3c0 8c0 3s2 8s2",
            "playerId": "pid3654459"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:27:49",
    "roomId": "6865599"
}


{
    "stakes": 5,
    "handData": {"200528054448-6865599-0000017-1": [
        {
            "inFantasy": false,
            "playerName": "pid132095",
            "orderIndex": 1,
            "hero": false,
            "dead": "Th1 3s2 3h3 As4",
            "rows": "Ah0 Ad0 Tc2/4h0 7d0 2s1 4s4 Kd4/Kc0 8d1 6s2 9s3 Kh3",
            "playerId": "pid132095"
        },
        {
            "inFantasy": false,
            "playerName": "pid3654459",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qc1 Js2 2h3 Qh4",
            "rows": "Jd3 5c4 5s4/5h0 3c1 4d1 6h2 7s2/9c0 Td0 Jc0 Qs0 8c3",
            "playerId": "pid3654459"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:28:53",
    "roomId": "6865599"
}


{
    "stakes": 5,
    "handData": {"200528054448-6865599-0000018-1": [
        {
            "inFantasy": false,
            "playerName": "pid2092229",
            "orderIndex": 0,
            "hero": false,
            "dead": "9h1 9s2 4s3 Qd4",
            "rows": "Kh0 Jc3 Kc3/Ah0 2h2 5s2 2c4 Td4/8s0 9d0 Tc0 8d1 8c1",
            "playerId": "pid2092229"
        },
        {
            "inFantasy": false,
            "playerName": "pid132095",
            "orderIndex": 1,
            "hero": false,
            "dead": "Th1 2s2 8h3 3d4",
            "rows": "4d3 4c3 Qh4/6c0 7d0 3h1 4h2 5h2/Js0 Qs0 Ks0 As1 Ad4",
            "playerId": "pid132095"
        },
        {
            "inFantasy": false,
            "playerName": "pid3654459",
            "orderIndex": 2,
            "hero": true,
            "dead": "Ts1 3c2 7h3 5d4",
            "rows": "Jh3 Jd3 7s4/3s0 6d0 2d1 6s2 6h4/5c0 7c0 Qc0 Ac1 9c2",
            "playerId": "pid3654459"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:30:52",
    "roomId": "6865599"
}


{
    "stakes": 5,
    "handData": {"200528054448-6865599-0000019-1": [
        {
            "inFantasy": false,
            "playerName": "pid2092229",
            "orderIndex": 2,
            "hero": false,
            "dead": "5h1 Ks2 5d3 6d4",
            "rows": "Ah0 Kh2 As3/2c0 4s1 4c2 Js3 4d4/8c0 Th0 Qd0 Jd1 8s4",
            "playerId": "pid2092229"
        },
        {
            "inFantasy": false,
            "playerName": "pid132095",
            "orderIndex": 0,
            "hero": false,
            "dead": "9h1 Jh2 2h3 Qh4",
            "rows": "Kd0 Kc2 9c3/3h0 6c1 8d1 6h2 3c4/Td0 Ts0 Qs0 7s3 Tc4",
            "playerId": "pid132095"
        },
        {
            "inFantasy": false,
            "playerName": "pid3654459",
            "orderIndex": 1,
            "hero": true,
            "dead": "5c1 8h2 4h3 7c4",
            "rows": "Qc0 Ad1 6s4/2d0 3s0 2s1 3d2 Jc3/7d0 9s0 5s2 9d3 7h4",
            "playerId": "pid3654459"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:32:54",
    "roomId": "6865599"
}


{
    "stakes": 5,
    "handData": {"200528054448-6865599-0000020-1": [
        {
            "inFantasy": false,
            "playerName": "pid2092229",
            "orderIndex": 1,
            "hero": false,
            "dead": "5h1 5c2 3c3 3h4",
            "rows": "Ad0 As0 8c3/2h0 4d0 2s1 Jc2 Ac4/Qs0 Qd1 Kh2 Qh3 9c4",
            "playerId": "pid2092229"
        },
        {
            "inFantasy": true,
            "playerName": "pid132095",
            "orderIndex": 2,
            "hero": false,
            "dead": "3s0 6c1",
            "rows": "Jh0 Js0 Kc0/6s0 7c0 8h0 9s0 Td0/3d0 6d0 7d0 9d0 Jd0",
            "playerId": "pid132095"
        },
        {
            "inFantasy": false,
            "playerName": "pid3654459",
            "orderIndex": 0,
            "hero": true,
            "dead": "Th1 4c2 4s3 6h4",
            "rows": "Qc0 9h2 Tc3/2d0 4h0 Ah1 5d3 5s4/7s0 8s0 8d1 7h2 Ks4",
            "playerId": "pid3654459"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:33:53",
    "roomId": "6865599"
}


{
    "stakes": 5,
    "handData": {"200528054448-6865599-0000021-1": [
        {
            "inFantasy": false,
            "playerName": "pid132095",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jc1 4c2 3c3 3s4",
            "rows": "5c2 9c2 Ah3/2c0 2s0 8h0 Td1 5h3/4s0 7s0 Qs1 4d4 7h4",
            "playerId": "pid132095"
        },
        {
            "inFantasy": false,
            "playerName": "pid3654459",
            "orderIndex": 1,
            "hero": true,
            "dead": "2h1 6c2 3h3 5d4",
            "rows": "8c1 Ts4 Kc4/4h0 6d0 6s0 7c1 7d3/Jd0 Qd0 Th2 Kh2 9d3",
            "playerId": "pid3654459"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:36:01",
    "roomId": "6865599"
}


{
    "stakes": 5,
    "handData": {"200528054448-6865599-0000022-1": [
        {
            "inFantasy": false,
            "playerName": "pid132095",
            "orderIndex": 1,
            "hero": false,
            "dead": "4h1 7h2 7c3 5c4",
            "rows": "Ks2 4d3 4c4/Qh0 Qs0 2d1 Jc3 9c4/5s0 6s0 7s0 9s1 8s2",
            "playerId": "pid132095"
        },
        {
            "inFantasy": false,
            "playerName": "pid3654459",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ts1 2s2 9d3 Td4",
            "rows": "Kc0 Kd2 Qd3/3s0 Ah0 6d3 2c4 3c4/8c0 9h0 7d1 Th1 Jd2",
            "playerId": "pid3654459"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:37:32",
    "roomId": "6865599"
}


{
    "stakes": 5,
    "handData": {"200528054448-6865599-0000023-1": [
        {
            "inFantasy": false,
            "playerName": "pid132095",
            "orderIndex": 0,
            "hero": false,
            "dead": "7h1 9d2 2c3 Ks4",
            "rows": "Kd0 Kc1 7c4/3h0 4h0 6s2 4s3 6h3/Td0 Tc0 Jc1 Ts2 Jd4",
            "playerId": "pid132095"
        },
        {
            "inFantasy": false,
            "playerName": "pid3654459",
            "orderIndex": 1,
            "hero": true,
            "dead": "3d1 Ad2 3c3 2h4",
            "rows": "5h2 9c2 2d3/5d0 8c0 9h0 6d1 Qh3/3s0 7s0 Qs1 8d4 9s4",
            "playerId": "pid3654459"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:39:23",
    "roomId": "6865599"
}


{
    "stakes": 5,
    "handData": {"200528054448-6865599-0000024-1": [
        {
            "inFantasy": true,
            "playerName": "pid132095",
            "orderIndex": 1,
            "hero": false,
            "dead": "5c0 2s1",
            "rows": "9d0 Td0 Tc0/6c0 7c0 9c0 Jc0 Qc0/2h0 6h0 Jh0 Qh0 Kh0",
            "playerId": "pid132095"
        },
        {
            "inFantasy": false,
            "playerName": "pid3654459",
            "orderIndex": 0,
            "hero": true,
            "dead": "9h1 4s2 Js3 As4",
            "rows": "Kd0 Kc1 Ks4/3h0 7d0 Ac1 3c2 7h3/Th0 Ts0 6d2 Qd3 5h4",
            "playerId": "pid3654459"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:40:25",
    "roomId": "6865599"
}


