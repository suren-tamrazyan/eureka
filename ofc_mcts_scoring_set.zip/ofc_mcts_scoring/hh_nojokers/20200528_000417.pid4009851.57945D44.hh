{
    "stakes": 2,
    "handData": {"200528025259-6852666-0000000-1": [
        {
            "inFantasy": false,
            "playerName": "pid3841225",
            "orderIndex": 1,
            "hero": false,
            "dead": "5c1 2d2 7s3 Kh4",
            "rows": "As1 Jd3 Jh4/3s0 4d0 3d1 2h2 2c2/6c0 9d0 9s0 6s3 9c4",
            "playerId": "pid3841225"
        },
        {
            "inFantasy": false,
            "playerName": "pid4009851",
            "orderIndex": 0,
            "hero": true,
            "dead": "3h1 4h2 3c3 6d4",
            "rows": "Ad1 Qd3 Qs3/Kd0 Kc0 2s1 4c4 Ah4/5s0 6h0 7d0 8h2 9h2",
            "playerId": "pid4009851"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 21:04:17",
    "roomId": "6852666"
}


{
    "stakes": 2,
    "handData": {"200528025259-6852666-0000001-1": [
        {
            "inFantasy": false,
            "playerName": "pid3841225",
            "orderIndex": 0,
            "hero": false,
            "dead": "6s1 7c2 4c3 Qh4",
            "rows": "Kh0 Kc0 9h3/Ah0 As0 8h2 6h3 Ts4/2d0 3d1 7d1 Ad2 Ks4",
            "playerId": "pid3841225"
        },
        {
            "inFantasy": true,
            "playerName": "pid4009851",
            "orderIndex": 1,
            "hero": true,
            "dead": "4s0",
            "rows": "8d0 8s0 Th0/2c0 3h0 4d0 5h0 6d0/9d0 Tc0 Jh0 Qc0 Kd0",
            "playerId": "pid4009851"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 21:05:20",
    "roomId": "6852666"
}


{
    "stakes": 2,
    "handData": {"200528025259-6852666-0000002-1": [
        {
            "inFantasy": false,
            "playerName": "pid3841225",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jh1 9d2 7h3 3c4",
            "rows": "Kd0 Js3 Tc4/2d0 Th0 4d2 4c3 4h4/9s0 Qs0 3s1 5s1 6s2",
            "playerId": "pid3841225"
        },
        {
            "inFantasy": false,
            "playerName": "pid4009851",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jd1 2c2 Kh3 Ad4",
            "rows": "As0 9h2 5h4/3h0 5d1 6d1 5c2 6c3/8c0 8s0 Td0 4s3 2s4",
            "playerId": "pid4009851"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 21:06:23",
    "roomId": "6852666"
}


{
    "stakes": 2,
    "handData": {"200528025259-6852666-0000003-1": [
        {
            "inFantasy": false,
            "playerName": "pid3841225",
            "orderIndex": 0,
            "hero": false,
            "dead": "5c1 2c2 Js3 4h4",
            "rows": "As0 Qh3 Qs3/6d0 7h0 7d1 6s4 9h4/3s0 Qc0 Tc1 Th2 Td2",
            "playerId": "pid3841225"
        },
        {
            "inFantasy": false,
            "playerName": "pid4009851",
            "orderIndex": 1,
            "hero": true,
            "dead": "2s1 3d2 2d3 8d4",
            "rows": "Ks0 4s2 Qd4/8c0 7s1 9d1 Jd2 Ad3/5h0 6h0 Ah0 Jh3 Kh4",
            "playerId": "pid4009851"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 21:08:05",
    "roomId": "6852666"
}


{
    "stakes": 2,
    "handData": {"200528025259-6852666-0000004-1": [
        {
            "inFantasy": true,
            "playerName": "pid3841225",
            "orderIndex": 1,
            "hero": false,
            "dead": "7c0",
            "rows": "9h0 Qc0 Qs0/3d0 4d0 8d0 Td0 Kd0/6d0 6s0 Jh0 Jd0 Jc0",
            "playerId": "pid3841225"
        },
        {
            "inFantasy": false,
            "playerName": "pid4009851",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ks1 Qh2 2c3 Tc4",
            "rows": "As0 9c3 7d4/3c0 2d1 5s2 6c2 4s3/8s0 9d0 Ts0 Qd1 3h4",
            "playerId": "pid4009851"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 21:09:05",
    "roomId": "6852666"
}


{
    "stakes": 2,
    "handData": {"200528025259-6852666-0000005-1": [
        {
            "inFantasy": false,
            "playerName": "pid3841225",
            "orderIndex": 0,
            "hero": false,
            "dead": "3s1 Ks2 Js3 2c4",
            "rows": "Ah1 As3 6c4/7c0 7h1 7s2 Qs3 2s4/7d0 8d0 9s0 Td0 6s2",
            "playerId": "pid3841225"
        },
        {
            "inFantasy": false,
            "playerName": "pid2139036",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jh1 4h2 2d3 3c4",
            "rows": "Kh0 Kd0 6h4/Th0 Ts1 Kc2 8h3 8s4/4c0 5d0 3d1 2h2 Ac3",
            "playerId": "pid2139036"
        },
        {
            "inFantasy": false,
            "playerName": "pid4009851",
            "orderIndex": 2,
            "hero": true,
            "dead": "3h1 8c2 Tc3 Qc4",
            "rows": "Qh2 Qd2 Ad3/6d0 9h0 9d0 4s1 4d3/5c0 Jc0 5h1 5s4 Jd4",
            "playerId": "pid4009851"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 21:10:59",
    "roomId": "6852666"
}


{
    "stakes": 2,
    "handData": {"200528025259-6852666-0000006-1": [
        {
            "inFantasy": true,
            "playerName": "pid3841225",
            "orderIndex": 2,
            "hero": false,
            "dead": "6h0 5d1 2c2",
            "rows": "Td0 Kd0 Ks0/4h0 4d0 4c0 8c0 9h0/8s0 9s0 Tc0 Jc0 Qh0",
            "playerId": "pid3841225"
        },
        {
            "inFantasy": true,
            "playerName": "pid2139036",
            "orderIndex": 0,
            "hero": false,
            "dead": "2h0 6d1",
            "rows": "Kc0 Ah0 Ac0/Th0 Jh0 Js0 Qd0 Qc0/3d0 3c0 3s0 7d0 7c0",
            "playerId": "pid2139036"
        },
        {
            "inFantasy": true,
            "playerName": "pid4009851",
            "orderIndex": 1,
            "hero": true,
            "dead": "2d0",
            "rows": "Qs0 Ad0 As0/3h0 7h0 7s0 8h0 8d0/5h0 5c0 6c0 9d0 9c0",
            "playerId": "pid4009851"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 21:12:09",
    "roomId": "6852666"
}


{
    "stakes": 2,
    "handData": {"200528025259-6852666-0000007-1": [
        {
            "inFantasy": false,
            "playerName": "pid3841225",
            "orderIndex": 1,
            "hero": false,
            "dead": "Ts1 5d2 5s3 6h4",
            "rows": "Kc0 Qs2 Jh4/2s0 4c0 As1 8h3 Ad4/9s0 Jd0 9h1 4d2 Js3",
            "playerId": "pid3841225"
        },
        {
            "inFantasy": false,
            "playerName": "pid2139036",
            "orderIndex": 2,
            "hero": false,
            "dead": "2d1 7d2 6c3 2h4",
            "rows": "Qh1 8c2 Ks4/3s1 4s2 3h3 3d3 9d4/2c0 5c0 Tc0 Qc0 Ac0",
            "playerId": "pid2139036"
        },
        {
            "inFantasy": false,
            "playerName": "pid4009851",
            "orderIndex": 0,
            "hero": true,
            "dead": "Th1 3c2 4h3 7s4",
            "rows": "Kh0 Jc1 Ah3/5h0 7c0 8s2 9c3 6s4/Td0 Qd0 6d1 8d2 Kd4",
            "playerId": "pid4009851"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 21:13:18",
    "roomId": "6852666"
}


{
    "stakes": 2,
    "handData": {"200528025259-6852666-0000008-1": [
        {
            "inFantasy": false,
            "playerName": "pid3841225",
            "orderIndex": 0,
            "hero": false,
            "dead": "7h1 Js2 8c3 8s4",
            "rows": "Ah0 Tc3 Ad4/2s0 5h0 5s1 2h2 7c3/Qd0 Kd0 4d1 Qs2 Jc4",
            "playerId": "pid3841225"
        },
        {
            "inFantasy": false,
            "playerName": "pid2139036",
            "orderIndex": 1,
            "hero": false,
            "dead": "5d1 6h2 9h3 8h4",
            "rows": "Kc0 4c3 9c3/2d0 Ac0 2c1 3c2 8d4/7s0 Ts0 4s1 Ks2 Qh4",
            "playerId": "pid2139036"
        },
        {
            "inFantasy": false,
            "playerName": "pid4009851",
            "orderIndex": 2,
            "hero": true,
            "dead": "7d1 Td2 Jh3 Kh4",
            "rows": "As0 Jd2 Th4/3s0 4h0 3d2 3h3 Qc3/6d0 6s0 9d1 9s1 5c4",
            "playerId": "pid4009851"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 21:15:12",
    "roomId": "6852666"
}


{
    "stakes": 2,
    "handData": {"200528025259-6852666-0000009-1": [
        {
            "inFantasy": false,
            "playerName": "pid3841225",
            "orderIndex": 2,
            "hero": false,
            "dead": "6s1 4s2 3d3 2d4",
            "rows": "Ac1 As1 Ts4/2h0 7d0 9s2 2s3 7s3/8c0 8s0 Qd0 8h2 4c4",
            "playerId": "pid3841225"
        },
        {
            "inFantasy": false,
            "playerName": "pid2139036",
            "orderIndex": 0,
            "hero": false,
            "dead": "Js1 7h2 Jc3 2c4",
            "rows": "Td0 Kd1 Ks1/4h0 Ad0 Qs2 Kc3 4d4/5c0 9c0 5d2 9d3 6c4",
            "playerId": "pid2139036"
        },
        {
            "inFantasy": false,
            "playerName": "pid4009851",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jd1 Tc2 8d3 9h4",
            "rows": "Qc0 Qh3 Ah3/3s0 5s2 6d2 3h4 3c4/6h0 Th0 Jh0 5h1 Kh1",
            "playerId": "pid4009851"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 21:17:04",
    "roomId": "6852666"
}


{
    "stakes": 2,
    "handData": {"200528025259-6852666-0000010-1": [
        {
            "inFantasy": true,
            "playerName": "pid3841225",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qd0 4h1 9d2",
            "rows": "5d0 5c0 5s0/8c0 9h0 Th0 Jd0 Qs0/2h0 2c0 2s0 3h0 3c0",
            "playerId": "pid3841225"
        },
        {
            "inFantasy": false,
            "playerName": "pid2139036",
            "orderIndex": 2,
            "hero": false,
            "dead": "9c1 8d2 2d3 8h4",
            "rows": "Ah0 Ts2 Ac3/3s0 7c0 4s1 7h3 Qh4/Jh0 Js0 Kc1 Ks2 Tc4",
            "playerId": "pid2139036"
        },
        {
            "inFantasy": true,
            "playerName": "pid4009851",
            "orderIndex": 0,
            "hero": true,
            "dead": "4c0",
            "rows": "Qc0 Kh0 Kd0/6d0 7d0 Jc0 Ad0 As0/5h0 6c0 7s0 8s0 9s0",
            "playerId": "pid4009851"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 21:18:16",
    "roomId": "6852666"
}


{
    "stakes": 2,
    "handData": {"200528025259-6852666-0000011-1": [
        {
            "inFantasy": true,
            "playerName": "pid3841225",
            "orderIndex": 0,
            "hero": false,
            "dead": "2c0 3d1 4h2",
            "rows": "Qh0 Kh0 Ad0/3s0 6s0 8s0 Ts0 Qs0/5h0 5d0 5c0 5s0 Jd0",
            "playerId": "pid3841225"
        },
        {
            "inFantasy": false,
            "playerName": "pid4009851",
            "orderIndex": 1,
            "hero": true,
            "dead": "4s1 7d2 2h3 4d4",
            "rows": "Qd3 8h4 Qc4/6d0 8c0 6h1 Tc2 6c3/2s0 7s0 Js0 9s1 As2",
            "playerId": "pid4009851"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 21:19:04",
    "roomId": "6852666"
}


{
    "stakes": 2,
    "handData": {"200528025259-6852666-0000012-1": [
        {
            "inFantasy": true,
            "playerName": "pid3841225",
            "orderIndex": 1,
            "hero": false,
            "dead": "6d0 6s1 5c2",
            "rows": "Jc0 Kh0 Ks0/2h0 4h0 5h0 Jh0 Ah0/8d0 8c0 Th0 Td0 Ts0",
            "playerId": "pid3841225"
        },
        {
            "inFantasy": true,
            "playerName": "pid4009851",
            "orderIndex": 0,
            "hero": true,
            "dead": "7s0",
            "rows": "Qh0 Kd0 As0/3h0 4d0 4s0 5d0 8h0/9h0 9d0 9c0 9s0 Js0",
            "playerId": "pid4009851"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 21:20:01",
    "roomId": "6852666"
}


{
    "stakes": 2,
    "handData": {"200528025259-6852666-0000013-1": [
        {
            "inFantasy": false,
            "playerName": "pid3841225",
            "orderIndex": 0,
            "hero": false,
            "dead": "2h1 4c2 3s3 2c4",
            "rows": "5h0 9c3 Ah3/6c0 Jc0 7h1 7c1 6h2/8d0 Qd0 6d2 6s4 9h4",
            "playerId": "pid3841225"
        },
        {
            "inFantasy": true,
            "playerName": "pid4009851",
            "orderIndex": 1,
            "hero": true,
            "dead": "3c0",
            "rows": "8h0 8c0 8s0/7s0 Tc0 Kh0 Kd0 Kc0/2d0 3d0 4d0 5c0 Ad0",
            "playerId": "pid4009851"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 21:20:52",
    "roomId": "6852666"
}


{
    "stakes": 2,
    "handData": {"200528025259-6852666-0000014-1": [
        {
            "inFantasy": false,
            "playerName": "pid3841225",
            "orderIndex": 1,
            "hero": false,
            "dead": "8h1 4s2 Th3 4h4",
            "rows": "Qh2 Jh3 Qc3/3d0 3c0 6c0 2d1 Ks4/5h0 5d0 9d1 9s2 4c4",
            "playerId": "pid3841225"
        },
        {
            "inFantasy": true,
            "playerName": "pid4009851",
            "orderIndex": 0,
            "hero": true,
            "dead": "5s0",
            "rows": "Js0 Kc0 Ad0/6h0 6d0 6s0 7c0 8c0/2h0 2s0 Td0 Tc0 Ts0",
            "playerId": "pid4009851"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 21:21:55",
    "roomId": "6852666"
}


