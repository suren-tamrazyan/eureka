{
    "stakes": 0.5,
    "handData": {"200528051443-6863235-0000031-1": [
        {
            "inFantasy": false,
            "playerName": "pid1271805",
            "orderIndex": 1,
            "hero": false,
            "dead": "9c1 3s2 6c3 Qc4",
            "rows": "Ah0 Kh2 Ac3/4s0 Jd1 5d2 4c4 Jh4/2h0 2s0 Tc0 2d1 6d3",
            "playerId": "pid1271805"
        },
        {
            "inFantasy": false,
            "playerName": "pid3964294",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ad1 As2 Qh3 4h4",
            "rows": "Kd0 Ks0 8s4/5c0 3c2 7s2 7d3 7c4/7h0 9s0 8d1 Th1 6h3",
            "playerId": "pid3964294"
        }
    ]},
    "joined": true,
    "clubId": "1328116",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 22:56:48",
    "roomId": "6863235"
}


{
    "stakes": 0.5,
    "handData": {"200528051443-6863235-0000032-1": [
        {
            "inFantasy": true,
            "playerName": "pid1271805",
            "orderIndex": 0,
            "hero": false,
            "dead": "8c0 4h1 7d2",
            "rows": "Jh0 Qd0 Qs0/2d0 2c0 3d0 3c0 Td0/5s0 8s0 9s0 Ks0 As0",
            "playerId": "pid1271805"
        },
        {
            "inFantasy": true,
            "playerName": "pid3964294",
            "orderIndex": 1,
            "hero": true,
            "dead": "2s0 3s0",
            "rows": "Kc0 Ah0 Ad0/6h0 6s0 8h0 8d0 Jd0/3h0 5h0 7h0 Qh0 Kh0",
            "playerId": "pid3964294"
        }
    ]},
    "joined": true,
    "clubId": "1328116",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 22:57:54",
    "roomId": "6863235"
}


{
    "stakes": 0.5,
    "handData": {"200528051443-6863235-0000033-1": [
        {
            "inFantasy": false,
            "playerName": "pid1271805",
            "orderIndex": 1,
            "hero": false,
            "dead": "3d1 Ts2 5h3 Jd4",
            "rows": "Ad3 2h4 2d4/9s0 2s1 4d2 9d2 2c3/6d0 7d0 8h0 9c0 Td1",
            "playerId": "pid1271805"
        },
        {
            "inFantasy": false,
            "playerName": "pid3964294",
            "orderIndex": 0,
            "hero": true,
            "dead": "5c1 3c2 Ac3 7h4",
            "rows": "Kd0 Qs2 Qh4/3s0 Ah1 As1 5d2 9h3/6h0 6s0 Jh0 4h3 4c4",
            "playerId": "pid3964294"
        }
    ]},
    "joined": true,
    "clubId": "1328116",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 22:58:58",
    "roomId": "6863235"
}


{
    "stakes": 0.5,
    "handData": {"200528051443-6863235-0000034-1": [
        {
            "inFantasy": false,
            "playerName": "pid1271805",
            "orderIndex": 0,
            "hero": false,
            "dead": "3s1 4d2 Ks3 7c4",
            "rows": "Kd0 Ac1 Js4/9c0 8h1 6s2 8s3 9s3/Th0 Tc0 Qd0 Qh2 6c4",
            "playerId": "pid1271805"
        },
        {
            "inFantasy": true,
            "playerName": "pid3964294",
            "orderIndex": 1,
            "hero": true,
            "dead": "9h0",
            "rows": "2h0 2d0 2c0/5h0 5d0 5c0 Jd0 Qc0/3d0 4c0 5s0 6h0 7s0",
            "playerId": "pid3964294"
        }
    ]},
    "joined": true,
    "clubId": "1328116",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 22:59:38",
    "roomId": "6863235"
}


{
    "stakes": 0.5,
    "handData": {"200528051443-6863235-0000035-1": [
        {
            "inFantasy": false,
            "playerName": "pid1271805",
            "orderIndex": 1,
            "hero": false,
            "dead": "4d1 2h2 Jd3 8h4",
            "rows": "Ks1 Qh4 Kd4/3d0 8c0 5c1 5d2 3c3/9h0 9s0 Qd0 7s2 7h3",
            "playerId": "pid1271805"
        },
        {
            "inFantasy": true,
            "playerName": "pid3964294",
            "orderIndex": 0,
            "hero": true,
            "dead": "3s0",
            "rows": "2d0 2s0 4c0/9d0 Td0 Jc0 Ah0 As0/3h0 4s0 5h0 6h0 7d0",
            "playerId": "pid3964294"
        }
    ]},
    "joined": true,
    "clubId": "1328116",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 23:00:25",
    "roomId": "6863235"
}


{
    "stakes": 0.5,
    "handData": {"200528051443-6863235-0000036-1": [
        {
            "inFantasy": true,
            "playerName": "pid1271805",
            "orderIndex": 0,
            "hero": false,
            "dead": "3h0 2d1",
            "rows": "Th0 Ts0 Ac0/5h0 7c0 Jh0 Js0 Qc0/6d0 6c0 6s0 8h0 8s0",
            "playerId": "pid1271805"
        },
        {
            "inFantasy": false,
            "playerName": "pid3964294",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jd1 Td2 8c3 6h4",
            "rows": "Qh0 As3 Kh4/7d0 4d1 5d2 3d3 8d4/3c0 5c0 Tc0 Kc1 Jc2",
            "playerId": "pid3964294"
        }
    ]},
    "joined": true,
    "clubId": "1328116",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 23:01:13",
    "roomId": "6863235"
}


{
    "stakes": 0.5,
    "handData": {"200528051443-6863235-0000037-1": [
        {
            "inFantasy": false,
            "playerName": "pid1271805",
            "orderIndex": 1,
            "hero": false,
            "dead": "7c1 Kd2 Qs3 Ac4",
            "rows": "Kh0 As0 6h4/2c0 6s1 4s2 3d3 3c3/8d0 8s0 8c1 Jd2 6c4",
            "playerId": "pid1271805"
        },
        {
            "inFantasy": false,
            "playerName": "pid3964294",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qh1 9c2 4c3 Js4",
            "rows": "Qd0 Kc2 7h4/5s0 2d2 4d3 5c3 Jc4/9h0 9s0 Ts0 Th1 Tc1",
            "playerId": "pid3964294"
        }
    ]},
    "joined": true,
    "clubId": "1328116",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 23:02:24",
    "roomId": "6863235"
}


{
    "stakes": 0.5,
    "handData": {"200528051443-6863235-0000038-1": [
        {
            "inFantasy": false,
            "playerName": "pid1271805",
            "orderIndex": 0,
            "hero": false,
            "dead": "2s1 Qs2 Qd3 6c4",
            "rows": "As0 Ks2 Ad3/3h0 7h0 4h1 4s1 2c4/5h0 5d0 5c2 Qh3 2d4",
            "playerId": "pid1271805"
        },
        {
            "inFantasy": false,
            "playerName": "pid3964294",
            "orderIndex": 1,
            "hero": true,
            "dead": "6s1 5s2 Jc3 8s4",
            "rows": "8h2 8d3 Kd3/4c0 7c1 9c1 9h2 Ac4/3s0 Th0 Td0 Ts0 3d4",
            "playerId": "pid3964294"
        }
    ]},
    "joined": true,
    "clubId": "1328116",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 23:03:44",
    "roomId": "6863235"
}


{
    "stakes": 0.5,
    "handData": {"200528051443-6863235-0000039-1": [
        {
            "inFantasy": false,
            "playerName": "pid1271805",
            "orderIndex": 1,
            "hero": false,
            "dead": "8s1 9c2 3h3 5d4",
            "rows": "Ad0 As0 Qd4/5s0 4h2 4s2 4d3 Jh3/2c0 Jc0 6c1 Kc1 3c4",
            "playerId": "pid1271805"
        },
        {
            "inFantasy": false,
            "playerName": "pid3964294",
            "orderIndex": 0,
            "hero": true,
            "dead": "Th1 Qh2 7c3 6d4",
            "rows": "2h0 4c1 8h2/3d0 7d0 5c2 9h3 Jd3/Js0 Qs0 9s1 3s4 7h4",
            "playerId": "pid3964294"
        }
    ]},
    "joined": true,
    "clubId": "1328116",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 23:04:36",
    "roomId": "6863235"
}


{
    "stakes": 0.5,
    "handData": {"200528051443-6863235-0000040-1": [
        {
            "inFantasy": true,
            "playerName": "pid1271805",
            "orderIndex": 0,
            "hero": false,
            "dead": "4c0 2s1 3s2",
            "rows": "6h0 6d0 6c0/7h0 9h0 9c0 9s0 As0/2d0 3d0 Jd0 Kd0 Ad0",
            "playerId": "pid1271805"
        },
        {
            "inFantasy": false,
            "playerName": "pid3964294",
            "orderIndex": 1,
            "hero": true,
            "dead": "4h1 Qh2 8c3 5h4",
            "rows": "Ks0 Kh1 9d4/5c0 Ac1 Qc3 Ah3 7s4/8h0 Tc0 Js0 Th2 Jc2",
            "playerId": "pid3964294"
        }
    ]},
    "joined": true,
    "clubId": "1328116",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 23:05:18",
    "roomId": "6863235"
}


{
    "stakes": 0.5,
    "handData": {"200528051443-6863235-0000041-1": [
        {
            "inFantasy": true,
            "playerName": "pid1271805",
            "orderIndex": 1,
            "hero": false,
            "dead": "7h0 Kh1 3h2",
            "rows": "Qh0 Qd0 Qc0/6h0 7s0 8s0 9s0 Ts0/3c0 4c0 6c0 Kc0 Ac0",
            "playerId": "pid1271805"
        },
        {
            "inFantasy": true,
            "playerName": "pid3964294",
            "orderIndex": 0,
            "hero": true,
            "dead": "7c0 2c0",
            "rows": "9c0 Ah0 Ad0/2d0 5d0 7d0 8d0 Td0/3s0 4s0 5s0 Qs0 Ks0",
            "playerId": "pid3964294"
        }
    ]},
    "joined": true,
    "clubId": "1328116",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 23:06:01",
    "roomId": "6863235"
}


{
    "stakes": 0.5,
    "handData": {"200528051443-6863235-0000042-1": [
        {
            "inFantasy": true,
            "playerName": "pid1271805",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jc0 7h1 3h2",
            "rows": "8h0 8s0 Kc0/3d0 6d0 7d0 Kd0 Ad0/5h0 5s0 Th0 Td0 Tc0",
            "playerId": "pid1271805"
        },
        {
            "inFantasy": false,
            "playerName": "pid3964294",
            "orderIndex": 1,
            "hero": true,
            "dead": "6c1 3s2 4c3 4d4",
            "rows": "7c2 6s4 Jh4/5d0 9s0 Qd1 Qs1 5c3/4h0 6h0 Kh0 2h2 Ah3",
            "playerId": "pid3964294"
        }
    ]},
    "joined": true,
    "clubId": "1328116",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 23:07:02",
    "roomId": "6863235"
}


