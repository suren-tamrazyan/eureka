{
    "stakes": 2,
    "handData": {"200528021300-6849808-0000000-1": [
        {
            "inFantasy": false,
            "playerName": "pid3317301",
            "orderIndex": 1,
            "hero": false,
            "dead": "4s1 3c2 5s3 3h4",
            "rows": "Kh0 7c3 9d4/7h0 9h0 Th1 8s2 6c4/8d0 Qd0 Td1 7d2 5d3",
            "playerId": "pid3317301"
        },
        {
            "inFantasy": false,
            "playerName": "pid3035348",
            "orderIndex": 0,
            "hero": true,
            "dead": "9c1 8c2 Jd3 Js4",
            "rows": "Kc0 Qc2 Ks2/3d0 Ts0 As1 Ac3 Jc4/5h0 6h0 4d1 5c3 6d4",
            "playerId": "pid3035348"
        }
    ]},
    "joined": true,
    "clubId": "768777",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:29:54",
    "roomId": "6849808"
}


{
    "stakes": 2,
    "handData": {"200528021300-6849808-0000001-1": [
        {
            "inFantasy": false,
            "playerName": "pid3317301",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qh1 Jd2 4d3 8s4",
            "rows": "7h3 As3 Qc4/2h0 6d0 4h1 3h2 Th4/5c0 7c0 Tc0 Jc1 9c2",
            "playerId": "pid3317301"
        },
        {
            "inFantasy": true,
            "playerName": "pid3035348",
            "orderIndex": 1,
            "hero": true,
            "dead": "4c0 2c0",
            "rows": "6h0 Kc0 Ks0/2s0 3s0 5s0 6s0 7s0/5d0 7d0 9d0 Td0 Qd0",
            "playerId": "pid3035348"
        }
    ]},
    "joined": true,
    "clubId": "768777",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:30:24",
    "roomId": "6849808"
}


{
    "stakes": 2,
    "handData": {"200528021300-6849808-0000002-1": [
        {
            "inFantasy": false,
            "playerName": "pid3317301",
            "orderIndex": 1,
            "hero": false,
            "dead": "6s1 2s2 2d3 7d4",
            "rows": "6c2 4c3 Jh4/5h0 8s0 2c1 8h1 5s2/9h0 9c0 Jd0 7s3 Js4",
            "playerId": "pid3317301"
        },
        {
            "inFantasy": false,
            "playerName": "pid3035348",
            "orderIndex": 0,
            "hero": true,
            "dead": "5c1 6d2 Qc3 2h4",
            "rows": "Qs0 Qd1 9s4/Kc0 Ac0 3h3 Ad3 Qh4/4d0 4s0 Td1 4h2 Th2",
            "playerId": "pid3035348"
        }
    ]},
    "joined": true,
    "clubId": "768777",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:31:05",
    "roomId": "6849808"
}


{
    "stakes": 2,
    "handData": {"200528021300-6849808-0000003-1": [
        {
            "inFantasy": false,
            "playerName": "pid3317301",
            "orderIndex": 0,
            "hero": false,
            "dead": "7d1 Kc2 6h3 6d4",
            "rows": "Ah0 Ad1 7h2/5c0 9d0 4s2 9s3 Th4/2h0 2c0 Qc1 Kd3 Ts4",
            "playerId": "pid3317301"
        },
        {
            "inFantasy": true,
            "playerName": "pid3035348",
            "orderIndex": 1,
            "hero": true,
            "dead": "9h0",
            "rows": "7c0 7s0 Tc0/2s0 3d0 4c0 5d0 Ac0/6c0 6s0 8d0 8c0 8s0",
            "playerId": "pid3035348"
        }
    ]},
    "joined": true,
    "clubId": "768777",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:31:37",
    "roomId": "6849808"
}


{
    "stakes": 2,
    "handData": {"200528021300-6849808-0000004-1": [
        {
            "inFantasy": false,
            "playerName": "pid3340617",
            "orderIndex": 0,
            "hero": false,
            "dead": "9h1 3s2 3d3 2c4",
            "rows": "Kh2 Js3 4c4/Tc0 Ts1 5h2 9c3 Th4/4h0 5c0 6d0 7d0 3c1",
            "playerId": "pid3340617"
        },
        {
            "inFantasy": false,
            "playerName": "pid3035348",
            "orderIndex": 1,
            "hero": true,
            "dead": "3h1 8c2 Kd3 7c4",
            "rows": "As0 Ah2 Ks4/8s0 2s1 8h2 4d3 4s3/Jd0 Jc0 Qc0 Qh1 6h4",
            "playerId": "pid3035348"
        }
    ]},
    "joined": true,
    "clubId": "768777",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:32:54",
    "roomId": "6849808"
}


{
    "stakes": 2,
    "handData": {"200528021300-6849808-0000005-1": [
        {
            "inFantasy": false,
            "playerName": "pid3340617",
            "orderIndex": 1,
            "hero": false,
            "dead": "Kc1 6c2 4h3 3d4",
            "rows": "8h3 Qc3 5h4/3s0 9h0 3h1 9c1 4c2/6d0 Td0 Kd0 2d2 7d4",
            "playerId": "pid3340617"
        },
        {
            "inFantasy": true,
            "playerName": "pid3035348",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qd0 8d0 5s0",
            "rows": "Ah0 Ad0 As0/6s0 7s0 9s0 Ts0 Qs0/2c0 5c0 8c0 Jc0 Ac0",
            "playerId": "pid3035348"
        }
    ]},
    "joined": true,
    "clubId": "768777",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:33:26",
    "roomId": "6849808"
}


{
    "stakes": 2,
    "handData": {"200528021300-6849808-0000006-1": [
        {
            "inFantasy": false,
            "playerName": "pid3340617",
            "orderIndex": 0,
            "hero": false,
            "dead": "6c1 2c2 3c3 9h4",
            "rows": "Kc2 7d3 Kh4/3d0 4c0 5d1 5s1 3h2/8h0 Qh0 Qs0 5c3 Kd4",
            "playerId": "pid3340617"
        },
        {
            "inFantasy": true,
            "playerName": "pid3035348",
            "orderIndex": 1,
            "hero": true,
            "dead": "2h0",
            "rows": "Jc0 Js0 As0/7s0 9d0 9s0 Th0 Td0/6h0 6d0 6s0 8d0 8c0",
            "playerId": "pid3035348"
        }
    ]},
    "joined": true,
    "clubId": "768777",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:34:05",
    "roomId": "6849808"
}


{
    "stakes": 2,
    "handData": {"200528021300-6849808-0000007-1": [
        {
            "inFantasy": false,
            "playerName": "pid3317301",
            "orderIndex": 0,
            "hero": false,
            "dead": "9c1 3h2 2s3 6c4",
            "rows": "Ac0 Jh2 9h4/6d0 4d1 7c1 6h3 7d4/5d0 5s0 Kh0 8h2 5c3",
            "playerId": "pid3317301"
        },
        {
            "inFantasy": false,
            "playerName": "pid3035348",
            "orderIndex": 1,
            "hero": true,
            "dead": "4s1 Js2 4h3 7s4",
            "rows": "Kd0 Qd2 Ad3/2c0 8d0 6s1 8c2 Jd3/Td0 Ts0 3c1 3s4 Th4",
            "playerId": "pid3035348"
        }
    ]},
    "joined": true,
    "clubId": "768777",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:35:05",
    "roomId": "6849808"
}


{
    "stakes": 2,
    "handData": {"200528021300-6849808-0000008-1": [
        {
            "inFantasy": false,
            "playerName": "pid3340617",
            "orderIndex": 1,
            "hero": false,
            "dead": "6d1 Jc2 6c3 3c4",
            "rows": "Kh0 Kc1 Jd3/4c0 5c0 5d1 Ah2 Jh4/9s0 Ts0 2s2 3s3 Qh4",
            "playerId": "pid3340617"
        },
        {
            "inFantasy": false,
            "playerName": "pid3317301",
            "orderIndex": 2,
            "hero": false,
            "dead": "6s1 Js2 2d3 5s4",
            "rows": "Kd0 6h3 As4/9d0 8d1 8s1 7h2 7s2/3h0 3d0 Qc0 Qd3 Td4",
            "playerId": "pid3317301"
        },
        {
            "inFantasy": false,
            "playerName": "pid3035348",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qs1 9h2 7d3 5h4",
            "rows": "2c2 Th3 Ad4/2h0 4d0 4h1 4s1 8h3/7c0 8c0 9c0 Tc2 Ac4",
            "playerId": "pid3035348"
        }
    ]},
    "joined": true,
    "clubId": "768777",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:36:05",
    "roomId": "6849808"
}


{
    "stakes": 2,
    "handData": {"200528021300-6849808-0000009-1": [
        {
            "inFantasy": false,
            "playerName": "pid3340617",
            "orderIndex": 0,
            "hero": false,
            "dead": "5c1 As2 4h3 Qs4",
            "rows": "Kc0 Kh1 9d3/2h0 3s0 3d1 6h2 6d4/Tc0 Js0 Ts2 7h3 7d4",
            "playerId": "pid3340617"
        },
        {
            "inFantasy": false,
            "playerName": "pid3317301",
            "orderIndex": 1,
            "hero": false,
            "dead": "2s1 4s2 5s3 2d4",
            "rows": "Ah0 Th3 8h4/5h0 4c2 5d2 Td3 8s4/3c0 8c0 9c0 3h1 9h1",
            "playerId": "pid3317301"
        },
        {
            "inFantasy": false,
            "playerName": "pid3035348",
            "orderIndex": 2,
            "hero": true,
            "dead": "Jh1 Ad2 7s3 Ac4",
            "rows": "Ks0 Kd1 Jd3/4d1 Qh2 Qd2 8d4 9s4/2c0 6c0 7c0 Qc0 Jc3",
            "playerId": "pid3035348"
        }
    ]},
    "joined": true,
    "clubId": "768777",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:37:26",
    "roomId": "6849808"
}


{
    "stakes": 2,
    "handData": {"200528021300-6849808-0000010-1": [
        {
            "inFantasy": true,
            "playerName": "pid3340617",
            "orderIndex": 2,
            "hero": false,
            "dead": "4s0 4h1",
            "rows": "6h0 Ah0 Ad0/7h0 8s0 9d0 Th0 Jd0/5d0 5c0 Qh0 Qd0 Qs0",
            "playerId": "pid3340617"
        },
        {
            "inFantasy": false,
            "playerName": "pid3317301",
            "orderIndex": 0,
            "hero": false,
            "dead": "6s1 7d2 3h3 As4",
            "rows": "Kc0 9h3 Kd4/4c0 5s0 3s1 6d2 2c3/Td0 Ts0 Js1 Tc2 8h4",
            "playerId": "pid3317301"
        },
        {
            "inFantasy": false,
            "playerName": "pid3035348",
            "orderIndex": 1,
            "hero": true,
            "dead": "3c1 2s2 5h3 8d4",
            "rows": "Ac0 4d2 7s3/2d0 6c0 7c1 2h2 Kh4/9s0 Qc0 Jc1 Ks3 Jh4",
            "playerId": "pid3035348"
        }
    ]},
    "joined": true,
    "clubId": "768777",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:39:09",
    "roomId": "6849808"
}


{
    "stakes": 2,
    "handData": {"200528021300-6849808-0000011-1": [
        {
            "inFantasy": false,
            "playerName": "pid3340617",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qc1 3d2 Jd3 4s4",
            "rows": "Ah1 Qd3 Qh4/3c0 3s0 4d0 4h1 2d4/6c0 Ts0 7h2 9d2 8s3",
            "playerId": "pid3340617"
        },
        {
            "inFantasy": false,
            "playerName": "pid3317301",
            "orderIndex": 2,
            "hero": false,
            "dead": "9c1 9h2 6d3 2h4",
            "rows": "Qs2 Kc3 Ad4/3h0 5c0 Jc2 5d3 Ks4/8c0 9s0 Th0 8d1 Td1",
            "playerId": "pid3317301"
        },
        {
            "inFantasy": false,
            "playerName": "pid3035348",
            "orderIndex": 0,
            "hero": true,
            "dead": "Kh1 4c2 5s3 8h4",
            "rows": "Kd0 Ac2 As3/6s0 6h1 2s2 2c3 5h4/7d0 7c0 Tc0 7s1 Js4",
            "playerId": "pid3035348"
        }
    ]},
    "joined": true,
    "clubId": "768777",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:40:04",
    "roomId": "6849808"
}


{
    "stakes": 2,
    "handData": {"200528021300-6849808-0000012-1": [
        {
            "inFantasy": true,
            "playerName": "pid3340617",
            "orderIndex": 0,
            "hero": false,
            "dead": "6h0",
            "rows": "Td0 Tc0 Ks0/3c0 3s0 5h0 5d0 Js0/2s0 7h0 7d0 7c0 7s0",
            "playerId": "pid3340617"
        },
        {
            "inFantasy": false,
            "playerName": "pid3317301",
            "orderIndex": 1,
            "hero": false,
            "dead": "3h1 4h2 Th3 8d4",
            "rows": "Ad1 5s2 Ah4/2d0 8s0 8h1 9h2 9c3/6c0 Jc0 Qc0 4c3 5c4",
            "playerId": "pid3317301"
        },
        {
            "inFantasy": true,
            "playerName": "pid3035348",
            "orderIndex": 2,
            "hero": true,
            "dead": "2c0 3d0 4s0",
            "rows": "Kd0 Kc0 Ac0/4d0 9d0 9s0 Jh0 Jd0/6d0 6s0 Qh0 Qd0 Qs0",
            "playerId": "pid3035348"
        }
    ]},
    "joined": true,
    "clubId": "768777",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:40:54",
    "roomId": "6849808"
}


{
    "stakes": 2,
    "handData": {"200528021300-6849808-0000013-1": [
        {
            "inFantasy": true,
            "playerName": "pid3340617",
            "orderIndex": 2,
            "hero": false,
            "dead": "3d0",
            "rows": "2h0 2c0 2s0/4d0 6d0 6c0 6s0 Kd0/7d0 8c0 9s0 Ts0 Jc0",
            "playerId": "pid3340617"
        },
        {
            "inFantasy": true,
            "playerName": "pid3317301",
            "orderIndex": 0,
            "hero": false,
            "dead": "3h0 Ad1 4c2",
            "rows": "Qd0 Qc0 Qs0/2d0 3s0 4h0 5h0 As0/7s0 8h0 9c0 Tc0 Jd0",
            "playerId": "pid3317301"
        },
        {
            "inFantasy": false,
            "playerName": "pid3035348",
            "orderIndex": 1,
            "hero": true,
            "dead": "6h1 Jh2 5c3 Ac4",
            "rows": "Kh0 Ks2 9h3/5d0 7c0 Th1 Td1 7h2/4s0 8s0 8d3 5s4 Kc4",
            "playerId": "pid3035348"
        }
    ]},
    "joined": true,
    "clubId": "768777",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:41:44",
    "roomId": "6849808"
}


{
    "stakes": 2,
    "handData": {"200528021300-6849808-0000014-1": [
        {
            "inFantasy": true,
            "playerName": "pid3340617",
            "orderIndex": 1,
            "hero": false,
            "dead": "6h0",
            "rows": "Kd0 Ks0 Ac0/8d0 8c0 Jh0 Js0 Qd0/3h0 3c0 3s0 5d0 5c0",
            "playerId": "pid3340617"
        },
        {
            "inFantasy": true,
            "playerName": "pid3317301",
            "orderIndex": 2,
            "hero": false,
            "dead": "3d0",
            "rows": "7s0 Ah0 Ad0/4h0 4d0 6d0 8h0 8s0/2c0 2s0 Qh0 Qc0 Qs0",
            "playerId": "pid3317301"
        },
        {
            "inFantasy": false,
            "playerName": "pid3035348",
            "orderIndex": 0,
            "hero": true,
            "dead": "9d1 Kc2 4c3 5s4",
            "rows": "As1 9h3 7d4/5h0 2d1 2h2 6c3 6s4/Th0 Tc0 Ts0 Jd0 Td2",
            "playerId": "pid3035348"
        }
    ]},
    "joined": true,
    "clubId": "768777",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:42:35",
    "roomId": "6849808"
}


{
    "stakes": 2,
    "handData": {"200528021300-6849808-0000015-1": [
        {
            "inFantasy": false,
            "playerName": "pid3340617",
            "orderIndex": 0,
            "hero": false,
            "dead": "4s1 5s2 9c3 4d4",
            "rows": "Ad0 Kh3 8c4/3s0 6c0 3h1 3d2 8d3/Qd0 Ks0 Jc1 As2 Jh4",
            "playerId": "pid3340617"
        },
        {
            "inFantasy": false,
            "playerName": "pid3317301",
            "orderIndex": 1,
            "hero": false,
            "dead": "Js1 2c2 2h3 6d4",
            "rows": "Kd1 Qc2 7c4/8h0 9h0 4c1 4h3 2d4/7d0 7s0 Td0 2s2 Ts3",
            "playerId": "pid3317301"
        },
        {
            "inFantasy": false,
            "playerName": "pid3035348",
            "orderIndex": 2,
            "hero": true,
            "dead": "7h1 9s2 8s3 Tc4",
            "rows": "Qh0 Kc1 Qs2/6s0 Ah1 6h2 9d3 Th4/5h0 5c0 Jd0 5d3 3c4",
            "playerId": "pid3035348"
        }
    ]},
    "joined": true,
    "clubId": "768777",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:44:09",
    "roomId": "6849808"
}


{
    "stakes": 2,
    "handData": {"200528021300-6849808-0000016-1": [
        {
            "inFantasy": false,
            "playerName": "pid3340617",
            "orderIndex": 2,
            "hero": false,
            "dead": "4s1 Jc2 2d3 8h4",
            "rows": "Kc2 Ad3 Ah4/5d0 8s0 4h2 4c3 8d4/Ts0 Qh0 Kh0 Th1 Kd1",
            "playerId": "pid3340617"
        },
        {
            "inFantasy": false,
            "playerName": "pid3317301",
            "orderIndex": 0,
            "hero": false,
            "dead": "Td1 Ks2 4d3 Jh4",
            "rows": "2h1 As2 7s3/6h0 7d0 9c1 7h3 9h4/3h0 3s0 Qs0 3c2 5s4",
            "playerId": "pid3317301"
        },
        {
            "inFantasy": false,
            "playerName": "pid3035348",
            "orderIndex": 1,
            "hero": true,
            "dead": "5h1 7c2 9d3 6d4",
            "rows": "Ac0 2c3 2s3/3d0 6s0 6c1 Js2 5c4/Tc0 Jd0 9s1 Qc2 Qd4",
            "playerId": "pid3035348"
        }
    ]},
    "joined": true,
    "clubId": "768777",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:45:42",
    "roomId": "6849808"
}


{
    "stakes": 2,
    "handData": {"200528021300-6849808-0000017-1": [
        {
            "inFantasy": true,
            "playerName": "pid3340617",
            "orderIndex": 1,
            "hero": false,
            "dead": "6c0 2d1 4c2",
            "rows": "Kc0 Ah0 Ad0/8h0 9h0 9s0 Th0 Td0/4d0 5d0 6d0 7d0 8d0",
            "playerId": "pid3340617"
        },
        {
            "inFantasy": false,
            "playerName": "pid3317301",
            "orderIndex": 2,
            "hero": false,
            "dead": "2s1 Kh2 4s3 7s4",
            "rows": "Ac0 As1 5s3/5c0 6s0 3h2 5h2 6h4/Jh0 Qh0 Jd1 Tc3 4h4",
            "playerId": "pid3317301"
        },
        {
            "inFantasy": false,
            "playerName": "pid3035348",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jc1 9d2 3s3 Qd4",
            "rows": "Kd0 Qc2 Ks4/2c0 3d0 2h1 3c2 Ts3/7h0 8c0 7c1 8s3 Js4",
            "playerId": "pid3035348"
        }
    ]},
    "joined": true,
    "clubId": "768777",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:46:29",
    "roomId": "6849808"
}


{
    "stakes": 2,
    "handData": {"200528021300-6849808-0000018-1": [
        {
            "inFantasy": true,
            "playerName": "pid3340617",
            "orderIndex": 0,
            "hero": false,
            "dead": "2h0",
            "rows": "8c0 Ah0 Ad0/3h0 9c0 9s0 Qh0 Qc0/6d0 6c0 Kh0 Kd0 Ks0",
            "playerId": "pid3340617"
        },
        {
            "inFantasy": false,
            "playerName": "pid3317301",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jc1 6h2 3s3 6s4",
            "rows": "8d3 2s4 4d4/2c0 3c0 3d1 4h1 4s3/7d0 7s0 8s0 Jd2 Js2",
            "playerId": "pid3317301"
        },
        {
            "inFantasy": true,
            "playerName": "pid3035348",
            "orderIndex": 2,
            "hero": true,
            "dead": "4c0 2d0",
            "rows": "Kc0 Ac0 As0/5h0 5d0 5s0 7h0 8h0/9h0 9d0 Th0 Td0 Tc0",
            "playerId": "pid3035348"
        }
    ]},
    "joined": true,
    "clubId": "768777",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:47:20",
    "roomId": "6849808"
}


{
    "stakes": 2,
    "handData": {"200528021300-6849808-0000019-1": [
        {
            "inFantasy": false,
            "playerName": "pid3340617",
            "orderIndex": 1,
            "hero": false,
            "dead": "8s1 2c2 7s3 Qh4",
            "rows": "Ac1 Kc3 Ks4/4c0 6d0 4s1 5d3 4h4/9s0 Js0 Qd0 8c2 Td2",
            "playerId": "pid3340617"
        },
        {
            "inFantasy": false,
            "playerName": "pid3035348",
            "orderIndex": 0,
            "hero": true,
            "dead": "4d1 6h2 9h3 Jd4",
            "rows": "Qs0 Kd0 9d4/As0 2h1 3h1 3d3 6s4/9c0 Jc0 7h2 7d2 Jh3",
            "playerId": "pid3035348"
        }
    ]},
    "joined": true,
    "clubId": "768777",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:48:12",
    "roomId": "6849808"
}


{
    "stakes": 2,
    "handData": {"200528021300-6849808-0000020-1": [
        {
            "inFantasy": true,
            "playerName": "pid3340617",
            "orderIndex": 0,
            "hero": false,
            "dead": "2h0 4s1",
            "rows": "6h0 Tc0 As0/3h0 3c0 3s0 8d0 8c0/Td0 Jd0 Qd0 Kd0 Ad0",
            "playerId": "pid3340617"
        },
        {
            "inFantasy": false,
            "playerName": "pid3035348",
            "orderIndex": 1,
            "hero": true,
            "dead": "6s1 4c2 Js3 7h4",
            "rows": "9h1 Jh2 Qs3/5h0 Ts0 2c1 Ac2 Qh4/2d0 4d0 6d0 5d3 9d4",
            "playerId": "pid3035348"
        }
    ]},
    "joined": true,
    "clubId": "768777",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:48:52",
    "roomId": "6849808"
}


{
    "stakes": 2,
    "handData": {"200528021300-6849808-0000021-1": [
        {
            "inFantasy": true,
            "playerName": "pid3340617",
            "orderIndex": 1,
            "hero": false,
            "dead": "2c0",
            "rows": "7s0 Kc0 Ks0/2h0 3h0 4c0 5c0 As0/8h0 8d0 8s0 Th0 Ts0",
            "playerId": "pid3340617"
        },
        {
            "inFantasy": false,
            "playerName": "pid3035348",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jc1 7d2 Js3 Qc4",
            "rows": "Kd0 Qh1 Qs1/Ac0 3c2 5h2 Qd3 Ad3/4h0 6h0 6s0 8c4 Tc4",
            "playerId": "pid3035348"
        }
    ]},
    "joined": true,
    "clubId": "768777",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:49:41",
    "roomId": "6849808"
}


{
    "stakes": 2,
    "handData": {"200528021300-6849808-0000022-1": [
        {
            "inFantasy": false,
            "playerName": "pid3340617",
            "orderIndex": 0,
            "hero": false,
            "dead": "2h1 Ts2 Tc3 5s4",
            "rows": "Ad0 As2 Qs4/4d0 6h0 3d2 3h3 3c4/Td0 Jh0 9h1 Qc1 Kd3",
            "playerId": "pid3340617"
        },
        {
            "inFantasy": false,
            "playerName": "pid3317301",
            "orderIndex": 1,
            "hero": false,
            "dead": "2s1 Qh2 5h3 Th4",
            "rows": "Ah0 8s3 Ac3/2d0 8d0 6d2 9d2 7d4/7c0 Kc0 4c1 9c1 4s4",
            "playerId": "pid3317301"
        },
        {
            "inFantasy": false,
            "playerName": "pid3035348",
            "orderIndex": 2,
            "hero": true,
            "dead": "6c1 5c2 5d3 2c4",
            "rows": "Jd1 7h2 7s4/4h0 8h0 Kh0 8c1 Qd3/3s0 6s0 Ks2 9s3 Js4",
            "playerId": "pid3035348"
        }
    ]},
    "joined": true,
    "clubId": "768777",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:51:10",
    "roomId": "6849808"
}


{
    "stakes": 2,
    "handData": {"200528021300-6849808-0000023-1": [
        {
            "inFantasy": true,
            "playerName": "pid3340617",
            "orderIndex": 2,
            "hero": false,
            "dead": "9c0 Tc1 Qd2",
            "rows": "7h0 7c0 7s0/4h0 5h0 9h0 Jh0 Qh0/5s0 8s0 9s0 Js0 As0",
            "playerId": "pid3340617"
        },
        {
            "inFantasy": false,
            "playerName": "pid3317301",
            "orderIndex": 0,
            "hero": false,
            "dead": "3h1 Jd2 Ks3 Ts4",
            "rows": "Qs0 Ac2 Ad3/2h0 4d0 8c2 2c3 8d4/7d0 8h0 5c1 6d1 5d4",
            "playerId": "pid3317301"
        },
        {
            "inFantasy": false,
            "playerName": "pid3035348",
            "orderIndex": 1,
            "hero": true,
            "dead": "3d1 4s2 Ah3 3s4",
            "rows": "Td1 Kh3 Kd4/2s0 6h0 9d0 2d2 6s3/Jc0 Qc0 3c1 4c2 6c4",
            "playerId": "pid3035348"
        }
    ]},
    "joined": true,
    "clubId": "768777",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:52:59",
    "roomId": "6849808"
}


{
    "stakes": 2,
    "handData": {"200528021300-6849808-0000024-1": [
        {
            "inFantasy": true,
            "playerName": "pid3340617",
            "orderIndex": 0,
            "hero": false,
            "dead": "2c0",
            "rows": "3h0 6d0 6s0/Th0 Jh0 Qs0 Ks0 As0/3c0 7c0 Tc0 Jc0 Kc0",
            "playerId": "pid3340617"
        },
        {
            "inFantasy": true,
            "playerName": "pid3035348",
            "orderIndex": 1,
            "hero": true,
            "dead": "3s0 5s0",
            "rows": "Jd0 Js0 Ac0/6c0 7d0 Ts0 Kh0 Kd0/8h0 8d0 8s0 9h0 9d0",
            "playerId": "pid3035348"
        }
    ]},
    "joined": true,
    "clubId": "768777",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:53:36",
    "roomId": "6849808"
}


{
    "stakes": 2,
    "handData": {"200528021300-6849808-0000025-1": [
        {
            "inFantasy": false,
            "playerName": "pid3340617",
            "orderIndex": 2,
            "hero": false,
            "dead": "Ks1 3h2 6c3 7s4",
            "rows": "Ah0 Ac2 6s3/2d0 4c0 5c1 5s1 3s4/Th0 Qd0 Ts2 Tc3 Qc4",
            "playerId": "pid3340617"
        },
        {
            "inFantasy": false,
            "playerName": "pid3317301",
            "orderIndex": 0,
            "hero": false,
            "dead": "2s1 5d2 7h3 As4",
            "rows": "Ad0 4s3 7d4/6d0 3d1 9d1 8c3 8d4/2h0 9h0 Kh0 9s2 Kc2",
            "playerId": "pid3317301"
        },
        {
            "inFantasy": false,
            "playerName": "pid3035348",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qs1 3c2 Jc3 7c4",
            "rows": "Kd1 5h3 Qh4/2c0 4d0 6h0 4h3 Td4/8h0 8s0 Js1 Jh2 Jd2",
            "playerId": "pid3035348"
        }
    ]},
    "joined": true,
    "clubId": "768777",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:55:19",
    "roomId": "6849808"
}


{
    "stakes": 2,
    "handData": {"200528021300-6849808-0000026-1": [
        {
            "inFantasy": false,
            "playerName": "pid3340617",
            "orderIndex": 1,
            "hero": false,
            "dead": "9s1 Js2 Jh3 2s4",
            "rows": "Ah0 Qs2 8c4/4c1 5s1 6d2 5c3 5d4/8d0 9d0 Jd0 Qd0 4d3",
            "playerId": "pid3340617"
        },
        {
            "inFantasy": false,
            "playerName": "pid3317301",
            "orderIndex": 2,
            "hero": false,
            "dead": "Td1 7c2 4s3 7d4",
            "rows": "Ad0 Ac2 As4/2d0 8s0 9c1 Kc3 Ks3/9h0 Kh0 Qh1 4h2 2h4",
            "playerId": "pid3317301"
        },
        {
            "inFantasy": false,
            "playerName": "pid3035348",
            "orderIndex": 0,
            "hero": true,
            "dead": "7h1 2c2 6h3 3s4",
            "rows": "Kd1 5h3 Qc4/3c0 8h0 3h1 3d3 Jc4/6c0 6s0 Tc0 Th2 Ts2",
            "playerId": "pid3035348"
        }
    ]},
    "joined": true,
    "clubId": "768777",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:56:38",
    "roomId": "6849808"
}


{
    "stakes": 2,
    "handData": {"200528021300-6849808-0000027-1": [
        {
            "inFantasy": false,
            "playerName": "pid3340617",
            "orderIndex": 0,
            "hero": false,
            "dead": "9d1 8c2 4c3 5d4",
            "rows": "Kd2 Td3 Ks3/6c0 Qs0 6h1 7d2 Jc4/2h0 4h0 5h0 9h1 9s4",
            "playerId": "pid3340617"
        },
        {
            "inFantasy": false,
            "playerName": "pid3317301",
            "orderIndex": 1,
            "hero": false,
            "dead": "3s1 Kc2 8s3 3d4",
            "rows": "Ac0 As2 Tc3/2s0 6d0 7s0 7c3 4s4/Kh0 8h1 Jh1 7h2 Th4",
            "playerId": "pid3317301"
        },
        {
            "inFantasy": false,
            "playerName": "pid3035348",
            "orderIndex": 2,
            "hero": true,
            "dead": "5s1 Jd2 Qd3 Js4",
            "rows": "Ah1 Ad1 6s4/4d0 Ts0 8d2 Qh3 2d4/3c0 5c0 9c0 2c2 3h3",
            "playerId": "pid3035348"
        }
    ]},
    "joined": true,
    "clubId": "768777",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:58:14",
    "roomId": "6849808"
}


{
    "stakes": 2,
    "handData": {"200528021300-6849808-0000028-1": [
        {
            "inFantasy": false,
            "playerName": "pid3340617",
            "orderIndex": 2,
            "hero": false,
            "dead": "Jd1 Jh2 Ks3 5s4",
            "rows": "Kc0 Ac1 Kd3/6d0 2s1 4d2 4c2 4h3/9c0 Ts0 Js0 6c4 7c4",
            "playerId": "pid3340617"
        },
        {
            "inFantasy": false,
            "playerName": "pid3317301",
            "orderIndex": 0,
            "hero": false,
            "dead": "8d1 8c2 9d3 4s4",
            "rows": "6s2 Qd2 Qc3/2c0 3c0 2d1 5d1 5c4/3d0 7h0 Tc0 3s3 Jc4",
            "playerId": "pid3317301"
        },
        {
            "inFantasy": false,
            "playerName": "pid3035348",
            "orderIndex": 1,
            "hero": true,
            "dead": "9h1 Th2 5h3 2h4",
            "rows": "Qh0 Qs1 Kh4/As1 7s2 Ad2 3h3 Ah3/7d0 8h0 9s0 Td0 6h4",
            "playerId": "pid3035348"
        }
    ]},
    "joined": true,
    "clubId": "768777",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 22:59:45",
    "roomId": "6849808"
}


{
    "stakes": 2,
    "handData": {"200528021300-6849808-0000029-1": [
        {
            "inFantasy": false,
            "playerName": "pid3340617",
            "orderIndex": 1,
            "hero": false,
            "dead": "8c1 3d2 4d3 6s4",
            "rows": "Ks0 Ac2 Td4/2c0 2s0 7s1 2d2 5s3/5h0 8h0 7h1 6h3 2h4",
            "playerId": "pid3340617"
        },
        {
            "inFantasy": false,
            "playerName": "pid3317301",
            "orderIndex": 2,
            "hero": false,
            "dead": "8s1 Ts2 Th3 9d4",
            "rows": "As0 Js2 9h4/5d0 8d0 Qc3 Ad3 Kd4/6c0 Tc0 3c1 9c1 4c2",
            "playerId": "pid3317301"
        },
        {
            "inFantasy": true,
            "playerName": "pid3035348",
            "orderIndex": 0,
            "hero": true,
            "dead": "3s0",
            "rows": "Kh0 Kc0 Ah0/9s0 Jh0 Jc0 Qd0 Qs0/3h0 4h0 5c0 6d0 7d0",
            "playerId": "pid3035348"
        }
    ]},
    "joined": true,
    "clubId": "768777",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 23:01:03",
    "roomId": "6849808"
}


