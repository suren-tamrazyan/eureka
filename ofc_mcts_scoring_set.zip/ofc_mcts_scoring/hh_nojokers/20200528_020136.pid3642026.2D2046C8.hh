{
    "stakes": 30,
    "handData": {"200528020740-6849347-0000000-1": [
        {
            "inFantasy": false,
            "playerName": "pid2970719",
            "orderIndex": 1,
            "hero": false,
            "dead": "Ac1 9c2 8h3 4c4",
            "rows": "Qd0 Ts3 6s4/Kd0 Kh1 3d2 Js3 5h4/4s0 7s0 9s0 Ks1 8s2",
            "playerId": "pid2970719"
        },
        {
            "inFantasy": false,
            "playerName": "pid3642026",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qs1 7h2 Td3 7d4",
            "rows": "3s2 3h3 Tc4/5c0 7c1 2c2 5s3 5d4/2d0 6d0 8d0 Ad0 Jd1",
            "playerId": "pid3642026"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 23:01:36",
    "roomId": "6849347"
}


{
    "stakes": 30,
    "handData": {"200528020740-6849347-0000001-1": [
        {
            "inFantasy": false,
            "playerName": "pid2970719",
            "orderIndex": 0,
            "hero": false,
            "dead": "4d1 3s2 4h3 2h4",
            "rows": "Kh0 Jh2 Ks2/9d0 Ah0 7h1 6h3 Ad4/2c0 Tc0 9c1 Qh3 8c4",
            "playerId": "pid2970719"
        },
        {
            "inFantasy": false,
            "playerName": "pid3642026",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jc1 3d2 5c3 2s4",
            "rows": "6s3 Qd3 Js4/Td0 3c1 4c1 3h2 Ts4/8h0 8s0 9h0 9s0 8d2",
            "playerId": "pid3642026"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 23:03:02",
    "roomId": "6849347"
}


{
    "stakes": 30,
    "handData": {"200528020740-6849347-0000002-1": [
        {
            "inFantasy": false,
            "playerName": "pid2970719",
            "orderIndex": 1,
            "hero": false,
            "dead": "2d1 Jh2 4d3 8h4",
            "rows": "Qd0 7d3 Ah4/3h0 6c2 Td2 Th3 6s4/7c0 9c0 Jc0 9d1 9s1",
            "playerId": "pid2970719"
        },
        {
            "inFantasy": false,
            "playerName": "pid3642026",
            "orderIndex": 0,
            "hero": true,
            "dead": "4c1 Qs2 3d3 Ts4",
            "rows": "Kc2 Kh3 Jd4/5h0 5d1 2c2 2s3 Tc4/3s0 5s0 8s0 Js0 Ks1",
            "playerId": "pid3642026"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 23:04:09",
    "roomId": "6849347"
}


{
    "stakes": 30,
    "handData": {"200528020740-6849347-0000003-1": [
        {
            "inFantasy": false,
            "playerName": "pid2970719",
            "orderIndex": 0,
            "hero": false,
            "dead": "3h1 Ah2 2s3 4c4",
            "rows": "Ks0 Qs1 7h3/9c0 6h1 6s2 9h2 3s3/4d0 Jd0 Qd0 Td4 Kd4",
            "playerId": "pid2970719"
        },
        {
            "inFantasy": true,
            "playerName": "pid3642026",
            "orderIndex": 1,
            "hero": true,
            "dead": "7s0 2d0",
            "rows": "8c0 8s0 Kc0/6d0 6c0 Th0 Tc0 Ts0/5h0 5d0 5c0 5s0 Qh0",
            "playerId": "pid3642026"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 23:05:24",
    "roomId": "6849347"
}


