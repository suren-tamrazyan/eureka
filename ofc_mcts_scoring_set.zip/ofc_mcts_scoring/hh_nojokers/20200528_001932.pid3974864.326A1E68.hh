{
    "stakes": 10,
    "handData": {"200528050559-6862479-0000008-1": [
        {
            "inFantasy": true,
            "playerName": "pid3721422",
            "orderIndex": 1,
            "hero": false,
            "dead": "2d0",
            "rows": "6d0 7d0 Jc0/2s0 6s0 9s0 Ts0 Js0/Qh0 Qd0 Ah0 Ad0 As0",
            "playerId": "pid3721422"
        },
        {
            "inFantasy": false,
            "playerName": "pid1497364",
            "orderIndex": 0,
            "hero": false,
            "dead": "Ac1 2h2 8s3 3d4",
            "rows": "Kd0 Ks1 6c3/7s0 7c1 8d2 8c2 3s4/5d0 5c0 5s0 Jd3 5h4",
            "playerId": "pid1497364"
        }
    ]},
    "joined": false,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 21:19:32",
    "roomId": "6862479"
}


{
    "stakes": 10,
    "handData": {"200528050559-6862479-0000009-1": [
        {
            "inFantasy": false,
            "playerName": "pid3721422",
            "orderIndex": 0,
            "hero": false,
            "dead": "2c1 2s2 4h3 4d4",
            "rows": "Kc0 Ah2 Ks3/5s1 9c1 5d2 Qd3 Qs4/4s0 5h0 6d0 8h0 7s4",
            "playerId": "pid3721422"
        },
        {
            "inFantasy": true,
            "playerName": "pid1497364",
            "orderIndex": 1,
            "hero": false,
            "dead": "9h0 9s1",
            "rows": "Kh0 Kd0 Ac0/7d0 8c0 8s0 Jh0 Js0/6h0 6c0 6s0 Td0 Ts0",
            "playerId": "pid1497364"
        }
    ]},
    "joined": false,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 21:20:23",
    "roomId": "6862479"
}


{
    "stakes": 10,
    "handData": {"200528050559-6862479-0000010-1": [
        {
            "inFantasy": true,
            "playerName": "pid3721422",
            "orderIndex": 1,
            "hero": false,
            "dead": "7h0 8s1",
            "rows": "Kd0 Ad0 Ac0/5h0 5d0 9h0 9s0 Qh0/3c0 7c0 Tc0 Jc0 Qc0",
            "playerId": "pid3721422"
        },
        {
            "inFantasy": false,
            "playerName": "pid1497364",
            "orderIndex": 0,
            "hero": false,
            "dead": "3d1 6d2 3s3 9c4",
            "rows": "Qs1 6s3 Td4/4c0 2d2 Jd2 7s3 4s4/3h0 6h0 Th0 Kh0 8h1",
            "playerId": "pid1497364"
        }
    ]},
    "joined": false,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 21:21:17",
    "roomId": "6862479"
}


