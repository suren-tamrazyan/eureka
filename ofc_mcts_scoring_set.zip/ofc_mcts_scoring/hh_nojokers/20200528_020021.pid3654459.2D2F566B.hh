{
    "stakes": 5,
    "handData": {"200528064014-6870111-0000000-1": [
        {
            "inFantasy": false,
            "playerName": "pid348217",
            "orderIndex": 1,
            "hero": false,
            "dead": "6h1 7c2 Kh3 2s4",
            "rows": "Ks0 Ad1 Ac2/2d0 4d0 4h1 8d3 8s3/Th0 Jc0 9c2 4c4 4s4",
            "playerId": "pid348217"
        },
        {
            "inFantasy": false,
            "playerName": "pid3654459",
            "orderIndex": 0,
            "hero": true,
            "dead": "9h1 7h2 6s3 Js4",
            "rows": "Qd0 Qh2 7d3/2c0 5h0 Ah1 5c2 8c4/3s0 Ts0 3c1 Tc3 6d4",
            "playerId": "pid3654459"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 23:00:21",
    "roomId": "6870111"
}


{
    "stakes": 5,
    "handData": {"200528064014-6870111-0000001-1": [
        {
            "inFantasy": false,
            "playerName": "pid348217",
            "orderIndex": 0,
            "hero": false,
            "dead": "Ts1 Tc2 Js3 2d4",
            "rows": "Ac2 Kh3 Jd4/3d0 3s0 6c0 7h2 9c4/4h0 4s0 9h1 9s1 4d3",
            "playerId": "pid348217"
        },
        {
            "inFantasy": false,
            "playerName": "pid3654459",
            "orderIndex": 1,
            "hero": true,
            "dead": "4c1 2s2 7d3 Kd4",
            "rows": "Ks0 As3 8d4/8c0 Ad0 5c1 5h2 2h3/Th0 Qh0 Qd1 Td2 Qc4",
            "playerId": "pid3654459"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 23:02:10",
    "roomId": "6870111"
}


{
    "stakes": 5,
    "handData": {"200528064014-6870111-0000002-1": [
        {
            "inFantasy": false,
            "playerName": "pid348217",
            "orderIndex": 1,
            "hero": false,
            "dead": "As1 Jd2 7d3 2s4",
            "rows": "Ks0 Ad2 Ac4/2c0 4c0 4s2 2h3 Th3/9d0 9c0 6h1 6d1 8s4",
            "playerId": "pid348217"
        },
        {
            "inFantasy": false,
            "playerName": "pid3654459",
            "orderIndex": 0,
            "hero": true,
            "dead": "3d1 9h2 3h3 4d4",
            "rows": "Ah0 8c4 Js4/2d0 5s0 5c1 Td2 Ts3/Jc0 Kc0 Kd1 7h2 Kh3",
            "playerId": "pid3654459"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 23:03:15",
    "roomId": "6870111"
}


{
    "stakes": 5,
    "handData": {"200528064014-6870111-0000003-1": [
        {
            "inFantasy": true,
            "playerName": "pid348217",
            "orderIndex": 0,
            "hero": false,
            "dead": "8d0 6c1 2d2",
            "rows": "Jh0 Ac0 As0/9c0 Qd0 Qc0 Kc0 Ks0/5d0 6s0 7h0 8s0 9h0",
            "playerId": "pid348217"
        },
        {
            "inFantasy": false,
            "playerName": "pid3654459",
            "orderIndex": 1,
            "hero": true,
            "dead": "Tc1 Td2 2c3 3s4",
            "rows": "Qs2 Jd4 Kd4/3c0 3d1 7d1 5s2 7c3/2h0 4h0 Th0 Qh0 3h3",
            "playerId": "pid3654459"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 23:04:07",
    "roomId": "6870111"
}


{
    "stakes": 5,
    "handData": {"200528064014-6870111-0000004-1": [
        {
            "inFantasy": false,
            "playerName": "pid348217",
            "orderIndex": 1,
            "hero": false,
            "dead": "Th1 Tc2 6h3 7c4",
            "rows": "Kd1 As2 Ad3/5d0 5c0 3c2 5h4 9h4/9d0 Td0 Js0 7d1 8c3",
            "playerId": "pid348217"
        },
        {
            "inFantasy": false,
            "playerName": "pid3654459",
            "orderIndex": 0,
            "hero": true,
            "dead": "Kh1 2d2 2s3 2h4",
            "rows": "Ac0 9s3 Ah4/6d0 Jh0 8s1 Jc2 6s4/Qd0 Qc0 Qs1 Qh2 3h3",
            "playerId": "pid3654459"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 23:05:13",
    "roomId": "6870111"
}


{
    "stakes": 5,
    "handData": {"200528064014-6870111-0000005-1": [
        {
            "inFantasy": true,
            "playerName": "pid348217",
            "orderIndex": 0,
            "hero": false,
            "dead": "8s0 6s1 2d2",
            "rows": "5d0 5c0 5s0/Td0 Tc0 Ts0 Jd0 Kd0/2c0 3c0 9c0 Jc0 Ac0",
            "playerId": "pid348217"
        },
        {
            "inFantasy": true,
            "playerName": "pid3654459",
            "orderIndex": 1,
            "hero": true,
            "dead": "As0 8d0 9s0",
            "rows": "4d0 4c0 4s0/Th0 Js0 Qs0 Kh0 Ah0/3h0 3d0 3s0 7c0 7s0",
            "playerId": "pid3654459"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 23:06:15",
    "roomId": "6870111"
}


{
    "stakes": 5,
    "handData": {"200528064014-6870111-0000006-1": [
        {
            "inFantasy": true,
            "playerName": "pid348217",
            "orderIndex": 1,
            "hero": false,
            "dead": "2s0",
            "rows": "Kd0 Kc0 Ah0/3h0 3s0 5h0 5d0 Jd0/7h0 8c0 9h0 Tc0 Jc0",
            "playerId": "pid348217"
        },
        {
            "inFantasy": true,
            "playerName": "pid3654459",
            "orderIndex": 0,
            "hero": true,
            "dead": "9c0",
            "rows": "Qd0 Qs0 Ks0/2d0 3d0 4h0 5c0 6h0/7s0 8d0 9d0 Ts0 Jh0",
            "playerId": "pid3654459"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 23:07:13",
    "roomId": "6870111"
}


{
    "stakes": 5,
    "handData": {"200528064014-6870111-0000007-1": [
        {
            "inFantasy": false,
            "playerName": "pid348217",
            "orderIndex": 0,
            "hero": false,
            "dead": "Td1 Kh2 8d3 Ac4",
            "rows": "Qs1 3s4 5h4/3h0 6d0 2s2 Jc3 Qc3/7c0 7s0 Js0 7h1 7d2",
            "playerId": "pid348217"
        },
        {
            "inFantasy": false,
            "playerName": "pid2277085",
            "orderIndex": 1,
            "hero": false,
            "dead": "Ts1 Th2 4c3 6s4",
            "rows": "Qd1 6c3 8c4/2h0 2c2 5c2 Ah3 Qh4/9d0 9c0 Kd0 Ks0 Kc1",
            "playerId": "pid2277085"
        },
        {
            "inFantasy": false,
            "playerName": "pid3654459",
            "orderIndex": 2,
            "hero": true,
            "dead": "9h1 4s2 2d3 9s4",
            "rows": "Ad1 3d3 As4/4h0 5d0 6h0 4d1 5s4/8s0 Tc0 Jh2 Jd2 8h3",
            "playerId": "pid3654459"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 23:09:08",
    "roomId": "6870111"
}


{
    "stakes": 5,
    "handData": {"200528064014-6870111-0000008-1": [
        {
            "inFantasy": false,
            "playerName": "pid348217",
            "orderIndex": 2,
            "hero": false,
            "dead": "6c1 3s2 7h3 3d4",
            "rows": "Kh0 Kd1 As3/5h0 5s0 2d1 4s3 Qh4/9h0 Qs0 Jc2 Ks2 Ac4",
            "playerId": "pid348217"
        },
        {
            "inFantasy": false,
            "playerName": "pid2277085",
            "orderIndex": 0,
            "hero": false,
            "dead": "Ts1 3c2 Js3 2c4",
            "rows": "Tc2 8d4 Qd4/6h0 8s0 7c1 7s2 8h3/5d0 9d0 Td0 Jd1 6d3",
            "playerId": "pid2277085"
        },
        {
            "inFantasy": true,
            "playerName": "pid3654459",
            "orderIndex": 1,
            "hero": true,
            "dead": "2s0 3h0 2h0",
            "rows": "4c0 9c0 9s0/4d0 5c0 6s0 7d0 8c0/Th0 Jh0 Qc0 Kc0 Ad0",
            "playerId": "pid3654459"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 23:10:49",
    "roomId": "6870111"
}


{
    "stakes": 5,
    "handData": {"200528064014-6870111-0000009-1": [
        {
            "inFantasy": false,
            "playerName": "pid348217",
            "orderIndex": 1,
            "hero": false,
            "dead": "2c1 9s2 3c3 5h4",
            "rows": "Ah0 Kc2 Th4/5d0 6d0 6s1 8c3 8s3/8h0 Tc0 Qc1 9d2 7d4",
            "playerId": "pid348217"
        },
        {
            "inFantasy": false,
            "playerName": "pid2277085",
            "orderIndex": 2,
            "hero": false,
            "dead": "9c1 7c2 Ac3 3h4",
            "rows": "Qh0 Ks1 9h4/3s0 7h0 As1 Ad2 5c3/2d0 Jd0 Js2 7s3 2h4",
            "playerId": "pid2277085"
        },
        {
            "inFantasy": false,
            "playerName": "pid3654459",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qs1 5s2 6c3 Qd4",
            "rows": "Ts3 Kd3 3d4/4d0 8d0 Td1 4c2 4s2/4h0 6h0 Jh0 Kh1 2s4",
            "playerId": "pid3654459"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 23:11:59",
    "roomId": "6870111"
}


{
    "stakes": 5,
    "handData": {"200528064014-6870111-0000010-1": [
        {
            "inFantasy": false,
            "playerName": "pid348217",
            "orderIndex": 0,
            "hero": false,
            "dead": "5c1 5s2 4h3 3h4",
            "rows": "Qh1 Td3 Qc3/3s0 4s0 7s2 Ks2 Ts4/6c0 8h0 8s0 8d1 8c4",
            "playerId": "pid348217"
        },
        {
            "inFantasy": false,
            "playerName": "pid3654459",
            "orderIndex": 1,
            "hero": true,
            "dead": "9c1 Qs2 9h3 9s4",
            "rows": "Kc0 Kh1 Qd3/6h0 7c1 Ad2 3d4 5h4/2d0 2c0 Tc0 2h2 Kd3",
            "playerId": "pid3654459"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 23:13:29",
    "roomId": "6870111"
}


{
    "stakes": 5,
    "handData": {"200528064014-6870111-0000011-1": [
        {
            "inFantasy": true,
            "playerName": "pid348217",
            "orderIndex": 1,
            "hero": false,
            "dead": "7s0",
            "rows": "8s0 Ah0 As0/9s0 Ts0 Jh0 Qc0 Kc0/8d0 9d0 Td0 Jd0 Qd0",
            "playerId": "pid348217"
        },
        {
            "inFantasy": false,
            "playerName": "pid3654459",
            "orderIndex": 0,
            "hero": true,
            "dead": "Js1 Jc2 2s3 8c4",
            "rows": "Kd0 9h3 Ks4/6c0 4c1 4s1 Th2 Tc3/5h0 5d0 5c0 3d2 Qh4",
            "playerId": "pid3654459"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 23:14:11",
    "roomId": "6870111"
}


{
    "stakes": 5,
    "handData": {"200528064014-6870111-0000012-1": [
        {
            "inFantasy": true,
            "playerName": "pid348217",
            "orderIndex": 0,
            "hero": false,
            "dead": "2c0",
            "rows": "Jh0 Ah0 Ac0/5h0 5s0 Th0 Kh0 Kd0/3c0 6c0 9c0 Jc0 Qc0",
            "playerId": "pid348217"
        },
        {
            "inFantasy": true,
            "playerName": "pid3654459",
            "orderIndex": 1,
            "hero": true,
            "dead": "4h0 2s0",
            "rows": "5c0 Qh0 Qs0/2d0 3d0 9d0 Td0 Qd0/7c0 7s0 8h0 8d0 8s0",
            "playerId": "pid3654459"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 23:15:21",
    "roomId": "6870111"
}


