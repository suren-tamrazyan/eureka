{
    "stakes": 5,
    "handData": {"200528022350-6850654-0000000-1": [
        {
            "inFantasy": false,
            "playerName": "pid2918116",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qc1 7c2 Qh3 4h4",
            "rows": "Ac0 Tc4 Ad4/3d0 3s0 4d0 6h2 6d3/8c0 8s1 Jh1 9s2 8d3",
            "playerId": "pid2918116"
        },
        {
            "inFantasy": false,
            "playerName": "pid3654459",
            "orderIndex": 0,
            "hero": true,
            "dead": "9d1 4s2 5d3 6s4",
            "rows": "7s0 Qs1 Ah3/2h0 8h0 2d1 5s2 9h3/4c0 Jc0 Kc2 6c4 Kd4",
            "playerId": "pid3654459"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 21:16:18",
    "roomId": "6850654"
}


{
    "stakes": 5,
    "handData": {"200528022350-6850654-0000001-1": [
        {
            "inFantasy": true,
            "playerName": "pid2918116",
            "orderIndex": 0,
            "hero": false,
            "dead": "8s0 3h1 3d2",
            "rows": "Qs0 Ah0 Ad0/4h0 5c0 6c0 7s0 8c0/9s0 Th0 Jh0 Qc0 Ks0",
            "playerId": "pid2918116"
        },
        {
            "inFantasy": false,
            "playerName": "pid3654459",
            "orderIndex": 1,
            "hero": true,
            "dead": "2s1 As2 Tc3 Qd4",
            "rows": "Kc0 Kd2 Ac3/5d0 6s1 7c1 3c2 Jd4/6h0 9h0 Qh0 2h3 4s4",
            "playerId": "pid3654459"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 21:17:11",
    "roomId": "6850654"
}


