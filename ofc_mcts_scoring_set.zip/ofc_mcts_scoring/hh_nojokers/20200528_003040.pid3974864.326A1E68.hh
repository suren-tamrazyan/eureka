{
    "stakes": 10,
    "handData": {"200528052814-6864187-0000000-1": [
        {
            "inFantasy": false,
            "playerName": "pid3317301",
            "orderIndex": 2,
            "hero": false,
            "dead": "8s1 3c2 Qc3 2h4",
            "rows": "Ks0 Kc3 Qd4/6c0 7s0 6h1 4h2 Ad4/5d0 Jd0 Td1 9d2 Kd3",
            "playerId": "pid3317301"
        },
        {
            "inFantasy": false,
            "playerName": "pid3974864",
            "orderIndex": 0,
            "hero": true,
            "dead": "2d1 9c2 6d3 4c4",
            "rows": "7c3 Ah3 8h4/3h0 3s0 8d0 9h1 3d2/Ts0 Js0 6s1 2s2 9s4",
            "playerId": "pid3974864"
        },
        {
            "inFantasy": false,
            "playerName": "pid3997701",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jc1 Qs2 Jh3 7h4",
            "rows": "As2 Ac3 5c4/4d0 7d0 4s1 5h1 5s2/8c0 Th0 Tc0 Kh3 2c4",
            "playerId": "pid3997701"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 21:30:40",
    "roomId": "6864187"
}


{
    "stakes": 10,
    "handData": {"200528052814-6864187-0000001-1": [
        {
            "inFantasy": false,
            "playerName": "pid3317301",
            "orderIndex": 1,
            "hero": false,
            "dead": "3d1 As2 Jc3 7c4",
            "rows": "Kd0 Ks0 Ac4/2d0 5h0 6d0 2h2 5d2/9h1 9d1 4h3 4s3 Ts4",
            "playerId": "pid3317301"
        },
        {
            "inFantasy": false,
            "playerName": "pid3974864",
            "orderIndex": 2,
            "hero": true,
            "dead": "Qs1 5c2 4d3 Jd4",
            "rows": "Kh0 Kc0 Qd2/7s0 3h1 3c1 4c4 Tc4/8s0 9s0 Th2 6s3 7d3",
            "playerId": "pid3974864"
        },
        {
            "inFantasy": false,
            "playerName": "pid3997701",
            "orderIndex": 0,
            "hero": false,
            "dead": "6c1 8c2 Ah3 8d4",
            "rows": "Qc0 Ad1 Td4/7h1 Jh2 Qh2 6h3 8h3/2s0 3s0 5s0 Js0 9c4",
            "playerId": "pid3997701"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 21:32:51",
    "roomId": "6864187"
}


{
    "stakes": 10,
    "handData": {"200528052814-6864187-0000002-1": [
        {
            "inFantasy": true,
            "playerName": "pid3317301",
            "orderIndex": 0,
            "hero": false,
            "dead": "3d0 4s1",
            "rows": "Td0 Ad0 Ac0/7c0 9h0 9d0 Qd0 Qs0/5c0 5s0 Kd0 Kc0 Ks0",
            "playerId": "pid3317301"
        },
        {
            "inFantasy": false,
            "playerName": "pid3974864",
            "orderIndex": 1,
            "hero": true,
            "dead": "4c1 Jh2 5d3 3c4",
            "rows": "7d3 7s4 9s4/8d0 2s1 6d2 6c2 2d3/3h0 8h0 Qh0 Kh0 4h1",
            "playerId": "pid3974864"
        },
        {
            "inFantasy": false,
            "playerName": "pid3997701",
            "orderIndex": 2,
            "hero": false,
            "dead": "8c1 Jc2 2c3 2h4",
            "rows": "Ah0 9c3 8s4/7h0 3s2 6s2 Js3 As4/Th0 Jd0 Qc0 Tc1 Ts1",
            "playerId": "pid3997701"
        }
    ]},
    "joined": true,
    "clubId": "19320",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2020-05-27 21:34:26",
    "roomId": "6864187"
}


