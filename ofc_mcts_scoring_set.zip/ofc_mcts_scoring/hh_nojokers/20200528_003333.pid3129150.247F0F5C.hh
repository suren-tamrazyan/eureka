{
    "stakes": 10,
    "handData": {"200528051140-6862981-0000009-1": [
        {
            "inFantasy": false,
            "playerName": "pid3129150",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qc1 4h2 5h3 6c4",
            "rows": "Kd2 Ac2 Js4/8d0 9h0 8c1 3d3 3c4/5s0 7s0 Ks0 6s1 9s3",
            "playerId": "pid3129150"
        },
        {
            "inFantasy": false,
            "playerName": "pid3744876",
            "orderIndex": 0,
            "hero": false,
            "dead": "Td1 Th2 2s3 3s4",
            "rows": "Ah2 7h3 Kc4/4d0 6h0 9d2 4s3 Ad4/9c0 Tc0 Jc0 8h1 Qs1",
            "playerId": "pid3744876"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 21:33:33",
    "roomId": "6862981"
}


{
    "stakes": 10,
    "handData": {"200528051140-6862981-0000010-1": [
        {
            "inFantasy": false,
            "playerName": "pid3129150",
            "orderIndex": 0,
            "hero": true,
            "dead": "2c1 Qs2 5c3 Th4",
            "rows": "Ad0 Ah2 6d3/7s0 Js0 4d3 4c4 9d4/9c0 Kc0 7c1 Tc1 Ac2",
            "playerId": "pid3129150"
        },
        {
            "inFantasy": false,
            "playerName": "pid3744876",
            "orderIndex": 1,
            "hero": false,
            "dead": "8h1 2d2 Qh3 3h4",
            "rows": "As0 7d4 8c4/5h0 6h0 5d1 3c2 5s3/Ts0 Qc0 Jh1 9s2 8d3",
            "playerId": "pid3744876"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 21:34:31",
    "roomId": "6862981"
}


{
    "stakes": 10,
    "handData": {"200528051140-6862981-0000011-1": [
        {
            "inFantasy": false,
            "playerName": "pid3129150",
            "orderIndex": 1,
            "hero": true,
            "dead": "Td1 Kc2 3c3 3h4",
            "rows": "Qs0 Kd1 Ah3/2h0 7s1 2c2 8c3 8d4/9h0 9c0 Jc0 Jh2 7d4",
            "playerId": "pid3129150"
        },
        {
            "inFantasy": false,
            "playerName": "pid3744876",
            "orderIndex": 0,
            "hero": false,
            "dead": "6d1 Qh2 Ac3 3d4",
            "rows": "Qc0 Kh1 As4/2s0 5d0 2d2 3s3 5c3/8h0 Tc0 9s1 7h2 5h4",
            "playerId": "pid3744876"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 21:36:13",
    "roomId": "6862981"
}


{
    "stakes": 10,
    "handData": {"200528051140-6862981-0000012-1": [
        {
            "inFantasy": false,
            "playerName": "pid3129150",
            "orderIndex": 0,
            "hero": true,
            "dead": "6s1 Qd2 8s3 Kc4",
            "rows": "Qh0 As2 9c4/3h0 7d0 8d1 8h2 3d3/4s0 Js0 Jd1 Td3 8c4",
            "playerId": "pid3129150"
        },
        {
            "inFantasy": false,
            "playerName": "pid3744876",
            "orderIndex": 1,
            "hero": false,
            "dead": "Ac1 5d2 Jh3 3s4",
            "rows": "Ks0 Ah2 6c4/2h0 4c0 2c1 4h1 5c4/7c0 Ts0 9s2 7s3 Th3",
            "playerId": "pid3744876"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 21:37:04",
    "roomId": "6862981"
}


{
    "stakes": 10,
    "handData": {"200528051140-6862981-0000013-1": [
        {
            "inFantasy": false,
            "playerName": "pid3129150",
            "orderIndex": 1,
            "hero": true,
            "dead": "7c1 4d2 2s3 Ts4",
            "rows": "As0 9h3 9s4/3s0 5d0 5c0 5h1 Jh4/Td0 8d1 8h2 8s2 Th3",
            "playerId": "pid3129150"
        },
        {
            "inFantasy": false,
            "playerName": "pid3744876",
            "orderIndex": 0,
            "hero": false,
            "dead": "7h1 3h2 Qc3 2h4",
            "rows": "Qd1 Ks2 Kc4/Jd0 9c1 6h2 6d3 Js3/4s0 6c0 7s0 8c0 Jc4",
            "playerId": "pid3744876"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 21:38:39",
    "roomId": "6862981"
}


{
    "stakes": 10,
    "handData": {"200528051140-6862981-0000014-1": [
        {
            "inFantasy": false,
            "playerName": "pid3129150",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qh1 Td2 4s3 5h4",
            "rows": "Kh0 Kd2 Qs4/2c0 Ad0 Ac0 4h3 5s3/9s0 8h1 Jc1 Jd2 8c4",
            "playerId": "pid3129150"
        },
        {
            "inFantasy": false,
            "playerName": "pid3744876",
            "orderIndex": 1,
            "hero": false,
            "dead": "2s1 2d2 5c3 Qc4",
            "rows": "Qd1 Ts2 8s3/7c0 9d0 7h1 4c2 3s3/2h0 3h0 Ah0 4d4 5d4",
            "playerId": "pid3744876"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 21:39:54",
    "roomId": "6862981"
}


{
    "stakes": 10,
    "handData": {"200528051140-6862981-0000015-1": [
        {
            "inFantasy": true,
            "playerName": "pid3129150",
            "orderIndex": 1,
            "hero": true,
            "dead": "6c0 2h0",
            "rows": "4h0 4c0 7h0/2s0 3s0 8s0 Js0 Qs0/3d0 6d0 9d0 Kd0 Ad0",
            "playerId": "pid3129150"
        },
        {
            "inFantasy": false,
            "playerName": "pid3744876",
            "orderIndex": 0,
            "hero": false,
            "dead": "Kc1 Qc2 5h3 3c4",
            "rows": "Ac0 Kh3 Ks3/4d1 4s1 Jd2 Jc2 5s4/6h0 7s0 9h0 Tc0 Qd4",
            "playerId": "pid3744876"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 21:40:54",
    "roomId": "6862981"
}


{
    "stakes": 10,
    "handData": {"200528051140-6862981-0000016-1": [
        {
            "inFantasy": false,
            "playerName": "pid3129150",
            "orderIndex": 0,
            "hero": true,
            "dead": "7s1 Jd2 7c3 6s4",
            "rows": "As1 7d3 Jh4/4c0 5h0 4d1 9s2 4h4/Th0 Td0 Ts0 3s2 Tc3",
            "playerId": "pid3129150"
        },
        {
            "inFantasy": false,
            "playerName": "pid3744876",
            "orderIndex": 1,
            "hero": false,
            "dead": "8c1 6c2 Ah3 3c4",
            "rows": "Kc0 8h2 Ks2/6h0 8s0 6d1 8d1 5d4/Js0 Qd0 2s3 Jc3 9c4",
            "playerId": "pid3744876"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 21:42:07",
    "roomId": "6862981"
}


{
    "stakes": 10,
    "handData": {"200528051140-6862981-0000017-1": [
        {
            "inFantasy": false,
            "playerName": "pid3129150",
            "orderIndex": 1,
            "hero": true,
            "dead": "Ad1 2d2 Ac3 Jd4",
            "rows": "As0 Ah1 Jh4/3s0 6c0 6s1 4c2 6h3/8d0 Js0 9c2 Qc3 7c4",
            "playerId": "pid3129150"
        },
        {
            "inFantasy": false,
            "playerName": "pid3744876",
            "orderIndex": 0,
            "hero": false,
            "dead": "Ts1 5s2 Jc3 Kd4",
            "rows": "Ks1 Qd2 Kc4/2s0 5h0 5c0 2h1 4d3/7h0 7s0 9h2 8s3 8h4",
            "playerId": "pid3744876"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 21:43:44",
    "roomId": "6862981"
}


{
    "stakes": 10,
    "handData": {"200528051140-6862981-0000018-1": [
        {
            "inFantasy": false,
            "playerName": "pid3129150",
            "orderIndex": 0,
            "hero": true,
            "dead": "7c1 Qc2 9c3 3c4",
            "rows": "Ad0 Qd3 Kh4/6h0 6s0 Ts2 6c3 7d4/5h0 9h0 7h1 Jh1 3h2",
            "playerId": "pid3129150"
        },
        {
            "inFantasy": true,
            "playerName": "pid3744876",
            "orderIndex": 1,
            "hero": false,
            "dead": "2c0 Tc1",
            "rows": "Kc0 Ac0 As0/3s0 5s0 7s0 9s0 Js0/2h0 8h0 Th0 Qh0 Ah0",
            "playerId": "pid3744876"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 21:44:52",
    "roomId": "6862981"
}


{
    "stakes": 10,
    "handData": {"200528051140-6862981-0000019-1": [
        {
            "inFantasy": false,
            "playerName": "pid3129150",
            "orderIndex": 1,
            "hero": true,
            "dead": "5s1 8s2 9d3 8h4",
            "rows": "Kh1 9s2 3c3/Th0 2s1 Ah2 2h3 Jd4/4d0 4s0 6d0 6c0 7c4",
            "playerId": "pid3129150"
        },
        {
            "inFantasy": false,
            "playerName": "pid3744876",
            "orderIndex": 0,
            "hero": false,
            "dead": "7h1 Qs2 6h3 7s4",
            "rows": "Ks1 As2 Kd3/5c0 3s1 5d2 2c3 4c4/8d0 Td0 Js0 Qc0 Jh4",
            "playerId": "pid3744876"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 21:46:35",
    "roomId": "6862981"
}


{
    "stakes": 10,
    "handData": {"200528051140-6862981-0000020-1": [
        {
            "inFantasy": false,
            "playerName": "pid3129150",
            "orderIndex": 0,
            "hero": true,
            "dead": "3c1 8c2 7c3 Tc4",
            "rows": "Kd0 As2 Td4/2c0 5d0 3h1 5h1 Qd4/Ts0 Jc0 Js2 4h3 4s3",
            "playerId": "pid3129150"
        },
        {
            "inFantasy": false,
            "playerName": "pid3744876",
            "orderIndex": 1,
            "hero": false,
            "dead": "5c1 3s2 4d3 6s4",
            "rows": "Kh1 Kc2 Jd3/2d0 6c0 6d1 7h2 7d3/9d0 Qh0 Qc0 5s4 Ad4",
            "playerId": "pid3744876"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 21:47:45",
    "roomId": "6862981"
}


{
    "stakes": 10,
    "handData": {"200528051140-6862981-0000021-1": [
        {
            "inFantasy": false,
            "playerName": "pid3129150",
            "orderIndex": 1,
            "hero": true,
            "dead": "7s1 Tc2 9s3 Ts4",
            "rows": "Kc2 Ac2 7c4/3d0 4c0 5h0 5c1 4s3/6h0 6s0 Js1 9d3 Jd4",
            "playerId": "pid3129150"
        },
        {
            "inFantasy": false,
            "playerName": "pid3744876",
            "orderIndex": 0,
            "hero": false,
            "dead": "9h1 6c2 Th3 Ks4",
            "rows": "Qs0 Kh2 Qc3/3c0 5s0 4h1 Ah2 As3/7h0 8d0 8c1 6d4 8s4",
            "playerId": "pid3744876"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 21:49:09",
    "roomId": "6862981"
}


{
    "stakes": 10,
    "handData": {"200528051140-6862981-0000022-1": [
        {
            "inFantasy": false,
            "playerName": "pid3129150",
            "orderIndex": 0,
            "hero": true,
            "dead": "9d1 9c2 4s3 2s4",
            "rows": "Qc2 5c4 8s4/3d0 5d1 7s2 Kh3 Kc3/2h0 Th0 Jh0 Qh0 8h1",
            "playerId": "pid3129150"
        },
        {
            "inFantasy": true,
            "playerName": "pid3744876",
            "orderIndex": 1,
            "hero": false,
            "dead": "5h0",
            "rows": "Ks0 Ad0 As0/7h0 7d0 9h0 9s0 Qd0/3c0 4c0 6c0 8c0 Jc0",
            "playerId": "pid3744876"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 21:50:02",
    "roomId": "6862981"
}


{
    "stakes": 10,
    "handData": {"200528051140-6862981-0000023-1": [
        {
            "inFantasy": false,
            "playerName": "pid3129150",
            "orderIndex": 1,
            "hero": true,
            "dead": "2d1 3d2 Tc3 7d4",
            "rows": "Kc0 5c2 Kh3/6h0 Ah1 8h2 3h3 6s4/5s0 Qs0 As0 7s1 6d4",
            "playerId": "pid3129150"
        },
        {
            "inFantasy": false,
            "playerName": "pid3744876",
            "orderIndex": 0,
            "hero": false,
            "dead": "6c1 5d2 Qh3 8s4",
            "rows": "Ks1 Ts4 Qc4/2c0 4s1 3c2 4c2 2s3/7c0 8d0 Td0 Jh0 9s3",
            "playerId": "pid3744876"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 21:51:36",
    "roomId": "6862981"
}


{
    "stakes": 10,
    "handData": {"200528051140-6862981-0000024-1": [
        {
            "inFantasy": false,
            "playerName": "pid3129150",
            "orderIndex": 0,
            "hero": true,
            "dead": "6s1 8h2 Jd3 9d4",
            "rows": "Kd0 Ks3 7s4/2h0 Th0 7h2 Qh3 3d4/9c0 Jc0 7c1 Qc1 Kc2",
            "playerId": "pid3129150"
        },
        {
            "inFantasy": false,
            "playerName": "pid3744876",
            "orderIndex": 1,
            "hero": false,
            "dead": "Ac1 6h2 Js3 9s4",
            "rows": "7d2 Ad4 As4/3h0 6d0 6c1 3s2 4d3/8c0 Td0 Ts0 8s1 5d3",
            "playerId": "pid3744876"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 21:52:52",
    "roomId": "6862981"
}


{
    "stakes": 10,
    "handData": {"200528051140-6862981-0000025-1": [
        {
            "inFantasy": false,
            "playerName": "pid3129150",
            "orderIndex": 1,
            "hero": true,
            "dead": "Kd1 Ts2 9c3 3h4",
            "rows": "As1 9d4 Ah4/6c0 3s1 4d2 5s3 7s3/7h0 8s0 Tc0 Js0 9h2",
            "playerId": "pid3129150"
        },
        {
            "inFantasy": true,
            "playerName": "pid3744876",
            "orderIndex": 0,
            "hero": false,
            "dead": "9s0 Kh1 Qc2",
            "rows": "2h0 2c0 2s0/4h0 4c0 4s0 5c0 8h0/3d0 5d0 8d0 Qd0 Ad0",
            "playerId": "pid3744876"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 21:53:43",
    "roomId": "6862981"
}


{
    "stakes": 10,
    "handData": {"200528051140-6862981-0000026-1": [
        {
            "inFantasy": true,
            "playerName": "pid3129150",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jd0 2c0 9d0",
            "rows": "Qd0 Qs0 Kc0/2d0 3d0 4c0 5h0 6c0/2s0 5s0 6s0 9s0 Js0",
            "playerId": "pid3129150"
        },
        {
            "inFantasy": true,
            "playerName": "pid3744876",
            "orderIndex": 1,
            "hero": false,
            "dead": "7d0 5d1 3s2",
            "rows": "Kh0 Ks0 As0/6h0 7h0 8s0 9h0 Th0/5c0 7c0 8c0 Tc0 Ac0",
            "playerId": "pid3744876"
        }
    ]},
    "joined": true,
    "clubId": "977180",
    "rules": "progressive17_nojokers",
    "endDateTime": "2020-05-27 21:55:03",
    "roomId": "6862981"
}


