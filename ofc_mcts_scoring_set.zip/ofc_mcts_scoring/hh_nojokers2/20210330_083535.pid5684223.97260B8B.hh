{
    "stakes": 20,
    "handData": {"210330125914-21936391-0000002-1": [
        {
            "inFantasy": false,
            "result": -7,
            "playerName": "pid2634961",
            "orderIndex": 1,
            "hero": false,
            "dead": "3c1 2h2 4s3 Jd4",
            "rows": "2d2 Ac2 2s4/7s0 8s0 8c1 3h3 Td4/6c0 9h0 9c0 6h1 Ks3",
            "win": -140,
            "playerId": "pid2634961"
        },
        {
            "inFantasy": false,
            "result": 7,
            "playerName": "pid5684223",
            "orderIndex": 0,
            "hero": true,
            "dead": "3d1 7c2 Kd3 4h4",
            "rows": "7h2 Ah2 Js4/9d0 Jh0 4d1 8h3 8d3/5h0 Qh0 Qs0 5s1 Qc4",
            "win": 136,
            "playerId": "pid5684223"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:35:35",
    "roomId": "21936391"
}


{
    "stakes": 20,
    "handData": {"210330125914-21936391-0000003-1": [
        {
            "inFantasy": false,
            "result": 23,
            "playerName": "pid2634961",
            "orderIndex": 0,
            "hero": false,
            "dead": "7c1 2h2 2d3 Kh4",
            "rows": "As0 Kc1 Ac2/4d0 6h0 4s2 3d3 6d4/9c0 9s0 Jh1 Qh3 Jc4",
            "win": 446,
            "playerId": "pid2634961"
        },
        {
            "inFantasy": false,
            "result": -23,
            "playerName": "pid301738",
            "orderIndex": 1,
            "hero": false,
            "dead": "Js1 8s2 9d3 4c4",
            "rows": "Kd0 Ks2 Ah4/7d0 8c0 7h1 8h1 Ts3/5d0 5s0 Qd2 Jd3 8d4",
            "win": -460,
            "playerId": "pid301738"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5684223",
            "orderIndex": 2,
            "hero": true,
            "dead": "5c1 Td2 7s3 6c4",
            "rows": "Ad0 9h3 3s4/Tc0 Qc0 Th1 2c3 3h4/4h0 5h0 2s1 3c2 6s2",
            "win": 0,
            "playerId": "pid5684223"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:37:48",
    "roomId": "21936391"
}


{
    "stakes": 20,
    "handData": {"210330125914-21936391-0000004-1": [
        {
            "inFantasy": true,
            "result": 27,
            "playerName": "pid2634961",
            "orderIndex": 2,
            "hero": false,
            "dead": "4s0 5d1 3s2",
            "rows": "Td0 Kd0 Ks0/4c0 6c0 7c0 8c0 Qc0/2h0 8h0 9h0 Th0 Ah0",
            "win": 524,
            "playerId": "pid2634961"
        },
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid301738",
            "orderIndex": 0,
            "hero": false,
            "dead": "8s1 Tc2 As3 2c4",
            "rows": "Ac1 Ad2 3h3/4d0 7s0 7d1 9d2 9s3/5h0 5s0 Jd0 5c4 6d4",
            "win": -160,
            "playerId": "pid301738"
        },
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid5684223",
            "orderIndex": 1,
            "hero": true,
            "dead": "2s1 Qd2 2d3 6s4",
            "rows": "Kc2 6h3 4h4/3d0 7h0 8d2 3c3 Kh4/Jh0 Js0 Qs0 Jc1 Qh1",
            "win": -380,
            "playerId": "pid5684223"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:39:40",
    "roomId": "21936391"
}


{
    "stakes": 20,
    "handData": {"210330125914-21936391-0000005-1": [
        {
            "inFantasy": false,
            "result": 20,
            "playerName": "pid2634961",
            "orderIndex": 1,
            "hero": false,
            "dead": "5d1 Ad2 Qs3 7d4",
            "rows": "Qc1 Qd2 3h3/2d0 Th0 Ts1 7c3 Td4/4h0 4c0 Jh0 Jc2 4d4",
            "win": 388,
            "playerId": "pid2634961"
        },
        {
            "inFantasy": true,
            "result": 22,
            "playerName": "pid301738",
            "orderIndex": 2,
            "hero": false,
            "dead": "6c0 9s1 2s2",
            "rows": "Qh0 Ah0 As0/5h0 5c0 Tc0 Jd0 Js0/3d0 3s0 8h0 8d0 8c0",
            "win": 345,
            "playerId": "pid301738"
        },
        {
            "inFantasy": false,
            "result": -42,
            "playerName": "pid5684223",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h1 4s2 Kh3 8s4",
            "rows": "Kd0 Kc2 7s3/2c0 3c0 Ac2 5s4 6s4/6h0 6d0 9h1 9c1 9d3",
            "win": -756,
            "playerId": "pid5684223"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:41:13",
    "roomId": "21936391"
}


{
    "stakes": 20,
    "handData": {"210330125914-21936391-0000006-1": [
        {
            "inFantasy": true,
            "result": 17,
            "playerName": "pid2634961",
            "orderIndex": 1,
            "hero": false,
            "dead": "4c0",
            "rows": "Qd0 Qc0 Ah0/3h0 3d0 5d0 5c0 8c0/2s0 4s0 Ts0 Js0 As0",
            "win": 330,
            "playerId": "pid2634961"
        },
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid301738",
            "orderIndex": 0,
            "hero": false,
            "dead": "5s1 3s2 Tc3 Ad4",
            "rows": "Ac0 5h2 3c4/Td0 8h1 9s1 Th2 4h3/7d0 7c0 Qh0 Jh3 Jc4",
            "win": -340,
            "playerId": "pid301738"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": false,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:42:05",
    "roomId": "21936391"
}


{
    "stakes": 20,
    "handData": {"210330125914-21936391-0000007-1": [
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid301738",
            "orderIndex": 1,
            "hero": false,
            "dead": "3c1 3h2 3s3 Kd4",
            "rows": "Ad0 6d2 Ah3/2c0 4d0 8h1 8d1 Jc4/Tc0 Jh0 7c2 9d3 Qh4",
            "win": -385,
            "playerId": "pid301738"
        },
        {
            "inFantasy": false,
            "result": 20,
            "playerName": "pid5684223",
            "orderIndex": 0,
            "hero": true,
            "dead": "6h1 9c2 7s3 5c4",
            "rows": "7h3 Td4 Kh4/2s0 Ts0 As1 8s2 6s3/5d0 Qd0 Qs0 5h1 5s2",
            "win": 373,
            "playerId": "pid5684223"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:43:10",
    "roomId": "21936391"
}


