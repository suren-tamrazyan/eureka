{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000044-1": [
        {
            "inFantasy": false,
            "result": 2,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "Ks1 4c2 3s3 4s4",
            "rows": "Ad0 As1 6s3/7c0 7s0 9d2 9s2 Ac4/8d0 8s0 8c1 Js3 Kh4",
            "win": 0.4,
            "playerId": "pid2923305"
        },
        {
            "inFantasy": false,
            "result": -2,
            "playerName": "pid5353395",
            "orderIndex": 1,
            "hero": false,
            "dead": "4h1 2d2 4d3 5c4",
            "rows": "7h3 6c4 Tc4/Th0 Jc0 5s1 Ts1 5d2/2h0 Qh0 Qs0 2c2 2s3",
            "win": -0.4,
            "playerId": "pid5353395"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": false,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 11:18:20",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000045-1": [
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "6d0 3s1 2d2",
            "rows": "7c0 Ah0 Ac0/8h0 9c0 Td0 Jh0 Qc0/5s0 6s0 7s0 8s0 Ts0",
            "win": 4.1,
            "playerId": "pid2923305"
        },
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "pid5353395",
            "orderIndex": 0,
            "hero": false,
            "dead": "4h1 Js2 9d3 7h4",
            "rows": "Ad0 Qs3 9h4/3d0 5h0 3c1 2c2 2h4/9s0 Jc0 Tc1 Qh2 Kh3",
            "win": -4.2,
            "playerId": "pid5353395"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": false,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 11:18:55",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000046-1": [
        {
            "inFantasy": false,
            "result": 17,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "3s1 9d2 9s3 2h4",
            "rows": "Th2 As3 Ts4/7d0 8h0 8c0 2d1 7s4/Tc0 Jc0 3c1 6c2 Qc3",
            "win": 3.3,
            "playerId": "pid2923305"
        },
        {
            "inFantasy": false,
            "result": -29,
            "playerName": "pid5684470",
            "orderIndex": 1,
            "hero": true,
            "dead": "7h1 7c2 Td3 Kd4",
            "rows": "Ad0 Ah1 8s4/4h0 6s0 4c2 5s2 5c3/9c0 Jh0 Js1 3d3 4s4",
            "win": -5.8,
            "playerId": "pid5684470"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid5353395",
            "orderIndex": 2,
            "hero": false,
            "dead": "8d1 Jd2 Ks3 4d4",
            "rows": "Kh0 Kc2 Ac4/2s0 5h0 2c1 3h2 5d3/9h0 Qs0 Qh1 Qd3 6h4",
            "win": 2.3,
            "playerId": "pid5353395"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 11:20:24",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000047-1": [
        {
            "inFantasy": false,
            "result": -26,
            "playerName": "pid2923305",
            "orderIndex": 2,
            "hero": false,
            "dead": "4h1 2s2 4s3 7c4",
            "rows": "Ks0 Ac1 Th3/3c0 8d0 9h1 3h2 5h3/Jh0 Qs0 Qd2 Tc4 Js4",
            "win": -5.2,
            "playerId": "pid2923305"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5684470",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jd1 6s2 5s3 8h4",
            "rows": "As1 Qh2 Jc4/2c0 Kd1 Ts2 Kh3 Kc4/4d0 5c0 6d0 7s0 3d3",
            "win": -2.4,
            "playerId": "pid5684470"
        },
        {
            "inFantasy": true,
            "result": 38,
            "playerName": "pid5353395",
            "orderIndex": 1,
            "hero": false,
            "dead": "2d0 9c1",
            "rows": "Qc0 Ah0 Ad0/2h0 3s0 4c0 5d0 6c0/6h0 7d0 8s0 9s0 Td0",
            "win": 7.4,
            "playerId": "pid5353395"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 11:21:24",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000048-1": [
        {
            "inFantasy": false,
            "result": 4,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "Ks1 Qh2 7s3 Td4",
            "rows": "Ah0 Ts3 Kc4/Js0 4s1 4d2 3c3 5s4/2c0 6c0 Tc0 Jc1 5c2",
            "win": 0.8,
            "playerId": "pid2923305"
        },
        {
            "inFantasy": false,
            "result": 16,
            "playerName": "pid5684470",
            "orderIndex": 2,
            "hero": true,
            "dead": "As1 4c2 Jh3 3h4",
            "rows": "2s1 7d3 2h4/4h0 8h0 9c2 9s2 8s4/3d0 Qd0 Kd0 5d1 6d3",
            "win": 3.1,
            "playerId": "pid5684470"
        },
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid5353395",
            "orderIndex": 0,
            "hero": false,
            "dead": "2d1 5h2 Jd3 Th4",
            "rows": "Ad0 Ac0 Qs3/6h0 3s1 6s2 9h4 Kh4/8d0 9d0 7c1 7h2 8c3",
            "win": -4,
            "playerId": "pid5353395"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 11:22:59",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000049-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "2c1 5c2 2d3 Ad4",
            "rows": "Kh1 7s2 Kc2/4h0 Th0 3d1 5s3 5h4/6h0 6d0 Qd0 9h3 3c4",
            "win": -1.2,
            "playerId": "pid2923305"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5684470",
            "orderIndex": 0,
            "hero": true,
            "dead": "4s1 9s2 3h3 4c4",
            "rows": "Ah0 Ks3 3s4/2s0 6c0 5d1 2h3 Qh4/Jd0 Qc0 8s1 8d2 Jh2",
            "win": 1.2,
            "playerId": "pid5684470"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 11:23:59",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000050-1": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "8h1 3c2 4h3 3s4",
            "rows": "Ad0 Kh1 8c4/2h0 2d2 6d2 6c3 6h4/7d0 7c0 Td0 Ts1 7s3",
            "win": 2.3,
            "playerId": "pid2923305"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5684470",
            "orderIndex": 1,
            "hero": true,
            "dead": "9h1 Jc2 Kd3 Tc4",
            "rows": "Qd1 Jd2 Qh4/4c0 5h0 2c1 4d2 5s3/3h0 3d0 8d0 Ac3 As4",
            "win": -2.4,
            "playerId": "pid5684470"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 11:25:26",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000051-1": [
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "5s1 Qc2 3d3 6c4",
            "rows": "Kd0 Kc0 As3/6d0 Ad1 Ac1 3s2 2c4/4h0 9h0 9d2 Th3 6s4",
            "win": -4,
            "playerId": "pid2923305"
        },
        {
            "inFantasy": true,
            "result": 20,
            "playerName": "pid5684470",
            "orderIndex": 0,
            "hero": true,
            "dead": "4d0",
            "rows": "8d0 Qh0 Ah0/3c0 4c0 5c0 7c0 9c0/5h0 5d0 Jh0 Jc0 Js0",
            "win": 3.9,
            "playerId": "pid5684470"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 11:26:01",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000052-1": [
        {
            "inFantasy": false,
            "result": 2,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "Kd1 7c2 Tc3 6h4",
            "rows": "As1 Td2 3d3/5s0 9s0 2s1 9d3 2c4/2h0 3h0 Jh0 Qh2 7h4",
            "win": 0.4,
            "playerId": "pid2923305"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5684470",
            "orderIndex": 2,
            "hero": true,
            "dead": "6d1 7s2 6c3 9c4",
            "rows": "Kh0 Js3 Jd4/4h0 5c0 5d1 4c3 Qs4/9h0 Ts0 8h1 8c2 Th2",
            "win": 1.2,
            "playerId": "pid5684470"
        },
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "2d1 3s2 3c3 Kc4",
            "rows": "Ac2 Ks3 8s4/Jc0 Qd1 Qc1 4d3 Ah4/5h0 6s0 7d0 8d0 4s2",
            "win": -1.6,
            "playerId": "pid1087966"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 11:27:48",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000053-1": [
        {
            "inFantasy": false,
            "result": -13,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "7c1 4c2 8d3 Kh4",
            "rows": "6c2 Ad3 Ah4/2d0 2s0 4d0 9h1 9c1/5s0 Js0 8s2 5d3 Ks4",
            "win": -2.6,
            "playerId": "pid2923305"
        },
        {
            "inFantasy": false,
            "result": -13,
            "playerName": "pid5684470",
            "orderIndex": 1,
            "hero": true,
            "dead": "2c1 Kd2 7s3 Td4",
            "rows": "Ac0 As2 Jd3/Jh0 Jc0 6h1 Ts2 7d4/Qd0 Qc0 5c1 3d3 2h4",
            "win": -2.6,
            "playerId": "pid5684470"
        },
        {
            "inFantasy": false,
            "result": 26,
            "playerName": "pid1087966",
            "orderIndex": 2,
            "hero": false,
            "dead": "3h1 3s2 5h3 3c4",
            "rows": "Qs2 Qh3 Kc4/4s0 9d0 4h1 6s1 9s4/8h0 8c0 Tc0 7h2 Th3",
            "win": 5,
            "playerId": "pid1087966"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 11:29:11",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000054-1": [
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid2923305",
            "orderIndex": 2,
            "hero": false,
            "dead": "Jc1 8h2 Th3 2d4",
            "rows": "Ad1 9h2 Jd3/3d0 6h2 7d3 5h4 7c4/2s0 5s0 Ts0 Js0 4s1",
            "win": -3.2,
            "playerId": "pid2923305"
        },
        {
            "inFantasy": false,
            "result": -7,
            "playerName": "pid5684470",
            "orderIndex": 0,
            "hero": true,
            "dead": "3s1 3c2 Ks3 9d4",
            "rows": "8s2 5d3 Td3/2h0 Qh1 Jh2 2c4 Kh4/6d0 6s0 8d0 8c0 6c1",
            "win": -1.4,
            "playerId": "pid5684470"
        },
        {
            "inFantasy": true,
            "result": 23,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "3h0",
            "rows": "9s0 Ac0 As0/4h0 4d0 7h0 Qd0 Qs0/5c0 9c0 Tc0 Qc0 Kc0",
            "win": 4.5,
            "playerId": "pid1087966"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 11:30:18",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000055-1": [
        {
            "inFantasy": false,
            "result": -4,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qh1 8s2 Ad3 5h4",
            "rows": "Ah0 As0 Ts3/3c0 3h1 2s2 2d3 Th4/7h0 9s0 Jc1 Jh2 9h4",
            "win": -0.8,
            "playerId": "pid2923305"
        },
        {
            "inFantasy": false,
            "result": 13,
            "playerName": "pid5684470",
            "orderIndex": 2,
            "hero": true,
            "dead": "Ac1 Js2 3s3 6c4",
            "rows": "Qc1 8h3 6d4/5d0 4d2 Qd2 Kd3 3d4/4h0 4c0 7c0 7s0 4s1",
            "win": 2.5,
            "playerId": "pid5684470"
        },
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qs1 9c2 7d3 Kc4",
            "rows": "Ks0 9d2 Kh2/5s0 5c1 6s1 6h3 8d4/2h0 2c0 Td0 8c3 Tc4",
            "win": -1.8,
            "playerId": "pid1087966"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 11:32:00",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000056-1": [
        {
            "inFantasy": true,
            "result": 31,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "4c0 6d1 5d2",
            "rows": "9c0 Ts0 Qs0/8h0 8c0 8s0 Kh0 Kc0/3d0 3s0 Ad0 Ac0 As0",
            "win": 6,
            "playerId": "pid2923305"
        },
        {
            "inFantasy": false,
            "result": -42,
            "playerName": "pid5684470",
            "orderIndex": 1,
            "hero": true,
            "dead": "7h1 Tc2 5h3 Jc4",
            "rows": "Jd1 6c3 4s4/Qd0 Qc0 4h2 4d2 7d3/6h0 7c0 8d0 Td1 3h4",
            "win": -8.4,
            "playerId": "pid5684470"
        },
        {
            "inFantasy": true,
            "result": 11,
            "playerName": "pid1087966",
            "orderIndex": 2,
            "hero": false,
            "dead": "2d0 3c1",
            "rows": "5c0 9d0 Kd0/2s0 5s0 6s0 7s0 Ks0/2h0 9h0 Th0 Jh0 Ah0",
            "win": 2.1,
            "playerId": "pid1087966"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 11:33:04",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000057-1": [
        {
            "inFantasy": false,
            "result": -24,
            "playerName": "pid2923305",
            "orderIndex": 2,
            "hero": false,
            "dead": "5c1 Qs2 Kc3 2d4",
            "rows": "Ac0 Ad2 3s4/3h0 7c0 3c1 6h1 7h2/9d0 Js0 8s3 Jc3 6d4",
            "win": -4.8,
            "playerId": "pid2923305"
        },
        {
            "inFantasy": false,
            "result": 7,
            "playerName": "pid5684470",
            "orderIndex": 0,
            "hero": true,
            "dead": "7s1 9s2 7d3 5d4",
            "rows": "Qh3 Kd3 8c4/6s0 Jd0 2s1 2c2 6c4/5h0 8h0 Th0 9h1 4h2",
            "win": 1.4,
            "playerId": "pid5684470"
        },
        {
            "inFantasy": false,
            "result": 17,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "2h1 3d2 Tc3 5s4",
            "rows": "Qd0 Kh0 Ks1/Ah0 As0 Ts2 8d3 Jh3/4c0 9c1 4d2 4s4 Qc4",
            "win": 3.3,
            "playerId": "pid1087966"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 11:33:58",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000058-1": [
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "5c1 Th2 2h3 3d4",
            "rows": "Ac2 4d3 5h4/4c0 6h0 6d1 6s2 7c3/8h0 8d0 8c0 Qs1 3s4",
            "win": -2,
            "playerId": "pid2923305"
        },
        {
            "inFantasy": false,
            "result": -33,
            "playerName": "pid5684470",
            "orderIndex": 2,
            "hero": true,
            "dead": "Td1 7d2 2c3 Qd4",
            "rows": "Kh2 Jh3 Kd3/2d0 3c0 4h0 Ah2 Qh4/4s0 8s0 9s1 As1 Ts4",
            "win": -6.6,
            "playerId": "pid5684470"
        },
        {
            "inFantasy": true,
            "result": 43,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "6c0 Js1",
            "rows": "9h0 9d0 Ad0/3h0 5d0 5s0 7h0 7s0/9c0 Tc0 Jc0 Qc0 Kc0",
            "win": 8.3,
            "playerId": "pid1087966"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 11:35:06",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000059-1": [
        {
            "inFantasy": false,
            "result": 8,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "5h1 2d2 5s3 5d4",
            "rows": "Kh0 Qh3 Kd4/5c0 Ac0 As1 3s3 9c4/Td0 Jh0 7h1 7d2 Jd2",
            "win": 1.6,
            "playerId": "pid2923305"
        },
        {
            "inFantasy": false,
            "result": -23,
            "playerName": "pid5684470",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qc1 2h2 Ts3 Tc4",
            "rows": "Ah0 Ks3 Qd4/4s0 6h0 6d1 3d2 Th4/9s0 Jc0 8c1 Js2 8d3",
            "win": -3.7,
            "playerId": "pid5684470"
        },
        {
            "inFantasy": true,
            "result": 15,
            "playerName": "pid1087966",
            "orderIndex": 2,
            "hero": false,
            "dead": "8h0 7c1",
            "rows": "9h0 9d0 Kc0/2c0 3h0 3c0 4h0 4d0/2s0 6s0 7s0 8s0 Qs0",
            "win": 2,
            "playerId": "pid1087966"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 11:36:29",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000060-1": [
        {
            "inFantasy": true,
            "result": -2,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "7d0 9s1",
            "rows": "Jh0 Kc0 Ks0/2s0 4d0 4c0 5h0 5c0/2c0 6h0 6s0 Th0 Ts0",
            "win": -0.4,
            "playerId": "pid2923305"
        },
        {
            "inFantasy": false,
            "result": 2,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "9c1 8d2 8c3 3s4",
            "rows": "Qd0 Qs1 7s3/2d0 5d2 Kh3 6c4 Kd4/3h0 8h0 9h0 4h1 Ah2",
            "win": 0.4,
            "playerId": "pid1087966"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": false,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 11:37:01",
    "roomId": "21947173"
}





