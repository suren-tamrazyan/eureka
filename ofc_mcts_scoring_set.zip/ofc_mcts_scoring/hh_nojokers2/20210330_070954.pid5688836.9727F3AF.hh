{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000309-1": [
        {
            "inFantasy": false,
            "result": -13,
            "playerName": "pid3182099",
            "orderIndex": 0,
            "hero": false,
            "dead": "7s1 7h2 4c3 Ks4",
            "rows": "Kh0 Ad0 8c4/9c1 3d2 3c2 6c3 Kd4/Th0 Tc0 Qs0 Qc1 Jh3",
            "win": -2.6,
            "playerId": "pid3182099"
        },
        {
            "inFantasy": false,
            "result": 13,
            "playerName": "pid5257862",
            "orderIndex": 1,
            "hero": false,
            "dead": "Td1 Jd2 5d3 2d4",
            "rows": "Kc1 Ts4 Qh4/4h0 5h0 8h0 3h2 Ah3/3s0 As0 5s1 4s2 9s3",
            "win": 2.5,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": false,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:09:54",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000310-1": [
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5688836",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jd1 3d2 4s3 Qs4",
            "rows": "Ah0 4h2 6s4/7h0 7s0 8h1 9s1 9h3/2c0 Kc0 2h2 Jc3 5d4",
            "win": -2,
            "playerId": "pid5688836"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid3182099",
            "orderIndex": 2,
            "hero": false,
            "dead": "6d1 7c2 Js3 4d4",
            "rows": "Ad0 Ac1 Tc4/2d0 Jh0 3s1 3h2 6c4/5c0 8c0 8d2 Th3 Ts3",
            "win": -2,
            "playerId": "pid3182099"
        },
        {
            "inFantasy": false,
            "result": 20,
            "playerName": "pid5257862",
            "orderIndex": 0,
            "hero": false,
            "dead": "As1 8s2 6h3 2s4",
            "rows": "Qc3 Ks3 9c4/4c0 5s0 5h1 3c2 Qh4/9d0 Td0 Kd0 7d1 Qd2",
            "win": 3.9,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:11:49",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000311-1": [
        {
            "inFantasy": false,
            "result": 13,
            "playerName": "pid5688836",
            "orderIndex": 0,
            "hero": true,
            "dead": "7s1 6d2 2s3 Ad4",
            "rows": "Ac0 9s3 Ah4/6h0 9c0 6c1 3d2 3s2/Qc0 Qs0 5c1 Qd3 Ks4",
            "win": 2.5,
            "playerId": "pid5688836"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "pid3182099",
            "orderIndex": 1,
            "hero": false,
            "dead": "8s1 3c2 3h3 Kh4",
            "rows": "Ts2 Jh4 Jc4/7d0 Js0 7c1 9d2 Jd3/2h0 9h0 Qh0 8h1 Th3",
            "win": 3.5,
            "playerId": "pid3182099"
        },
        {
            "inFantasy": false,
            "result": -31,
            "playerName": "pid5257862",
            "orderIndex": 2,
            "hero": false,
            "dead": "6s1 8d2 4h3 4c4",
            "rows": "2c0 2d1 8c4/4d0 7h0 5h1 5d3 4s4/Td0 Tc0 Kc2 As2 Kd3",
            "win": -6.2,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:13:09",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000312-1": [
        {
            "inFantasy": true,
            "result": 29,
            "playerName": "pid5688836",
            "orderIndex": 2,
            "hero": true,
            "dead": "3c0 7d0 2s0",
            "rows": "Qs0 Kc0 Ad0/5h0 5s0 Td0 Tc0 Ts0/9h0 9c0 Jh0 Jd0 Js0",
            "win": 5.6,
            "playerId": "pid5688836"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "pid3182099",
            "orderIndex": 0,
            "hero": false,
            "dead": "3s1 6c2 3d3 5c4",
            "rows": "Ah2 Th3 Qc4/6s0 5d1 6h1 7c2 6d3/8d0 8c0 Kh0 Kd0 Ks4",
            "win": -0.6,
            "playerId": "pid3182099"
        },
        {
            "inFantasy": false,
            "result": -26,
            "playerName": "pid5257862",
            "orderIndex": 1,
            "hero": false,
            "dead": "3h1 2h2 2d3 2c4",
            "rows": "Qh0 Jc2 4d4/8s0 As1 7h3 7s3 Qd4/4h0 4c0 4s0 9s1 9d2",
            "win": -5.2,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:14:25",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000313-1": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5688836",
            "orderIndex": 1,
            "hero": true,
            "dead": "8s1 9s2 6c3 As4",
            "rows": "Ad2 Ah3 Qs4/2d0 3s0 4c0 4s3 Qc4/Td0 Js0 Tc1 Jc1 6h2",
            "win": -2.4,
            "playerId": "pid5688836"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "pid3182099",
            "orderIndex": 2,
            "hero": false,
            "dead": "Kh1 8h2 4d3 5h4",
            "rows": "Kc1 Qd3 9d4/5s0 7s0 5c2 7d2 2c4/3d0 Jh0 Jd0 3c1 3h3",
            "win": 4.7,
            "playerId": "pid3182099"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5257862",
            "orderIndex": 0,
            "hero": false,
            "dead": "Ac1 4h2 8c3 2h4",
            "rows": "2s0 Ks2 Kd3/Th0 Ts2 Qh3 6s4 7h4/5d0 6d0 7c0 8d1 9c1",
            "win": -2.4,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:16:22",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000314-1": [
        {
            "inFantasy": false,
            "result": 42,
            "playerName": "pid5688836",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h1 3h2 8s3 6h4",
            "rows": "Kc0 Ks3 Kh4/6c0 Tc1 3c2 8c2 9c3/3d0 5d0 Jd0 2d1 6d4",
            "win": 8.1,
            "playerId": "pid5688836"
        },
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid3182099",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jh1 2s2 9h3 Th4",
            "rows": "As0 Ac1 Qh3/3s0 5h0 5s2 4h3 4c4/8d0 Kd0 7d1 Td2 4d4",
            "win": -4,
            "playerId": "pid3182099"
        },
        {
            "inFantasy": false,
            "result": -22,
            "playerName": "pid5257862",
            "orderIndex": 2,
            "hero": false,
            "dead": "9d1 5c2 2c3 4s4",
            "rows": "Jc1 Ad2 Ah4/8h0 Qd0 Qs0 7h3 7c4/6s0 9s0 7s1 Js2 Ts3",
            "win": -4.4,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:17:35",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000315-1": [
        {
            "inFantasy": true,
            "result": 0,
            "playerName": "pid5688836",
            "orderIndex": 2,
            "hero": true,
            "dead": "7h0 6h0 Ts0",
            "rows": "Qh0 Kh0 Kd0/2d0 2s0 9d0 9c0 Jc0/4h0 4c0 4s0 5d0 5s0",
            "win": 0,
            "playerId": "pid5688836"
        },
        {
            "inFantasy": true,
            "result": -1,
            "playerName": "pid3182099",
            "orderIndex": 0,
            "hero": false,
            "dead": "6s0 3d1 9s2",
            "rows": "8h0 8d0 Qs0/4d0 6d0 7d0 Td0 Jd0/3c0 5c0 Tc0 Kc0 Ac0",
            "win": -0.2,
            "playerId": "pid3182099"
        },
        {
            "inFantasy": true,
            "result": 1,
            "playerName": "pid5257862",
            "orderIndex": 1,
            "hero": false,
            "dead": "5h0 2c1 3h2",
            "rows": "Qd0 Qc0 Ad0/6c0 7c0 8s0 9h0 Th0/3s0 7s0 Js0 Ks0 As0",
            "win": 0.2,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:19:14",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000316-1": [
        {
            "inFantasy": false,
            "result": 22,
            "playerName": "pid5688836",
            "orderIndex": 1,
            "hero": true,
            "dead": "2c1 Kc2 8c3 3s4",
            "rows": "Ah0 Jd4 Ac4/Th0 4s1 5h1 4c2 5s3/2d0 3d0 Qd0 8d2 6d3",
            "win": 4.3,
            "playerId": "pid5688836"
        },
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid3182099",
            "orderIndex": 2,
            "hero": false,
            "dead": "3c1 Ts2 7c3 7h4",
            "rows": "Ad0 9c1 Tc4/4d0 Qc0 Qh1 4h2 Td3/6h0 Kh0 Js2 Jh3 Jc4",
            "win": -3.4,
            "playerId": "pid3182099"
        },
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "pid5257862",
            "orderIndex": 0,
            "hero": false,
            "dead": "7s1 8h2 9h3 3h4",
            "rows": "2h0 Kd3 7d4/9d0 9s1 5d2 5c2 6s4/8s0 Qs0 Ks0 As1 2s3",
            "win": -1,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:21:09",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000317-1": [
        {
            "inFantasy": true,
            "result": 36,
            "playerName": "pid5688836",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h0 3c0 2d0",
            "rows": "Qs0 Kd0 Ks0/7d0 Td0 Ts0 Jh0 Jc0/3h0 4h0 6h0 Qh0 Ah0",
            "win": 7,
            "playerId": "pid5688836"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid3182099",
            "orderIndex": 1,
            "hero": false,
            "dead": "4c1 Kc2 5s3 Js4",
            "rows": "Tc1 Ac2 7s3/2c0 2s0 8h0 6c1 6d4/3d0 9d0 Qc2 9c3 9s4",
            "win": -2.4,
            "playerId": "pid3182099"
        },
        {
            "inFantasy": false,
            "result": -24,
            "playerName": "pid5257862",
            "orderIndex": 2,
            "hero": false,
            "dead": "4d1 8d2 6s3 7c4",
            "rows": "Qd2 Ad3 As4/3s0 5c0 5d1 5h2 Jd3/9h0 Th0 Kh0 7h1 8s4",
            "win": -4.8,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:22:26",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000318-1": [
        {
            "inFantasy": false,
            "result": 26,
            "playerName": "pid5688836",
            "orderIndex": 2,
            "hero": true,
            "dead": "Td1 As2 Ts3 2c4",
            "rows": "Th2 Kd2 Ks3/6h0 2s1 2h3 2d4 9c4/7c0 7s0 Qh0 Qs0 7d1",
            "win": 5,
            "playerId": "pid5688836"
        },
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid3182099",
            "orderIndex": 0,
            "hero": false,
            "dead": "3h1 4d2 8c3 3c4",
            "rows": "Kc1 6c3 3s4/4s0 Tc0 9h1 4c2 4h4/8h0 8d0 Js0 Qd2 8s3",
            "win": -3.6,
            "playerId": "pid3182099"
        },
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid5257862",
            "orderIndex": 1,
            "hero": false,
            "dead": "5s1 5h2 5d3 5c4",
            "rows": "Qc1 9d2 6d4/3d0 7h0 6s1 9s3 Kh3/Jc0 Ah0 Ac0 Ad2 Jh4",
            "win": -1.6,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:24:04",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000319-1": [
        {
            "inFantasy": true,
            "result": 34,
            "playerName": "pid5688836",
            "orderIndex": 1,
            "hero": true,
            "dead": "2h0 3c0",
            "rows": "Qh0 Ad0 As0/4d0 Td0 Ts0 Jh0 Js0/8d0 8c0 8s0 9h0 9d0",
            "win": 6.6,
            "playerId": "pid5688836"
        },
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid3182099",
            "orderIndex": 2,
            "hero": false,
            "dead": "2s1 Kd2 5c3 5h4",
            "rows": "Ac2 Qd3 Kh4/7s0 4s1 6s1 6h2 4h4/2c0 6c0 9c0 Qc0 Tc3",
            "win": -3,
            "playerId": "pid3182099"
        },
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid5257862",
            "orderIndex": 0,
            "hero": false,
            "dead": "Th1 4c2 3s3 3h4",
            "rows": "Ah1 Qs3 Kc3/7c0 5s1 8h2 5d4 9s4/2d0 6d0 7d0 Jd0 3d2",
            "win": -3.8,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:25:14",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000320-1": [
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid5688836",
            "orderIndex": 0,
            "hero": true,
            "dead": "2c1 8d2 7s3 Jd4",
            "rows": "Ah0 Ad0 5c4/5d1 5s2 Kh2 4h3 4s3/Th0 Js0 Qd0 Kd1 5h4",
            "win": -3.8,
            "playerId": "pid5688836"
        },
        {
            "inFantasy": false,
            "result": -7,
            "playerName": "pid3182099",
            "orderIndex": 1,
            "hero": false,
            "dead": "6h1 3d2 2d3 3h4",
            "rows": "9s2 Jh3 Kc4/2h0 2s0 9d1 9c2 7h3/8c0 8s0 Qs0 8h1 7c4",
            "win": -1.4,
            "playerId": "pid3182099"
        },
        {
            "inFantasy": false,
            "result": 26,
            "playerName": "pid5257862",
            "orderIndex": 2,
            "hero": false,
            "dead": "9h1 4c2 Jc3 3c4",
            "rows": "Qh0 Qc0 7d4/Ks0 Ac2 6c3 6s3 As4/3s0 6d0 Td1 Tc1 Ts2",
            "win": 5,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:26:19",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000321-1": [
        {
            "inFantasy": false,
            "result": -27,
            "playerName": "pid5688836",
            "orderIndex": 2,
            "hero": true,
            "dead": "Qd1 2c2 9s3 4s4",
            "rows": "Kc0 9d2 Qs3/3d0 Jc0 8s1 4c2 4h3/6h0 7h0 6d1 7d4 Qc4",
            "win": -2.6,
            "playerId": "pid5688836"
        },
        {
            "inFantasy": false,
            "result": -39,
            "playerName": "pid3182099",
            "orderIndex": 0,
            "hero": false,
            "dead": "5s1 7s2 Ts3 2s4",
            "rows": "Ah0 9c2 8h4/2h0 Tc0 2d1 Td1 7c3/4d0 Jd0 Jh2 3c3 8d4",
            "win": -7.8,
            "playerId": "pid3182099"
        },
        {
            "inFantasy": true,
            "result": 66,
            "playerName": "pid5257862",
            "orderIndex": 1,
            "hero": false,
            "dead": "5d0",
            "rows": "Kh0 Kd0 Ks0/6c0 Js0 Ad0 Ac0 As0/3h0 5h0 9h0 Th0 Qh0",
            "win": 10.1,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:27:54",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000322-1": [
        {
            "inFantasy": false,
            "result": 22,
            "playerName": "pid5688836",
            "orderIndex": 1,
            "hero": true,
            "dead": "8h1 8c2 Ts3 7h4",
            "rows": "Ah1 9c2 9h4/3h0 5s0 3d3 Kc3 Ks4/7d0 8s0 Td0 9d1 Js2",
            "win": 4.3,
            "playerId": "pid5688836"
        },
        {
            "inFantasy": false,
            "result": -13,
            "playerName": "pid3182099",
            "orderIndex": 2,
            "hero": false,
            "dead": "5h1 9s2 2d3 2c4",
            "rows": "As0 7s3 6s4/3s0 Th0 4h1 4c2 Tc3/Jd0 Jc0 Qc1 Qh2 6c4",
            "win": -2.6,
            "playerId": "pid3182099"
        },
        {
            "inFantasy": true,
            "result": -9,
            "playerName": "pid5257862",
            "orderIndex": 0,
            "hero": false,
            "dead": "2s0",
            "rows": "Jh0 Qs0 Kh0/3c0 4d0 6d0 Ad0 Ac0/4s0 5c0 6h0 7c0 8d0",
            "win": -1.8,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:29:43",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000323-1": [
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid5688836",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jd1 Jc2 4d3 6s4",
            "rows": "Qh0 Ac3 Kc4/3d0 7c1 9c1 3s2 9s4/2h0 2s0 Tc0 Td2 8c3",
            "win": -3.4,
            "playerId": "pid5688836"
        },
        {
            "inFantasy": false,
            "result": 29,
            "playerName": "pid3182099",
            "orderIndex": 1,
            "hero": false,
            "dead": "Th1 2c2 2d3 Ad4",
            "rows": "As2 7h3 Ah4/4c0 Jh0 3c1 3h2 4s4/8d0 Qd0 Kd0 5d1 7d3",
            "win": 5.6,
            "playerId": "pid3182099"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5257862",
            "orderIndex": 2,
            "hero": false,
            "dead": "9d1 5c2 Ks3 6c4",
            "rows": "Kh3 8s4 9h4/5h0 6h1 8h1 4h2 6d3/5s0 7s0 Js0 Qs0 Ts2",
            "win": -2.4,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:31:06",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000324-1": [
        {
            "inFantasy": false,
            "result": -37,
            "playerName": "pid5688836",
            "orderIndex": 2,
            "hero": true,
            "dead": "9s1 Ts2 2h3 3c4",
            "rows": "7d1 Jd1 7h3/2c0 4s0 8c0 8d3 Kh4/5h0 6h0 5c2 6c2 Qc4",
            "win": -7.4,
            "playerId": "pid5688836"
        },
        {
            "inFantasy": true,
            "result": 72,
            "playerName": "pid3182099",
            "orderIndex": 0,
            "hero": false,
            "dead": "4d0 9h1 9d2",
            "rows": "Ad0 Ac0 As0/3h0 4c0 5s0 6s0 7s0/Th0 Td0 Tc0 Qh0 Qd0",
            "win": 14,
            "playerId": "pid3182099"
        },
        {
            "inFantasy": false,
            "result": -35,
            "playerName": "pid5257862",
            "orderIndex": 1,
            "hero": false,
            "dead": "2d1 5d2 4h3 Qs4",
            "rows": "3d0 3s3 7c3/9c0 Jc0 8h1 Js2 Jh4/Kd0 Kc0 Ks1 6d2 Ah4",
            "win": -7,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:32:57",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000325-1": [
        {
            "inFantasy": false,
            "result": -28,
            "playerName": "pid5688836",
            "orderIndex": 1,
            "hero": true,
            "dead": "Th1 Tc2 6d3 Ks4",
            "rows": "Kh0 As2 Ac3/5d0 6c0 5s1 6s1 8s3/9c0 Qd0 9s2 2s4 4h4",
            "win": -5.6,
            "playerId": "pid5688836"
        },
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "pid3182099",
            "orderIndex": 2,
            "hero": false,
            "dead": "2d0 4d1 5c2",
            "rows": "9h0 9d0 Td0/4s0 5h0 6h0 7s0 8d0/Ts0 Jd0 Qc0 Kc0 Ah0",
            "win": 4.1,
            "playerId": "pid3182099"
        },
        {
            "inFantasy": false,
            "result": 7,
            "playerName": "pid5257862",
            "orderIndex": 0,
            "hero": false,
            "dead": "3h1 2c2 3c3 2h4",
            "rows": "Qs0 Jc2 Ad3/3d0 Kd0 3s2 4c3 Js4/7d0 7c0 8h1 8c1 7h4",
            "win": 1.4,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:35:10",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000326-1": [
        {
            "inFantasy": false,
            "result": -7,
            "playerName": "pid5688836",
            "orderIndex": 0,
            "hero": true,
            "dead": "7c1 7d2 9h3 4d4",
            "rows": "Kd1 9d2 8d4/2d0 6c0 As1 Ad3 Td4/5h0 6h0 7h0 3c2 4c3",
            "win": -1.4,
            "playerId": "pid5688836"
        },
        {
            "inFantasy": false,
            "result": -2,
            "playerName": "pid3182099",
            "orderIndex": 1,
            "hero": false,
            "dead": "5s1 6d2 5d3 Tc4",
            "rows": "8h1 8s2 Kc4/2s0 9c0 3s1 9s2 3h4/Th0 Jh0 Jc0 Qh3 Qs3",
            "win": -0.4,
            "playerId": "pid3182099"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "pid5257862",
            "orderIndex": 2,
            "hero": false,
            "dead": "Ts1 3d2 4h3 5c4",
            "rows": "Jd0 Js2 7s3/Qd1 Ah1 8c2 6s3 Ac4/2h0 2c0 Kh0 Ks0 Qc4",
            "win": 1.7,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:36:46",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000327-1": [
        {
            "inFantasy": false,
            "result": 7,
            "playerName": "pid5688836",
            "orderIndex": 2,
            "hero": true,
            "dead": "Ac1 3h2 5h3 2d4",
            "rows": "Ks0 Td4 Qd4/4d0 3c1 3s1 4h2 Ah3/8s0 9c0 Jh0 9s2 Jc3",
            "win": 1.4,
            "playerId": "pid5688836"
        },
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid3182099",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jd1 Qh2 3d3 5d4",
            "rows": "9h3 Kc3 Qc4/2h0 4c0 6s1 2s2 8h4/7c0 8d0 Ts0 7s1 7d2",
            "win": 1,
            "playerId": "pid3182099"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5257862",
            "orderIndex": 1,
            "hero": false,
            "dead": "6h1 Th2 5s3 4s4",
            "rows": "Js0 Qs1 Kh4/9d0 Ad0 As1 Kd2 7h3/2c0 8c0 Tc2 6c3 6d4",
            "win": -2.4,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:39:00",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000328-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5688836",
            "orderIndex": 1,
            "hero": true,
            "dead": "3d1 4h2 8h3 Ah4",
            "rows": "7s2 2d3 7h4/4d0 6d0 4s1 6h1 9c2/Th0 Tc0 Jh0 5s3 Ts4",
            "win": -1.2,
            "playerId": "pid5688836"
        },
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid3182099",
            "orderIndex": 2,
            "hero": false,
            "dead": "4c1 6s2 5c3 2h4",
            "rows": "Ac0 Jc3 5d4/Td0 7c2 Qs2 Qc3 7d4/2s0 8s0 Ks0 Kd1 Kc1",
            "win": -3,
            "playerId": "pid3182099"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "pid5257862",
            "orderIndex": 0,
            "hero": false,
            "dead": "5h1 Qd2 Qh3 2c4",
            "rows": "Ad3 Jd4 Kh4/3s0 Js0 As1 3h2 3c2/9h0 9d0 9s0 8c1 8d3",
            "win": 4.1,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:40:42",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000329-1": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid5688836",
            "orderIndex": 0,
            "hero": true,
            "dead": "4h1 Ac2 4c3 9d4",
            "rows": "Ks0 2d3 Ah4/2h0 3c0 7s1 3h2 7h2/5h0 5s0 Ts1 Td3 Th4",
            "win": 0.6,
            "playerId": "pid5688836"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "pid5257862",
            "orderIndex": 1,
            "hero": false,
            "dead": "3d1 5d2 7c3 7d4",
            "rows": "9h2 2c3 9s3/4s0 9c0 6h1 6c1 4d2/8d0 8c0 Kd0 8h4 Qh4",
            "win": -0.6,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:41:45",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000330-1": [
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "pid5688836",
            "orderIndex": 1,
            "hero": true,
            "dead": "As1 4c2 2h3 7d4",
            "rows": "Ac3 Qc4 Kh4/8h0 Js0 8c1 6h2 Jc2/3d0 6d0 Td0 Jd1 Kd3",
            "win": -1,
            "playerId": "pid5688836"
        },
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid5257862",
            "orderIndex": 0,
            "hero": false,
            "dead": "5d1 5h2 Qh3 3c4",
            "rows": "5c1 4h4 5s4/8d0 9h0 Th0 7c2 Jh3/9s0 Qs0 6s1 4s2 8s3",
            "win": 1,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:43:10",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000331-1": [
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "pid5688836",
            "orderIndex": 0,
            "hero": true,
            "dead": "9c1 7d2 2s3 8c4",
            "rows": "Kd0 Kh2 9h3/2h0 3d0 2c1 4h2 3c3/5c0 Qc0 5h1 5d4 Ad4",
            "win": -1.8,
            "playerId": "pid5688836"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "pid5257862",
            "orderIndex": 1,
            "hero": false,
            "dead": "Tc1 Qd2 3h3 5s4",
            "rows": "Qs0 Ac1 As3/3s0 7h0 7s1 7c2 9d4/Jh0 Jc0 Js2 2d3 8s4",
            "win": 1.7,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:44:05",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000332-1": [
        {
            "inFantasy": true,
            "result": -7,
            "playerName": "pid5688836",
            "orderIndex": 1,
            "hero": true,
            "dead": "3c0 5s0",
            "rows": "8s0 Kc0 Ah0/6d0 7c0 8d0 9d0 Ts0/2h0 2d0 2c0 4h0 4s0",
            "win": -1.4,
            "playerId": "pid5688836"
        },
        {
            "inFantasy": true,
            "result": 7,
            "playerName": "pid5257862",
            "orderIndex": 0,
            "hero": false,
            "dead": "Ks0 4c1 Qh2",
            "rows": "Jd0 Js0 As0/5d0 6c0 7d0 8h0 9s0/3h0 3d0 3s0 Th0 Tc0",
            "win": 1.4,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:45:04",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000333-1": [
        {
            "inFantasy": false,
            "result": 25,
            "playerName": "pid5688836",
            "orderIndex": 0,
            "hero": true,
            "dead": "Kh1 Jd2 Jc3 Qc4",
            "rows": "Ad1 9c2 Ac3/3h0 4d0 7c2 4h3 7h4/6h0 6c0 Qs0 6d1 6s4",
            "win": 4.8,
            "playerId": "pid5688836"
        },
        {
            "inFantasy": false,
            "result": -25,
            "playerName": "pid5257862",
            "orderIndex": 1,
            "hero": false,
            "dead": "4c1 8c2 7d3 5d4",
            "rows": "Ks1 As2 Kc3/5c0 8d0 9d0 8s1 8h4/Jh0 Js0 3c2 Th3 Qh4",
            "win": -5,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:46:29",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000334-1": [
        {
            "inFantasy": true,
            "result": 11,
            "playerName": "pid5688836",
            "orderIndex": 1,
            "hero": true,
            "dead": "2d0 3s0 4c0",
            "rows": "Kd0 Kc0 Ad0/8h0 8c0 9d0 9s0 Qs0/6d0 6s0 Th0 Td0 Tc0",
            "win": 2.1,
            "playerId": "pid5688836"
        },
        {
            "inFantasy": false,
            "result": -11,
            "playerName": "pid5257862",
            "orderIndex": 0,
            "hero": false,
            "dead": "5d1 8d2 7d3 2c4",
            "rows": "Qc0 9c1 8s4/4s0 As0 Ts1 4d2 Ac2/2h0 6h0 3h3 Jh3 Qh4",
            "win": -2.2,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:47:31",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000335-1": [
        {
            "inFantasy": false,
            "result": 11,
            "playerName": "pid5688836",
            "orderIndex": 0,
            "hero": true,
            "dead": "6h1 Jc2 3s3 9c4",
            "rows": "8h2 6s3 8d4/Td0 Js0 Jd1 4d2 Ad4/2s0 Qh0 Qd0 2c1 Qc3",
            "win": 2.1,
            "playerId": "pid5688836"
        },
        {
            "inFantasy": false,
            "result": -11,
            "playerName": "pid5257862",
            "orderIndex": 1,
            "hero": false,
            "dead": "5s1 Ts2 6d3 8s4",
            "rows": "Qs1 Ks3 Jh4/3d0 4c1 2d2 4h3 9h4/5h0 7h0 Th0 Kh0 Ah2",
            "win": -2.2,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:48:17",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000336-1": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5688836",
            "orderIndex": 1,
            "hero": true,
            "dead": "7h1 2c2 Ac3 Ah4",
            "rows": "Ad0 As1 9h3/5d0 9d0 4h2 9c2 Ks4/6d0 6s0 Qd1 Jc3 5h4",
            "win": -2.4,
            "playerId": "pid5688836"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid5257862",
            "orderIndex": 0,
            "hero": false,
            "dead": "Js1 7d2 Qh3 3h4",
            "rows": "Kh2 6h4 9s4/3s0 3c1 8s1 2d3 2s3/7c0 7s0 Td0 Tc0 Ts2",
            "win": 2.3,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:49:34",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000337-1": [
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid5688836",
            "orderIndex": 0,
            "hero": true,
            "dead": "2d1 7s2 5h3 Ad4",
            "rows": "Kd0 Ks2 Kh4/Ah0 Ac0 5s1 Tc3 Jc3/8c0 Qc0 9d1 9h2 Td4",
            "win": -2.8,
            "playerId": "pid5688836"
        },
        {
            "inFantasy": false,
            "result": 14,
            "playerName": "pid5257862",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jd1 7d2 5d3 Qd4",
            "rows": "3s3 4c3 Kc4/5c0 8d0 9s1 7h2 6d4/6h0 Th0 Qh0 2h1 Jh2",
            "win": 2.7,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:50:31",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000338-1": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "pid5688836",
            "orderIndex": 1,
            "hero": true,
            "dead": "6c1 8c2 Kd3 6d4",
            "rows": "Kc0 Ah1 Jd4/2d0 2s0 5s0 Jh3 Js3/9d0 9c1 Qd2 Qs2 Th4",
            "win": -0.6,
            "playerId": "pid5688836"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid5257862",
            "orderIndex": 0,
            "hero": false,
            "dead": "8h1 2h2 9s3 3c4",
            "rows": "As1 Kh3 3s4/6s0 Ts0 4s1 Td3 5d4/4c0 7c0 Ac0 2c2 Jc2",
            "win": 0.6,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:52:10",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000339-1": [
        {
            "inFantasy": false,
            "result": 8,
            "playerName": "pid5688836",
            "orderIndex": 0,
            "hero": true,
            "dead": "7s1 7h2 7d3 4s4",
            "rows": "As0 Kc2 Ad3/2c0 3d0 6d1 2s4 6c4/8d0 Qs0 9s1 Jc2 Tc3",
            "win": 1.6,
            "playerId": "pid5688836"
        },
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid5257862",
            "orderIndex": 1,
            "hero": false,
            "dead": "9d1 8c2 Jd3 3c4",
            "rows": "7c2 Td3 4c4/8s0 Js0 Ks0 6s1 Qd4/Th0 Ah0 Kh1 5h2 Jh3",
            "win": -1.6,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:53:11",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000340-1": [
        {
            "inFantasy": true,
            "result": 20,
            "playerName": "pid5688836",
            "orderIndex": 1,
            "hero": true,
            "dead": "2h0 3h0 6h0",
            "rows": "8c0 Kd0 Kc0/4s0 5s0 7s0 Qs0 As0/9h0 9d0 9s0 Th0 Ts0",
            "win": 3.9,
            "playerId": "pid5688836"
        },
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid5257862",
            "orderIndex": 0,
            "hero": false,
            "dead": "Ac1 Tc2 2c3 6c4",
            "rows": "7h3 9c4 Ks4/5c0 6s0 8h0 4h1 7c2/Jd0 Ad0 8d1 7d2 4d3",
            "win": -4,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:54:02",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000341-1": [
        {
            "inFantasy": false,
            "result": 4,
            "playerName": "pid5688836",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qd1 Th2 2s3 Js4",
            "rows": "Ah0 Td3 Jc4/4d0 5s0 3s2 2d3 6h4/9c0 Jh0 8d1 Tc1 7d2",
            "win": 0.8,
            "playerId": "pid5688836"
        },
        {
            "inFantasy": false,
            "result": -4,
            "playerName": "pid5257862",
            "orderIndex": 1,
            "hero": false,
            "dead": "3c1 7c2 5h3 2c4",
            "rows": "Kc0 4s1 Qc4/6d0 6s0 6c1 8c3 5c4/8s0 9d0 Ts2 Jd2 7h3",
            "win": -0.8,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:54:59",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000342-1": [
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid5688836",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qc1 9s2 9c3 7h4",
            "rows": "Ah0 Ac1 4d4/2c0 4h0 5c0 2s3 5d3/6s0 8c1 6h2 Td2 3s4",
            "win": -2.8,
            "playerId": "pid5688836"
        },
        {
            "inFantasy": false,
            "result": 14,
            "playerName": "pid5257862",
            "orderIndex": 0,
            "hero": false,
            "dead": "9d1 8h2 4s3 7s4",
            "rows": "Kd0 Tc2 Kh4/2h0 3c0 9h2 3d3 2d4/Jh0 Jc0 7d1 7c1 Qh3",
            "win": 2.7,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:56:15",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000343-1": [
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid5688836",
            "orderIndex": 0,
            "hero": true,
            "dead": "3c1 Jd2 3h3 3s4",
            "rows": "Ks1 Th3 Js4/4c0 5d0 Qc2 Ah3 9d4/6h0 6d0 7s0 7c1 6s2",
            "win": -2.8,
            "playerId": "pid5688836"
        },
        {
            "inFantasy": true,
            "result": 14,
            "playerName": "pid5257862",
            "orderIndex": 1,
            "hero": false,
            "dead": "2c0 9s1",
            "rows": "Tc0 Qs0 Ac0/2d0 3d0 4d0 7d0 Ad0/8h0 8d0 8s0 Kh0 Kd0",
            "win": 2.7,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:57:28",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000344-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5688836",
            "orderIndex": 1,
            "hero": true,
            "dead": "9d1 7d2 4s3 Ks4",
            "rows": "Ac1 Ah2 7c3/8s0 Jd0 Jc1 Qh3 3d4/5h0 6h0 7h0 4d2 2s4",
            "win": 0,
            "playerId": "pid5688836"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5257862",
            "orderIndex": 0,
            "hero": false,
            "dead": "8h1 Th2 8c3 9h4",
            "rows": "Kh0 Js1 Ts3/4c0 6d1 3c2 3s2 Qs4/2d0 2c0 As0 Kd3 3h4",
            "win": 0,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:59:16",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000345-1": [
        {
            "inFantasy": false,
            "result": -7,
            "playerName": "pid5688836",
            "orderIndex": 0,
            "hero": true,
            "dead": "6s1 Jc2 Tc3 4c4",
            "rows": "Ah1 Qs3 Kh4/8c0 9c0 8s1 8d2 Js3/2d0 7d0 Jd0 5d2 Td4",
            "win": -1.4,
            "playerId": "pid5688836"
        },
        {
            "inFantasy": false,
            "result": 7,
            "playerName": "pid5257862",
            "orderIndex": 1,
            "hero": false,
            "dead": "3h1 8h2 5s3 2h4",
            "rows": "Kc1 4s4 Kd4/6h0 9d0 6d1 7c2 7h3/9s0 Ts0 Ks0 3s2 7s3",
            "win": 1.4,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:00:17",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000346-1": [
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid5688836",
            "orderIndex": 1,
            "hero": true,
            "dead": "5d1 4s2 7s3 Th4",
            "rows": "Qc0 Kh1 Jc3/6s0 2s1 Ts2 Ac2 Ad4/3h0 3d0 9d0 3c3 Jd4",
            "win": -3.6,
            "playerId": "pid5688836"
        },
        {
            "inFantasy": true,
            "result": 18,
            "playerName": "pid5257862",
            "orderIndex": 0,
            "hero": false,
            "dead": "2c0 9s1",
            "rows": "Tc0 Kc0 As0/4h0 6h0 7h0 Jh0 Qh0/2d0 6d0 Td0 Qd0 Kd0",
            "win": 3.5,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:01:09",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000347-1": [
        {
            "inFantasy": false,
            "result": 23,
            "playerName": "pid5688836",
            "orderIndex": 0,
            "hero": true,
            "dead": "Kh1 Kd2 As3 3c4",
            "rows": "Ac0 Ad2 Qc4/4c1 6c1 5h3 7h3 3h4/3s0 7s0 9s0 Ks0 Ts2",
            "win": 4.5,
            "playerId": "pid5688836"
        },
        {
            "inFantasy": false,
            "result": -23,
            "playerName": "pid5257862",
            "orderIndex": 1,
            "hero": false,
            "dead": "5d1 7c2 2c3 5c4",
            "rows": "7d1 Kc2 Qs3/2s0 4d0 2d1 9h3 9c4/8c0 Jd0 Jc0 8s2 5s4",
            "win": -4.6,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:02:10",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000348-1": [
        {
            "inFantasy": true,
            "result": 26,
            "playerName": "pid5688836",
            "orderIndex": 1,
            "hero": true,
            "dead": "6s0 Jc0 Qh0",
            "rows": "Kh0 Kc0 Ks0/5h0 6h0 7s0 8d0 9d0/2d0 2c0 2s0 5d0 5c0",
            "win": 5,
            "playerId": "pid5688836"
        },
        {
            "inFantasy": false,
            "result": -26,
            "playerName": "pid5257862",
            "orderIndex": 0,
            "hero": false,
            "dead": "Js1 Jd2 4d3 5s4",
            "rows": "Qs0 Qd2 7h3/Ah0 2h1 8h1 Ad2 3h4/6c0 Tc0 Ac0 4c3 9c4",
            "win": -5.2,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:02:49",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000349-1": [
        {
            "inFantasy": true,
            "result": 3,
            "playerName": "pid5688836",
            "orderIndex": 0,
            "hero": true,
            "dead": "5c0 2c0 5h0",
            "rows": "Kh0 Ks0 Ah0/8d0 8c0 Tc0 Ts0 Jh0/2d0 4d0 7d0 9d0 Qd0",
            "win": 0.6,
            "playerId": "pid5688836"
        },
        {
            "inFantasy": true,
            "result": -3,
            "playerName": "pid5257862",
            "orderIndex": 1,
            "hero": false,
            "dead": "2h0",
            "rows": "Js0 Qs0 Kc0/3d0 6d0 6c0 6s0 8h0/4h0 4c0 4s0 9h0 9c0",
            "win": -0.6,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:03:38",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000350-1": [
        {
            "inFantasy": false,
            "result": -4,
            "playerName": "pid5688836",
            "orderIndex": 1,
            "hero": true,
            "dead": "6s1 Js2 Ts3 3c4",
            "rows": "Ks1 Qs2 As3/4h0 9d0 9c2 2d3 7h4/2c0 7c0 Jc0 4c1 Tc4",
            "win": -0.8,
            "playerId": "pid5688836"
        },
        {
            "inFantasy": false,
            "result": 4,
            "playerName": "pid5257862",
            "orderIndex": 0,
            "hero": false,
            "dead": "3d1 2h2 Jh3 9s4",
            "rows": "Qc0 Kh1 Qd2/Ac0 Ah1 Jd2 3s3 6h4/7d0 7s0 8s0 Td3 Th4",
            "win": 0.8,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:05:00",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000351-1": [
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid5688836",
            "orderIndex": 0,
            "hero": true,
            "dead": "3c1 8s2 4c3 4d4",
            "rows": "Ks0 7c3 Ts4/2d0 6c0 6s1 3d2 3s2/4h0 7h0 5h1 6h3 Ah4",
            "win": -2.8,
            "playerId": "pid5688836"
        },
        {
            "inFantasy": true,
            "result": 14,
            "playerName": "pid5257862",
            "orderIndex": 1,
            "hero": false,
            "dead": "6d0",
            "rows": "Td0 Qd0 As0/2h0 3h0 9h0 Th0 Qh0/5c0 8c0 Qc0 Kc0 Ac0",
            "win": 2.7,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:05:53",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000352-1": [
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid5688836",
            "orderIndex": 1,
            "hero": true,
            "dead": "3s1 5s2 Jh3 7h4",
            "rows": "As0 5h2 Jd4/8d0 9s0 Td1 Ts3 6s4/4c0 Qc0 3c1 7c2 8c3",
            "win": 1.9,
            "playerId": "pid5688836"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5257862",
            "orderIndex": 0,
            "hero": false,
            "dead": "3h1 Tc2 2h3 3d4",
            "rows": "Qd2 Kh2 4s4/2s0 5d0 8h3 8s3 6d4/Jc0 Kc0 Ad0 Js1 Kd1",
            "win": -2,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:07:28",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000353-1": [
        {
            "inFantasy": false,
            "result": 16,
            "playerName": "pid5688836",
            "orderIndex": 0,
            "hero": true,
            "dead": "6d1 Th2 Jd3 4d4",
            "rows": "Ks0 9c4 9s4/4s0 2d2 3c2 5s3 6s3/3h0 6h0 Kh0 8h1 9h1",
            "win": 3.1,
            "playerId": "pid5688836"
        },
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid5257862",
            "orderIndex": 1,
            "hero": false,
            "dead": "7c1 5d2 3s3 5h4",
            "rows": "Ac2 Kd3 Qd4/Ah0 Ad0 2h1 2c1 8s4/9d0 Tc0 Jc0 8d2 Qh3",
            "win": -3.2,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:08:18",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000354-1": [
        {
            "inFantasy": false,
            "result": -22,
            "playerName": "pid5688836",
            "orderIndex": 1,
            "hero": true,
            "dead": "Ad1 2c2 3c3 5d4",
            "rows": "Ah0 Ac0 5h4/6h0 6d0 5c1 4d2 4s2/9s0 Tc1 8h3 Js3 2h4",
            "win": -4.4,
            "playerId": "pid5688836"
        },
        {
            "inFantasy": false,
            "result": 22,
            "playerName": "pid5257862",
            "orderIndex": 0,
            "hero": false,
            "dead": "2d1 4h2 9c3 Qd4",
            "rows": "Kc1 Kd2 As4/6c0 8c0 7h1 4c2 5s4/2s0 7s0 8s0 6s3 Ks3",
            "win": 4.3,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:09:39",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000355-1": [
        {
            "inFantasy": false,
            "result": -29,
            "playerName": "pid5688836",
            "orderIndex": 0,
            "hero": true,
            "dead": "3s1 2d2 5s3 Kd4",
            "rows": "Ad2 Ks3 5d4/4h0 5c0 7s0 3c2 7c3/8d0 Jd0 9h1 Qh1 8h4",
            "win": -5.8,
            "playerId": "pid5688836"
        },
        {
            "inFantasy": true,
            "result": 29,
            "playerName": "pid5257862",
            "orderIndex": 1,
            "hero": false,
            "dead": "4d0 2s1",
            "rows": "Qc0 Kh0 Kc0/5h0 9d0 9c0 Th0 Td0/8s0 9s0 Ts0 Js0 Qs0",
            "win": 5.6,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:10:33",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000356-1": [
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid5688836",
            "orderIndex": 1,
            "hero": true,
            "dead": "4c1 5d2 7h3 Ts4",
            "rows": "Ad0 Ks3 9c4/2c0 3h0 6c0 6h1 2h3/9s0 8c1 Tc2 Qh2 2s4",
            "win": -3.4,
            "playerId": "pid5688836"
        },
        {
            "inFantasy": true,
            "result": 17,
            "playerName": "pid5257862",
            "orderIndex": 0,
            "hero": false,
            "dead": "4d0 9h1",
            "rows": "Th0 Td0 Kc0/5h0 5s0 8d0 8s0 Jc0/3c0 3s0 Qd0 Qc0 Qs0",
            "win": 3.3,
            "playerId": "pid5257862"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:12:34",
    "roomId": "21907751"
}


