{
    "stakes": 5,
    "handData": {"210330130438-21936576-0000000-1": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5669865",
            "orderIndex": 1,
            "hero": false,
            "dead": "3s1 7h2 Jc3 5d4",
            "rows": "3h0 7c0 9s0/5h1 5s2 6h3 8s3 4s4/Ts0 Ah0 Qs1 Qd2 Js4",
            "win": 29.1,
            "playerId": "pid5669865"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5650827",
            "orderIndex": 0,
            "hero": true,
            "dead": "7s1 2h2 9d3 As4",
            "rows": "Kd3 Ks3 Kc4/5c0 9c0 6c1 8c2 2s4/6d0 7d0 8d0 Td1 2d2",
            "win": -30,
            "playerId": "pid5650827"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "30022",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:18:08",
    "roomId": "21936576"
}


{
    "stakes": 5,
    "handData": {"210330130438-21936576-0000001-1": [
        {
            "inFantasy": false,
            "result": 19,
            "playerName": "pid5669865",
            "orderIndex": 0,
            "hero": false,
            "dead": "9c1 5d2 7c3 2c4",
            "rows": "Kh0 As3 Ac4/Ts0 Js1 Th2 Jd3 9s4/2d0 7d0 Ad0 4d1 8d2",
            "win": 92.1,
            "playerId": "pid5669865"
        },
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid5650827",
            "orderIndex": 1,
            "hero": true,
            "dead": "4c1 7s2 3d3 Qc4",
            "rows": "Kc2 Ks2 Qs3/2h0 5c0 5h1 6h1 Tc4/9d0 Td0 Jc0 Qh3 9h4",
            "win": -95,
            "playerId": "pid5650827"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "30022",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:19:12",
    "roomId": "21936576"
}


{
    "stakes": 5,
    "handData": {"210330130438-21936576-0000002-1": [
        {
            "inFantasy": true,
            "result": 20,
            "playerName": "pid5669865",
            "orderIndex": 1,
            "hero": false,
            "dead": "4d0 Td1 8d2",
            "rows": "Jh0 Jc0 Kh0/2c0 3d0 4c0 5s0 6h0/2s0 3s0 7s0 9s0 As0",
            "win": 97,
            "playerId": "pid5669865"
        },
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid5650827",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ac1 9c2 9h3 Qd4",
            "rows": "Kc0 Ks2 Ad3/2d0 4s0 7d1 7c1 5c4/Tc0 Jd0 Th2 8h3 5d4",
            "win": -100,
            "playerId": "pid5650827"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "30022",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:20:07",
    "roomId": "21936576"
}


