{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000000-1": [
        {
            "inFantasy": false,
            "result": 11,
            "playerName": "pid5679885",
            "orderIndex": 2,
            "hero": false,
            "dead": "4s1 Qc2 Jh3 7s4",
            "rows": "2h1 Ac3 Js4/8c0 9h0 6h1 Tc2 Ts3/8d0 Td0 Kd0 6d2 5d4",
            "win": 10.7,
            "playerId": "pid5679885"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "pid5693395",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jc1 Qd2 2c3 8h4",
            "rows": "Ks0 7d3 Qh4/2s0 9d0 6s1 As2 3c4/4h0 5h0 Th1 7h2 Ah3",
            "win": 8.7,
            "playerId": "pid5693395"
        },
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid4511013",
            "orderIndex": 1,
            "hero": false,
            "dead": "9s1 6c2 Ad3 3s4",
            "rows": "Kh0 Kc2 5s4/2d0 4c0 3d2 3h3 4d3/8s0 9c0 7c1 Jd1 5c4",
            "win": -20,
            "playerId": "pid4511013"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:42:08",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000001-1": [
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "pid5679885",
            "orderIndex": 1,
            "hero": false,
            "dead": "2h1 4h2 Kh3 7c4",
            "rows": "Kd0 Kc0 Js3/4s0 5c0 3h1 4d2 5h2/8c0 8d1 8h3 Ah4 Ad4",
            "win": 17.5,
            "playerId": "pid5679885"
        },
        {
            "inFantasy": false,
            "result": -23,
            "playerName": "pid5693395",
            "orderIndex": 2,
            "hero": true,
            "dead": "3d1 9d2 2s3 Jd4",
            "rows": "Tc0 Td1 9h3/2d0 Jh0 Qd2 6d4 Qs4/5s0 7s0 6h1 5d2 6c3",
            "win": -23,
            "playerId": "pid5693395"
        },
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid4511013",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qh1 7h2 7d3 3s4",
            "rows": "As2 Th3 9c4/9s0 Ts0 6s1 Ks1 8s4/2c0 4c0 Ac0 Qc2 Jc3",
            "win": 4.8,
            "playerId": "pid4511013"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:44:27",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000002-1": [
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "pid5679885",
            "orderIndex": 0,
            "hero": false,
            "dead": "5s0 3c1",
            "rows": "Tc0 Jd0 Kc0/3h0 5h0 7h0 Th0 Qh0/6d0 6c0 Ah0 Ad0 As0",
            "win": 20.4,
            "playerId": "pid5679885"
        },
        {
            "inFantasy": false,
            "result": -4,
            "playerName": "pid5693395",
            "orderIndex": 1,
            "hero": true,
            "dead": "9c1 8d2 4d3 Ac4",
            "rows": "Kh0 Kd0 5c3/7c0 3d1 2h2 2s2 7s4/Td0 Jh0 Js1 Ts3 7d4",
            "win": -4,
            "playerId": "pid5693395"
        },
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid4511013",
            "orderIndex": 2,
            "hero": false,
            "dead": "Ks1 9d2 9s3 3s4",
            "rows": "4h0 6h0 9h0/2d2 4c3 8h3 4s4 6s4/Qd0 Qc0 8c1 8s1 Qs2",
            "win": -17,
            "playerId": "pid4511013"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:45:46",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000003-1": [
        {
            "inFantasy": false,
            "result": -48,
            "playerName": "pid5679885",
            "orderIndex": 2,
            "hero": false,
            "dead": "7s1 2h2 7h3 3h4",
            "rows": "Kc0 6h2 Jc3/Ts0 Jh0 8s1 As3 8c4/6d0 7d0 3d1 Qd2 Ad4",
            "win": -48,
            "playerId": "pid5679885"
        },
        {
            "inFantasy": true,
            "result": 49,
            "playerName": "pid5693395",
            "orderIndex": 0,
            "hero": true,
            "dead": "5s0 7c0",
            "rows": "3c0 3s0 Kh0/4h0 4d0 4c0 4s0 8h0/9h0 9d0 9c0 9s0 Jd0",
            "win": 47.5,
            "playerId": "pid5693395"
        },
        {
            "inFantasy": false,
            "result": -1,
            "playerName": "pid4511013",
            "orderIndex": 1,
            "hero": false,
            "dead": "Js1 6c2 6s3 Qc4",
            "rows": "Kd0 Ks1 8d2/Ah0 2c1 5h2 2d4 5c4/Td0 Qh0 Qs0 Th3 Tc3",
            "win": -1,
            "playerId": "pid4511013"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:47:21",
    "roomId": "21931339"
}





