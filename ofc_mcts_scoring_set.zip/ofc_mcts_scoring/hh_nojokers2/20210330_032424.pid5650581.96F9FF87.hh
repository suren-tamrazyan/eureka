{
    "stakes": 20,
    "handData": {"210330022107-21902689-0000000-1": [
        {
            "inFantasy": false,
            "result": -1,
            "playerName": "pid233574",
            "orderIndex": 1,
            "hero": false,
            "dead": "7s1 Kd2 5s3 7h4",
            "rows": "As3 Th4 Kc4/9d0 Js0 6c1 6s2 Jh3/3h0 5h0 8h0 4h1 6h2",
            "win": -20,
            "playerId": "pid233574"
        },
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid5650581",
            "orderIndex": 0,
            "hero": true,
            "dead": "9s1 8d2 3d3 3c4",
            "rows": "Ac1 Jd2 9c4/2c0 7c0 Tc3 Ts3 2d4/4d0 Qc0 Qs0 Qd1 4c2",
            "win": 19.4,
            "playerId": "pid5650581"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "8863",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:24:24",
    "roomId": "21902689"
}


{
    "stakes": 20,
    "handData": {"210330022107-21902689-0000001-1": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid233574",
            "orderIndex": 0,
            "hero": false,
            "dead": "8c1 Qh2 9d3 Kc4",
            "rows": "Ah1 Ad2 4c3/2d0 4h0 6d0 6s1 2s2/Th0 Td0 3c3 3d4 4s4",
            "win": 116.4,
            "playerId": "pid233574"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5650581",
            "orderIndex": 1,
            "hero": true,
            "dead": "3h1 6c2 4d3 Ts4",
            "rows": "Jd1 Qc2 5s4/2h0 5c0 7d0 Kh3 Ks4/9s0 Qs0 8s1 Js2 As3",
            "win": -120,
            "playerId": "pid5650581"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "8863",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:25:35",
    "roomId": "21902689"
}


{
    "stakes": 20,
    "handData": {"210330022107-21902689-0000002-1": [
        {
            "inFantasy": true,
            "result": 40,
            "playerName": "pid233574",
            "orderIndex": 1,
            "hero": false,
            "dead": "7s0 4c1 6c2",
            "rows": "Ah0 Ad0 Ac0/2d0 7d0 8d0 9d0 Kd0/4h0 6h0 9h0 Qh0 Kh0",
            "win": 776,
            "playerId": "pid233574"
        },
        {
            "inFantasy": false,
            "result": -40,
            "playerName": "pid5650581",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qc1 Js2 2c3 As4",
            "rows": "Kc0 Qd1 Jd3/3s0 6d0 3d2 4d2 3c3/8h0 Jh0 7h1 2h4 Tc4",
            "win": -800,
            "playerId": "pid5650581"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "8863",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:26:18",
    "roomId": "21902689"
}


{
    "stakes": 20,
    "handData": {"210330022107-21902689-0000003-1": [
        {
            "inFantasy": true,
            "result": 27,
            "playerName": "pid233574",
            "orderIndex": 0,
            "hero": false,
            "dead": "6c0 6d1 3c2",
            "rows": "Qh0 Qc0 Ah0/4s0 5s0 6s0 9s0 Ks0/Td0 Tc0 Ts0 Jd0 Jc0",
            "win": 96.4,
            "playerId": "pid233574"
        },
        {
            "inFantasy": false,
            "result": -27,
            "playerName": "pid5650581",
            "orderIndex": 1,
            "hero": true,
            "dead": "2s1 2c2 8s3 As4",
            "rows": "Kc0 7h2 7s4/4d0 6h0 4c1 3s2 3d3/9c0 Th0 Qd1 8c3 2d4",
            "win": -99.4,
            "playerId": "pid5650581"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "8863",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:27:10",
    "roomId": "21902689"
}


{
    "stakes": 20,
    "handData": {"210330022107-21902689-0000004-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid233574",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qc1 Qs2 9h3 Qd4",
            "rows": "Ah0 Ad0 Qh3/2d0 4s1 5c1 6s2 6h4/8h0 Th0 9s2 7s3 Jd4",
            "win": 0,
            "playerId": "pid233574"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5650581",
            "orderIndex": 0,
            "hero": true,
            "dead": "2c1 5h2 2s3 Td4",
            "rows": "8d2 Kh2 Kd3/4h0 Jc0 Js3 5d4 7d4/3s0 5s0 8s0 Ts1 As1",
            "win": 0,
            "playerId": "pid5650581"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "8863",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:28:15",
    "roomId": "21902689"
}


