{
    "stakes": 0.2,
    "handData": {"210330050513-21911102-0000000-1": [
        {
            "inFantasy": false,
            "result": -13,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "5s1 4s2 Th3 Jc4",
            "rows": "6c2 Tc2 2s3/3c0 7h0 Jh0 Qc3 4c4/Td0 Qd0 2d1 5d1 Ts4",
            "win": -2.6,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": 13,
            "playerName": "pid5359358",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jd1 2c2 3d3 8s4",
            "rows": "Kc0 8c2 8h4/Qs0 7s1 9s1 As3 9d4/2h0 5h0 9h0 4h2 Qh3",
            "win": 2.5,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:50:45",
    "roomId": "21911102"
}


{
    "stakes": 0.2,
    "handData": {"210330050513-21911102-0000001-1": [
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "3h1 7h2 9c3 4h4",
            "rows": "Kd0 Tc4 Ac4/2h0 Js2 Qh2 6c3 6s3/7c0 8c0 9h0 Th1 Jc1",
            "win": -1.6,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": 8,
            "playerName": "pid5359358",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qs1 Ts2 4c3 8d4",
            "rows": "Ah0 Qc2 Ks4/2c0 5s0 7s2 8h3 8s3/4d0 7d0 3d1 6d1 Td4",
            "win": 1.6,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:51:28",
    "roomId": "21911102"
}


{
    "stakes": 0.2,
    "handData": {"210330050513-21911102-0000002-1": [
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "Td1 6h2 8c3 5h4",
            "rows": "Kh0 As2 Ts3/7c0 3d1 4s1 7s2 6c4/2h0 2d0 Qh0 9s3 2c4",
            "win": -1,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid5359358",
            "orderIndex": 0,
            "hero": false,
            "dead": "4h1 Kc2 Tc3 3h4",
            "rows": "Ah0 Kd1 5d4/Qd0 7d1 6d2 Qs3 Ad4/5s0 6s0 Ks0 8s2 Js3",
            "win": 1,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:52:37",
    "roomId": "21911102"
}


{
    "stakes": 0.2,
    "handData": {"210330050513-21911102-0000003-1": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "Js1 7c2 7h3 Jc4",
            "rows": "Ks1 9h2 Ac3/3d0 5d0 4d1 3h2 Jh3/8h0 8s0 Tc0 Ts4 Qs4",
            "win": 1.2,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5359358",
            "orderIndex": 1,
            "hero": false,
            "dead": "5h1 Kc2 5c3 3c4",
            "rows": "As0 Ah2 4s3/2h0 7s0 3s1 7d1 4h3/9d0 Qd0 Td2 6h4 9s4",
            "win": -1.2,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:53:23",
    "roomId": "21911102"
}


{
    "stakes": 0.2,
    "handData": {"210330050513-21911102-0000004-1": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "9d1 Js2 7s3 Ts4",
            "rows": "Qc1 6s3 8c3/8h0 Jd0 2c1 Qd2 4d4/2s0 4h0 5s0 Ac2 Ad4",
            "win": 1.2,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5359358",
            "orderIndex": 0,
            "hero": false,
            "dead": "4s1 2h2 6d3 Th4",
            "rows": "Kh1 3h2 Kc2/5d0 8d0 7d1 5h3 Kd4/9h0 9c0 Qs0 Jc3 As4",
            "win": -1.2,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:54:35",
    "roomId": "21911102"
}


{
    "stakes": 0.2,
    "handData": {"210330050513-21911102-0000005-1": [
        {
            "inFantasy": false,
            "result": 14,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "2s1 Ac2 8c3 7c4",
            "rows": "Kh0 Kc2 9s3/6h0 5h1 5c2 Tc3 Td4/3d0 Qc0 Qs0 Qh1 6c4",
            "win": 2.7,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid5359358",
            "orderIndex": 1,
            "hero": false,
            "dead": "4h1 2c2 Jc3 5s4",
            "rows": "Ah0 Ad2 Ts3/4s0 Js0 3s1 Jh2 4c3/8d0 Qd0 Kd1 7s4 8s4",
            "win": -2.8,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:55:26",
    "roomId": "21911102"
}


{
    "stakes": 0.2,
    "handData": {"210330050513-21911102-0000006-1": [
        {
            "inFantasy": true,
            "result": 41,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "7c0 8c0",
            "rows": "Kh0 Kc0 Ks0/2h0 4h0 9h0 Th0 Qh0/5h0 5d0 5s0 Jd0 Jc0",
            "win": 8,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": -41,
            "playerName": "pid5359358",
            "orderIndex": 0,
            "hero": false,
            "dead": "6c1 3c2 Td3 3s4",
            "rows": "Kd2 Ac3 9d4/2c0 3d0 4s0 5c1 6h2/9s0 Tc0 8d1 Js3 Ts4",
            "win": -8.2,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:55:57",
    "roomId": "21911102"
}


{
    "stakes": 0.2,
    "handData": {"210330050513-21911102-0000007-1": [
        {
            "inFantasy": true,
            "result": 14,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "6s0 2d0",
            "rows": "Js0 Ad0 As0/7h0 8h0 8s0 Qd0 Qs0/5c0 8c0 Tc0 Jc0 Kc0",
            "win": 2.7,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid5359358",
            "orderIndex": 1,
            "hero": false,
            "dead": "2c1 2h2 2s3 7s4",
            "rows": "Ts3 Ac3 Td4/4c0 7d0 4d1 6h1 6c2/5d0 5s0 9c0 9h2 4h4",
            "win": -2.8,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:56:31",
    "roomId": "21911102"
}


{
    "stakes": 0.2,
    "handData": {"210330050513-21911102-0000008-1": [
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5694588",
            "orderIndex": 1,
            "hero": false,
            "dead": "2c1 4d2 2d3 3s4",
            "rows": "Ks3 Tc4 Kd4/3d0 7c0 3h1 7d1 9s3/5d0 8h0 8d0 6h2 6d2",
            "win": -2,
            "playerId": "pid5694588"
        },
        {
            "inFantasy": false,
            "result": 11,
            "playerName": "pid5679020",
            "orderIndex": 2,
            "hero": true,
            "dead": "8c1 As2 6c3 2h4",
            "rows": "Ad0 Ac1 Kh3/3c0 7h0 4h2 4s2 4c4/9h0 Ts0 Qd1 9c3 9d4",
            "win": 2.1,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": -1,
            "playerName": "pid5359358",
            "orderIndex": 0,
            "hero": false,
            "dead": "Td1 7s2 Js3 Th4",
            "rows": "Ah1 8s2 Kc4/2s0 5h0 6s2 5c3 5s4/Jh0 Qc0 Qs0 Jd1 Jc3",
            "win": -0.2,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:57:49",
    "roomId": "21911102"
}


{
    "stakes": 0.2,
    "handData": {"210330050513-21911102-0000009-1": [
        {
            "inFantasy": true,
            "result": -3,
            "playerName": "pid5694588",
            "orderIndex": 0,
            "hero": false,
            "dead": "2c0 4d1",
            "rows": "9d0 Jd0 Qc0/2s0 5s0 6s0 9s0 Qs0/3h0 5h0 Th0 Kh0 Ah0",
            "win": -0.6,
            "playerId": "pid5694588"
        },
        {
            "inFantasy": true,
            "result": 17,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "4h0 4c0 2h0",
            "rows": "Js0 Kc0 Ks0/6h0 7h0 8s0 9c0 Td0/3d0 3c0 3s0 Tc0 Ts0",
            "win": 3.3,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid5359358",
            "orderIndex": 2,
            "hero": false,
            "dead": "6d1 Qh2 Qd3 2d4",
            "rows": "Kd1 Ad1 Ac2/4s0 5c0 7d2 7c3 5d4/8h0 8c0 9h0 8d3 6c4",
            "win": -2.8,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:58:42",
    "roomId": "21911102"
}


{
    "stakes": 0.2,
    "handData": {"210330050513-21911102-0000010-1": [
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5694588",
            "orderIndex": 2,
            "hero": false,
            "dead": "9h1 Jh2 8c3 3c4",
            "rows": "Kh3 8s4 As4/4c0 6h0 5d1 6d2 4d3/9s0 Td0 Jd0 Qh1 8h2",
            "win": -2,
            "playerId": "pid5694588"
        },
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "6c1 2h2 9d3 2d4",
            "rows": "Qc0 Ah1 Kd4/3h0 4h1 4s2 7s3 Qs4/Tc0 Ts0 Js0 Th2 2c3",
            "win": -3.6,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": true,
            "result": 28,
            "playerName": "pid5359358",
            "orderIndex": 1,
            "hero": false,
            "dead": "3s0 2s1 6s2",
            "rows": "7h0 Jc0 Ac0/3d0 7d0 8d0 Qd0 Ad0/5h0 5c0 5s0 Kc0 Ks0",
            "win": 5.4,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:59:43",
    "roomId": "21911102"
}


{
    "stakes": 0.2,
    "handData": {"210330050513-21911102-0000011-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5694588",
            "orderIndex": 1,
            "hero": false,
            "dead": "2h1 Qc2 Kd3 Ac4",
            "rows": "Kc0 Kh1 Jc3/5h0 6s0 7d1 5d2 8s4/9d0 Ts0 9h2 Th3 Qd4",
            "win": -1.2,
            "playerId": "pid5694588"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5679020",
            "orderIndex": 2,
            "hero": true,
            "dead": "5s1 4c2 4d3 Qs4",
            "rows": "Ad1 8c2 Td3/2d0 3s0 Js2 Ks3 Jd4/6h0 7h0 8h0 4h1 3d4",
            "win": -1.2,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid5359358",
            "orderIndex": 0,
            "hero": false,
            "dead": "4s1 2s2 5c3 9c4",
            "rows": "2c2 Jh3 As4/7s0 8d0 Tc0 7c1 Ah4/3h0 Qh0 3c1 6c2 6d3",
            "win": 2.3,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:01:07",
    "roomId": "21911102"
}


{
    "stakes": 0.2,
    "handData": {"210330050513-21911102-0000012-1": [
        {
            "inFantasy": false,
            "result": -33,
            "playerName": "pid5694588",
            "orderIndex": 0,
            "hero": false,
            "dead": "3d1 3h2 Qs3 3c4",
            "rows": "Kd0 Kh1 5s2/2d0 9c0 2c1 9d2 5d3/Jc0 Js0 Td3 7c4 Kc4",
            "win": -6.6,
            "playerId": "pid5694588"
        },
        {
            "inFantasy": false,
            "result": -33,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "2h1 4s2 9h3 Qh4",
            "rows": "Ah2 Th3 Jh4/3s0 4h1 5h1 2s3 Tc4/5c0 6c0 Qc0 Ac0 4c2",
            "win": -6.6,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": 66,
            "playerName": "pid5359358",
            "orderIndex": 2,
            "hero": false,
            "dead": "Qd1 9s2 Jd3 Ts4",
            "rows": "4d3 As3 Ad4/6h0 6d0 8c0 8h1 6s4/7d0 7s0 7h1 8d2 8s2",
            "win": 12.8,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:02:36",
    "roomId": "21911102"
}


{
    "stakes": 0.2,
    "handData": {"210330050513-21911102-0000013-1": [
        {
            "inFantasy": false,
            "result": -4,
            "playerName": "pid5694588",
            "orderIndex": 2,
            "hero": false,
            "dead": "Jh1 5s2 6c3 3h4",
            "rows": "Qc1 Ac2 As3/8c0 8s0 Tc2 8d3 9d4/3d0 4d0 Jd0 Ad1 Kd4",
            "win": -0.8,
            "playerId": "pid5694588"
        },
        {
            "inFantasy": false,
            "result": -33,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "9s1 9c2 5c3 4c4",
            "rows": "Ks0 Js3 Ah3/6s0 8h0 Th2 Td2 3s4/7c0 7s0 2h1 2c1 2s4",
            "win": -6.6,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": true,
            "result": 37,
            "playerName": "pid5359358",
            "orderIndex": 1,
            "hero": false,
            "dead": "Kc0 Ts1 2d2",
            "rows": "Qh0 Qd0 Qs0/3c0 4s0 5d0 6d0 7d0/4h0 5h0 7h0 9h0 Kh0",
            "win": 7.2,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:03:28",
    "roomId": "21911102"
}


{
    "stakes": 0.2,
    "handData": {"210330050513-21911102-0000014-1": [
        {
            "inFantasy": true,
            "result": 17,
            "playerName": "pid5694588",
            "orderIndex": 1,
            "hero": false,
            "dead": "Ts0 4s1 Tc2",
            "rows": "Qs0 Kd0 Ks0/2d0 4d0 8d0 9d0 Qd0/5h0 6h0 8h0 Jh0 Ah0",
            "win": 3.3,
            "playerId": "pid5694588"
        },
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid5679020",
            "orderIndex": 2,
            "hero": true,
            "dead": "Qh1 Jc2 3h3 Th4",
            "rows": "As1 Ac2 7c3/2h0 2s0 6c0 6s3 Kh4/5c0 5s0 Js1 5d2 9c4",
            "win": -3.6,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": true,
            "result": 1,
            "playerName": "pid5359358",
            "orderIndex": 0,
            "hero": false,
            "dead": "4h0 3s1 9s2",
            "rows": "Td0 Jd0 Ad0/2c0 3c0 4c0 Qc0 Kc0/7h0 7d0 7s0 8c0 8s0",
            "win": 0.2,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:04:37",
    "roomId": "21911102"
}


{
    "stakes": 0.2,
    "handData": {"210330050513-21911102-0000015-1": [
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5694588",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jc1 3s2 Qc3 Ks4",
            "rows": "As0 Kc1 Kd4/2h0 4c0 2c3 5d3 4d4/8d0 Qd0 9d1 8h2 Qh2",
            "win": -2,
            "playerId": "pid5694588"
        },
        {
            "inFantasy": true,
            "result": 42,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "Tc0 9c0 3c0",
            "rows": "Kh0 Ah0 Ad0/8s0 9h0 Td0 Js0 Qs0/2d0 2s0 7h0 7d0 7s0",
            "win": 8.1,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": -32,
            "playerName": "pid5359358",
            "orderIndex": 2,
            "hero": false,
            "dead": "3d1 7c2 6c3 3h4",
            "rows": "Jh1 Th4 Ac4/6d0 8c0 4s1 6h2 4h3/5c0 5s0 Ts0 9s2 5h3",
            "win": -6.4,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:05:48",
    "roomId": "21911102"
}


{
    "stakes": 0.2,
    "handData": {"210330050513-21911102-0000016-1": [
        {
            "inFantasy": true,
            "result": 14,
            "playerName": "pid5694588",
            "orderIndex": 2,
            "hero": false,
            "dead": "9s0 7h1",
            "rows": "Kd0 Ah0 As0/3h0 3s0 8c0 8s0 Qc0/2h0 2s0 Jh0 Jd0 Js0",
            "win": 2.7,
            "playerId": "pid5694588"
        },
        {
            "inFantasy": false,
            "result": -23,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "2d1 3d2 2c3 5d4",
            "rows": "Ad2 6c4 7d4/6d0 8h0 6s1 8d2 4s3/5c0 9c0 Tc0 Kc1 3c3",
            "win": -4.6,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "pid5359358",
            "orderIndex": 1,
            "hero": false,
            "dead": "5s1 9d2 Jc3 6h4",
            "rows": "Ks0 5h1 Kh1/7c0 4c2 Ac2 4h4 7s4/Td0 Ts0 Qd0 Qh3 Qs3",
            "win": 1.7,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:06:50",
    "roomId": "21911102"
}


{
    "stakes": 0.2,
    "handData": {"210330050513-21911102-0000017-1": [
        {
            "inFantasy": false,
            "result": -13,
            "playerName": "pid5694588",
            "orderIndex": 1,
            "hero": false,
            "dead": "7c1 2c2 4h3 5c4",
            "rows": "Ac1 Qh2 9s4/6d0 Td0 4c3 6c3 Ts4/2s0 3s0 8s0 As1 7s2",
            "win": -2.6,
            "playerId": "pid5694588"
        },
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid5679020",
            "orderIndex": 2,
            "hero": true,
            "dead": "9c1 Jc2 7d3 3d4",
            "rows": "Kh0 Kc0 Js3/2d0 5d2 8h3 5s4 8d4/Th0 Jd0 Qs1 Kd1 Ad2",
            "win": 1,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": true,
            "result": 8,
            "playerName": "pid5359358",
            "orderIndex": 0,
            "hero": false,
            "dead": "Tc0 9d1",
            "rows": "Qd0 Qc0 Ks0/3c0 4d0 4s0 6h0 6s0/3h0 5h0 7h0 Jh0 Ah0",
            "win": 1.6,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:08:07",
    "roomId": "21911102"
}


{
    "stakes": 0.2,
    "handData": {"210330050513-21911102-0000018-1": [
        {
            "inFantasy": false,
            "result": -35,
            "playerName": "pid5694588",
            "orderIndex": 0,
            "hero": false,
            "dead": "3d1 7d2 7s3 9d4",
            "rows": "As1 Qc2 Jd3/4c0 6h0 5s1 4h3 Qh4/2d0 2s0 8s0 Ts2 7h4",
            "win": -7,
            "playerId": "pid5694588"
        },
        {
            "inFantasy": true,
            "result": 58,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "9s0 2h0",
            "rows": "Th0 Tc0 Qs0/3h0 3s0 Kh0 Kc0 Ks0/8h0 8d0 Ah0 Ad0 Ac0",
            "win": 11.3,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": -23,
            "playerName": "pid5359358",
            "orderIndex": 2,
            "hero": false,
            "dead": "9c1 3c2 8c3 Td4",
            "rows": "Kd0 5h2 6c3/2c0 4s0 4d1 7c2 5d4/Jh0 Qd0 Jc1 9h3 Js4",
            "win": -4.6,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:09:03",
    "roomId": "21911102"
}


{
    "stakes": 0.2,
    "handData": {"210330050513-21911102-0000019-1": [
        {
            "inFantasy": false,
            "result": -22,
            "playerName": "pid5694588",
            "orderIndex": 2,
            "hero": false,
            "dead": "3s1 Th2 Jc3 5d4",
            "rows": "As0 Qh1 Ad3/2d0 8s0 Jh2 Jd2 3h4/7c0 Kc0 Kh1 Qd3 5h4",
            "win": -4.4,
            "playerId": "pid5694588"
        },
        {
            "inFantasy": false,
            "result": 7,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "6s1 2s2 7d3 5s4",
            "rows": "9d1 Kd2 4s4/4c0 Ts0 Tc1 Qc3 4d4/2h0 6h0 7h0 4h2 9h3",
            "win": 1.4,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "pid5359358",
            "orderIndex": 1,
            "hero": false,
            "dead": "Js1 Td2 7s3 Ah4",
            "rows": "Ac0 Qs1 Ks3/2c0 3d1 6d2 5c3 6c4/8h0 8d0 9c0 8c2 9s4",
            "win": 2.9,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:09:59",
    "roomId": "21911102"
}


{
    "stakes": 0.2,
    "handData": {"210330050513-21911102-0000020-1": [
        {
            "inFantasy": false,
            "result": 13,
            "playerName": "pid5694588",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qs1 3c2 9c3 7d4",
            "rows": "Ac0 Jc3 As3/8h0 2d1 2c1 4h2 8s4/5h0 5d0 Qc0 5c2 9h4",
            "win": 2.5,
            "playerId": "pid5694588"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "pid5679020",
            "orderIndex": 2,
            "hero": true,
            "dead": "Qh1 Ts2 Kd3 2h4",
            "rows": "Ah0 9s4 Ad4/7s0 6h1 Ks2 6c3 Kh3/8d0 Jd0 Qd0 Jh1 Js2",
            "win": 2.9,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": -28,
            "playerName": "pid5359358",
            "orderIndex": 0,
            "hero": false,
            "dead": "8c1 3h2 Kc3 Tc4",
            "rows": "5s2 6d4 6s4/2s0 3s0 3d1 4c1 4s3/7h0 7c0 9d0 Th2 Td3",
            "win": -5.6,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:11:19",
    "roomId": "21911102"
}


{
    "stakes": 0.2,
    "handData": {"210330050513-21911102-0000021-1": [
        {
            "inFantasy": true,
            "result": 37,
            "playerName": "pid5694588",
            "orderIndex": 0,
            "hero": false,
            "dead": "6c0 5d1 7d2",
            "rows": "Qd0 Qc0 Ks0/8h0 8c0 8s0 9h0 9d0/Th0 Tc0 Ah0 Ac0 As0",
            "win": 7.2,
            "playerId": "pid5694588"
        },
        {
            "inFantasy": true,
            "result": 20,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "2h0 4h0 6h0",
            "rows": "Kd0 Kc0 Ad0/2c0 3c0 4c0 5c0 7c0/3s0 5s0 7s0 Js0 Qs0",
            "win": 3.9,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": -57,
            "playerName": "pid5359358",
            "orderIndex": 2,
            "hero": false,
            "dead": "5h1 3d2 3h3 4s4",
            "rows": "Kh0 9s2 6d3/2d0 2s0 7h1 4d2 9c3/Td0 Ts0 Qh1 Jd4 Jc4",
            "win": -11.4,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:12:26",
    "roomId": "21911102"
}


{
    "stakes": 0.2,
    "handData": {"210330050513-21911102-0000022-1": [
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid5694588",
            "orderIndex": 2,
            "hero": false,
            "dead": "8s1 8h2 2s3 Tc4",
            "rows": "Ks0 Qs2 Jc4/3h0 7s0 5h1 4h2 As4/6d0 Jd0 2d1 4d3 Td3",
            "win": -3.2,
            "playerId": "pid5694588"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "5c1 9d2 Kc3 3c4",
            "rows": "Ah2 Ad3 Jh4/2h0 Qd0 2c1 Th1 Ts2/5d0 6s0 7c0 4c3 3d4",
            "win": 1.7,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": 7,
            "playerName": "pid5359358",
            "orderIndex": 1,
            "hero": false,
            "dead": "8d1 8c2 Kd3 9c4",
            "rows": "Qc0 Ac3 Qh4/6h0 7d0 7h1 6c2 Kh4/3s0 4s0 Js1 5s2 9s3",
            "win": 1.4,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:13:16",
    "roomId": "21911102"
}


{
    "stakes": 0.2,
    "handData": {"210330050513-21911102-0000023-1": [
        {
            "inFantasy": false,
            "result": -62,
            "playerName": "pid5694588",
            "orderIndex": 1,
            "hero": false,
            "dead": "5d1 3h2 3d3 2s4",
            "rows": "Ad1 Qs2 Qh4/4h0 5c0 4s1 5h3 6h3/7d0 9h0 Jd0 Jh2 6s4",
            "win": -12.4,
            "playerId": "pid5694588"
        },
        {
            "inFantasy": true,
            "result": 71,
            "playerName": "pid5679020",
            "orderIndex": 2,
            "hero": true,
            "dead": "5s0 2h0 8h0",
            "rows": "Th0 Td0 Js0/2c0 3c0 4c0 7c0 9c0/Tc0 Jc0 Qc0 Kc0 Ac0",
            "win": 13.8,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": true,
            "result": -9,
            "playerName": "pid5359358",
            "orderIndex": 0,
            "hero": false,
            "dead": "6c0",
            "rows": "7h0 8c0 Kh0/2d0 4d0 6d0 9d0 Kd0/3s0 7s0 9s0 Ts0 Ks0",
            "win": -1.8,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:14:09",
    "roomId": "21911102"
}


{
    "stakes": 0.2,
    "handData": {"210330050513-21911102-0000024-1": [
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "pid5694588",
            "orderIndex": 0,
            "hero": false,
            "dead": "9s1 6s2 6h3 3s4",
            "rows": "4h3 4s3 8h4/2h0 2c1 5c1 2d2 Jh2/8s0 9h0 Ts0 Jd0 7d4",
            "win": -1.8,
            "playerId": "pid5694588"
        },
        {
            "inFantasy": true,
            "result": 42,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "3h0 3d0 4d0",
            "rows": "Tc0 Ac0 As0/9c0 Th0 Jc0 Qh0 Kd0/5s0 7s0 Js0 Qs0 Ks0",
            "win": 8.1,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": -33,
            "playerName": "pid5359358",
            "orderIndex": 2,
            "hero": false,
            "dead": "7c1 4c2 Kc3 8c4",
            "rows": "Kh0 Ah0 Ad2/2s0 3c2 Qd3 5h4 7h4/9d0 Td0 5d1 6d1 8d3",
            "win": -6.6,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:15:04",
    "roomId": "21911102"
}


{
    "stakes": 0.2,
    "handData": {"210330050513-21911102-0000025-1": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5694588",
            "orderIndex": 2,
            "hero": false,
            "dead": "8s1 Kc2 6c3 Qh4",
            "rows": "Kd0 Kh1 4d2/2c0 Td0 Th2 8d3 8c3/4s0 9s0 Ts1 8h4 9h4",
            "win": -2.4,
            "playerId": "pid5694588"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "3h1 3c2 7s3 Ad4",
            "rows": "Qc0 Jh4 Jc4/Ah0 Ac0 2d2 3d2 Tc3/5s0 6s0 9d1 9c1 5h3",
            "win": 4.7,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5359358",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qs1 2h2 2s3 3s4",
            "rows": "Ks0 As1 7d4/4c0 6d0 7c1 6h2 4h3/5d0 5c0 Qd2 Jd3 7h4",
            "win": -2.4,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:16:23",
    "roomId": "21911102"
}


