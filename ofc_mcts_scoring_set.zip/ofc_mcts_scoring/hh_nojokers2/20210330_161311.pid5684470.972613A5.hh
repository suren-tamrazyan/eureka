{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000133-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid1793219",
            "orderIndex": 0,
            "hero": false,
            "dead": "2s1 3d2 7s3 Kd4",
            "rows": "Ks0 3h1 Tc3/4h0 8s0 5c1 5d2 Ac4/9d0 Qc0 6h2 Jh3 Td4",
            "win": -1.2,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "5h1 3s2 4c3 9s4",
            "rows": "Kc1 Ad3 Qd4/7h0 8d0 7d1 4d2 8c2/2d0 2c0 Qs0 Th3 Ts4",
            "win": 1.2,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": false,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:13:11",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000134-1": [
        {
            "inFantasy": false,
            "result": 19,
            "playerName": "pid1793219",
            "orderIndex": 2,
            "hero": false,
            "dead": "8s1 3h2 9c3 2s4",
            "rows": "Kc0 4c2 9s4/2h0 3c0 5h0 3s1 5s3/7d0 8d1 8c2 7s3 7c4",
            "win": 3.7,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": false,
            "result": -1,
            "playerName": "pid5684470",
            "orderIndex": 0,
            "hero": true,
            "dead": "2d1 2c2 4s3 Td4",
            "rows": "Ad1 Jh2 Kd4/5c0 7h0 4h1 6s2 6c3/9d0 Js0 Qc0 Qs3 Qh4",
            "win": -0.2,
            "playerId": "pid5684470"
        },
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "3d1 4d2 9h3 Jd4",
            "rows": "Ac0 Ah1 Qd3/5d0 8h0 6d1 Ks4 As4/Th0 Jc0 Ts2 Kh2 Tc3",
            "win": -3.6,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:14:24",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000135-1": [
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid1793219",
            "orderIndex": 1,
            "hero": false,
            "dead": "Kh1 3h2 6h3 Td4",
            "rows": "Ad0 7h3 Ac3/5c0 2c1 4d1 2d2 4s4/9h0 9c0 Qd0 8d2 8c4",
            "win": 1.9,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": false,
            "result": -11,
            "playerName": "pid5684470",
            "orderIndex": 2,
            "hero": true,
            "dead": "4h1 2s2 6s3 7c4",
            "rows": "Th3 3d4 As4/8s0 9d0 9s0 Jd2 Js2/3s0 4c0 5h1 6d1 7d3",
            "win": -2.2,
            "playerId": "pid5684470"
        },
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "2h1 8h2 3c3 Qh4",
            "rows": "5d3 Qc3 5s4/6c0 7s0 Jh2 Jc2 Ah4/Ts0 Kc0 Ks0 Tc1 Kd1",
            "win": 0.2,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:15:46",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000136-1": [
        {
            "inFantasy": true,
            "result": 25,
            "playerName": "pid1793219",
            "orderIndex": 0,
            "hero": false,
            "dead": "4c0 7s1 9d2",
            "rows": "Kh0 Ad0 Ac0/9h0 Th0 Jd0 Qh0 Ks0/5h0 5c0 8d0 8c0 8s0",
            "win": 4.8,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": false,
            "result": -49,
            "playerName": "pid5684470",
            "orderIndex": 1,
            "hero": true,
            "dead": "Td1 3h2 4h3 Kc4",
            "rows": "As1 Qc3 Ah3/2h0 2c0 4d0 2d1 Qd4/7c0 8h0 4s2 6d2 3s4",
            "win": -9.8,
            "playerId": "pid5684470"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "pid2923305",
            "orderIndex": 2,
            "hero": false,
            "dead": "Qs1 5s2 3d3 2s4",
            "rows": "Kd2 3c4 9c4/7h0 7d0 6c1 6h3 6s3/Tc0 Jh0 Js0 Jc1 Ts2",
            "win": 4.7,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:16:39",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000137-1": [
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid1793219",
            "orderIndex": 2,
            "hero": false,
            "dead": "3d1 2s2 5h3 7c4",
            "rows": "7h2 6c3 7d3/4h0 5c0 6h0 4d1 4c2/9s0 Ks0 Kd1 Tc4 As4",
            "win": -3.8,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": false,
            "result": 38,
            "playerName": "pid5684470",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ts1 6s2 9d3 Ah4",
            "rows": "Ac1 Ad2 Kc4/3s0 3c1 Qs2 Jc3 Js4/5d0 6d0 Jd0 Qd0 2d3",
            "win": 7.4,
            "playerId": "pid5684470"
        },
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "8c1 8s2 Qh3 Td4",
            "rows": "Qc0 9c3 Jh3/5s0 2c1 7s2 4s4 9h4/2h0 3h0 Kh0 8h1 Th2",
            "win": -3.8,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:17:56",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000138-1": [
        {
            "inFantasy": false,
            "result": -31,
            "playerName": "pid1793219",
            "orderIndex": 1,
            "hero": false,
            "dead": "9d1 Kd2 Kc3 5h4",
            "rows": "Qc1 Ad2 Qh4/3h0 3c0 4c0 2d1 4d3/6h0 6d0 6c2 Jh3 Js4",
            "win": -6.2,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": true,
            "result": 67,
            "playerName": "pid5684470",
            "orderIndex": 2,
            "hero": true,
            "dead": "5c0 2s0 3d0",
            "rows": "Th0 Td0 Ts0/8d0 8c0 8s0 9h0 9c0/7h0 7d0 7c0 7s0 Jd0",
            "win": 13,
            "playerId": "pid5684470"
        },
        {
            "inFantasy": false,
            "result": -36,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "2h1 Qd2 Tc3 4h4",
            "rows": "Kh0 Ks2 8h4/Ac0 As2 2c3 5d3 4s4/3s0 6s0 9s0 5s1 Qs1",
            "win": -7.2,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:18:46",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000139-1": [
        {
            "inFantasy": true,
            "result": -19,
            "playerName": "pid1793219",
            "orderIndex": 0,
            "hero": false,
            "dead": "5d0",
            "rows": "Jh0 Jc0 Ah0/7h0 9d0 Tc0 Qc0 Qs0/2d0 2s0 4h0 4d0 6s0",
            "win": -3.8,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": true,
            "result": 17,
            "playerName": "pid5684470",
            "orderIndex": 1,
            "hero": true,
            "dead": "3d0 4c0 4s0",
            "rows": "Td0 Kc0 Ks0/7d0 7s0 8c0 Qh0 Qd0/5h0 5c0 5s0 9h0 9s0",
            "win": 3.3,
            "playerId": "pid5684470"
        },
        {
            "inFantasy": true,
            "result": 2,
            "playerName": "pid2923305",
            "orderIndex": 2,
            "hero": false,
            "dead": "3c0 2c1",
            "rows": "8h0 Jd0 Kd0/7c0 8s0 9c0 Th0 Js0/6h0 6d0 6c0 Ad0 As0",
            "win": 0.4,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:19:16",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000140-1": [
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "pid1793219",
            "orderIndex": 2,
            "hero": false,
            "dead": "Ad1 7h2 4d3 5c4",
            "rows": "Kd0 Jc3 Kh4/2s0 4h0 4c1 6h2 2c3/8d0 Tc0 8s1 9d2 6d4",
            "win": -4.2,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "pid5684470",
            "orderIndex": 0,
            "hero": true,
            "dead": "9c1 9s2 3c3 Ts4",
            "rows": "As0 6s3 Td4/2h0 4s0 2d1 7d2 7s2/Qd0 Kc0 Qh1 5d3 Ks4",
            "win": -1.8,
            "playerId": "pid5684470"
        },
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "7c1 9h2 3s3 6c4",
            "rows": "Ah0 Ac0 Qc3/3h0 8h1 8c1 3d2 5h4/Th0 Jd0 Js2 Jh3 5s4",
            "win": 5.8,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:20:14",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000141-1": [
        {
            "inFantasy": false,
            "result": -24,
            "playerName": "pid1793219",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jc1 4h2 3c3 3s4",
            "rows": "Kh0 9h3 5c4/2h0 2s0 3h1 6h2 6c3/8h0 Tc0 8d1 Qc2 6s4",
            "win": -4.8,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": false,
            "result": -24,
            "playerName": "pid5684470",
            "orderIndex": 2,
            "hero": true,
            "dead": "8s1 2d2 Ts3 Ad4",
            "rows": "Ks0 Kc1 Ah4/Js0 6d2 Jd2 7d3 9d4/4d0 4c0 Qd0 Qh1 4s3",
            "win": -4.8,
            "playerId": "pid5684470"
        },
        {
            "inFantasy": true,
            "result": 48,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "3d0 8c1 2c2",
            "rows": "9s0 Jh0 Kd0/5h0 5d0 5s0 Th0 Td0/7h0 7c0 7s0 Ac0 As0",
            "win": 9.3,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:22:03",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000142-1": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid1793219",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qh1 6c2 2d3 6d4",
            "rows": "2s3 Ks3 Ac4/3d0 7d0 3h1 4h2 4c2/Th0 Tc0 Jh0 Jc1 9d4",
            "win": 2.3,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5684470",
            "orderIndex": 1,
            "hero": true,
            "dead": "8c1 8h2 8d3 Jd4",
            "rows": "As0 Ad2 3s4/2c0 7h0 2h1 7s2 4s3/5s0 9s0 9h1 Qd3 3c4",
            "win": -1.2,
            "playerId": "pid5684470"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid2923305",
            "orderIndex": 2,
            "hero": false,
            "dead": "Td1 7c2 Qc3 4d4",
            "rows": "Kc0 Kd2 Kh4/Ah0 5h1 5d1 6h3 9c4/6s0 Ts0 Qs0 Js2 8s3",
            "win": -1.2,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:23:34",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000143-1": [
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "pid1793219",
            "orderIndex": 2,
            "hero": false,
            "dead": "2h1 Ks2 Qd3 3s4",
            "rows": "Ah2 8c3 Kc4/Th0 3c1 9h1 9d2 Ts4/4d0 5s0 7s0 8d0 6s3",
            "win": 1.7,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid5684470",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jh1 3d2 2d3 Kh4",
            "rows": "Ad0 Ac2 Js4/5d0 7h0 6h1 6d1 6c3/9c0 Qh0 8s2 8h3 7d4",
            "win": -3.2,
            "playerId": "pid5684470"
        },
        {
            "inFantasy": false,
            "result": 7,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "4c1 4h2 Tc3 7c4",
            "rows": "4s1 Jc3 As4/2s0 5h0 5c1 Qc2 2c3/Td0 Jd0 Kd0 Qs2 9s4",
            "win": 1.4,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:24:38",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000144-1": [
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid1793219",
            "orderIndex": 1,
            "hero": false,
            "dead": "2h1 2c2 4c3 3c4",
            "rows": "Kc1 9h4 Ah4/Qd0 3h2 Qc2 5c3 5s3/7s0 8s0 Ts0 Js0 3s1",
            "win": 0.2,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "pid5684470",
            "orderIndex": 2,
            "hero": true,
            "dead": "Ad1 As2 4s3 Tc4",
            "rows": "Jd0 Ks2 Kd3/6c0 8c0 6d2 5d4 8d4/4h0 Qh0 Th1 Jh1 5h3",
            "win": 5.2,
            "playerId": "pid5684470"
        },
        {
            "inFantasy": false,
            "result": -28,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "8h1 7c2 7h3 9d4",
            "rows": "Jc0 Ac1 Kh3/3d0 4d0 7d2 Td3 2d4/9s0 Qs0 2s1 6s2 6h4",
            "win": -5.6,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:26:05",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000145-1": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "pid1793219",
            "orderIndex": 0,
            "hero": false,
            "dead": "As1 6h2 9h3 4s4",
            "rows": "Ad0 Ac2 Qc4/2h0 5d0 2d1 2s2 6d4/8h0 8c0 8d1 Jh3 Jc3",
            "win": 4.7,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": true,
            "result": 20,
            "playerName": "pid5684470",
            "orderIndex": 1,
            "hero": true,
            "dead": "8s0 4c0",
            "rows": "3h0 3d0 3s0/7d0 7c0 7s0 Td0 Qh0/9d0 Tc0 Js0 Qs0 Kd0",
            "win": 3.9,
            "playerId": "pid5684470"
        },
        {
            "inFantasy": false,
            "result": -44,
            "playerName": "pid2923305",
            "orderIndex": 2,
            "hero": false,
            "dead": "9s1 Ks2 5c3 Th4",
            "rows": "Kc0 2c2 Kh2/5s0 7h0 4h1 5h1 3c4/Jd0 Qd0 6c3 6s3 Ah4",
            "win": -8.8,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:26:56",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000146-1": [
        {
            "inFantasy": true,
            "result": 28,
            "playerName": "pid1793219",
            "orderIndex": 2,
            "hero": false,
            "dead": "As0 5h1 2d2",
            "rows": "3d0 3c0 3s0/7d0 8h0 9s0 Th0 Jc0/5d0 8d0 Jd0 Kd0 Ad0",
            "win": 5.4,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": true,
            "result": 8,
            "playerName": "pid5684470",
            "orderIndex": 0,
            "hero": true,
            "dead": "7h0 2s0",
            "rows": "Qd0 Qc0 Ah0/8s0 9d0 9c0 Td0 Tc0/4h0 4c0 4s0 6d0 6c0",
            "win": 1.6,
            "playerId": "pid5684470"
        },
        {
            "inFantasy": false,
            "result": -36,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "2c1 5s2 8c3 6s4",
            "rows": "Ac0 Ks2 Qs4/7c0 Js0 7s1 Ts3 6h4/Qh0 Kh0 Jh1 2h2 3h3",
            "win": -7.2,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:27:41",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000147-1": [
        {
            "inFantasy": true,
            "result": 8,
            "playerName": "pid1793219",
            "orderIndex": 1,
            "hero": false,
            "dead": "5c0 5d1 3c2",
            "rows": "7c0 Ad0 As0/8s0 9h0 Td0 Jc0 Qd0/4s0 7s0 Js0 Qs0 Ks0",
            "win": 1.6,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": false,
            "result": -38,
            "playerName": "pid5684470",
            "orderIndex": 2,
            "hero": true,
            "dead": "8d1 7d2 6h3 4d4",
            "rows": "Qh3 Ah3 8h4/3d0 5s0 2d2 2s2 7h4/2c0 6c0 Ac0 4c1 9c1",
            "win": -7.6,
            "playerId": "pid5684470"
        },
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qc1 Jd2 3s3 3h4",
            "rows": "Kd1 8c3 Kc4/2h0 5h0 4h2 Jh3 Kh4/9d0 9s0 Ts0 Tc1 Th2",
            "win": 5.8,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:28:50",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000148-1": [
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "pid1793219",
            "orderIndex": 0,
            "hero": false,
            "dead": "4s1 2c2 Qs3 2h4",
            "rows": "Kh0 Jc3 Qd4/7d0 Qc0 Th2 Td2 Qh3/3s0 8s0 3h1 8h1 9c4",
            "win": -4.2,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "pid5684470",
            "orderIndex": 1,
            "hero": true,
            "dead": "7c1 6h2 8c3 6c4",
            "rows": "Kc0 7s3 8d3/3c0 4d0 2d1 Ac2 Ad4/5h0 5s0 9s1 9h2 Jd4",
            "win": -1.8,
            "playerId": "pid5684470"
        },
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "pid2923305",
            "orderIndex": 2,
            "hero": false,
            "dead": "9d0 7h1",
            "rows": "Ks0 Ah0 As0/4h0 4c0 5c0 6d0 6s0/2s0 Tc0 Ts0 Jh0 Js0",
            "win": 5.8,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:30:04",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000149-1": [
        {
            "inFantasy": false,
            "result": 16,
            "playerName": "pid1793219",
            "orderIndex": 2,
            "hero": false,
            "dead": "5c1 Jc2 8s3 Jh4",
            "rows": "3h0 6h3 6s4/Qd0 2d1 Qs2 Qc3 As4/Kd0 Kc0 Ks0 9c1 9s2",
            "win": 3.1,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "pid5684470",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h1 6c2 2s3 Tc4",
            "rows": "Ad1 Ac2 Kh3/3s0 5d1 5h2 3d3 4s4/7h0 7s0 Jd0 Js0 4d4",
            "win": 1.7,
            "playerId": "pid5684470"
        },
        {
            "inFantasy": false,
            "result": -25,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "7c1 Th2 Qh3 7d4",
            "rows": "Ah2 9h4 Ts4/2c0 3c0 5s0 4h3 4c3/6d0 8h0 8c1 Td1 8d2",
            "win": -5,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:31:12",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000150-1": [
        {
            "inFantasy": false,
            "result": 13,
            "playerName": "pid1793219",
            "orderIndex": 1,
            "hero": false,
            "dead": "6h1 5c2 Kh3 6d4",
            "rows": "Ad0 Ah1 6s4/7h0 7c0 2s2 4h2 2d3/8d0 Td0 7d1 8h3 8c4",
            "win": 2.5,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": true,
            "result": 18,
            "playerName": "pid5684470",
            "orderIndex": 2,
            "hero": true,
            "dead": "8s0 Ts0 3d0",
            "rows": "9h0 9d0 Jh0/2c0 3h0 4d0 5d0 6c0/Th0 Jd0 Qs0 Ks0 Ac0",
            "win": 3.5,
            "playerId": "pid5684470"
        },
        {
            "inFantasy": false,
            "result": -31,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "2h1 9s2 5h3 Qh4",
            "rows": "As1 Qc3 Qd4/5s0 7s0 3s1 Js3 Kd4/3c0 9c0 Kc0 Tc2 Jc2",
            "win": -6.2,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:32:11",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000151-1": [
        {
            "inFantasy": true,
            "result": 52,
            "playerName": "pid1793219",
            "orderIndex": 0,
            "hero": false,
            "dead": "7h0 8h1 Ts2",
            "rows": "Js0 Qh0 Qs0/3d0 4d0 7d0 Jd0 Kd0/2d0 2c0 5h0 5d0 5s0",
            "win": 10.1,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid5684470",
            "orderIndex": 1,
            "hero": true,
            "dead": "3h1 4h2 2h3 9h4",
            "rows": "Ks3 Qd4 Ah4/8s0 Td0 Th1 8d2 9c3/4c0 5c0 7c0 6d1 3s2",
            "win": -3.4,
            "playerId": "pid5684470"
        },
        {
            "inFantasy": false,
            "result": -35,
            "playerName": "pid2923305",
            "orderIndex": 2,
            "hero": false,
            "dead": "3c1 Kc2 6h3 Ad4",
            "rows": "Ac0 As0 Qc3/6c0 6s0 2s2 7s3 Kh4/9d0 Tc1 Jc1 9s2 8c4",
            "win": -7,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:33:03",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000152-1": [
        {
            "inFantasy": false,
            "result": -43,
            "playerName": "pid1793219",
            "orderIndex": 2,
            "hero": false,
            "dead": "Kc1 2h2 7c3 5s4",
            "rows": "Qc0 Ks2 Qh3/2d0 5d0 Ad1 7d2 7s4/6h0 Th0 Td1 6c3 Ts4",
            "win": -8.6,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": false,
            "result": 39,
            "playerName": "pid5684470",
            "orderIndex": 0,
            "hero": true,
            "dead": "6d1 2c2 Jc3 4c4",
            "rows": "Ac3 As3 Tc4/2s0 Qs0 3s1 Js1 4s4/5h0 Jh0 Ah0 7h2 Kh2",
            "win": 7.6,
            "playerId": "pid5684470"
        },
        {
            "inFantasy": false,
            "result": 4,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qd1 6s2 8s3 Jd4",
            "rows": "Kd1 9d4 9s4/4h0 5c0 4d2 3d3 3c3/8h0 9h0 9c0 8c1 8d2",
            "win": 0.8,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:34:26",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000153-1": [
        {
            "inFantasy": false,
            "result": 11,
            "playerName": "pid1793219",
            "orderIndex": 1,
            "hero": false,
            "dead": "Js1 9d2 Qs3 Ks4",
            "rows": "7d2 Ah3 7s4/2s0 4c0 5c0 2h1 5s4/8d0 Th0 8s1 8h2 Ts3",
            "win": 2.1,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "pid5684470",
            "orderIndex": 2,
            "hero": true,
            "dead": "Td0 6s0 3s0",
            "rows": "2d0 2c0 Jd0/3h0 5h0 9h0 Jh0 Qh0/7c0 9c0 Qc0 Kc0 Ac0",
            "win": 4.1,
            "playerId": "pid5684470"
        },
        {
            "inFantasy": false,
            "result": -32,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "8c1 3c2 3d3 6h4",
            "rows": "As0 Qd3 Tc4/4h0 6c0 6d1 4d2 5d2/Kh0 Kd0 9s1 Jc3 7h4",
            "win": -6.4,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:35:28",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000154-1": [
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid1793219",
            "orderIndex": 0,
            "hero": false,
            "dead": "4h1 3h2 4c3 3c4",
            "rows": "Ac1 8s2 7s3/2s0 Jc0 Qh1 As3 9c4/3d0 9d0 Kd0 Qd2 Ad4",
            "win": -2,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": false,
            "result": -34,
            "playerName": "pid5684470",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qs1 Qc2 8c3 Tc4",
            "rows": "Kc2 4d3 5d4/8d0 9s0 6c1 7c2 5s3/6h0 8h0 Th0 Ah1 2d4",
            "win": -6.8,
            "playerId": "pid5684470"
        },
        {
            "inFantasy": false,
            "result": 44,
            "playerName": "pid2923305",
            "orderIndex": 2,
            "hero": false,
            "dead": "5h1 7d2 9h3 2h4",
            "rows": "7h2 Kh4 Ks4/2c0 3s0 5c1 4s2 6d3/Td0 Ts0 Js0 Jd1 Jh3",
            "win": 8.5,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:37:17",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000155-1": [
        {
            "inFantasy": false,
            "result": -33,
            "playerName": "pid1793219",
            "orderIndex": 2,
            "hero": false,
            "dead": "8c1 Tc2 Kh3 As4",
            "rows": "Qc2 Ah2 Qh3/5h0 8h0 5s1 Js3 Jc4/4h0 4d0 9d0 9s1 Ks4",
            "win": -6.6,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid5684470",
            "orderIndex": 0,
            "hero": true,
            "dead": "4s1 9c2 8d3 2d4",
            "rows": "Kd0 Qs3 Qd4/2h0 6d0 5c1 6s2 2s3/7d0 7c0 Td1 Ts2 9h4",
            "win": 1,
            "playerId": "pid5684470"
        },
        {
            "inFantasy": true,
            "result": 28,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "7h0 6h1",
            "rows": "8s0 Th0 Ad0/2c0 4c0 6c0 Kc0 Ac0/3h0 3d0 3s0 Jh0 Jd0",
            "win": 5.4,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:38:18",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000156-1": [
        {
            "inFantasy": false,
            "result": -11,
            "playerName": "pid1793219",
            "orderIndex": 1,
            "hero": false,
            "dead": "Th1 6d2 5h3 7c4",
            "rows": "Kh2 Td4 Kd4/2c0 7d0 5c1 7s1 5d2/Js0 Qh0 Qs0 4h3 4d3",
            "win": -2.2,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": true,
            "result": 8,
            "playerName": "pid5684470",
            "orderIndex": 2,
            "hero": true,
            "dead": "2d0",
            "rows": "6h0 6c0 Qd0/3s0 4s0 8s0 Ts0 As0/4c0 8c0 9c0 Jc0 Ac0",
            "win": 1.6,
            "playerId": "pid5684470"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "Ad1 5s2 Jd3 2h4",
            "rows": "Kc0 Ks0 9d4/3d0 7h0 6s1 3c3 3h4/Tc0 9s1 Jh2 Qc2 8d3",
            "win": 0.6,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:39:08",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000157-1": [
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "pid1793219",
            "orderIndex": 0,
            "hero": false,
            "dead": "2c0 2d1",
            "rows": "5d0 Kc0 Ks0/6s0 7s0 8h0 9s0 Ts0/5c0 9c0 Jc0 Qc0 Ac0",
            "win": 5.8,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": false,
            "result": -32,
            "playerName": "pid5684470",
            "orderIndex": 1,
            "hero": true,
            "dead": "6c1 6d2 4s3 6h4",
            "rows": "As0 Qs3 Jd4/2s0 8c0 8s0 3d1 2h3/9h0 Th1 7h2 Tc2 Td4",
            "win": -6.4,
            "playerId": "pid5684470"
        },
        {
            "inFantasy": true,
            "result": 2,
            "playerName": "pid2923305",
            "orderIndex": 2,
            "hero": false,
            "dead": "7c0 4c1",
            "rows": "9d0 Ah0 Ad0/3s0 Jh0 Js0 Qh0 Qd0/3c0 5h0 5s0 Kh0 Kd0",
            "win": 0.4,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:40:05",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000158-1": [
        {
            "inFantasy": false,
            "result": -2,
            "playerName": "pid1793219",
            "orderIndex": 2,
            "hero": false,
            "dead": "7s1 8s2 9d3 Th4",
            "rows": "6c2 Jh3 Kd4/2h0 3d0 7h0 Ad3 Jc4/5c0 Qc0 5s1 Qd1 5d2",
            "win": -0.4,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": false,
            "result": 25,
            "playerName": "pid5684470",
            "orderIndex": 0,
            "hero": true,
            "dead": "4c1 2c2 Ks3 6s4",
            "rows": "Kh0 Kc2 9h3/Tc0 As1 Js2 Ts3 Ac4/2d0 4d0 8d0 Jd1 Td4",
            "win": 4.8,
            "playerId": "pid5684470"
        },
        {
            "inFantasy": false,
            "result": -23,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "4s1 4h2 7c3 Qh4",
            "rows": "7d1 3s3 Ah4/3c0 5h0 6h0 3h2 6d4/9c0 9s0 8c1 2s2 8h3",
            "win": -4.6,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:41:05",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000159-1": [
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid1793219",
            "orderIndex": 1,
            "hero": false,
            "dead": "4d1 3s2 3d3 4s4",
            "rows": "As0 5d3 4c4/9c1 7h2 Th2 9s3 7d4/Qd0 Qc0 Kd0 Ks0 Qh1",
            "win": 0.2,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": true,
            "result": 33,
            "playerName": "pid5684470",
            "orderIndex": 2,
            "hero": true,
            "dead": "5s0 2s0",
            "rows": "Kh0 Kc0 Ah0/8d0 9d0 Tc0 Js0 Qs0/2c0 5c0 6c0 8c0 Jc0",
            "win": 6.4,
            "playerId": "pid5684470"
        },
        {
            "inFantasy": false,
            "result": -34,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "2d1 Ts2 8s3 7c4",
            "rows": "Ad2 Jh3 Ac3/3c0 3h1 5h1 2h2 4h4/6h0 7s0 8h0 Td0 9h4",
            "win": -6.8,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:42:01",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000160-1": [
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid1793219",
            "orderIndex": 0,
            "hero": false,
            "dead": "6d1 9d2 3s3 Jh4",
            "rows": "Kh0 Kc1 Qs2/3d0 4d0 3c1 4h3 5h4/7c0 8c0 7s2 6s3 Js4",
            "win": -3,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "pid5684470",
            "orderIndex": 1,
            "hero": true,
            "dead": "3h1 2c2 4s3 8d4",
            "rows": "Ah0 5s3 Ad3/2s0 7h0 7d0 2h2 Jd4/Tc0 9c1 Qh1 Th2 9s4",
            "win": 5.8,
            "playerId": "pid5684470"
        },
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid2923305",
            "orderIndex": 2,
            "hero": false,
            "dead": "6h1 2d2 Td3 Ac4",
            "rows": "Kd0 Ks0 As3/4c0 5d1 5c1 6c3 8h4/9h0 Ts0 8s2 Qd2 Jc4",
            "win": -3,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:43:26",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000161-1": [
        {
            "inFantasy": false,
            "result": -23,
            "playerName": "pid1793219",
            "orderIndex": 2,
            "hero": false,
            "dead": "Jh1 Ts2 3s3 Ac4",
            "rows": "Kd0 Ks0 Jd3/2d0 2s2 5d2 6s3 2h4/5h0 6h0 7d1 8d1 Td4",
            "win": -4.6,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": true,
            "result": 46,
            "playerName": "pid5684470",
            "orderIndex": 0,
            "hero": true,
            "dead": "6c0 Tc0 9s0",
            "rows": "Qs0 Ad0 As0/3c0 4d0 5c0 6d0 7h0/3h0 8h0 9h0 Kh0 Ah0",
            "win": 8.9,
            "playerId": "pid5684470"
        },
        {
            "inFantasy": false,
            "result": -23,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "7s1 9c2 Qc3 9d4",
            "rows": "Qh0 Th2 Qd2/3d0 4s0 2c1 4h3 4c4/8c0 Jc0 Js1 7c3 5s4",
            "win": -4.6,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:44:34",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000162-1": [
        {
            "inFantasy": false,
            "result": 19,
            "playerName": "pid1793219",
            "orderIndex": 1,
            "hero": false,
            "dead": "2d1 5c2 Jd3 4h4",
            "rows": "Qh0 Jh3 Qc3/8c0 3h1 3s1 9h4 9s4/7d0 9d0 Td0 9c2 Tc2",
            "win": 3.7,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": false,
            "result": 7,
            "playerName": "pid5684470",
            "orderIndex": 2,
            "hero": true,
            "dead": "8h1 8d2 Ts3 Kd4",
            "rows": "Qs0 7s2 Qd4/2s0 5h0 Kc1 Kh3 Ac3/4d0 6d0 6s1 4s2 7h4",
            "win": 1.4,
            "playerId": "pid5684470"
        },
        {
            "inFantasy": false,
            "result": -26,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "3d1 5d2 Ah3 5s4",
            "rows": "As0 6h1 Ad2/4c0 7c0 2c1 3c3 6c4/8s0 Js0 Ks2 Th3 Jc4",
            "win": -5.2,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:46:00",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000163-1": [
        {
            "inFantasy": true,
            "result": -4,
            "playerName": "pid1793219",
            "orderIndex": 0,
            "hero": false,
            "dead": "2d0",
            "rows": "9d0 Kd0 Kc0/4c0 5h0 7d0 Ah0 As0/9s0 Ts0 Js0 Qh0 Ks0",
            "win": -0.8,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": true,
            "result": -13,
            "playerName": "pid5684470",
            "orderIndex": 1,
            "hero": true,
            "dead": "2c0",
            "rows": "Jh0 Jd0 Kh0/5d0 5c0 6d0 6c0 Qd0/3d0 3s0 8d0 8s0 Tc0",
            "win": -2.6,
            "playerId": "pid5684470"
        },
        {
            "inFantasy": false,
            "result": 17,
            "playerName": "pid2923305",
            "orderIndex": 2,
            "hero": false,
            "dead": "8h1 Th2 9h3 8c4",
            "rows": "Ad0 Ac1 9c4/4h0 7h0 4d1 3c2 3h3/2s0 Qs0 4s2 5s3 6s4",
            "win": 3.3,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:46:50",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000164-1": [
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "pid1793219",
            "orderIndex": 2,
            "hero": false,
            "dead": "8h1 2c2 2h3 Tc4",
            "rows": "Kc0 8c1 8s4/3d0 6d0 3s2 4d2 3h3/7h0 7d0 7c1 6h3 Qh4",
            "win": -1.8,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": false,
            "result": -36,
            "playerName": "pid5684470",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jd1 Qs2 Kd3 Ks4",
            "rows": "Ah0 Ac1 Kh3/2s0 5d0 4s1 4h3 4c4/8d0 9c0 9h2 Qc2 3c4",
            "win": -7.2,
            "playerId": "pid5684470"
        },
        {
            "inFantasy": true,
            "result": 45,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "9d0 Jc1 Ad2",
            "rows": "5h0 5c0 5s0/2d0 6c0 Th0 Td0 Ts0/6s0 7s0 9s0 Js0 As0",
            "win": 8.7,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:47:48",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000165-1": [
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid1793219",
            "orderIndex": 1,
            "hero": false,
            "dead": "6h1 Jh2 Kc3 4d4",
            "rows": "Ks1 Ac1 As3/Th0 Tc0 8h2 6d4 Td4/2d0 5d0 Jd0 8d2 9d3",
            "win": 1.9,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": false,
            "result": -40,
            "playerName": "pid5684470",
            "orderIndex": 2,
            "hero": true,
            "dead": "7d1 3d2 3h3 2h4",
            "rows": "Kd2 Ts3 Ah3/Qs0 6s1 8s1 Qd2 9s4/3c0 4c0 9c0 Jc0 8c4",
            "win": -8,
            "playerId": "pid5684470"
        },
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "9h0 6c1 4h2",
            "rows": "Qh0 Qc0 Ad0/2s0 3s0 4s0 7s0 Js0/5h0 5c0 5s0 7h0 7c0",
            "win": 5.8,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:49:08",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000166-1": [
        {
            "inFantasy": true,
            "result": 40,
            "playerName": "pid1793219",
            "orderIndex": 0,
            "hero": false,
            "dead": "5d0 6d1 8s2",
            "rows": "9d0 Qs0 Kc0/2h0 5h0 9h0 Th0 Qh0/4c0 4s0 Ah0 Ad0 As0",
            "win": 7.8,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid5684470",
            "orderIndex": 1,
            "hero": true,
            "dead": "6c1 6h2 8h3 Qc4",
            "rows": "Kd0 Qd2 Ks2/2c0 3s0 4d1 7h4 8d4/Jd0 Jc0 8c1 Td3 Ts3",
            "win": -4,
            "playerId": "pid5684470"
        },
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid2923305",
            "orderIndex": 2,
            "hero": false,
            "dead": "9c1 5c2 2d3 5s4",
            "rows": "Ac1 9s3 Kh4/2s0 3c0 6s0 3h1 3d2/7c0 7s0 4h2 Tc3 Js4",
            "win": -4,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:50:15",
    "roomId": "21947173"
}


