{
    "stakes": 5,
    "handData": {"210330074958-21920251-0000000-1": [
        {
            "inFantasy": false,
            "result": 13,
            "playerName": "pid5679436",
            "orderIndex": 1,
            "hero": true,
            "dead": "6d1 Qc2 4c3 5d4",
            "rows": "Qs0 Qd2 6c4/5s0 2h1 Ah2 4h3 Ac3/7h0 7s0 9d0 9c1 4s4",
            "win": 63,
            "playerId": "pid5679436"
        },
        {
            "inFantasy": false,
            "result": -13,
            "playerName": "pid5011126",
            "orderIndex": 0,
            "hero": false,
            "dead": "2s1 3s2 7c3 8h4",
            "rows": "Ad0 As0 9s3/6h0 9h0 8c1 6s2 8s2/Ts0 Js1 4d3 Td4 Qh4",
            "win": -65,
            "playerId": "pid5011126"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:08:26",
    "roomId": "21920251"
}


{
    "stakes": 5,
    "handData": {"210330074958-21920251-0000001-1": [
        {
            "inFantasy": true,
            "result": 20,
            "playerName": "pid5679436",
            "orderIndex": 0,
            "hero": true,
            "dead": "2d0",
            "rows": "6c0 9c0 Kd0/6h0 7h0 9h0 Jh0 Ah0/4d0 4c0 8h0 8c0 8s0",
            "win": 97,
            "playerId": "pid5679436"
        },
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid5011126",
            "orderIndex": 1,
            "hero": false,
            "dead": "2s1 3s2 2h3 Kc4",
            "rows": "7c2 Kh2 Ks3/4h0 6s0 9d1 9s1 3c4/Jc0 Qh0 Qd0 As3 7s4",
            "win": -100,
            "playerId": "pid5011126"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:09:00",
    "roomId": "21920251"
}


{
    "stakes": 5,
    "handData": {"210330074958-21920251-0000002-1": [
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid5679436",
            "orderIndex": 1,
            "hero": true,
            "dead": "Kd1 7s2 3c3 8c4",
            "rows": "Qd1 Qc1 9s3/5s0 6h0 2c2 5d2 7d4/4d0 4s0 Jd0 Jc3 4h4",
            "win": -75,
            "playerId": "pid5679436"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "pid5011126",
            "orderIndex": 0,
            "hero": false,
            "dead": "Tc1 As2 6s3 8d4",
            "rows": "Ah0 Ac0 Ts4/6d0 7h1 7c1 6c2 9c3/Jh0 Qs0 Qh2 8s3 8h4",
            "win": 73,
            "playerId": "pid5011126"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:10:11",
    "roomId": "21920251"
}


{
    "stakes": 5,
    "handData": {"210330074958-21920251-0000003-1": [
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5679436",
            "orderIndex": 0,
            "hero": true,
            "dead": "7d1 7s2 2h3 5h4",
            "rows": "Ad2 Qc3 Ah4/4d0 4s0 5d1 5s2 8s3/6h0 6s0 Jc0 Jh1 Qd4",
            "win": -50,
            "playerId": "pid5679436"
        },
        {
            "inFantasy": true,
            "result": 10,
            "playerName": "pid5011126",
            "orderIndex": 1,
            "hero": false,
            "dead": "2s0 4c1 Js2",
            "rows": "9h0 9s0 Qs0/3d0 6d0 9d0 Jd0 Kd0/7h0 7c0 Th0 Tc0 Ts0",
            "win": 48,
            "playerId": "pid5011126"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:10:58",
    "roomId": "21920251"
}


{
    "stakes": 5,
    "handData": {"210330074958-21920251-0000004-1": [
        {
            "inFantasy": true,
            "result": 24,
            "playerName": "pid5679436",
            "orderIndex": 1,
            "hero": true,
            "dead": "2d0 5s0 6d0",
            "rows": "7s0 Jh0 Ah0/3c0 3s0 Qh0 Qd0 Qc0/Th0 Ts0 Kd0 Kc0 Ks0",
            "win": 116,
            "playerId": "pid5679436"
        },
        {
            "inFantasy": false,
            "result": -24,
            "playerName": "pid5011126",
            "orderIndex": 0,
            "hero": false,
            "dead": "5d1 9s2 Tc3 Ac4",
            "rows": "Ad2 As3 5h4/2h0 4d0 2c1 4s1 8c2/6h0 6s0 Jc0 Qs3 7d4",
            "win": -120,
            "playerId": "pid5011126"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:11:36",
    "roomId": "21920251"
}


{
    "stakes": 5,
    "handData": {"210330074958-21920251-0000005-1": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5679436",
            "orderIndex": 0,
            "hero": true,
            "dead": "7s1 7h2 5h3 Jh4",
            "rows": "Ks0 8s3 4s4/2h0 4c0 3s1 Ah1 As2/Td0 Jd0 9h2 8d3 2s4",
            "win": -60,
            "playerId": "pid5679436"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid5011126",
            "orderIndex": 1,
            "hero": false,
            "dead": "3h1 Kd2 3d3 4h4",
            "rows": "5s1 8h3 Ts3/2d0 Qd0 6s1 6h2 6d4/2c0 9c0 Kc0 6c2 Ac4",
            "win": 58,
            "playerId": "pid5011126"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:12:25",
    "roomId": "21920251"
}


{
    "stakes": 5,
    "handData": {"210330074958-21920251-0000006-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5679436",
            "orderIndex": 1,
            "hero": true,
            "dead": "Th1 7h2 Jh3 Jd4",
            "rows": "Qc0 Ks0 Kh2/Ah0 3h1 9h3 Qh3 4d4/6s0 8h0 8d1 6c2 2h4",
            "win": 0,
            "playerId": "pid5679436"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5011126",
            "orderIndex": 0,
            "hero": false,
            "dead": "9s1 7s2 3c3 Kd4",
            "rows": "Kc0 9c3 6h4/3d0 Td0 3s1 Ts1 6d3/Jc0 Qs0 5h2 5s2 7c4",
            "win": 0,
            "playerId": "pid5011126"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:13:32",
    "roomId": "21920251"
}


{
    "stakes": 5,
    "handData": {"210330074958-21920251-0000007-1": [
        {
            "inFantasy": false,
            "result": -4,
            "playerName": "pid5679436",
            "orderIndex": 0,
            "hero": true,
            "dead": "Js1 4s2 5s3 2s4",
            "rows": "Qd1 2h3 5c3/7c0 9d0 3h1 3d2 Ah4/6h0 6s0 Th0 Td2 6c4",
            "win": -20,
            "playerId": "pid5679436"
        },
        {
            "inFantasy": false,
            "result": 4,
            "playerName": "pid5011126",
            "orderIndex": 1,
            "hero": false,
            "dead": "4h1 3s2 3c3 5d4",
            "rows": "As0 Ad2 6d3/2d0 4d0 4c1 8c3 2c4/Kd0 Ks0 Kh1 Qs2 Jh4",
            "win": 19,
            "playerId": "pid5011126"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:14:17",
    "roomId": "21920251"
}


{
    "stakes": 5,
    "handData": {"210330074958-21920251-0000008-1": [
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid5679436",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jh1 8s2 3c3 Qh4",
            "rows": "Ah0 As3 Js4/2s0 2d1 5c1 5h2 9c3/7d0 8d0 Qd0 Td2 4s4",
            "win": -90,
            "playerId": "pid5679436"
        },
        {
            "inFantasy": true,
            "result": 18,
            "playerName": "pid5011126",
            "orderIndex": 0,
            "hero": false,
            "dead": "7s0 2h1 6s2",
            "rows": "8h0 9h0 Qs0/4c0 6c0 8c0 Qc0 Kc0/3d0 5d0 9d0 Kd0 Ad0",
            "win": 87,
            "playerId": "pid5011126"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:15:07",
    "roomId": "21920251"
}


{
    "stakes": 5,
    "handData": {"210330074958-21920251-0000009-1": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "pid5679436",
            "orderIndex": 0,
            "hero": true,
            "dead": "9c1 Jc2 2h3 Ks4",
            "rows": "Kc1 8c3 7h4/5d0 Td0 4s2 3s3 Tc4/3h0 6h0 8h0 Th1 9h2",
            "win": -15,
            "playerId": "pid5679436"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid5011126",
            "orderIndex": 1,
            "hero": false,
            "dead": "8s1 4h2 7d3 6c4",
            "rows": "4c2 Kh3 6s4/2d0 2c0 6d0 7c1 7s3/Jd0 Qc0 Qs1 Jh2 Qd4",
            "win": 15,
            "playerId": "pid5011126"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:16:11",
    "roomId": "21920251"
}


{
    "stakes": 5,
    "handData": {"210330074958-21920251-0000010-1": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "pid5679436",
            "orderIndex": 1,
            "hero": true,
            "dead": "Kc1 7d2 9h3 Kd4",
            "rows": "As0 Jc3 Qc3/5h0 6c0 4d1 2d4 3c4/9d0 Ts0 8h1 Js2 Qh2",
            "win": -15,
            "playerId": "pid5679436"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid5011126",
            "orderIndex": 0,
            "hero": false,
            "dead": "Th1 2h2 Jd3 3d4",
            "rows": "Td1 Ah3 4c4/3h0 6d0 4h2 7c3 5d4/4s0 8s0 Ks0 5s1 3s2",
            "win": 15,
            "playerId": "pid5011126"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:17:47",
    "roomId": "21920251"
}


{
    "stakes": 5,
    "handData": {"210330074958-21920251-0000011-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5679436",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h1 Jd2 Jh3 Ts4",
            "rows": "As0 Th3 Tc3/3h0 3d0 7d0 8h2 Td4/Qh0 5h1 Qs1 5s2 2s4",
            "win": 0,
            "playerId": "pid5679436"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5011126",
            "orderIndex": 1,
            "hero": false,
            "dead": "9h1 3c2 5d3 Kc4",
            "rows": "Kd1 Ad2 4c4/6d0 Qd0 6h1 Jc3 Qc3/3s0 7s0 Js0 6s2 4d4",
            "win": 0,
            "playerId": "pid5011126"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:18:35",
    "roomId": "21920251"
}


{
    "stakes": 5,
    "handData": {"210330074958-21920251-0000012-1": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid5679436",
            "orderIndex": 1,
            "hero": true,
            "dead": "Js1 Ts2 Qs3 6h4",
            "rows": "2d0 7d1 7h4/Tc0 4c1 Ad3 As3 2c4/3h0 Qh0 Kh0 8h2 9h2",
            "win": 58,
            "playerId": "pid5679436"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5011126",
            "orderIndex": 0,
            "hero": false,
            "dead": "9d1 Qc2 Kd3 7c4",
            "rows": "Ac0 Ah3 Jh4/2s0 3s0 4h2 5h3 8c4/4d0 Jd0 8d1 Qd1 5d2",
            "win": -60,
            "playerId": "pid5011126"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:19:57",
    "roomId": "21920251"
}


{
    "stakes": 5,
    "handData": {"210330074958-21920251-0000013-1": [
        {
            "inFantasy": false,
            "result": 8,
            "playerName": "pid5679436",
            "orderIndex": 0,
            "hero": true,
            "dead": "8c1 5h2 7d3 8h4",
            "rows": "4h2 Kc4 Ac4/6c0 Jc0 Qc2 Jd3 Qd3/8s0 9s0 Ts0 7s1 Js1",
            "win": 39,
            "playerId": "pid5679436"
        },
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid5011126",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jh1 Ah2 Td3 4d4",
            "rows": "Kh0 Ks1 Qh4/5d0 6h0 2d2 6d2 2h3/3c0 9c0 3s1 3h3 5s4",
            "win": -40,
            "playerId": "pid5011126"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:20:41",
    "roomId": "21920251"
}


{
    "stakes": 5,
    "handData": {"210330074958-21920251-0000014-1": [
        {
            "inFantasy": false,
            "result": -7,
            "playerName": "pid5679436",
            "orderIndex": 1,
            "hero": true,
            "dead": "7c1 5d2 7s3 5c4",
            "rows": "Kc2 Jc3 Qc4/6s0 9c0 6c1 9h2 Qd4/5h0 7h0 Ah0 6h1 4h3",
            "win": -35,
            "playerId": "pid5679436"
        },
        {
            "inFantasy": true,
            "result": 7,
            "playerName": "pid5011126",
            "orderIndex": 0,
            "hero": false,
            "dead": "3d0 4c1",
            "rows": "5s0 9d0 Tc0/Th0 Jd0 Qh0 Kh0 Ac0/2h0 2c0 2s0 8d0 8s0",
            "win": 34,
            "playerId": "pid5011126"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:21:26",
    "roomId": "21920251"
}


{
    "stakes": 5,
    "handData": {"210330074958-21920251-0000015-1": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid5679436",
            "orderIndex": 0,
            "hero": true,
            "dead": "7h1 Jc2 8h3 6h4",
            "rows": "As0 8s4 9s4/4d0 4s0 4c1 5h2 Js3/5d0 6d0 2d1 3d2 9d3",
            "win": 58,
            "playerId": "pid5679436"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5011126",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qc1 3c2 Qd3 9h4",
            "rows": "Ac0 7c2 9c4/5c0 Tc0 5s1 8c1 Th3/Jh0 Ks0 Kc2 2c3 Td4",
            "win": -60,
            "playerId": "pid5011126"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:22:14",
    "roomId": "21920251"
}


{
    "stakes": 5,
    "handData": {"210330074958-21920251-0000016-1": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5679436",
            "orderIndex": 1,
            "hero": true,
            "dead": "8d1 4d2 6d3 3h4",
            "rows": "Ad0 Qc2 8c4/2d0 5s0 7d1 2s3 7s4/Jc0 Js0 Td1 9d2 Jh3",
            "win": 29,
            "playerId": "pid5679436"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5011126",
            "orderIndex": 0,
            "hero": false,
            "dead": "Kd1 Ts2 9c3 Qd4",
            "rows": "Kh0 Ks0 Ac3/5c0 2c1 7c2 5d3 3d4/4h0 8h0 Th1 6h2 Qs4",
            "win": -30,
            "playerId": "pid5011126"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:23:43",
    "roomId": "21920251"
}


{
    "stakes": 5,
    "handData": {"210330074958-21920251-0000017-1": [
        {
            "inFantasy": false,
            "result": -7,
            "playerName": "pid5679436",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qh1 9d2 8s3 8h4",
            "rows": "As0 9h2 Kh4/4d0 5d1 5c2 6s3 Jh4/Th0 Jd0 Qs0 9c1 8d3",
            "win": -35,
            "playerId": "pid5679436"
        },
        {
            "inFantasy": false,
            "result": 7,
            "playerName": "pid5011126",
            "orderIndex": 1,
            "hero": false,
            "dead": "Kd1 Qc2 4s3 7c4",
            "rows": "Kc0 Ks0 6d3/5h0 7s1 8c2 7h3 5s4/2d0 2c0 Td1 Ts2 9s4",
            "win": 34,
            "playerId": "pid5011126"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:24:32",
    "roomId": "21920251"
}


{
    "stakes": 5,
    "handData": {"210330074958-21920251-0000018-1": [
        {
            "inFantasy": false,
            "result": -2,
            "playerName": "pid5679436",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qh1 4h2 8c3 9h4",
            "rows": "Ah1 As2 Ts4/9s0 7s2 3s3 Js3 8s4/9c0 Jc0 Qc0 Kc0 3c1",
            "win": -10,
            "playerId": "pid5679436"
        },
        {
            "inFantasy": true,
            "result": 2,
            "playerName": "pid5011126",
            "orderIndex": 0,
            "hero": false,
            "dead": "4c0 7c1",
            "rows": "Tc0 Kh0 Ks0/3d0 4d0 Td0 Jd0 Ad0/2h0 2c0 5d0 5c0 5s0",
            "win": 10,
            "playerId": "pid5011126"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:25:15",
    "roomId": "21920251"
}


{
    "stakes": 5,
    "handData": {"210330074958-21920251-0000019-1": [
        {
            "inFantasy": true,
            "result": 29,
            "playerName": "pid5679436",
            "orderIndex": 0,
            "hero": true,
            "dead": "4d0 3h0 7s0",
            "rows": "Qs0 Ac0 As0/8h0 9s0 Td0 Jh0 Qh0/5h0 5d0 5c0 5s0 Tc0",
            "win": 141,
            "playerId": "pid5679436"
        },
        {
            "inFantasy": false,
            "result": -29,
            "playerName": "pid5011126",
            "orderIndex": 1,
            "hero": false,
            "dead": "8c1 8d2 9d3 Ad4",
            "rows": "Ah0 Kd1 9h4/3d0 4s0 4h1 3s2 7d3/6h0 6s0 Js2 Ts3 3c4",
            "win": -145,
            "playerId": "pid5011126"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:25:46",
    "roomId": "21920251"
}


{
    "stakes": 5,
    "handData": {"210330074958-21920251-0000020-1": [
        {
            "inFantasy": true,
            "result": 13,
            "playerName": "pid5679436",
            "orderIndex": 1,
            "hero": true,
            "dead": "6c0 7d0 9d0",
            "rows": "Ts0 Jc0 Kh0/3h0 3c0 4h0 4c0 4s0/5d0 5s0 8h0 8d0 8c0",
            "win": 22,
            "playerId": "pid5679436"
        },
        {
            "inFantasy": false,
            "result": -13,
            "playerName": "pid5011126",
            "orderIndex": 0,
            "hero": false,
            "dead": "4d1 2d2 Qd3 3d4",
            "rows": "Ks1 Ac1 6s2/7s0 Qc0 9c2 Qh4 Qs4/Th0 Jh0 Ah0 5h3 7h3",
            "win": -23,
            "playerId": "pid5011126"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:27:31",
    "roomId": "21920251"
}


