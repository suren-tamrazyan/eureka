{
    "stakes": 10,
    "handData": {"210330060030-21914126-0000001-1": [
        {
            "inFantasy": true,
            "result": 2,
            "playerName": "pid2813203",
            "orderIndex": 0,
            "hero": false,
            "dead": "4c0 3d1 Tc2",
            "rows": "Qc0 Qs0 Kh0/3s0 4s0 5c0 6s0 7c0/4d0 9d0 Td0 Jd0 Ad0",
            "win": 19,
            "playerId": "pid2813203"
        },
        {
            "inFantasy": true,
            "result": -2,
            "playerName": "pid5682370",
            "orderIndex": 1,
            "hero": false,
            "dead": "5d0 6d1 6c2",
            "rows": "7h0 7d0 Jc0/5s0 8s0 9s0 Ts0 Js0/2h0 3h0 9h0 Th0 Qh0",
            "win": -20,
            "playerId": "pid5682370"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": false,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:31:37",
    "roomId": "21914126"
}


{
    "stakes": 10,
    "handData": {"210330060030-21914126-0000002-1": [
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid5682370",
            "orderIndex": 1,
            "hero": false,
            "dead": "6s1 2c2 Qc3 4s4",
            "rows": "Qs0 9h2 3c4/4c0 Th1 Kh1 Ts3 3h4/3d0 8d0 Kd0 6d2 9d3",
            "win": 97,
            "playerId": "pid5682370"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5679560",
            "orderIndex": 0,
            "hero": true,
            "dead": "2d1 2s2 As3 Jh4",
            "rows": "Ad0 Ac0 5s3/8h0 6c1 4h2 8c2 8s4/7s0 9s0 7h1 Jd3 7d4",
            "win": -100,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:33:03",
    "roomId": "21914126"
}


{
    "stakes": 10,
    "handData": {"210330060030-21914126-0000003-1": [
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid5682370",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qs1 4d2 Kh3 Ks4",
            "rows": "Ad0 4s3 8s3/3d0 7d0 Tc1 2c4 9d4/6h0 6d0 Jd1 6c2 6s2",
            "win": -140,
            "playerId": "pid5682370"
        },
        {
            "inFantasy": false,
            "result": 14,
            "playerName": "pid5679560",
            "orderIndex": 1,
            "hero": true,
            "dead": "3c1 5c2 Ac3 3s4",
            "rows": "Kd0 Kc2 Ah3/5h0 7h0 8h1 5d2 8d3/Qh0 Qd0 9s1 Th4 Ts4",
            "win": 136,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:34:16",
    "roomId": "21914126"
}


{
    "stakes": 10,
    "handData": {"210330060030-21914126-0000004-1": [
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid5682370",
            "orderIndex": 1,
            "hero": false,
            "dead": "4s1 Kd2 3d3 2c4",
            "rows": "Ac1 8h3 7d4/5c0 6c0 7c1 6s2 7h2/9c0 9s0 Qh0 9h3 Qd4",
            "win": -170,
            "playerId": "pid5682370"
        },
        {
            "inFantasy": true,
            "result": 17,
            "playerName": "pid5679560",
            "orderIndex": 0,
            "hero": true,
            "dead": "2s0 6d0",
            "rows": "Kc0 Ah0 As0/4h0 4d0 4c0 Jh0 Qc0/5d0 5s0 Th0 Tc0 Ts0",
            "win": 165,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:35:00",
    "roomId": "21914126"
}


{
    "stakes": 10,
    "handData": {"210330060030-21914126-0000005-1": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5682370",
            "orderIndex": 0,
            "hero": false,
            "dead": "Ad1 5d2 5c3 Tc4",
            "rows": "Qs0 Kd2 Qc3/3d0 6d0 3s1 8s2 3c3/2h0 Jh0 Kh1 7c4 9s4",
            "win": -120,
            "playerId": "pid5682370"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid5679560",
            "orderIndex": 1,
            "hero": true,
            "dead": "8d1 6c2 Th3 5s4",
            "rows": "Jd2 4c4 6s4/2c0 2s0 2d1 9d3 Qh3/3h0 4h0 7h0 6h1 8h2",
            "win": 116,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:36:29",
    "roomId": "21914126"
}


{
    "stakes": 10,
    "handData": {"210330060030-21914126-0000006-1": [
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid5682370",
            "orderIndex": 1,
            "hero": false,
            "dead": "6d1 8h2 Jh3 Kh4",
            "rows": "Qh0 5d3 Td3/9s0 Js0 5s1 5h2 Jd2/4c0 5c0 8c1 3c4 7c4",
            "win": 97,
            "playerId": "pid5682370"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5679560",
            "orderIndex": 0,
            "hero": true,
            "dead": "4h1 Kc2 4s3 Qd4",
            "rows": "Kd0 Ks1 Qs3/2s0 3s0 3h2 Ac3 Jc4/8d0 9h0 Ts1 6s2 4d4",
            "win": -100,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:37:51",
    "roomId": "21914126"
}


{
    "stakes": 10,
    "handData": {"210330060030-21914126-0000007-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5682370",
            "orderIndex": 0,
            "hero": false,
            "dead": "Tc1 7d2 8s3 5d4",
            "rows": "Kc2 Qs3 Jd4/3d0 4c0 6c1 Ad3 8d4/5h0 7h0 9h0 2h1 3h2",
            "win": -60,
            "playerId": "pid5682370"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5679560",
            "orderIndex": 1,
            "hero": true,
            "dead": "5c1 4h2 6h3 9d4",
            "rows": "Jh3 Kd4 Ac4/Qh0 8h1 8c1 Qd2 3c3/2s0 3s0 6s0 As0 4s2",
            "win": 58,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:39:15",
    "roomId": "21914126"
}


{
    "stakes": 10,
    "handData": {"210330060030-21914126-0000008-1": [
        {
            "inFantasy": false,
            "result": -25,
            "playerName": "pid5682370",
            "orderIndex": 1,
            "hero": false,
            "dead": "Kh1 3d2 4s3 Ac4",
            "rows": "Ah0 Kd3 9d4/6h0 6c0 2d1 7d2 7c2/5c0 8c0 5s1 Tc3 Jh4",
            "win": -213,
            "playerId": "pid5682370"
        },
        {
            "inFantasy": false,
            "result": 25,
            "playerName": "pid5679560",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jc1 8h2 4c3 9h4",
            "rows": "Kc2 Qh3 Qc3/9s0 Ks0 2s1 7s1 8s4/Td0 Jd0 Ad0 8d2 6d4",
            "win": 207,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:40:53",
    "roomId": "21914126"
}


{
    "stakes": 10,
    "handData": {"210330060030-21914126-0000009-1": [
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "pid5682370",
            "orderIndex": 0,
            "hero": false,
            "dead": "2c1 Kd2 9c3 6s4",
            "rows": "Qd2 7d4 Js4/3s0 2s1 7s2 9s3 Ks3/3h0 8h0 Qh0 Kh0 Jh1",
            "win": 87,
            "playerId": "pid5682370"
        },
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "pid5679560",
            "orderIndex": 1,
            "hero": true,
            "dead": "4s1 5d2 4h3 4c4",
            "rows": "6c3 Qs3 3d4/9h0 8c1 Jd2 Qc2 As4/3c0 Tc0 Kc0 Ac0 5c1",
            "win": -90,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:42:16",
    "roomId": "21914126"
}


{
    "stakes": 10,
    "handData": {"210330060030-21914126-0000010-1": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid5682370",
            "orderIndex": 1,
            "hero": false,
            "dead": "Js1 7c2 9c3 6d4",
            "rows": "Kc1 Jh3 Qh4/8c0 6s1 Qc2 Qs2 7s3/4h0 4s0 Th0 Ts0 4d4",
            "win": 116,
            "playerId": "pid5682370"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5679560",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jd1 6h2 7h3 As4",
            "rows": "Ad1 Ac3 Ah4/2h0 2c0 8h1 2s2 9h2/5h0 5c0 Td0 Tc3 Jc4",
            "win": -120,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:43:40",
    "roomId": "21914126"
}


{
    "stakes": 10,
    "handData": {"210330060030-21914126-0000011-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5682370",
            "orderIndex": 0,
            "hero": false,
            "dead": "Td1 Jc2 Tc3 As4",
            "rows": "Ac1 6s2 3s3/2s0 7d0 5c1 7s2 5s3/4h0 6h0 Qh0 4s4 9s4",
            "win": 0,
            "playerId": "pid5682370"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5679560",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qs1 Th2 8c3 Ad4",
            "rows": "Kd2 Qc3 Qd4/2d0 3c0 3h1 2c2 4d3/7c0 8d0 Ts0 9d1 9h4",
            "win": 0,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:45:11",
    "roomId": "21914126"
}


{
    "stakes": 10,
    "handData": {"210330060030-21914126-0000012-1": [
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "pid5682370",
            "orderIndex": 1,
            "hero": false,
            "dead": "3d1 3h2 3s3 Kd4",
            "rows": "Qc2 Kc2 5d4/7s0 Tc0 9s1 Ts1 7h3/2h0 2c0 Jd0 6s3 Td4",
            "win": -90,
            "playerId": "pid5682370"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "pid5679560",
            "orderIndex": 0,
            "hero": true,
            "dead": "Th1 4s2 Js3 7d4",
            "rows": "8s2 Ks2 8d4/6h0 8c0 3c1 8h1 6c3/5c0 5s0 Qs0 5h3 Ad4",
            "win": 87,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:46:39",
    "roomId": "21914126"
}


{
    "stakes": 10,
    "handData": {"210330060030-21914126-0000013-1": [
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid5682370",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jc1 Qh2 Qd3 5d4",
            "rows": "Kh0 3s3 4s4/4d0 5c0 7h1 7c2 8s3/6s0 Ts0 Th1 6d2 2c4",
            "win": -150,
            "playerId": "pid5682370"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "pid5679560",
            "orderIndex": 1,
            "hero": true,
            "dead": "7s1 Qs2 5s3 3c4",
            "rows": "Ac0 Ah3 Tc4/4h0 2h1 4c1 9c2 9s2/3d0 8d0 Jd0 8c3 Jh4",
            "win": 145,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:47:56",
    "roomId": "21914126"
}


{
    "stakes": 10,
    "handData": {"210330060030-21914126-0000014-1": [
        {
            "inFantasy": false,
            "result": -1,
            "playerName": "pid5682370",
            "orderIndex": 1,
            "hero": false,
            "dead": "Js1 2c2 2d3 7d4",
            "rows": "Kd0 Td3 Ts3/Jc0 4d1 4s1 4c2 9c4/7h0 Th0 Ah0 9h2 5h4",
            "win": -10,
            "playerId": "pid5682370"
        },
        {
            "inFantasy": true,
            "result": 1,
            "playerName": "pid5679560",
            "orderIndex": 0,
            "hero": true,
            "dead": "2s0 3c0 5s0",
            "rows": "Ks0 Ad0 Ac0/5c0 7c0 7s0 Qh0 Qd0/2h0 3h0 4h0 8h0 Kh0",
            "win": 10,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:48:40",
    "roomId": "21914126"
}


{
    "stakes": 10,
    "handData": {"210330060030-21914126-0000015-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5682370",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jh1 4s2 2s3 5s4",
            "rows": "Ad1 Kc2 Ac4/6c0 8c0 8d1 5h2 6h3/3d0 Tc0 Ts0 Qh3 7s4",
            "win": 0,
            "playerId": "pid5682370"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5679560",
            "orderIndex": 1,
            "hero": true,
            "dead": "3c1 6s2 As3 Js4",
            "rows": "Ah0 9s2 9d3/7c0 Jc0 4h1 Jd1 8h3/Qs0 Kd0 2d2 6d4 8s4",
            "win": 0,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:50:01",
    "roomId": "21914126"
}


{
    "stakes": 10,
    "handData": {"210330060030-21914126-0000016-1": [
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid5682370",
            "orderIndex": 1,
            "hero": false,
            "dead": "8h1 Qd2 8c3 6s4",
            "rows": "Ks0 Ad2 As3/4h0 6d1 7h3 2d4 9c4/2c0 3c0 Tc0 6c1 Kc2",
            "win": -200,
            "playerId": "pid5682370"
        },
        {
            "inFantasy": false,
            "result": 20,
            "playerName": "pid5679560",
            "orderIndex": 0,
            "hero": true,
            "dead": "7d1 5h2 Qs3 2h4",
            "rows": "9d2 Kd2 Kh3/8d0 Ts0 Th1 Td4 Jh4/4c0 5c0 Qc0 Jc1 Ac3",
            "win": 194,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:51:26",
    "roomId": "21914126"
}


{
    "stakes": 10,
    "handData": {"210330060030-21914126-0000017-1": [
        {
            "inFantasy": false,
            "result": -25,
            "playerName": "pid5682370",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qh1 7d2 6d3 8c4",
            "rows": "Ah0 Ad2 Td4/2h0 2s0 6c1 6s1 4c3/5h0 5c0 Kd2 9d3 Th4",
            "win": -250,
            "playerId": "pid5682370"
        },
        {
            "inFantasy": true,
            "result": 25,
            "playerName": "pid5679560",
            "orderIndex": 1,
            "hero": true,
            "dead": "2d0 4s0",
            "rows": "9h0 Ac0 As0/4h0 8h0 8s0 Kh0 Kc0/9s0 Jh0 Jd0 Jc0 Js0",
            "win": 242,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:52:11",
    "roomId": "21914126"
}


{
    "stakes": 10,
    "handData": {"210330060030-21914126-0000018-1": [
        {
            "inFantasy": false,
            "result": -23,
            "playerName": "pid5682370",
            "orderIndex": 1,
            "hero": false,
            "dead": "2d1 Jd2 7d3 7s4",
            "rows": "Kh1 Ac2 Js3/5h0 6h1 3d2 5d3 Ah4/8d0 9c0 Jc0 Qs0 2h4",
            "win": -3,
            "playerId": "pid5682370"
        },
        {
            "inFantasy": true,
            "result": 23,
            "playerName": "pid5679560",
            "orderIndex": 0,
            "hero": true,
            "dead": "3h0 9h0",
            "rows": "Th0 Td0 Qd0/3c0 4c0 8c0 Qc0 Kc0/4s0 8s0 9s0 Ts0 As0",
            "win": 3,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:53:04",
    "roomId": "21914126"
}


