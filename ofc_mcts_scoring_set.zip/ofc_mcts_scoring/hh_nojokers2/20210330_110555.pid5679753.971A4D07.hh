{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000027-1": [
        {
            "inFantasy": false,
            "result": 2,
            "playerName": "pid5321042",
            "orderIndex": 1,
            "hero": false,
            "dead": "2d1 3s2 8d3 4c4",
            "rows": "Ad0 8h3 As3/4d0 7c0 5h2 5s2 4s4/Td0 Kd0 Tc1 Ks1 Ac4",
            "win": 0.4,
            "playerId": "pid5321042"
        },
        {
            "inFantasy": false,
            "result": -2,
            "playerName": "pid5679753",
            "orderIndex": 0,
            "hero": true,
            "dead": "5c1 3c2 8s3 8c4",
            "rows": "Kc1 Jh3 Kh3/3h0 6c0 3d2 6d2 7h4/9c0 9s0 Qs0 Qd1 6h4",
            "win": -0.4,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:05:55",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000028-1": [
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "pid5321042",
            "orderIndex": 0,
            "hero": false,
            "dead": "7s0 5c1 3h2",
            "rows": "Jh0 Kc0 Ad0/4d0 4s0 8c0 8s0 Tc0/8d0 9d0 Td0 Jd0 Qd0",
            "win": 1.2,
            "playerId": "pid5321042"
        },
        {
            "inFantasy": true,
            "result": -6,
            "playerName": "pid5679753",
            "orderIndex": 1,
            "hero": true,
            "dead": "4c0 6c0",
            "rows": "9s0 Js0 Qc0/2d0 3d0 4h0 5h0 6h0/7h0 7d0 Kh0 Kd0 Ks0",
            "win": -1.2,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:06:24",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000029-1": [
        {
            "inFantasy": true,
            "result": 19,
            "playerName": "pid5321042",
            "orderIndex": 1,
            "hero": false,
            "dead": "6h0 3s1 4h2",
            "rows": "8h0 8c0 8s0/9h0 Td0 Jh0 Qs0 Kd0/3c0 5c0 9c0 Jc0 Kc0",
            "win": 3.7,
            "playerId": "pid5321042"
        },
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid5679753",
            "orderIndex": 0,
            "hero": true,
            "dead": "9s1 8d2 Js3 Ac4",
            "rows": "Ad2 Jd3 5s4/4d0 3h1 7c1 4s3 Ah4/2h0 2d0 Th0 Ts0 Tc2",
            "win": -3.8,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:07:08",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000030-1": [
        {
            "inFantasy": true,
            "result": 9,
            "playerName": "pid5321042",
            "orderIndex": 0,
            "hero": false,
            "dead": "3c0 3h1 8h2",
            "rows": "Kc0 Ks0 As0/9h0 9s0 Jc0 Qh0 Qc0/4d0 7d0 8d0 Td0 Jd0",
            "win": 1.7,
            "playerId": "pid5321042"
        },
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "pid5679753",
            "orderIndex": 1,
            "hero": true,
            "dead": "Js1 6h2 4h3 6d4",
            "rows": "Ad1 9c4 Kh4/5d0 Jh0 5s1 7c2 7s3/6s0 8s0 Ts0 4s2 Qs3",
            "win": -1.8,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:07:57",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000031-1": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "pid5321042",
            "orderIndex": 1,
            "hero": false,
            "dead": "4c1 2d2 4d3 2c4",
            "rows": "7c2 As3 Ks4/6d0 6c0 8s0 5d1 5s4/9c0 Jh0 Qd1 Jc2 9d3",
            "win": -0.6,
            "playerId": "pid5321042"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid5679753",
            "orderIndex": 0,
            "hero": true,
            "dead": "7d1 2h2 4h3 6h4",
            "rows": "Qc0 Kc1 Tc4/8d0 Ac1 8h2 3c3 Qh4/2s0 3s0 Js0 7s2 4s3",
            "win": 0.6,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:08:41",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000032-1": [
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid5321042",
            "orderIndex": 0,
            "hero": false,
            "dead": "6s1 7s2 4s3 6d4",
            "rows": "Ad0 Kc2 7h3/3c0 Tc0 3s1 9c2 5d3/8h0 Jh0 Jd1 Qh4 As4",
            "win": -3,
            "playerId": "pid5321042"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "pid5679753",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jc1 9d2 2c3 4d4",
            "rows": "Ah0 Ac0 Qd4/2h0 4h0 2d1 4c3 Td4/3d0 Ks1 3h2 7d2 7c3",
            "win": 2.9,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:09:54",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000033-1": [
        {
            "inFantasy": false,
            "result": -27,
            "playerName": "pid5321042",
            "orderIndex": 1,
            "hero": false,
            "dead": "7s1 4h2 2s3 7c4",
            "rows": "Ks0 Jh2 Qs3/4c0 2c1 3c1 6c2 5h3/5d0 6d0 Qd0 Kc4 Ac4",
            "win": -5.4,
            "playerId": "pid5321042"
        },
        {
            "inFantasy": true,
            "result": 27,
            "playerName": "pid5679753",
            "orderIndex": 0,
            "hero": true,
            "dead": "5s0 Tc0 Js0",
            "rows": "Kh0 Ad0 As0/2h0 3h0 8h0 9h0 Qh0/2d0 7d0 Td0 Jd0 Kd0",
            "win": 5.2,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:10:27",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000034-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5321042",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jh1 Ah2 6c3 4d4",
            "rows": "Ad0 As2 9d3/4s0 7c0 8c1 8s2 4h3/Qd0 Kc0 Ks1 2d4 9c4",
            "win": -1.2,
            "playerId": "pid5321042"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5679753",
            "orderIndex": 1,
            "hero": true,
            "dead": "Ts1 2h2 5c3 3h4",
            "rows": "Ac0 Qc2 7d4/3c0 9s0 Js1 Td3 Tc3/6h0 Kh0 Kd1 5s2 Qh4",
            "win": 1.2,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:11:40",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000035-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5321042",
            "orderIndex": 1,
            "hero": false,
            "dead": "Kd1 2s2 8s3 9s4",
            "rows": "Ah0 Ac1 Td3/4c0 5d0 5c2 6d3 Ts4/Th0 Jd0 Qd1 Ks2 9c4",
            "win": 0,
            "playerId": "pid5321042"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5679753",
            "orderIndex": 0,
            "hero": true,
            "dead": "7h1 Jc2 Jh3 Qc4",
            "rows": "Kh0 Kc2 Tc3/2d0 3h0 Ad2 2h3 8d4/4s0 Js0 3s1 7s1 4d4",
            "win": 0,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:12:25",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000036-1": [
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid5321042",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qd1 Th2 Td3 6s4",
            "rows": "Kh0 Kc2 5c4/3h0 4s0 4d1 8c3 5s4/2c0 9c0 7c1 9h2 2d3",
            "win": -3.8,
            "playerId": "pid5321042"
        },
        {
            "inFantasy": false,
            "result": 19,
            "playerName": "pid5679753",
            "orderIndex": 1,
            "hero": true,
            "dead": "Kd1 3c2 Ac3 3s4",
            "rows": "Ad1 As1 9d4/4c0 5h0 6h2 6c3 4h4/9s0 Js0 Ks0 2s2 Qs3",
            "win": 3.7,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:13:38",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000037-1": [
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid5321042",
            "orderIndex": 1,
            "hero": false,
            "dead": "2c1 Js2 8c3 2h4",
            "rows": "Ac0 Kc2 Ah3/7c0 6c2 6d3 8s4 9d4/3s0 5s0 Ts0 9s1 Ks1",
            "win": -4,
            "playerId": "pid5321042"
        },
        {
            "inFantasy": true,
            "result": 20,
            "playerName": "pid5679753",
            "orderIndex": 0,
            "hero": true,
            "dead": "8d0 Kd0 4s0",
            "rows": "7d0 7s0 Ad0/4h0 5h0 6h0 9h0 Qh0/3c0 4c0 5c0 Jc0 Qc0",
            "win": 3.9,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:14:12",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000038-1": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5321042",
            "orderIndex": 0,
            "hero": false,
            "dead": "6c1 4c2 6s3 5d4",
            "rows": "Ac2 Ks3 Ad4/5c0 7s0 8d0 8s1 7d3/Jd0 Qs0 Qh1 Jc2 9h4",
            "win": 1.2,
            "playerId": "pid5321042"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5679753",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qd1 3d2 Js3 5h4",
            "rows": "9s2 2h3 Qc4/8h0 Td0 4h1 As2 3h4/7c0 8c0 9c0 Tc1 3c3",
            "win": -1.2,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:15:26",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000039-1": [
        {
            "inFantasy": true,
            "result": 23,
            "playerName": "pid5321042",
            "orderIndex": 1,
            "hero": false,
            "dead": "8h0 2h1 8s2",
            "rows": "Qc0 Qs0 Kd0/2s0 3c0 4d0 5d0 Ad0/9h0 9c0 9s0 Tc0 Ts0",
            "win": 4.5,
            "playerId": "pid5321042"
        },
        {
            "inFantasy": false,
            "result": -23,
            "playerName": "pid5679753",
            "orderIndex": 0,
            "hero": true,
            "dead": "5s1 2d2 9d3 Th4",
            "rows": "Qd0 As2 7s4/4s0 7h0 6h2 4h3 7d3/5c0 Jc0 8c1 Kc1 5h4",
            "win": -4.6,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:16:14",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000040-1": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "pid5321042",
            "orderIndex": 0,
            "hero": false,
            "dead": "4h1 3d2 6s3 5h4",
            "rows": "4s2 4c4 Qh4/2s0 5s0 6h0 5d1 6d1/Tc0 Jh0 8h2 8s3 Js3",
            "win": -0.6,
            "playerId": "pid5321042"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid5679753",
            "orderIndex": 1,
            "hero": true,
            "dead": "5c1 9d2 Ts3 9c4",
            "rows": "Ks1 Ad2 Jd4/3h0 7h0 7c0 4d1 3c3/Th0 Jc0 9h2 8c3 Qd4",
            "win": 0.6,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:17:26",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000041-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5321042",
            "orderIndex": 1,
            "hero": false,
            "dead": "4c1 Tc2 8d3 4d4",
            "rows": "Qd1 Qs1 Js2/2s0 6c0 9c2 6d3 Ac3/3h0 5h0 Kh0 5d4 Ts4",
            "win": 0,
            "playerId": "pid5321042"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5679753",
            "orderIndex": 0,
            "hero": true,
            "dead": "7s1 Th2 Kd3 Qh4",
            "rows": "Ah0 Kc2 As3/2d0 4h0 4s1 3c2 7d4/6h0 8c0 8h1 7c3 5c4",
            "win": 0,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:18:14",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000042-1": [
        {
            "inFantasy": false,
            "result": 20,
            "playerName": "pid5321042",
            "orderIndex": 0,
            "hero": false,
            "dead": "8h1 Jd2 Kc3 6h4",
            "rows": "Ks0 Kh3 Qs4/9d0 7s1 2h2 2s2 7d3/5h0 5c0 5s0 4c1 4d4",
            "win": 3.9,
            "playerId": "pid5321042"
        },
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid5679753",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jc1 8s2 9s3 Kd4",
            "rows": "5d0 Ah0 Ad3/Jh0 4h1 4s1 3d3 Td4/8c0 Tc0 2c2 9c2 2d4",
            "win": -4,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:19:30",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000043-1": [
        {
            "inFantasy": true,
            "result": 13,
            "playerName": "pid5321042",
            "orderIndex": 1,
            "hero": false,
            "dead": "8s0 3d1",
            "rows": "Qh0 Qc0 Ac0/5d0 7d0 8d0 9d0 Kd0/2d0 2s0 Th0 Td0 Ts0",
            "win": 2.5,
            "playerId": "pid5321042"
        },
        {
            "inFantasy": false,
            "result": -13,
            "playerName": "pid5679753",
            "orderIndex": 0,
            "hero": true,
            "dead": "8h1 8c2 Js3 9c4",
            "rows": "Ad0 As0 9h4/2c0 4h1 7s1 7h2 4c3/6c0 6s0 Kc2 9s3 6d4",
            "win": -2.6,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:20:14",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000044-1": [
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid5321042",
            "orderIndex": 0,
            "hero": false,
            "dead": "Th1 3d2 2h3 Qd4",
            "rows": "6c2 7s3 As4/3c0 8c0 7h1 8s1 3s2/Jh0 Jd0 Qh0 4c3 Qc4",
            "win": -3.8,
            "playerId": "pid5321042"
        },
        {
            "inFantasy": true,
            "result": 19,
            "playerName": "pid5679753",
            "orderIndex": 1,
            "hero": true,
            "dead": "2d0 7c0 8h0",
            "rows": "Kd0 Ad0 Ac0/5h0 5d0 9h0 9c0 Jc0/4s0 5s0 6s0 Js0 Qs0",
            "win": 3.7,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:21:06",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000045-1": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "pid5321042",
            "orderIndex": 1,
            "hero": false,
            "dead": "9c1 3c2 2s3 7c4",
            "rows": "Ks1 As1 9d4/7s0 8c0 6s2 9s3 5s4/Ts0 Jc0 Js0 Th2 Td3",
            "win": -0.6,
            "playerId": "pid5321042"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid5679753",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qs1 Tc2 4h3 4s4",
            "rows": "Kc0 Ah1 Kh4/3d0 3s0 3h3 6d3 5h4/5d0 8d0 Qd1 4d2 Jd2",
            "win": 0.6,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:21:53",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000046-1": [
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid5321042",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jc1 9d2 4s3 8h4",
            "rows": "Ac0 Qd2 Qc3/3s0 5d0 2d2 3c3 Jd4/Ts0 Kc0 Tc1 Ks1 Th4",
            "win": -4,
            "playerId": "pid5321042"
        },
        {
            "inFantasy": true,
            "result": 20,
            "playerName": "pid5679753",
            "orderIndex": 1,
            "hero": true,
            "dead": "7d0 5c0",
            "rows": "9c0 Td0 Jh0/2s0 6s0 7s0 Qs0 As0/4h0 4d0 8d0 8c0 8s0",
            "win": 3.9,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:22:27",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000047-1": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid5321042",
            "orderIndex": 1,
            "hero": false,
            "dead": "Ts1 2d2 5h3 7s4",
            "rows": "Qh0 Qs2 Th4/7c1 3d2 3h3 Kd3 7h4/5d0 Td0 Jd0 Ad0 6d1",
            "win": 0.6,
            "playerId": "pid5321042"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "pid5679753",
            "orderIndex": 0,
            "hero": true,
            "dead": "Tc1 Jc2 8c3 8d4",
            "rows": "Ac1 As2 Js3/2c0 5c0 4h1 4d4 5s4/9d0 9c0 Qd0 3c2 9s3",
            "win": -0.6,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:23:09",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000048-1": [
        {
            "inFantasy": true,
            "result": -6,
            "playerName": "pid5321042",
            "orderIndex": 0,
            "hero": false,
            "dead": "2c0",
            "rows": "7c0 Kd0 Ks0/3s0 5h0 6c0 Ah0 Ac0/7s0 8d0 9h0 Td0 Jh0",
            "win": -1.2,
            "playerId": "pid5321042"
        },
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "pid5679753",
            "orderIndex": 1,
            "hero": true,
            "dead": "6d0 5d0 3d0",
            "rows": "8c0 8s0 Qd0/2s0 5s0 6s0 Ts0 Js0/2h0 3h0 4h0 Th0 Qh0",
            "win": 1.2,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:23:47",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000049-1": [
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid5321042",
            "orderIndex": 1,
            "hero": false,
            "dead": "2h1 9d2 4s3 Ks4",
            "rows": "Jh2 4d3 Kh3/2d0 3s0 5s0 4c2 5c4/9c0 Jc0 8c1 Qc1 2c4",
            "win": 1.9,
            "playerId": "pid5321042"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5679753",
            "orderIndex": 0,
            "hero": true,
            "dead": "8d1 3c2 4h3 Kd4",
            "rows": "Kc0 Qh2 Qd3/7c0 6d1 5h2 7s3 Td4/9h0 9s0 Jd0 Js1 8s4",
            "win": -2,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:24:41",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000050-1": [
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "pid5321042",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jh1 6s2 5d3 7c4",
            "rows": "Ah0 Ac1 5h3/7d0 8h0 8d1 5c2 8s3/Kd0 Kc0 Ks2 Th4 Kh4",
            "win": 5.2,
            "playerId": "pid5321042"
        },
        {
            "inFantasy": false,
            "result": -27,
            "playerName": "pid5679753",
            "orderIndex": 1,
            "hero": true,
            "dead": "3d1 2d2 Jc3 Td4",
            "rows": "Qd0 Qs1 9d3/9h0 9c1 Jd2 Js2 7h3/4h0 6d0 7s0 2c4 3c4",
            "win": -5.4,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:25:53",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000051-1": [
        {
            "inFantasy": true,
            "result": 18,
            "playerName": "pid5321042",
            "orderIndex": 1,
            "hero": false,
            "dead": "2d0 4h1 2h2",
            "rows": "8c0 Kh0 Kd0/4s0 Jd0 Js0 Qd0 Qc0/5h0 5s0 Ah0 Ac0 As0",
            "win": 3.5,
            "playerId": "pid5321042"
        },
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid5679753",
            "orderIndex": 0,
            "hero": true,
            "dead": "Tc1 9d2 7s3 8s4",
            "rows": "Ks2 Qs3 9s4/3h1 6h1 6d2 5c3 Qh4/7d0 8d0 9h0 Td0 Jh0",
            "win": -3.6,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:26:40",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000052-1": [
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "pid5321042",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jh1 4d2 7d3 2h4",
            "rows": "As0 Ad1 Jd3/3s0 6s1 6d2 Kd3 3c4/9h0 9c0 Qs0 9d2 Ah4",
            "win": -1,
            "playerId": "pid5321042"
        },
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid5679753",
            "orderIndex": 1,
            "hero": true,
            "dead": "Td1 2d2 9s3 Ac4",
            "rows": "Ks3 Qh4 Qd4/3d0 5h0 7s1 5s2 5c3/7c0 Tc0 Jc0 4c1 Qc2",
            "win": 1,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:28:01",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000053-1": [
        {
            "inFantasy": true,
            "result": -1,
            "playerName": "pid5321042",
            "orderIndex": 1,
            "hero": false,
            "dead": "2h0 2c1 Jc2",
            "rows": "Kh0 Kc0 Ad0/3s0 4h0 5h0 6h0 7d0/4d0 4s0 Qd0 Qc0 Qs0",
            "win": -0.2,
            "playerId": "pid5321042"
        },
        {
            "inFantasy": true,
            "result": 1,
            "playerName": "pid5679753",
            "orderIndex": 0,
            "hero": true,
            "dead": "7h0",
            "rows": "8s0 9c0 Qh0/5d0 5s0 Jh0 Jd0 Js0/Th0 Tc0 Ah0 Ac0 As0",
            "win": 0.2,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:29:09",
    "roomId": "21938386"
}


