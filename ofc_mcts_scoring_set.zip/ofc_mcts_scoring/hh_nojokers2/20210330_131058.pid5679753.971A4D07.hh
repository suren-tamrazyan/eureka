{
    "stakes": 0.2,
    "handData": {"210330135915-21938847-0000000-1": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid108315",
            "orderIndex": 1,
            "hero": false,
            "dead": "2d1 Qs2 5s3 7s4",
            "rows": "Ah1 Kc3 5c4/3d0 3s0 6c0 8h2 8c2/9s0 Qh0 Jc1 9c3 Qd4",
            "win": 1.2,
            "playerId": "pid108315"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5679753",
            "orderIndex": 0,
            "hero": true,
            "dead": "9h1 8s2 Th3 As4",
            "rows": "Kh0 Js3 Ks3/2c0 4s0 5h1 3h2 Jh4/Td0 Jd0 7d1 6d2 4c4",
            "win": -1.2,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:10:58",
    "roomId": "21938847"
}


{
    "stakes": 0.2,
    "handData": {"210330135915-21938847-0000001-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid108315",
            "orderIndex": 0,
            "hero": false,
            "dead": "Js1 Ts2 5h3 Jc4",
            "rows": "Ks0 Kc1 Jd2/3d0 Qd1 9c3 Qc3 3c4/5c0 6s0 7s0 9h2 Kd4",
            "win": -1.2,
            "playerId": "pid108315"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5679753",
            "orderIndex": 1,
            "hero": true,
            "dead": "8c1 Td2 8s3 2d4",
            "rows": "Kh2 4d3 4s4/3s0 5d0 4c1 4h2 Ac4/9d0 Tc0 Qs0 8d1 9s3",
            "win": 1.2,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:13:31",
    "roomId": "21938847"
}


