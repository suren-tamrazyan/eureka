{
    "stakes": 20,
    "handData": {"210330081117-21921376-0000002-1": [
        {
            "inFantasy": false,
            "result": 13,
            "playerName": "pid5679594",
            "orderIndex": 1,
            "hero": false,
            "dead": "5d1 9c2 Kc3 Ad4",
            "rows": "8d1 Qc2 8c4/6d0 Js0 Jc1 4d2 Ts3/5h0 7h0 9h0 Th3 2h4",
            "win": 175,
            "playerId": "pid5679594"
        },
        {
            "inFantasy": false,
            "result": -13,
            "playerName": "pid4175886",
            "orderIndex": 0,
            "hero": false,
            "dead": "3s1 3c2 6h3 4c4",
            "rows": "Kh0 Kd0 Ah3/4h0 9s0 4s1 2s3 8h4/Qd0 As1 Jh2 Ks2 8s4",
            "win": -180,
            "playerId": "pid4175886"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": false,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:24:55",
    "roomId": "21921376"
}


{
    "stakes": 20,
    "handData": {"210330081117-21921376-0000003-1": [
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid5679594",
            "orderIndex": 1,
            "hero": false,
            "dead": "9c1 8s2 5s3 Kd4",
            "rows": "As1 9s3 3s4/4s0 7s0 4h2 6s3 7d4/5d0 8d0 Ad0 2d1 6d2",
            "win": 19,
            "playerId": "pid5679594"
        },
        {
            "inFantasy": false,
            "result": -1,
            "playerName": "pid5679560",
            "orderIndex": 0,
            "hero": true,
            "dead": "6c1 Ah2 2s3 4d4",
            "rows": "4c0 9d0 9h2/Js1 Th2 2c3 Qh3 Qs4/5h0 5c0 Kh0 Ks1 7h4",
            "win": -20,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:26:44",
    "roomId": "21921376"
}


{
    "stakes": 20,
    "handData": {"210330081117-21921376-0000004-1": [
        {
            "inFantasy": false,
            "result": 36,
            "playerName": "pid5679594",
            "orderIndex": 0,
            "hero": false,
            "dead": "8s1 3h2 Ts3 4s4",
            "rows": "Kh0 Ks0 Jd3/6h0 7h1 5h2 6c4 7s4/Jc0 Qc0 4c1 7c2 8c3",
            "win": 698,
            "playerId": "pid5679594"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid4175886",
            "orderIndex": 1,
            "hero": false,
            "dead": "Js1 5d2 2d3 3d4",
            "rows": "Qh2 5s4 Ad4/3s0 2c1 4d1 2s2 Qd3/7d0 8h0 Td0 Jh0 Tc3",
            "win": -240,
            "playerId": "pid4175886"
        },
        {
            "inFantasy": false,
            "result": -24,
            "playerName": "pid5679560",
            "orderIndex": 2,
            "hero": true,
            "dead": "8d1 Kc2 4h3 As4",
            "rows": "Ah0 Ac0 5c3/3c0 6s0 Th2 2h4 9c4/9d0 9h1 Qs1 9s2 Kd3",
            "win": -480,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:29:03",
    "roomId": "21921376"
}


{
    "stakes": 20,
    "handData": {"210330081117-21921376-0000005-1": [
        {
            "inFantasy": true,
            "result": 42,
            "playerName": "pid5679594",
            "orderIndex": 2,
            "hero": false,
            "dead": "2d0 3d1",
            "rows": "9c0 Ad0 Ac0/6d0 7c0 8c0 9s0 Tc0/7h0 8h0 Jh0 Qh0 Kh0",
            "win": 795,
            "playerId": "pid5679594"
        },
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid4175886",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jd1 4d2 4s3 Ks4",
            "rows": "9h3 9d3 As4/4h0 4c0 5d1 8s1 5h4/Th0 Ts0 Qd0 3h2 3s2",
            "win": -320,
            "playerId": "pid4175886"
        },
        {
            "inFantasy": false,
            "result": -26,
            "playerName": "pid5679560",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qs1 6s2 5s3 2c4",
            "rows": "Kd0 Ah3 5c4/2s0 6h0 2h1 6c2 Qc3/7d0 7s0 Js1 Jc2 3c4",
            "win": -500,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:30:32",
    "roomId": "21921376"
}


{
    "stakes": 20,
    "handData": {"210330081117-21921376-0000006-1": [
        {
            "inFantasy": false,
            "result": -1,
            "playerName": "pid5679594",
            "orderIndex": 0,
            "hero": false,
            "dead": "7d1 5d2 2s3 2d4",
            "rows": "Tc2 Kh3 5c4/6s0 8c0 6d1 3c2 6c3/9h0 9c0 Qd0 9s1 5s4",
            "win": -20,
            "playerId": "pid5679594"
        },
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid4175886",
            "orderIndex": 1,
            "hero": false,
            "dead": "9d1 4d2 2c3 6h4",
            "rows": "7h2 8h3 Kc3/2h0 4h0 4c0 Jh1 Jc2/Ts0 Qs0 7s1 4s4 Js4",
            "win": 19,
            "playerId": "pid4175886"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": false,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:31:40",
    "roomId": "21921376"
}


{
    "stakes": 20,
    "handData": {"210330081117-21921376-0000007-1": [
        {
            "inFantasy": false,
            "result": -39,
            "playerName": "pid5679594",
            "orderIndex": 2,
            "hero": false,
            "dead": "Jh1 2s2 7d3 5c4",
            "rows": "Qc1 Kd2 As4/5h0 6h0 7h1 Ad3 6s4/4h0 4s0 9d0 3d2 3h3",
            "win": -780,
            "playerId": "pid5679594"
        },
        {
            "inFantasy": false,
            "result": -41,
            "playerName": "pid4175886",
            "orderIndex": 0,
            "hero": false,
            "dead": "8h1 2d2 6c3 5d4",
            "rows": "Ah0 Ks3 8s4/2c0 3s0 5s0 2h2 Jd4/9h0 9s1 Jc1 Js2 7s3",
            "win": -459,
            "playerId": "pid4175886"
        },
        {
            "inFantasy": false,
            "result": 80,
            "playerName": "pid5679560",
            "orderIndex": 1,
            "hero": true,
            "dead": "4d1 6d2 Td3 4c4",
            "rows": "Qh0 Qs2 Qd4/7c0 3c1 9c3 Kc3 Ac4/8d0 8c0 Tc0 Ts1 Th2",
            "win": 1202,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:34:48",
    "roomId": "21921376"
}


{
    "stakes": 20,
    "handData": {"210330081117-21921376-0000008-1": [
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid5679594",
            "orderIndex": 0,
            "hero": false,
            "dead": "9h1 7c2 Jh3 9d4",
            "rows": "Ah0 6s2 Js4/2d0 7s0 7d1 3d2 3s3/5h0 Qh0 5s1 Kh3 2c4",
            "win": -400,
            "playerId": "pid5679594"
        },
        {
            "inFantasy": true,
            "result": 20,
            "playerName": "pid5679560",
            "orderIndex": 1,
            "hero": true,
            "dead": "3c0 9s0 Jd0",
            "rows": "Kd0 Ks0 Ad0/4h0 4s0 8h0 8c0 Qc0/2h0 2s0 6h0 6d0 6c0",
            "win": 388,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:35:44",
    "roomId": "21921376"
}


