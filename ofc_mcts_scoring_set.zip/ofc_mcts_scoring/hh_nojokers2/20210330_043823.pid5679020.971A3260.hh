{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000208-1": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h1 8c2 5c3 9h4",
            "rows": "4c3 Ks3 Ah4/9c0 3h1 2s2 3s2 3d4/5s0 6s0 9s0 Js0 As1",
            "win": 2.3,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid1503276",
            "orderIndex": 1,
            "hero": false,
            "dead": "3c1 5d2 8d3 6c4",
            "rows": "Qd1 Kh2 Td4/Tc0 Ts0 8h1 2c3 8s3/7h0 7c0 7s0 Jc2 9d4",
            "win": -2.4,
            "playerId": "pid1503276"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:38:23",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000209-1": [
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "pid4838353",
            "orderIndex": 1,
            "hero": false,
            "dead": "Td1 Kc2 Tc3 9s4",
            "rows": "Jh0 Jc1 Ac4/3c0 9c0 Qd1 9d2 3h3/7s0 Ks0 5s2 Ts3 Js4",
            "win": -1,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qs1 9h2 Th3 2s4",
            "rows": "Kh0 Kd0 8d4/3s0 4c1 As1 3d2 4s4/6d0 7d0 7c2 6s3 7h3",
            "win": 1,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:39:20",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000210-1": [
        {
            "inFantasy": false,
            "result": -7,
            "playerName": "pid4838353",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qs1 Qh2 3s3 5d4",
            "rows": "Ah2 Kc3 Kd4/4s0 6c0 2d1 2c2 6h3/8c0 Th0 Td0 Ts1 8h4",
            "win": -1.4,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": true,
            "result": 7,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "6s0 7d0",
            "rows": "Qc0 Ad0 Ac0/4h0 4d0 9d0 9s0 Tc0/3h0 3d0 Jh0 Jd0 Js0",
            "win": 1.4,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:39:55",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000211-1": [
        {
            "inFantasy": true,
            "result": 24,
            "playerName": "pid4838353",
            "orderIndex": 1,
            "hero": false,
            "dead": "7d0 Jc1",
            "rows": "8c0 Ks0 Ah0/2h0 2d0 3d0 3c0 3s0/9d0 9c0 9s0 Td0 Ts0",
            "win": 4.7,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": -24,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "6c1 7s2 2c3 Qs4",
            "rows": "Kc0 Qc3 Qd4/5h0 7c0 7h1 4s2 4d3/8s0 Jd0 Th1 Js2 5c4",
            "win": -4.8,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:40:50",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000212-1": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "pid4838353",
            "orderIndex": 0,
            "hero": false,
            "dead": "Th1 7h2 2s3 Js4",
            "rows": "Ad0 9c3 Qd4/3d0 Jh0 Jc1 4d2 6h4/6s0 Ks0 6d1 9d2 6c3",
            "win": -0.6,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "8s1 Tc2 5s3 3h4",
            "rows": "7d3 4s4 Ts4/2h0 2d0 3s0 5h2 5c3/9s0 Td0 7c1 8c1 Jd2",
            "win": 0.6,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:42:06",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000213-1": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid4838353",
            "orderIndex": 1,
            "hero": false,
            "dead": "Tc1 3d2 Ts3 3c4",
            "rows": "Jh1 Ad2 Jd3/5s0 7h0 7c2 4h3 5c4/8s0 Kh0 Kd0 Ks1 6d4",
            "win": 2.3,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "9h1 Kc2 2d3 9d4",
            "rows": "4d2 3s3 4s4/2h0 6h0 6s1 3h2 8c3/8d0 9s0 Jc0 Qc1 Js4",
            "win": -2.4,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:43:07",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000214-1": [
        {
            "inFantasy": false,
            "result": -11,
            "playerName": "pid4838353",
            "orderIndex": 0,
            "hero": false,
            "dead": "4s1 4d2 Tc3 3d4",
            "rows": "Kd0 Ah1 9c3/5h0 7c2 Th2 Ts3 7h4/Jd0 Qd0 Qs0 Jc1 8d4",
            "win": -2.2,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": 11,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "9d1 9h2 2s3 Td4",
            "rows": "Ks0 2h3 Kh3/Jh0 Ad1 8s2 2c4 Ac4/4h0 5c0 6c0 7s1 3s2",
            "win": 2.1,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:44:26",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000215-1": [
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid4838353",
            "orderIndex": 1,
            "hero": false,
            "dead": "8h1 4s2 8d3 2h4",
            "rows": "Ah0 Ac1 Qd4/4d0 7h2 7s2 3s3 5s4/Ts0 Jd0 Kc0 Qh1 As3",
            "win": -4,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": true,
            "result": 20,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "2s0 9c0",
            "rows": "Jc0 Js0 Ks0/2c0 3h0 4h0 5c0 6s0/2d0 5d0 6d0 7d0 Td0",
            "win": 3.9,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:45:10",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000216-1": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "pid4838353",
            "orderIndex": 0,
            "hero": false,
            "dead": "7s1 3d2 4s3 4d4",
            "rows": "Ac2 Qc3 Ah4/6c0 7d0 9d0 6s2 9s3/Th0 Jh0 Tc1 Js1 5c4",
            "win": 2.9,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "9h1 Td2 Jd3 8s4",
            "rows": "4h2 2d3 4c4/3c0 6d0 8h1 8d1 Kd3/Ts0 Ks0 As0 Jc2 2h4",
            "win": -3,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:46:15",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000217-1": [
        {
            "inFantasy": true,
            "result": 16,
            "playerName": "pid4838353",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qd0 Td1 3h2",
            "rows": "Kc0 Ah0 Ad0/8c0 9c0 Tc0 Js0 Qs0/2s0 4s0 6s0 7s0 Ks0",
            "win": 3.1,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "2d1 5s2 Kd3 3s4",
            "rows": "8d2 8h3 Th4/9d0 9h1 Jd1 4h2 4c4/2c0 3c0 5c0 Jc0 Qc3",
            "win": -3.2,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:47:05",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000218-1": [
        {
            "inFantasy": false,
            "result": -13,
            "playerName": "pid4838353",
            "orderIndex": 0,
            "hero": false,
            "dead": "Th1 7h2 7s3 3s4",
            "rows": "Ac0 As0 Tc3/4c1 4s2 Qc3 5h4 9s4/3d0 7d0 Kd0 2d1 Jd2",
            "win": -2.6,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": 13,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qs1 2h2 5c3 8c4",
            "rows": "Qd0 Qh1 Jc3/Kc0 Ks0 8s2 Td2 Ts4/3c0 9c0 9d1 9h3 Jh4",
            "win": 2.5,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:48:29",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000219-1": [
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid4838353",
            "orderIndex": 1,
            "hero": false,
            "dead": "Th1 8d2 7d3 3d4",
            "rows": "Ad0 3h3 4c3/2d0 Ts0 6c2 5s4 Td4/4h0 5h0 7h1 Qh1 Kh2",
            "win": -2.8,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": true,
            "result": 14,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "3s0",
            "rows": "Jh0 Ah0 Ac0/5c0 6h0 7c0 8c0 9h0/6s0 7s0 8s0 Js0 Qs0",
            "win": 2.7,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:49:10",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000220-1": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "pid4838353",
            "orderIndex": 0,
            "hero": false,
            "dead": "9h1 4c2 5s3 8s4",
            "rows": "Ah1 Js3 Jc4/6h0 6s0 2h2 6c3 2d4/7h0 7c0 Th0 Tc1 Td2",
            "win": 4.7,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": -24,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "9d1 Ts2 7d3 8d4",
            "rows": "Kd1 8c3 7s4/4h0 5c0 2c2 Ac3 Kc4/3d0 3c0 Qs0 Qh1 3h2",
            "win": -4.8,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:50:27",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000221-1": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid4838353",
            "orderIndex": 1,
            "hero": false,
            "dead": "8h1 2h2 9c3 Js4",
            "rows": "As1 Qh2 Kd4/Ts0 5s1 2c3 2s3 Th4/3c0 Tc0 Qc0 Kc0 Jc2",
            "win": 1.2,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "4d1 2d2 4h3 7h4",
            "rows": "Qd1 Ad3 Kh4/3s0 5h0 6c0 6s2 Td4/9d0 Jh0 8s1 Jd2 9h3",
            "win": -1.2,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:51:20",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000222-1": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid4838353",
            "orderIndex": 0,
            "hero": false,
            "dead": "3d1 3s2 6d3 7s4",
            "rows": "As0 6c2 7c4/4h0 9d0 8h1 Ts3 Tc4/Jc0 Kc0 Js1 Jd2 Ks3",
            "win": 2.3,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "8c1 3c2 7d3 8d4",
            "rows": "Qc1 Kd2 Ac3/5s0 9s0 4s1 5d3 6s4/3h0 7h0 Th0 Ah2 2c4",
            "win": -2.4,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:52:36",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000223-1": [
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "pid4838353",
            "orderIndex": 1,
            "hero": false,
            "dead": "5d1 2d2 4d3 4c4",
            "rows": "Tc1 3c2 6d3/5s0 Js0 7s1 8s3 9s4/6h0 Jh0 Ah0 8h2 5h4",
            "win": 3.5,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "7d1 9h2 Ks3 Td4",
            "rows": "Ac0 Kc3 As3/4h1 2s2 5c2 3d4 9d4/9c0 Th0 Jc0 Qs0 8d1",
            "win": -3.6,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:53:37",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000224-1": [
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid4838353",
            "orderIndex": 0,
            "hero": false,
            "dead": "5d1 6c2 4d3 9h4",
            "rows": "Ah0 6d3 7d4/8c1 Qc1 Th2 Td2 9c4/3s0 8s0 Ts0 Js0 Qs3",
            "win": 1.9,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jd1 Jc2 As3 Jh4",
            "rows": "Ac2 Ad3 7h4/4h0 4s0 6s1 9s2 2d4/5h0 6h0 Kh0 3h1 8h3",
            "win": -2,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:54:48",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000225-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid4838353",
            "orderIndex": 1,
            "hero": false,
            "dead": "Ah1 4s2 Jd3 4h4",
            "rows": "Ks0 5d4 Ts4/9d0 9s1 Th2 5c3 Tc3/6h0 6d0 Js0 Jh1 6s2",
            "win": 0,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jc1 Ac2 5h3 3d4",
            "rows": "Qc0 As1 Qd3/5s0 Kc0 Kh1 3h3 Qs4/7h0 8h0 7s2 8c2 9c4",
            "win": 0,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:55:42",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000226-1": [
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid4838353",
            "orderIndex": 0,
            "hero": false,
            "dead": "7c1 5c2 8d3 2d4",
            "rows": "Ah0 Ac2 Jh4/9c0 6h1 9h1 Ts3 4c4/4s0 7s0 Ks0 3s2 Js3",
            "win": -4,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": true,
            "result": 20,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "4h0",
            "rows": "5h0 Jd0 Kh0/5s0 6s0 9s0 Qs0 As0/3h0 3d0 3c0 Td0 Tc0",
            "win": 3.9,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:56:19",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000227-1": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid4838353",
            "orderIndex": 1,
            "hero": false,
            "dead": "As1 6s2 Th3 4d4",
            "rows": "Ac0 Ad1 4h3/2s0 9c0 3s1 3c2 Qs4/8h0 Jh0 8c2 8d3 Jd4",
            "win": -2.4,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "Kh1 Qd2 7c3 2d4",
            "rows": "Ah1 Tc4 Kd4/3d0 5s0 2h2 4s2 6h3/9h0 Jc0 Qh0 Ts1 8s3",
            "win": 2.3,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:57:14",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000228-1": [
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid4838353",
            "orderIndex": 0,
            "hero": false,
            "dead": "6s1 9s2 4d3 6c4",
            "rows": "Ac2 Ah3 Qc4/3d0 4s0 7h0 4h1 Jh4/2c0 Tc0 Td1 Th2 Ts3",
            "win": -2,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "7d1 9c2 3c3 3s4",
            "rows": "Ad0 6h3 Kc4/Js0 8c1 Jd2 5s3 2d4/2h0 3h0 Qh0 8h1 9h2",
            "win": 1.9,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:58:32",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000229-1": [
        {
            "inFantasy": false,
            "result": -4,
            "playerName": "pid4838353",
            "orderIndex": 1,
            "hero": false,
            "dead": "9d1 5s2 9h3 4c4",
            "rows": "As0 4d3 Ad4/2h0 7s1 3d2 3c2 2s4/7d0 8h0 9s0 Ts1 Js3",
            "win": -0.8,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": 4,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "7c1 Jc2 9c3 7h4",
            "rows": "Ac0 Kd1 Kc4/4s0 Jd0 4h1 Jh3 3s4/Qc0 Qs0 5h2 5d2 5c3",
            "win": 0.8,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:59:27",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000230-1": [
        {
            "inFantasy": true,
            "result": -22,
            "playerName": "pid4838353",
            "orderIndex": 0,
            "hero": false,
            "dead": "4s0 6c1 2s2",
            "rows": "7h0 7c0 Ks0/7s0 8c0 9d0 Th0 Jc0/3h0 3d0 3s0 5h0 5d0",
            "win": -4.4,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": true,
            "result": 22,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "As0 6s0",
            "rows": "Kh0 Kd0 Kc0/2c0 5c0 9c0 Tc0 Qc0/2h0 4h0 6h0 Jh0 Ah0",
            "win": 4.3,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 02:00:15",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000231-1": [
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid4838353",
            "orderIndex": 1,
            "hero": false,
            "dead": "Td1 Th2 9d3 5h4",
            "rows": "Ad0 Kc1 As3/6d0 6s1 3s2 7h3 Qs4/8h0 Jd0 Js0 8d2 Kd4",
            "win": -3.8,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": true,
            "result": 19,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "2c0 3c0",
            "rows": "9c0 Ah0 Ac0/3d0 5d0 5s0 7d0 7s0/2h0 4h0 6h0 Jh0 Qh0",
            "win": 3.7,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 02:00:51",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000232-1": [
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "pid4838353",
            "orderIndex": 0,
            "hero": false,
            "dead": "Th1 Jc2 3h3 2s4",
            "rows": "Ad0 Ks4 As4/2h0 8h0 4h1 7h2 Jh3/5s0 Js0 Ts1 9s2 3s3",
            "win": 3.5,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "Kh1 Tc2 2c3 8s4",
            "rows": "Ah1 9d3 Qc4/6h0 7s0 4s2 6d2 7c4/2d0 5d0 7d0 Kd1 3d3",
            "win": -3.6,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 02:02:02",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000233-1": [
        {
            "inFantasy": true,
            "result": 28,
            "playerName": "pid4838353",
            "orderIndex": 1,
            "hero": false,
            "dead": "4d0 7s1 3d2",
            "rows": "9d0 Jh0 Kh0/5h0 5d0 5s0 6d0 6s0/6c0 7c0 8c0 9c0 Tc0",
            "win": 5.4,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": -28,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "9h1 Th2 Td3 3c4",
            "rows": "Ks0 Ah2 Ts4/3s0 5c0 7h1 3h3 4s4/2h0 2c0 Js1 2d2 Qd3",
            "win": -5.6,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 02:03:09",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000234-1": [
        {
            "inFantasy": true,
            "result": 29,
            "playerName": "pid4838353",
            "orderIndex": 0,
            "hero": false,
            "dead": "2h0 6c1 8h2",
            "rows": "Td0 Ah0 As0/6s0 7s0 8s0 Js0 Ks0/3d0 3c0 5h0 5d0 5c0",
            "win": 5.6,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": -29,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qd1 9h2 8d3 Qc4",
            "rows": "Ac0 Kc3 9d4/6h0 7h0 3s1 7d2 7c3/4d0 Jd0 4s1 4h2 2s4",
            "win": -5.8,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 02:03:58",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000235-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid4838353",
            "orderIndex": 1,
            "hero": false,
            "dead": "Ac1 9s2 7d3 7c4",
            "rows": "7h2 Kh3 Kc3/3s0 4s0 5h0 3c1 5c1/Tc0 Jd0 Js2 8s4 Qh4",
            "win": 0,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "6c1 2s2 3h3 Ah4",
            "rows": "Ad0 As1 Ks4/2h0 5s0 4d2 4c2 5d3/7s0 9c0 Td1 Jc3 Qd4",
            "win": 0,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 02:04:57",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000236-1": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid4838353",
            "orderIndex": 0,
            "hero": false,
            "dead": "4s1 4h2 Td3 5s4",
            "rows": "Qd0 Ah3 Ks4/6s0 8h0 7s2 8s2 7h4/7c0 Jc0 4c1 Tc1 5c3",
            "win": 1.2,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "8d1 8c2 Kd3 2d4",
            "rows": "Ac0 Qh2 Kh3/6h0 7d0 6d1 Js4 Qc4/Th0 Ts0 9h1 Jd2 9s3",
            "win": -1.2,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 02:06:10",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000237-1": [
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid4838353",
            "orderIndex": 1,
            "hero": false,
            "dead": "Kc1 Js2 4d3 4c4",
            "rows": "Ah1 9s3 Qd4/2c0 Tc0 5c1 Th2 8h4/3d0 6d0 Td0 Jd2 7d3",
            "win": 1.9,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h1 3c2 Jh3 Ac4",
            "rows": "Ad0 Kd2 As3/6h0 9c0 6c1 9d2 7c4/Ts0 Qs0 2s1 7s3 7h4",
            "win": -2,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 02:07:07",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000238-1": [
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid4838353",
            "orderIndex": 0,
            "hero": false,
            "dead": "As1 9s2 2h3 9h4",
            "rows": "Jc2 Ts4 Qs4/3c0 7c0 7s1 7h2 6s3/Th0 Js0 Qd0 9c1 Ks3",
            "win": 1.9,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qh1 3d2 Jh3 Td4",
            "rows": "4h2 2c3 5h4/6d0 Tc0 8c1 7d2 6c3/3s0 5s0 8s0 2s1 3h4",
            "win": -2,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 02:08:28",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000239-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid4838353",
            "orderIndex": 1,
            "hero": false,
            "dead": "7s1 3d2 7c3 7d4",
            "rows": "5d2 Kc3 Ah4/3s0 4d0 Th1 Td1 4h2/9s0 Jd0 Jc0 Qh3 Ad4",
            "win": -1.2,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "Kh1 Qd2 6s3 Js4",
            "rows": "As0 9d3 Ks4/2d0 5h0 4s1 4c2 6h3/9h0 Ts0 6c1 8h2 Tc4",
            "win": 1.2,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 02:09:23",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000240-1": [
        {
            "inFantasy": false,
            "result": -13,
            "playerName": "pid4838353",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jh1 3d2 2h3 2s4",
            "rows": "4h3 Td3 6c4/7d0 7s0 5d1 8h2 8c2/9h0 9c0 Qc0 Qd1 5s4",
            "win": -2.6,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": 13,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "5h1 9s2 6h3 3s4",
            "rows": "Kd0 Ks2 6d4/3h0 8s0 3c1 8d3 Kc4/4c0 Jc0 Tc1 2c2 5c3",
            "win": 2.5,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 02:10:39",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000241-1": [
        {
            "inFantasy": false,
            "result": -23,
            "playerName": "pid4838353",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qc1 4h2 8h3 6h4",
            "rows": "Qh0 Qd2 Kh3/7d0 Td0 6d1 3d2 3h4/5s0 Js0 2s1 2c3 9s4",
            "win": -4.6,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": true,
            "result": 23,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "4d0 9d0",
            "rows": "Jd0 Ad0 As0/5c0 6s0 7s0 8d0 9h0/3c0 4c0 8c0 Tc0 Jc0",
            "win": 4.5,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 02:11:17",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000242-1": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid4838353",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jd1 8c2 Ac3 Th4",
            "rows": "6h0 Ad2 5c3/2c0 Tc0 2d1 9c1 4s3/7s0 Ks0 Jh2 7d4 Kd4",
            "win": -2.4,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "9s1 6s2 6c3 2s4",
            "rows": "8s2 Kc3 Ah4/5h0 Td0 7h1 Ts1 5s4/3d0 3s0 Js0 Jc2 3c3",
            "win": 2.3,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 02:12:33",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000243-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid4838353",
            "orderIndex": 1,
            "hero": false,
            "dead": "2c1 2s2 7c3 6h4",
            "rows": "As0 Ac1 7h3/Qs0 Ks1 8s2 Kc2 Jh4/6d0 8d0 Jd0 9d3 9h4",
            "win": -1.2,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "Js1 Th2 8h3 9s4",
            "rows": "Kd1 Ad3 9c4/3h0 5d0 6s0 5c1 3d2/7d0 7s0 2h2 4s3 4h4",
            "win": 1.2,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 02:13:35",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000244-1": [
        {
            "inFantasy": false,
            "result": -7,
            "playerName": "pid4838353",
            "orderIndex": 1,
            "hero": false,
            "dead": "Ks1 4s2 6s3 2d4",
            "rows": "Qd2 5c4 6c4/8s0 9s0 8c1 3d2 3c3/4h0 6h0 Qh0 Jh1 8h3",
            "win": -1.4,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5679020",
            "orderIndex": 2,
            "hero": true,
            "dead": "6d1 5s2 Ad3 Kh4",
            "rows": "Ah0 Ac0 7h3/2c0 7c1 7s1 9d2 2s3/Jc0 Js0 3h2 3s4 4c4",
            "win": 1.2,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "9c1 Qs2 9h3 2h4",
            "rows": "Qc1 As3 Kd4/Td0 Tc0 5h1 Ts2 Kc4/4d0 5d0 7d0 8d2 Jd3",
            "win": 0.2,
            "playerId": "pid1087966"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 02:14:43",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000245-1": [
        {
            "inFantasy": false,
            "result": -33,
            "playerName": "pid4838353",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jd1 4h2 As3 2s4",
            "rows": "Qs2 8d4 Kd4/2h0 5d0 5h1 7d1 5c3/7c0 8c0 Ac0 3c2 2c3",
            "win": -6.6,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": true,
            "result": 58,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jc0 9c0 8h0",
            "rows": "Kh0 Kc0 Ad0/7h0 7s0 Th0 Td0 Ts0/6h0 6d0 6c0 6s0 Jh0",
            "win": 11.3,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": -25,
            "playerName": "pid1087966",
            "orderIndex": 2,
            "hero": false,
            "dead": "5s1 9s2 8s3 3h4",
            "rows": "Ks0 Ah2 9h4/Js0 4d1 4s2 Tc3 4c4/3d0 3s0 Qd0 Qc1 Qh3",
            "win": -5,
            "playerId": "pid1087966"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 02:15:45",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000246-1": [
        {
            "inFantasy": false,
            "result": -45,
            "playerName": "pid4838353",
            "orderIndex": 2,
            "hero": false,
            "dead": "6s1 9c2 6c3 2h4",
            "rows": "Ah1 9d2 4s3/2d0 8d0 7h1 2c2 Jd4/Th0 Tc0 Qs0 Jc3 2s4",
            "win": -9,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": true,
            "result": 54,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "3c0 4c0 4d0",
            "rows": "7d0 7c0 7s0/Ts0 Jh0 Qh0 Kh0 Ad0/5h0 5d0 5s0 8h0 8c0",
            "win": 10.5,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "4h1 8s2 Qd3 5c4",
            "rows": "Ac0 Kc2 Ks3/6d0 6h1 9s2 9h3 As4/3h0 3s0 Qc0 3d1 Td4",
            "win": -1.8,
            "playerId": "pid1087966"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 02:16:40",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000247-1": [
        {
            "inFantasy": false,
            "result": -40,
            "playerName": "pid4838353",
            "orderIndex": 1,
            "hero": false,
            "dead": "4d1 7d2 6s3 Ks4",
            "rows": "Kh0 As1 Qs3/2d0 Ts0 3s2 7s3 8d4/6c0 Jc0 7c1 9c2 Ac4",
            "win": -5.1,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": true,
            "result": 31,
            "playerName": "pid5679020",
            "orderIndex": 2,
            "hero": true,
            "dead": "5c0 7h0 3c0",
            "rows": "9d0 Kd0 Ah0/2h0 2s0 4h0 4c0 4s0/Th0 Td0 Tc0 Jd0 Js0",
            "win": 3.2,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": true,
            "result": 9,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jh0 6d1",
            "rows": "9h0 9s0 Ad0/2c0 5h0 5s0 8c0 8s0/3h0 3d0 Qh0 Qd0 Qc0",
            "win": 1.7,
            "playerId": "pid1087966"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 02:17:25",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000248-1": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "9d1 2s2 9c3 6c4",
            "rows": "Kd1 Ad3 Td4/3h0 3s0 7h1 Th2 Tc3/4c0 4s0 Jh0 Qc2 Jd4",
            "win": 1.2,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "5h1 5d2 8s3 5c4",
            "rows": "Ks3 As3 Ac4/2d0 4d0 4h1 6h1 6s2/8c0 Ts0 Jc0 9s2 6d4",
            "win": -1.2,
            "playerId": "pid1087966"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 02:18:21",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000249-1": [
        {
            "inFantasy": false,
            "result": 7,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "5c1 Jh2 Qd3 3c4",
            "rows": "Qc0 Kh2 Kd3/Ah0 Ad0 8c3 2h4 7s4/9d0 Jd0 4h1 4s1 4c2",
            "win": 1.4,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": -7,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "Td1 3d2 2d3 4d4",
            "rows": "Ks0 Qh3 8s4/2s0 Js1 3h2 Jc2 3s3/7h0 7c0 9c0 7d1 8d4",
            "win": -1.4,
            "playerId": "pid1087966"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 02:19:20",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000250-1": [
        {
            "inFantasy": true,
            "result": -2,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "3c0 3s0",
            "rows": "7h0 Th0 Td0/5h0 5s0 8h0 8c0 9c0/Tc0 Jc0 Qd0 Ks0 As0",
            "win": -0.4,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": 2,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "2c1 6d2 7c3 4s4",
            "rows": "Ts3 Kd3 7d4/5c0 7s0 6s1 9s1 8d2/2h0 Qh0 Ah0 9h2 6h4",
            "win": 0.4,
            "playerId": "pid1087966"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 02:19:51",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000251-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "Ks1 7s2 2c3 5c4",
            "rows": "Qh0 Qc2 9c3/Tc0 Kc0 Kd1 9h3 3h4/6c0 6s0 Ah1 Jd2 2s4",
            "win": 0,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "2h1 5h2 2d3 5d4",
            "rows": "Kh1 As2 Ac3/7d0 8h0 4s1 4c3 9d4/3s0 Th0 Ts0 9s2 Td4",
            "win": 0,
            "playerId": "pid1087966"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 02:21:20",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000252-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qs1 Ks2 5h3 Th4",
            "rows": "Ad3 Ac3 9c4/2d0 4h0 7c2 7s2 8d4/Tc0 Jc0 Kc0 4c1 5c1",
            "win": 0,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "8s1 9d2 Ah3 2h4",
            "rows": "Qc0 Qh1 4s4/3d1 5s2 6d3 6s3 7d4/7h0 8c0 9s0 Ts0 Jh2",
            "win": 0,
            "playerId": "pid1087966"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 02:22:22",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000253-1": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "Ah1 5d2 Tc3 7c4",
            "rows": "6s2 8d2 Kh4/3h0 9h0 3d3 Kc3 9c4/2d0 2c0 Jc0 Jh1 Jd1",
            "win": 2.3,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "2h1 5c2 3s3 4s4",
            "rows": "Js2 Ks2 Qs4/8h0 8c0 3c1 4c1 4d3/9d0 9s0 Ts0 As3 8s4",
            "win": -2.4,
            "playerId": "pid1087966"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 02:23:34",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000254-1": [
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qd1 9h2 3d3 Jc4",
            "rows": "Ah0 Ad2 6h3/5d0 5c0 2d2 Kc3 Th4/7s0 8c0 6c1 9s1 4c4",
            "win": -2,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "Kh1 5h2 As3 Ts4",
            "rows": "7h2 Qh4 Ac4/3c0 4h0 4s1 2h2 4d3/7d0 9c0 Js0 Td1 8d3",
            "win": 1.9,
            "playerId": "pid1087966"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 02:24:23",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000255-1": [
        {
            "inFantasy": false,
            "result": 11,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "7h1 4c2 2c3 3h4",
            "rows": "As0 8h3 8d3/Td0 6d1 Th2 2d4 Qh4/6c0 7c0 8c0 9d1 5c2",
            "win": 2.1,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": -11,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jd1 9s2 7d3 2s4",
            "rows": "Ad1 Ks2 Qd3/4h0 5s1 2h2 4d3 Kh4/3c0 9c0 Qc0 Ac0 Jh4",
            "win": -2.2,
            "playerId": "pid1087966"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 02:25:40",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000256-1": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid5685540",
            "orderIndex": 0,
            "hero": false,
            "dead": "7c1 Qs2 5s3 Qh4",
            "rows": "Ks1 Ad1 Ac4/3d0 4h0 8h2 8c3 3c4/9c0 9s0 Jh0 Js2 Tc3",
            "win": 2.3,
            "playerId": "pid5685540"
        },
        {
            "inFantasy": false,
            "result": -32,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "2h1 6s2 4c3 Ts4",
            "rows": "As0 9h3 7d4/4s0 6h0 5h1 2c2 3h2/9d0 Td0 Jc1 Kc3 5c4",
            "win": -6.4,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": 20,
            "playerName": "pid1087966",
            "orderIndex": 2,
            "hero": false,
            "dead": "Th1 6c2 Kh3 2s4",
            "rows": "Ah0 Qc2 Qd4/3s0 7s0 8s1 7h3 8d4/6d0 Jd0 2d1 4d2 Kd3",
            "win": 3.9,
            "playerId": "pid1087966"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 02:27:06",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000257-1": [
        {
            "inFantasy": true,
            "result": 36,
            "playerName": "pid5685540",
            "orderIndex": 2,
            "hero": false,
            "dead": "Jc0 7d1 4d2",
            "rows": "Jh0 Kc0 Ks0/4h0 5d0 6s0 7c0 8h0/9h0 9d0 9s0 Qd0 Qs0",
            "win": 7,
            "playerId": "pid5685540"
        },
        {
            "inFantasy": false,
            "result": -42,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "3s1 5s2 As3 Kh4",
            "rows": "Ad0 Kd1 Ah3/2h0 2s0 4s0 9c2 2d3/Tc0 Th1 6c2 6h4 7s4",
            "win": -8.4,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qh0",
            "rows": "Jd0 Js0 Ac0/7h0 8d0 8c0 Td0 Ts0/3h0 3d0 3c0 5h0 5c0",
            "win": 1.2,
            "playerId": "pid1087966"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 02:28:05",
    "roomId": "21907751"
}


