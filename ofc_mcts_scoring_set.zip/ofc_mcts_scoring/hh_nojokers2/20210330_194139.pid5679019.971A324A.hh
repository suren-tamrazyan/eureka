{
    "stakes": 10,
    "handData": {"210331001654-21964407-0000004-1": [
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5679019",
            "orderIndex": 0,
            "hero": true,
            "dead": "4h1 Td2 3c3 9s4",
            "rows": "Ah0 5d3 5c4/2d0 3h0 2s1 6h2 6c3/7s0 8s0 Qs1 Qc2 3d4",
            "win": -100,
            "playerId": "pid5679019"
        },
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid144737",
            "orderIndex": 1,
            "hero": false,
            "dead": "2h1 8d2 9c3 9h4",
            "rows": "Ac2 Jh3 Kd4/4s0 Tc0 Th1 5s3 4d4/6d0 9d0 Qd0 7d1 Jd2",
            "win": 97,
            "playerId": "pid144737"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:41:39",
    "roomId": "21964407"
}


{
    "stakes": 10,
    "handData": {"210331001654-21964407-0000005-1": [
        {
            "inFantasy": false,
            "result": 36,
            "playerName": "pid284474",
            "orderIndex": 1,
            "hero": false,
            "dead": "9d1 7c2 3h3 3d4",
            "rows": "Kc0 Qd2 Ad4/4s0 9s1 Js3 As3 6s4/8h0 9h0 Ah0 Jh1 Qh2",
            "win": 349,
            "playerId": "pid284474"
        },
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid5679019",
            "orderIndex": 2,
            "hero": true,
            "dead": "8s1 2h2 Kh3 5h4",
            "rows": "Th0 Kd2 Qc3/3c0 6c0 8c0 Ts3 8d4/7d0 4h1 4c1 7s2 2s4",
            "win": -170,
            "playerId": "pid5679019"
        },
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid144737",
            "orderIndex": 0,
            "hero": false,
            "dead": "4d1 6h2 3s3 2d4",
            "rows": "Ac0 Qs2 Td3/5c0 5s0 2c2 7h3 Tc4/9c0 Ks0 Jd1 Jc1 5d4",
            "win": -190,
            "playerId": "pid144737"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:43:45",
    "roomId": "21964407"
}


{
    "stakes": 10,
    "handData": {"210331001654-21964407-0000006-1": [
        {
            "inFantasy": false,
            "result": -4,
            "playerName": "pid284474",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qs1 5s2 8d3 2c4",
            "rows": "Kd1 4c3 Kh3/7d0 8h0 9s0 9c1 8s2/Td0 Tc0 Th2 5h4 8c4",
            "win": -40,
            "playerId": "pid284474"
        },
        {
            "inFantasy": false,
            "result": 23,
            "playerName": "pid5679019",
            "orderIndex": 1,
            "hero": true,
            "dead": "2s1 Js2 Ac3 3h4",
            "rows": "As1 Ad3 6d4/4h0 7c0 3d2 7h2 7s4/9h0 Ts0 Qc0 Jh1 Ks3",
            "win": 223,
            "playerId": "pid5679019"
        },
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid144737",
            "orderIndex": 2,
            "hero": false,
            "dead": "6h1 6c2 6s3 2h4",
            "rows": "Ah0 Qh1 Qd2/2d0 4s0 5d1 5c3 4d4/3c0 Jc0 3s2 Jd3 Kc4",
            "win": -190,
            "playerId": "pid144737"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:45:49",
    "roomId": "21964407"
}


{
    "stakes": 10,
    "handData": {"210331001654-21964407-0000007-1": [
        {
            "inFantasy": true,
            "result": 8,
            "playerName": "pid284474",
            "orderIndex": 2,
            "hero": false,
            "dead": "4c0 2s1",
            "rows": "7h0 8d0 Ts0/3h0 3c0 3s0 Kh0 Kd0/6d0 6s0 Ah0 Ad0 As0",
            "win": 78,
            "playerId": "pid284474"
        },
        {
            "inFantasy": true,
            "result": -2,
            "playerName": "pid5679019",
            "orderIndex": 0,
            "hero": true,
            "dead": "4h0 5h0 6h0",
            "rows": "7c0 9h0 9s0/2d0 5d0 9d0 Td0 Qd0/4s0 7s0 8s0 Js0 Qs0",
            "win": -20,
            "playerId": "pid5679019"
        },
        {
            "inFantasy": true,
            "result": -6,
            "playerName": "pid144737",
            "orderIndex": 1,
            "hero": false,
            "dead": "2h0",
            "rows": "3d0 Jh0 Jd0/4d0 5s0 6c0 7d0 8h0/5c0 9c0 Tc0 Qc0 Ac0",
            "win": -60,
            "playerId": "pid144737"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:46:36",
    "roomId": "21964407"
}


{
    "stakes": 10,
    "handData": {"210331001654-21964407-0000008-1": [
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid284474",
            "orderIndex": 1,
            "hero": false,
            "dead": "9h1 Jc2 2c3 4c4",
            "rows": "Kd0 Ks0 8c2/5d1 7d1 Kh2 Kc3 Ah4/2s0 9s0 Qs0 7s3 7h4",
            "win": -160,
            "playerId": "pid284474"
        },
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid5679019",
            "orderIndex": 2,
            "hero": true,
            "dead": "Jd1 Ad2 4s3 2d4",
            "rows": "Ac1 6s3 5h4/7c0 8h0 3d2 3c2 8s3/Td0 Ts0 Js0 Tc1 2h4",
            "win": 10,
            "playerId": "pid5679019"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "pid144737",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qc1 Qd2 5s3 3h4",
            "rows": "9c2 8d3 As4/3s0 4d0 6c0 5c1 6d4/Jh0 Qh0 6h1 Th2 4h3",
            "win": 145,
            "playerId": "pid144737"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:48:50",
    "roomId": "21964407"
}


{
    "stakes": 10,
    "handData": {"210331001654-21964407-0000009-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5679019",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jd1 2c2 Kh3 Th4",
            "rows": "Kd2 Ks2 5d4/3c0 9c1 9h3 As3 4h4/8h0 8s0 Jc0 Js0 Jh1",
            "win": 0,
            "playerId": "pid5679019"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid144737",
            "orderIndex": 1,
            "hero": false,
            "dead": "3h1 3s2 6d3 2d4",
            "rows": "Td1 7d3 9d4/4d0 5h0 7c1 6h2 3d3/8d0 Qd0 Qc0 8c2 7s4",
            "win": 0,
            "playerId": "pid144737"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:49:39",
    "roomId": "21964407"
}


{
    "stakes": 10,
    "handData": {"210331001654-21964407-0000010-1": [
        {
            "inFantasy": false,
            "result": -2,
            "playerName": "pid5679019",
            "orderIndex": 1,
            "hero": true,
            "dead": "8h1 Ks2 6s3 Jc4",
            "rows": "Qc1 Qs3 Ad3/6h0 6d0 7h0 3d2 7s4/5s0 Ts0 Tc1 5c2 2h4",
            "win": -20,
            "playerId": "pid5679019"
        },
        {
            "inFantasy": false,
            "result": 2,
            "playerName": "pid144737",
            "orderIndex": 0,
            "hero": false,
            "dead": "9d1 9h2 Kc3 3s4",
            "rows": "Ah0 Kh1 Kd2/3c0 4s0 8s2 3h3 8d3/Th0 Td0 2c1 2d4 9s4",
            "win": 19,
            "playerId": "pid144737"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:50:52",
    "roomId": "21964407"
}


{
    "stakes": 10,
    "handData": {"210331001654-21964407-0000011-1": [
        {
            "inFantasy": true,
            "result": -10,
            "playerName": "pid5679019",
            "orderIndex": 0,
            "hero": true,
            "dead": "5s0",
            "rows": "Kh0 Ks0 Ah0/6c0 Jh0 Js0 Qc0 Qs0/2s0 3d0 4c0 5d0 6s0",
            "win": -100,
            "playerId": "pid5679019"
        },
        {
            "inFantasy": true,
            "result": 10,
            "playerName": "pid144737",
            "orderIndex": 1,
            "hero": false,
            "dead": "2h0 3h1",
            "rows": "8h0 Qh0 Qd0/2d0 7d0 9d0 Jd0 Kd0/2c0 7c0 8c0 Tc0 Ac0",
            "win": 97,
            "playerId": "pid144737"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:51:29",
    "roomId": "21964407"
}


{
    "stakes": 10,
    "handData": {"210331001654-21964407-0000012-1": [
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid5679019",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qh1 3c2 Qd3 Kd4",
            "rows": "Kc1 Ks1 Jc4/2s0 5d0 4d2 5c2 2h3/6h0 6c0 8c0 Tc3 2c4",
            "win": -80,
            "playerId": "pid5679019"
        },
        {
            "inFantasy": false,
            "result": 8,
            "playerName": "pid144737",
            "orderIndex": 0,
            "hero": false,
            "dead": "3d1 7d2 6d3 4c4",
            "rows": "Qs0 Th3 9d4/4h0 3h2 Ac2 7s3 As4/6s0 7h0 9c0 5h1 8d1",
            "win": 78,
            "playerId": "pid144737"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:52:46",
    "roomId": "21964407"
}


{
    "stakes": 10,
    "handData": {"210331001654-21964407-0000013-1": [
        {
            "inFantasy": false,
            "result": 23,
            "playerName": "pid5216321",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jd1 Th2 9d3 4h4",
            "rows": "Kd0 Ks0 Qd3/As0 2s1 Ad3 6s4 Ah4/4c0 7c0 5c1 Tc2 Qc2",
            "win": 223,
            "playerId": "pid5216321"
        },
        {
            "inFantasy": false,
            "result": -36,
            "playerName": "pid5679019",
            "orderIndex": 1,
            "hero": true,
            "dead": "5d1 3c2 7d3 Qs4",
            "rows": "Kh0 Ac2 5h4/2h0 2c0 3h1 3s1 Qh3/6d0 Td0 Jc2 6h3 4d4",
            "win": -243,
            "playerId": "pid5679019"
        },
        {
            "inFantasy": false,
            "result": 13,
            "playerName": "pid144737",
            "orderIndex": 2,
            "hero": false,
            "dead": "Kc1 Jh2 8c3 Ts4",
            "rows": "2d0 Js1 9s3/4s0 3d1 6c2 5s4 7s4/8d0 9h0 9c0 8h2 8s3",
            "win": 13,
            "playerId": "pid144737"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:54:56",
    "roomId": "21964407"
}


{
    "stakes": 10,
    "handData": {"210331001654-21964407-0000014-1": [
        {
            "inFantasy": true,
            "result": 23,
            "playerName": "pid5216321",
            "orderIndex": 1,
            "hero": false,
            "dead": "8c0 Js1",
            "rows": "Qh0 Ah0 Ac0/4c0 5c0 6h0 7c0 8h0/2d0 4d0 8d0 9d0 Qd0",
            "win": 223,
            "playerId": "pid5216321"
        },
        {
            "inFantasy": false,
            "result": -23,
            "playerName": "pid144737",
            "orderIndex": 0,
            "hero": false,
            "dead": "2s1 7d2 6s3 4s4",
            "rows": "Td2 As2 Jd3/8s0 Jc0 Tc1 Qc1 Qs3/3h0 7h0 9h0 7s4 9c4",
            "win": -230,
            "playerId": "pid144737"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": false,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:56:05",
    "roomId": "21964407"
}


{
    "stakes": 10,
    "handData": {"210331001654-21964407-0000015-1": [
        {
            "inFantasy": false,
            "result": -23,
            "playerName": "pid5216321",
            "orderIndex": 0,
            "hero": false,
            "dead": "2c1 5d2 8d3 8c4",
            "rows": "Td1 Jc2 As3/4s0 8s0 7c1 4c2 Ac4/5h0 6h0 7h0 7d3 Jh4",
            "win": -230,
            "playerId": "pid5216321"
        },
        {
            "inFantasy": false,
            "result": 8,
            "playerName": "pid5679019",
            "orderIndex": 1,
            "hero": true,
            "dead": "5s1 8h2 3c3 4d4",
            "rows": "Ad0 6c3 Qd4/2s0 3s0 2h1 2d2 Tc3/Jd0 Kh0 9s1 Ts2 Qh4",
            "win": 78,
            "playerId": "pid5679019"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "pid144737",
            "orderIndex": 2,
            "hero": false,
            "dead": "5c1 7s2 6s3 4h4",
            "rows": "Qs0 Ks0 Qc3/3h0 Kd1 Kc1 Ah3 3d4/9d0 Th0 9h2 9c2 Js4",
            "win": 145,
            "playerId": "pid144737"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:58:43",
    "roomId": "21964407"
}


{
    "stakes": 10,
    "handData": {"210331001654-21964407-0000016-1": [
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid5216321",
            "orderIndex": 2,
            "hero": false,
            "dead": "2c1 2h2 8d3 7c4",
            "rows": "As0 Qh4 Kc4/5h1 5s2 Tc2 4h3 4d3/3h0 3d0 9d0 9c0 3s1",
            "win": -180,
            "playerId": "pid5216321"
        },
        {
            "inFantasy": false,
            "result": -2,
            "playerName": "pid5679019",
            "orderIndex": 0,
            "hero": true,
            "dead": "3c1 5c2 7s3 9h4",
            "rows": "Ad0 Qd1 Ac2/4s0 Ts1 4c2 Th3 Jc3/6h0 8h0 Kh0 8c4 8s4",
            "win": -20,
            "playerId": "pid5679019"
        },
        {
            "inFantasy": true,
            "result": 20,
            "playerName": "pid144737",
            "orderIndex": 1,
            "hero": false,
            "dead": "5d0",
            "rows": "Td0 Kd0 Ks0/7d0 Jh0 Js0 Qc0 Qs0/2d0 2s0 6d0 6c0 6s0",
            "win": 194,
            "playerId": "pid144737"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 17:00:19",
    "roomId": "21964407"
}


{
    "stakes": 10,
    "handData": {"210331001654-21964407-0000017-1": [
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid5216321",
            "orderIndex": 1,
            "hero": false,
            "dead": "3c1 Jh2 4d3 7h4",
            "rows": "Kc0 Qh3 9h4/5s0 Jc0 Js1 3d2 3h4/7d0 8d0 7c1 Ad2 Ac3",
            "win": -170,
            "playerId": "pid5216321"
        },
        {
            "inFantasy": true,
            "result": 31,
            "playerName": "pid5679019",
            "orderIndex": 2,
            "hero": true,
            "dead": "8c0 3s0 6d0",
            "rows": "Qc0 Qs0 Kh0/5h0 5d0 9s0 Tc0 Ts0/2h0 2d0 2c0 4h0 4c0",
            "win": 301,
            "playerId": "pid5679019"
        },
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid144737",
            "orderIndex": 0,
            "hero": false,
            "dead": "Th1 9d2 8s3 6c4",
            "rows": "Ks1 Td4 Qd4/Ah0 As0 2s1 9c3 Jd3/4s0 5c0 7s0 6s2 8h2",
            "win": -140,
            "playerId": "pid144737"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 17:01:57",
    "roomId": "21964407"
}


