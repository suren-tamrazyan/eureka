{
    "stakes": 5,
    "handData": {"210330064847-21916709-0000003-1": [
        {
            "inFantasy": true,
            "result": 25,
            "playerName": "pid5172376",
            "orderIndex": 0,
            "hero": false,
            "dead": "4c0 7c1 2s2",
            "rows": "Js0 Qd0 Qs0/3d0 4d0 6d0 7d0 Kd0/2h0 3h0 8h0 Qh0 Ah0",
            "win": 121,
            "playerId": "pid5172376"
        },
        {
            "inFantasy": false,
            "result": -25,
            "playerName": "pid2813203",
            "orderIndex": 1,
            "hero": false,
            "dead": "2c1 5d2 5c3 4s4",
            "rows": "Qc2 Ac3 Jd4/7h0 9c0 9s1 Ts2 5h4/8d0 8c0 Jc0 8s1 6c3",
            "win": -125,
            "playerId": "pid2813203"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": false,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:23:51",
    "roomId": "21916709"
}


{
    "stakes": 5,
    "handData": {"210330064847-21916709-0000004-1": [
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "pid2813203",
            "orderIndex": 1,
            "hero": false,
            "dead": "2d1 5s2 8h3 3c4",
            "rows": "Ac0 Ah1 9s3/5h0 9d0 5c2 9c2 Jh4/Qh0 Qs0 3d1 3h3 Qd4",
            "win": 44,
            "playerId": "pid2813203"
        },
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "pid5679436",
            "orderIndex": 0,
            "hero": true,
            "dead": "7s1 8d2 9h3 Tc4",
            "rows": "Ad0 Jd2 Jc4/4d0 4s0 2c1 Td2 2s3/6c0 Kc0 6d1 Kh3 6s4",
            "win": -45,
            "playerId": "pid5679436"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:24:54",
    "roomId": "21916709"
}


{
    "stakes": 5,
    "handData": {"210330064847-21916709-0000005-1": [
        {
            "inFantasy": true,
            "result": 15,
            "playerName": "pid2813203",
            "orderIndex": 0,
            "hero": false,
            "dead": "3c0 6d1 7s2",
            "rows": "Qh0 Qc0 As0/4c0 4s0 Th0 Td0 Ks0/3h0 4h0 5h0 6h0 7h0",
            "win": 73,
            "playerId": "pid2813203"
        },
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid5679436",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qs1 5d2 9d3 9s4",
            "rows": "Kc0 Kd1 Js4/Ah0 Ad0 2d2 9c2 Ts3/3d0 Jd0 3s1 8h3 Jh4",
            "win": -75,
            "playerId": "pid5679436"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:25:35",
    "roomId": "21916709"
}


{
    "stakes": 5,
    "handData": {"210330064847-21916709-0000006-1": [
        {
            "inFantasy": true,
            "result": 20,
            "playerName": "pid2813203",
            "orderIndex": 1,
            "hero": false,
            "dead": "4d0 6h1 7c2",
            "rows": "Th0 Jh0 Ks0/5h0 5d0 5s0 8d0 8c0/2c0 Ah0 Ad0 Ac0 As0",
            "win": 97,
            "playerId": "pid2813203"
        },
        {
            "inFantasy": true,
            "result": -20,
            "playerName": "pid5679436",
            "orderIndex": 0,
            "hero": true,
            "dead": "4c0 8h0",
            "rows": "9s0 Ts0 Js0/2h0 3c0 4h0 5c0 6c0/2d0 7d0 Td0 Jd0 Kd0",
            "win": -100,
            "playerId": "pid5679436"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:26:25",
    "roomId": "21916709"
}


{
    "stakes": 5,
    "handData": {"210330064847-21916709-0000007-1": [
        {
            "inFantasy": true,
            "result": 25,
            "playerName": "pid2813203",
            "orderIndex": 0,
            "hero": false,
            "dead": "8s0 5h1 7d2",
            "rows": "6c0 6s0 As0/2h0 2d0 9h0 9d0 9c0/3c0 3s0 Qh0 Qd0 Qs0",
            "win": 29,
            "playerId": "pid2813203"
        },
        {
            "inFantasy": false,
            "result": -25,
            "playerName": "pid5679436",
            "orderIndex": 1,
            "hero": true,
            "dead": "4d1 Jh2 Js3 Kh4",
            "rows": "Ks0 Ac1 Ah3/3d0 6d0 5d2 5s4 8d4/8h0 Tc0 8c1 Th2 Ts3",
            "win": -30,
            "playerId": "pid5679436"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:27:48",
    "roomId": "21916709"
}


