{
    "stakes": 8,
    "handData": {"210330065056-21916828-0000001-1": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid2813203",
            "orderIndex": 1,
            "hero": false,
            "dead": "4d1 7d2 6s3 6d4",
            "rows": "Kh1 Kd1 7h3/2c0 9c0 5s2 9s3 5c4/Th0 Td0 Jd0 Jc2 Ts4",
            "win": 47,
            "playerId": "pid2813203"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5679436",
            "orderIndex": 0,
            "hero": true,
            "dead": "3c1 Js2 5h3 5d4",
            "rows": "Ac0 As1 Tc3/2h0 3d0 3s0 2s2 4c3/Qc0 7s1 8d2 7c4 8h4",
            "win": -48,
            "playerId": "pid5679436"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:30:15",
    "roomId": "21916828"
}


{
    "stakes": 8,
    "handData": {"210330065056-21916828-0000002-1": [
        {
            "inFantasy": true,
            "result": -8,
            "playerName": "pid2813203",
            "orderIndex": 0,
            "hero": false,
            "dead": "2d0 3d1",
            "rows": "4c0 5d0 8d0/3s0 7s0 8s0 9s0 As0/8h0 9h0 Th0 Jh0 Ah0",
            "win": -64,
            "playerId": "pid2813203"
        },
        {
            "inFantasy": true,
            "result": 8,
            "playerName": "pid5679436",
            "orderIndex": 1,
            "hero": true,
            "dead": "3c0 4h0 3h0",
            "rows": "7c0 Qc0 Qs0/2s0 5s0 Ts0 Js0 Ks0/4d0 9d0 Td0 Kd0 Ad0",
            "win": 62,
            "playerId": "pid5679436"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:31:17",
    "roomId": "21916828"
}


{
    "stakes": 8,
    "handData": {"210330065056-21916828-0000003-1": [
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid2813203",
            "orderIndex": 1,
            "hero": false,
            "dead": "3h1 Qh2 2s3 7s4",
            "rows": "Ah0 Ac1 Ad4/4h1 5c2 4c3 6c3 Jc4/3d0 4d0 Jd0 Qd0 2d2",
            "win": -80,
            "playerId": "pid2813203"
        },
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid5679436",
            "orderIndex": 0,
            "hero": true,
            "dead": "Td1 6d2 5s3 Kh4",
            "rows": "Ks0 7d3 5h4/7h0 Js0 9s2 Th2 9d3/2c0 3c0 Qc1 Kc1 7c4",
            "win": 78,
            "playerId": "pid5679436"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:32:23",
    "roomId": "21916828"
}


{
    "stakes": 8,
    "handData": {"210330065056-21916828-0000004-1": [
        {
            "inFantasy": false,
            "result": 25,
            "playerName": "pid5172376",
            "orderIndex": 0,
            "hero": false,
            "dead": "7s1 4d2 8s3 3c4",
            "rows": "As0 Ah3 Qd4/2s0 4c0 4h1 2c2 8h2/6h0 6d0 9h1 6s3 9d4",
            "win": 194,
            "playerId": "pid5172376"
        },
        {
            "inFantasy": false,
            "result": -37,
            "playerName": "pid2813203",
            "orderIndex": 1,
            "hero": false,
            "dead": "Ac1 2h2 4s3 9s4",
            "rows": "Ks0 Kd1 5c3/5d0 7d0 7h1 5h2 Kh4/8c0 Qh0 Qc2 Th3 Jh4",
            "win": -296,
            "playerId": "pid2813203"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid5679436",
            "orderIndex": 2,
            "hero": true,
            "dead": "2d1 Js2 Jd3 Qs4",
            "rows": "Jc2 Kc2 3s3/5s0 9c0 8d1 6c4 7c4/3h0 Td0 Ts0 3d1 Tc3",
            "win": 93,
            "playerId": "pid5679436"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:33:40",
    "roomId": "21916828"
}


{
    "stakes": 8,
    "handData": {"210330065056-21916828-0000005-1": [
        {
            "inFantasy": true,
            "result": 42,
            "playerName": "pid5172376",
            "orderIndex": 2,
            "hero": false,
            "dead": "9c0 7d1 6c2",
            "rows": "Jd0 Ah0 As0/5s0 6h0 7s0 8c0 9s0/2h0 2d0 2c0 4d0 4s0",
            "win": 309,
            "playerId": "pid5172376"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "pid2813203",
            "orderIndex": 0,
            "hero": false,
            "dead": "4c1 5d2 5h3 6s4",
            "rows": "Kc0 Ks0 Qs3/7c0 Ac1 Ad2 8d3 6d4/Th0 Ts0 3h1 3s2 8h4",
            "win": -7,
            "playerId": "pid2813203"
        },
        {
            "inFantasy": false,
            "result": -39,
            "playerName": "pid5679436",
            "orderIndex": 1,
            "hero": true,
            "dead": "7h1 Td2 Jc3 Kh4",
            "rows": "Qh1 Jh3 Qd3/4h0 2s2 8s2 3d4 5c4/9h0 Tc0 Js0 Qc0 Kd1",
            "win": -312,
            "playerId": "pid5679436"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:36:19",
    "roomId": "21916828"
}


