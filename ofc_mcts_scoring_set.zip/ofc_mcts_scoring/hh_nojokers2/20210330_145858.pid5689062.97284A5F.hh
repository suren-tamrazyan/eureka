{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000062-1": [
        {
            "inFantasy": false,
            "result": -2,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jc1 7c2 3c3 9h4",
            "rows": "Kh1 7s4 Js4/Td0 Qd0 6c1 Kd3 Kc3/2h0 2c0 2s0 4h2 4s2",
            "win": -0.4,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": 2,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "2d1 Tc2 8s3 Ts4",
            "rows": "Ac0 Qh2 Qc4/5d0 7d1 8h1 5s2 8d3/9d0 9c0 Jd0 Jh3 Th4",
            "win": 0.4,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 11:58:58",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000063-1": [
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "6d1 2s2 3d3 Ks4",
            "rows": "Qc1 As3 Ad4/9d0 Jc0 Js1 7s2 9s4/2h0 4h0 Kh0 6h2 Th3",
            "win": -2,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": true,
            "result": 10,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "6s0",
            "rows": "7c0 9c0 Kd0/3h0 3c0 3s0 Qd0 Qs0/4c0 5h0 5d0 5c0 5s0",
            "win": 1.9,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 11:59:40",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000064-1": [
        {
            "inFantasy": true,
            "result": 8,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "4h0 4d0 3d0",
            "rows": "Qc0 Qs0 Ad0/7d0 7c0 Th0 Tc0 Kc0/5h0 6h0 6d0 6c0 6s0",
            "win": 1.6,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": true,
            "result": -8,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "7s0",
            "rows": "9d0 Kh0 Ks0/2h0 2s0 3c0 3s0 4c0/8h0 9c0 Ts0 Jc0 Qd0",
            "win": -1.6,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:00:15",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000065-1": [
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "9c0 7d0 Jc0",
            "rows": "Ks0 Ad0 Ac0/3h0 3d0 Qh0 Qd0 Kc0/2h0 2s0 5h0 5d0 5c0",
            "win": 4.1,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "6c1 3s2 5s3 6h4",
            "rows": "As0 Qs3 Qc4/2c0 8c0 8s1 2d2 6s2/4h0 Th0 Tc1 7c3 9d4",
            "win": -4.2,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:00:53",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000066-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "9h1 Js2 2c3 Qc4",
            "rows": "Qd0 Kd1 Ah3/2d0 2s0 5d1 6s2 Qs3/4c0 8c0 Td2 7d4 9s4",
            "win": -1.2,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "6h1 2h2 Kh3 3c4",
            "rows": "Qh0 Ad1 9c2/3d0 6d1 Jd2 6c3 5c4/7s0 Ks0 As0 8s3 Kc4",
            "win": 1.2,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:02:10",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000067-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h1 8d2 6s3 Js4",
            "rows": "8h2 6d3 Jc4/4d0 5h0 5d1 4s2 4c3/Td0 Tc0 Qc0 Qd1 3c4",
            "win": 0,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "7c1 7d2 9h3 8c4",
            "rows": "Kd0 Kc0 Ts3/3d0 4h0 5c0 5s1 7s4/Ad1 Jh2 Ks2 Ah3 Kh4",
            "win": 0,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:03:03",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000068-1": [
        {
            "inFantasy": false,
            "result": 14,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "2h1 Js2 4c3 8s4",
            "rows": "Kh0 Qh1 Ks2/Ad0 7s1 Jd2 7c3 As4/6d0 6c0 9s0 6s3 Kc4",
            "win": 2.7,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "Ah1 Th2 3d3 7h4",
            "rows": "Qc2 5h3 5s4/5c0 Jh0 3h1 3c1 Jc2/2s0 4s0 Ts0 4h3 4d4",
            "win": -2.8,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:04:04",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000069-1": [
        {
            "inFantasy": true,
            "result": 39,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "7h0 4h0",
            "rows": "Kh0 Kd0 Ks0/3c0 5c0 8c0 Tc0 Kc0/7s0 8s0 Js0 Qs0 As0",
            "win": 7.6,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": -39,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "5h1 4c2 6d3 3h4",
            "rows": "Qd3 9c4 Th4/2h0 2d0 6h0 6c1 8d3/9s0 Qc0 9d1 Jh2 Jd2",
            "win": -7.8,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:04:33",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000070-1": [
        {
            "inFantasy": true,
            "result": 20,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "2d0 5s0",
            "rows": "Jc0 Kd0 Ks0/7d0 8c0 8s0 9h0 9d0/4h0 4d0 4c0 6c0 6s0",
            "win": 3.9,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "5d1 8d2 2c3 Kh4",
            "rows": "As0 Kc2 3h4/Th0 Jh0 6d1 Tc1 9s4/3c0 Qc0 3d2 5c3 Qh3",
            "win": -4,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:05:06",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000071-1": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "5d1 7h2 4c3 2d4",
            "rows": "As2 Td3 Kd4/6c0 3c1 Qh2 Jc3 3d4/8c0 8s0 Tc0 Ts0 8d1",
            "win": 2.3,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "7d1 Js2 Th3 Jd4",
            "rows": "Kc2 Qc3 Qs3/2h0 2s0 5c0 2c1 Ah4/6s0 7s0 8h1 5h2 Jh4",
            "win": -2.4,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:06:00",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000072-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "Tc1 2c2 9c3 3c4",
            "rows": "Qh0 Ah1 Jd4/5h0 6s0 5s2 7h2 Qd4/3d0 8d0 7d1 2d3 6d3",
            "win": -1.2,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qc1 6h2 4c3 7s4",
            "rows": "As2 8c3 Ad4/7c0 8s0 8h1 9h1 9s3/2h0 2s0 Jh0 Js2 9d4",
            "win": 1.2,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:07:07",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000073-1": [
        {
            "inFantasy": false,
            "result": -27,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "7d1 8h2 Ts3 7c4",
            "rows": "Ac2 Qd3 8s4/3s0 3h1 2s2 Jc3 2c4/7s0 8c0 9c0 Td0 6d1",
            "win": -5.4,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": true,
            "result": 27,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "Js0 9d1 3c2",
            "rows": "Qc0 Ad0 As0/2h0 7h0 9h0 Jh0 Kh0/4d0 4s0 6h0 6c0 6s0",
            "win": 5.2,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:07:57",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000074-1": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "8c1 Th2 Ac3 Jh4",
            "rows": "Kd0 Kc3 3d4/7s0 2d1 4h1 7h2 4s3/9c0 9s0 Qs0 5d2 3h4",
            "win": -2.4,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jd1 9d2 Td3 5h4",
            "rows": "Ah0 Jc3 5c4/6d0 Tc0 6h1 6c2 7d2/3s0 Ks0 8s1 2s3 Ts4",
            "win": 2.3,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:09:08",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000075-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "3h1 4d2 8d3 Ts4",
            "rows": "Th1 Jd2 Jc3/4h0 8c0 Kc1 Kd2 Qd3/6s0 9s0 Ks0 5c4 7h4",
            "win": 0,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "3d1 3s2 2d3 2s4",
            "rows": "Ad0 5h2 Ac3/4s0 8h0 7s1 7d2 Jh4/6d0 9d0 9h1 5s3 6h4",
            "win": 0,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:09:56",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000076-1": [
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "Td1 Kd2 8c3 Qc4",
            "rows": "Ac0 8d2 Ad2/3h0 5c0 9h1 3s3 9s3/2h0 2c0 Jh1 6h4 7s4",
            "win": -3.6,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "Th1 6c2 Tc3 2d4",
            "rows": "Kh0 Kc0 3c4/3d0 4s0 7h0 4d2 7d3/6s1 Ks1 8s2 Ts3 2s4",
            "win": 3.5,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:11:07",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000077-1": [
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "3c1 5c2 8d3 Kh4",
            "rows": "Ah0 Ac1 Tc3/4d0 Jh0 Qh2 6d4 Js4/6s0 Ks0 Kd1 6c2 Kc3",
            "win": -4,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": true,
            "result": 20,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "2d0 4c1",
            "rows": "8h0 Th0 Qc0/2s0 3s0 4s0 5s0 Ts0/7h0 7c0 9h0 9c0 9s0",
            "win": 3.9,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:11:59",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000078-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "7c1 5s2 Qs3 Th4",
            "rows": "4d2 Js2 Qd3/2s0 9c0 Jc0 9d1 Jd1/5h0 8h0 3h3 2c4 6d4",
            "win": 0,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "5c1 As2 2h3 3c4",
            "rows": "Ad0 Ac1 Ah3/4s0 8d0 5d2 6c3 4c4/Td0 Qc0 9s1 Kd2 3d4",
            "win": 0,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:13:12",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000079-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "6s1 7s2 5h3 Ks4",
            "rows": "As0 Ah2 Qd4/2h0 7h0 7d0 9d2 9h3/8s0 8c1 Tc1 Ac3 3c4",
            "win": -1.2,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "Ts1 4h2 Td3 2s4",
            "rows": "4c3 5c3 2c4/2d0 9c0 3h1 6d2 6c2/8h0 8d0 Qh0 Qc1 Ad4",
            "win": 1.2,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:14:01",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000080-1": [
        {
            "inFantasy": false,
            "result": 22,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qd1 3s2 3h3 9h4",
            "rows": "Ks0 7h3 Kd4/2c0 Tc0 2h1 5h3 2d4/Jc0 Js0 Jd1 8d2 8s2",
            "win": 4.3,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": -22,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "4c1 3d2 Ac3 2s4",
            "rows": "Ah0 Ad2 4s3/7c0 6s1 7d1 8c2 Td4/9d0 9c0 Qc0 Kc3 Qs4",
            "win": -4.4,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:15:10",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000081-1": [
        {
            "inFantasy": true,
            "result": 38,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h0 Ks0",
            "rows": "Qh0 Qd0 Qs0/3c0 6c0 7c0 9c0 Qc0/4h0 5h0 Th0 Kh0 Ah0",
            "win": 7.4,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": -38,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "9h1 9s2 4d3 As4",
            "rows": "Ac0 5c3 Tc3/6s0 7s0 8d1 8c1 4c4/2c0 Jc0 3d2 3s2 3h4",
            "win": -7.6,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:15:43",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000082-1": [
        {
            "inFantasy": true,
            "result": 16,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "5s0 8s0",
            "rows": "Tc0 Kd0 Kc0/2h0 2d0 6h0 6c0 9h0/8c0 9s0 Ts0 Jc0 Qh0",
            "win": 3.1,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "Td1 3h2 9c3 4h4",
            "rows": "Ad1 As2 7h4/4s0 6d0 5h1 6s2 4d3/3d0 3s0 Qc0 Ks3 9d4",
            "win": -3.2,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:16:19",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000083-1": [
        {
            "inFantasy": false,
            "result": -1,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jc1 Js2 Ac3 5c4",
            "rows": "Kd0 Jh2 2d4/2h0 7s0 3c1 3d2 7d3/Th0 Td0 Ts1 Qs3 Qh4",
            "win": -0.2,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "3h1 Ks2 8s3 8d4",
            "rows": "Qc0 Kh0 Kc1/Ah0 Ad1 2c2 7c4 9c4/5d0 9d0 Qd2 9h3 9s3",
            "win": 0.2,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:17:15",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000084-1": [
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "6h1 7d2 Td3 8s4",
            "rows": "Ah0 Th2 Ac2/Qc0 2c1 Kc1 Kd3 8c4/2s0 4s0 Ts0 9s3 6s4",
            "win": -3.2,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": true,
            "result": 16,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "3c0 7s1",
            "rows": "9d0 Qd0 Ad0/2h0 3s0 4h0 5d0 6c0/Jh0 Jd0 Jc0 Kh0 Ks0",
            "win": 3.1,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:18:05",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000085-1": [
        {
            "inFantasy": false,
            "result": -23,
            "playerName": "pid5450708",
            "orderIndex": 0,
            "hero": false,
            "dead": "8s1 3h2 3s3 Ac4",
            "rows": "Td2 Kc2 6h3/2s0 4h0 4s0 7h1 5c4/5s0 Jh0 9h1 9c3 Jd4",
            "win": -4.6,
            "playerId": "pid5450708"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "5h1 3d2 Qs3 4c4",
            "rows": "Ah0 Kd3 4d4/8d0 Th1 9s2 Qd3 Jc4/2c0 3c0 6c0 7c1 Qc2",
            "win": 2.9,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": 8,
            "playerName": "pid2923305",
            "orderIndex": 2,
            "hero": false,
            "dead": "9d1 8c2 7s3 2h4",
            "rows": "Ks0 Qh1 Kh4/5d0 Ad0 As1 7d3 Js3/Tc0 Ts0 6d2 6s2 8h4",
            "win": 1.6,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:19:33",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000086-1": [
        {
            "inFantasy": false,
            "result": -30,
            "playerName": "pid5450708",
            "orderIndex": 2,
            "hero": false,
            "dead": "3d1 9c2 Ks3 2h4",
            "rows": "Kh1 Ac1 Ah3/7d0 Jc0 Qd2 Qc2 2s4/Th0 Td0 Ts0 8c3 9d4",
            "win": -6,
            "playerId": "pid5450708"
        },
        {
            "inFantasy": false,
            "result": -1,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "2c1 Jd2 8s3 6s4",
            "rows": "4c2 Tc4 As4/6d0 7h0 7c0 5s1 5c3/Jh0 Qh0 6h1 5h2 3h3",
            "win": -0.2,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": true,
            "result": 31,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "7s0 8h1",
            "rows": "9h0 Qs0 Kc0/2d0 5d0 8d0 Kd0 Ad0/3c0 3s0 4h0 4d0 4s0",
            "win": 6,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:20:31",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000087-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5450708",
            "orderIndex": 1,
            "hero": false,
            "dead": "5c1 3d2 Tc3 2c4",
            "rows": "8c0 As0 Ac1/7h0 7c0 6c2 4h4 8d4/Qc0 Jc1 Kd2 Td3 Ad3",
            "win": -1.2,
            "playerId": "pid5450708"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid5689062",
            "orderIndex": 2,
            "hero": true,
            "dead": "5s1 Js2 4s3 2s4",
            "rows": "Qh0 Ah1 Ks3/2d0 4d0 7d2 5d3 2h4/9c0 9s0 Th1 Ts2 Qs4",
            "win": 2.3,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "3h1 6s2 Jd3 5h4",
            "rows": "7s2 Kh3 Kc3/3c0 3s0 6h0 9d1 9h2/8h0 8s0 Jh1 4c4 6d4",
            "win": -1.2,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:22:18",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000088-1": [
        {
            "inFantasy": false,
            "result": -36,
            "playerName": "pid5450708",
            "orderIndex": 0,
            "hero": false,
            "dead": "4h1 6c2 6s3 2c4",
            "rows": "9h3 7h4 Ad4/3d0 8h0 8c0 2h1 2d3/9c0 9s0 Js1 Th2 Ts2",
            "win": -7.2,
            "playerId": "pid5450708"
        },
        {
            "inFantasy": false,
            "result": 25,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "Tc1 7d2 9d3 Jh4",
            "rows": "Kh0 Qc3 Ks3/4d0 Ah1 Ac2 4c4 8s4/5d0 5c0 Jd0 5s1 Jc2",
            "win": 4.8,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": 11,
            "playerName": "pid2923305",
            "orderIndex": 2,
            "hero": false,
            "dead": "Td1 As2 6d3 2s4",
            "rows": "Kd1 Kc2 5h4/3h0 6h0 7s0 3c3 3s3/8d0 Qd0 Qh1 Qs2 7c4",
            "win": 2.1,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:23:54",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000089-1": [
        {
            "inFantasy": false,
            "result": -42,
            "playerName": "pid5450708",
            "orderIndex": 2,
            "hero": false,
            "dead": "7s1 5d2 9s3 Tc4",
            "rows": "9c2 Ks3 9h4/2c0 3h0 6d1 3d3 4s4/Jc0 Qh0 Qc0 8d1 Qd2",
            "win": -1,
            "playerId": "pid5450708"
        },
        {
            "inFantasy": true,
            "result": 37,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "6c0 8s0",
            "rows": "Jh0 Js0 As0/2d0 7d0 Jd0 Kd0 Ad0/4h0 4d0 4c0 5h0 5c0",
            "win": 1,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": true,
            "result": 5,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "7c0 6h1",
            "rows": "Qs0 Kh0 Kc0/2h0 3c0 5s0 Ah0 Ac0/6s0 7h0 8c0 9d0 Td0",
            "win": 0,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:24:46",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000090-1": [
        {
            "inFantasy": false,
            "result": -7,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jd1 7c2 8s3 6s4",
            "rows": "Ac1 Qc3 5c4/9h0 Th0 9d1 Ts2 8c3/2h0 2d0 2s0 3d2 Tc4",
            "win": -1.4,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": 7,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "4h1 Td2 3c3 7d4",
            "rows": "Kd0 Qd2 Kh3/7h0 7s1 8d1 6d2 8h4/5s0 9s0 Js0 9c3 Jc4",
            "win": 1.4,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:25:53",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000091-1": [
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "2c1 4c2 6c3 3h4",
            "rows": "8c3 Tc3 Jc4/6s0 9h0 8s1 8h2 9s2/2d0 5d0 Td0 Jd1 8d4",
            "win": -1.6,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": true,
            "result": 8,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "9c0 Js1",
            "rows": "Kc0 Ac0 As0/2h0 3d0 3c0 Qh0 Qc0/3s0 4h0 5c0 6h0 7s0",
            "win": 1.6,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:26:43",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000092-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5450708",
            "orderIndex": 1,
            "hero": false,
            "dead": "4s1 4c2 9c3 2s4",
            "rows": "Ks0 Kc2 Ac4/2d0 6s0 2c1 3c3 3s4/9d0 Ts0 Jd1 Jc2 Td3",
            "win": 0,
            "playerId": "pid5450708"
        },
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid5689062",
            "orderIndex": 2,
            "hero": true,
            "dead": "Jh1 9h2 3h3 8c4",
            "rows": "As1 Tc3 5s4/4d0 5h0 6c0 6h1 5c4/9s0 Js0 7d2 Th2 8h3",
            "win": -3.2,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": 16,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qd1 8s2 Qs3 4h4",
            "rows": "7c2 Qc4 Kd4/3d0 5d0 8d0 6d2 Ad3/Qh0 Kh0 7h1 Ah1 2h3",
            "win": 3.1,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:28:07",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000093-1": [
        {
            "inFantasy": true,
            "result": 62,
            "playerName": "pid5450708",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qc0 Kc1",
            "rows": "9h0 9c0 9s0/2c0 3c0 4d0 5d0 6h0/6s0 7s0 Ts0 Js0 Ks0",
            "win": 12,
            "playerId": "pid5450708"
        },
        {
            "inFantasy": false,
            "result": -31,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "6d1 3s2 2s3 Tc4",
            "rows": "As0 Ah2 Kh3/3h0 8s0 7d1 8d1 5s4/Jc0 Qd0 Jh2 9d3 4c4",
            "win": -6.2,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": -31,
            "playerName": "pid2923305",
            "orderIndex": 2,
            "hero": false,
            "dead": "8c1 5c2 3d3 2d4",
            "rows": "Ac0 7c3 Th4/5h0 6c0 8h0 7h2 4h3/Jd0 Td1 Kd1 Qh2 Qs4",
            "win": -6.2,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:29:06",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000094-1": [
        {
            "inFantasy": true,
            "result": 47,
            "playerName": "pid5450708",
            "orderIndex": 2,
            "hero": false,
            "dead": "3c0 2c1",
            "rows": "7d0 7c0 7s0/8h0 8d0 8c0 Js0 Qh0/6h0 6d0 6c0 9h0 9s0",
            "win": 9.1,
            "playerId": "pid5450708"
        },
        {
            "inFantasy": false,
            "result": -41,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "5s1 5c2 6s3 As4",
            "rows": "Kh0 Kd0 Ah3/4c0 3d1 3s1 4h2 Ks4/Jh0 Qs0 Ts2 Jc3 4s4",
            "win": -8.2,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "9c1 8s2 5h3 2d4",
            "rows": "Kc0 9d4 Jd4/Ac0 Ad1 2s2 3h2 5d3/Th0 Qd0 Qc0 Td1 Tc3",
            "win": -1.2,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:29:59",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000095-1": [
        {
            "inFantasy": true,
            "result": 27,
            "playerName": "pid5450708",
            "orderIndex": 1,
            "hero": false,
            "dead": "3s0 2s1",
            "rows": "Jh0 Jd0 As0/8d0 9d0 Td0 Qc0 Qs0/4d0 4c0 4s0 6h0 6c0",
            "win": 5.2,
            "playerId": "pid5450708"
        },
        {
            "inFantasy": false,
            "result": -28,
            "playerName": "pid5689062",
            "orderIndex": 2,
            "hero": true,
            "dead": "Kd1 9c2 Jc3 Kh4",
            "rows": "Ac0 Ah3 3h4/5s0 8c0 7s1 5c3 2c4/Th0 Qh0 Qd1 2h2 2d2",
            "win": -5.6,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "8h1 9h2 7d3 5d4",
            "rows": "Ad1 Tc3 Ks4/3d0 3c0 5h1 7h2 7c2/6s0 9s0 Js0 Ts3 8s4",
            "win": 0.2,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:31:11",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000096-1": [
        {
            "inFantasy": false,
            "result": 17,
            "playerName": "pid5450708",
            "orderIndex": 0,
            "hero": false,
            "dead": "2s1 4h2 8s3 2c4",
            "rows": "Ad2 As3 Qd4/5h0 5s0 7d0 7s1 6s2/9h0 9d0 Ts1 Th3 5c4",
            "win": 3.3,
            "playerId": "pid5450708"
        },
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "8h1 3s2 8c3 9s4",
            "rows": "Ah0 Jd3 5d4/2d0 6d0 Td2 6c3 6h4/7c0 9c0 3c1 4c1 Jc2",
            "win": 1.9,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": -27,
            "playerName": "pid2923305",
            "orderIndex": 2,
            "hero": false,
            "dead": "Kc1 7h2 8d3 2h4",
            "rows": "Kd0 Ks0 Qs2/4d0 Ac0 Js2 Jh3 4s4/Tc0 3h1 3d1 Qc3 Kh4",
            "win": -5.4,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:32:41",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000097-1": [
        {
            "inFantasy": true,
            "result": 27,
            "playerName": "pid5450708",
            "orderIndex": 2,
            "hero": false,
            "dead": "6c0 2c1 3c2",
            "rows": "Ks0 Ah0 As0/8d0 Jd0 Js0 Qd0 Qc0/4h0 7h0 8h0 9h0 Kh0",
            "win": 5.2,
            "playerId": "pid5450708"
        },
        {
            "inFantasy": false,
            "result": -26,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "4c1 Td2 2h3 6s4",
            "rows": "2d2 2s2 5c3/4s0 7c0 8c1 8s1 7d4/3d0 3s0 Qs0 Qh3 Kd4",
            "win": -5.2,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": -1,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "Ts1 6d2 7s3 4d4",
            "rows": "Ac3 5s4 Tc4/5d0 9s0 9c1 9d2 Jc3/6h0 Th0 Jh0 5h1 3h2",
            "win": -0.2,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:33:35",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000098-1": [
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "pid5450708",
            "orderIndex": 1,
            "hero": false,
            "dead": "5s1 4d2 2h3 4h4",
            "rows": "Ks3 Td4 Qc4/5d0 5c0 7s0 8h1 8s2/Th0 Js0 Jd1 Tc2 4c3",
            "win": -1.8,
            "playerId": "pid5450708"
        },
        {
            "inFantasy": false,
            "result": 25,
            "playerName": "pid5689062",
            "orderIndex": 2,
            "hero": true,
            "dead": "4s1 Qs2 Kh3 7h4",
            "rows": "Ah0 Ad2 6c4/2s0 3h0 8c2 3d3 8d4/6d0 Kd0 9d1 9c1 9s3",
            "win": 4.8,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "As1 3s2 2d3 2c4",
            "rows": "Ts2 3c3 Kc3/5h0 6h0 6s0 7d2 7c4/Jh0 Qd0 Jc1 Qh1 Ac4",
            "win": -3.2,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:35:03",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000099-1": [
        {
            "inFantasy": false,
            "result": -22,
            "playerName": "pid5450708",
            "orderIndex": 0,
            "hero": false,
            "dead": "4d1 Th2 7d3 Ts4",
            "rows": "Ad0 9h3 Jh4/2c0 8s0 6c1 6s1 8h3/Jd0 Jc0 Qh2 Qd2 Qc4",
            "win": -4.4,
            "playerId": "pid5450708"
        },
        {
            "inFantasy": true,
            "result": 46,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "Td0 4s0 6d0",
            "rows": "Qs0 Ac0 As0/2h0 3h0 4h0 5h0 7h0/8d0 8c0 Kh0 Kd0 Ks0",
            "win": 8.9,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": -24,
            "playerName": "pid2923305",
            "orderIndex": 2,
            "hero": false,
            "dead": "5d1 Js2 7c3 7s4",
            "rows": "Kc0 Ah1 Tc4/2s0 4c0 3d1 2d3 3c3/9d0 9s0 5c2 5s2 9c4",
            "win": -4.8,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:35:58",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000100-1": [
        {
            "inFantasy": false,
            "result": -38,
            "playerName": "pid5450708",
            "orderIndex": 2,
            "hero": false,
            "dead": "3h1 8c2 5c3 3c4",
            "rows": "Ah1 Kd2 Kc3/4d0 7h0 7c0 2c2 4s3/Jd0 Qs0 Jc1 2s4 Ks4",
            "win": -7.6,
            "playerId": "pid5450708"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "3s1 6c2 3d3 Qh4",
            "rows": "Qc0 Qd2 4c4/6d0 6s0 5s1 As3 5d4/7d0 Td0 9s1 9d2 9c3",
            "win": 0,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": 38,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "9h1 Ad2 2d3 7s4",
            "rows": "Kh1 Tc4 Ts4/4h0 Th0 5h2 6h2 2h3/8d0 8s0 Js0 Jh1 8h3",
            "win": 7.4,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:37:05",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000101-1": [
        {
            "inFantasy": false,
            "result": -44,
            "playerName": "pid5450708",
            "orderIndex": 1,
            "hero": false,
            "dead": "4h1 5d2 9d3 8s4",
            "rows": "Ah0 Jd3 9s4/2c0 6c0 3d1 2s2 As4/Tc0 Qh0 9h1 Qs2 Ts3",
            "win": -8.8,
            "playerId": "pid5450708"
        },
        {
            "inFantasy": true,
            "result": 19,
            "playerName": "pid5689062",
            "orderIndex": 2,
            "hero": true,
            "dead": "2d0",
            "rows": "5h0 9c0 Ac0/4c0 4s0 7h0 7d0 7s0/Th0 Td0 Kh0 Kd0 Ks0",
            "win": 3.7,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": 25,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "6s1 4d2 8d3 6d4",
            "rows": "Js1 Qc3 Qd4/2h0 8h0 3h2 Jh3 6h4/5c0 7c0 Kc0 8c1 3c2",
            "win": 4.8,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:37:59",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000102-1": [
        {
            "inFantasy": false,
            "result": -2,
            "playerName": "pid5450708",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jd1 4s2 Ts3 6h4",
            "rows": "Ac1 Jc4 Kc4/3s0 7h0 2d1 2h3 3h3/5d0 5s0 Qd0 4d2 4c2",
            "win": -0.4,
            "playerId": "pid5450708"
        },
        {
            "inFantasy": false,
            "result": -4,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "6c1 3c2 Qh3 6d4",
            "rows": "Ah0 7d2 Qs4/Jh0 4h1 Td2 8d3 8s3/9h0 9d0 Ks0 Kh1 Ad4",
            "win": -0.8,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "pid2923305",
            "orderIndex": 2,
            "hero": false,
            "dead": "3d0",
            "rows": "5h0 6s0 7s0/2s0 8h0 Th0 Js0 Kd0/2c0 5c0 7c0 8c0 Qc0",
            "win": 1.2,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:39:16",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000103-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5450708",
            "orderIndex": 2,
            "hero": false,
            "dead": "Js1 Qd2 8h3 9d4",
            "rows": "Kh0 Kc3 As4/3d0 3s0 Td1 7s2 9s4/5c0 9c0 4c1 3c2 Jc3",
            "win": 0,
            "playerId": "pid5450708"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "Th1 8s2 4d3 8c4",
            "rows": "Ad0 9h3 Ac3/5d0 6c0 2c1 2s1 7h4/Jh0 Qh0 Tc2 Ts2 6h4",
            "win": 0,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "7c1 6s2 5s3 6d4",
            "rows": "Kd0 Ks0 5h3/3h0 4s0 2h1 2d1 4h2/Jd0 Qs2 Qc3 8d4 Ah4",
            "win": 0,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:40:16",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000104-1": [
        {
            "inFantasy": false,
            "result": 34,
            "playerName": "pid5450708",
            "orderIndex": 1,
            "hero": false,
            "dead": "4d1 Th2 3c3 Qs4",
            "rows": "Ad0 Ks3 As4/2h0 2d0 4h0 4s1 7d3/Qh0 9h1 8s2 Ts2 Js4",
            "win": 6.6,
            "playerId": "pid5450708"
        },
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid5689062",
            "orderIndex": 2,
            "hero": true,
            "dead": "Ah1 Qd2 5s3 Ac4",
            "rows": "Kc0 2c3 Kh4/3d0 5c0 5h1 3h2 7s3/8h0 9c0 Jh1 Jc2 3s4",
            "win": -3.4,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "6s1 4c2 2s3 6h4",
            "rows": "7h1 Tc4 Jd4/8c0 Qc0 6c2 7c3 9d3/5d0 6d0 Td0 8d1 9s2",
            "win": -3.4,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:42:00",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000105-1": [
        {
            "inFantasy": true,
            "result": 26,
            "playerName": "pid5450708",
            "orderIndex": 0,
            "hero": false,
            "dead": "Ts0 5s1 4c2",
            "rows": "Kh0 Ks0 Ac0/8h0 8d0 9d0 9c0 Qh0/2d0 2s0 Jh0 Jd0 Jc0",
            "win": 5,
            "playerId": "pid5450708"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "7c1 Kc2 9s3 Tc4",
            "rows": "As0 9h3 Ah4/3d0 4d0 2c1 3h2 4h3/5h0 5c0 6s1 6c2 2h4",
            "win": 1.7,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": -35,
            "playerName": "pid2923305",
            "orderIndex": 2,
            "hero": false,
            "dead": "5d1 Qc2 6d3 Th4",
            "rows": "Qd0 Kd0 Qs2/Ad0 3s1 8c2 4s4 8s4/7h0 7d0 Js1 7s3 Td3",
            "win": -7,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:42:57",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000106-1": [
        {
            "inFantasy": false,
            "result": -24,
            "playerName": "pid5450708",
            "orderIndex": 2,
            "hero": false,
            "dead": "8d1 8c2 9c3 7d4",
            "rows": "Ah0 Kh3 Qs4/2s0 4d0 6d2 6c3 Td4/7h0 Js0 9h1 9s1 Jh2",
            "win": -4.8,
            "playerId": "pid5450708"
        },
        {
            "inFantasy": true,
            "result": 23,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "6s0 2c0 4h0",
            "rows": "Th0 Ts0 Kc0/7c0 9d0 Jd0 Qh0 Qd0/5h0 5d0 Ad0 Ac0 As0",
            "win": 4.5,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "Tc1 2d2 5c3 8s4",
            "rows": "Qc0 Jc2 Kd4/3h0 8h0 2h1 3d2 3c4/4s0 7s0 5s1 3s3 Ks3",
            "win": 0.2,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:43:52",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000107-1": [
        {
            "inFantasy": false,
            "result": -2,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qd1 4d2 Jd3 7c4",
            "rows": "Kc0 Ks1 Ah4/2c0 5h0 2h1 2d3 Kh3/4s0 9s0 6s2 Ts2 As4",
            "win": -0.4,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": 2,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "7s1 Th2 4c3 4h4",
            "rows": "Ad0 Ac1 Qh3/6h0 8s0 6c1 9h3 9d4/3c0 Jc0 3h2 Js2 Jh4",
            "win": 0.4,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:45:07",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000108-1": [
        {
            "inFantasy": true,
            "result": 9,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "5d0 5c0",
            "rows": "8h0 8d0 Qc0/2s0 7s0 Ts0 Js0 As0/6d0 7d0 Td0 Kd0 Ad0",
            "win": 1.7,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": true,
            "result": -9,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "3s0 9s1 2h2",
            "rows": "4h0 4d0 Qs0/2c0 3c0 6c0 9c0 Kc0/5h0 6h0 Th0 Jh0 Ah0",
            "win": -1.8,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:45:42",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000109-1": [
        {
            "inFantasy": false,
            "result": 14,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "7h1 9s2 8h3 3h4",
            "rows": "Kh2 4s4 9h4/3c0 6c0 4h1 5c1 2s3/2d0 7d0 Qd0 3d2 8d3",
            "win": 2.7,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "8s1 As2 Qh3 Th4",
            "rows": "Ah0 Ac0 Kd2/5d1 9d1 6d2 Jd3 2c4/8c0 Tc0 Jc0 Kc3 Qc4",
            "win": -2.8,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:47:00",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000110-1": [
        {
            "inFantasy": false,
            "result": -26,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jc1 Jd2 9h3 7c4",
            "rows": "Kd0 As3 2h4/Ah0 Ad0 2c2 2s3 Th4/5h0 8h0 6s1 7h1 4s2",
            "win": -5.2,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": 26,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "9c1 8c2 Kc3 5d4",
            "rows": "Ks1 Kh2 7s4/4d0 8d0 7d1 6d3 Td3/Jh0 Qd0 Qc0 Js2 Qh4",
            "win": 5,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:47:51",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000111-1": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "6s1 6d2 2d3 2s4",
            "rows": "As0 6c3 Kc4/7d0 Th0 Tc1 5d3 Jd4/Qh0 Qd0 9c1 9h2 Qc2",
            "win": -2.4,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": true,
            "result": 12,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "4s0 4h1",
            "rows": "Jh0 Jc0 Kh0/2c0 8h0 8s0 Td0 Ts0/3d0 3c0 Ah0 Ad0 Ac0",
            "win": 2.3,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:48:39",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000112-1": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "3h1 Qc2 3c3 Th4",
            "rows": "2h1 2s1 As3/6d0 7h0 9s0 9h2 Ts3/5c0 Jc0 Jd2 8d4 8c4",
            "win": 1.2,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qh1 Qs2 Kh3 Qd4",
            "rows": "Kd0 Ad2 Ah3/2c0 4h0 6c1 5s3 3d4/7d0 8s0 7c1 8h2 6h4",
            "win": -1.2,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:49:49",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000113-1": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "7h1 5d2 Td3 4d4",
            "rows": "Ac2 Ks3 As4/3d0 Jc0 Js1 2c3 Jh4/5s0 6s0 9s0 3s1 Ts2",
            "win": 4.1,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "5h1 9d2 Kh3 4h4",
            "rows": "Kd1 Ah3 Qh4/6d0 7s0 8c1 6c2 9c4/4c0 4s0 Qc0 Th2 Qd3",
            "win": -4.2,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:51:02",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000114-1": [
        {
            "inFantasy": true,
            "result": 15,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "3c0 4c0 8c0",
            "rows": "Js0 Qs0 As0/3d0 5d0 Td0 Kd0 Ad0/2h0 2c0 2s0 6h0 6s0",
            "win": 2.9,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "9c1 Kh2 7c3 Ks4",
            "rows": "Qh0 Ac1 Kc3/3h0 5s0 3s2 8h2 4s4/Tc0 Jc0 Jd1 9s3 Ts4",
            "win": -3,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:51:43",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000115-1": [
        {
            "inFantasy": false,
            "result": -22,
            "playerName": "pid5334816",
            "orderIndex": 1,
            "hero": false,
            "dead": "9d1 5d2 3h3 5s4",
            "rows": "Ks1 Ah3 6h4/8c0 Tc0 Th1 7d2 8h3/2h0 2s0 Jh0 Qs2 8d4",
            "win": -4.4,
            "playerId": "pid5334816"
        },
        {
            "inFantasy": false,
            "result": 13,
            "playerName": "pid5689062",
            "orderIndex": 2,
            "hero": true,
            "dead": "4h1 Qc2 6c3 2c4",
            "rows": "Qh0 3c3 7c4/Jd0 Kh0 6d1 Ac2 Kd4/5h0 9c0 5c1 9h2 9s3",
            "win": 2.5,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "3d1 Jc2 Qd3 Td4",
            "rows": "Ad1 Kc2 Ts4/2d0 7h0 4d1 7s2 4c4/3s0 4s0 Js0 6s3 8s3",
            "win": 1.7,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:53:16",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000116-1": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "pid5334816",
            "orderIndex": 0,
            "hero": false,
            "dead": "4h1 4s2 Th3 Ad4",
            "rows": "Qh1 Kd2 Ks2/5h0 5s0 8s0 7s3 7h4/9c0 Jc0 4c1 Tc3 Ac4",
            "win": 4.7,
            "playerId": "pid5334816"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "2s1 Js2 4d3 Ah4",
            "rows": "Kh0 8d4 8c4/9s0 Td0 9h1 Ts1 2d3/7c0 Qc0 3d2 3s2 Qs3",
            "win": -2,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid2923305",
            "orderIndex": 2,
            "hero": false,
            "dead": "3c1 6c2 As3 2c4",
            "rows": "5c0 Kc2 6h4/8h0 Jh0 2h1 Jd3 3h4/7d0 Qd0 6d1 9d2 5d3",
            "win": -2.8,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:54:48",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000117-1": [
        {
            "inFantasy": true,
            "result": 26,
            "playerName": "pid5334816",
            "orderIndex": 2,
            "hero": false,
            "dead": "3s0 Jh1",
            "rows": "Tc0 Ts0 Ac0/6h0 6c0 8c0 8s0 Qh0/2d0 7d0 Jd0 Kd0 Ad0",
            "win": 5,
            "playerId": "pid5334816"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "9c1 3c2 3d3 2c4",
            "rows": "7s2 4h3 4d4/Td0 Qd0 Jc1 As3 Js4/2h0 8h0 Kh0 7h1 9h2",
            "win": -1.2,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "9d1 Qc2 2s3 9s4",
            "rows": "Ah2 Qs3 Ks4/4c0 6s0 3h1 6d1 4s3/5h0 5c0 8d0 5s2 Th4",
            "win": -4,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:55:41",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000118-1": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5334816",
            "orderIndex": 1,
            "hero": false,
            "dead": "3d1 3c2 7c3 5d4",
            "rows": "9c2 Kc2 Qs3/4c0 8s0 5c1 6c1 7s3/2h0 6h0 Qh0 Jc4 Ks4",
            "win": -2.4,
            "playerId": "pid5334816"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5689062",
            "orderIndex": 2,
            "hero": true,
            "dead": "6d1 9d2 2s3 Th4",
            "rows": "Ah2 Ac2 Qd3/As0 Jh1 Jd1 Kh3 2c4/5s0 6s0 8d0 9h0 2d4",
            "win": -2.4,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "9s1 Kd2 Ad3 5h4",
            "rows": "Qc3 7h4 Js4/3s0 4h0 4d1 7d1 3h3/8c0 Td0 Ts0 8h2 Tc2",
            "win": 4.7,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:57:12",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000119-1": [
        {
            "inFantasy": false,
            "result": -13,
            "playerName": "pid5334816",
            "orderIndex": 0,
            "hero": false,
            "dead": "4s1 Ah2 6c3 2c4",
            "rows": "7c3 Tc4 Ad4/2h0 6s0 5d1 4c2 3d3/7s0 Th0 Jc0 8d1 9s2",
            "win": -2.6,
            "playerId": "pid5334816"
        },
        {
            "inFantasy": false,
            "result": 19,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "2s1 5h2 4h3 Ac4",
            "rows": "Qd2 Jh3 Jd3/8c0 Td0 7h1 9c1 6h2/Ts0 Js0 Qs0 8s4 9d4",
            "win": 3.7,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid2923305",
            "orderIndex": 2,
            "hero": false,
            "dead": "As1 8h2 7d3 6d4",
            "rows": "3h3 3s3 9h4/2d0 4d0 5s0 5c2 3c4/Qc0 Kc0 Kh1 Kd1 Qh2",
            "win": -1.2,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:58:40",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000120-1": [
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5334816",
            "orderIndex": 2,
            "hero": false,
            "dead": "2s1 5c2 7c3 3h4",
            "rows": "Kd2 Jc3 5d4/6c0 7s0 4d1 7d1 6s3/Th0 Qd0 Qs0 8h2 Qc4",
            "win": -2,
            "playerId": "pid5334816"
        },
        {
            "inFantasy": false,
            "result": -22,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jh1 7h2 8d3 Qh4",
            "rows": "Ac0 Ad1 Jd4/4h0 Tc0 Ts1 6d2 4s4/5s0 Ks0 3s2 2d3 2c3",
            "win": -4.4,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": 32,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "Td1 6h2 3c3 9s4",
            "rows": "As0 Kc3 Js4/2h0 3d0 4c1 5h2 Ah4/8c0 9d0 9h1 9c2 8s3",
            "win": 6.2,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:59:29",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000121-1": [
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "pid5334816",
            "orderIndex": 1,
            "hero": false,
            "dead": "2h1 9c2 9s3 Qc4",
            "rows": "Ac2 Jc3 Ad4/3s0 4h0 3d1 5c3 5h4/9d0 Tc0 Jh0 7c1 8c2",
            "win": 3.5,
            "playerId": "pid5334816"
        },
        {
            "inFantasy": false,
            "result": 14,
            "playerName": "pid5689062",
            "orderIndex": 2,
            "hero": true,
            "dead": "8s1 5s2 6s3 Jd4",
            "rows": "Ah0 As3 Kd4/9h0 Qd0 Qh1 7h2 7d2/3c0 Kc0 Ks1 6c3 Kh4",
            "win": 2.7,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": -32,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "2c1 8d2 4d3 3h4",
            "rows": "Th2 4c3 8h4/7s0 Qs0 2s1 Ts2 Js3/5d0 6d0 Td0 2d1 6h4",
            "win": -6.4,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:01:02",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000122-1": [
        {
            "inFantasy": true,
            "result": 14,
            "playerName": "pid5334816",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qd0 Jd1 Qc2",
            "rows": "Kh0 Ah0 As0/3h0 4d0 5c0 6d0 7s0/9d0 9s0 Th0 Td0 Ts0",
            "win": 2.7,
            "playerId": "pid5334816"
        },
        {
            "inFantasy": true,
            "result": 29,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "5s0 7d0 6c0",
            "rows": "Ks0 Ad0 Ac0/9h0 9c0 Tc0 Jh0 Jc0/4h0 5h0 6h0 7h0 8h0",
            "win": 5.6,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": -43,
            "playerName": "pid2923305",
            "orderIndex": 2,
            "hero": false,
            "dead": "2d1 6s2 5d3 3c4",
            "rows": "Kd1 8d4 Js4/3d0 4s0 7c0 3s1 4c3/Qh0 Qs0 2h2 2s2 2c3",
            "win": -8.6,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:01:41",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000123-1": [
        {
            "inFantasy": false,
            "result": -33,
            "playerName": "pid5334816",
            "orderIndex": 2,
            "hero": false,
            "dead": "6h1 Qd2 2c3 7c4",
            "rows": "Qc1 Ah2 8d3/5h0 7d0 9c0 9d3 2h4/Ts0 Js0 2s1 7s2 Th4",
            "win": -6.6,
            "playerId": "pid5334816"
        },
        {
            "inFantasy": true,
            "result": 78,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jd0 As0 6s0",
            "rows": "Kd0 Kc0 Ks0/4h0 7h0 9h0 Jh0 Qh0/3c0 4c0 8c0 Jc0 Ac0",
            "win": 13.7,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": -45,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qs1 8s2 4s3 2d4",
            "rows": "Kh0 Ad2 5s3/4d0 3h1 5d1 6c2 6d3/8h0 9s0 Td0 3s4 5c4",
            "win": -7.5,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:02:50",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000124-1": [
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "pid5334816",
            "orderIndex": 0,
            "hero": false,
            "dead": "9h1 4s2 5c3 5s4",
            "rows": "Qs0 Kc2 Qc3/2s0 9d1 7s2 Tc4 Jd4/Td0 Jc0 Js0 Th1 8d3",
            "win": -4.2,
            "playerId": "pid5334816"
        },
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "2d0 7h0 2c0",
            "rows": "Kh0 Ah0 As0/4d0 4c0 9c0 9s0 Ts0/3h0 3d0 6h0 6c0 6s0",
            "win": 4.1,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:03:22",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000125-1": [
        {
            "inFantasy": false,
            "result": -22,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jd1 3s2 7h3 3c4",
            "rows": "Td1 Qh2 As4/2d0 3d0 2h1 3h2 Ah3/6c0 6s0 8c0 8d3 Ad4",
            "win": -4.4,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": 22,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "6h1 5s2 Ts3 5d4",
            "rows": "Ks0 Kd2 4h4/4c0 4s0 2c1 4d3 7s4/9h0 9s0 Jc1 9c2 Jh3",
            "win": 4.3,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:04:45",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000126-1": [
        {
            "inFantasy": false,
            "result": -2,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "9d1 8c2 5c3 3s4",
            "rows": "Ac1 As2 Th3/6h0 Td0 Ts2 6s3 Qh4/2h0 Jh0 Js0 2c1 3d4",
            "win": -0.4,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": true,
            "result": 2,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "5h0 6d1",
            "rows": "8d0 Qd0 Ad0/3h0 4c0 5s0 6c0 7s0/9c0 9s0 Kh0 Kc0 Ks0",
            "win": 0.4,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:05:31",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000127-1": [
        {
            "inFantasy": true,
            "result": 22,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "Js0 7h0 9h0",
            "rows": "Kh0 Ks0 Ah0/2d0 5d0 6d0 7d0 8d0/2c0 4c0 8c0 9c0 Jc0",
            "win": 4.3,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": -22,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "Th1 6h2 7c3 9s4",
            "rows": "Kd0 8h2 Qs4/4h0 Ad0 5h1 3d2 Qh4/2s0 8s0 4s1 6s3 Ts3",
            "win": -4.4,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:06:07",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000128-1": [
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid1793219",
            "orderIndex": 0,
            "hero": false,
            "dead": "9s1 3d2 8c3 5c4",
            "rows": "As0 Ah2 Qd3/4s0 2s1 6c1 3c3 6h4/Jc0 Js0 Kh0 Td2 Jd4",
            "win": -4,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": false,
            "result": 28,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "2d1 Jh2 2h3 9c4",
            "rows": "Ks0 Kc1 Ad4/2c0 5d0 3h2 3s2 5s3/8s0 Qs0 8h1 4c3 4h4",
            "win": 5.4,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid2923305",
            "orderIndex": 2,
            "hero": false,
            "dead": "Ts1 7c2 Tc3 6s4",
            "rows": "Kd1 Ac2 Qc3/6d0 7d0 7s0 4d3 8d4/9h0 Qh0 5h1 Th2 9d4",
            "win": -1.6,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:08:05",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000129-1": [
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid1793219",
            "orderIndex": 2,
            "hero": false,
            "dead": "Qd1 8c2 2s3 4d4",
            "rows": "Ah2 Tc4 Kd4/5h0 5c0 8d2 8h3 9h3/4s0 Js0 Qs0 3s1 6s1",
            "win": -3.6,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": true,
            "result": 60,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "8s0 4c0",
            "rows": "Kh0 Ks0 Ad0/2h0 2d0 2c0 3h0 3d0/7h0 7c0 7s0 9d0 9c0",
            "win": 11.6,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": -42,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qc1 3c2 6h3 7d4",
            "rows": "Qh2 As3 9s4/6c0 Ts0 6d1 Th1 Td2/Jh0 Jd0 Jc0 4h3 5s4",
            "win": -8.4,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:09:05",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000130-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid1793219",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jc1 7s2 5d3 3c4",
            "rows": "Ah2 Jh3 Ad3/3d0 4h0 6h1 4s2 3s4/7d0 9c0 Ts0 Jd1 Td4",
            "win": 0,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5689062",
            "orderIndex": 2,
            "hero": true,
            "dead": "2c1 Tc2 2d3 Js4",
            "rows": "Kh0 As1 Th4/4d0 4c0 6c0 6s2 2h3/Qh0 5c1 5s2 9s3 8s4",
            "win": 0,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qs1 9d2 9h3 Ks4",
            "rows": "Kd0 Ac1 Kc2/2s0 3h0 5h1 6d3 Qd4/7h0 8c0 7c2 8h3 Qc4",
            "win": 0,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:11:01",
    "roomId": "21947173"
}


