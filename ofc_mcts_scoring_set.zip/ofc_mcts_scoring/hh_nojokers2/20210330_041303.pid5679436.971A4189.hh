{
    "stakes": 5,
    "handData": {"210330064858-21916719-0000000-1": [
        {
            "inFantasy": false,
            "result": 17,
            "playerName": "pid742728",
            "orderIndex": 1,
            "hero": false,
            "dead": "2c1 4d2 8s3 3h4",
            "rows": "Qd0 As0 Ah2/8c0 Td1 Tc1 Ts3 5c4/Kc0 Ks0 Kd2 Jc3 9d4",
            "win": 82,
            "playerId": "pid742728"
        },
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid5679436",
            "orderIndex": 0,
            "hero": true,
            "dead": "Js1 9s2 4h3 7s4",
            "rows": "Jd1 8h3 7c4/4c0 6d0 3c2 5h2 7h3/2h0 Qh0 Qs0 2s1 5s4",
            "win": -85,
            "playerId": "pid5679436"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:13:03",
    "roomId": "21916719"
}


{
    "stakes": 5,
    "handData": {"210330064858-21916719-0000001-1": [
        {
            "inFantasy": true,
            "result": 20,
            "playerName": "pid742728",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qd0 Th1 5d2",
            "rows": "9c0 9s0 As0/3h0 4c0 5h0 6c0 7s0/2c0 2s0 Jh0 Jd0 Jc0",
            "win": 97,
            "playerId": "pid742728"
        },
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid5679436",
            "orderIndex": 1,
            "hero": true,
            "dead": "2d1 7h2 7c3 Kh4",
            "rows": "Qs0 Qc2 Ac3/Kc0 Ks0 4s1 Qh2 5c3/6s0 8c0 6h1 4d4 Tc4",
            "win": -100,
            "playerId": "pid5679436"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:13:46",
    "roomId": "21916719"
}


{
    "stakes": 5,
    "handData": {"210330064858-21916719-0000002-1": [
        {
            "inFantasy": false,
            "result": 16,
            "playerName": "pid742728",
            "orderIndex": 1,
            "hero": false,
            "dead": "7h1 6h2 Js3 Ks4",
            "rows": "Ah0 Kh1 2c4/4c0 2d1 5h2 Td3 Th4/5s0 8s0 9s0 6s2 7s3",
            "win": 63,
            "playerId": "pid742728"
        },
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid5679436",
            "orderIndex": 0,
            "hero": true,
            "dead": "7c1 4s2 4h3 2h4",
            "rows": "Ad0 Qh2 Kc4/3h0 6c0 3c2 2s3 8h3/9h0 Jd0 Qc1 Kd1 Qd4",
            "win": -65,
            "playerId": "pid5679436"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:14:45",
    "roomId": "21916719"
}


{
    "stakes": 5,
    "handData": {"210330064858-21916719-0000003-1": [
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid742728",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jc1 8s2 Qs3 9s4",
            "rows": "As1 Kh2 Kc2/4h0 5d0 3s1 4s3 Ad4/7d0 Td0 Tc0 7h3 7s4",
            "win": -70,
            "playerId": "pid742728"
        },
        {
            "inFantasy": false,
            "result": 14,
            "playerName": "pid5679436",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ts1 5s2 3h3 7c4",
            "rows": "Kd0 Ac1 Ks2/4c0 9d0 2c1 2d3 9c3/Jh0 Js0 6d2 6c4 9h4",
            "win": 68,
            "playerId": "pid5679436"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:15:35",
    "roomId": "21916719"
}


{
    "stakes": 5,
    "handData": {"210330064858-21916719-0000004-1": [
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid742728",
            "orderIndex": 0,
            "hero": false,
            "dead": "5s1 7d2 2s3 4h4",
            "rows": "Kh0 Ah0 Ad1/6d0 6s1 4c2 4s2 Kc3/9c0 Jc0 9h3 6h4 8s4",
            "win": -90,
            "playerId": "pid742728"
        },
        {
            "inFantasy": true,
            "result": 18,
            "playerName": "pid5679436",
            "orderIndex": 1,
            "hero": true,
            "dead": "3d0 2h0",
            "rows": "Jh0 Qd0 As0/6c0 7h0 8h0 8d0 8c0/4d0 Th0 Td0 Tc0 Ts0",
            "win": 87,
            "playerId": "pid5679436"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:16:14",
    "roomId": "21916719"
}


{
    "stakes": 5,
    "handData": {"210330064858-21916719-0000005-1": [
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid742728",
            "orderIndex": 1,
            "hero": false,
            "dead": "5d1 2d2 8d3 4c4",
            "rows": "Kd0 Ks2 Ad3/2c0 4d0 2h1 4h2 6d4/Js0 Qc0 Jd1 Qs3 7c4",
            "win": -85,
            "playerId": "pid742728"
        },
        {
            "inFantasy": true,
            "result": 17,
            "playerName": "pid5679436",
            "orderIndex": 0,
            "hero": true,
            "dead": "7s0 Ac0",
            "rows": "3h0 3c0 3s0/5c0 6c0 7h0 8c0 9d0/8h0 9h0 Th0 Qh0 Ah0",
            "win": 82,
            "playerId": "pid5679436"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:16:43",
    "roomId": "21916719"
}


{
    "stakes": 5,
    "handData": {"210330064858-21916719-0000006-1": [
        {
            "inFantasy": true,
            "result": 8,
            "playerName": "pid742728",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qs0 Tc1",
            "rows": "7h0 7d0 7s0/2s0 3h0 4h0 5c0 6s0/2h0 6h0 Jh0 Qh0 Kh0",
            "win": 39,
            "playerId": "pid742728"
        },
        {
            "inFantasy": true,
            "result": -8,
            "playerName": "pid5679436",
            "orderIndex": 1,
            "hero": true,
            "dead": "4d0 2c0",
            "rows": "6c0 Qd0 Ac0/3s0 4s0 8s0 Ks0 As0/9d0 9c0 9s0 Th0 Td0",
            "win": -40,
            "playerId": "pid5679436"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:17:09",
    "roomId": "21916719"
}


{
    "stakes": 5,
    "handData": {"210330064858-21916719-0000007-1": [
        {
            "inFantasy": true,
            "result": 25,
            "playerName": "pid742728",
            "orderIndex": 1,
            "hero": false,
            "dead": "3c0 6d1",
            "rows": "9h0 Ah0 As0/6c0 7s0 8d0 9s0 Ts0/2d0 2s0 Jh0 Jd0 Jc0",
            "win": 121,
            "playerId": "pid742728"
        },
        {
            "inFantasy": false,
            "result": -25,
            "playerName": "pid5679436",
            "orderIndex": 0,
            "hero": true,
            "dead": "3d1 6s2 3s3 Kc4",
            "rows": "Ad2 4c3 Qc4/4d0 4s0 9d0 9c1 3h3/8s0 Js0 8h1 Tc2 5d4",
            "win": -125,
            "playerId": "pid5679436"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:18:01",
    "roomId": "21916719"
}


