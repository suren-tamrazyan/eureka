{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000000-1": [
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid5086566",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jd1 Jc2 Js3 3c4",
            "rows": "7s2 4s3 Ts3/6d0 2d1 8d1 9d2 2h4/7h0 9h0 Jh0 Qh0 Kh4",
            "win": 1.9,
            "playerId": "pid5086566"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "Td1 9s2 Th3 8h4",
            "rows": "Ad0 As2 Kc3/5s0 8s2 6s3 3s4 7c4/2c0 8c0 Qc0 6c1 9c1",
            "win": -2,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:40:05",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000001-1": [
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid5086566",
            "orderIndex": 0,
            "hero": false,
            "dead": "Tc1 Ks2 7c3 6s4",
            "rows": "Ac1 Ts4 Qh4/4c0 5d0 4d1 4h3 7s3/6h0 Th0 Ah0 2h2 3h2",
            "win": 0.2,
            "playerId": "pid5086566"
        },
        {
            "inFantasy": false,
            "result": -1,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "Kc1 3s2 3d3 Jh4",
            "rows": "Td2 Jd3 Qs4/4s0 7h0 8c2 Ad3 8h4/9c0 9s0 Js0 9d1 Jc1",
            "win": -0.2,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:41:14",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000002-1": [
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid5086566",
            "orderIndex": 1,
            "hero": false,
            "dead": "9c1 8h2 5h3 4h4",
            "rows": "Ks0 Kd2 6h4/2s0 Ah0 Qh3 Qd3 2c4/Ts0 Jd0 7d1 7c1 7s2",
            "win": 1,
            "playerId": "pid5086566"
        },
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "4c1 7h2 6s3 3s4",
            "rows": "5c3 5s3 As4/9h0 Jc0 3h1 Js2 9d4/3d0 4d0 8d0 Td1 5d2",
            "win": -1,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:41:59",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000003-1": [
        {
            "inFantasy": true,
            "result": 2,
            "playerName": "pid5086566",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jc0 6d1",
            "rows": "Qh0 Kd0 Ad0/4c0 5c0 6h0 7h0 8c0/3h0 3s0 9d0 9c0 9s0",
            "win": 0.4,
            "playerId": "pid5086566"
        },
        {
            "inFantasy": false,
            "result": -2,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "4h1 Ts2 9h3 Tc4",
            "rows": "Ac0 Qs3 As4/2c0 2s0 7d2 7s2 Th3/Jd0 Ks0 Jh1 Kc1 Qd4",
            "win": -0.4,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:42:45",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000004-1": [
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "pid5086566",
            "orderIndex": 1,
            "hero": false,
            "dead": "7h1 5c2 8h3 9c4",
            "rows": "Qh0 Kd0 Qs3/2c0 Ac0 3h1 3s3 Ts4/Js0 Jd1 5d2 Jc2 4h4",
            "win": -4.2,
            "playerId": "pid5086566"
        },
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "3c0 Tc0 Jh0",
            "rows": "Kh0 Ah0 As0/6d0 6c0 7d0 7s0 Qd0/5h0 5s0 8d0 8c0 8s0",
            "win": 4.1,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:43:23",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000005-1": [
        {
            "inFantasy": false,
            "result": -13,
            "playerName": "pid5086566",
            "orderIndex": 0,
            "hero": false,
            "dead": "Td1 3d2 Ts3 4d4",
            "rows": "3s1 Ac2 Qd3/4c0 8d0 7s1 7h4 Ah4/5h0 5s0 9s0 6s2 6c3",
            "win": -2.6,
            "playerId": "pid5086566"
        },
        {
            "inFantasy": false,
            "result": 13,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "5c1 Tc2 3c3 6h4",
            "rows": "Qh0 Qc1 Th2/5d0 As0 7c3 Kh4 Ks4/Jh0 Js0 9c1 Jc2 Qs3",
            "win": 2.5,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:44:37",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000006-1": [
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid5086566",
            "orderIndex": 1,
            "hero": false,
            "dead": "3c1 5s2 3h3 2s4",
            "rows": "Ac2 6h3 Kc3/8s0 Tc0 8d1 Jc2 Qh4/2d0 4d0 7d0 6d1 7c4",
            "win": -3,
            "playerId": "pid5086566"
        },
        {
            "inFantasy": true,
            "result": 15,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "2c0",
            "rows": "Td0 Ah0 As0/3d0 9c0 9s0 Qc0 Qs0/4s0 Jh0 Jd0 Kh0 Ks0",
            "win": 2.9,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:45:08",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000007-1": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid5086566",
            "orderIndex": 0,
            "hero": false,
            "dead": "As1 6d2 Ts3 3s4",
            "rows": "Ac0 Kc2 9s4/5h0 8s0 5d1 4c3 4s3/7d0 Qd0 7s1 Qs2 Qc4",
            "win": 2.3,
            "playerId": "pid5086566"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "Th1 Kd2 Td3 Ad4",
            "rows": "Kh0 Ks1 Jd4/6s0 4d2 2h3 2d3 9d4/7c0 8c0 Tc0 Jc1 9h2",
            "win": -2.4,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:46:20",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000008-1": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "pid5086566",
            "orderIndex": 1,
            "hero": false,
            "dead": "Ts1 Th2 3s3 2d4",
            "rows": "As0 Ac1 5c3/2c0 7s0 6h1 7c3 6d4/4d0 4s0 4h2 9c2 Ad4",
            "win": 2.9,
            "playerId": "pid5086566"
        },
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qh1 Jh2 3d3 Jd4",
            "rows": "Ks0 Kd1 7d3/5s0 6c0 Qd2 Qs2 4c4/8c0 9d0 Js1 7h3 3h4",
            "win": -3,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:47:12",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000009-1": [
        {
            "inFantasy": true,
            "result": 18,
            "playerName": "pid5086566",
            "orderIndex": 0,
            "hero": false,
            "dead": "2c0 5d1 5s2",
            "rows": "Qh0 Kh0 Ks0/6h0 6d0 Th0 Jd0 Js0/3c0 7c0 9c0 Qc0 Ac0",
            "win": 3.5,
            "playerId": "pid5086566"
        },
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "3s1 3h2 7h3 8d4",
            "rows": "Ah0 As2 8c3/2d0 4h0 4c1 5h2 8h4/Jc0 Qs0 Kd1 Jh3 2h4",
            "win": -3.6,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:47:59",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000010-1": [
        {
            "inFantasy": false,
            "result": 4,
            "playerName": "pid5086566",
            "orderIndex": 1,
            "hero": false,
            "dead": "9s1 Ad2 3c3 Kc4",
            "rows": "Ac0 7s3 Ah4/3s0 7c0 4c2 4s2 3d3/6h0 Qh0 5h1 8h1 2h4",
            "win": 0.8,
            "playerId": "pid5086566"
        },
        {
            "inFantasy": false,
            "result": -4,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "3h1 7d2 2s3 2c4",
            "rows": "Kh0 9c4 Jc4/6c0 8s0 Jh2 Jd2 Js3/Qc0 Qs0 Td1 Ts1 Tc3",
            "win": -0.8,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:48:54",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000011-1": [
        {
            "inFantasy": true,
            "result": 14,
            "playerName": "pid5086566",
            "orderIndex": 0,
            "hero": false,
            "dead": "3d0 7d1 2d2",
            "rows": "5d0 5c0 Qh0/6c0 7h0 8c0 9d0 Th0/3s0 4s0 Js0 Qs0 As0",
            "win": 2.7,
            "playerId": "pid5086566"
        },
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "5h1 9h2 2s3 Kc4",
            "rows": "Ac0 Ah2 Kd4/4d0 4c0 6h1 6d2 5s3/9s0 Jd0 8h1 8d3 4h4",
            "win": -2.8,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:49:41",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000012-1": [
        {
            "inFantasy": false,
            "result": 19,
            "playerName": "pid5086566",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qs1 Jh2 7d3 7s4",
            "rows": "Kh0 Qc3 Qd4/2s0 Ad0 6c2 6d3 2c4/8h0 8s0 Tc1 Ts1 Th2",
            "win": 3.7,
            "playerId": "pid5086566"
        },
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "9h1 5c2 Qh3 Td4",
            "rows": "Kc0 Ac2 As3/3h0 3s0 5h0 5d1 6h3/8d0 Jd1 9c2 2h4 3c4",
            "win": -3.8,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:50:34",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000013-1": [
        {
            "inFantasy": true,
            "result": 9,
            "playerName": "pid5086566",
            "orderIndex": 0,
            "hero": false,
            "dead": "6h0",
            "rows": "Jd0 Ad0 Ac0/3d0 3s0 5d0 5s0 9c0/8c0 9h0 Ts0 Jh0 Qd0",
            "win": 1.7,
            "playerId": "pid5086566"
        },
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "8d1 2c2 4d3 Jc4",
            "rows": "Kd0 Ks1 Qc2/Js0 As0 4s2 2d4 Ah4/6c0 Tc0 Th1 3h3 3c3",
            "win": -1.8,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:51:21",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000014-1": [
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "pid5086566",
            "orderIndex": 1,
            "hero": false,
            "dead": "3d1 Js2 Jc3 3c4",
            "rows": "Qs3 9d4 Jd4/2d0 4d0 5s0 4s1 2c3/6h0 6d0 8c1 9h2 9c2",
            "win": -4.2,
            "playerId": "pid5086566"
        },
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h0 5d0",
            "rows": "Qd0 Ah0 Ac0/7h0 8h0 8s0 Td0 Ts0/6c0 6s0 Kh0 Kd0 Ks0",
            "win": 4.1,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:51:55",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000015-1": [
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5086566",
            "orderIndex": 0,
            "hero": false,
            "dead": "3c1 9h2 2d3 Ts4",
            "rows": "Ks1 4d4 4c4/2h0 6h0 6c1 6s2 4h3/3d0 Td0 Kd0 Jd2 6d3",
            "win": -2,
            "playerId": "pid5086566"
        },
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jc1 Th2 4s3 8c4",
            "rows": "Ad0 Ac2 Jh3/2c0 2s0 3s0 7s2 3h4/9c0 Qd1 Qs1 9s3 Qh4",
            "win": 1.9,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:52:52",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000016-1": [
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid5086566",
            "orderIndex": 1,
            "hero": false,
            "dead": "6s1 2h2 Js3 6c4",
            "rows": "2d1 2c3 8s4/Th0 6h2 7h2 8h3 Jh4/4c0 5c0 8c0 Kc0 Qc1",
            "win": 0.2,
            "playerId": "pid5086566"
        },
        {
            "inFantasy": true,
            "result": -1,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "7c0 6d0 3c0",
            "rows": "9h0 9c0 Tc0/Td0 Jc0 Qd0 Kh0 Ad0/2s0 3s0 4s0 Qs0 Ks0",
            "win": -0.2,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:53:26",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000017-1": [
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid5086566",
            "orderIndex": 0,
            "hero": false,
            "dead": "4h1 Kd2 5d3 8c4",
            "rows": "Ac0 8s3 Tc4/3c0 5c0 2h2 4c2 Th4/Js0 Qs0 8d1 9h1 Ts3",
            "win": -3,
            "playerId": "pid5086566"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "9c1 3s2 2c3 7d4",
            "rows": "Ad0 Kh2 Ah4/5h0 5s0 4d1 4s2 6s4/7h0 7s0 6d1 3h3 3d3",
            "win": 2.9,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:54:24",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000018-1": [
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid5086566",
            "orderIndex": 1,
            "hero": false,
            "dead": "Ts1 Js2 4h3 5d4",
            "rows": "As0 Jc1 Ad2/2s0 3c0 7c1 2h2 7d3/6h0 Qh0 9h3 4c4 8s4",
            "win": -3.4,
            "playerId": "pid5086566"
        },
        {
            "inFantasy": true,
            "result": 17,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "5c0 7s0 Jh0",
            "rows": "8h0 8c0 Qs0/2c0 3s0 4s0 5h0 Ah0/3d0 8d0 Td0 Qd0 Kd0",
            "win": 3.3,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:54:56",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000019-1": [
        {
            "inFantasy": false,
            "result": -7,
            "playerName": "pid5086566",
            "orderIndex": 0,
            "hero": false,
            "dead": "2c1 Td2 7d3 2d4",
            "rows": "Ad0 Kc3 Jh4/3d0 4s0 3h2 Qh3 Ah4/8d0 Tc0 6d1 7c1 9c2",
            "win": -1.4,
            "playerId": "pid5086566"
        },
        {
            "inFantasy": false,
            "result": 7,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "9s1 Jd2 5d3 9d4",
            "rows": "Qs2 7h3 Kd4/4c0 2s1 5c1 3s3 Ac4/2h0 5h0 9h0 Kh0 8h2",
            "win": 1.4,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:56:07",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000020-1": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "pid5086566",
            "orderIndex": 1,
            "hero": false,
            "dead": "9h1 Kd2 3s3 4d4",
            "rows": "Qd0 Ah1 As4/5h0 5d1 4c2 7c2 4h4/8d0 8s0 Tc0 8h3 9s3",
            "win": 2.9,
            "playerId": "pid5086566"
        },
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "6c1 5s2 Js3 Ks4",
            "rows": "Kc0 Ac2 4s3/7h0 3h1 9c2 5c4 6h4/2h0 2s0 Qc0 2d1 Qs3",
            "win": -3,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:57:03",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000021-1": [
        {
            "inFantasy": true,
            "result": 22,
            "playerName": "pid5086566",
            "orderIndex": 0,
            "hero": false,
            "dead": "8d0 Qc1 As2",
            "rows": "2h0 2c0 2s0/6d0 7c0 8s0 9s0 Ts0/3h0 5h0 8h0 Jh0 Qh0",
            "win": 4.3,
            "playerId": "pid5086566"
        },
        {
            "inFantasy": false,
            "result": -22,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "9c1 7d2 4s3 5c4",
            "rows": "Jc3 Kd3 Qs4/2d0 Tc0 9d1 Th2 Kh4/5s0 6h0 7h0 4h1 3s2",
            "win": -4.4,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:58:14",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000022-1": [
        {
            "inFantasy": true,
            "result": 16,
            "playerName": "pid5086566",
            "orderIndex": 1,
            "hero": false,
            "dead": "2c0 Qc1 5c2",
            "rows": "Kh0 Kd0 As0/4c0 5h0 6s0 7c0 8s0/3d0 4d0 5d0 8d0 Jd0",
            "win": 3.1,
            "playerId": "pid5086566"
        },
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "6d1 Ts2 Tc3 Ks4",
            "rows": "Qd1 Js3 Ac4/7s0 9s0 9h2 Jc2 9d3/2h0 3h0 6h0 4h1 8h4",
            "win": -3.2,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:59:01",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000023-1": [
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5086566",
            "orderIndex": 1,
            "hero": false,
            "dead": "8c1 3s2 Kc3 6d4",
            "rows": "Ks1 Kh2 Qs3/2h0 4c0 2d2 4s3 5d4/7h0 Td0 Tc0 7d1 5s4",
            "win": -2,
            "playerId": "pid5086566"
        },
        {
            "inFantasy": false,
            "result": 36,
            "playerName": "pid5689062",
            "orderIndex": 2,
            "hero": true,
            "dead": "Th1 3h2 5h3 As4",
            "rows": "Ad0 Js3 Ah4/2c0 6s0 8s1 6c2 6h4/9h0 Qc0 9s1 9c2 Qd3",
            "win": 7,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": -26,
            "playerName": "pid5353395",
            "orderIndex": 0,
            "hero": false,
            "dead": "2s1 5c2 7s3 Jd4",
            "rows": "Kd0 Ac3 Jh4/3d0 3c0 4h0 Qh3 4d4/7c0 8d1 9d1 Ts2 Jc2",
            "win": -5.2,
            "playerId": "pid5353395"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 11:00:19",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000024-1": [
        {
            "inFantasy": true,
            "result": 31,
            "playerName": "pid5086566",
            "orderIndex": 0,
            "hero": false,
            "dead": "9c0 Qd1",
            "rows": "Th0 Td0 Ts0/3s0 4c0 5s0 6s0 7d0/8h0 8c0 8s0 Jh0 Jc0",
            "win": 6,
            "playerId": "pid5086566"
        },
        {
            "inFantasy": true,
            "result": 4,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "7c0 3c0 Ks0",
            "rows": "Kc0 Ah0 Ad0/3h0 4h0 5h0 6h0 9h0/5d0 6d0 8d0 9d0 Jd0",
            "win": 0.8,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": -35,
            "playerName": "pid5353395",
            "orderIndex": 2,
            "hero": false,
            "dead": "Js1 3d2 2d3 7h4",
            "rows": "As0 Ac2 Kh4/2h0 2c1 5c1 7s2 2s3/9s0 Qc0 Qs0 Qh3 Kd4",
            "win": -7,
            "playerId": "pid5353395"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 11:01:06",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000025-1": [
        {
            "inFantasy": true,
            "result": 61,
            "playerName": "pid5086566",
            "orderIndex": 2,
            "hero": false,
            "dead": "Qc0 2h1",
            "rows": "9h0 9d0 9c0/3d0 4d0 8d0 Qd0 Ad0/5h0 5d0 5c0 5s0 Ac0",
            "win": 11.8,
            "playerId": "pid5086566"
        },
        {
            "inFantasy": false,
            "result": -63,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "Td1 8h2 2s3 8s4",
            "rows": "Qh2 Qs2 6h4/7d0 7c1 Jh1 3h3 4s4/4c0 6c0 8c0 Tc0 Jc3",
            "win": -12.6,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": true,
            "result": 2,
            "playerName": "pid5353395",
            "orderIndex": 1,
            "hero": false,
            "dead": "4h0 7h1 3c2",
            "rows": "Jd0 Js0 Ah0/2d0 2c0 6d0 6s0 Ts0/9s0 Kh0 Kd0 Kc0 Ks0",
            "win": 0.4,
            "playerId": "pid5353395"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 11:02:02",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000026-1": [
        {
            "inFantasy": true,
            "result": -2,
            "playerName": "pid5086566",
            "orderIndex": 1,
            "hero": false,
            "dead": "6c0 3c1",
            "rows": "9d0 Jd0 Jc0/5c0 5s0 8d0 Td0 Ts0/2h0 3h0 Jh0 Qh0 Kh0",
            "win": -0.4,
            "playerId": "pid5086566"
        },
        {
            "inFantasy": false,
            "result": -49,
            "playerName": "pid5689062",
            "orderIndex": 2,
            "hero": true,
            "dead": "2d1 9h2 6s3 Kd4",
            "rows": "Ad0 Ah2 Js4/7h0 7c0 3s1 8s1 9c4/Qd0 Kc0 Qc2 Ac3 As3",
            "win": -5.7,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": true,
            "result": 51,
            "playerName": "pid5353395",
            "orderIndex": 0,
            "hero": false,
            "dead": "7s0 2c1 9s2",
            "rows": "Tc0 Qs0 Ks0/4h0 4c0 4s0 8h0 8c0/3d0 4d0 5d0 6d0 7d0",
            "win": 5.9,
            "playerId": "pid5353395"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 11:03:16",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000027-1": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "pid5086566",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jc1 7s2 9d3 3c4",
            "rows": "Qs0 Qc2 Jh4/3s0 As1 Kh2 Ad3 Ac4/4d0 6d0 Kd0 3d1 Qd3",
            "win": -0.6,
            "playerId": "pid5086566"
        },
        {
            "inFantasy": true,
            "result": 3,
            "playerName": "pid5353395",
            "orderIndex": 1,
            "hero": false,
            "dead": "6c0 8d1 Qh2",
            "rows": "Th0 Tc0 Ks0/4s0 5d0 6s0 7h0 8h0/2h0 2s0 9h0 9c0 9s0",
            "win": 0.6,
            "playerId": "pid5353395"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": false,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 11:03:48",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000028-1": [
        {
            "inFantasy": true,
            "result": 20,
            "playerName": "pid5086566",
            "orderIndex": 1,
            "hero": false,
            "dead": "4c0",
            "rows": "5h0 9s0 Ah0/7d0 8d0 9d0 Jd0 Qd0/6h0 6d0 6s0 Th0 Ts0",
            "win": 3.9,
            "playerId": "pid5086566"
        },
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid5353395",
            "orderIndex": 0,
            "hero": false,
            "dead": "4h1 2s2 2c3 2h4",
            "rows": "Ad0 4d2 Kh4/3c0 5d0 7h0 5s1 3s2/Qs0 Tc1 3h3 3d3 8s4",
            "win": -4,
            "playerId": "pid5353395"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": false,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 11:04:24",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000029-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "2c1 3d2 Ac3 Ks4",
            "rows": "Ah0 Ad1 Qc3/9c0 6s1 5h2 3s4 Th4/Jd0 Js0 Kh0 Td2 Ts3",
            "win": -1.2,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5353395",
            "orderIndex": 1,
            "hero": false,
            "dead": "6c1 5d2 7h3 2s4",
            "rows": "As0 6h3 7d3/2d0 3c1 4s1 3h2 8c4/9s0 Jh0 Qd0 9d2 4d4",
            "win": 1.2,
            "playerId": "pid5353395"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 11:05:08",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000030-1": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "9c1 3c2 3h3 Th4",
            "rows": "Qh0 8h2 Tc3/4c0 Kc0 7h1 Kd2 2h3/5s0 9s0 4s1 4d4 5h4",
            "win": 1.2,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5353395",
            "orderIndex": 0,
            "hero": false,
            "dead": "7s1 4h2 7c3 3s4",
            "rows": "As0 Ad1 8c3/2c0 5c0 6d0 6c3 2d4/9h0 Jc1 8d2 Qs2 5d4",
            "win": -1.2,
            "playerId": "pid5353395"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 11:06:33",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000031-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "2d1 4h2 2s3 Qc4",
            "rows": "Kh0 Ah2 Ac2/5d0 5h1 7h1 6h4 Th4/9h0 9s0 Qs0 Kc3 Ks3",
            "win": -1.2,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5353395",
            "orderIndex": 1,
            "hero": false,
            "dead": "6s1 Qh2 2h3 4d4",
            "rows": "8h3 Jh3 Qd4/3c0 5s0 3h2 6d2 9c4/8c0 Tc0 Js0 8d1 Jd1",
            "win": 1.2,
            "playerId": "pid5353395"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 11:07:20",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000032-1": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "9c1 4h2 Jh3 2h4",
            "rows": "Kh0 3d3 7h3/7d0 5d1 8h1 6d2 Ks4/2s0 9s0 Qs0 3s2 Qc4",
            "win": 1.2,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5353395",
            "orderIndex": 0,
            "hero": false,
            "dead": "2d1 4d2 Th3 2c4",
            "rows": "Qh2 Qd2 Kd4/7s0 8c0 6h1 6c3 8s3/Td0 Tc0 Jd0 5s1 3h4",
            "win": -1.2,
            "playerId": "pid5353395"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 11:09:01",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000033-1": [
        {
            "inFantasy": false,
            "result": -2,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "7h1 2d2 2s3 3s4",
            "rows": "Ah1 9s3 3d4/5s1 8h2 8d2 4h3 7s4/9h0 Tc0 Js0 Qd0 Ks0",
            "win": -0.4,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": 2,
            "playerName": "pid5353395",
            "orderIndex": 1,
            "hero": false,
            "dead": "8s1 5h2 4c3 3c4",
            "rows": "Ad1 Qh3 4d4/3h0 7d0 6c1 7c2 6h4/9d0 Th0 Qs0 Kc2 Jh3",
            "win": 0.4,
            "playerId": "pid5353395"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 11:09:47",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000034-1": [
        {
            "inFantasy": false,
            "result": 14,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "3h1 6d2 5c3 9h4",
            "rows": "Ks0 Kd2 8d3/5h0 4d1 4c1 7c2 7h3/Th0 Tc0 Jc0 4h4 4s4",
            "win": 2.7,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid5353395",
            "orderIndex": 0,
            "hero": false,
            "dead": "Ac1 9d2 Js3 Kc4",
            "rows": "Ah0 Ad0 Qd4/6c0 6s0 5d1 2s2 Qc4/7s0 8s1 8c2 9c3 9s3",
            "win": -2.8,
            "playerId": "pid5353395"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 11:11:01",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000035-1": [
        {
            "inFantasy": true,
            "result": -4,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "8c0 3d0",
            "rows": "4d0 4s0 Qs0/7h0 7s0 Tc0 Jd0 Kh0/2c0 2s0 9h0 9d0 9c0",
            "win": -0.8,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": false,
            "result": 4,
            "playerName": "pid5353395",
            "orderIndex": 1,
            "hero": false,
            "dead": "2h1 6c2 As3 4h4",
            "rows": "Ah0 Ac2 8s4/5s0 6h0 6d0 5h1 7d4/Th0 Kc1 Jc2 Js3 Kd3",
            "win": 0.8,
            "playerId": "pid5353395"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 11:11:35",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000036-1": [
        {
            "inFantasy": false,
            "result": -13,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "6h1 Jh2 Kh3 9s4",
            "rows": "Kd0 Kc0 8c3/Ah1 7s2 7h3 2d4 2c4/9c0 Th0 Js0 8d1 Qd2",
            "win": -2.6,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": true,
            "result": 13,
            "playerName": "pid5353395",
            "orderIndex": 0,
            "hero": false,
            "dead": "4h0 6d1 7c2",
            "rows": "Ts0 Qc0 Ks0/2h0 2s0 5h0 5d0 5c0/3h0 3d0 3c0 3s0 8s0",
            "win": 2.5,
            "playerId": "pid5353395"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 11:12:33",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000037-1": [
        {
            "inFantasy": true,
            "result": -10,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "3c0 2c0",
            "rows": "Kd0 Ad0 Ac0/2h0 3h0 6h0 7h0 9h0/5d0 6d0 9d0 Td0 Jd0",
            "win": -2,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": true,
            "result": 10,
            "playerName": "pid5353395",
            "orderIndex": 1,
            "hero": false,
            "dead": "8d0 Th1 4d2",
            "rows": "Qh0 Qd0 Kh0/4s0 6s0 7s0 Qs0 As0/9c0 Tc0 Jc0 Qc0 Kc0",
            "win": 1.9,
            "playerId": "pid5353395"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 11:13:14",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000038-1": [
        {
            "inFantasy": false,
            "result": -29,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "6c1 6h2 Jc3 Tc4",
            "rows": "Kh0 Kd0 Jd3/4s0 5h1 3d2 2s3 6d4/9d0 Jh0 Qc1 Th2 4h4",
            "win": -5.8,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": true,
            "result": 29,
            "playerName": "pid5353395",
            "orderIndex": 0,
            "hero": false,
            "dead": "5d0 8c1 3h2",
            "rows": "9h0 9c0 9s0/2c0 3s0 4c0 5c0 6s0/Ts0 Js0 Qd0 Kc0 Ah0",
            "win": 5.6,
            "playerId": "pid5353395"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 11:13:57",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000039-1": [
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "5s1 8h2 9h3 3s4",
            "rows": "Ts1 As2 Qd4/3c0 Tc0 4c1 8c2 4d4/5d0 8d0 Kd0 9d3 Ad3",
            "win": -4,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": true,
            "result": 20,
            "playerName": "pid5353395",
            "orderIndex": 1,
            "hero": false,
            "dead": "2s0 6d1 4s2",
            "rows": "7d0 7c0 7s0/Td0 Jh0 Qs0 Kc0 Ac0/2h0 3h0 4h0 5h0 Qh0",
            "win": 3.9,
            "playerId": "pid5353395"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 11:14:39",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000040-1": [
        {
            "inFantasy": false,
            "result": -32,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "Td1 4h2 5c3 6c4",
            "rows": "Kc1 Kh2 Ad3/4d0 4c0 8s0 9s1 8d2/6h0 Jh0 Qh3 3c4 5s4",
            "win": -6.4,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": true,
            "result": 32,
            "playerName": "pid5353395",
            "orderIndex": 0,
            "hero": false,
            "dead": "9c0 3d1 Tc2",
            "rows": "Qd0 Qc0 Qs0/3s0 4s0 5h0 6d0 7d0/7h0 8h0 9h0 Ts0 Js0",
            "win": 6.2,
            "playerId": "pid5353395"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 11:15:26",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000041-1": [
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "6s1 7s2 7h3 Ad4",
            "rows": "Ac0 Ah2 Jd4/2h0 Qc0 6c1 Qd1 6d2/Kh0 Kc0 3s3 4d3 5c4",
            "win": -4,
            "playerId": "pid5689062"
        },
        {
            "inFantasy": true,
            "result": 20,
            "playerName": "pid5353395",
            "orderIndex": 1,
            "hero": false,
            "dead": "8s0 9h1 6h2",
            "rows": "Jc0 Qh0 As0/2d0 3d0 8d0 9d0 Kd0/4c0 4s0 Th0 Tc0 Ts0",
            "win": 3.9,
            "playerId": "pid5353395"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 11:16:23",
    "roomId": "21947173"
}


