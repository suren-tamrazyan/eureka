{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000088-1": [
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid5397550",
            "orderIndex": 1,
            "hero": false,
            "dead": "7d1 6d2 2d3 2h4",
            "rows": "9h2 Ad2 6h3/2s0 3s0 4s1 6s1 4c4/8c0 9c0 Kc0 Jc3 Ac4",
            "win": 1.9,
            "playerId": "pid5397550"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5359358",
            "orderIndex": 0,
            "hero": false,
            "dead": "7s1 6c2 3c3 3d4",
            "rows": "Tc2 7c3 As4/4h0 5d0 5c0 3h1 4d1/9s0 Qs0 5s2 Qh3 Jd4",
            "win": -2,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": false,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 17:21:51",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000089-1": [
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid5397550",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jc1 Th2 4s3 Kh4",
            "rows": "As0 7s2 Ac2/3h0 5c1 9c1 9d3 Qs4/5d0 6d0 Kd0 Qd3 3d4",
            "win": -3.6,
            "playerId": "pid5397550"
        },
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid5359358",
            "orderIndex": 2,
            "hero": false,
            "dead": "4d1 4c2 Kc3 8h4",
            "rows": "5s1 Ad2 Ts4/6h0 7d0 8c0 7h1 6s2/Td0 Js0 8s3 9h3 7c4",
            "win": 1,
            "playerId": "pid5359358"
        },
        {
            "inFantasy": false,
            "result": 13,
            "playerName": "pid5679065",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h1 9s2 3s3 5h4",
            "rows": "Qh0 8d3 Ah4/Jd0 Ks0 Jh1 4h2 2d4/3c0 6c0 2c1 Qc2 Tc3",
            "win": 2.5,
            "playerId": "pid5679065"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 17:22:56",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000090-1": [
        {
            "inFantasy": false,
            "result": -28,
            "playerName": "pid5397550",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jc1 2d2 Th3 8s4",
            "rows": "Qh0 Kc2 Ah4/Ac0 As1 Jd2 9h3 Tc3/3h0 4d0 5s0 4h1 2h4",
            "win": -5.6,
            "playerId": "pid5397550"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "pid5359358",
            "orderIndex": 1,
            "hero": false,
            "dead": "Js1 3c2 6s3 6h4",
            "rows": "Ks0 3d4 3s4/5h0 6d1 4s2 7d2 8h3/2c0 6c0 9c0 4c1 8c3",
            "win": 2.9,
            "playerId": "pid5359358"
        },
        {
            "inFantasy": false,
            "result": 13,
            "playerName": "pid5679065",
            "orderIndex": 2,
            "hero": true,
            "dead": "Qc1 Qd2 8d3 Qs4",
            "rows": "Kh0 Kd0 Ad3/5d0 9s1 5c2 2s3 9d4/7h0 Jh0 7c1 Td2 Ts4",
            "win": 2.5,
            "playerId": "pid5679065"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 17:24:16",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000091-1": [
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid5397550",
            "orderIndex": 2,
            "hero": false,
            "dead": "3s1 Ts2 Ac3 2h4",
            "rows": "Ks2 4d4 7h4/5h0 8c0 4h1 6c3 7d3/2d0 2c0 2s0 Js1 Jd2",
            "win": 1,
            "playerId": "pid5397550"
        },
        {
            "inFantasy": false,
            "result": -31,
            "playerName": "pid5359358",
            "orderIndex": 0,
            "hero": false,
            "dead": "9s1 Qd2 7s3 8d4",
            "rows": "Qs1 9d3 Jh4/3h0 3c1 5d2 5c2 6h3/9c0 Td0 Jc0 Qh0 8h4",
            "win": -6.2,
            "playerId": "pid5359358"
        },
        {
            "inFantasy": true,
            "result": 26,
            "playerName": "pid5679065",
            "orderIndex": 1,
            "hero": true,
            "dead": "5s0 7c0",
            "rows": "9h0 Th0 Qc0/4c0 4s0 Kh0 Kd0 Kc0/6d0 6s0 Ah0 Ad0 As0",
            "win": 5,
            "playerId": "pid5679065"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 17:25:20",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000092-1": [
        {
            "inFantasy": false,
            "result": 23,
            "playerName": "pid5397550",
            "orderIndex": 1,
            "hero": false,
            "dead": "8c1 9s2 4c3 5c4",
            "rows": "Th1 Kh3 Kd3/3c0 5h0 7c0 Ad4 Ac4/4d0 Jd0 Jh1 2d2 2c2",
            "win": 4.5,
            "playerId": "pid5397550"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "pid5359358",
            "orderIndex": 2,
            "hero": false,
            "dead": "4s1 As2 Qh3 6s4",
            "rows": "5d0 6d0 7s0/2h1 4h2 9d2 2s3 8h3/Td0 Js0 Ts1 Jc4 Ks4",
            "win": -0.6,
            "playerId": "pid5359358"
        },
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid5679065",
            "orderIndex": 0,
            "hero": true,
            "dead": "3d1 7d2 3s3 Qc4",
            "rows": "Qd0 6c3 Qs3/Kc0 8d1 5s2 8s4 Tc4/3h0 9h0 Ah0 7h1 6h2",
            "win": -4,
            "playerId": "pid5679065"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 17:27:04",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000093-1": [
        {
            "inFantasy": true,
            "result": 15,
            "playerName": "pid5397550",
            "orderIndex": 0,
            "hero": false,
            "dead": "9d0 8d1",
            "rows": "Qs0 Ah0 Ac0/4h0 6h0 7h0 9h0 Kh0/2c0 2s0 3h0 3c0 3s0",
            "win": 2.9,
            "playerId": "pid5397550"
        },
        {
            "inFantasy": false,
            "result": -38,
            "playerName": "pid5359358",
            "orderIndex": 1,
            "hero": false,
            "dead": "9c1 8h2 9s3 6c4",
            "rows": "Ad0 Kc1 Qd4/5h0 3d1 2d2 5d3 Kd4/Th0 Td0 Jd0 Js2 Jh3",
            "win": -7.6,
            "playerId": "pid5359358"
        },
        {
            "inFantasy": false,
            "result": 23,
            "playerName": "pid5679065",
            "orderIndex": 2,
            "hero": true,
            "dead": "2h1 Tc2 5s3 Ts4",
            "rows": "Qh0 Ks2 Qc3/4c0 6s0 6d1 4d3 4s4/7d0 7s0 8c1 8s2 7c4",
            "win": 4.5,
            "playerId": "pid5679065"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 17:28:06",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000094-1": [
        {
            "inFantasy": false,
            "result": -28,
            "playerName": "pid5397550",
            "orderIndex": 2,
            "hero": false,
            "dead": "4c1 Jc2 4h3 Kd4",
            "rows": "Ah0 Qh1 Qc2/2d0 5c0 6h0 2h2 Jd4/9s0 8d1 8h3 8s3 As4",
            "win": -5.6,
            "playerId": "pid5397550"
        },
        {
            "inFantasy": false,
            "result": -28,
            "playerName": "pid5359358",
            "orderIndex": 0,
            "hero": false,
            "dead": "8c1 7h2 2s3 3c4",
            "rows": "Ad0 Ac2 9h4/5s0 7s0 7c1 Jh3 9c4/4d0 9d0 6d1 3d2 Qd3",
            "win": -5.6,
            "playerId": "pid5359358"
        },
        {
            "inFantasy": true,
            "result": 56,
            "playerName": "pid5679065",
            "orderIndex": 1,
            "hero": true,
            "dead": "5h0",
            "rows": "7d0 Js0 Qs0/3h0 3s0 Kh0 Kc0 Ks0/6c0 Th0 Td0 Tc0 Ts0",
            "win": 10.9,
            "playerId": "pid5679065"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 17:29:01",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000095-1": [
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid5397550",
            "orderIndex": 1,
            "hero": false,
            "dead": "2h1 5c2 8d3 5h4",
            "rows": "Ad1 Kc3 9d4/3h0 4s0 3s1 6c2 6d3/Th0 Ts0 Js0 Td2 9h4",
            "win": -3.6,
            "playerId": "pid5397550"
        },
        {
            "inFantasy": false,
            "result": -30,
            "playerName": "pid5359358",
            "orderIndex": 2,
            "hero": false,
            "dead": "Tc1 4h2 4c3 3c4",
            "rows": "2s0 5d0 9s0/8s1 Ah1 Jd3 7h4 Jh4/Qd0 Ks0 7c2 As2 Ac3",
            "win": -5.4,
            "playerId": "pid5359358"
        },
        {
            "inFantasy": true,
            "result": 48,
            "playerName": "pid5679065",
            "orderIndex": 0,
            "hero": true,
            "dead": "6s0",
            "rows": "9c0 Kh0 Kd0/3d0 4d0 5s0 6h0 7s0/2d0 2c0 Qh0 Qc0 Qs0",
            "win": 8.7,
            "playerId": "pid5679065"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 17:29:42",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000096-1": [
        {
            "inFantasy": false,
            "result": 7,
            "playerName": "pid5397550",
            "orderIndex": 0,
            "hero": false,
            "dead": "9d1 3d2 Ad3 6d4",
            "rows": "Qc2 Qs2 2d3/6c0 7c1 4c3 4h4 4d4/5s0 7s0 Ts0 Js0 9s1",
            "win": 1.4,
            "playerId": "pid5397550"
        },
        {
            "inFantasy": false,
            "result": -7,
            "playerName": "pid5679065",
            "orderIndex": 1,
            "hero": true,
            "dead": "2s1 9h2 2h3 Ks4",
            "rows": "Qh0 As1 Qd3/4s0 8h0 3h2 Kc3 Kd4/Td0 Jd0 Th1 Tc2 Ac4",
            "win": -1.4,
            "playerId": "pid5679065"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 17:30:59",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000097-1": [
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "pid5397550",
            "orderIndex": 1,
            "hero": false,
            "dead": "3h0",
            "rows": "Th0 Tc0 Js0/2c0 3c0 4c0 9c0 Qc0/4d0 5d0 7d0 9d0 Kd0",
            "win": 1.2,
            "playerId": "pid5397550"
        },
        {
            "inFantasy": true,
            "result": -6,
            "playerName": "pid5679065",
            "orderIndex": 0,
            "hero": true,
            "dead": "4h0",
            "rows": "Qd0 Kh0 Kc0/8h0 Jc0 Ah0 Ad0 As0/5s0 6h0 7s0 8s0 9h0",
            "win": -1.2,
            "playerId": "pid5679065"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 17:31:38",
    "roomId": "21950775"
}


