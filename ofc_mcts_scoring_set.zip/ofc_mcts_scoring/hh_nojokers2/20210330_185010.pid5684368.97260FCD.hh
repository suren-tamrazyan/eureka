{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000000-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5359358",
            "orderIndex": 1,
            "hero": false,
            "dead": "7c1 2c2 Qh3 4s4",
            "rows": "Kc0 Th2 9d4/5h0 8d0 7d1 Ah2 4c4/3s0 Js0 7s1 2s3 Ts3",
            "win": -1.2,
            "playerId": "pid5359358"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5684368",
            "orderIndex": 0,
            "hero": true,
            "dead": "Kd1 Ks2 4d3 6h4",
            "rows": "Qd0 Ad1 Ac2/3d0 6s0 3c1 6c3 5d4/Tc0 Jc0 8s2 Jh3 Jd4",
            "win": 1.2,
            "playerId": "pid5684368"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 15:50:10",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000001-1": [
        {
            "inFantasy": false,
            "result": -28,
            "playerName": "pid5359358",
            "orderIndex": 0,
            "hero": false,
            "dead": "Kd1 Kc2 4c3 8h4",
            "rows": "Ah2 Qd3 Jd4/2c0 7d0 2s1 Td2 Th3/6s0 9s0 Ks0 Qs1 7s4",
            "win": -5.6,
            "playerId": "pid5359358"
        },
        {
            "inFantasy": true,
            "result": 28,
            "playerName": "pid5684368",
            "orderIndex": 1,
            "hero": true,
            "dead": "7h0 8d0 8s0",
            "rows": "Tc0 Qh0 Qc0/2h0 3d0 4s0 5d0 As0/5c0 6c0 7c0 8c0 9c0",
            "win": 5.4,
            "playerId": "pid5684368"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 15:50:45",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000002-1": [
        {
            "inFantasy": false,
            "result": -7,
            "playerName": "pid5359358",
            "orderIndex": 1,
            "hero": false,
            "dead": "4d1 6s2 8h3 7s4",
            "rows": "Kh0 Ks0 8d2/9c1 Jc1 3c2 3h4 Js4/Th0 Qh0 Qc0 5h3 Qs3",
            "win": -1.4,
            "playerId": "pid5359358"
        },
        {
            "inFantasy": true,
            "result": 7,
            "playerName": "pid5684368",
            "orderIndex": 0,
            "hero": true,
            "dead": "2d0 3s0 5s0",
            "rows": "Jd0 Kd0 Kc0/7h0 7c0 9h0 9s0 Ts0/6d0 6c0 Ah0 Ad0 As0",
            "win": 1.4,
            "playerId": "pid5684368"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 15:51:19",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000003-1": [
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "pid5359358",
            "orderIndex": 0,
            "hero": false,
            "dead": "7c0 4s1",
            "rows": "Kd0 Ah0 As0/3h0 Jd0 Jc0 Qh0 Qd0/6h0 6s0 9h0 9d0 9c0",
            "win": 4.1,
            "playerId": "pid5359358"
        },
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "pid5684368",
            "orderIndex": 1,
            "hero": true,
            "dead": "4c1 4d2 Kh3 Th4",
            "rows": "Ad0 Ac1 4h3/7h0 6d1 Ts2 2h4 2c4/Jh0 Js0 Qs0 8d2 8c3",
            "win": -4.2,
            "playerId": "pid5684368"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 15:52:10",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000004-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5359358",
            "orderIndex": 1,
            "hero": false,
            "dead": "4c1 Ac2 7c3 2h4",
            "rows": "Kh0 Ks2 Jd4/6c0 7h0 4d2 3c3 5c3/Jc0 Qs0 9d1 Tc1 9s4",
            "win": 0,
            "playerId": "pid5359358"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5684368",
            "orderIndex": 0,
            "hero": true,
            "dead": "5s1 Qd2 6d3 Kd4",
            "rows": "As0 3s3 Js3/3h0 3d0 2d1 8s1 2c2/4h0 9h0 Th2 6h4 Ts4",
            "win": 0,
            "playerId": "pid5684368"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 15:52:59",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000005-1": [
        {
            "inFantasy": false,
            "result": 13,
            "playerName": "pid5118808",
            "orderIndex": 0,
            "hero": false,
            "dead": "Kh1 Kc2 7d3 5d4",
            "rows": "Ah0 7c3 Tc4/4d0 6c0 8h1 4h2 Td4/Jd0 Qc0 Qh1 Jh2 Js3",
            "win": 2.5,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": -22,
            "playerName": "pid5359358",
            "orderIndex": 1,
            "hero": false,
            "dead": "5s1 Ac2 8d3 Qs4",
            "rows": "Ks0 Th3 Qd3/4s0 As0 3h1 3d1 5c4/7h0 9d0 8s2 Ts2 9h4",
            "win": -4.4,
            "playerId": "pid5359358"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "pid5684368",
            "orderIndex": 2,
            "hero": true,
            "dead": "Kd1 3c2 6h3 3s4",
            "rows": "9s3 Ad3 Jc4/2d0 2h1 2c2 4c2 6s4/5h0 6d0 7s0 9c0 8c1",
            "win": 1.7,
            "playerId": "pid5684368"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 15:54:21",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000006-1": [
        {
            "inFantasy": false,
            "result": 4,
            "playerName": "pid5118808",
            "orderIndex": 2,
            "hero": false,
            "dead": "5s1 5c2 4c3 2d4",
            "rows": "Ad1 Ks3 As3/5d0 6s0 6d1 5h2 8s4/9h0 Jd0 Js0 Jh2 4h4",
            "win": 0.8,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid5359358",
            "orderIndex": 0,
            "hero": false,
            "dead": "9c1 2c2 Kh3 3d4",
            "rows": "Kc0 Ah2 Qs4/3s0 7h1 3h3 3c3 Qh4/4d0 7d0 Qd0 9d1 Kd2",
            "win": -1.6,
            "playerId": "pid5359358"
        },
        {
            "inFantasy": false,
            "result": 4,
            "playerName": "pid5684368",
            "orderIndex": 1,
            "hero": true,
            "dead": "8d1 4s2 6h3 7c4",
            "rows": "2h1 2s2 9s4/Th0 Ts0 Td1 7s2 8h3/6c0 8c0 Jc0 Qc3 Ac4",
            "win": 0.8,
            "playerId": "pid5684368"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 15:55:39",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000007-1": [
        {
            "inFantasy": true,
            "result": 72,
            "playerName": "pid5118808",
            "orderIndex": 1,
            "hero": false,
            "dead": "Kd0 4h1 Js2",
            "rows": "Qh0 Qc0 Qs0/4s0 5h0 6c0 7s0 8h0/7h0 7d0 Td0 Tc0 Ts0",
            "win": 14,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": -36,
            "playerName": "pid5359358",
            "orderIndex": 2,
            "hero": false,
            "dead": "Ac1 6d2 9s3 3h4",
            "rows": "Ah0 Ad0 8d1/2s0 5d0 3s2 2d3 5c3/Jh0 9h1 7c2 3c4 8c4",
            "win": -7.2,
            "playerId": "pid5359358"
        },
        {
            "inFantasy": false,
            "result": -36,
            "playerName": "pid5684368",
            "orderIndex": 0,
            "hero": true,
            "dead": "As1 5s2 6s3 Kc4",
            "rows": "Kh0 Ks0 6h4/2c0 2h1 9d2 9c3 Th3/8s0 Jd0 Qd1 Jc2 4d4",
            "win": -7.2,
            "playerId": "pid5684368"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 15:56:37",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000008-1": [
        {
            "inFantasy": true,
            "result": 73,
            "playerName": "pid5118808",
            "orderIndex": 0,
            "hero": false,
            "dead": "6h0 9c1 3h2",
            "rows": "Kh0 Kd0 Kc0/2d0 3d0 8d0 Td0 Ad0/4h0 4c0 4s0 Qc0 Qs0",
            "win": 13.5,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid5359358",
            "orderIndex": 1,
            "hero": false,
            "dead": "6d1 8c2 9s3 2s4",
            "rows": "As0 Qd3 Ac4/3c0 5s0 7s0 5h1 7c1/Jd0 Ts2 Jh2 Js3 7d4",
            "win": -2.7,
            "playerId": "pid5359358"
        },
        {
            "inFantasy": false,
            "result": -56,
            "playerName": "pid5684368",
            "orderIndex": 2,
            "hero": true,
            "dead": "3s1 9d2 6c3 Ks4",
            "rows": "Ah2 8h3 6s4/2c0 5d0 2h1 5c1 Tc3/8s0 Th0 Jc0 9h2 4d4",
            "win": -11.2,
            "playerId": "pid5684368"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 15:57:40",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000009-1": [
        {
            "inFantasy": true,
            "result": 35,
            "playerName": "pid5118808",
            "orderIndex": 1,
            "hero": false,
            "dead": "Ts0 4h1 6s2",
            "rows": "Kh0 Kd0 Kc0/6d0 9d0 Td0 Jd0 Ad0/4c0 8c0 Jc0 Qc0 Ac0",
            "win": 6.8,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": -35,
            "playerName": "pid5684368",
            "orderIndex": 0,
            "hero": true,
            "dead": "4s1 5s2 2c3 5c4",
            "rows": "Th2 As3 Ks4/2h0 2d0 3h0 2s1 Jh4/9c0 Tc0 7h1 8s2 Js3",
            "win": -7,
            "playerId": "pid5684368"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 15:58:30",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000010-1": [
        {
            "inFantasy": true,
            "result": 23,
            "playerName": "pid5118808",
            "orderIndex": 0,
            "hero": false,
            "dead": "4s0 6h1 2s2",
            "rows": "Kh0 Ah0 Ad0/7h0 7c0 Jd0 Jc0 Qc0/5h0 5d0 5c0 5s0 9d0",
            "win": 0.9,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": -23,
            "playerName": "pid5684368",
            "orderIndex": 1,
            "hero": true,
            "dead": "8s1 Th2 Js3 8d4",
            "rows": "Kc0 Jh2 Qh4/3s0 As1 2h3 2d3 4h4/7d0 8c0 9c0 Tc1 6s2",
            "win": -0.9,
            "playerId": "pid5684368"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 15:59:21",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000011-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5359358",
            "orderIndex": 1,
            "hero": false,
            "dead": "Tc1 8c2 5h3 5c4",
            "rows": "Kd0 Kh1 Qh2/As0 3d1 4c2 3h3 3c3/6d0 6s0 Jc0 Qs4 Ks4",
            "win": 0,
            "playerId": "pid5359358"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5684368",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ts1 7c2 2s3 4d4",
            "rows": "Qd2 Ah3 3s4/2d0 7h0 7d1 9c1 2h2/5d0 5s0 Js0 9s3 2c4",
            "win": 0,
            "playerId": "pid5684368"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:00:14",
    "roomId": "21958502"
}


