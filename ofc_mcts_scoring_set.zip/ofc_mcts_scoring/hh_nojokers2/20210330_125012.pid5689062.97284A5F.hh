{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000083-1": [
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5359358",
            "orderIndex": 1,
            "hero": false,
            "dead": "2c1 8c2 7d3 4c4",
            "rows": "Kc0 6c1 Jc3/Td0 Ah0 3d1 Tc3 Ac4/4s0 7s0 6s2 Ts2 Qd4",
            "win": -2,
            "playerId": "pid5359358"
        },
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "6h1 2s2 Th3 9d4",
            "rows": "Kh3 Qc4 Ad4/4d0 8d1 Jd2 Js2 4h3/2h0 3h0 9h0 Qh0 5h1",
            "win": 1.9,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:50:12",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000084-1": [
        {
            "inFantasy": false,
            "result": 17,
            "playerName": "pid5359358",
            "orderIndex": 0,
            "hero": false,
            "dead": "7s1 As2 2h3 3c4",
            "rows": "Ah0 6c4 Ac4/6h0 9d0 Kh1 Ks1 9s3/8c0 Qc0 9c2 Jc2 Th3",
            "win": 3.3,
            "playerId": "pid5359358"
        },
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "3d1 5c2 5d3 Kc4",
            "rows": "7h2 Jh3 Ad3/2c0 8h0 Td0 8d1 2d2/3s0 5s0 Ts1 6s4 Jd4",
            "win": -3.4,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:51:29",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000085-1": [
        {
            "inFantasy": true,
            "result": 10,
            "playerName": "pid5359358",
            "orderIndex": 1,
            "hero": false,
            "dead": "Tc0 9d1 7d2",
            "rows": "Jd0 Qh0 Qs0/2h0 3c0 4h0 5c0 Ad0/2s0 4s0 8s0 Ts0 Js0",
            "win": 1.9,
            "playerId": "pid5359358"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "4d1 4c2 6d3 2d4",
            "rows": "Qd1 Ks2 6h4/8c0 Td0 7c1 7s2 7h4/5h0 9h0 Kh0 3h3 8h3",
            "win": -2,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:52:20",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000086-1": [
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5359358",
            "orderIndex": 0,
            "hero": false,
            "dead": "8c1 Kh2 2s3 2d4",
            "rows": "Ah0 As1 Kc4/3h0 7s0 3d2 5s2 Td4/Qh0 Qd0 Jh1 Tc3 Ts3",
            "win": -2,
            "playerId": "pid5359358"
        },
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "2c1 9s2 Js3 6c4",
            "rows": "4s2 9h2 4c4/3c0 4h0 2h1 6s1 6h4/5d0 7d0 Kd0 4d3 6d3",
            "win": 1.9,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:53:53",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000087-1": [
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid5359358",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jh1 6h2 3h3 4s4",
            "rows": "Ks0 Ac1 Qs3/2c0 8c0 Tc1 2d4 7h4/4d0 9d0 Td2 Kd2 8d3",
            "win": -3.8,
            "playerId": "pid5359358"
        },
        {
            "inFantasy": false,
            "result": 19,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "4h1 7d2 7s3 8s4",
            "rows": "Kc0 Ad2 Ah3/5h0 5c0 5s2 6d3 Th4/3d0 Jd0 Jc1 Js1 3s4",
            "win": 3.7,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:55:08",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000088-1": [
        {
            "inFantasy": false,
            "result": -34,
            "playerName": "pid5359358",
            "orderIndex": 0,
            "hero": false,
            "dead": "7s1 4s2 4h3 5d4",
            "rows": "Ks1 9h3 Th4/2h0 Td0 3s2 As3 Ts4/Jh0 Qh0 Qs0 Jd1 Jc2",
            "win": -6.8,
            "playerId": "pid5359358"
        },
        {
            "inFantasy": true,
            "result": 34,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "4c0 5s0 9s0",
            "rows": "8d0 8c0 8s0/3c0 9c0 Qc0 Kc0 Ac0/6h0 6d0 6c0 6s0 Ad0",
            "win": 6.6,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:55:49",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000089-1": [
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid5359358",
            "orderIndex": 1,
            "hero": false,
            "dead": "Kh1 3h2 Tc3 6h4",
            "rows": "Ac1 Kc2 As3/9h0 Qh0 7h1 9c2 9d4/7s0 9s0 Js0 Ks3 5c4",
            "win": -3.8,
            "playerId": "pid5359358"
        },
        {
            "inFantasy": true,
            "result": 19,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "2s0 3s0 8c0",
            "rows": "6c0 6s0 Qs0/2d0 4d0 7d0 Qd0 Kd0/2h0 4h0 8h0 Jh0 Ah0",
            "win": 3.7,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:56:26",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000090-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5359358",
            "orderIndex": 0,
            "hero": false,
            "dead": "5h1 6s2 Ts3 4h4",
            "rows": "Kh0 Kd1 Ac3/3c0 8h0 Ah2 Ad2 4s3/Qd0 Qs0 9c1 7c4 Jh4",
            "win": 0,
            "playerId": "pid5359358"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "5s1 5c2 Js3 As4",
            "rows": "Th2 Tc3 Jd4/3d0 3s0 7d0 7s1 8c3/Qc0 Kc0 Ks1 6d2 Td4",
            "win": 0,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:57:33",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000091-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5359358",
            "orderIndex": 1,
            "hero": false,
            "dead": "6h1 9h2 2c3 2d4",
            "rows": "Kc0 4c3 Ks4/Ah0 As0 4h1 7h1 5d3/Th0 Qd0 Jc2 Js2 4d4",
            "win": 0,
            "playerId": "pid5359358"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "Td1 Jh2 7d3 Qc4",
            "rows": "Qh0 Ac1 Ad2/2h0 6s0 5c2 5s4 7s4/3d0 9d0 3c1 3h3 Qs3",
            "win": 0,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:58:20",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000092-1": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5359358",
            "orderIndex": 0,
            "hero": false,
            "dead": "9s1 5c2 Kh3 As4",
            "rows": "Kc2 Kd3 Ks3/2s0 4s0 8s0 Jh4 Jc4/3d0 Qd0 2d1 Td1 9d2",
            "win": -2.4,
            "playerId": "pid5359358"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "6c1 8d2 7d3 8c4",
            "rows": "Ad0 9h3 2h4/3h0 4c0 Tc2 Ah3 4h4/7h0 7s0 Jd1 Js1 7c2",
            "win": 2.3,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:59:28",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000093-1": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5359358",
            "orderIndex": 1,
            "hero": false,
            "dead": "8d1 9h2 Js3 5d4",
            "rows": "Ad0 Jh2 2d3/3h0 6s0 7d0 4c3 3c4/Qc0 Qs1 Kc1 Kd2 Ts4",
            "win": 1.2,
            "playerId": "pid5359358"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h1 Th2 9d3 Qh4",
            "rows": "Ah2 Qd3 Ac3/4s0 7c0 2c2 6c4 7h4/9s0 Tc0 Jd0 9c1 Td1",
            "win": -1.2,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:00:19",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000094-1": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "pid5359358",
            "orderIndex": 0,
            "hero": false,
            "dead": "7c1 2d2 4s3 4h4",
            "rows": "Th2 Kh4 Ah4/3h0 3s0 5s0 5h1 8d3/8s0 9c0 9d1 9h2 9s3",
            "win": -0.6,
            "playerId": "pid5359358"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "3d1 3c2 4d3 Jh4",
            "rows": "Js1 Jd2 Ks4/2s0 7d0 8c0 7s3 2c4/6h0 6s0 Ts1 Tc2 6c3",
            "win": 0.6,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:01:27",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000095-1": [
        {
            "inFantasy": false,
            "result": -2,
            "playerName": "pid5359358",
            "orderIndex": 1,
            "hero": false,
            "dead": "5h1 Ts2 6s3 4h4",
            "rows": "Ah0 7s3 Kh3/2c0 3c1 9c1 2s2 9s4/9d0 Td0 Qd0 Jd2 4d4",
            "win": -0.4,
            "playerId": "pid5359358"
        },
        {
            "inFantasy": false,
            "result": 2,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "2d1 Ad2 6d3 7h4",
            "rows": "Kc0 Qs1 Qh3/3h0 Ac0 As0 9h2 Qc4/8s0 Th1 8h2 5d3 8d4",
            "win": 0.4,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:02:17",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000096-1": [
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid5359358",
            "orderIndex": 0,
            "hero": false,
            "dead": "8s1 2d2 4c3 6s4",
            "rows": "As1 6d2 Ad3/4s0 9s0 Ts2 Th3 Jd4/2c0 3c0 6c0 Kc1 5c4",
            "win": -3.4,
            "playerId": "pid5359358"
        },
        {
            "inFantasy": true,
            "result": 17,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "4d0",
            "rows": "Qh0 Qd0 Ah0/8h0 Jh0 Jc0 Js0 Ks0/6h0 7d0 8c0 9c0 Td0",
            "win": 3.3,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:03:05",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000097-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5359358",
            "orderIndex": 1,
            "hero": false,
            "dead": "7s1 Td2 3s3 6s4",
            "rows": "Qh0 Ah1 Ts4/2h0 3c0 2c1 3d3 4c3/8s0 9d0 9c2 Kd2 7h4",
            "win": -1.2,
            "playerId": "pid5359358"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "2d1 8c2 2s3 3h4",
            "rows": "Ac0 Qc2 Kh3/4d0 6c0 Th1 4s3 8d4/5h0 5d0 Js1 7d2 5c4",
            "win": 1.2,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:03:49",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000098-1": [
        {
            "inFantasy": false,
            "result": 4,
            "playerName": "pid5359358",
            "orderIndex": 0,
            "hero": false,
            "dead": "5c1 2s2 2c3 5h4",
            "rows": "As1 Ah2 Qs4/2d0 4d0 4s0 2h1 6h4/9d0 Ts0 6d2 9h3 9s3",
            "win": 0.8,
            "playerId": "pid5359358"
        },
        {
            "inFantasy": false,
            "result": -4,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "6s1 4h2 Qd3 7c4",
            "rows": "Jd2 Kd3 3h4/8d0 8c0 Th0 3d3 Td4/Jc0 Qc0 4c1 Tc1 Kc2",
            "win": -0.8,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:05:00",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000099-1": [
        {
            "inFantasy": true,
            "result": 4,
            "playerName": "pid5359358",
            "orderIndex": 1,
            "hero": false,
            "dead": "9c0 8s1 4s2",
            "rows": "Kc0 Ac0 As0/9h0 Th0 Jh0 Qs0 Ks0/3d0 6d0 7d0 Td0 Jd0",
            "win": 0.8,
            "playerId": "pid5359358"
        },
        {
            "inFantasy": false,
            "result": -4,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "9s1 3s2 4c3 6h4",
            "rows": "Ah0 Kh3 Ad4/8d1 5h2 7h2 8h3 7s4/6c0 Tc0 Jc0 Qc0 7c1",
            "win": -0.8,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:05:45",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000100-1": [
        {
            "inFantasy": false,
            "result": -22,
            "playerName": "pid5359358",
            "orderIndex": 0,
            "hero": false,
            "dead": "3h1 4h2 2c3 5h4",
            "rows": "Ah1 6c2 8c4/9s0 Qh0 Tc1 9h3 9c4/3d0 7d0 Kd0 9d2 Qd3",
            "win": -4.4,
            "playerId": "pid5359358"
        },
        {
            "inFantasy": true,
            "result": 22,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "7h0 2h0 6d0",
            "rows": "Jh0 Kh0 Kc0/2s0 3s0 7s0 Js0 Qs0/4d0 4c0 8h0 8d0 8s0",
            "win": 4.3,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:06:28",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000101-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5359358",
            "orderIndex": 1,
            "hero": false,
            "dead": "2d1 Ts2 5h3 Ks4",
            "rows": "As0 Ah1 Jc3/4h0 7h0 8h2 8s2 4c4/5d0 Td0 6d1 6c3 7c4",
            "win": -1.2,
            "playerId": "pid5359358"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "5s1 3s2 3h3 9s4",
            "rows": "Kh1 Tc2 Ac3/4d0 4s0 8c0 5c1 9h3/7d0 Qd0 Jd2 7s4 Ad4",
            "win": 1.2,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:07:16",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000102-1": [
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "pid5359358",
            "orderIndex": 0,
            "hero": false,
            "dead": "8d1 Kc2 9s3 6h4",
            "rows": "Ah0 Ac2 Ts4/Qc0 6c1 4c3 Jc3 2c4/4h0 8h0 Jh0 Qh1 7h2",
            "win": 5.2,
            "playerId": "pid5359358"
        },
        {
            "inFantasy": false,
            "result": -27,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "6s1 7d2 7s3 As4",
            "rows": "Qd1 Ks2 Js4/5h0 8c0 5s1 5d2 Jd3/3h0 9h0 9d0 Th3 8s4",
            "win": -5.4,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:08:23",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000103-1": [
        {
            "inFantasy": true,
            "result": 25,
            "playerName": "pid5359358",
            "orderIndex": 1,
            "hero": false,
            "dead": "5h0 Tc1 7h2",
            "rows": "3h0 3c0 3s0/9c0 Ts0 Jc0 Qs0 Kc0/2d0 5d0 Td0 Jd0 Ad0",
            "win": 4.8,
            "playerId": "pid5359358"
        },
        {
            "inFantasy": false,
            "result": -25,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "4s1 Jh2 6s3 5s4",
            "rows": "Kd0 Kh2 6d3/2s0 8d0 5c2 As3 4d4/7c0 Qc0 7d1 7s1 3d4",
            "win": -5,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:09:07",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000104-1": [
        {
            "inFantasy": true,
            "result": 10,
            "playerName": "pid5359358",
            "orderIndex": 0,
            "hero": false,
            "dead": "4h0 5h1 3c2",
            "rows": "6c0 6s0 Qs0/2d0 3d0 5d0 8d0 9d0/8h0 9h0 Th0 Jh0 Qh0",
            "win": 1.9,
            "playerId": "pid5359358"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "4c1 2s2 9s3 Ac4",
            "rows": "Ad0 Td4 Ah4/3h0 6h0 6d0 4d1 3s2/Jd0 Jc1 7h2 7c3 7s3",
            "win": -2,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:09:54",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000105-1": [
        {
            "inFantasy": true,
            "result": 2,
            "playerName": "pid5359358",
            "orderIndex": 1,
            "hero": false,
            "dead": "8h0 3d1 2h2",
            "rows": "6h0 6c0 Kc0/3s0 5s0 7s0 Js0 Qs0/5d0 9d0 Jd0 Qd0 Ad0",
            "win": 0.4,
            "playerId": "pid5359358"
        },
        {
            "inFantasy": true,
            "result": -2,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "5h0 3c0 Tc0",
            "rows": "9h0 9s0 Ah0/2c0 2s0 8d0 8s0 Qc0/4h0 4d0 4c0 6d0 6s0",
            "win": -0.4,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:10:39",
    "roomId": "21938386"
}


