{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000000-1": [
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "4d1 3c2 2d3 5s4",
            "rows": "Kc0 9h3 Jd4/8h0 8s0 7d2 7c2 5h3/Qh0 Qc0 3h1 3s1 8c4",
            "win": 0.2,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": -1,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "Js1 5c2 Jc3 2c4",
            "rows": "Ah0 Qd2 4h3/2s0 7s0 9s1 Qs3 9c4/Th0 Ts0 6s1 6d2 As4",
            "win": -0.2,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 22:30:08",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000001-1": [
        {
            "inFantasy": false,
            "result": -22,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "2s1 7s2 Kh3 5s4",
            "rows": "Kd0 Ad2 Ah3/2d0 6h0 6s1 4s3 9c4/8h0 Ts0 8c1 Th2 9s4",
            "win": -4.4,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": 22,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "8s1 6d2 Tc3 Kc4",
            "rows": "Jc2 9d3 Jh4/7c0 Js0 3c1 Jd1 3d2/5d0 Qh0 Qd0 Qs3 Qc4",
            "win": 4.3,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 22:31:22",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000002-1": [
        {
            "inFantasy": false,
            "result": -27,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "9d1 Tc2 Td3 Ks4",
            "rows": "Kc0 Kd1 9h3/5s0 4c2 6d2 4d4 Ad4/3h0 5h0 6h0 Kh1 Jh3",
            "win": -5.4,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "9c1 4s2 7s3 Qs4",
            "rows": "8c2 Jc3 8s4/2d0 5d0 5c1 2c2 2s4/Ah0 Ac0 As0 7d1 7h3",
            "win": 5.2,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 22:32:18",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000003-1": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "3d1 4d2 Kc3 7d4",
            "rows": "Kd1 6c2 Ac3/9d0 Qs0 2s1 2c2 Js3/4h0 5h0 Th0 8h4 Td4",
            "win": 1.2,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "3h1 2d2 Qd3 Jc4",
            "rows": "Kh1 Ad2 As2/7h0 9s0 9h1 2h4 4s4/3c0 4c0 9c0 6s3 Ts3",
            "win": -1.2,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 22:33:29",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000004-1": [
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "3h1 Ad2 8c3 2s4",
            "rows": "Jh3 3d4 Kh4/2d0 Jd0 2c1 9d2 9s2/8h0 8s0 Qc0 Qd1 8d3",
            "win": -3.8,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": 19,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "5h1 4d2 3c3 5s4",
            "rows": "Kc2 Ah2 As3/6d0 9h0 Tc1 6c3 Th4/7d0 7c0 7s0 7h1 Qs4",
            "win": 3.7,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 22:34:21",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000005-1": [
        {
            "inFantasy": false,
            "result": -4,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "9c1 5d2 Jd3 4h4",
            "rows": "Qc3 9d4 Td4/4d0 8c0 8d1 7h2 7s2/2h0 9h0 Kh0 5h1 8h3",
            "win": -0.8,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": true,
            "result": 4,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "2d0 3h0 4s0",
            "rows": "Tc0 Ts0 Ah0/6d0 7d0 Js0 Qh0 Qd0/3c0 4c0 6c0 7c0 Kc0",
            "win": 0.8,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 22:34:53",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000006-1": [
        {
            "inFantasy": false,
            "result": 19,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "7d1 3s2 6s3 Ts4",
            "rows": "Ac2 As2 Kc4/Qh1 Qc1 Js3 Ks3 Qs4/2h0 3c0 4d0 5d0 Ah0",
            "win": 3.7,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jd1 8d2 7c3 4h4",
            "rows": "Qd2 2s4 Kh4/5h0 6h0 5c1 7h1 6c2/3d0 Th0 Tc0 9c3 9s3",
            "win": -3.8,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 22:35:40",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000007-1": [
        {
            "inFantasy": true,
            "result": 42,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "8c0 5c1 3s2",
            "rows": "Ah0 Ad0 As0/2h0 2d0 2s0 Qc0 Qs0/7h0 7c0 7s0 9d0 9s0",
            "win": 8.1,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": -42,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "Tc1 8s2 5h3 4c4",
            "rows": "Qh0 Jd4 Kh4/Js0 Ks0 8h2 Jc2 Kc3/5d0 7d0 3d1 Td1 6d3",
            "win": -8.4,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 22:36:25",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000008-1": [
        {
            "inFantasy": true,
            "result": 20,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "3s0 4s1 6d2",
            "rows": "9h0 9c0 Tc0/Ts0 Jh0 Qc0 Kd0 Ah0/5h0 5d0 5c0 7c0 7s0",
            "win": 3.9,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qs1 4h2 7d3 Kh4",
            "rows": "As1 Ac2 9s3/3c0 5s0 6s0 3d3 Th4/2d0 Jd0 Jc1 2c2 4d4",
            "win": -4,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 22:37:09",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000009-1": [
        {
            "inFantasy": false,
            "result": 8,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qs1 7s2 Ad3 Kd4",
            "rows": "Ah1 Kc2 7h4/2c0 3s0 5s1 4s3 4d4/7d0 9d0 Jc0 8s2 Ts3",
            "win": 1.6,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "2h1 4c2 7c3 Qd4",
            "rows": "Qc0 Qh3 6h4/6d0 Td1 Jd1 2d2 3d2/2s0 9s0 Ks0 Js3 3h4",
            "win": -1.6,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 22:38:28",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000010-1": [
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "7h1 5h2 2s3 7s4",
            "rows": "Qd1 Qh2 Kd3/3d0 Js0 9d1 2h4 4h4/2c0 4c0 Ac0 8c2 6c3",
            "win": -2,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "6h1 Td2 6d3 8s4",
            "rows": "Ah0 7c1 Jh4/2d0 Tc0 8h1 Kh3 8d4/4s0 Ks0 3s2 6s2 Ts3",
            "win": 1.9,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 22:39:25",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000011-1": [
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "8h1 6c2 5s3 Ah4",
            "rows": "Ks0 2d4 2s4/2c0 8c1 8d2 7h3 7d3/Th0 Tc0 Jc0 Js1 Jh2",
            "win": -1,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "4d1 Qs2 7s3 Ac4",
            "rows": "Kc2 Td3 Kd3/9c0 6d1 9d1 4c4 6h4/3c0 4h0 5d0 6s0 7c2",
            "win": 1,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 22:40:30",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000012-1": [
        {
            "inFantasy": false,
            "result": -38,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "3c1 Jc2 2d3 Qs4",
            "rows": "Ks0 Kd1 2c3/4d0 6c1 5s2 4s3 Jd4/9h0 Jh0 Qh0 8h2 Kh4",
            "win": -7.6,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": true,
            "result": 38,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qc0 Td0",
            "rows": "Ah0 Ad0 As0/4c0 5c0 6d0 7h0 8d0/7c0 7s0 9d0 9c0 9s0",
            "win": 7.4,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 22:41:02",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000013-1": [
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "7h1 As2 6h3 Ad4",
            "rows": "Ks0 7s3 8s3/2d0 4d0 8d1 7d2 Ah4/5c0 Tc0 3c1 4c2 3s4",
            "win": -3.8,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": true,
            "result": 19,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "5s0 2s0",
            "rows": "8c0 9d0 Jd0/2h0 3h0 5h0 8h0 Kh0/7c0 Qh0 Qd0 Qc0 Qs0",
            "win": 3.7,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 22:41:30",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000014-1": [
        {
            "inFantasy": false,
            "result": -23,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "5c1 7s2 Kc3 4c4",
            "rows": "Kh2 Ks2 2h3/6c0 9s0 9h1 Th1 5d4/3h0 3d0 Qh0 4d3 4h4",
            "win": -4.6,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": true,
            "result": 23,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "4s0 Jh0",
            "rows": "Qd0 Ad0 Ac0/5h0 6d0 7h0 8h0 9d0/3c0 7c0 9c0 Tc0 Jc0",
            "win": 4.5,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 22:42:05",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000015-1": [
        {
            "inFantasy": false,
            "result": 4,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "2h1 Js2 4h3 Jd4",
            "rows": "Kc0 Ks0 Qh3/8c0 3s1 7c1 7h2 8s4/5d0 Td0 Ts2 Th3 Qc4",
            "win": 0.8,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": 34,
            "playerName": "pid5591227",
            "orderIndex": 1,
            "hero": false,
            "dead": "8h1 3d2 4c3 2d4",
            "rows": "Kh2 Qs3 Kd4/2s0 5c0 3h1 2c2 3c3/6d0 6s0 Tc0 6c1 6h4",
            "win": 6.6,
            "playerId": "pid5591227"
        },
        {
            "inFantasy": false,
            "result": -38,
            "playerName": "pid5684226",
            "orderIndex": 2,
            "hero": true,
            "dead": "5s1 Ad2 5h3 As4",
            "rows": "Ah0 Ac1 Qd4/4d0 4s0 7d1 8d2 9d4/9c0 9s0 Jh2 9h3 Jc3",
            "win": -7.6,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 22:43:49",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000016-1": [
        {
            "inFantasy": true,
            "result": 11,
            "playerName": "pid1087966",
            "orderIndex": 2,
            "hero": false,
            "dead": "9h0 8c1",
            "rows": "Jh0 Jd0 Qd0/5h0 5d0 6c0 Th0 Tc0/2s0 4s0 6s0 8s0 As0",
            "win": 2.1,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": true,
            "result": 10,
            "playerName": "pid5591227",
            "orderIndex": 0,
            "hero": false,
            "dead": "Td0 2d1",
            "rows": "Js0 Qs0 Ad0/3c0 5c0 7c0 Jc0 Kc0/2h0 3h0 4h0 Qh0 Kh0",
            "win": 1.9,
            "playerId": "pid5591227"
        },
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "7h1 8h2 4c3 2c4",
            "rows": "Ah0 Ks2 6h4/3s0 3d1 Ts2 Qc3 Ac4/7d0 8d0 9d0 4d1 6d3",
            "win": -4.2,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 22:44:46",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000017-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "7d1 3d2 7c3 4c4",
            "rows": "Kd0 Tc3 Qh4/4d0 As0 3s1 2s2 5c4/6c0 6s0 6d1 6h2 8d3",
            "win": 0,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid5591227",
            "orderIndex": 2,
            "hero": false,
            "dead": "Kc1 8c2 Th3 9h4",
            "rows": "Qc0 Ad2 Ac3/2h0 5h0 Jd3 2c4 Jh4/9c0 Td0 Jc1 Js1 9d2",
            "win": -3.4,
            "playerId": "pid5591227"
        },
        {
            "inFantasy": false,
            "result": 17,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "2d1 3c2 5d3 4s4",
            "rows": "Qd0 Qs2 Ks4/8s0 9s1 Ts1 7s2 5s3/3h0 4h0 7h0 8h3 Ah4",
            "win": 3.3,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 22:46:34",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000018-1": [
        {
            "inFantasy": false,
            "result": -53,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "Js1 Th2 2c3 5s4",
            "rows": "Kc0 Td4 Ah4/3h0 2d1 3s2 3d3 8s3/6c0 7s0 9d0 5d1 8h2",
            "win": -8.2,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": true,
            "result": 58,
            "playerName": "pid5591227",
            "orderIndex": 1,
            "hero": false,
            "dead": "7d0 Qd1 5h2",
            "rows": "Kh0 Kd0 Ks0/2s0 4s0 6s0 9s0 Qs0/3c0 7c0 8c0 Qc0 Ac0",
            "win": 8.9,
            "playerId": "pid5591227"
        },
        {
            "inFantasy": true,
            "result": -5,
            "playerName": "pid5684226",
            "orderIndex": 2,
            "hero": true,
            "dead": "6d0",
            "rows": "4h0 4d0 4c0/Jh0 Jd0 Jc0 Qh0 As0/6h0 7h0 8d0 9c0 Tc0",
            "win": -1,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 22:47:34",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000019-1": [
        {
            "inFantasy": true,
            "result": -6,
            "playerName": "pid5591227",
            "orderIndex": 1,
            "hero": false,
            "dead": "3d0 2c1 3c2",
            "rows": "Th0 Ts0 Ac0/4h0 5s0 6c0 7s0 8s0/4d0 6d0 Jd0 Qd0 Kd0",
            "win": -1.2,
            "playerId": "pid5591227"
        },
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "5d0",
            "rows": "6s0 7c0 Kh0/2h0 2d0 2s0 3h0 3s0/8h0 8d0 8c0 Td0 Tc0",
            "win": 1.2,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 22:48:13",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000020-1": [
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "2d1 Jd2 Qh3 3s4",
            "rows": "Ad0 Qd3 Ks3/5d0 6s0 4h1 7s2 3h4/Td0 Jc0 9c1 7d2 9s4",
            "win": -2.8,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid5591227",
            "orderIndex": 1,
            "hero": false,
            "dead": "Ts1 7h2 Th3 2h4",
            "rows": "As0 Kd2 Jh3/9h0 3d1 5s2 8s4 Js4/7c0 Tc0 Qc0 3c1 8c3",
            "win": -2.8,
            "playerId": "pid5591227"
        },
        {
            "inFantasy": false,
            "result": 28,
            "playerName": "pid5684226",
            "orderIndex": 2,
            "hero": true,
            "dead": "9d1 5c2 6d3 5h4",
            "rows": "Kh2 Kc3 Ac3/4c0 6h0 4s1 6c1 Qs4/2c0 2s0 8d0 8h2 4d4",
            "win": 5.4,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 22:49:57",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000021-1": [
        {
            "inFantasy": false,
            "result": -4,
            "playerName": "pid1087966",
            "orderIndex": 2,
            "hero": false,
            "dead": "8s1 2h2 8d3 Jc4",
            "rows": "Ac0 As0 Jh3/Tc1 6c2 9c2 Th3 9d4/4h0 4d0 Qs0 Qd1 Ks4",
            "win": -0.8,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "pid5591227",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qh1 2c2 4s3 6s4",
            "rows": "Kc0 Qc3 9s4/6d0 7h2 7d2 7s3 5c4/3d0 3c0 8h0 3s1 8c1",
            "win": -0.6,
            "playerId": "pid5591227"
        },
        {
            "inFantasy": true,
            "result": 7,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "5s0 4c0",
            "rows": "Ts0 Kh0 Kd0/2d0 2s0 Td0 Jd0 Js0/3h0 5h0 6h0 9h0 Ah0",
            "win": 1.4,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 22:50:58",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000022-1": [
        {
            "inFantasy": true,
            "result": 38,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "7s0 8c1 4h2",
            "rows": "Jd0 Ah0 Ac0/2c0 9h0 9s0 Kh0 Ks0/6d0 6s0 Qh0 Qd0 Qc0",
            "win": 7.4,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": -31,
            "playerName": "pid5591227",
            "orderIndex": 2,
            "hero": false,
            "dead": "Ts1 2d2 2h3 5c4",
            "rows": "Jc1 As1 Ad3/3c0 4s0 3d2 9d3 6c4/7h0 7c0 8d0 7d2 6h4",
            "win": -6.2,
            "playerId": "pid5591227"
        },
        {
            "inFantasy": false,
            "result": -7,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "8h1 5d2 Jh3 5h4",
            "rows": "Kc0 Tc2 Js4/9c0 3h1 4d1 Kd3 4c4/5s0 8s0 Qs0 3s2 2s3",
            "win": -1.4,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 22:52:09",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000023-1": [
        {
            "inFantasy": false,
            "result": 8,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "2h1 5c2 3h3 2s4",
            "rows": "Qs2 4h3 8h4/5d0 7s0 3c1 4c1 3s4/8c0 Td0 Qh0 Js2 9d3",
            "win": 1.6,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jc1 4s2 2c3 Th4",
            "rows": "Ks2 Kc3 8s4/7d0 8d0 Jd1 Ts3 7c4/7h0 Jh0 Kh0 6h1 5h2",
            "win": -1.6,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 22:53:16",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000024-1": [
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "5c1 6h2 6c3 5d4",
            "rows": "8c3 Kc3 2s4/2c0 4h0 4c1 2h2 9c2/8s0 Jc0 Qd0 9s1 9d4",
            "win": -3.6,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "3d1 8d2 4s3 7c4",
            "rows": "Kd0 Ks1 9h3/2d0 Tc0 Td3 Ac4 As4/3h0 5h0 7h1 Jh2 Kh2",
            "win": 3.5,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 22:54:09",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000025-1": [
        {
            "inFantasy": false,
            "result": -7,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "9d1 5d2 4c3 Jc4",
            "rows": "6c2 Td3 6d4/3s0 7s0 9s1 5s2 2s3/4h0 5h0 Th0 Jh1 6h4",
            "win": -1.4,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": true,
            "result": 7,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "3h0 Kc0",
            "rows": "Kh0 Ah0 Ac0/6s0 7d0 8c0 9c0 Tc0/2d0 2c0 Qd0 Qc0 Qs0",
            "win": 1.4,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 22:54:47",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000026-1": [
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "Ad1 8h2 5d3 5h4",
            "rows": "Kc0 Ac3 7s4/Ah0 As0 4s2 5c2 Td3/2d0 3s0 6c1 6s1 2s4",
            "win": -2.8,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": 14,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "Js1 6h2 5s3 9h4",
            "rows": "Kh0 Th2 Ks3/3d0 4d0 4c0 7d2 7h4/8s0 Qc1 Qs1 8d3 Kd4",
            "win": 2.7,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 22:55:43",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000027-1": [
        {
            "inFantasy": false,
            "result": -7,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "7c1 Ks2 7s3 Ts4",
            "rows": "Ah2 9h3 As3/2s0 3c0 5h0 2h1 5c4/Jd0 Kd0 Td1 8d2 Qd4",
            "win": -1.4,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": true,
            "result": 7,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "5d0 6d0",
            "rows": "9d0 Qc0 Qs0/3h0 7h0 8h0 Th0 Jh0/6c0 9c0 Tc0 Jc0 Ac0",
            "win": 1.4,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 22:56:20",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000028-1": [
        {
            "inFantasy": true,
            "result": 0,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "7d0 9h1 5d2",
            "rows": "Kd0 Kc0 As0/3s0 6h0 6s0 Th0 Ts0/2h0 2d0 Qh0 Qd0 Qc0",
            "win": 0,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ks1 7c2 6c3 Td4",
            "rows": "Ah0 Jc2 Ad4/2s0 4s0 3c1 3h2 4c4/8c0 9d0 8s1 8d3 9s3",
            "win": 0,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 22:57:09",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000029-1": [
        {
            "inFantasy": false,
            "result": -26,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "7c1 9c2 4c3 Kc4",
            "rows": "As0 Ac2 Kh3/2h0 8s0 5s3 7d4 9h4/6c0 Tc0 Th1 Ts1 6d2",
            "win": -5.2,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": true,
            "result": 26,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "8c0 6s0 3c0",
            "rows": "Qs0 Kd0 Ks0/4h0 6h0 8h0 Jh0 Qh0/2d0 3d0 9d0 Jd0 Qd0",
            "win": 5,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 22:57:46",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000030-1": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "5d1 8d2 9c3 4c4",
            "rows": "9d2 Kc2 Qs3/2s0 7c0 6c1 4d3 6s4/3c0 3s0 Js0 Jc1 Th4",
            "win": 1.2,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "7s1 Td2 2h3 Ts4",
            "rows": "Kh1 Kd2 As3/3d0 5c0 Ac1 Ad2 6d3/9h0 9s0 Qh0 4h4 5h4",
            "win": -1.2,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 22:58:35",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000031-1": [
        {
            "inFantasy": false,
            "result": 4,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "2c1 7d2 Tc3 Qh4",
            "rows": "Qd0 Qc2 Ks4/5s0 5d2 2h3 2d3 Kc4/3c0 7c0 Jc0 8c1 Ac1",
            "win": 0.8,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": -4,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qs1 Js2 7h3 3s4",
            "rows": "Kd0 Ah3 6h4/3h0 3d0 7s2 9c2 9s3/8h0 Th0 8d1 Ts1 8s4",
            "win": -0.8,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 22:59:36",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000032-1": [
        {
            "inFantasy": true,
            "result": 25,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "2c0",
            "rows": "4d0 Td0 Tc0/2s0 3s0 9s0 Js0 Ks0/7h0 7c0 8h0 8c0 8s0",
            "win": 4.8,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": -25,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "7d1 Ah2 5h3 Kd4",
            "rows": "As0 Ad1 Ts3/5c0 5s0 6s0 4h3 9c4/Qd0 9d1 Jh2 Jd2 3h4",
            "win": -5,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:00:31",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000033-1": [
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "2d1 Qs2 3d3 Qc4",
            "rows": "Kd0 Kh1 2c2/8d0 7d1 Kc2 Td3 Ks4/5h0 5c0 9c0 6d3 Jh4",
            "win": -1.6,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": 8,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "5s1 8s2 9s3 4h4",
            "rows": "Ad0 9h4 Jc4/Ts0 3c1 4s1 4d3 Tc3/3h0 4c0 5d0 2s2 Ac2",
            "win": 1.6,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:01:47",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000034-1": [
        {
            "inFantasy": false,
            "result": -7,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "2s1 4h2 2h3 6s4",
            "rows": "Ah1 Js2 7d3/5d0 9h0 9s1 3s2 3c4/4c0 6c0 Qc0 Qh3 Qs4",
            "win": -1.4,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": 7,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qd1 2c2 5h3 4d4",
            "rows": "Ac0 6d4 Kc4/4s0 8s0 8c1 7h3 7c3/Jd0 Kd0 Jh1 Jc2 Kh2",
            "win": 1.4,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:02:43",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000035-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jh1 Ks2 6s3 4d4",
            "rows": "Kd0 Kc0 Qd3/7d0 7h1 Td1 2s3 Th4/3c0 8c0 8h2 Ah2 9h4",
            "win": 0,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "2d1 4c2 2c3 Qc4",
            "rows": "As0 Ts2 Ad3/7s0 Jc0 6h1 Jd2 8d4/Qh0 Qs0 5d1 3d3 4s4",
            "win": 0,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:03:55",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000036-1": [
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "3h1 Kh2 3d3 Td4",
            "rows": "Ac0 9h3 Qd3/Qc0 4c1 5c1 9c2 Qs4/4s0 6s0 Ts0 5s2 8s4",
            "win": 1.9,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jc1 Th2 5h3 Js4",
            "rows": "Kc0 Ad1 Kd3/2h0 2c0 3s1 7d4 8d4/9d0 9s0 6h2 6c2 6d3",
            "win": -2,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:04:51",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000037-1": [
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "9s1 5d2 Jd3 6h4",
            "rows": "Ac0 Ks2 9c4/6d0 7h0 7s2 7c3 4h4/Qh0 Qc0 4d1 4c1 4s3",
            "win": 0.2,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": -1,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jh1 6s2 7d3 9h4",
            "rows": "Qd1 Kd2 3c4/2c0 3s0 3d3 Jc3 3h4/8d0 8s0 Tc0 Ts1 Th2",
            "win": -0.2,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:06:00",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000038-1": [
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "2d1 2s2 Td3 3c4",
            "rows": "Kh2 Ks3 8h4/3d0 4s0 6h1 3h2 4c4/8c0 Js0 Qh0 8d1 Qc3",
            "win": -1.8,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "4d1 7c2 3s3 Qs4",
            "rows": "Ad1 Jh3 Ac3/2c0 9d0 5d1 5c2 2h4/7s0 8s0 9s0 Jc2 Ts4",
            "win": 1.7,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:06:51",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000039-1": [
        {
            "inFantasy": true,
            "result": -14,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "9h0 4h1",
            "rows": "Td0 Ts0 Kd0/2h0 3d0 4s0 5d0 Ac0/2c0 5c0 7c0 8c0 Jc0",
            "win": -2.8,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": true,
            "result": 14,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "3s0 4c0 2s0",
            "rows": "Kh0 Ah0 Ad0/3h0 5h0 6h0 Th0 Qh0/5s0 7s0 8s0 9s0 Ks0",
            "win": 2.7,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:07:20",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000040-1": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "3h1 Jh2 3s3 2h4",
            "rows": "Tc1 Qc2 Ah4/5c0 6d0 4d1 5s2 Kc4/2d0 2s0 8c0 4c3 4s3",
            "win": -0.6,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qh1 7s2 5h3 3c4",
            "rows": "Ac0 Ts3 Jc4/6h0 Js0 7h1 7d2 7c3/9d0 Kd0 9h1 9c2 6s4",
            "win": 0.6,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:08:16",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000041-1": [
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jc1 6s2 4h3 Qs4",
            "rows": "4d3 As3 Qd4/2h0 9h0 7s1 7h2 9d2/8h0 8c0 Tc0 Th1 2c4",
            "win": 0.2,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": -1,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "7c1 8d2 8s3 Kc4",
            "rows": "Kh1 9c2 4c4/3c0 4s0 2s1 5h2 2d3/Jh0 Js0 Qh0 5c3 Qc4",
            "win": -0.2,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:09:21",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000042-1": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "Th1 Qs2 4h3 3h4",
            "rows": "As3 6c4 8c4/2h0 4s0 4c1 5h2 5c2/6d0 8s0 9d0 9h1 8h3",
            "win": 1.2,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "4d1 2c2 2d3 Ad4",
            "rows": "Qd1 Qc1 9s3/6h0 Td0 5s2 Ts3 Jd4/7h0 7s0 Js0 Jh2 9c4",
            "win": -1.2,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:10:08",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000043-1": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "7s1 7c2 Th3 Jc4",
            "rows": "Ks1 Td3 Kh4/2c0 6h0 2d2 9d2 6c4/4c0 4s0 Qc0 4d1 4h3",
            "win": 4.7,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": -24,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "5d1 3h2 Tc3 6s4",
            "rows": "Qh0 Qs0 5c4/2s0 Kd0 Ac1 As2 8s3/7h0 9c1 9h2 Js3 3d4",
            "win": -4.8,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:11:27",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000044-1": [
        {
            "inFantasy": true,
            "result": 16,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "3c0 4c1",
            "rows": "Th0 Kc0 Ks0/2d0 Jc0 Js0 Qh0 Qd0/5h0 5d0 8d0 8c0 8s0",
            "win": 3.1,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "3h1 5s2 4d3 4h4",
            "rows": "Kh3 6h4 Jh4/3d0 3s0 8h0 6d1 6s1/5c0 Qc0 2c2 6c2 9c3",
            "win": -3.2,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:12:18",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000045-1": [
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "2h1 9c2 9h3 7s4",
            "rows": "Ad0 Kc3 8d4/Jd0 3h1 6d1 6s2 6h3/Tc0 Ts0 Qc0 Qh2 Qd4",
            "win": 1.9,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "8c1 3c2 5d3 7d4",
            "rows": "Kd0 Ah3 4d4/7c0 Jh0 4c2 Jc2 4h3/4s0 5s0 9s1 Js1 8s4",
            "win": -2,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:13:27",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000046-1": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qs1 Jd2 Qd3 3d4",
            "rows": "Kc0 Ks0 8s4/5h0 6h2 3c3 4h3 7h4/2d0 9d0 2h1 9s1 9h2",
            "win": 4.7,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": -24,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "9c1 4d2 2c3 5s4",
            "rows": "Kd2 Qc3 Ah4/5d0 6s0 Td1 Ts2 6c3/8h0 Jh0 Jc0 8c1 7c4",
            "win": -4.8,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:14:20",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000047-1": [
        {
            "inFantasy": true,
            "result": 24,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "7d0 8s1",
            "rows": "Jc0 Kh0 Kd0/2h0 3s0 4c0 5d0 Ad0/3h0 3d0 6h0 6c0 6s0",
            "win": 4.7,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": -24,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "2d1 7c2 3c3 5h4",
            "rows": "Ah1 9d3 Ks4/8d0 9s0 Td2 Tc2 9h3/4s0 Qc0 Qs0 4h1 Jd4",
            "win": -4.8,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:15:07",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000048-1": [
        {
            "inFantasy": false,
            "result": 2,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "7c1 4d2 Jc3 Ah4",
            "rows": "Qc3 8h4 8d4/4h0 4c0 2s1 9h1 2c3/7h0 8c0 9s0 7d2 7s2",
            "win": 0.4,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": -2,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "2d1 Qd2 9d3 3c4",
            "rows": "As0 Kd3 Js4/3h0 3d0 6h1 6c2 Jd4/4s0 5s0 Ts1 Tc2 Td3",
            "win": -0.4,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:16:06",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000049-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "7c1 Qh2 4s3 Qc4",
            "rows": "Ah0 Kd1 Kh2/2c0 3s0 6h2 4c4 8c4/5h0 5d0 Jh1 5s3 9h3",
            "win": 0,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "5c1 9c2 Tc3 Qd4",
            "rows": "Ad0 Ac0 Jc3/4h0 7s0 3d3 6s4 Jd4/Js0 2s1 8s1 2h2 8d2",
            "win": 0,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:17:22",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000050-1": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "Js1 8d2 Th3 9s4",
            "rows": "Ah1 Kd3 9d4/2h0 3s0 4s2 5s2 6h3/9c0 Tc0 Kc0 6c1 2c4",
            "win": 0.6,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qh1 9h2 Jh3 5d4",
            "rows": "Qs0 As1 8h4/4c0 6s0 Kh2 4d3 6d3/3d0 7d0 3c1 7s2 7h4",
            "win": -0.6,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:18:15",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000051-1": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "8c1 8s2 As3 8d4",
            "rows": "Kc1 Kh2 Tc4/Ts0 Jc0 9s1 Ad2 Ac3/7c0 7s0 Qh0 3c3 Jd4",
            "win": -2.4,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "9h1 Qc2 2h3 6c4",
            "rows": "Ah2 3s4 Qd4/5s0 8h0 6s1 5d2 5c3/4d0 7d0 Td0 6d1 3d3",
            "win": 2.3,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:19:45",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000052-1": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "Ah1 2d2 2c3 5h4",
            "rows": "Ad0 Ts3 Qd4/4d0 7h0 4h2 6c2 6s4/3h0 3d0 3c1 3s1 9d3",
            "win": 0.6,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "4c1 Td2 Tc3 6d4",
            "rows": "Qh0 9h3 9s4/Kd0 Jd1 Kc2 5d3 Ac4/4s0 7s0 As0 8s1 2s2",
            "win": -0.6,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:20:33",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000053-1": [
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "5c1 2s2 2h3 7d4",
            "rows": "Kc1 Ks1 4s3/3d0 9h0 8s2 9c2 8d4/6h0 6c0 Jd0 Ad3 Qd4",
            "win": -3,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "2d1 4d2 7h3 9d4",
            "rows": "Ac0 As0 8h4/3h0 5s0 3s1 4c1 5h2/9s0 Ts2 Tc3 Qc3 Qs4",
            "win": 2.9,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:21:46",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000054-1": [
        {
            "inFantasy": false,
            "result": -34,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qd1 5c2 5s3 7c4",
            "rows": "As0 Kd2 8c4/4h0 2c1 8h1 8d3 4s4/6h0 6d0 Js0 9d2 Jd3",
            "win": -6.8,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": true,
            "result": 34,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "7h0 4d0 3s0",
            "rows": "Th0 Td0 Ah0/6s0 7s0 8s0 Qs0 Ks0/9c0 Tc0 Jc0 Qc0 Kc0",
            "win": 6.6,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:22:18",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000055-1": [
        {
            "inFantasy": false,
            "result": -11,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "3d1 2h2 6d3 3s4",
            "rows": "7c3 Kc3 5h4/6s0 Td0 7h2 8d2 9d4/5c0 8c0 Ac0 2c1 Qc1",
            "win": -2.2,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": true,
            "result": 11,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "4c0 9h0 3c0",
            "rows": "Tc0 Jh0 Js0/2s0 5s0 7s0 9s0 Ks0/2d0 7d0 Jd0 Qd0 Kd0",
            "win": 2.1,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:22:57",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000056-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid1087966",
            "orderIndex": 2,
            "hero": false,
            "dead": "4h1 5c2 3h3 3d4",
            "rows": "As0 Qc1 4d3/2d0 8s0 7h2 2s4 7c4/9h0 Th0 9d1 Ts2 9s3",
            "win": 0,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid695998",
            "orderIndex": 0,
            "hero": false,
            "dead": "6s1 Tc2 Kc3 2c4",
            "rows": "Qh1 Ac1 Js4/4c0 3s2 8c2 8h3 8d3/Td0 Jh0 Qs0 Kh0 Ad4",
            "win": -1.2,
            "playerId": "pid695998"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "9c1 6h2 Qd3 7s4",
            "rows": "Jc3 5s4 Ks4/4s0 5h0 2h1 3c2 6c3/5d0 6d0 7d0 Jd1 Kd2",
            "win": 1.2,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:24:31",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000057-1": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qs1 8h2 7s3 6c4",
            "rows": "Ah0 Ad0 3s3/4h0 5h0 2h1 Th4 Kc4/9d0 Jc1 Jh2 Kh2 Ks3",
            "win": -2.4,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid695998",
            "orderIndex": 2,
            "hero": false,
            "dead": "6s1 8c2 3h3 2c4",
            "rows": "4s0 As1 Ac2/7d0 9s0 9c2 5s3 9h3/Td0 Tc0 Jd1 4d4 4c4",
            "win": -2.4,
            "playerId": "pid695998"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "3c1 8s2 Js3 5c4",
            "rows": "7h2 7c2 5d4/Qh0 Qc0 2s3 6h3 6d4/2d0 3d0 8d0 Qd1 Kd1",
            "win": 4.7,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:25:37",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000058-1": [
        {
            "inFantasy": false,
            "result": 16,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jc1 7s2 5s3 Tc4",
            "rows": "Qh1 Ks1 Kc4/2c0 3d0 Jd2 Ad2 Ac3/6c0 7h0 8s0 5d3 4d4",
            "win": 3.1,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": 17,
            "playerName": "pid695998",
            "orderIndex": 1,
            "hero": false,
            "dead": "Td1 2s2 6h3 3s4",
            "rows": "Qd2 3h4 Qs4/4h0 7d1 9d2 Kh3 Kd3/4c0 5c0 7c0 8c0 Qc1",
            "win": 3.3,
            "playerId": "pid695998"
        },
        {
            "inFantasy": false,
            "result": -33,
            "playerName": "pid5684226",
            "orderIndex": 2,
            "hero": true,
            "dead": "2d1 4s2 2h3 9s4",
            "rows": "Ah0 As0 9c3/5h0 6d1 3c2 6s4 8h4/Th0 Ts0 Jh1 Js2 9h3",
            "win": -6.6,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:27:06",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000059-1": [
        {
            "inFantasy": true,
            "result": 1,
            "playerName": "pid1087966",
            "orderIndex": 2,
            "hero": false,
            "dead": "3h0 2h1",
            "rows": "4s0 Ts0 Jh0/2c0 4c0 6c0 Tc0 Qc0/5h0 5d0 5s0 8h0 8d0",
            "win": 0.2,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": true,
            "result": 4,
            "playerName": "pid695998",
            "orderIndex": 0,
            "hero": false,
            "dead": "6d0",
            "rows": "Qh0 Ah0 Ad0/2s0 3d0 4h0 5c0 6h0/9s0 Td0 Js0 Qs0 Kc0",
            "win": 0.8,
            "playerId": "pid695998"
        },
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "8s1 Kh2 Ks3 2d4",
            "rows": "Ac0 Kd1 Jc4/4d0 6s0 9h2 9c2 9d4/7d0 7c0 Qd1 7h3 7s3",
            "win": -1,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:28:01",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000060-1": [
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "5c1 5h2 7h3 7c4",
            "rows": "Ks1 Ac2 As3/3c0 4h0 3d2 9d3 9h4/2h0 2d0 8s0 2s1 Qc4",
            "win": 5.8,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "pid695998",
            "orderIndex": 2,
            "hero": false,
            "dead": "4s1 Tc2 Jc3 5d4",
            "rows": "Kc1 Ts3 Ah4/2c0 4d0 5s0 3h2 6d2/Td0 Js0 8h1 Qd3 Qs4",
            "win": -4.2,
            "playerId": "pid695998"
        },
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "Th1 3s2 9c3 8d4",
            "rows": "Ad0 9s2 6h4/6c0 7s0 8c1 6s3 7d3/Jh0 Kd0 Jd1 Kh2 4c4",
            "win": -1.8,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:29:03",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000061-1": [
        {
            "inFantasy": true,
            "result": 38,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "3s0 3c1 8c2",
            "rows": "6h0 6c0 Jc0/2d0 8d0 Td0 Jd0 Qd0/7s0 9s0 Ts0 Qs0 Ks0",
            "win": 7.4,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid695998",
            "orderIndex": 1,
            "hero": false,
            "dead": "4d1 4c2 4h3 5c4",
            "rows": "As0 5s2 5d4/7d0 8h0 7c1 9d3 9c3/Js0 Qc0 9h1 Kd2 4s4",
            "win": -3.8,
            "playerId": "pid695998"
        },
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid5684226",
            "orderIndex": 2,
            "hero": true,
            "dead": "3h1 Qh2 Th3 Ac4",
            "rows": "Jh0 Ad2 Ah3/5h0 6d0 6s1 7h2 8s4/2c0 Tc0 2s1 2h3 3d4",
            "win": -3.8,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:30:53",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000062-1": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "pid1087966",
            "orderIndex": 2,
            "hero": false,
            "dead": "2c1 3s2 2h3 Ac4",
            "rows": "Ah0 2s4 Js4/7s0 8s1 5s2 Th3 Tc3/8d0 9d0 Jd0 Td1 Qd2",
            "win": 2.9,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": -37,
            "playerName": "pid695998",
            "orderIndex": 0,
            "hero": false,
            "dead": "5h1 4s2 5c3 9h4",
            "rows": "Kh2 Ts3 5d4/8h0 Qc0 3h2 2d3 Qs4/3d0 4h0 6c0 6d1 6s1",
            "win": -7.4,
            "playerId": "pid695998"
        },
        {
            "inFantasy": false,
            "result": 22,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jh1 6h2 9s3 7c4",
            "rows": "Ad0 As0 Qh3/7h0 Kd1 Kc1 Ks3 4d4/8c0 9c0 3c2 4c2 Jc4",
            "win": 4.3,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:32:44",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000063-1": [
        {
            "inFantasy": false,
            "result": -24,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jd1 2d2 2c3 4d4",
            "rows": "5d3 Tc4 Ad4/8c1 9d1 6c2 Ts2 7c3/Td0 Jc0 Qd0 Kh0 Ac0",
            "win": -4.8,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid695998",
            "orderIndex": 2,
            "hero": false,
            "dead": "9s1 6h2 4s3 3h4",
            "rows": "Kd1 Qh2 Ah3/5c0 8h0 9c2 5h3 Js4/2h0 2s0 3s0 3c1 3d4",
            "win": -3.4,
            "playerId": "pid695998"
        },
        {
            "inFantasy": true,
            "result": 41,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "4h0 4c0 6d0",
            "rows": "7h0 7d0 7s0/8d0 9h0 Th0 Jh0 Qc0/5s0 6s0 Qs0 Ks0 As0",
            "win": 8,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:33:56",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000064-1": [
        {
            "inFantasy": false,
            "result": -38,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "8d1 5c2 2c3 2h4",
            "rows": "Ac0 As2 Qh4/4c0 7d0 4s1 Jh3 6c4/9d0 9s0 Qs1 Qc2 9c3",
            "win": -6.3,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "pid695998",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qd1 2s2 5d3 7h4",
            "rows": "Kd2 Td3 Kc4/8s0 3h1 3s1 Jc3 Jd4/5h0 6h0 9h0 Ah0 4h2",
            "win": 1.6,
            "playerId": "pid695998"
        },
        {
            "inFantasy": true,
            "result": 23,
            "playerName": "pid5684226",
            "orderIndex": 2,
            "hero": true,
            "dead": "5s0 2d0 3d0",
            "rows": "Kh0 Ks0 Ad0/7c0 7s0 8h0 8c0 Js0/6d0 6s0 Th0 Tc0 Ts0",
            "win": 4.5,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:34:41",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000065-1": [
        {
            "inFantasy": false,
            "result": -40,
            "playerName": "pid1087966",
            "orderIndex": 2,
            "hero": false,
            "dead": "4h1 8c2 Jc3 7c4",
            "rows": "Kh1 Ad1 Kc2/5s0 6h0 9d2 9c3 6c4/Th0 Qh0 Qs0 Jd3 Kd4",
            "win": 0,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": true,
            "result": 68,
            "playerName": "pid695998",
            "orderIndex": 0,
            "hero": false,
            "dead": "2s0 3d1",
            "rows": "Ah0 Ac0 As0/3h0 4s0 5d0 6s0 7d0/8d0 9s0 Tc0 Js0 Qc0",
            "win": 3.2,
            "playerId": "pid695998"
        },
        {
            "inFantasy": false,
            "result": -28,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "5h1 5c2 Jh3 2d4",
            "rows": "Td1 8s4 9h4/3c0 4c0 8h1 3s2 4d2/7h0 7s0 Qd0 2h3 2c3",
            "win": -3.3,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:35:38",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000066-1": [
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jh1 Td2 7c3 9d4",
            "rows": "9h3 Ks3 Ah4/2s0 3c0 5h1 2d2 Jd4/6c0 7h0 9s0 Th1 8d2",
            "win": -0.9,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": true,
            "result": 38,
            "playerName": "pid695998",
            "orderIndex": 2,
            "hero": false,
            "dead": "4d0 3d1",
            "rows": "Kd0 Kc0 As0/4h0 5d0 6s0 7d0 8h0/8s0 9c0 Ts0 Js0 Qc0",
            "win": 6.3,
            "playerId": "pid695998"
        },
        {
            "inFantasy": false,
            "result": -28,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qd1 7s2 4s3 Ac4",
            "rows": "Kh0 Qh1 Qs3/3h0 3s1 2c2 5s2 5c3/6h0 6d0 Jc0 8c4 Tc4",
            "win": -5.6,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:37:10",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000067-1": [
        {
            "inFantasy": false,
            "result": -40,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "3h1 3s2 2h3 3c4",
            "rows": "Qh1 Ks2 Jc4/2s0 5c0 7c0 2d3 6s4/9d0 Td0 9c1 6d2 Th3",
            "win": -8,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": 29,
            "playerName": "pid695998",
            "orderIndex": 1,
            "hero": false,
            "dead": "7s1 4c2 Kh3 Kd4",
            "rows": "2c0 Ac2 Ah4/8d0 9h0 8s1 7h2 7d3/5h0 5s0 Jh1 5d3 Js4",
            "win": 5.6,
            "playerId": "pid695998"
        },
        {
            "inFantasy": false,
            "result": 11,
            "playerName": "pid5684226",
            "orderIndex": 2,
            "hero": true,
            "dead": "8c1 3d2 6c3 6h4",
            "rows": "Qs2 Jd3 Qc4/9s0 8h1 As2 Qd3 Ad4/4h0 4d0 Tc0 Ts0 4s1",
            "win": 2.1,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:38:31",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000068-1": [
        {
            "inFantasy": false,
            "result": -45,
            "playerName": "pid1087966",
            "orderIndex": 2,
            "hero": false,
            "dead": "Tc1 5s2 5h3 9c4",
            "rows": "Kd0 Qc2 Js4/As0 Jd1 6s2 6h3 Jh3/7d0 7c0 8s0 8h1 9d4",
            "win": -9,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": true,
            "result": 29,
            "playerName": "pid695998",
            "orderIndex": 0,
            "hero": false,
            "dead": "7s0 6c1 9s2",
            "rows": "3h0 3d0 3c0/4h0 4d0 4s0 Jc0 Qs0/2h0 2d0 2c0 Ah0 Ac0",
            "win": 5.6,
            "playerId": "pid695998"
        },
        {
            "inFantasy": true,
            "result": 16,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "2s0",
            "rows": "3s0 4c0 9h0/6d0 8d0 Td0 Qd0 Ad0/Th0 Ts0 Kh0 Kc0 Ks0",
            "win": 3.1,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:40:00",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000069-1": [
        {
            "inFantasy": false,
            "result": -38,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qd1 Kh2 4c3 6d4",
            "rows": "As0 Ad2 Ah3/3d0 4d0 5h1 6s1 7s4/8c0 9h0 Qh2 Js3 4s4",
            "win": -7.4,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": true,
            "result": 40,
            "playerName": "pid695998",
            "orderIndex": 2,
            "hero": false,
            "dead": "8s0 7c1 Qc2",
            "rows": "2h0 2d0 2c0/9d0 Tc0 Jd0 Qs0 Ks0/3h0 4h0 6h0 7h0 Jh0",
            "win": 7.6,
            "playerId": "pid695998"
        },
        {
            "inFantasy": false,
            "result": -2,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ac1 6c2 3c3 9s4",
            "rows": "Kd0 Kc0 9c3/8h1 8d1 7d2 Td2 Ts4/5d0 5c0 5s0 Jc3 2s4",
            "win": -0.4,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:40:52",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000070-1": [
        {
            "inFantasy": true,
            "result": -20,
            "playerName": "pid695998",
            "orderIndex": 0,
            "hero": false,
            "dead": "2c0 4s1 6c2",
            "rows": "Qh0 Qc0 Kc0/7h0 8d0 9c0 Th0 Jh0/2d0 4d0 6d0 Td0 Jd0",
            "win": -4,
            "playerId": "pid695998"
        },
        {
            "inFantasy": true,
            "result": 20,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "3d0 9d0",
            "rows": "7d0 7c0 7s0/2h0 3h0 4h0 6h0 Kh0/5d0 5c0 5s0 Qd0 Qs0",
            "win": 3.9,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:41:34",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000071-1": [
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid695998",
            "orderIndex": 1,
            "hero": false,
            "dead": "3h1 8d2 Jc3 7h4",
            "rows": "Qd3 Kd3 4s4/2h0 6c0 2c1 7c2 7s2/8s0 9c0 Js0 Qh1 9d4",
            "win": -3.8,
            "playerId": "pid695998"
        },
        {
            "inFantasy": true,
            "result": 19,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "5c0 6h0",
            "rows": "Kc0 Ah0 Ad0/8h0 Th0 Ts0 Qc0 Qs0/2d0 4d0 5d0 6d0 Jd0",
            "win": 3.7,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:42:18",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000072-1": [
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "6h1 Kd2 7h3 Kc4",
            "rows": "Ks0 Ac1 As3/7c0 8c1 Th2 Td2 8h3/4d0 4c0 Qc0 9d4 9s4",
            "win": -4,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": 4,
            "playerName": "pid695998",
            "orderIndex": 1,
            "hero": false,
            "dead": "4s1 Jc2 5s3 3c4",
            "rows": "Qs1 5h4 6d4/6c0 Ts0 9c1 Jd3 Js3/5d0 Qd0 Ad0 3d2 7d2",
            "win": 0.8,
            "playerId": "pid695998"
        },
        {
            "inFantasy": false,
            "result": 16,
            "playerName": "pid5684226",
            "orderIndex": 2,
            "hero": true,
            "dead": "8s1 8d2 6s3 5c4",
            "rows": "Tc1 2h4 2c4/2d0 7s0 3h2 3s2 2s3/Jh0 Qh0 Kh0 Ah1 9h3",
            "win": 3.1,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:43:55",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000073-1": [
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "6d1 6h2 4d3 2h4",
            "rows": "Tc2 As3 Ks4/2d0 5d0 5c0 7c1 2c2/Qh0 Qc0 Jc1 9s3 Jd4",
            "win": -2,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "Kh1 7s2 8s3 Qd4",
            "rows": "Ad1 Kc2 Ac3/4c0 8d0 9d1 9c3 8h4/6c0 6s0 Th0 Ts2 7h4",
            "win": 1.9,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:44:49",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000074-1": [
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "9h1 Tc2 7h3 6h4",
            "rows": "Ac0 9c3 Th4/6d0 4c1 5h1 2h2 3s3/4s0 5s0 9s0 Ks2 Jh4",
            "win": -3.6,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": true,
            "result": 18,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "8h0 7c0 Qh0",
            "rows": "3h0 3d0 Kh0/2s0 6s0 7s0 8s0 Qs0/5d0 9d0 Td0 Jd0 Ad0",
            "win": 3.5,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:45:26",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000075-1": [
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid1087966",
            "orderIndex": 2,
            "hero": false,
            "dead": "7s1 7d2 9c3 6d4",
            "rows": "As0 9h2 Kh3/2d0 3h0 5s1 Ah3 2c4/Js0 Qd0 Qs1 4d2 Ad4",
            "win": -3.8,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": 17,
            "playerName": "pid1503276",
            "orderIndex": 0,
            "hero": false,
            "dead": "7h1 Qh2 Ac3 5c4",
            "rows": "Ks0 Kd1 Jh4/5h0 6s0 8d2 8s2 6h3/3c0 Tc0 Jc1 3s3 3d4",
            "win": 3.3,
            "playerId": "pid1503276"
        },
        {
            "inFantasy": false,
            "result": 2,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "8h1 Jd2 4h3 2s4",
            "rows": "5d3 Th4 Kc4/2h0 Ts0 9d1 9s2 Td3/6c0 7c0 Qc0 8c1 4c2",
            "win": 0.4,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:47:09",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000076-1": [
        {
            "inFantasy": false,
            "result": -24,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "Kh1 8h2 3h3 4c4",
            "rows": "Ah0 5s2 8s2/7d0 Jd0 Qd1 3c4 Kd4/6c0 Qc0 Tc1 Th3 Td3",
            "win": -4.8,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": true,
            "result": 48,
            "playerName": "pid1503276",
            "orderIndex": 2,
            "hero": false,
            "dead": "3s0 2d1",
            "rows": "8d0 9c0 Ts0/4h0 4d0 4s0 6h0 6s0/Jh0 Jc0 Ad0 Ac0 As0",
            "win": 9.3,
            "playerId": "pid1503276"
        },
        {
            "inFantasy": false,
            "result": -24,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "2s1 Qs2 2c3 Ks4",
            "rows": "Kc2 3d3 Js4/7s0 8c0 5c1 5d2 9d3/2h0 9h0 Qh0 5h1 6d4",
            "win": -4.8,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:48:09",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000077-1": [
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "3c1 9d2 2d3 5d4",
            "rows": "Ac0 2c4 9c4/3s0 4c0 5s0 3h1 4s2/Th0 Jh1 Qh2 6h3 8h3",
            "win": -2,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": 8,
            "playerName": "pid1503276",
            "orderIndex": 1,
            "hero": false,
            "dead": "Js1 Kd2 Jd3 5h4",
            "rows": "Ad0 Ks1 9s4/7h0 3d1 7c2 2h3 2s3/6d0 6c0 Td0 Ts2 Tc4",
            "win": 1.6,
            "playerId": "pid1503276"
        },
        {
            "inFantasy": false,
            "result": 2,
            "playerName": "pid5684226",
            "orderIndex": 2,
            "hero": true,
            "dead": "5c1 9h2 7s3 8s4",
            "rows": "Qd0 Jc1 Qs3/Kh0 Kc0 6s3 Qc4 As4/4h0 Ah0 4d1 8d2 8c2",
            "win": 0.4,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:49:25",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000078-1": [
        {
            "inFantasy": false,
            "result": 39,
            "playerName": "pid1087966",
            "orderIndex": 2,
            "hero": false,
            "dead": "Kd1 5d2 2s3 2h4",
            "rows": "Ac0 4c3 8c4/5h0 5c1 5s2 7s2 7c4/9d0 9c0 Jd0 9h1 9s3",
            "win": 7.6,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": -46,
            "playerName": "pid1503276",
            "orderIndex": 0,
            "hero": false,
            "dead": "8h1 6c2 Kc3 Ts4",
            "rows": "Kh1 Td2 Qc2/3c0 7d0 2c1 7h3 3s4/4s0 8s0 Qs0 4d3 Jc4",
            "win": -9.2,
            "playerId": "pid1503276"
        },
        {
            "inFantasy": true,
            "result": 7,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "Tc0",
            "rows": "Js0 Ks0 As0/2d0 3d0 6d0 8d0 Qd0/3h0 6h0 Jh0 Qh0 Ah0",
            "win": 1.4,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:50:17",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000079-1": [
        {
            "inFantasy": false,
            "result": 39,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "9h1 7c2 9d3 Ts4",
            "rows": "Kc0 Ah4 Ad4/7s0 8d0 8c1 5c2 5s2/4h0 4s0 Tc1 4d3 4c3",
            "win": 7.6,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": -37,
            "playerName": "pid1503276",
            "orderIndex": 2,
            "hero": false,
            "dead": "8s1 8h2 6s3 5d4",
            "rows": "As0 5h2 Th3/2s0 3c0 7d1 9s3 9c4/Qd0 Kd0 Qs1 Jc2 Ks4",
            "win": -7.4,
            "playerId": "pid1503276"
        },
        {
            "inFantasy": false,
            "result": -2,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qc1 3s2 2c3 6d4",
            "rows": "Td1 Ac2 6h4/6c0 Jd0 Jh2 2d3 Js4/2h0 3h0 Qh0 Kh1 7h3",
            "win": -0.4,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:51:22",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000080-1": [
        {
            "inFantasy": true,
            "result": 56,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "Tc0 8h1 5c2",
            "rows": "Jh0 Jd0 Qc0/2s0 3s0 4s0 9s0 Qs0/4h0 6h0 6d0 6c0 6s0",
            "win": 10.9,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid1503276",
            "orderIndex": 1,
            "hero": false,
            "dead": "3d1 5h2 5s3 Qd4",
            "rows": "Kd1 Ad1 Ts3/7c0 8s0 8c2 4d3 Kc4/2h0 Qh0 Kh0 9h2 Th4",
            "win": -3.2,
            "playerId": "pid1503276"
        },
        {
            "inFantasy": false,
            "result": -40,
            "playerName": "pid5684226",
            "orderIndex": 2,
            "hero": true,
            "dead": "8d1 7s2 2d3 Ah4",
            "rows": "Ac0 3c3 As3/2c0 3h0 5d0 4c2 Ks4/Js0 9d1 Td1 7d2 Jc4",
            "win": -8,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:52:33",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000081-1": [
        {
            "inFantasy": true,
            "result": 32,
            "playerName": "pid1087966",
            "orderIndex": 2,
            "hero": false,
            "dead": "9s0 2h1 Ks2",
            "rows": "7h0 7d0 7c0/2s0 3h0 4d0 5h0 Ad0/6h0 6d0 6s0 8h0 8d0",
            "win": 6.2,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": -2,
            "playerName": "pid1503276",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jc1 3c2 4s3 3s4",
            "rows": "Kc0 Kh2 Qs4/Ts0 Th1 6c2 Ah3 Td4/5d0 5c0 Qc0 Qh1 Qd3",
            "win": -0.4,
            "playerId": "pid1503276"
        },
        {
            "inFantasy": false,
            "result": -30,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "Tc1 5s2 4h3 9c4",
            "rows": "Ac0 Kd2 As4/2c0 8c0 4c1 2d2 8s3/9d0 Js0 Jd1 7s3 Jh4",
            "win": -6,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:53:46",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000082-1": [
        {
            "inFantasy": true,
            "result": -4,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qd0 2d1 8s2",
            "rows": "5d0 5s0 As0/6h0 7h0 8h0 Th0 Kh0/3c0 7c0 Jc0 Qc0 Ac0",
            "win": -0.8,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": true,
            "result": -12,
            "playerName": "pid1503276",
            "orderIndex": 2,
            "hero": false,
            "dead": "7d0 2s1",
            "rows": "Qs0 Ks0 Ah0/5h0 5c0 6d0 6s0 Tc0/8d0 9h0 9d0 9c0 9s0",
            "win": -2.4,
            "playerId": "pid1503276"
        },
        {
            "inFantasy": true,
            "result": 16,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h0 6c0 2c0",
            "rows": "Ts0 Kd0 Kc0/3d0 3s0 7s0 Jd0 Js0/4h0 4d0 4c0 4s0 8c0",
            "win": 3.1,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:54:20",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000083-1": [
        {
            "inFantasy": false,
            "result": -48,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "3c1 6s2 Qd3 4c4",
            "rows": "7d2 Ac3 Qc4/2s0 5c0 6h0 3h1 4d1/9c0 Qs0 Jd2 8h3 Jc4",
            "win": -9.6,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": true,
            "result": 19,
            "playerName": "pid1503276",
            "orderIndex": 1,
            "hero": false,
            "dead": "Kc0 Th1",
            "rows": "7h0 7s0 As0/3d0 6d0 8d0 Td0 Ad0/2h0 2d0 2c0 4h0 4s0",
            "win": 3.7,
            "playerId": "pid1503276"
        },
        {
            "inFantasy": true,
            "result": 29,
            "playerName": "pid5684226",
            "orderIndex": 2,
            "hero": true,
            "dead": "8c0 9d0 7c0",
            "rows": "Tc0 Kh0 Kd0/3s0 5s0 8s0 9s0 Ts0/5h0 9h0 Jh0 Qh0 Ah0",
            "win": 5.6,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:55:38",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000084-1": [
        {
            "inFantasy": false,
            "result": 40,
            "playerName": "pid1087966",
            "orderIndex": 2,
            "hero": false,
            "dead": "3c1 Jc2 Qc3 4c4",
            "rows": "Ks2 Kd3 7d4/6s0 9s0 3h1 9d2 6d4/8d0 8s0 Td0 8c1 Tc3",
            "win": 7.8,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid1503276",
            "orderIndex": 0,
            "hero": false,
            "dead": "4h1 3d2 6c3 3s4",
            "rows": "Ad0 7h2 Ah2/2h0 9h0 2c1 5h1 7c4/Qs0 Kc0 Ts3 Jh3 Jd4",
            "win": -4,
            "playerId": "pid1503276"
        },
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "9c1 4s2 2d3 Qd4",
            "rows": "Qh0 Ac1 As2/4d0 Th0 5d1 5s2 5c3/7s0 Js0 Kh3 6h4 8h4",
            "win": -4,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:57:19",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000085-1": [
        {
            "inFantasy": true,
            "result": 31,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "Td0 7c1",
            "rows": "Js0 Qc0 Kd0/4h0 4d0 4s0 6h0 6s0/3h0 3d0 3c0 3s0 5s0",
            "win": 6,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid1503276",
            "orderIndex": 2,
            "hero": false,
            "dead": "Ad1 Ah2 8h3 8s4",
            "rows": "Ac0 As0 7h2/2c0 5d0 6c2 2s4 6d4/Ts0 Kc1 Ks1 Th3 Qd3",
            "win": -2,
            "playerId": "pid1503276"
        },
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "8c1 7s2 9h3 Kh4",
            "rows": "9c2 Qh2 9s4/2h0 5c0 2d3 Jd3 5h4/8d0 9d0 Jc0 7d1 Tc1",
            "win": -4.2,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:58:06",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000086-1": [
        {
            "inFantasy": true,
            "result": 9,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jc0 8c1",
            "rows": "9h0 9s0 Kh0/2s0 3c0 4s0 5h0 Ah0/5d0 7h0 7d0 7c0 7s0",
            "win": 1.7,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": true,
            "result": 53,
            "playerName": "pid1503276",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qh0 3s1 6h2",
            "rows": "Td0 Tc0 Ts0/2d0 8d0 Jd0 Qd0 Ad0/4h0 4d0 4c0 Kc0 Ks0",
            "win": 9,
            "playerId": "pid1503276"
        },
        {
            "inFantasy": false,
            "result": -62,
            "playerName": "pid5684226",
            "orderIndex": 2,
            "hero": true,
            "dead": "3d1 5s2 3h3 6c4",
            "rows": "Kd0 Qc2 Th4/6s0 Ac1 9c2 8s3 As3/2h0 Jh0 Js0 2c1 9d4",
            "win": -11.1,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:59:18",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000087-1": [
        {
            "inFantasy": true,
            "result": 5,
            "playerName": "pid1087966",
            "orderIndex": 2,
            "hero": false,
            "dead": "2h0 3s1",
            "rows": "6h0 7c0 Ts0/4d0 9d0 Td0 Jd0 Qd0/5h0 5c0 5s0 8c0 8s0",
            "win": 1,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": true,
            "result": 33,
            "playerName": "pid1503276",
            "orderIndex": 0,
            "hero": false,
            "dead": "3h0 7d1 2s2",
            "rows": "Ks0 Ah0 As0/4h0 7h0 9h0 Qh0 Kh0/3c0 9c0 Jc0 Qc0 Ac0",
            "win": 6.4,
            "playerId": "pid1503276"
        },
        {
            "inFantasy": false,
            "result": -38,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "6c1 9s2 4c3 3d4",
            "rows": "6d3 Qs3 8h4/2c0 Tc1 Jh1 Th2 Js4/4s0 5d0 6s0 7s0 8d2",
            "win": -7.6,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:00:29",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000088-1": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid1503276",
            "orderIndex": 1,
            "hero": false,
            "dead": "9s1 9c2 6h3 3h4",
            "rows": "Ac0 Qh2 Kd4/8h0 8d1 5c2 8c3 Th3/2d0 Jd0 Qd0 4d1 7d4",
            "win": 2.3,
            "playerId": "pid1503276"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "3d1 4h2 Qc3 9d4",
            "rows": "Kh1 Ks1 6c4/5s0 6d0 9h0 Ts3 2h4/7c0 Jc0 2c2 Jh2 Td3",
            "win": -2.4,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:01:17",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000089-1": [
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid1503276",
            "orderIndex": 0,
            "hero": false,
            "dead": "2s1 5d2 5h3 4d4",
            "rows": "Ah0 Kc2 Ac2/3c0 8s0 Jd1 8c4 Th4/7h0 Qh0 Qs1 6h3 Td3",
            "win": -3.6,
            "playerId": "pid1503276"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "9d1 Jh2 Qd3 As4",
            "rows": "Ad0 Ks1 Kd3/2h0 2c0 3d0 2d2 Qc4/Tc0 7c1 9s2 Jc3 8h4",
            "win": 3.5,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:02:58",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000090-1": [
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid1503276",
            "orderIndex": 1,
            "hero": false,
            "dead": "Kc1 2c2 3d3 Jd4",
            "rows": "As0 Js2 Ad3/4d0 6d0 6c1 3s3 Ks4/5h0 8h0 8s1 8c2 5c4",
            "win": -3.8,
            "playerId": "pid1503276"
        },
        {
            "inFantasy": true,
            "result": 19,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "7s0 2s0",
            "rows": "Qh0 Qs0 Kd0/4h0 4c0 9h0 Jh0 Jc0/3h0 3c0 Th0 Tc0 Ts0",
            "win": 3.7,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:03:40",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000091-1": [
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid1503276",
            "orderIndex": 0,
            "hero": false,
            "dead": "5c1 Th2 4d3 6s4",
            "rows": "As0 Qs2 Ad3/7s0 6d1 8c1 8h2 7d3/9h0 9d0 Jh0 Ts4 Kh4",
            "win": -3.4,
            "playerId": "pid1503276"
        },
        {
            "inFantasy": false,
            "result": 17,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "Ac1 6c2 3s3 5s4",
            "rows": "Qd0 9c4 Qc4/Kd0 Ks0 8s2 Kc2 2s3/5d0 8d0 4c1 6h1 7c3",
            "win": 3.3,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:05:12",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000092-1": [
        {
            "inFantasy": false,
            "result": -11,
            "playerName": "pid1503276",
            "orderIndex": 1,
            "hero": false,
            "dead": "7h1 Th2 5c3 3s4",
            "rows": "Jh1 9c3 6h4/Qh0 Qd0 3h2 3d2 5h3/7d0 8d0 Td0 Kd1 2d4",
            "win": -2.2,
            "playerId": "pid1503276"
        },
        {
            "inFantasy": true,
            "result": 11,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "4h0",
            "rows": "6c0 8h0 Tc0/4s0 6s0 7s0 9s0 Qs0/2h0 2c0 Jd0 Jc0 Js0",
            "win": 2.1,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:05:45",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000093-1": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid1503276",
            "orderIndex": 0,
            "hero": false,
            "dead": "7s1 Js2 8h3 6d4",
            "rows": "8c1 Jc3 Qh3/3c0 5s0 2d1 3d2 Ts4/9s0 Kh0 Kd0 4c2 Qc4",
            "win": 1.2,
            "playerId": "pid1503276"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "Ks1 Td2 Jh3 Ac4",
            "rows": "Qs0 As1 6h4/3h0 7h0 5h2 5c2 5d3/9d0 Jd0 Tc1 8s3 4d4",
            "win": -1.2,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:07:04",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000094-1": [
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid1503276",
            "orderIndex": 1,
            "hero": false,
            "dead": "9h1 4h2 9c3 2c4",
            "rows": "Th2 As2 Ah3/5d0 7h0 8h0 Tc4 Jh4/3d0 3c0 2s1 3h1 2d3",
            "win": -2,
            "playerId": "pid1503276"
        },
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "Kh1 2h2 Qh3 7s4",
            "rows": "Qs0 Ac1 8c4/6h0 8s0 6s1 5h2 6d3/9d0 Td0 Kd2 Qd3 Jc4",
            "win": 1.9,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:08:02",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000095-1": [
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "pid1503276",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jh1 8h2 Th3 5c4",
            "rows": "Ac0 Ks1 Jc2/3s0 6c1 2h2 Qs3 6s4/2d0 4d0 7d0 Qd3 7c4",
            "win": -1,
            "playerId": "pid1503276"
        },
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "3d1 5s2 4h3 2s4",
            "rows": "Qh2 5d3 Ah4/8s0 9h0 Ts0 Td2 8c4/4c0 Qc0 2c1 Tc1 3c3",
            "win": 1,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:09:26",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000096-1": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid1503276",
            "orderIndex": 1,
            "hero": false,
            "dead": "6h1 4d2 2c3 5d4",
            "rows": "Ks0 Ac0 9h4/7d0 7s0 8h2 8d2 9s3/Qc0 3d1 3c1 Jd3 Jc4",
            "win": 1.2,
            "playerId": "pid1503276"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "4h1 6c2 3s3 Qh4",
            "rows": "Ad0 As0 Kd3/5h0 6d0 6s1 4c3 Js4/Th0 Td1 2h2 2d2 8c4",
            "win": -1.2,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:10:22",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000097-1": [
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "pid1503276",
            "orderIndex": 0,
            "hero": false,
            "dead": "8c1 2d2 8s3 3h4",
            "rows": "Kc1 Qd3 Jh4/5d0 7h0 4h2 7s3 Ks4/6d0 6c0 9d0 6h1 6s2",
            "win": 1.7,
            "playerId": "pid1503276"
        },
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "5s1 Td2 Tc3 Jd4",
            "rows": "Ac0 8d3 Qh4/4c0 2s1 5h2 Ah3 Kd4/8h0 9h0 Ts0 Js1 7c2",
            "win": -1.8,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:11:39",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000098-1": [
        {
            "inFantasy": false,
            "result": 2,
            "playerName": "pid1503276",
            "orderIndex": 1,
            "hero": false,
            "dead": "Ah1 6h2 9h3 8s4",
            "rows": "Kh2 Ks3 Td4/3h0 5s0 3c1 5d2 Ts3/8d0 9c0 Th0 7h1 6s4",
            "win": 0.4,
            "playerId": "pid1503276"
        },
        {
            "inFantasy": false,
            "result": -2,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "4c1 Jc2 2c3 6c4",
            "rows": "As0 Kc3 Ac3/3d0 4h0 5h0 5c2 3s4/7s0 Qd1 Qc1 Qh2 Jh4",
            "win": -0.4,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:12:30",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000099-1": [
        {
            "inFantasy": true,
            "result": -13,
            "playerName": "pid1503276",
            "orderIndex": 0,
            "hero": false,
            "dead": "2c0 Jh1",
            "rows": "Kd0 Ks0 As0/4d0 4c0 Td0 Tc0 Qs0/5s0 6c0 7h0 8c0 9h0",
            "win": -2.6,
            "playerId": "pid1503276"
        },
        {
            "inFantasy": true,
            "result": 13,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "3c0 6s0 2s0",
            "rows": "Qc0 Ah0 Ad0/7s0 8s0 9d0 Th0 Jd0/2h0 3h0 4h0 8h0 Qh0",
            "win": 2.5,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:13:26",
    "roomId": "21910272"
}


{
    "stakes": 0.2,
    "handData": {"210330044852-21910272-0000100-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid1503276",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qd1 9d2 Td3 3c4",
            "rows": "Kd1 Kc1 Jd3/3h0 5d0 5h2 Th2 3d3/6s0 8s0 Qs0 Js4 Qc4",
            "win": -1.2,
            "playerId": "pid1503276"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "5c1 8d2 3s3 9c4",
            "rows": "Kh1 Tc2 9s3/2h0 9h0 6d1 Ad2 2c3/4h0 4s0 Jc0 6h4 Ks4",
            "win": 1.2,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:15:22",
    "roomId": "21910272"
}


