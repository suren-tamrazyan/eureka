{
    "stakes": 0.2,
    "handData": {"210330183953-21948833-0000000-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid4053249",
            "orderIndex": 1,
            "hero": false,
            "dead": "Td1 Js2 4c3 3h4",
            "rows": "Ah0 Ac2 Jd3/4h0 4s1 2d2 7c3 2h4/8d0 9c0 Qs0 Qc1 6h4",
            "win": -1.2,
            "playerId": "pid4053249"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "7d1 6s2 9s3 7h4",
            "rows": "Ks1 6c3 Tc4/5c0 9d0 9h1 5d2 Ts2/3s0 Jh0 Jc0 3c3 8c4",
            "win": 1.2,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:41:11",
    "roomId": "21948833"
}


{
    "stakes": 0.2,
    "handData": {"210330183953-21948833-0000001-1": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid4053249",
            "orderIndex": 0,
            "hero": false,
            "dead": "8s1 8d2 4s3 2d4",
            "rows": "Qd1 Kd3 7s4/3h0 6h2 9h2 9c3 6c4/4c0 7c0 Kc0 Ac0 Qc1",
            "win": 0.6,
            "playerId": "pid4053249"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "Js1 Qh2 9s3 7d4",
            "rows": "Ah0 4h3 Jc4/3d0 5h1 5c1 2h3 As4/7h0 8c0 Ts0 9d2 Jd2",
            "win": -0.6,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:42:25",
    "roomId": "21948833"
}


{
    "stakes": 0.2,
    "handData": {"210330183953-21948833-0000002-1": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid4053249",
            "orderIndex": 1,
            "hero": false,
            "dead": "Kc1 5c2 8d3 8c4",
            "rows": "5d2 Qh3 Ad4/3h0 4s0 6s0 3c1 Kd4/Td0 Jh0 8h1 Js2 Jd3",
            "win": 1.2,
            "playerId": "pid4053249"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "6c1 3d2 3s3 Jc4",
            "rows": "Kh0 4h2 4d3/5s0 7d0 6h1 6d1 7c2/Ts0 Qc0 7s3 2c4 9h4",
            "win": -1.2,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:43:25",
    "roomId": "21948833"
}


{
    "stakes": 0.2,
    "handData": {"210330183953-21948833-0000003-1": [
        {
            "inFantasy": false,
            "result": 7,
            "playerName": "pid4053249",
            "orderIndex": 0,
            "hero": false,
            "dead": "9h1 Qc2 9s3 3d4",
            "rows": "Kc0 Ah3 8d4/2h0 4h1 3h2 7h2 Kh4/6d0 7d0 Jd0 9d1 Kd3",
            "win": 1.4,
            "playerId": "pid4053249"
        },
        {
            "inFantasy": false,
            "result": -7,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "2d1 9c2 8c3 2c4",
            "rows": "Ac0 Td2 Ks4/6h0 7c0 5d1 6c1 Qh3/3s0 Js0 6s2 As3 8s4",
            "win": -1.4,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:44:41",
    "roomId": "21948833"
}


{
    "stakes": 0.2,
    "handData": {"210330183953-21948833-0000004-1": [
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "pid4053249",
            "orderIndex": 1,
            "hero": false,
            "dead": "9c1 4c2 6h3 9d4",
            "rows": "Ad1 Jh3 9h4/2h0 4h0 5d0 2s2 5h3/9s0 Js0 Ts1 Ks2 As4",
            "win": -1,
            "playerId": "pid4053249"
        },
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "5s1 2c2 2d3 Qs4",
            "rows": "Kh0 Kc2 Qc4/3s0 4d0 3c1 6s2 6d3/7s0 Th0 7c1 7h3 Jc4",
            "win": 1,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:45:43",
    "roomId": "21948833"
}


{
    "stakes": 0.2,
    "handData": {"210330183953-21948833-0000005-1": [
        {
            "inFantasy": false,
            "result": -13,
            "playerName": "pid4053249",
            "orderIndex": 0,
            "hero": false,
            "dead": "5s1 Ac2 2h3 3d4",
            "rows": "Qs1 Qd3 Ad3/4d0 Ah0 As0 6s1 Kd4/8c0 Js0 9h2 9d2 8d4",
            "win": -2.6,
            "playerId": "pid4053249"
        },
        {
            "inFantasy": true,
            "result": 13,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "2c0 5c0",
            "rows": "Qh0 Kh0 Kc0/2d0 3h0 4c0 5d0 6c0/7d0 8h0 9s0 Ts0 Jd0",
            "win": 2.5,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:46:19",
    "roomId": "21948833"
}


{
    "stakes": 0.2,
    "handData": {"210330183953-21948833-0000006-1": [
        {
            "inFantasy": true,
            "result": 5,
            "playerName": "pid4053249",
            "orderIndex": 1,
            "hero": false,
            "dead": "5c0",
            "rows": "6c0 9d0 9c0/8d0 9s0 Tc0 Jd0 Qd0/4h0 5h0 Jh0 Kh0 Ah0",
            "win": 1,
            "playerId": "pid4053249"
        },
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "7d1 4d2 9h3 Ts4",
            "rows": "Js2 Jc3 Qc3/2d0 5s0 2h1 6h1 2s4/3h0 3c0 8h0 3d2 Th4",
            "win": -1,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:47:06",
    "roomId": "21948833"
}


{
    "stakes": 0.2,
    "handData": {"210330183953-21948833-0000007-1": [
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid4053249",
            "orderIndex": 0,
            "hero": false,
            "dead": "Kd1 3d2 3h3 7h4",
            "rows": "Ad0 Ah1 Kh3/2d0 6s0 Qs2 6c4 7d4/8c0 Kc0 Tc1 7c2 4c3",
            "win": -3.2,
            "playerId": "pid4053249"
        },
        {
            "inFantasy": false,
            "result": 16,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "7s1 8h2 Ts3 4h4",
            "rows": "Ks1 9d2 9c4/3s0 4d0 2c2 5c3 6h3/8s0 Th0 Jd0 9s1 Qc4",
            "win": 3.1,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:48:25",
    "roomId": "21948833"
}


{
    "stakes": 0.2,
    "handData": {"210330183953-21948833-0000008-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid4053249",
            "orderIndex": 1,
            "hero": false,
            "dead": "7h1 4s2 Jd3 7c4",
            "rows": "Ah2 Qd3 Ac3/3h0 5s0 5c1 2h2 5h4/9c0 Js0 Qc0 8s1 Qh4",
            "win": -1.2,
            "playerId": "pid4053249"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "9s1 Ts2 Jc3 8d4",
            "rows": "Kc0 As3 Jh4/6s0 7s0 3s1 3c2 6c2/4h0 8h0 4c1 Tc3 Th4",
            "win": 1.2,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:49:34",
    "roomId": "21948833"
}


