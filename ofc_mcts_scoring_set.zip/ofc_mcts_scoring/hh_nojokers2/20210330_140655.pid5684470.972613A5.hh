{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000172-1": [
        {
            "inFantasy": true,
            "result": 14,
            "playerName": "pid5334816",
            "orderIndex": 0,
            "hero": false,
            "dead": "6d0 6c1 Qc2",
            "rows": "Tc0 Ts0 Ah0/5h0 5d0 5c0 5s0 8d0/Td0 Jd0 Qd0 Kd0 Ad0",
            "win": 2.7,
            "playerId": "pid5334816"
        },
        {
            "inFantasy": true,
            "result": -14,
            "playerName": "pid5118808",
            "orderIndex": 1,
            "hero": false,
            "dead": "6h0 8h1 Kh2",
            "rows": "7h0 7d0 7s0/2h0 2d0 2s0 4d0 4s0/3h0 3d0 3c0 3s0 Ac0",
            "win": -2.8,
            "playerId": "pid5118808"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": false,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 11:06:55",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000173-1": [
        {
            "inFantasy": true,
            "result": -4,
            "playerName": "pid5334816",
            "orderIndex": 1,
            "hero": false,
            "dead": "3c0 4h1 6h2",
            "rows": "8h0 8c0 9d0/9s0 Tc0 Jd0 Qs0 Kd0/5c0 5s0 7h0 7c0 7s0",
            "win": -0.8,
            "playerId": "pid5334816"
        },
        {
            "inFantasy": true,
            "result": 4,
            "playerName": "pid5118808",
            "orderIndex": 0,
            "hero": false,
            "dead": "6c0 8s1 2h2",
            "rows": "Qc0 Ah0 As0/9h0 Td0 Js0 Qh0 Ks0/3d0 5d0 7d0 8d0 Qd0",
            "win": 0.8,
            "playerId": "pid5118808"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": false,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 11:07:41",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000174-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5684470",
            "orderIndex": 0,
            "hero": true,
            "dead": "8s1 8h2 8c3 Tc4",
            "rows": "3s3 Kh4 Ac4/6c0 6s0 Ts1 5s2 6d3/7d0 8d0 Qd0 Kd1 Jd2",
            "win": 0,
            "playerId": "pid5684470"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5334816",
            "orderIndex": 1,
            "hero": false,
            "dead": "4h1 2h2 4d3 3d4",
            "rows": "Ks0 Qc1 Qh3/2d0 Ad0 Td2 As2 4c4/6h0 9c0 9d1 3h3 9h4",
            "win": 0,
            "playerId": "pid5334816"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 11:08:34",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000175-1": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid5684470",
            "orderIndex": 1,
            "hero": true,
            "dead": "5d1 Ts2 2s3 3d4",
            "rows": "2c3 Ah3 As4/Th0 Qd0 Jh1 Jc2 Qh2/5h0 6d0 7c0 4h1 8d4",
            "win": 0.6,
            "playerId": "pid5684470"
        },
        {
            "inFantasy": true,
            "result": -3,
            "playerName": "pid5334816",
            "orderIndex": 0,
            "hero": false,
            "dead": "3c0",
            "rows": "Qc0 Qs0 Ad0/4d0 6c0 7h0 Kh0 Ks0/6h0 7s0 8c0 9h0 Td0",
            "win": -0.6,
            "playerId": "pid5334816"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 11:09:24",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000176-1": [
        {
            "inFantasy": true,
            "result": 25,
            "playerName": "pid5684470",
            "orderIndex": 0,
            "hero": true,
            "dead": "3s0 6c0 Ts0",
            "rows": "Qc0 Qs0 Kc0/5h0 7h0 8h0 Jh0 Qh0/4d0 5d0 9d0 Jd0 Ad0",
            "win": 4.8,
            "playerId": "pid5684470"
        },
        {
            "inFantasy": false,
            "result": -25,
            "playerName": "pid5334816",
            "orderIndex": 1,
            "hero": false,
            "dead": "6h1 6s2 5s3 3h4",
            "rows": "Kd2 Ah2 Th4/8c0 8s0 Td1 Tc1 7d3/2h0 2d0 2c0 Qd3 8d4",
            "win": -5,
            "playerId": "pid5334816"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 11:10:55",
    "roomId": "21938386"
}


