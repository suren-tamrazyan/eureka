{
    "stakes": 10,
    "handData": {"210330224037-21959443-0000000-1": [
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid2813203",
            "orderIndex": 1,
            "hero": false,
            "dead": "2d1 4s2 Qd3 Jd4",
            "rows": "As0 Ts1 Jh4/5s0 6c0 3c1 6d2 3d3/8h0 Kh0 4h2 4d3 4c4",
            "win": -190,
            "playerId": "pid2813203"
        },
        {
            "inFantasy": false,
            "result": 19,
            "playerName": "pid5674822",
            "orderIndex": 0,
            "hero": true,
            "dead": "9c1 3s2 Js3 7s4",
            "rows": "Ad0 Kc3 Ac4/Qs0 9d1 8c2 8s2 Qh4/6h0 7h0 Th0 2h1 Ah3",
            "win": 184,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 20:36:41",
    "roomId": "21959443"
}


{
    "stakes": 10,
    "handData": {"210330224037-21959443-0000001-1": [
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "pid2813203",
            "orderIndex": 0,
            "hero": false,
            "dead": "2h1 3c2 3h3 2c4",
            "rows": "As0 6h3 7d4/Qd0 Jh1 Jc1 Qh2 2s3/5d0 Kd0 Ks0 8d2 7s4",
            "win": -210,
            "playerId": "pid2813203"
        },
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "pid5674822",
            "orderIndex": 1,
            "hero": true,
            "dead": "9h0 2d0 Th0",
            "rows": "Kc0 Ad0 Ac0/4d0 4c0 8h0 8c0 Qc0/3d0 3s0 6d0 6c0 6s0",
            "win": 204,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 20:37:20",
    "roomId": "21959443"
}


{
    "stakes": 10,
    "handData": {"210330224037-21959443-0000002-1": [
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid2813203",
            "orderIndex": 1,
            "hero": false,
            "dead": "Tc1 2h2 5h3 2c4",
            "rows": "Ac0 9d3 7s4/Qd0 Td1 6d2 Ts2 Ad4/2s0 3s0 9s0 4s1 8s3",
            "win": -100,
            "playerId": "pid2813203"
        },
        {
            "inFantasy": false,
            "result": 16,
            "playerName": "pid5674822",
            "orderIndex": 0,
            "hero": true,
            "dead": "7c1 8c2 Qc3 9h4",
            "rows": "Kh0 Qs4 Kd4/6c0 3h1 3c1 8d2 8h3/5d0 5s0 Jh0 Jd2 5c3",
            "win": 97,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 20:39:13",
    "roomId": "21959443"
}


