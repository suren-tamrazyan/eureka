{
    "stakes": 5,
    "handData": {"210330153931-21942718-0000016-1": [
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid3019067",
            "orderIndex": 2,
            "hero": false,
            "dead": "Kh1 5c2 4d3 3s4",
            "rows": "Kd1 Ad2 6d3/3h0 4h0 5s0 3d1 5d2/8c0 Jc0 2c3 2h4 7h4",
            "win": -50,
            "playerId": "pid3019067"
        },
        {
            "inFantasy": false,
            "result": 20,
            "playerName": "pid5688837",
            "orderIndex": 0,
            "hero": true,
            "dead": "3c1 Jh2 4s3 Qc4",
            "rows": "Kc0 9h4 Ac4/6c0 9s0 5h1 Tc2 Ts2/2d0 Qd0 Jd1 7d3 8d3",
            "win": 97,
            "playerId": "pid5688837"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5597356",
            "orderIndex": 1,
            "hero": false,
            "dead": "2s1 7s2 6s3 Th4",
            "rows": "Ks0 Ah2 As3/Td0 Qh1 Qs1 9c3 9d4/4c0 6h0 7c0 8s2 Js4",
            "win": -50,
            "playerId": "pid5597356"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:44:39",
    "roomId": "21942718"
}


{
    "stakes": 5,
    "handData": {"210330153931-21942718-0000017-1": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid3019067",
            "orderIndex": 1,
            "hero": false,
            "dead": "2s1 Qc2 6s3 Ac4",
            "rows": "9h0 Ad0 8s3/7d0 8c0 7c1 5h2 5d2/Ks0 Jh1 Td3 6d4 6c4",
            "win": -60,
            "playerId": "pid3019067"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "pid5688837",
            "orderIndex": 2,
            "hero": true,
            "dead": "Kh1 6h2 8h3 9s4",
            "rows": "Jd2 Ah3 9c4/2h0 4h0 3d1 3s1 2d3/Ts0 Qh0 Qs0 Qd2 Tc4",
            "win": 116.4,
            "playerId": "pid5688837"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5597356",
            "orderIndex": 0,
            "hero": false,
            "dead": "7s1 3c2 3h3 7h4",
            "rows": "Kc1 4d3 Kd4/4c0 4s0 5s0 5c1 2c2/9d0 Jc0 8d2 Js3 As4",
            "win": -60,
            "playerId": "pid5597356"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:46:29",
    "roomId": "21942718"
}


{
    "stakes": 5,
    "handData": {"210330153931-21942718-0000018-1": [
        {
            "inFantasy": false,
            "result": -2,
            "playerName": "pid3019067",
            "orderIndex": 0,
            "hero": false,
            "dead": "7s1 6c2 6h3 2d4",
            "rows": "Ac0 6d3 7d4/Jh0 Jd1 Qs1 Tc2 Ts3/9h0 9s0 Kc0 9d2 2s4",
            "win": -10,
            "playerId": "pid3019067"
        },
        {
            "inFantasy": false,
            "result": 23,
            "playerName": "pid5688837",
            "orderIndex": 1,
            "hero": true,
            "dead": "5c1 Ks2 8d3 Td4",
            "rows": "As0 9c3 Ah3/3h0 5s0 5h1 3c2 8c4/7h0 7c0 Qd1 Qc2 2h4",
            "win": 111.5,
            "playerId": "pid5688837"
        },
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "pid5597356",
            "orderIndex": 2,
            "hero": false,
            "dead": "Jc1 Js2 3s3 4d4",
            "rows": "Kh0 3d2 Kd3/2c0 4c0 5d0 4s1 4h3/8s0 6s1 8h2 Th4 Ad4",
            "win": -105,
            "playerId": "pid5597356"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:48:13",
    "roomId": "21942718"
}


{
    "stakes": 5,
    "handData": {"210330153931-21942718-0000019-1": [
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid3019067",
            "orderIndex": 2,
            "hero": false,
            "dead": "3h1 7d2 2c3 4d4",
            "rows": "Jd1 Th4 Td4/2s0 9d0 Ts2 Jh3 Js3/5h0 5d0 Qs0 Qd1 Qh2",
            "win": -70,
            "playerId": "pid3019067"
        },
        {
            "inFantasy": true,
            "result": 73,
            "playerName": "pid5688837",
            "orderIndex": 0,
            "hero": true,
            "dead": "Tc0 9h0 4h0",
            "rows": "Qc0 Ac0 As0/8h0 8d0 8s0 Kh0 Ks0/3s0 4s0 5s0 6s0 7s0",
            "win": 345,
            "playerId": "pid5688837"
        },
        {
            "inFantasy": false,
            "result": -59,
            "playerName": "pid5597356",
            "orderIndex": 1,
            "hero": false,
            "dead": "6h1 8c2 6d3 7h4",
            "rows": "Kd0 Kc0 Ah4/2d0 3d0 2h1 4c2 6c4/Jc0 Ad1 7c2 9c3 9s3",
            "win": -285,
            "playerId": "pid5597356"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:49:26",
    "roomId": "21942718"
}


{
    "stakes": 5,
    "handData": {"210330153931-21942718-0000020-1": [
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid3019067",
            "orderIndex": 0,
            "hero": false,
            "dead": "5s1 8h2 Th3 7s4",
            "rows": "Ah2 Js3 Ad4/2c0 3d0 8c0 3s1 2d4/6h0 Qh0 Qd1 6c2 Qc3",
            "win": -75,
            "playerId": "pid3019067"
        },
        {
            "inFantasy": true,
            "result": 15,
            "playerName": "pid5688837",
            "orderIndex": 1,
            "hero": true,
            "dead": "8s0 8d0 3c0",
            "rows": "Jh0 Jd0 Jc0/2h0 3h0 4c0 5h0 6d0/9h0 9d0 9c0 Td0 Ts0",
            "win": 72.7,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:49:59",
    "roomId": "21942718"
}


{
    "stakes": 5,
    "handData": {"210330153931-21942718-0000021-1": [
        {
            "inFantasy": true,
            "result": -6,
            "playerName": "pid3019067",
            "orderIndex": 1,
            "hero": false,
            "dead": "7h0 8c1 2s2",
            "rows": "9c0 9s0 Tc0/Ts0 Js0 Qh0 Kh0 Ah0/2d0 4d0 6d0 7d0 Jd0",
            "win": -30,
            "playerId": "pid3019067"
        },
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "pid5688837",
            "orderIndex": 0,
            "hero": true,
            "dead": "4c0 2h0 4h0",
            "rows": "Qd0 Qc0 Ac0/5s0 7c0 7s0 8h0 8d0/3h0 3d0 3c0 3s0 Kd0",
            "win": 29.1,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:50:35",
    "roomId": "21942718"
}


{
    "stakes": 5,
    "handData": {"210330153931-21942718-0000022-1": [
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid3019067",
            "orderIndex": 0,
            "hero": false,
            "dead": "3d1 2s2 Ad3 Ah4",
            "rows": "Kh0 Kd1 4h3/5s0 7d0 Ac2 As3 7h4/9s0 Th0 Qc1 9c2 9h4",
            "win": -40,
            "playerId": "pid3019067"
        },
        {
            "inFantasy": true,
            "result": 8,
            "playerName": "pid5688837",
            "orderIndex": 1,
            "hero": true,
            "dead": "2h0 2d0 3s0",
            "rows": "6c0 8h0 8c0/3c0 4c0 5c0 Tc0 Jc0/4d0 5d0 6d0 9d0 Qd0",
            "win": 38.8,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:51:17",
    "roomId": "21942718"
}


{
    "stakes": 5,
    "handData": {"210330153931-21942718-0000023-1": [
        {
            "inFantasy": true,
            "result": 16,
            "playerName": "pid3019067",
            "orderIndex": 1,
            "hero": false,
            "dead": "5s0 2h1",
            "rows": "7d0 8c0 Jc0/Ts0 Js0 Qs0 Kd0 Ah0/4h0 4d0 4s0 6h0 6d0",
            "win": 77.6,
            "playerId": "pid3019067"
        },
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid5688837",
            "orderIndex": 0,
            "hero": true,
            "dead": "5d1 Qd2 8h3 Ac4",
            "rows": "Qh0 Qc1 5c2/4c0 6c0 2s2 2c4 8s4/3s0 7s0 3h1 3d3 3c3",
            "win": -80,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:52:08",
    "roomId": "21942718"
}


