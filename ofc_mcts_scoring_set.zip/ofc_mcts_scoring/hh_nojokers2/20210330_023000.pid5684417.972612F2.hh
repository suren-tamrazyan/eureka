{
    "stakes": 10,
    "handData": {"210330010918-21899037-0000000-1": [
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid2813203",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qh1 6d2 3d3 6h4",
            "rows": "Kh0 Ad3 8s4/5d0 Td0 9s1 5s2 7d4/7c0 Qc0 6c1 Kc2 3c3",
            "win": 97,
            "playerId": "pid2813203"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5680756",
            "orderIndex": 0,
            "hero": false,
            "dead": "2c1 5c2 Th3 9d4",
            "rows": "Kd0 As1 Ac2/2h0 2s0 4d0 2d1 3h3/7h0 8d2 8c3 Tc4 Ks4",
            "win": -100,
            "playerId": "pid5680756"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": false,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:30:00",
    "roomId": "21899037"
}


{
    "stakes": 10,
    "handData": {"210330010918-21899037-0000001-1": [
        {
            "inFantasy": false,
            "result": 13,
            "playerName": "pid5680756",
            "orderIndex": 1,
            "hero": false,
            "dead": "4s1 8d2 6h3 9d4",
            "rows": "Qh0 Qc0 9h4/2d0 Ks0 Kh1 As3 Js4/6c0 4h1 Td2 Tc2 Ts3",
            "win": 126,
            "playerId": "pid5680756"
        },
        {
            "inFantasy": false,
            "result": -13,
            "playerName": "pid5684417",
            "orderIndex": 0,
            "hero": true,
            "dead": "3s1 5d2 9c3 7h4",
            "rows": "Ah2 4c3 7s3/5s0 8c0 5c1 6s2 Ac4/2h0 2c0 Qd0 Th1 Qs4",
            "win": -130,
            "playerId": "pid5684417"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:31:17",
    "roomId": "21899037"
}


{
    "stakes": 10,
    "handData": {"210330010918-21899037-0000002-1": [
        {
            "inFantasy": true,
            "result": -8,
            "playerName": "pid5680756",
            "orderIndex": 0,
            "hero": false,
            "dead": "2s0",
            "rows": "3d0 3s0 Qd0/5h0 6h0 9h0 Jh0 Qh0/2c0 4c0 9c0 Kc0 Ac0",
            "win": -80,
            "playerId": "pid5680756"
        },
        {
            "inFantasy": false,
            "result": 8,
            "playerName": "pid5684417",
            "orderIndex": 1,
            "hero": true,
            "dead": "Js1 Jc2 6s3 Jd4",
            "rows": "As0 Qc2 Qs4/4s0 5c0 5s1 6c2 5d3/8h0 8s0 8c1 3c3 8d4",
            "win": 78,
            "playerId": "pid5684417"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:32:01",
    "roomId": "21899037"
}


{
    "stakes": 10,
    "handData": {"210330010918-21899037-0000003-1": [
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "pid5680756",
            "orderIndex": 1,
            "hero": false,
            "dead": "5d1 Kd2 4s3 5s4",
            "rows": "7s3 Js3 7c4/9d0 Ts0 6d1 6s2 Td2/4h0 6h0 Jh0 5h1 3h4",
            "win": -90,
            "playerId": "pid5680756"
        },
        {
            "inFantasy": true,
            "result": 9,
            "playerName": "pid5684417",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h0",
            "rows": "3s0 4d0 Ah0/3c0 4c0 5c0 9c0 Jc0/8h0 8s0 Qh0 Qd0 Qs0",
            "win": 87,
            "playerId": "pid5684417"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:32:47",
    "roomId": "21899037"
}


{
    "stakes": 10,
    "handData": {"210330010918-21899037-0000004-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5680756",
            "orderIndex": 0,
            "hero": false,
            "dead": "3h1 7s2 6c3 Jc4",
            "rows": "Kd0 Js2 As4/7c0 7d1 8d1 4c2 4s3/5d0 5s0 Qh0 8s3 Td4",
            "win": 0,
            "playerId": "pid5680756"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5684417",
            "orderIndex": 1,
            "hero": true,
            "dead": "5h1 Kh2 Ts3 Qs4",
            "rows": "Ad0 Ac0 6h3/3c0 Ah2 2s3 6d4 6s4/9s0 Jh0 Qc1 Ks1 Th2",
            "win": 0,
            "playerId": "pid5684417"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:34:06",
    "roomId": "21899037"
}


{
    "stakes": 10,
    "handData": {"210330010918-21899037-0000005-1": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5680756",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qs1 3s2 3d3 6s4",
            "rows": "As0 Ac3 2h4/2d0 4c0 2c1 4d1 7s3/9s0 Jd0 8s2 Jh2 8d4",
            "win": 58,
            "playerId": "pid5680756"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5684417",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ts1 9h2 Kd3 9d4",
            "rows": "Qd0 Ks2 Td3/2s0 5d0 3h1 Qh3 Ah4/Tc0 Jc0 Kc1 5c2 3c4",
            "win": -60,
            "playerId": "pid5684417"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:35:31",
    "roomId": "21899037"
}


{
    "stakes": 10,
    "handData": {"210330010918-21899037-0000006-1": [
        {
            "inFantasy": true,
            "result": 19,
            "playerName": "pid5680756",
            "orderIndex": 0,
            "hero": false,
            "dead": "4s0 2c1 3c2",
            "rows": "5c0 6c0 6s0/2d0 8d0 9d0 Jd0 Qd0/4h0 6h0 7h0 8h0 Kh0",
            "win": 184,
            "playerId": "pid5680756"
        },
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid5684417",
            "orderIndex": 1,
            "hero": true,
            "dead": "2h1 Qc2 Ah3 8s4",
            "rows": "Ks0 As1 Ad2/7d0 7c0 9c3 9s3 4c4/Th0 Jh0 Tc1 Qh2 3d4",
            "win": -190,
            "playerId": "pid5684417"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:36:20",
    "roomId": "21899037"
}


{
    "stakes": 10,
    "handData": {"210330010918-21899037-0000007-1": [
        {
            "inFantasy": false,
            "result": 14,
            "playerName": "pid5680756",
            "orderIndex": 1,
            "hero": false,
            "dead": "Th1 Td2 4h3 Ah4",
            "rows": "Ac1 Qs2 Ad4/5d0 9h1 8d2 6d3 7c3/2c0 8c0 9c0 Qc0 6c4",
            "win": 136,
            "playerId": "pid5680756"
        },
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid5684417",
            "orderIndex": 0,
            "hero": true,
            "dead": "7s1 5c2 8h3 6s4",
            "rows": "Ts1 As2 5s3/4d0 7d0 Qd1 4c4 Js4/2h0 Qh0 Kh0 5h2 Jh3",
            "win": -140,
            "playerId": "pid5684417"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:37:41",
    "roomId": "21899037"
}


{
    "stakes": 10,
    "handData": {"210330010918-21899037-0000008-1": [
        {
            "inFantasy": true,
            "result": 24,
            "playerName": "pid5680756",
            "orderIndex": 0,
            "hero": false,
            "dead": "2d0 3h1 5d2",
            "rows": "5h0 Jh0 Jd0/4c0 5c0 7c0 8c0 Tc0/2s0 4s0 7s0 9s0 Qs0",
            "win": 141,
            "playerId": "pid5680756"
        },
        {
            "inFantasy": false,
            "result": -24,
            "playerName": "pid5684417",
            "orderIndex": 1,
            "hero": true,
            "dead": "8s1 6s2 3s3 Qc4",
            "rows": "As0 Ah1 6h3/2c0 6d0 3d1 2h2 6c2/Th0 Ks0 Kd3 7d4 8h4",
            "win": -145,
            "playerId": "pid5684417"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:38:29",
    "roomId": "21899037"
}


{
    "stakes": 10,
    "handData": {"210330010918-21899037-0000009-1": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "pid5680756",
            "orderIndex": 1,
            "hero": false,
            "dead": "8c1 9d2 7c3 8h4",
            "rows": "8s1 3c3 Td3/2c0 4s0 Jd0 4c1 Kd4/5h0 6h0 6d2 6c2 6s4",
            "win": -30,
            "playerId": "pid5680756"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid5684417",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ts1 Ac2 Th3 Js4",
            "rows": "Ks0 Kc3 Qh4/3s0 5c0 2h1 2s1 3d3/7d0 8d0 5d2 Qd2 2d4",
            "win": 29,
            "playerId": "pid5684417"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:39:46",
    "roomId": "21899037"
}


{
    "stakes": 10,
    "handData": {"210330010918-21899037-0000010-1": [
        {
            "inFantasy": false,
            "result": -7,
            "playerName": "pid5680756",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qh1 4c2 4d3 3d4",
            "rows": "As0 Qs3 Kh4/3h0 3s0 Js1 3c2 4h3/6d0 Td0 Tc1 Th2 9d4",
            "win": -70,
            "playerId": "pid5680756"
        },
        {
            "inFantasy": true,
            "result": 7,
            "playerName": "pid5684417",
            "orderIndex": 1,
            "hero": true,
            "dead": "4s0 5c0",
            "rows": "9c0 9s0 Kd0/7d0 7c0 8c0 8s0 Ts0/5h0 6h0 8h0 Jh0 Ah0",
            "win": 68,
            "playerId": "pid5684417"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:40:41",
    "roomId": "21899037"
}


