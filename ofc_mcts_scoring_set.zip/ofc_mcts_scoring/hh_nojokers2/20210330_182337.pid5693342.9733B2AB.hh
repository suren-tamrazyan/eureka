{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000016-1": [
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid5118808",
            "orderIndex": 0,
            "hero": false,
            "dead": "7d1 Qc2 Jd3 6c4",
            "rows": "Ah2 Qd3 Qs4/2h0 2c0 Jh1 Jc1 8s4/4s0 5s0 6s0 3h2 2d3",
            "win": -3.6,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": true,
            "result": 18,
            "playerName": "pid1503276",
            "orderIndex": 1,
            "hero": false,
            "dead": "7s0 2s1",
            "rows": "Ts0 Ad0 As0/4c0 5c0 9c0 Tc0 Kc0/6h0 7h0 9h0 Qh0 Kh0",
            "win": 3.5,
            "playerId": "pid1503276"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": false,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 15:23:37",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000017-1": [
        {
            "inFantasy": true,
            "result": 3,
            "playerName": "pid5118808",
            "orderIndex": 1,
            "hero": false,
            "dead": "2s0",
            "rows": "Qs0 Kh0 Ks0/3c0 4d0 7d0 Ah0 As0/8h0 8d0 9h0 Jd0 Js0",
            "win": 0.6,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "pid1503276",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qc1 3h2 4c3 3s4",
            "rows": "Kd0 7c3 Qd4/9c0 8c1 9d2 Jc2 4s4/5h0 5d0 Td0 5s1 Th3",
            "win": -0.6,
            "playerId": "pid1503276"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": false,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 15:24:16",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000018-1": [
        {
            "inFantasy": false,
            "result": -7,
            "playerName": "pid5118808",
            "orderIndex": 0,
            "hero": false,
            "dead": "5s1 2s2 6h3 4d4",
            "rows": "As0 6c3 9c4/Js0 Qh0 Jh1 Ts2 Th4/Kc0 Ks0 8c1 8s2 2h3",
            "win": -1.4,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid5693342",
            "orderIndex": 1,
            "hero": true,
            "dead": "5h1 2c2 9s3 9h4",
            "rows": "Kd0 Qc3 Ad4/2d0 3c0 Ah2 Ac2 Jc3/4c0 4s0 6d1 6s1 7d4",
            "win": -2.8,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "pid1503276",
            "orderIndex": 2,
            "hero": false,
            "dead": "4h1 Kh2 3s3 8h4",
            "rows": "Qd3 Qs3 Jd4/3h0 5d0 5c0 3d1 Td4/8d0 9d0 7c1 7h2 7s2",
            "win": 4.1,
            "playerId": "pid1503276"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 15:25:55",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000019-1": [
        {
            "inFantasy": false,
            "result": -36,
            "playerName": "pid5118808",
            "orderIndex": 2,
            "hero": false,
            "dead": "2h1 Kc2 5h3 6c4",
            "rows": "Ac0 Ts4 Qs4/3c0 7h0 3s1 Th1 7c2/4s0 Js0 Jd2 Td3 Tc3",
            "win": -7.2,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": 13,
            "playerName": "pid5693342",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jh1 As2 7d3 4c4",
            "rows": "2c3 Kd4 Ad4/2d0 4h0 5d1 3h2 6s2/8h0 8s0 9d0 9c1 8c3",
            "win": 2.5,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": true,
            "result": 23,
            "playerName": "pid1503276",
            "orderIndex": 1,
            "hero": false,
            "dead": "9h0",
            "rows": "Qc0 Kh0 Ks0/2s0 3d0 4d0 5c0 Ah0/5s0 6d0 7s0 8d0 9s0",
            "win": 4.5,
            "playerId": "pid1503276"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 15:27:03",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000020-1": [
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid5118808",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qc1 5s2 9c3 3h4",
            "rows": "Kh0 Kd3 Kc4/3s0 7h1 7s2 8s2 8h3/4d0 8d0 9d0 5d1 4s4",
            "win": -3.8,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": 38,
            "playerName": "pid5693342",
            "orderIndex": 2,
            "hero": true,
            "dead": "2d1 Th2 9s3 7d4",
            "rows": "Ad2 Ac3 Qh4/6h0 Jh0 Js0 4h1 6s2/3c0 8c0 Jc1 2c3 Tc4",
            "win": 7.4,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid1503276",
            "orderIndex": 0,
            "hero": false,
            "dead": "4c1 6d2 6c3 7c4",
            "rows": "Ks0 As1 Ah4/2h0 5h0 2s2 5c3 Ts3/Jd0 Qd0 3d1 Td2 Qs4",
            "win": -3.8,
            "playerId": "pid1503276"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 15:28:59",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000021-1": [
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid5118808",
            "orderIndex": 0,
            "hero": false,
            "dead": "Td1 3d2 Jd3 3s4",
            "rows": "As0 Kh2 Kd3/5h0 6h0 2h1 6d2 2s4/4d0 4c0 8d1 4h3 Qs4",
            "win": -3.4,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": true,
            "result": 13,
            "playerName": "pid5693342",
            "orderIndex": 1,
            "hero": true,
            "dead": "Js0 8h0 9h0",
            "rows": "Qd0 Qc0 Ad0/2d0 3h0 4s0 5c0 6s0/2c0 3c0 7c0 9c0 Jc0",
            "win": 2.5,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": false,
            "result": 4,
            "playerName": "pid1503276",
            "orderIndex": 2,
            "hero": false,
            "dead": "9d1 7h2 8s3 7s4",
            "rows": "Ah0 Ac2 Kc4/5s0 6c0 5d1 Tc3 Ts3/Th0 Jh0 9s1 Qh2 Ks4",
            "win": 0.8,
            "playerId": "pid1503276"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 15:29:58",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000022-1": [
        {
            "inFantasy": true,
            "result": 31,
            "playerName": "pid5118808",
            "orderIndex": 2,
            "hero": false,
            "dead": "Qd0 Ks1",
            "rows": "6d0 6c0 6s0/3c0 5c0 9c0 Jc0 Ac0/2h0 4h0 8h0 Qh0 Ah0",
            "win": 6,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": -64,
            "playerName": "pid5693342",
            "orderIndex": 0,
            "hero": true,
            "dead": "9h1 7d2 5h3 6h4",
            "rows": "Qs2 4d3 Td4/2c0 2s0 8c0 5d1 8s2/3d0 Jd0 3h1 3s3 5s4",
            "win": -12.8,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": true,
            "result": 33,
            "playerName": "pid1503276",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jh0 Qc1 2d2",
            "rows": "Kh0 Kd0 Ad0/4c0 4s0 7h0 7c0 7s0/9d0 9s0 Th0 Tc0 Ts0",
            "win": 6.4,
            "playerId": "pid1503276"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 15:30:49",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000023-1": [
        {
            "inFantasy": true,
            "result": 40,
            "playerName": "pid5118808",
            "orderIndex": 1,
            "hero": false,
            "dead": "6s0 7s1",
            "rows": "8c0 Kh0 Ac0/3d0 4d0 5d0 7d0 9d0/2h0 2d0 2s0 Qc0 Qs0",
            "win": 7.8,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid5693342",
            "orderIndex": 2,
            "hero": true,
            "dead": "8d1 4s2 3s3 Jc4",
            "rows": "Qd0 Qh1 Jh4/7h2 8s2 9c3 Tc3 5c4/7c0 8h0 9h0 Ts0 6d1",
            "win": -4,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid1503276",
            "orderIndex": 0,
            "hero": false,
            "dead": "6c1 6h2 Ad3 Th4",
            "rows": "Ah0 As0 3h3/2c0 4c1 4h2 5s2 9s4/Kd0 Kc0 Ks1 Js3 Jd4",
            "win": -4,
            "playerId": "pid1503276"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 15:32:27",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000024-1": [
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "pid5118808",
            "orderIndex": 0,
            "hero": false,
            "dead": "4h1 4s2 5c3 7c4",
            "rows": "2h3 9h3 2d4/5h0 5s0 8d1 8s1 4d2/8c0 9d0 Ts0 Jd2 Qh4",
            "win": 1.7,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": 7,
            "playerName": "pid5693342",
            "orderIndex": 1,
            "hero": true,
            "dead": "2c1 9s2 6h3 6s4",
            "rows": "Kd1 Ah3 8h4/Td0 Tc1 Js2 Qd3 Jh4/4c0 5d0 6c0 7s0 3h2",
            "win": 1.4,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid1503276",
            "orderIndex": 2,
            "hero": false,
            "dead": "6d1 Qs2 3s3 3d4",
            "rows": "Ad0 Qc3 Th4/9c0 Jc0 7d1 7h2 As4/Kh0 Kc0 2s1 Ks2 3c3",
            "win": -3.2,
            "playerId": "pid1503276"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 15:34:16",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000025-1": [
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid5118808",
            "orderIndex": 2,
            "hero": false,
            "dead": "2h1 8h2 2c3 2s4",
            "rows": "Ah0 Qc3 Qd4/6c0 7s0 8c2 4h3 Kh4/2d0 Td0 9d1 Jd1 4d2",
            "win": -2.8,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": 28,
            "playerName": "pid5693342",
            "orderIndex": 0,
            "hero": true,
            "dead": "7c1 8d2 Th3 3s4",
            "rows": "Kd0 Qs3 Kc3/5h0 9h0 6h1 5c2 9s4/Jh0 Js0 4c1 4s2 3d4",
            "win": 5.4,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid1503276",
            "orderIndex": 1,
            "hero": false,
            "dead": "5s1 5d2 8s3 Jc4",
            "rows": "Ad0 Ac3 As4/6d0 7d0 6s1 3c2 7h3/9c0 Ks0 Ts1 Tc2 Qh4",
            "win": -2.8,
            "playerId": "pid1503276"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 15:35:57",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000026-1": [
        {
            "inFantasy": false,
            "result": -30,
            "playerName": "pid5118808",
            "orderIndex": 1,
            "hero": false,
            "dead": "4s1 9s2 6d3 7s4",
            "rows": "Ac0 As2 Qs3/3d0 8c0 Js2 Jh3 5s4/Td0 Kh0 Ts1 Kc1 Qh4",
            "win": -6,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": true,
            "result": 60,
            "playerName": "pid5693342",
            "orderIndex": 2,
            "hero": true,
            "dead": "2h0 3s0",
            "rows": "7c0 Ah0 Ad0/4h0 5h0 5d0 Th0 Tc0/2c0 3c0 4c0 5c0 6c0",
            "win": 11.6,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": false,
            "result": -30,
            "playerName": "pid1503276",
            "orderIndex": 0,
            "hero": false,
            "dead": "8d1 3h2 7h3 4d4",
            "rows": "9h1 9d2 8s4/Qc0 Qd1 2d2 Jc3 Jd4/6h0 7d0 8h0 9c0 Ks3",
            "win": -6,
            "playerId": "pid1503276"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 15:37:22",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000027-1": [
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid5118808",
            "orderIndex": 0,
            "hero": false,
            "dead": "8h1 4c2 9s3 4h4",
            "rows": "Kd0 Ks1 Ad4/2h0 3s0 2d1 7s3 6h4/9d0 Qs0 Tc2 Jh2 8c3",
            "win": -2.8,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": true,
            "result": 28,
            "playerName": "pid5693342",
            "orderIndex": 1,
            "hero": true,
            "dead": "2c0 5c0",
            "rows": "7h0 8s0 As0/Ts0 Jc0 Qh0 Kh0 Ac0/3d0 6d0 8d0 Td0 Qd0",
            "win": 5.4,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid1503276",
            "orderIndex": 2,
            "hero": false,
            "dead": "7c1 Jd2 6c3 3h4",
            "rows": "7d3 9h3 Ah4/3c0 4d0 5d0 4s1 5s2/Th0 Qc0 9c1 Js2 5h4",
            "win": -2.8,
            "playerId": "pid1503276"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 15:38:37",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000028-1": [
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid5118808",
            "orderIndex": 2,
            "hero": false,
            "dead": "9h1 2c2 9s3 5s4",
            "rows": "As0 Kd3 Jh4/Th0 Qs0 Ts1 3s3 7s4/4c0 Kc0 8c1 3c2 9c2",
            "win": 1,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": -24,
            "playerName": "pid5693342",
            "orderIndex": 0,
            "hero": true,
            "dead": "Kh1 Qc2 Tc3 Td4",
            "rows": "Ad0 Ah1 Qh3/2h0 3d0 2s1 7c2 8d4/8h0 8s0 9d2 Js3 6h4",
            "win": -4.8,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": false,
            "result": 19,
            "playerName": "pid1503276",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jc1 3h2 Ac3 6d4",
            "rows": "Qd0 Ks2 Jd4/4s0 6c0 2d3 4h3 4d4/5d0 5c0 7h1 7d1 5h2",
            "win": 3.7,
            "playerId": "pid1503276"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 15:39:57",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000029-1": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "pid5118808",
            "orderIndex": 1,
            "hero": false,
            "dead": "6d1 Qd2 5s3 4s4",
            "rows": "Ah0 9s1 Jd4/3s0 4d0 7c0 3d2 3h4/Jh0 2c1 Js2 2h3 2s3",
            "win": 2.9,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": -28,
            "playerName": "pid5693342",
            "orderIndex": 2,
            "hero": true,
            "dead": "5d1 8s2 9h3 Jc4",
            "rows": "Ks0 Kd1 8h4/7d0 9d0 Td1 7s2 Ts2/3c0 Ac0 Qh3 Ad3 5h4",
            "win": -5.6,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": false,
            "result": 13,
            "playerName": "pid1503276",
            "orderIndex": 0,
            "hero": false,
            "dead": "7h1 6s2 4h3 9c4",
            "rows": "As0 Kh3 Kc4/4c0 6h0 8d0 6c1 8c2/Qs0 5c1 Tc2 Th3 Qc4",
            "win": 2.5,
            "playerId": "pid1503276"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 15:41:47",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000030-1": [
        {
            "inFantasy": false,
            "result": -28,
            "playerName": "pid5118808",
            "orderIndex": 0,
            "hero": false,
            "dead": "3c1 Ac2 5d3 3d4",
            "rows": "Kh1 Qd3 Qh4/4s0 5h0 6c0 5s1 6d2/9c0 Ts0 Td2 Jh3 7c4",
            "win": -5.6,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": 7,
            "playerName": "pid5693342",
            "orderIndex": 1,
            "hero": true,
            "dead": "Js1 7d2 Tc3 Jd4",
            "rows": "Ks0 Qs3 Ad4/5c0 As0 2h2 4h2 2c4/8d0 9d0 8h1 8s1 9h3",
            "win": 1.4,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "pid1503276",
            "orderIndex": 2,
            "hero": false,
            "dead": "2s0 2d1",
            "rows": "Kd0 Kc0 Ah0/3h0 3s0 4c0 6h0 6s0/7h0 8c0 9s0 Th0 Jc0",
            "win": 4.1,
            "playerId": "pid1503276"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 15:42:59",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000031-1": [
        {
            "inFantasy": false,
            "result": -27,
            "playerName": "pid5118808",
            "orderIndex": 2,
            "hero": false,
            "dead": "Td1 3s2 8d3 6d4",
            "rows": "Ad1 Qs3 Kc3/5d0 7c0 8c1 4d2 6c2/2h0 Jh0 Jd0 7s4 Jc4",
            "win": -5.4,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": 42,
            "playerName": "pid5693342",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ts1 6h2 7d3 8s4",
            "rows": "Ah0 Ac2 4s3/2c1 2s1 3d3 2d4 9d4/4h0 8h0 Qh0 Kh0 7h2",
            "win": 8.1,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid1503276",
            "orderIndex": 1,
            "hero": false,
            "dead": "3h1 5s2 4c3 5c4",
            "rows": "As0 6s2 Js4/3c0 9c0 Th1 Tc1 5h3/Qd0 Kd0 Qc2 Ks3 9s4",
            "win": -3,
            "playerId": "pid1503276"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 15:44:18",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000032-1": [
        {
            "inFantasy": false,
            "result": -25,
            "playerName": "pid5118808",
            "orderIndex": 1,
            "hero": false,
            "dead": "Ts1 Td2 5h3 8s4",
            "rows": "Ad0 Js3 Jh4/3h0 3c0 9c2 9d3 Kh4/9s0 Th0 7s1 8d1 Jd2",
            "win": -5,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": true,
            "result": 53,
            "playerName": "pid5693342",
            "orderIndex": 2,
            "hero": true,
            "dead": "4c0 5s0 6c0",
            "rows": "Qh0 Qd0 Qc0/3d0 4h0 5c0 6h0 7c0/2h0 2d0 2s0 Ah0 Ac0",
            "win": 10.3,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": false,
            "result": -28,
            "playerName": "pid1503276",
            "orderIndex": 0,
            "hero": false,
            "dead": "7d1 3s2 Jc3 Tc4",
            "rows": "As0 7h2 Qs4/2c0 6s1 5d2 4d3 4s3/8h0 8c0 Kc0 Kd1 Ks4",
            "win": -5.6,
            "playerId": "pid1503276"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 15:45:38",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000033-1": [
        {
            "inFantasy": false,
            "result": -24,
            "playerName": "pid5118808",
            "orderIndex": 0,
            "hero": false,
            "dead": "2d1 7c2 3h3 3c4",
            "rows": "As0 6h3 8d3/4s0 Js0 9c1 Jc2 4h4/Tc0 Kc0 Ts1 Td2 Qh4",
            "win": -4.8,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": true,
            "result": 60,
            "playerName": "pid5693342",
            "orderIndex": 1,
            "hero": true,
            "dead": "7d0 3s0 2h0",
            "rows": "8h0 8c0 8s0/9h0 9d0 9s0 Qs0 Kh0/5h0 5d0 5s0 6c0 6s0",
            "win": 11.6,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": false,
            "result": -36,
            "playerName": "pid1503276",
            "orderIndex": 2,
            "hero": false,
            "dead": "Jd1 Ah2 7s3 6d4",
            "rows": "Ac0 Ad1 Qc4/2c0 4c0 2s2 3d2 4d3/Th0 Qd0 Jh1 Ks3 Kd4",
            "win": -7.2,
            "playerId": "pid1503276"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 15:46:44",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000034-1": [
        {
            "inFantasy": false,
            "result": -35,
            "playerName": "pid5118808",
            "orderIndex": 2,
            "hero": false,
            "dead": "6c1 8d2 Js3 2h4",
            "rows": "Kd0 Ac1 As2/3s2 Ks3 Ad3 9d4 Td4/4d0 5d0 6h0 7h0 8c1",
            "win": -7,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": true,
            "result": 53,
            "playerName": "pid5693342",
            "orderIndex": 0,
            "hero": true,
            "dead": "4s0 3c0 2d0",
            "rows": "6s0 7c0 Ts0/3h0 4h0 5h0 Qh0 Ah0/9c0 Tc0 Jc0 Qc0 Kc0",
            "win": 10.3,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid1503276",
            "orderIndex": 1,
            "hero": false,
            "dead": "5c1 8s2 2c3 2s4",
            "rows": "Kh0 Jd2 8h3/6d0 7s0 7d1 5s2 4c3/9h0 9s0 3d1 Th4 Jh4",
            "win": -3.6,
            "playerId": "pid1503276"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 15:47:51",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000035-1": [
        {
            "inFantasy": false,
            "result": -46,
            "playerName": "pid5118808",
            "orderIndex": 1,
            "hero": false,
            "dead": "5c1 4s2 5s3 8c4",
            "rows": "Ad0 As0 Ks4/6c0 3h1 6d2 8d2 6h3/Th0 Jd0 Qs1 Qd3 Ts4",
            "win": -5.2,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": true,
            "result": 25,
            "playerName": "pid5693342",
            "orderIndex": 2,
            "hero": true,
            "dead": "2d0 5h0 6s0",
            "rows": "9d0 Qc0 Ah0/3d0 3c0 3s0 8h0 8s0/7h0 7d0 7c0 Jc0 Js0",
            "win": 4.8,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "pid1503276",
            "orderIndex": 0,
            "hero": false,
            "dead": "7s1 2s2 Jh3 Kd4",
            "rows": "Kh2 Kc4 Ac4/2h0 5d0 4h1 4d1 4c3/9h0 9c0 Tc0 9s2 Td3",
            "win": 0.2,
            "playerId": "pid1503276"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 15:49:04",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000036-1": [
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid5118808",
            "orderIndex": 0,
            "hero": false,
            "dead": "7h1 4h2 Kd3 6d4",
            "rows": "Kc0 Ks0 Qh3/6h0 Ad1 Ac2 8s3 7c4/3h0 3s0 Jd1 Jc2 As4",
            "win": -0.2,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": -52,
            "playerName": "pid5693342",
            "orderIndex": 1,
            "hero": true,
            "dead": "Ts1 8c2 2c3 Ah4",
            "rows": "Tc1 Th2 6s3/5c0 7s0 9h0 9c1 6c4/3d0 4d0 4c2 3c3 4s4",
            "win": -0.2,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": true,
            "result": 68,
            "playerName": "pid1503276",
            "orderIndex": 2,
            "hero": false,
            "dead": "5s0 9s1",
            "rows": "Qd0 Qc0 Qs0/2d0 5d0 8d0 9d0 Td0/2h0 5h0 8h0 Jh0 Kh0",
            "win": 0.4,
            "playerId": "pid1503276"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 15:50:16",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000037-1": [
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid5693342",
            "orderIndex": 1,
            "hero": true,
            "dead": "3s1 2c2 4d3 9d4",
            "rows": "Ad2 Kh3 Ac3/4c0 4s0 6d1 7s2 7d4/8d0 Th0 Js0 Td1 Jh4",
            "win": -0.8,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": true,
            "result": 8,
            "playerName": "pid1503276",
            "orderIndex": 0,
            "hero": false,
            "dead": "8h0 3d1",
            "rows": "Qh0 Kd0 Kc0/2d0 3c0 4h0 5c0 Ah0/5s0 6s0 9s0 Ks0 As0",
            "win": 0.8,
            "playerId": "pid1503276"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 15:51:04",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000038-1": [
        {
            "inFantasy": true,
            "result": 17,
            "playerName": "pid5693342",
            "orderIndex": 0,
            "hero": true,
            "dead": "4s0 3d0 4d0",
            "rows": "Kc0 Ah0 Ad0/5c0 5s0 6s0 Th0 Td0/8h0 9d0 Ts0 Jc0 Qc0",
            "win": 1.6,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid1503276",
            "orderIndex": 1,
            "hero": false,
            "dead": "9s1 Tc2 6d3 6h4",
            "rows": "Ks1 7h3 Kh4/4h0 6c0 7c1 8c2 5h3/3h0 3s0 Qh0 Qs2 Jd4",
            "win": -1.6,
            "playerId": "pid1503276"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 15:51:51",
    "roomId": "21950775"
}


