{
    "stakes": 20,
    "handData": {"210330122956-21935096-0000000-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid2634961",
            "orderIndex": 1,
            "hero": false,
            "dead": "3s1 5h2 2d3 Jc4",
            "rows": "Ad1 5s2 Ac2/9h0 Td0 4d1 Ts4 Qc4/8d0 8s0 Qs0 8c3 Jh3",
            "win": 0,
            "playerId": "pid2634961"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5684223",
            "orderIndex": 0,
            "hero": true,
            "dead": "5d1 Qd2 4s3 7d4",
            "rows": "Kd0 Kh1 5c4/3h0 9c0 2h2 2s3 4c4/7s0 Js0 Ks1 6s2 As3",
            "win": 0,
            "playerId": "pid5684223"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:21:12",
    "roomId": "21935096"
}


{
    "stakes": 20,
    "handData": {"210330122956-21935096-0000001-1": [
        {
            "inFantasy": false,
            "result": 16,
            "playerName": "pid2634961",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qd1 2d2 Kh3 Qh4",
            "rows": "Ac3 Jh4 Jd4/3c0 4c0 5h0 4d2 5c2/8s0 Js0 3s1 Qs1 9s3",
            "win": 310,
            "playerId": "pid2634961"
        },
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid5684223",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qc1 5d2 8d3 Kc4",
            "rows": "Kd0 8h3 Jc4/2c0 2s1 4s2 9c2 9d3/7c0 8c0 9h0 5s1 7d4",
            "win": -320,
            "playerId": "pid5684223"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:22:35",
    "roomId": "21935096"
}


{
    "stakes": 20,
    "handData": {"210330122956-21935096-0000002-1": [
        {
            "inFantasy": false,
            "result": -2,
            "playerName": "pid2634961",
            "orderIndex": 1,
            "hero": false,
            "dead": "3d1 9h2 Th3 6h4",
            "rows": "Ad0 8h4 Kh4/4c0 8c0 2c1 Tc2 Kc3/3s0 Js0 Qs1 Ts2 Ks3",
            "win": -40,
            "playerId": "pid2634961"
        },
        {
            "inFantasy": false,
            "result": 2,
            "playerName": "pid5684223",
            "orderIndex": 0,
            "hero": true,
            "dead": "7s1 Kd2 4h3 4d4",
            "rows": "As0 Ah1 Jd4/9d0 9s0 5d1 5h3 8d4/6c0 Jc0 5c2 Ac2 7c3",
            "win": 39,
            "playerId": "pid5684223"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:23:27",
    "roomId": "21935096"
}


{
    "stakes": 20,
    "handData": {"210330122956-21935096-0000003-1": [
        {
            "inFantasy": false,
            "result": -23,
            "playerName": "pid2634961",
            "orderIndex": 0,
            "hero": false,
            "dead": "4s1 7d2 9c3 Ah4",
            "rows": "As1 Td3 4h4/3d0 6s0 Qc2 Ks3 3s4/8s0 Tc0 Jh0 7c1 9d2",
            "win": -460,
            "playerId": "pid2634961"
        },
        {
            "inFantasy": true,
            "result": 23,
            "playerName": "pid5684223",
            "orderIndex": 1,
            "hero": true,
            "dead": "2h0 3h0 5h0",
            "rows": "Qh0 Qs0 Kh0/4d0 5d0 6d0 8d0 Ad0/2c0 4c0 6c0 Jc0 Ac0",
            "win": 446,
            "playerId": "pid5684223"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:24:16",
    "roomId": "21935096"
}


{
    "stakes": 20,
    "handData": {"210330122956-21935096-0000004-1": [
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid2634961",
            "orderIndex": 1,
            "hero": false,
            "dead": "3h1 Ts2 2h3 2s4",
            "rows": "Ks1 4h3 4s4/7c0 Jc0 6c2 6h3 2d4/4d0 5d0 Qd0 7d1 8d2",
            "win": 194,
            "playerId": "pid2634961"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5684223",
            "orderIndex": 0,
            "hero": true,
            "dead": "Kc1 Qs2 9c3 Ah4",
            "rows": "Ad1 Kh2 As3/3d0 7h0 3c1 Td2 Th3/2c0 8h0 8c0 5c4 7s4",
            "win": -200,
            "playerId": "pid5684223"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:25:10",
    "roomId": "21935096"
}


{
    "stakes": 20,
    "handData": {"210330122956-21935096-0000005-1": [
        {
            "inFantasy": false,
            "result": -28,
            "playerName": "pid2634961",
            "orderIndex": 0,
            "hero": false,
            "dead": "Tc1 9c2 5s3 6h4",
            "rows": "Qc1 Kc2 Qh4/4c0 2h2 2d3 Ah3 As4/5h0 5d0 Jh0 Jd0 5c1",
            "win": -560,
            "playerId": "pid2634961"
        },
        {
            "inFantasy": false,
            "result": 28,
            "playerName": "pid5684223",
            "orderIndex": 1,
            "hero": true,
            "dead": "3c1 Jc2 Ad3 2c4",
            "rows": "Kd0 Ks3 Td4/8h0 8c1 7d2 8d2 7c4/9s0 Js0 Qs0 Ts1 8s3",
            "win": 543,
            "playerId": "pid5684223"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:26:18",
    "roomId": "21935096"
}


{
    "stakes": 20,
    "handData": {"210330122956-21935096-0000006-1": [
        {
            "inFantasy": true,
            "result": -1,
            "playerName": "pid2634961",
            "orderIndex": 1,
            "hero": false,
            "dead": "3s0",
            "rows": "Th0 Td0 Kc0/2c0 2s0 8c0 9h0 9s0/3d0 4d0 5d0 Jd0 Ad0",
            "win": -20,
            "playerId": "pid2634961"
        },
        {
            "inFantasy": true,
            "result": 1,
            "playerName": "pid5684223",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h0 2d0",
            "rows": "9c0 Ac0 As0/5c0 8d0 8s0 Tc0 Ts0/3h0 6h0 6d0 Qd0 Qs0",
            "win": 19,
            "playerId": "pid5684223"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:26:52",
    "roomId": "21935096"
}


{
    "stakes": 20,
    "handData": {"210330122956-21935096-0000007-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid2634961",
            "orderIndex": 0,
            "hero": false,
            "dead": "2d1 6d2 3h3 9h4",
            "rows": "Ah1 9d2 As3/3d0 8s0 7s1 3s3 3c4/5c0 5s0 Js0 Ts2 Qc4",
            "win": 0,
            "playerId": "pid2634961"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5684223",
            "orderIndex": 1,
            "hero": true,
            "dead": "8c1 Th2 7d3 Jc4",
            "rows": "Kd2 5d3 Tc3/4s0 Qs0 2c1 9c4 Td4/5h0 6h0 8h0 7h1 Jh2",
            "win": 0,
            "playerId": "pid5684223"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:28:14",
    "roomId": "21935096"
}


{
    "stakes": 20,
    "handData": {"210330122956-21935096-0000008-1": [
        {
            "inFantasy": false,
            "result": -2,
            "playerName": "pid2634961",
            "orderIndex": 1,
            "hero": false,
            "dead": "9d1 9h2 Jc3 4d4",
            "rows": "Qs0 Kd3 Qc4/2d0 5c0 2c1 5s3 Tc4/7h0 Ts0 9s1 6s2 8h2",
            "win": -40,
            "playerId": "pid2634961"
        },
        {
            "inFantasy": false,
            "result": 2,
            "playerName": "pid5684223",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ah1 7c2 3d3 6h4",
            "rows": "Ad3 Jh4 Kc4/2h0 3s0 4h0 6c2 5h3/8d0 Qd0 8c1 8s1 Qh2",
            "win": 39,
            "playerId": "pid5684223"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:29:14",
    "roomId": "21935096"
}


{
    "stakes": 20,
    "handData": {"210330122956-21935096-0000009-1": [
        {
            "inFantasy": true,
            "result": 4,
            "playerName": "pid2634961",
            "orderIndex": 0,
            "hero": false,
            "dead": "5d0",
            "rows": "Qh0 Kd0 Kc0/6s0 8d0 9c0 Ah0 As0/2d0 2s0 4d0 4c0 4s0",
            "win": 78,
            "playerId": "pid2634961"
        },
        {
            "inFantasy": false,
            "result": -4,
            "playerName": "pid5684223",
            "orderIndex": 1,
            "hero": true,
            "dead": "7d1 3s2 6h3 Ks4",
            "rows": "7c2 Qs2 Qc3/2h0 8s1 Td1 Tc4 Ts4/3c0 4h0 6c0 7s0 5h3",
            "win": -80,
            "playerId": "pid5684223"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:30:05",
    "roomId": "21935096"
}


{
    "stakes": 20,
    "handData": {"210330122956-21935096-0000010-1": [
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid2634961",
            "orderIndex": 1,
            "hero": false,
            "dead": "4s1 Ks2 9d3 2d4",
            "rows": "8s1 Kd3 Qh4/2s0 5c0 6c1 6d2 2c3/3h0 3c0 Jd0 Js2 7d4",
            "win": -400,
            "playerId": "pid2634961"
        },
        {
            "inFantasy": true,
            "result": 20,
            "playerName": "pid5684223",
            "orderIndex": 0,
            "hero": true,
            "dead": "3d0",
            "rows": "Kh0 Kc0 Ac0/4c0 6h0 6s0 8d0 8c0/5h0 5d0 Qd0 Qc0 Qs0",
            "win": 388,
            "playerId": "pid5684223"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:30:39",
    "roomId": "21935096"
}


{
    "stakes": 20,
    "handData": {"210330122956-21935096-0000011-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid2634961",
            "orderIndex": 0,
            "hero": false,
            "dead": "9d1 Qc2 8h3 Js4",
            "rows": "Qd0 Qs1 Jh3/2h0 4h0 5c2 4s3 3h4/6c0 7s0 6s1 Tc2 6d4",
            "win": 0,
            "playerId": "pid2634961"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5684223",
            "orderIndex": 1,
            "hero": true,
            "dead": "5s1 Td2 4c3 Kc4",
            "rows": "3c3 7d3 Th4/2s0 4d0 5h0 2d1 5d2/Jc0 Qh0 Jd1 8d2 7h4",
            "win": 0,
            "playerId": "pid5684223"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:32:07",
    "roomId": "21935096"
}


{
    "stakes": 20,
    "handData": {"210330122956-21935096-0000012-1": [
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid2634961",
            "orderIndex": 1,
            "hero": false,
            "dead": "Kc1 2s2 3c3 2c4",
            "rows": "Qs0 Kd3 6d4/4c0 6s0 8d1 4h3 6h4/2h0 7h0 5h1 3h2 Jh2",
            "win": -62,
            "playerId": "pid2634961"
        },
        {
            "inFantasy": false,
            "result": 17,
            "playerName": "pid5684223",
            "orderIndex": 0,
            "hero": true,
            "dead": "8h1 Jc2 8s3 5s4",
            "rows": "Ac0 Ad2 Js4/3d0 3s0 4d0 9s3 9c4/Tc0 7c1 7s1 Ts2 7d3",
            "win": 60,
            "playerId": "pid5684223"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:33:19",
    "roomId": "21935096"
}


