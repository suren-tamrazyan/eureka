{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000012-1": [
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid5693342",
            "orderIndex": 1,
            "hero": true,
            "dead": "4c1 Kd2 5s3 8c4",
            "rows": "Qs1 Kc1 6c4/3d0 9d0 9c2 Ac3 6h4/3h0 7h0 Qh0 4h2 8h3",
            "win": 1.9,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5359358",
            "orderIndex": 0,
            "hero": false,
            "dead": "2c1 Qd2 Th3 Ts4",
            "rows": "Kh0 Ks0 Qc4/As1 3s2 2s3 5c3 Js4/6d0 7s0 8s0 4d1 5h2",
            "win": -2,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:03:41",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000013-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5693342",
            "orderIndex": 0,
            "hero": true,
            "dead": "8s1 2c2 7s3 Qc4",
            "rows": "Kd0 Ad1 Ac3/5c0 9d0 3d2 2d4 6d4/Js0 Qs0 Jh1 Qh2 6s3",
            "win": -1.2,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5359358",
            "orderIndex": 1,
            "hero": false,
            "dead": "7h1 3h2 4h3 8c4",
            "rows": "Ah0 Qd2 Jc3/2h0 8d0 6c1 8h2 9s3/Ts0 Ks0 Th1 Kh4 As4",
            "win": 1.2,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:04:41",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000014-1": [
        {
            "inFantasy": false,
            "result": -7,
            "playerName": "pid5693342",
            "orderIndex": 1,
            "hero": true,
            "dead": "Td1 8c2 4c3 Qh4",
            "rows": "Ah1 5h3 5s4/3h0 3c0 Th1 6d2 6c4/Jc0 Js0 Qc0 9d2 9s3",
            "win": -1.4,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": false,
            "result": 7,
            "playerName": "pid5359358",
            "orderIndex": 0,
            "hero": false,
            "dead": "Ks1 3s2 Kd3 9h4",
            "rows": "Kc1 Ts3 Kh3/2s0 4d0 5d2 5c2 4h4/7h0 7s0 8s0 8d1 2h4",
            "win": 1.4,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:05:45",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000015-1": [
        {
            "inFantasy": false,
            "result": -28,
            "playerName": "pid5693342",
            "orderIndex": 0,
            "hero": true,
            "dead": "7s1 7c2 7d3 Kc4",
            "rows": "Qh0 Qc2 Jc3/4d0 8h0 4s1 2c2 5d4/5s0 9s0 9c1 9h3 3d4",
            "win": -5.6,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": true,
            "result": 28,
            "playerName": "pid5359358",
            "orderIndex": 1,
            "hero": false,
            "dead": "Js0 Jh1",
            "rows": "6h0 6d0 6s0/2h0 3s0 4h0 5h0 As0/3c0 4c0 5c0 8c0 Ac0",
            "win": 5.4,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:06:28",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000016-1": [
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid5693342",
            "orderIndex": 1,
            "hero": true,
            "dead": "4s1 7h2 7d3 Ac4",
            "rows": "Ad0 Ks2 As3/3s0 8c0 5s1 2c4 3h4/6h0 Qh0 6c1 6s2 Kc3",
            "win": -4,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": true,
            "result": 20,
            "playerName": "pid5359358",
            "orderIndex": 0,
            "hero": false,
            "dead": "Th0 Qc1",
            "rows": "9d0 9s0 Kd0/3d0 3c0 4h0 4c0 8s0/5c0 Jh0 Jd0 Jc0 Js0",
            "win": 3.9,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:07:16",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000017-1": [
        {
            "inFantasy": false,
            "result": -24,
            "playerName": "pid5693342",
            "orderIndex": 0,
            "hero": true,
            "dead": "6c1 Jd2 3s3 Kc4",
            "rows": "Kh1 Ac3 8s4/2s0 5d0 5c1 5h2 7d3/7h0 8d0 9c0 Tc2 3d4",
            "win": -4.8,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": true,
            "result": 24,
            "playerName": "pid5359358",
            "orderIndex": 1,
            "hero": false,
            "dead": "8h0 3c1",
            "rows": "Th0 Jc0 As0/2h0 2d0 4d0 4c0 4s0/6h0 6d0 6s0 9d0 9s0",
            "win": 4.7,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:08:06",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000018-1": [
        {
            "inFantasy": false,
            "result": 11,
            "playerName": "pid5693342",
            "orderIndex": 1,
            "hero": true,
            "dead": "9c1 2h2 5c3 9d4",
            "rows": "Ks0 8c3 8d4/Jh0 Ah1 9s2 7d3 Jd4/3c0 5d0 6h0 7c1 4h2",
            "win": 2.1,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": false,
            "result": -11,
            "playerName": "pid5359358",
            "orderIndex": 0,
            "hero": false,
            "dead": "Td1 Qc2 Qh3 2d4",
            "rows": "Kd0 Kh2 Ad3/2c0 2s1 3h1 4d2 4s3/6d0 6c0 8h0 5h4 Kc4",
            "win": -2.2,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:12:02",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000020-1": [
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid5685540",
            "orderIndex": 2,
            "hero": false,
            "dead": "Js1 4d2 6s3 3d4",
            "rows": "Qd0 Qc2 Ks3/3s0 9c0 2d1 2s1 9s2/5h0 Th0 As3 2h4 9h4",
            "win": -3.2,
            "playerId": "pid5685540"
        },
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid5693342",
            "orderIndex": 0,
            "hero": true,
            "dead": "7c1 Qs2 7h3 Ad4",
            "rows": "Kh2 Kc2 Ac3/3h0 6h0 4h1 6c3 Qh4/5c0 5s0 Tc0 5d1 6d4",
            "win": -3.2,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": false,
            "result": 32,
            "playerName": "pid5359358",
            "orderIndex": 1,
            "hero": false,
            "dead": "7s1 Ts2 Jc3 Ah4",
            "rows": "Jh1 2c3 Jd4/3c0 4c0 8c2 8s2 4s4/7d0 9d0 Td0 Kd1 8d3",
            "win": 6.2,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:12:54",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000021-1": [
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid5685540",
            "orderIndex": 1,
            "hero": false,
            "dead": "6h1 7c2 7s3 6d4",
            "rows": "Ah0 Ks1 Td4/5d0 5s0 4s2 2d3 4c4/8h0 Jc0 Qs1 Qh2 8s3",
            "win": -3.8,
            "playerId": "pid5685540"
        },
        {
            "inFantasy": false,
            "result": -31,
            "playerName": "pid5693342",
            "orderIndex": 2,
            "hero": true,
            "dead": "Qc1 Ts2 2c3 Ad4",
            "rows": "Kc0 Qd3 Kd3/6s0 7h0 7d1 Tc2 6c4/8d0 9c0 Jh1 Jd2 5h4",
            "win": -6.2,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": false,
            "result": 50,
            "playerName": "pid5359358",
            "orderIndex": 0,
            "hero": false,
            "dead": "Js1 9d2 Kh3 4h4",
            "rows": "Ac1 As2 8c4/2s0 5c0 9h3 9s3 2h4/3h0 3c0 Th0 3s1 3d2",
            "win": 9.7,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:14:01",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000022-1": [
        {
            "inFantasy": false,
            "result": -40,
            "playerName": "pid5685540",
            "orderIndex": 0,
            "hero": false,
            "dead": "2d1 5d2 9h3 6h4",
            "rows": "Ac0 Ad2 6c4/4h0 8d0 4d1 6s3 8s3/Qs0 Kc0 Th1 Ts2 Js4",
            "win": -4.1,
            "playerId": "pid5685540"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "pid5693342",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qh1 3s2 2h3 Qd4",
            "rows": "Kd0 Kh2 Ah4/7s0 7c1 Td1 9c3 Tc4/3c0 Jd0 Jc0 3d2 3h3",
            "win": 0.3,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": true,
            "result": 19,
            "playerName": "pid5359358",
            "orderIndex": 2,
            "hero": false,
            "dead": "8h0 6d1 9d2",
            "rows": "7h0 7d0 Jh0/2c0 4c0 5c0 8c0 Qc0/4s0 5s0 9s0 Ks0 As0",
            "win": 3.7,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:15:38",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000023-1": [
        {
            "inFantasy": false,
            "result": -33,
            "playerName": "pid5685540",
            "orderIndex": 2,
            "hero": false,
            "dead": "5d1 5c2 Qd3 5s4",
            "rows": "Ac0 Ks1 Kc2/Js0 9s2 2s3 Jh3 Tc4/3h0 Th0 Qh0 7h1 6s4",
            "win": -3.2,
            "playerId": "pid5685540"
        },
        {
            "inFantasy": true,
            "result": 20,
            "playerName": "pid5693342",
            "orderIndex": 0,
            "hero": true,
            "dead": "5h0 3d0",
            "rows": "9h0 Kh0 Kd0/4h0 4d0 7d0 7s0 8s0/2c0 3c0 9c0 Jc0 Qc0",
            "win": 0.6,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": false,
            "result": 13,
            "playerName": "pid5359358",
            "orderIndex": 1,
            "hero": false,
            "dead": "6h1 8h2 3s3 9d4",
            "rows": "Ad0 As0 Jd3/6c0 8d1 8c1 6d3 2d4/Td0 Ts0 4c2 4s2 2h4",
            "win": 2.5,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:16:48",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000024-1": [
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "pid5685540",
            "orderIndex": 1,
            "hero": false,
            "dead": "Js1 Jc2 Tc3 3h4",
            "rows": "Ac2 As2 6c4/2c0 5c0 5s0 8h3 8s4/4d0 Qd0 3d1 9d1 7d3",
            "win": 0,
            "playerId": "pid5685540"
        },
        {
            "inFantasy": false,
            "result": -38,
            "playerName": "pid5693342",
            "orderIndex": 2,
            "hero": true,
            "dead": "7s1 3c2 Ad3 Qc4",
            "rows": "Ks0 Kc1 7c2/2d0 Td2 2s3 Qs3 4s4/5h0 Jh0 Kh0 9h1 3s4",
            "win": -1.2,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": true,
            "result": 20,
            "playerName": "pid5359358",
            "orderIndex": 0,
            "hero": false,
            "dead": "2h0 9c1 5d2",
            "rows": "8d0 8c0 Ah0/9s0 Ts0 Jd0 Qh0 Kd0/4h0 4c0 6h0 6d0 6s0",
            "win": 1.2,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:18:02",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000025-1": [
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "pid5685540",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jc0 5c1 8c2",
            "rows": "Qd0 Qc0 Qs0/2h0 2c0 2s0 7h0 7s0/3h0 3c0 3s0 Ah0 As0",
            "win": 4.4,
            "playerId": "pid5685540"
        },
        {
            "inFantasy": false,
            "result": -30,
            "playerName": "pid5359358",
            "orderIndex": 1,
            "hero": false,
            "dead": "Kh1 Jh2 6h3 8h4",
            "rows": "Kc1 Ac3 Ks4/4s0 Th0 Ts2 7c3 Td4/2d0 5d0 Kd0 4d1 6d2",
            "win": -4.5,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": false,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:18:37",
    "roomId": "21958502"
}





