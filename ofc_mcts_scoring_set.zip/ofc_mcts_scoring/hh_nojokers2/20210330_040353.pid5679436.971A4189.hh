{
    "stakes": 5,
    "handData": {"210330083706-21922814-0000000-1": [
        {
            "inFantasy": false,
            "result": 19,
            "playerName": "pid742728",
            "orderIndex": 2,
            "hero": false,
            "dead": "Ts1 Jc2 8d3 4s4",
            "rows": "Ac1 7d4 8c4/2d0 4d0 Kd2 4h3 4c3/9s0 Qh0 Qd0 Qs1 9h2",
            "win": 92,
            "playerId": "pid742728"
        },
        {
            "inFantasy": false,
            "result": -24,
            "playerName": "pid4000265",
            "orderIndex": 0,
            "hero": false,
            "dead": "8h1 3c2 Ad3 5s4",
            "rows": "Kc0 Ks2 As2/3d0 3s0 6h1 5c3 5d4/9d0 Jh0 Js1 Qc3 7c4",
            "win": -120,
            "playerId": "pid4000265"
        },
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid5679436",
            "orderIndex": 1,
            "hero": true,
            "dead": "Th1 Kh2 7s3 6s4",
            "rows": "Ah2 Tc3 Jd4/2s0 2h1 2c2 3h3 6d4/5h0 6c0 8s0 9c0 7h1",
            "win": 24,
            "playerId": "pid5679436"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:03:53",
    "roomId": "21922814"
}


{
    "stakes": 5,
    "handData": {"210330083706-21922814-0000001-1": [
        {
            "inFantasy": false,
            "result": 34,
            "playerName": "pid742728",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jc1 4d2 Kc3 7d4",
            "rows": "Qs0 Ad3 Qc4/3d0 Td1 Ts2 6d3 6s4/3h0 6h0 9h0 Jh1 2h2",
            "win": 165,
            "playerId": "pid742728"
        },
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid4000265",
            "orderIndex": 2,
            "hero": false,
            "dead": "4c1 9s2 2c3 3s4",
            "rows": "Ah0 As1 Ks2/4s0 7h0 8s0 8d3 6c4/Qh0 Qd1 Jd2 Th3 Tc4",
            "win": -85,
            "playerId": "pid4000265"
        },
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid5679436",
            "orderIndex": 0,
            "hero": true,
            "dead": "3c1 9d2 7s3 7c4",
            "rows": "Kh0 Kd0 8h2/Ac0 8c1 9c2 4h4 5d4/2s0 5s0 5h1 2d3 5c3",
            "win": -85,
            "playerId": "pid5679436"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:05:19",
    "roomId": "21922814"
}


{
    "stakes": 5,
    "handData": {"210330083706-21922814-0000002-1": [
        {
            "inFantasy": true,
            "result": 10,
            "playerName": "pid742728",
            "orderIndex": 0,
            "hero": false,
            "dead": "2s0",
            "rows": "4d0 Jh0 Ah0/5d0 6c0 7d0 8h0 9h0/2c0 8c0 Tc0 Kc0 Ac0",
            "win": 48,
            "playerId": "pid742728"
        },
        {
            "inFantasy": false,
            "result": 23,
            "playerName": "pid4000265",
            "orderIndex": 1,
            "hero": false,
            "dead": "9s1 3h2 6h3 Qc4",
            "rows": "As0 Ad1 Kd4/3c0 5h1 3s2 2d3 3d4/9c0 Ts0 Js0 8s2 Qs3",
            "win": 44,
            "playerId": "pid4000265"
        },
        {
            "inFantasy": false,
            "result": -33,
            "playerName": "pid5679436",
            "orderIndex": 2,
            "hero": true,
            "dead": "7h1 5c2 Jc3 Qh4",
            "rows": "Kh1 Ks1 Jd4/5s0 6s0 7s0 4s3 4c4/8d0 Td0 6d2 9d2 Qd3",
            "win": -95,
            "playerId": "pid5679436"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:07:06",
    "roomId": "21922814"
}


{
    "stakes": 5,
    "handData": {"210330083706-21922814-0000003-1": [
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "pid742728",
            "orderIndex": 2,
            "hero": false,
            "dead": "6c1 2s2 Th3 Qs4",
            "rows": "As0 Kd1 Kc1/4d0 7s0 5h2 5d3 7d3/8c0 Jh0 Js2 8d4 Ah4",
            "win": 0,
            "playerId": "pid742728"
        },
        {
            "inFantasy": true,
            "result": 52,
            "playerName": "pid4000265",
            "orderIndex": 0,
            "hero": false,
            "dead": "4s0 9s1 5s2",
            "rows": "6h0 6d0 6s0/2h0 4h0 9h0 Qh0 Kh0/2c0 5c0 7c0 Jc0 Ac0",
            "win": 86,
            "playerId": "pid4000265"
        },
        {
            "inFantasy": false,
            "result": -31,
            "playerName": "pid5679436",
            "orderIndex": 1,
            "hero": true,
            "dead": "9d1 Qd2 2d3 3d4",
            "rows": "Ad0 Tc4 Ks4/3c1 3h2 3s2 4c3 8h3/8s0 9c0 Td0 Jd0 Qc1",
            "win": -89,
            "playerId": "pid5679436"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:08:02",
    "roomId": "21922814"
}


{
    "stakes": 5,
    "handData": {"210330083706-21922814-0000004-1": [
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "pid742728",
            "orderIndex": 1,
            "hero": false,
            "dead": "3d0 5h1",
            "rows": "Jc0 Qh0 Qd0/6h0 7c0 8c0 9s0 Td0/2h0 2s0 4d0 4c0 4s0",
            "win": 5,
            "playerId": "pid742728"
        },
        {
            "inFantasy": true,
            "result": 11,
            "playerName": "pid4000265",
            "orderIndex": 2,
            "hero": false,
            "dead": "3s0 2d1 8d2",
            "rows": "Js0 Qc0 Ah0/6d0 6c0 6s0 Kh0 Kd0/7h0 7s0 9h0 9d0 9c0",
            "win": 0,
            "playerId": "pid4000265"
        },
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid5679436",
            "orderIndex": 0,
            "hero": true,
            "dead": "7d1 Jh2 Jd3 8s4",
            "rows": "Kc0 Ks2 Ac4/As0 5c2 5d3 Qs3 5s4/3h0 8h0 Th0 Tc1 Ts1",
            "win": -5,
            "playerId": "pid5679436"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:09:09",
    "roomId": "21922814"
}


{
    "stakes": 5,
    "handData": {"210330083706-21922814-0000005-1": [
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid4000265",
            "orderIndex": 1,
            "hero": false,
            "dead": "Kc1 2s2 8d3 2c4",
            "rows": "Ah1 As2 Kh3/3h0 6c0 7d0 4d4 Ac4/9s0 Qh0 8h1 Jc2 Ts3",
            "win": -90,
            "playerId": "pid4000265"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "pid5679436",
            "orderIndex": 0,
            "hero": true,
            "dead": "7h1 Th2 8c3 5d4",
            "rows": "9h3 Jh3 9c4/3c0 5c0 6h0 4s1 7s2/2d0 Qd0 Ad1 6d2 3d4",
            "win": 87,
            "playerId": "pid5679436"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:10:24",
    "roomId": "21922814"
}


