{
    "stakes": 20,
    "handData": {"210330081117-21921376-0000019-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5679594",
            "orderIndex": 1,
            "hero": false,
            "dead": "6h1 Ts2 Th3 Qh4",
            "rows": "Kc0 2s2 Ah3/3h0 4c0 7s0 3c3 2d4/Jd0 8d1 Kd1 7d2 Ad4",
            "win": -120,
            "playerId": "pid5679594"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid4175886",
            "orderIndex": 0,
            "hero": false,
            "dead": "Kh1 9h2 9c3 2h4",
            "rows": "Ac0 As2 5d4/2c0 4s0 3s1 3d2 4d4/8c0 Js0 9s1 Jh3 Jc3",
            "win": 116,
            "playerId": "pid4175886"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": false,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:51:07",
    "roomId": "21921376"
}


{
    "stakes": 20,
    "handData": {"210330081117-21921376-0000020-1": [
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid5679594",
            "orderIndex": 0,
            "hero": false,
            "dead": "2c1 3h2 8c3 4c4",
            "rows": "Ks0 Kd2 6s3/2s0 7c0 5c2 2d4 5d4/4h0 4d0 Qh1 Qd1 Td3",
            "win": -340,
            "playerId": "pid5679594"
        },
        {
            "inFantasy": true,
            "result": 17,
            "playerName": "pid4175886",
            "orderIndex": 1,
            "hero": false,
            "dead": "4s0 3c1 6d2",
            "rows": "Kh0 Ac0 As0/6c0 7d0 8h0 9s0 Th0/Jh0 Jd0 Jc0 Qc0 Qs0",
            "win": 330,
            "playerId": "pid4175886"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": false,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:51:52",
    "roomId": "21921376"
}


{
    "stakes": 20,
    "handData": {"210330081117-21921376-0000021-1": [
        {
            "inFantasy": true,
            "result": 23,
            "playerName": "pid5679594",
            "orderIndex": 1,
            "hero": false,
            "dead": "7d0 5s1",
            "rows": "8d0 8c0 9c0/2h0 9h0 Th0 Jh0 Kh0/4c0 4s0 Qd0 Qc0 Qs0",
            "win": 446,
            "playerId": "pid5679594"
        },
        {
            "inFantasy": false,
            "result": -23,
            "playerName": "pid4175886",
            "orderIndex": 0,
            "hero": false,
            "dead": "8s1 6d2 9s3 2c4",
            "rows": "4d2 As2 4h4/3s0 5c0 6h1 6c1 5h3/7h0 7s0 Js0 7c3 3h4",
            "win": -460,
            "playerId": "pid4175886"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": false,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:52:34",
    "roomId": "21921376"
}


{
    "stakes": 20,
    "handData": {"210330081117-21921376-0000022-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5679594",
            "orderIndex": 1,
            "hero": false,
            "dead": "8d1 6d2 3s3 6h4",
            "rows": "Kd0 6s2 8s3/Js0 4s1 As1 Qh3 7h4/7c0 9c0 Qc0 4c2 Ad4",
            "win": -120,
            "playerId": "pid5679594"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5655944",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jc1 6c2 Jd3 3d4",
            "rows": "Ts2 Ac3 7s4/8h0 9s0 2h1 2s2 9h3/5d0 5s0 Qd0 5h1 3h4",
            "win": 116,
            "playerId": "pid5655944"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:53:50",
    "roomId": "21921376"
}


{
    "stakes": 20,
    "handData": {"210330081117-21921376-0000023-1": [
        {
            "inFantasy": false,
            "result": -7,
            "playerName": "pid5679594",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qs1 2h2 Qc3 Qd4",
            "rows": "5h2 3c4 4s4/8h0 9h0 9s0 4c2 9c3/4d0 Td0 8d1 Jd1 6d3",
            "win": -140,
            "playerId": "pid5679594"
        },
        {
            "inFantasy": false,
            "result": 23,
            "playerName": "pid5655944",
            "orderIndex": 2,
            "hero": true,
            "dead": "3d1 7s2 7d3 5d4",
            "rows": "Ad0 Ah3 7h4/6c0 Kh0 2c1 6s2 2d3/Ts0 Js0 5s1 8s2 Ks4",
            "win": 446,
            "playerId": "pid5655944"
        },
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid284474",
            "orderIndex": 0,
            "hero": false,
            "dead": "Tc1 3s2 7c3 Kd4",
            "rows": "9d2 8c3 Ac3/Jh0 Jc0 5c1 2s2 As4/3h0 4h0 Th0 6h1 Qh4",
            "win": -320,
            "playerId": "pid284474"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:55:41",
    "roomId": "21921376"
}


{
    "stakes": 20,
    "handData": {"210330081117-21921376-0000024-1": [
        {
            "inFantasy": false,
            "result": -27,
            "playerName": "pid5679594",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qd1 Jc2 6d3 5c4",
            "rows": "Kd1 Tc3 9d4/3h0 7h0 As1 Ah3 7s4/6c0 7c0 8c0 4s2 5s2",
            "win": -540,
            "playerId": "pid5679594"
        },
        {
            "inFantasy": true,
            "result": 41,
            "playerName": "pid5655944",
            "orderIndex": 1,
            "hero": true,
            "dead": "3s0 Td0 3c0",
            "rows": "Js0 Ad0 Ac0/2c0 3d0 4c0 5d0 6h0/9h0 9s0 Kh0 Kc0 Ks0",
            "win": 795,
            "playerId": "pid5655944"
        },
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid284474",
            "orderIndex": 2,
            "hero": false,
            "dead": "6s1 7d2 9c3 8h4",
            "rows": "Qc0 Qh2 Th4/5h0 8s0 2h1 8d2 2d4/4h0 4d0 Ts1 Jh3 Jd3",
            "win": -280,
            "playerId": "pid284474"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:57:04",
    "roomId": "21921376"
}


{
    "stakes": 20,
    "handData": {"210330081117-21921376-0000025-1": [
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid5679594",
            "orderIndex": 2,
            "hero": false,
            "dead": "Qd1 2h2 6h3 3c4",
            "rows": "Ah0 Kc3 4d4/3d0 7h0 7s2 Jd3 Jh4/6c0 Jc0 2c1 8c1 Qc2",
            "win": -160,
            "playerId": "pid5679594"
        },
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid5655944",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ts1 7d2 4h3 8d4",
            "rows": "Qs0 Ac2 Qh4/5h0 5d0 6d2 6s3 Ks3/7c0 9c0 Td1 Js1 8h4",
            "win": 97,
            "playerId": "pid5655944"
        },
        {
            "inFantasy": true,
            "result": 3,
            "playerName": "pid284474",
            "orderIndex": 1,
            "hero": false,
            "dead": "2d0",
            "rows": "Th0 Tc0 Kh0/4c0 5c0 9d0 Ad0 As0/2s0 3s0 5s0 8s0 9s0",
            "win": 58,
            "playerId": "pid284474"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:58:28",
    "roomId": "21921376"
}


{
    "stakes": 20,
    "handData": {"210330081117-21921376-0000026-1": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "pid5679594",
            "orderIndex": 1,
            "hero": false,
            "dead": "2d1 Tc2 Jd3 3s4",
            "rows": "8s3 Jc3 Ah4/3c0 6d0 2c2 5c2 4h4/4d0 4c0 Ts0 Th1 Td1",
            "win": 291,
            "playerId": "pid5679594"
        },
        {
            "inFantasy": true,
            "result": 17,
            "playerName": "pid5655944",
            "orderIndex": 2,
            "hero": true,
            "dead": "7s0",
            "rows": "Qc0 Kd0 As0/3h0 4s0 5d0 6c0 7c0/8h0 8d0 9h0 9d0 9s0",
            "win": 153,
            "playerId": "pid5655944"
        },
        {
            "inFantasy": false,
            "result": -32,
            "playerName": "pid284474",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qs1 6s2 Qh3 5s4",
            "rows": "Ad0 Ac1 3d2/2s0 8c0 7d2 6h4 7h4/9c0 Jh0 Js1 Kc3 Ks3",
            "win": -458,
            "playerId": "pid284474"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:59:49",
    "roomId": "21921376"
}


{
    "stakes": 20,
    "handData": {"210330081117-21921376-0000027-1": [
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid5679594",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qh1 4c2 Kd3 Kc4",
            "rows": "Th2 9s3 7d4/5h0 7c0 8h2 Jc3 2c4/2s0 8s0 Ks0 6s1 Qs1",
            "win": -340,
            "playerId": "pid5679594"
        },
        {
            "inFantasy": false,
            "result": 17,
            "playerName": "pid5655944",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ts1 8d2 Ac3 Tc4",
            "rows": "As0 Qc2 Qd4/5d0 6d0 4s1 3d2 2h4/7h0 Kh0 Ah1 6h3 9h3",
            "win": 330,
            "playerId": "pid5655944"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:01:05",
    "roomId": "21921376"
}


{
    "stakes": 20,
    "handData": {"210330081117-21921376-0000028-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5679594",
            "orderIndex": 0,
            "hero": false,
            "dead": "7s1 2d2 6s3 Th4",
            "rows": "Ad0 Kh3 Kd4/6c0 Tc0 3s1 Td1 6d2/9h0 Qh0 9d2 Jd3 Js4",
            "win": -120,
            "playerId": "pid5679594"
        },
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "pid5655944",
            "orderIndex": 1,
            "hero": true,
            "dead": "3d0",
            "rows": "Ts0 Qs0 Ks0/4s0 6h0 8c0 Jh0 Jc0/2c0 3c0 4c0 5c0 Ac0",
            "win": 116,
            "playerId": "pid5655944"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:01:48",
    "roomId": "21921376"
}


{
    "stakes": 20,
    "handData": {"210330081117-21921376-0000029-1": [
        {
            "inFantasy": true,
            "result": 1,
            "playerName": "pid5679594",
            "orderIndex": 1,
            "hero": false,
            "dead": "2h0 3c1",
            "rows": "Js0 Kh0 Kd0/5h0 5s0 8d0 8c0 9c0/4c0 4s0 7s0 Qh0 Qs0",
            "win": 19,
            "playerId": "pid5679594"
        },
        {
            "inFantasy": true,
            "result": -1,
            "playerName": "pid5655944",
            "orderIndex": 0,
            "hero": true,
            "dead": "4h0",
            "rows": "9h0 9d0 Jh0/5c0 7d0 7c0 8h0 8s0/Ts0 Jd0 Qd0 Kc0 Ac0",
            "win": -20,
            "playerId": "pid5655944"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:02:24",
    "roomId": "21921376"
}


