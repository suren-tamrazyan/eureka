{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000000-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5478342",
            "orderIndex": 1,
            "hero": false,
            "dead": "2d1 6h2 4s3 Ah4",
            "rows": "Kd0 Ad0 3s4/7s0 9h1 9d2 6s3 Kc4/Jc0 Qc0 Qh1 Qs2 Qd3",
            "win": 0,
            "playerId": "pid5478342"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5688836",
            "orderIndex": 0,
            "hero": true,
            "dead": "5d1 Td2 8c3 3c4",
            "rows": "As0 Ac3 6c4/2c0 4h0 4c0 Kh3 2s4/8d0 Ts1 Jh1 8h2 8s2",
            "win": 0,
            "playerId": "pid5688836"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:56:30",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000001-1": [
        {
            "inFantasy": false,
            "result": -35,
            "playerName": "pid5478342",
            "orderIndex": 0,
            "hero": false,
            "dead": "Kc1 3c2 Ts3 8s4",
            "rows": "Ad0 Jd3 8c4/Qd0 4d1 5d1 Td2 Qc3/6h0 8h0 9h0 3h2 2h4",
            "win": -7,
            "playerId": "pid5478342"
        },
        {
            "inFantasy": true,
            "result": 35,
            "playerName": "pid5688836",
            "orderIndex": 1,
            "hero": true,
            "dead": "2d0 2c0 Th0",
            "rows": "Kh0 Kd0 Ks0/4c0 5c0 7c0 9c0 Tc0/2s0 4s0 5s0 Js0 Qs0",
            "win": 6.8,
            "playerId": "pid5688836"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:57:20",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000002-1": [
        {
            "inFantasy": false,
            "result": 17,
            "playerName": "pid5478342",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qd1 2s2 Qh3 7h4",
            "rows": "Ac1 Ah4 Ad4/6d0 8s0 5d1 7c3 9h3/Kh0 Kd0 Ks0 Jh2 Jd2",
            "win": 3.3,
            "playerId": "pid5478342"
        },
        {
            "inFantasy": true,
            "result": -17,
            "playerName": "pid5688836",
            "orderIndex": 0,
            "hero": true,
            "dead": "2d0 4c0 8d0",
            "rows": "9c0 Jc0 Js0/6h0 7s0 8h0 9d0 Th0/3h0 3s0 5h0 5c0 5s0",
            "win": -3.4,
            "playerId": "pid5688836"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:58:27",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000003-1": [
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "pid5478342",
            "orderIndex": 0,
            "hero": false,
            "dead": "5s0 9s1 Th2",
            "rows": "Qh0 Qd0 Qc0/2d0 4d0 8d0 9d0 Td0/4c0 6c0 Tc0 Jc0 Ac0",
            "win": 5.8,
            "playerId": "pid5478342"
        },
        {
            "inFantasy": false,
            "result": -30,
            "playerName": "pid5688836",
            "orderIndex": 1,
            "hero": true,
            "dead": "2c1 Ks2 3s3 6s4",
            "rows": "Kd3 Qs4 As4/7d0 Ts1 Js1 8c2 9c3/5h0 6h0 9h0 Kh0 8h2",
            "win": -6,
            "playerId": "pid5688836"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:59:10",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000004-1": [
        {
            "inFantasy": true,
            "result": 20,
            "playerName": "pid5478342",
            "orderIndex": 1,
            "hero": false,
            "dead": "2h0 5d1 7c2",
            "rows": "4h0 4c0 4s0/6d0 6c0 6s0 Ts0 Kh0/9h0 Jd0 Ad0 Ac0 As0",
            "win": 3.9,
            "playerId": "pid5478342"
        },
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid5688836",
            "orderIndex": 0,
            "hero": true,
            "dead": "4d1 8d2 Jh3 2d4",
            "rows": "Kc1 Ah3 7h4/9d0 Tc0 7s1 7d2 Kd4/5h0 Qd0 Qs0 2s2 5c3",
            "win": -4,
            "playerId": "pid5688836"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 07:00:15",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000005-1": [
        {
            "inFantasy": true,
            "result": 25,
            "playerName": "pid5478342",
            "orderIndex": 0,
            "hero": false,
            "dead": "Kd0 5d1 6d2",
            "rows": "Qd0 Qc0 Ac0/2s0 3s0 7s0 Ts0 Ks0/8h0 Th0 Jh0 Kh0 Ah0",
            "win": 4.8,
            "playerId": "pid5478342"
        },
        {
            "inFantasy": false,
            "result": -25,
            "playerName": "pid5688836",
            "orderIndex": 1,
            "hero": true,
            "dead": "5h1 9c2 2c3 Qh4",
            "rows": "Kc1 Ad2 6c3/4h0 4s0 4c1 8d2 2d3/9s0 Js0 Qs0 4d4 9h4",
            "win": -5,
            "playerId": "pid5688836"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 07:00:58",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000006-1": [
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid5478342",
            "orderIndex": 1,
            "hero": false,
            "dead": "2d1 Qd2 3h3 5d4",
            "rows": "7d1 Td1 4h3/5s0 Js0 2s2 6s3 8h4/4c0 6c0 7c0 2c2 As4",
            "win": -3.8,
            "playerId": "pid5478342"
        },
        {
            "inFantasy": false,
            "result": 19,
            "playerName": "pid5688836",
            "orderIndex": 0,
            "hero": true,
            "dead": "Kh1 3c2 8c3 3s4",
            "rows": "Ah0 Ac1 9c2/5h0 Th2 5c3 Qs3 Tc4/6d0 9d0 Kd0 8d1 4d4",
            "win": 3.7,
            "playerId": "pid5688836"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 07:02:25",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000007-1": [
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid5478342",
            "orderIndex": 0,
            "hero": false,
            "dead": "8h1 Js2 Qd3 2d4",
            "rows": "As0 Kh2 Ac2/4c0 Tc1 6c3 9c3 9h4/6d0 9d0 Kd0 Ad1 4h4",
            "win": -4,
            "playerId": "pid5478342"
        },
        {
            "inFantasy": true,
            "result": 20,
            "playerName": "pid5688836",
            "orderIndex": 1,
            "hero": true,
            "dead": "3s0 5c0 Td0",
            "rows": "Qh0 Kc0 Ks0/3c0 4s0 5h0 6s0 7c0/7s0 8d0 9s0 Th0 Jh0",
            "win": 3.9,
            "playerId": "pid5688836"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 07:03:34",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000008-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5478342",
            "orderIndex": 1,
            "hero": false,
            "dead": "3h1 8h2 Kd3 5c4",
            "rows": "Kc0 Kh2 Js4/2h0 4s0 2s3 Qh3 6s4/7d0 Tc0 8d1 Jc1 9h2",
            "win": 0,
            "playerId": "pid5478342"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5688836",
            "orderIndex": 0,
            "hero": true,
            "dead": "5d1 3s2 5h3 9s4",
            "rows": "Ad0 As2 8s4/9d0 Ts0 7h1 9c3 Td3/8c0 Qc0 2c1 3c2 3d4",
            "win": 0,
            "playerId": "pid5688836"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 07:05:06",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000009-1": [
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid5478342",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jd1 4c2 6h3 4h4",
            "rows": "Qh1 9h3 5h4/6c0 8h0 Kd1 6s2 Jh4/2s0 7c0 Ts0 7h2 Td3",
            "win": -3.8,
            "playerId": "pid5478342"
        },
        {
            "inFantasy": false,
            "result": 19,
            "playerName": "pid5688836",
            "orderIndex": 1,
            "hero": true,
            "dead": "8d1 2h2 3h3 4s4",
            "rows": "Qc2 Ad3 Ac4/3c0 3s0 3d1 Jc3 4d4/7d0 8c0 Tc0 Js1 9s2",
            "win": 3.7,
            "playerId": "pid5688836"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 07:06:39",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000010-1": [
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "pid5478342",
            "orderIndex": 1,
            "hero": false,
            "dead": "Kc1 Kh2 3h3 8c4",
            "rows": "Ah1 Ac3 7c4/6h0 6d0 9h0 Qc3 2c4/3s0 Js0 Ts1 5s2 8s2",
            "win": -4.2,
            "playerId": "pid5478342"
        },
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "pid5688836",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h0 2d0 4s0",
            "rows": "Qd0 Qs0 Ks0/4h0 5d0 6s0 7h0 8d0/3c0 5c0 9c0 Tc0 Jc0",
            "win": 4.1,
            "playerId": "pid5688836"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 07:07:38",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000011-1": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "pid5478342",
            "orderIndex": 0,
            "hero": false,
            "dead": "6c1 4d2 4s3 7s4",
            "rows": "Ks0 Th3 6d4/2c0 3h0 3c1 5d3 3s4/8d0 9s0 Jc1 Td2 Qh2",
            "win": -0.6,
            "playerId": "pid5478342"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid5688836",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jh1 Js2 9h3 8c4",
            "rows": "As1 Tc3 9d4/2s0 6s0 Qs1 2h3 2d4/4c0 7c0 Ac0 9c2 Kc2",
            "win": 0.6,
            "playerId": "pid5688836"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 07:09:24",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000012-1": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5478342",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qs1 3s2 Kd3 Qd4",
            "rows": "Ah0 As2 Kc4/4c0 5h0 4d1 6d2 5d3/9d0 Js0 9s1 Jh3 Td4",
            "win": 1.2,
            "playerId": "pid5478342"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5688836",
            "orderIndex": 0,
            "hero": true,
            "dead": "8c1 2d2 Qc3 Jd4",
            "rows": "Ad1 4s3 6c4/3c0 9h0 7s2 Ac3 2h4/2s0 5s0 Ts0 6s1 8s2",
            "win": -1.2,
            "playerId": "pid5688836"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 07:11:04",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000013-1": [
        {
            "inFantasy": true,
            "result": 23,
            "playerName": "pid5478342",
            "orderIndex": 0,
            "hero": false,
            "dead": "4h0 5h1 3s2",
            "rows": "Jc0 Ah0 As0/5s0 6c0 7h0 8c0 9h0/4d0 6d0 9d0 Td0 Kd0",
            "win": 4.5,
            "playerId": "pid5478342"
        },
        {
            "inFantasy": false,
            "result": -23,
            "playerName": "pid5688836",
            "orderIndex": 1,
            "hero": true,
            "dead": "8s1 Ks2 7d3 9s4",
            "rows": "Ad0 Ac0 Th3/2d0 6s0 Jd2 7s4 9c4/Qc0 Qh1 Qd1 Tc2 Qs3",
            "win": -4.6,
            "playerId": "pid5688836"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 07:11:47",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000014-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5478342",
            "orderIndex": 1,
            "hero": false,
            "dead": "4d1 4c2 Qs3 7h4",
            "rows": "5d3 5s3 Kh4/9s0 Ts0 3s1 6s1 8s2/3c0 8c0 Qc0 Jc2 Ad4",
            "win": 0,
            "playerId": "pid5478342"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5688836",
            "orderIndex": 0,
            "hero": true,
            "dead": "As1 8h2 9h3 Ac4",
            "rows": "Kd0 Qd2 Qh3/2h0 7c0 2s1 7s2 6h3/Tc0 Js0 Td1 3h4 4s4",
            "win": 0,
            "playerId": "pid5688836"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 07:13:18",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000015-1": [
        {
            "inFantasy": false,
            "result": -13,
            "playerName": "pid5478342",
            "orderIndex": 0,
            "hero": false,
            "dead": "2s1 7c2 3c3 Kd4",
            "rows": "6c3 Jc3 Jh4/2d0 5h0 5d0 3h2 3d2/4c0 Qc0 Qh1 Qs1 8c4",
            "win": -2.6,
            "playerId": "pid5478342"
        },
        {
            "inFantasy": false,
            "result": 13,
            "playerName": "pid5688836",
            "orderIndex": 1,
            "hero": true,
            "dead": "3s1 4s2 9d3 4h4",
            "rows": "Kh0 Ad2 Ah4/Tc0 Ts1 9s2 Td3 Ks4/5c0 7d0 8d0 4d1 6d3",
            "win": 2.5,
            "playerId": "pid5688836"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 07:15:06",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000016-1": [
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "pid5478342",
            "orderIndex": 1,
            "hero": false,
            "dead": "2d1 Kd2 2c3 3h4",
            "rows": "Ad1 As2 8s3/6d0 6s0 4c3 6c4 Kh4/8h0 8c0 Qs0 Qh1 8d2",
            "win": -1.8,
            "playerId": "pid5478342"
        },
        {
            "inFantasy": true,
            "result": 9,
            "playerName": "pid5688836",
            "orderIndex": 0,
            "hero": true,
            "dead": "9d0 Jc0 Ks0",
            "rows": "7d0 7c0 7s0/9h0 Td0 Jd0 Qd0 Kc0/4h0 4d0 4s0 5h0 5s0",
            "win": 1.7,
            "playerId": "pid5688836"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 07:15:59",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000017-1": [
        {
            "inFantasy": true,
            "result": -4,
            "playerName": "pid5478342",
            "orderIndex": 0,
            "hero": false,
            "dead": "8c0 3d1 4c2",
            "rows": "Kh0 Ks0 Ac0/2d0 2s0 Jc0 Js0 Qh0/7d0 7s0 9h0 9d0 9s0",
            "win": -0.8,
            "playerId": "pid5478342"
        },
        {
            "inFantasy": true,
            "result": 4,
            "playerName": "pid5688836",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jh0 2c0 Qd0",
            "rows": "Kd0 Ah0 As0/3s0 4d0 5h0 6d0 7h0/5c0 7c0 9c0 Tc0 Kc0",
            "win": 0.8,
            "playerId": "pid5688836"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 07:16:31",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000018-1": [
        {
            "inFantasy": false,
            "result": -7,
            "playerName": "pid5478342",
            "orderIndex": 1,
            "hero": false,
            "dead": "5c1 8d2 Td3 Jd4",
            "rows": "Ah0 Ks1 8h4/3s0 7s0 7h1 9c2 9d3/Ts0 Qc0 Qh2 Qs3 Th4",
            "win": -1.4,
            "playerId": "pid5478342"
        },
        {
            "inFantasy": false,
            "result": 7,
            "playerName": "pid5688836",
            "orderIndex": 0,
            "hero": true,
            "dead": "6h1 5h2 6s3 Ac4",
            "rows": "Ad0 Kc2 Kd3/8c0 8s0 2h2 2d3 5s4/4s0 Js0 4d1 Jh1 4c4",
            "win": 1.4,
            "playerId": "pid5688836"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 07:18:21",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000019-1": [
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "pid5478342",
            "orderIndex": 0,
            "hero": false,
            "dead": "Ts1 9h2 9s3 2s4",
            "rows": "Qs0 Qd2 7d4/2d0 6d0 Kd1 Ad2 Kh3/3c0 5c0 5h1 Jh3 3h4",
            "win": -1,
            "playerId": "pid5478342"
        },
        {
            "inFantasy": true,
            "result": 5,
            "playerName": "pid5688836",
            "orderIndex": 1,
            "hero": true,
            "dead": "7s0 8s0",
            "rows": "6c0 6s0 Ac0/8h0 9d0 Th0 Jd0 Qc0/3d0 3s0 4h0 4d0 4c0",
            "win": 1,
            "playerId": "pid5688836"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 07:19:33",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000020-1": [
        {
            "inFantasy": true,
            "result": 14,
            "playerName": "pid5478342",
            "orderIndex": 1,
            "hero": false,
            "dead": "2d0",
            "rows": "9d0 Td0 Jh0/2c0 3h0 4d0 5c0 6s0/2s0 3s0 8s0 Ts0 Ks0",
            "win": 2.7,
            "playerId": "pid5478342"
        },
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid5688836",
            "orderIndex": 0,
            "hero": true,
            "dead": "Th1 As2 3d3 Qh4",
            "rows": "Qs1 Qd2 Ac3/6d0 6h1 5s2 9s3 Jd4/7d0 7c0 Kd0 Kc0 4h4",
            "win": -2.8,
            "playerId": "pid5688836"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 07:20:25",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000021-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5478342",
            "orderIndex": 0,
            "hero": false,
            "dead": "Td1 3c2 9c3 5d4",
            "rows": "Ah0 Ac3 Ad4/8c0 6h1 4c2 4s2 Qd4/Jc0 Js0 Kh0 Kd1 Kc3",
            "win": 0,
            "playerId": "pid5478342"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5688836",
            "orderIndex": 1,
            "hero": true,
            "dead": "5h1 3d2 Jd3 As4",
            "rows": "6c2 6s3 9h4/2c0 4h0 Tc0 Th1 2d2/7d0 8d0 7s1 8h3 6d4",
            "win": 0,
            "playerId": "pid5688836"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 07:22:06",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000022-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5478342",
            "orderIndex": 1,
            "hero": false,
            "dead": "Td1 7c2 8c3 7d4",
            "rows": "Ad0 Kh1 Ac3/4d0 3c1 4c2 2h3 3s4/8h0 9c0 Th0 7s2 Kd4",
            "win": -1.2,
            "playerId": "pid5478342"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5688836",
            "orderIndex": 0,
            "hero": true,
            "dead": "9s1 9d2 4s3 6h4",
            "rows": "3d3 5d3 Qc4/5s0 Ts0 8d1 8s1 5h2/2d0 Jh0 Js0 2c2 Qd4",
            "win": 1.2,
            "playerId": "pid5688836"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 07:23:39",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000023-1": [
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid5478342",
            "orderIndex": 0,
            "hero": false,
            "dead": "2h1 3h2 As3 4s4",
            "rows": "Ah0 Ac1 7c3/3s0 6c0 3d2 4c2 4h3/Td0 Qc0 Tc1 9d4 Js4",
            "win": -2.8,
            "playerId": "pid5478342"
        },
        {
            "inFantasy": false,
            "result": 14,
            "playerName": "pid5688836",
            "orderIndex": 1,
            "hero": true,
            "dead": "Th1 3c2 4d3 7h4",
            "rows": "Ks0 Kh1 Jh4/2c0 5c0 5s2 8s3 8h4/7d0 8d0 Jd1 7s2 Jc3",
            "win": 2.7,
            "playerId": "pid5688836"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 07:25:15",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000024-1": [
        {
            "inFantasy": false,
            "result": -27,
            "playerName": "pid5478342",
            "orderIndex": 1,
            "hero": false,
            "dead": "9h1 2s2 4h3 3s4",
            "rows": "Kc0 As3 7c4/5h0 6s1 5s2 Tc2 Kd4/Jh0 Qh0 Qc0 Jc1 9s3",
            "win": -5.4,
            "playerId": "pid5478342"
        },
        {
            "inFantasy": true,
            "result": 27,
            "playerName": "pid5688836",
            "orderIndex": 0,
            "hero": true,
            "dead": "4c0 8s0",
            "rows": "Js0 Qd0 Qs0/2d0 3d0 5d0 6d0 Jd0/7h0 7d0 7s0 Td0 Ts0",
            "win": 5.2,
            "playerId": "pid5688836"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 07:26:27",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000025-1": [
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5478342",
            "orderIndex": 0,
            "hero": false,
            "dead": "9d1 8d2 9c3 2h4",
            "rows": "Ks2 7d3 8h4/6c0 3c1 3h2 5c3 Qd4/9h0 Tc0 Js0 Qc0 Kc1",
            "win": -2,
            "playerId": "pid5478342"
        },
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid5688836",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jh1 Kh2 6s3 3s4",
            "rows": "As0 3d4 Ah4/2d0 4s1 5s1 4c2 2s3/7s0 8c0 9s0 Ts2 6h3",
            "win": 1.9,
            "playerId": "pid5688836"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 07:28:14",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000026-1": [
        {
            "inFantasy": false,
            "result": -31,
            "playerName": "pid5478342",
            "orderIndex": 1,
            "hero": false,
            "dead": "3h1 4h2 3d3 As4",
            "rows": "Ks0 Ac1 Kh4/5d0 5c0 6h0 6c1 7d3/Td0 8h2 9h2 8c3 Ad4",
            "win": -3.8,
            "playerId": "pid5478342"
        },
        {
            "inFantasy": true,
            "result": 31,
            "playerName": "pid5688836",
            "orderIndex": 0,
            "hero": true,
            "dead": "2d0 4c0 7h0",
            "rows": "Jd0 Jc0 Qc0/2h0 3c0 4d0 5h0 Ah0/6s0 7s0 8s0 9s0 Ts0",
            "win": 3.7,
            "playerId": "pid5688836"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 07:30:15",
    "roomId": "21938386"
}


