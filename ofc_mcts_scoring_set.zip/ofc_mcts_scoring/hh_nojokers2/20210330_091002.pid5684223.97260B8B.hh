{
    "stakes": 10,
    "handData": {"210330135309-21938525-0000000-1": [
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid301738",
            "orderIndex": 1,
            "hero": false,
            "dead": "5c1 8s2 5d3 Jd4",
            "rows": "Qh2 7d3 Ad4/2c0 3s0 3c1 4d3 2h4/7h0 9h0 Tc0 6s1 8h2",
            "win": -180,
            "playerId": "pid301738"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "pid5684223",
            "orderIndex": 0,
            "hero": true,
            "dead": "Kc1 5h2 5s3 4h4",
            "rows": "Kh0 Kd0 Qd3/2d0 2s2 8c3 Td4 Ts4/9d0 Js0 9s1 Jh1 9c2",
            "win": 175,
            "playerId": "pid5684223"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:10:02",
    "roomId": "21938525"
}


{
    "stakes": 10,
    "handData": {"210330135309-21938525-0000001-1": [
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "pid301738",
            "orderIndex": 0,
            "hero": false,
            "dead": "7d1 2d2 Jh3 As4",
            "rows": "Ah0 Ks3 5s4/8h0 Qh0 9s1 8s3 Ad4/6c0 Kc0 4c1 2c2 7c2",
            "win": -90,
            "playerId": "pid301738"
        },
        {
            "inFantasy": true,
            "result": 9,
            "playerName": "pid5684223",
            "orderIndex": 1,
            "hero": true,
            "dead": "7h0 8c0",
            "rows": "9h0 9d0 Kh0/2s0 3h0 4s0 5d0 Ac0/3s0 7s0 Ts0 Js0 Qs0",
            "win": 87,
            "playerId": "pid5684223"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:10:43",
    "roomId": "21938525"
}


{
    "stakes": 10,
    "handData": {"210330135309-21938525-0000002-1": [
        {
            "inFantasy": false,
            "result": -11,
            "playerName": "pid301738",
            "orderIndex": 1,
            "hero": false,
            "dead": "7h1 Js2 Kh3 5c4",
            "rows": "As1 6d4 9s4/3d0 4c0 4s2 9c2 3s3/9h0 Th0 Jc0 8h1 Qs3",
            "win": -110,
            "playerId": "pid301738"
        },
        {
            "inFantasy": false,
            "result": 11,
            "playerName": "pid5684223",
            "orderIndex": 0,
            "hero": true,
            "dead": "3h1 8c2 6s3 3c4",
            "rows": "Kc0 Ks0 8s3/2h0 Ac1 4h2 Ah2 7s4/5d0 8d0 Jd1 Qd3 Kd4",
            "win": 107,
            "playerId": "pid5684223"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:11:43",
    "roomId": "21938525"
}


{
    "stakes": 10,
    "handData": {"210330135309-21938525-0000003-1": [
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "pid301738",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qd1 4c2 8h3 6c4",
            "rows": "Ac1 6d2 As3/2s0 5h0 7h0 7s3 2c4/8c0 Tc0 9h1 Qh2 Qc4",
            "win": -120,
            "playerId": "pid301738"
        },
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "pid5684223",
            "orderIndex": 1,
            "hero": true,
            "dead": "4s0 5c0",
            "rows": "Td0 Ah0 Ad0/7d0 9d0 9c0 Jh0 Jc0/3h0 3s0 Kh0 Kc0 Ks0",
            "win": 116,
            "playerId": "pid5684223"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:12:29",
    "roomId": "21938525"
}


{
    "stakes": 10,
    "handData": {"210330135309-21938525-0000004-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid301738",
            "orderIndex": 0,
            "hero": false,
            "dead": "8c1 3s2 2c3 Qh4",
            "rows": "Ad1 Kh3 Kc3/8h0 8d1 6d2 9h2 Kd4/5h0 5s0 Th0 Tc0 Ts4",
            "win": 0,
            "playerId": "pid301738"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5684223",
            "orderIndex": 1,
            "hero": true,
            "dead": "9s1 Qc2 8s3 Qs4",
            "rows": "Ah0 As1 7c4/Td0 2d1 Qd2 4d3 2h4/Jd0 Jc0 Js0 Jh2 Ks3",
            "win": 0,
            "playerId": "pid5684223"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:13:44",
    "roomId": "21938525"
}


{
    "stakes": 10,
    "handData": {"210330135309-21938525-0000005-1": [
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid301738",
            "orderIndex": 1,
            "hero": false,
            "dead": "6d1 2s2 Qd3 Kh4",
            "rows": "Kd0 4d3 8d3/2c0 9c0 7c1 4h4 4c4/Jh0 Ah0 2h1 3h2 6h2",
            "win": -150,
            "playerId": "pid301738"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "pid5684223",
            "orderIndex": 0,
            "hero": true,
            "dead": "2d1 8h2 6s3 As4",
            "rows": "Qh1 Kc3 Qc4/3d0 5d0 6c0 3s1 5c2/9h0 Ts0 Tc2 9d3 Th4",
            "win": 145,
            "playerId": "pid5684223"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:14:51",
    "roomId": "21938525"
}


{
    "stakes": 10,
    "handData": {"210330135309-21938525-0000006-1": [
        {
            "inFantasy": false,
            "result": -13,
            "playerName": "pid301738",
            "orderIndex": 0,
            "hero": false,
            "dead": "8d1 7c2 2s3 2h4",
            "rows": "Kc1 5c4 Ah4/2c0 6s0 7h1 7d2 6d3/Jh0 Qc0 Qs0 Qh2 Jc3",
            "win": -130,
            "playerId": "pid301738"
        },
        {
            "inFantasy": true,
            "result": 13,
            "playerName": "pid5684223",
            "orderIndex": 1,
            "hero": true,
            "dead": "5d0",
            "rows": "8s0 Ks0 As0/3h0 3d0 3c0 6h0 6c0/9d0 9c0 Th0 Tc0 Ts0",
            "win": 126,
            "playerId": "pid5684223"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:15:43",
    "roomId": "21938525"
}


