{
    "stakes": 10,
    "handData": {"210330003138-21897200-0000000-1": [
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "pid2813203",
            "orderIndex": 1,
            "hero": false,
            "dead": "6c1 Tc2 Jh3 4c4",
            "rows": "2s0 Kd0 Kc0/9h1 9s2 Ac2 3c3 Qh4/8d0 Qd0 5d1 9d3 8h4",
            "win": -210,
            "playerId": "pid2813203"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "pid5684417",
            "orderIndex": 0,
            "hero": true,
            "dead": "7c1 Jc2 4s3 4d4",
            "rows": "Kh0 As3 Ah4/2h0 2c0 2d2 8c2 Ks4/6s0 Js0 5s1 Ts1 Qs3",
            "win": 204,
            "playerId": "pid5684417"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:22:15",
    "roomId": "21897200"
}


{
    "stakes": 10,
    "handData": {"210330003138-21897200-0000001-1": [
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid2813203",
            "orderIndex": 0,
            "hero": false,
            "dead": "7d1 2c2 Jh3 7h4",
            "rows": "Qh2 Ac3 7s4/2h0 3s0 9d0 9h1 2s4/Qc0 Kc0 Tc1 7c2 Jc3",
            "win": -170,
            "playerId": "pid2813203"
        },
        {
            "inFantasy": true,
            "result": 17,
            "playerName": "pid5684417",
            "orderIndex": 1,
            "hero": true,
            "dead": "3d0 3c0 8d0",
            "rows": "Ts0 Ah0 Ad0/6d0 6s0 9c0 Kh0 Kd0/4d0 4c0 5h0 5c0 5s0",
            "win": 165,
            "playerId": "pid5684417"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:23:00",
    "roomId": "21897200"
}


{
    "stakes": 10,
    "handData": {"210330003138-21897200-0000002-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid2813203",
            "orderIndex": 1,
            "hero": false,
            "dead": "Js1 2c2 Jh3 4c4",
            "rows": "Ac0 9c4 Kc4/3s0 4s0 6s2 Qh3 Ad3/9h0 Jd0 8h1 Tc1 Qd2",
            "win": 0,
            "playerId": "pid2813203"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5684417",
            "orderIndex": 0,
            "hero": true,
            "dead": "6c1 Th2 Ts3 Kh4",
            "rows": "Ks0 Qs2 7c3/7h0 Ah0 5s1 7s2 8c3/6d0 9d0 2d1 4h4 Qc4",
            "win": 0,
            "playerId": "pid5684417"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:24:17",
    "roomId": "21897200"
}


{
    "stakes": 10,
    "handData": {"210330003138-21897200-0000003-1": [
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid2813203",
            "orderIndex": 0,
            "hero": false,
            "dead": "Td1 8d2 8s3 8c4",
            "rows": "Kh0 Ts3 Qc4/4c0 7c0 9s1 4d2 9d4/5h0 5c0 Jc1 5d2 Jd3",
            "win": 48,
            "playerId": "pid2813203"
        },
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "pid5684417",
            "orderIndex": 1,
            "hero": true,
            "dead": "4s1 7h2 7d3 2d4",
            "rows": "Kd2 Ah2 Tc4/2c0 3s1 5s3 6d3 3c4/7s0 8h0 Th0 Js0 9c1",
            "win": -50,
            "playerId": "pid5684417"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:25:40",
    "roomId": "21897200"
}


{
    "stakes": 10,
    "handData": {"210330003138-21897200-0000004-1": [
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid2813203",
            "orderIndex": 1,
            "hero": false,
            "dead": "Js1 6c2 2h3 3s4",
            "rows": "As1 Qc2 4s3/8s0 Tc0 5c1 6s3 Jc4/2d0 4d0 7d0 9d2 2c4",
            "win": -168,
            "playerId": "pid2813203"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "pid5684417",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ks1 3c2 6d3 8h4",
            "rows": "4c0 Ac1 4h4/7h0 9h0 5h2 Jh3 3h4/Jd0 Qd0 8d1 Kd2 5d3",
            "win": 163,
            "playerId": "pid5684417"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:28:08",
    "roomId": "21897200"
}


