{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000071-1": [
        {
            "inFantasy": false,
            "result": 4,
            "playerName": "pid5118808",
            "orderIndex": 1,
            "hero": false,
            "dead": "2d1 2c2 Ks3 3c4",
            "rows": "Ad2 As2 Jh4/9h0 4h1 4s3 Qh3 Qs4/2s0 6s0 8s0 Ts0 Js1",
            "win": 0.8,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": -4,
            "playerName": "pid5693342",
            "orderIndex": 0,
            "hero": true,
            "dead": "9c1 4c2 6c3 9s4",
            "rows": "Kd1 8d2 9d3/3d0 Jc0 Qc2 Kc3 5c4/7h0 7d0 7s0 2h1 7c4",
            "win": -0.8,
            "playerId": "pid5693342"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:32:36",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000072-1": [
        {
            "inFantasy": true,
            "result": 27,
            "playerName": "pid5118808",
            "orderIndex": 0,
            "hero": false,
            "dead": "Tc0 2c1 6d2",
            "rows": "5h0 5d0 5c0/8d0 9h0 Td0 Js0 Qc0/2s0 8s0 9s0 Ts0 As0",
            "win": 5.2,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": -27,
            "playerName": "pid5693342",
            "orderIndex": 1,
            "hero": true,
            "dead": "5s1 4c2 Ac3 Th4",
            "rows": "Ad0 Kc2 Ah3/3h0 9c0 Jd1 Jh2 9d4/7s0 Qs0 Qd1 Ks3 8h4",
            "win": -5.4,
            "playerId": "pid5693342"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:33:24",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000073-1": [
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "pid5118808",
            "orderIndex": 1,
            "hero": false,
            "dead": "8h0 4h1 3s2",
            "rows": "Jh0 Jd0 Qd0/6s0 7h0 8d0 9c0 Th0/2c0 6c0 7c0 Kc0 Ac0",
            "win": 1.2,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5693342",
            "orderIndex": 0,
            "hero": true,
            "dead": "Js1 9s2 5h3 5c4",
            "rows": "Ad0 Kh3 As4/4c0 5d0 2d1 2s1 4s2/Ts0 Qh0 9h2 9d3 Tc4",
            "win": -1.2,
            "playerId": "pid5693342"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:34:10",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000074-1": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid5118808",
            "orderIndex": 0,
            "hero": false,
            "dead": "Ac1 2c2 Ad3 5h4",
            "rows": "Kh0 Kd3 7c4/9h0 8d1 8s1 Jh2 9d3/3h0 3s0 Qc0 Qd2 Qh4",
            "win": 0.6,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": true,
            "result": -3,
            "playerName": "pid5693342",
            "orderIndex": 1,
            "hero": true,
            "dead": "2d0 2s0 7d0",
            "rows": "Jd0 Jc0 Ah0/8c0 9c0 9s0 Td0 Tc0/4h0 4s0 6d0 6c0 6s0",
            "win": -0.6,
            "playerId": "pid5693342"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:34:47",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000075-1": [
        {
            "inFantasy": true,
            "result": 24,
            "playerName": "pid5118808",
            "orderIndex": 1,
            "hero": false,
            "dead": "4h0 8h1",
            "rows": "Jh0 Kh0 Kc0/8d0 9d0 Td0 Jd0 Kd0/5c0 7c0 Tc0 Qc0 Ac0",
            "win": 4.7,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": -24,
            "playerName": "pid5693342",
            "orderIndex": 0,
            "hero": true,
            "dead": "3d1 6d2 6h3 7d4",
            "rows": "As0 Qs3 8c4/2d0 4d0 5h0 4c2 5d2/Jc0 7s1 9h1 8s3 Th4",
            "win": -4.8,
            "playerId": "pid5693342"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:35:46",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000076-1": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid5118808",
            "orderIndex": 0,
            "hero": false,
            "dead": "Th1 2h2 6s3 4h4",
            "rows": "Ah1 Tc3 8h4/8s0 9h0 Js2 Ts3 7d4/3d0 Td0 Kd0 4d1 Jd2",
            "win": 0.6,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "pid5693342",
            "orderIndex": 1,
            "hero": true,
            "dead": "3h1 Qd2 Jh3 3s4",
            "rows": "Ks0 Qs1 As4/9d0 6d1 6h2 9s2 Jc4/3c0 7c0 Ac0 2c3 8c3",
            "win": -0.6,
            "playerId": "pid5693342"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:37:15",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000077-1": [
        {
            "inFantasy": false,
            "result": -13,
            "playerName": "pid5118808",
            "orderIndex": 1,
            "hero": false,
            "dead": "5h1 4d2 Ac3 3h4",
            "rows": "Jd2 Js3 9c4/6s0 8s0 9h1 7s2 Ts3/Qh0 Kd0 Kc0 Qd1 5d4",
            "win": -2.6,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": 13,
            "playerName": "pid5693342",
            "orderIndex": 0,
            "hero": true,
            "dead": "4s1 4h2 8h3 6d4",
            "rows": "Qs1 Qc2 Ad3/3d0 5c0 Td2 Tc3 3s4/2h0 2d0 Jh0 2c1 As4",
            "win": 2.5,
            "playerId": "pid5693342"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:38:12",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000078-1": [
        {
            "inFantasy": false,
            "result": -2,
            "playerName": "pid5118808",
            "orderIndex": 0,
            "hero": false,
            "dead": "Ts1 As2 4d3 6c4",
            "rows": "Ad0 Ac0 6s4/8c0 Qc1 9d2 Qs3 8s4/3h0 Th0 Kh1 4h2 9h3",
            "win": -0.4,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": true,
            "result": 2,
            "playerName": "pid5693342",
            "orderIndex": 1,
            "hero": true,
            "dead": "2h0",
            "rows": "6h0 Qd0 Ah0/2c0 3c0 9c0 Tc0 Kc0/5d0 5s0 Jh0 Jc0 Js0",
            "win": 0.4,
            "playerId": "pid5693342"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:38:48",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000079-1": [
        {
            "inFantasy": true,
            "result": 25,
            "playerName": "pid5118808",
            "orderIndex": 1,
            "hero": false,
            "dead": "4h0 3c1 9c2",
            "rows": "Th0 Ts0 Qd0/2s0 5s0 9s0 Ks0 As0/8h0 8s0 Jd0 Jc0 Js0",
            "win": 4.8,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": -25,
            "playerName": "pid5693342",
            "orderIndex": 0,
            "hero": true,
            "dead": "4s1 5d2 3d3 Qc4",
            "rows": "Qs2 Ad2 Tc3/9d0 6h1 6s1 4c3 7s4/3h0 5h0 Jh0 Kh0 6d4",
            "win": -5,
            "playerId": "pid5693342"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:39:35",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000080-1": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5118808",
            "orderIndex": 0,
            "hero": false,
            "dead": "7h1 5c2 5d3 3h4",
            "rows": "Ah0 Ac1 8s2/4d0 7d0 4h2 2s3 4c4/9h0 Ts0 9d1 6d3 9c4",
            "win": 1.2,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5693342",
            "orderIndex": 1,
            "hero": true,
            "dead": "7c1 Th2 7s3 Qs4",
            "rows": "Ad0 Tc3 Ks4/5h0 5s0 6h0 6s2 Qd4/Jc0 8h1 8d1 Jd2 Js3",
            "win": -1.2,
            "playerId": "pid5693342"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:40:48",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000081-1": [
        {
            "inFantasy": true,
            "result": 27,
            "playerName": "pid5118808",
            "orderIndex": 1,
            "hero": false,
            "dead": "6h0 7c1 6c2",
            "rows": "7h0 Ad0 As0/2s0 4s0 9s0 Js0 Qs0/4d0 9d0 Td0 Qd0 Kd0",
            "win": 5.2,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": -27,
            "playerName": "pid5693342",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qc1 6d2 2c3 Tc4",
            "rows": "Ah0 Ks1 Kh2/4c0 5d0 5s0 3d3 5h4/8s0 8c1 Ts2 9c3 2d4",
            "win": -5.4,
            "playerId": "pid5693342"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:42:29",
    "roomId": "21950775"
}


