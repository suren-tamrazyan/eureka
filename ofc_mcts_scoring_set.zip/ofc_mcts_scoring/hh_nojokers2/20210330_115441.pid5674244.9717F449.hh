{
    "stakes": 5,
    "handData": {"210330131941-21937123-0000000-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5011126",
            "orderIndex": 1,
            "hero": false,
            "dead": "4d1 3c2 8s3 Qd4",
            "rows": "Kh0 Kc0 Qs2/9s0 6d1 8c1 As2 2c4/5h0 Jh0 Ts3 Jc3 Th4",
            "win": 0,
            "playerId": "pid5011126"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5674244",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qh1 Td2 3s3 6s4",
            "rows": "Ks0 2d3 4h3/6h0 8d0 8h1 7h2 2s4/5c0 Tc0 Qc1 4c2 2h4",
            "win": 0,
            "playerId": "pid5674244"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:54:41",
    "roomId": "21937123"
}


{
    "stakes": 5,
    "handData": {"210330131941-21937123-0000001-1": [
        {
            "inFantasy": false,
            "result": 8,
            "playerName": "pid5011126",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qh1 9d2 8s3 3d4",
            "rows": "Ad2 9h3 Tc4/4c0 5c0 6h0 3h2 5s4/9s0 Th0 8h1 Jd1 Qs3",
            "win": 39,
            "playerId": "pid5011126"
        },
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid5674244",
            "orderIndex": 1,
            "hero": true,
            "dead": "4s1 Ts2 3c3 Kc4",
            "rows": "Qc0 Jh2 Js2/Kh0 3s1 Ks1 6s3 8c3/5d0 8d0 Td0 4d4 5h4",
            "win": -40,
            "playerId": "pid5674244"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:56:04",
    "roomId": "21937123"
}


{
    "stakes": 5,
    "handData": {"210330131941-21937123-0000002-1": [
        {
            "inFantasy": false,
            "result": 7,
            "playerName": "pid5011126",
            "orderIndex": 1,
            "hero": false,
            "dead": "Th1 7h2 3s3 Js4",
            "rows": "Jd2 Jh3 3d4/4c0 5h0 8s1 5s2 4d3/6c0 6s0 Qh0 Qd1 6d4",
            "win": 34,
            "playerId": "pid5011126"
        },
        {
            "inFantasy": false,
            "result": -7,
            "playerName": "pid5674244",
            "orderIndex": 0,
            "hero": true,
            "dead": "2c1 5c2 Ts3 2s4",
            "rows": "Kc1 3c3 7s3/6h0 9h0 9c1 9s2 Tc2/2d0 7d0 Kd0 5d4 Ad4",
            "win": -35,
            "playerId": "pid5674244"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:57:01",
    "roomId": "21937123"
}


{
    "stakes": 5,
    "handData": {"210330131941-21937123-0000003-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5011126",
            "orderIndex": 0,
            "hero": false,
            "dead": "2h1 3s2 2s3 8c4",
            "rows": "Qh2 5h3 As3/6c0 Tc0 3c1 9c1 Jc2/7d0 8d0 Kd0 3h4 Th4",
            "win": 0,
            "playerId": "pid5011126"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5674244",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qs1 Jd2 8s3 Kh4",
            "rows": "Ac0 Ad2 Jh3/4d0 7c0 7s0 6h2 7h4/Ts0 9h1 9d1 2d3 2c4",
            "win": 0,
            "playerId": "pid5674244"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:58:19",
    "roomId": "21937123"
}


{
    "stakes": 5,
    "handData": {"210330131941-21937123-0000004-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5011126",
            "orderIndex": 2,
            "hero": false,
            "dead": "8h1 5d2 Jd3 Qs4",
            "rows": "Ad0 7c2 Ac3/3d0 5s0 3h1 5c1 8d4/Th0 Ts0 9d2 6s3 4h4",
            "win": 0,
            "playerId": "pid5011126"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid419970",
            "orderIndex": 0,
            "hero": false,
            "dead": "7s1 4d2 6d3 2d4",
            "rows": "Qd1 Qh2 5h4/9s0 Js2 8s3 Qc3 As4/2c0 6c0 8c0 Tc0 3c1",
            "win": 0,
            "playerId": "pid419970"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5674244",
            "orderIndex": 1,
            "hero": true,
            "dead": "Td1 2s2 Kc3 Ah4",
            "rows": "Kh0 Ks1 9c3/3s0 7d0 7h2 6h3 Kd4/4c0 4s0 Jh1 Jc2 2h4",
            "win": 0,
            "playerId": "pid5674244"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:00:03",
    "roomId": "21937123"
}


{
    "stakes": 5,
    "handData": {"210330131941-21937123-0000005-1": [
        {
            "inFantasy": false,
            "result": -7,
            "playerName": "pid5011126",
            "orderIndex": 1,
            "hero": false,
            "dead": "7c1 Ad2 2s3 5c4",
            "rows": "Kh0 7s3 7h4/3s0 6s0 6c1 2d2 Qh3/9d0 Qd0 Td1 Jd2 Kd4",
            "win": -35,
            "playerId": "pid5011126"
        },
        {
            "inFantasy": false,
            "result": 14,
            "playerName": "pid419970",
            "orderIndex": 2,
            "hero": false,
            "dead": "3d1 2h2 3c3 7d4",
            "rows": "6h2 9h2 6d4/4s0 Ts0 8s1 8c3 Th3/5h0 5s0 Jc0 Jh1 Kc4",
            "win": 68,
            "playerId": "pid419970"
        },
        {
            "inFantasy": false,
            "result": -7,
            "playerName": "pid5674244",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qs1 8h2 3h3 Qc4",
            "rows": "Ah0 As0 5d3/4d0 Ac1 2c2 4h2 Tc4/9c0 Js0 9s1 Ks3 8d4",
            "win": -35,
            "playerId": "pid5674244"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:01:46",
    "roomId": "21937123"
}


{
    "stakes": 5,
    "handData": {"210330131941-21937123-0000006-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5011126",
            "orderIndex": 0,
            "hero": false,
            "dead": "3h1 Jh2 5c3 8h4",
            "rows": "Ah0 Kd1 Kh2/4h0 7h1 2c2 4s3 8s4/8d0 8c0 Qd0 6s3 Qc4",
            "win": 0,
            "playerId": "pid5011126"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5674244",
            "orderIndex": 1,
            "hero": true,
            "dead": "Ts1 7d2 Kc3 Ac4",
            "rows": "Ks0 Ad1 Qs4/2h0 4c2 3s3 6h3 Th4/9c0 9s0 Js0 9h1 Jc2",
            "win": 0,
            "playerId": "pid5674244"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:03:05",
    "roomId": "21937123"
}


{
    "stakes": 5,
    "handData": {"210330131941-21937123-0000007-1": [
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid5011126",
            "orderIndex": 1,
            "hero": false,
            "dead": "7h1 6d2 4c3 2d4",
            "rows": "Ah0 Ks1 As2/2s0 3c0 Tc1 Ad3 Ac4/9d0 Qh0 Jd2 9h3 Qd4",
            "win": -40,
            "playerId": "pid5011126"
        },
        {
            "inFantasy": false,
            "result": 8,
            "playerName": "pid5674244",
            "orderIndex": 0,
            "hero": true,
            "dead": "8d1 2h2 4h3 7c4",
            "rows": "6h3 Td3 Kc4/3s0 5c0 7s0 3h1 7d1/Th0 Jh0 9s2 Qs2 8s4",
            "win": 39,
            "playerId": "pid5674244"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:04:18",
    "roomId": "21937123"
}


{
    "stakes": 5,
    "handData": {"210330131941-21937123-0000008-1": [
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid5011126",
            "orderIndex": 0,
            "hero": false,
            "dead": "5s1 3s2 5c3 5h4",
            "rows": "Ac1 Jd2 Ks4/3d0 3c0 4c0 6d2 4s3/Th0 Qd0 Td1 8d3 7s4",
            "win": -85,
            "playerId": "pid5011126"
        },
        {
            "inFantasy": false,
            "result": 17,
            "playerName": "pid5674244",
            "orderIndex": 1,
            "hero": true,
            "dead": "2d1 Ad2 As3 4h4",
            "rows": "Qc0 7d4 Qs4/6c0 9d0 Ts1 6s3 9c3/2h0 3h0 6h1 9h2 Qh2",
            "win": 82,
            "playerId": "pid5674244"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:05:47",
    "roomId": "21937123"
}


{
    "stakes": 5,
    "handData": {"210330131941-21937123-0000009-1": [
        {
            "inFantasy": false,
            "result": -24,
            "playerName": "pid5011126",
            "orderIndex": 1,
            "hero": false,
            "dead": "9s1 6h2 Qh3 Qs4",
            "rows": "Ah0 As0 Ts4/3h0 6c0 4c1 5s2 7c2/Qd0 Kd1 4d3 Ad3 9h4",
            "win": -120,
            "playerId": "pid5011126"
        },
        {
            "inFantasy": true,
            "result": 24,
            "playerName": "pid5674244",
            "orderIndex": 0,
            "hero": true,
            "dead": "5c0",
            "rows": "9c0 Th0 Qc0/3d0 3s0 8h0 8d0 8s0/7h0 7s0 Kh0 Kc0 Ks0",
            "win": 116,
            "playerId": "pid5674244"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:06:43",
    "roomId": "21937123"
}


{
    "stakes": 5,
    "handData": {"210330131941-21937123-0000010-1": [
        {
            "inFantasy": false,
            "result": -24,
            "playerName": "pid5011126",
            "orderIndex": 0,
            "hero": false,
            "dead": "2c1 4h2 4c3 Kh4",
            "rows": "Ks1 Qs2 Js4/8s0 9c0 3h1 Th3 Ts3/5d0 Td0 Jd0 8d2 Jc4",
            "win": -43,
            "playerId": "pid5011126"
        },
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "pid282652",
            "orderIndex": 1,
            "hero": false,
            "dead": "6c1 4s2 3s3 5h4",
            "rows": "Kd0 4d3 Ad4/2d0 9d0 7s1 7d2 Kc4/6h0 8h0 Qh1 Ah2 7h3",
            "win": -25,
            "playerId": "pid282652"
        },
        {
            "inFantasy": false,
            "result": 29,
            "playerName": "pid5674244",
            "orderIndex": 2,
            "hero": true,
            "dead": "9h1 Jh2 9s3 5s4",
            "rows": "As1 Qc4 Ac4/2h0 2s0 3d0 6d1 6s2/7c0 Tc0 5c2 3c3 8c3",
            "win": 66,
            "playerId": "pid5674244"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:07:58",
    "roomId": "21937123"
}


{
    "stakes": 5,
    "handData": {"210330131941-21937123-0000011-1": [
        {
            "inFantasy": false,
            "result": -25,
            "playerName": "pid282652",
            "orderIndex": 1,
            "hero": false,
            "dead": "5d1 Jd2 Ts3 9s4",
            "rows": "7d1 Qd2 Qs2/3h0 Th0 2h1 Td3 6h4/4c0 Qc0 Ac0 Jc3 Kc4",
            "win": -125,
            "playerId": "pid282652"
        },
        {
            "inFantasy": true,
            "result": 25,
            "playerName": "pid5674244",
            "orderIndex": 0,
            "hero": true,
            "dead": "Js0 8s0 2d0",
            "rows": "Qh0 Ad0 As0/5s0 6s0 7c0 8d0 9c0/3d0 3c0 3s0 Kh0 Kd0",
            "win": 121,
            "playerId": "pid5674244"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:08:28",
    "roomId": "21937123"
}


{
    "stakes": 5,
    "handData": {"210330131941-21937123-0000012-1": [
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid282652",
            "orderIndex": 0,
            "hero": false,
            "dead": "Ts1 Ac2 8c3 Kc4",
            "rows": "Kh1 Qs3 6s4/8d0 5d1 7d2 6d3 7c4/4h0 4c0 9d0 9c0 9h2",
            "win": 24,
            "playerId": "pid282652"
        },
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "pid5674244",
            "orderIndex": 1,
            "hero": true,
            "dead": "Ks1 7h2 4d3 Jh4",
            "rows": "As0 Qd3 Tc4/2c0 5h0 2d1 3d2 3s4/Th0 Td0 Jd1 6c2 6h3",
            "win": -25,
            "playerId": "pid5674244"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:09:39",
    "roomId": "21937123"
}


{
    "stakes": 5,
    "handData": {"210330131941-21937123-0000013-1": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid282652",
            "orderIndex": 1,
            "hero": false,
            "dead": "7s1 6d2 4h3 8h4",
            "rows": "Ah0 As0 Kh3/2s0 3h0 9h2 9c2 6h4/Th0 Tc1 Qc1 Jh3 Qs4",
            "win": -60,
            "playerId": "pid282652"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid5674244",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h1 8s2 7c3 6s4",
            "rows": "Qd2 9d3 Ks4/3c0 5h0 5c1 8c3 Td4/4d0 4c0 7d0 7h1 4s2",
            "win": 58,
            "playerId": "pid5674244"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:10:41",
    "roomId": "21937123"
}


{
    "stakes": 5,
    "handData": {"210330131941-21937123-0000014-1": [
        {
            "inFantasy": false,
            "result": 8,
            "playerName": "pid282652",
            "orderIndex": 0,
            "hero": false,
            "dead": "5s1 5d2 6c3 Ad4",
            "rows": "7h3 Js3 7d4/6d0 8d0 8h1 9h1 9s2/2s0 Td0 Tc0 3c2 2h4",
            "win": 39,
            "playerId": "pid282652"
        },
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid5674244",
            "orderIndex": 1,
            "hero": true,
            "dead": "3d1 6s2 8c3 As4",
            "rows": "Ah1 Ts2 Ac3/2c0 Jh0 Jc1 Ks3 Kd4/5c0 6h0 8s0 9c2 9d4",
            "win": -40,
            "playerId": "pid5674244"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:11:59",
    "roomId": "21937123"
}


