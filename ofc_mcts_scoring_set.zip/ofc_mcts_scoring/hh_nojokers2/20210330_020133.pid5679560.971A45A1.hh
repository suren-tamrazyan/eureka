{
    "stakes": 20,
    "handData": {"210330062206-21915244-0000003-1": [
        {
            "inFantasy": false,
            "result": -2,
            "playerName": "pid5679594",
            "orderIndex": 1,
            "hero": false,
            "dead": "Kc1 2c2 5h3 4h4",
            "rows": "Ac0 Ad1 Qs2/4d0 7c0 7h3 Jh4 Jc4/Ts0 Jd0 9d1 Qc2 Ks3",
            "win": -40,
            "playerId": "pid5679594"
        },
        {
            "inFantasy": false,
            "result": 2,
            "playerName": "pid5679560",
            "orderIndex": 0,
            "hero": true,
            "dead": "Js1 7s2 2h3 5s4",
            "rows": "Qh0 As2 Ah4/6c0 8s0 8h1 9h1 6s3/2d0 Kd0 Qd2 8d3 5d4",
            "win": 39,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:01:33",
    "roomId": "21915244"
}


{
    "stakes": 20,
    "handData": {"210330062206-21915244-0000004-1": [
        {
            "inFantasy": true,
            "result": 0,
            "playerName": "pid5679594",
            "orderIndex": 0,
            "hero": false,
            "dead": "9h0 Ah1 3c2",
            "rows": "Th0 Td0 Tc0/2s0 3s0 4d0 5s0 6c0/6d0 9d0 Qd0 Kd0 Ad0",
            "win": 0,
            "playerId": "pid5679594"
        },
        {
            "inFantasy": true,
            "result": 0,
            "playerName": "pid5679560",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jh0 4s0 Kc0",
            "rows": "Qh0 Qc0 As0/2h0 2d0 2c0 5d0 5c0/8h0 8d0 8c0 9c0 9s0",
            "win": 0,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:02:04",
    "roomId": "21915244"
}


{
    "stakes": 20,
    "handData": {"210330062206-21915244-0000005-1": [
        {
            "inFantasy": true,
            "result": 0,
            "playerName": "pid5679594",
            "orderIndex": 1,
            "hero": false,
            "dead": "4s0 5c1 2s2",
            "rows": "6c0 7s0 9c0/2d0 3d0 7d0 8d0 Qd0/3h0 6h0 7h0 Jh0 Kh0",
            "win": 0,
            "playerId": "pid5679594"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5679560",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jd1 Kd2 8c3 Ah4",
            "rows": "Ad0 Qc1 Qh3/4h0 Th0 4c1 2c3 Ts4/9s0 Ks0 8s2 Js2 5s4",
            "win": 0,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:02:45",
    "roomId": "21915244"
}


{
    "stakes": 20,
    "handData": {"210330062206-21915244-0000006-1": [
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5679594",
            "orderIndex": 0,
            "hero": false,
            "dead": "Kc1 2d2 Ac3 3d4",
            "rows": "As0 Ad2 Js4/3h0 3s0 4s1 4d2 9s4/Th0 Jd0 Jc1 7c3 7s3",
            "win": -200,
            "playerId": "pid5679594"
        },
        {
            "inFantasy": true,
            "result": 10,
            "playerName": "pid5679560",
            "orderIndex": 1,
            "hero": true,
            "dead": "2s0",
            "rows": "8s0 Qs0 Kd0/2h0 7h0 8h0 9h0 Qh0/5h0 5d0 5c0 5s0 6d0",
            "win": 194,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:03:29",
    "roomId": "21915244"
}


{
    "stakes": 20,
    "handData": {"210330062206-21915244-0000007-1": [
        {
            "inFantasy": true,
            "result": 3,
            "playerName": "pid5679594",
            "orderIndex": 1,
            "hero": false,
            "dead": "8c0 3c1 6d2",
            "rows": "Ts0 Qs0 Ad0/3h0 6h0 8h0 9h0 Kh0/5d0 5c0 5s0 Jd0 Js0",
            "win": 58,
            "playerId": "pid5679594"
        },
        {
            "inFantasy": true,
            "result": -3,
            "playerName": "pid5679560",
            "orderIndex": 0,
            "hero": true,
            "dead": "7d0",
            "rows": "Jc0 Kd0 Ah0/2h0 2s0 5h0 6c0 8d0/4h0 4d0 4c0 4s0 Tc0",
            "win": -60,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:03:57",
    "roomId": "21915244"
}


{
    "stakes": 20,
    "handData": {"210330062206-21915244-0000008-1": [
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid5679594",
            "orderIndex": 0,
            "hero": false,
            "dead": "2s1 3h2 3d3 5h4",
            "rows": "Ad1 Ks3 Qh4/2d0 6h0 6c0 4h2 Qc4/8h0 Ts0 8s1 8d2 5d3",
            "win": -118,
            "playerId": "pid5679594"
        },
        {
            "inFantasy": true,
            "result": 20,
            "playerName": "pid5679560",
            "orderIndex": 1,
            "hero": true,
            "dead": "3s0",
            "rows": "Td0 Kd0 Kc0/5c0 6d0 7c0 Ac0 As0/9h0 9c0 9s0 Jh0 Js0",
            "win": 114,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:04:48",
    "roomId": "21915244"
}


{
    "stakes": 20,
    "handData": {"210330062206-21915244-0000009-1": [
        {
            "inFantasy": false,
            "result": 4,
            "playerName": "pid5679594",
            "orderIndex": 0,
            "hero": false,
            "dead": "Js1 4c2 8c3 Ah4",
            "rows": "Ac1 As3 Qh4/2h0 2d0 7c0 7h2 3h3/4s0 5s0 7s1 Ks2 3s4",
            "win": 78,
            "playerId": "pid5679594"
        },
        {
            "inFantasy": false,
            "result": -4,
            "playerName": "pid5679560",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qd1 5h2 3c3 4h4",
            "rows": "Kh0 Kd1 6d4/5d0 Ad0 5c3 Jh3 Jd4/Tc0 Jc0 9s1 8h2 Qs2",
            "win": -80,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:06:15",
    "roomId": "21915244"
}


{
    "stakes": 20,
    "handData": {"210330062206-21915244-0000010-1": [
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "pid5679594",
            "orderIndex": 1,
            "hero": false,
            "dead": "5d0 3c1 2s2",
            "rows": "Jd0 Kd0 Ks0/6c0 7c0 8h0 9c0 Th0/4s0 5s0 7s0 8s0 Js0",
            "win": 116,
            "playerId": "pid5679594"
        },
        {
            "inFantasy": true,
            "result": -6,
            "playerName": "pid5679560",
            "orderIndex": 0,
            "hero": true,
            "dead": "3h0 3d0",
            "rows": "Qh0 Ah0 Ad0/4h0 4c0 5c0 6h0 6s0/9s0 Tc0 Jc0 Qd0 Kh0",
            "win": -120,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:06:46",
    "roomId": "21915244"
}


{
    "stakes": 20,
    "handData": {"210330062206-21915244-0000011-1": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5679594",
            "orderIndex": 0,
            "hero": false,
            "dead": "5c1 9c2 8d3 9d4",
            "rows": "As2 7s3 Jh4/6c0 8c0 8h1 6s2 5d3/3h0 Td0 Ts0 Th1 2h4",
            "win": 116,
            "playerId": "pid5679594"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5679560",
            "orderIndex": 1,
            "hero": true,
            "dead": "Tc1 3s2 Kc3 Js4",
            "rows": "Ks0 Kd2 4d4/5s0 8s0 Ah1 5h3 2c4/Qd0 Qs0 2s1 4s2 Qh3",
            "win": -120,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:08:05",
    "roomId": "21915244"
}


{
    "stakes": 20,
    "handData": {"210330062206-21915244-0000012-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5679594",
            "orderIndex": 1,
            "hero": false,
            "dead": "9d1 Td2 7d3 Kh4",
            "rows": "Qd1 3d2 Kc4/6c0 9c0 3c1 5c2 7c3/6s0 8s0 Ks0 5s3 4c4",
            "win": 0,
            "playerId": "pid5679594"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5679560",
            "orderIndex": 0,
            "hero": true,
            "dead": "2c1 2s2 6h3 Kd4",
            "rows": "Ah0 Jd2 5d3/3h0 6d0 5h1 2d2 2h3/9s0 Jc0 8h1 4d4 7s4",
            "win": 0,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:09:30",
    "roomId": "21915244"
}


{
    "stakes": 20,
    "handData": {"210330062206-21915244-0000013-1": [
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid5679594",
            "orderIndex": 0,
            "hero": false,
            "dead": "Ks1 Qc2 2s3 Js4",
            "rows": "As0 Ah2 Jd4/3d0 4h0 8c1 3c3 6h4/6s0 Ts0 Th1 2h2 6c3",
            "win": -280,
            "playerId": "pid5679594"
        },
        {
            "inFantasy": false,
            "result": 14,
            "playerName": "pid5679560",
            "orderIndex": 1,
            "hero": true,
            "dead": "5h1 Jh2 3s3 9h4",
            "rows": "Ac0 5c4 Td4/Jc0 Tc1 9d2 Qd2 Kh3/4s0 5s0 Qs0 8s1 9s3",
            "win": 272,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:10:56",
    "roomId": "21915244"
}


{
    "stakes": 20,
    "handData": {"210330062206-21915244-0000014-1": [
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid5679594",
            "orderIndex": 1,
            "hero": false,
            "dead": "6c1 Jc2 9s3 3d4",
            "rows": "Qc3 Jh4 Kd4/2h0 8c0 2d2 8s2 5h3/5d0 9d0 Td0 6d1 7d1",
            "win": 194,
            "playerId": "pid5679594"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5679560",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ks1 9c2 Ts3 7c4",
            "rows": "As0 Ad1 Kc3/3s0 3h1 2c2 Js3 3c4/6h0 9h0 Qh0 6s2 2s4",
            "win": -200,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:12:21",
    "roomId": "21915244"
}


{
    "stakes": 20,
    "handData": {"210330062206-21915244-0000015-1": [
        {
            "inFantasy": false,
            "result": 8,
            "playerName": "pid5679594",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jh1 Js2 Kc3 Th4",
            "rows": "Td3 Ts3 2h4/3h0 3s0 5d0 3d1 Jd1/6c0 7c0 5s2 8h2 9s4",
            "win": 155,
            "playerId": "pid5679594"
        },
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid5679560",
            "orderIndex": 1,
            "hero": true,
            "dead": "7d1 3c2 2s3 Qc4",
            "rows": "Ks2 2d3 8s3/Qd0 4s1 9h1 Ah4 As4/6s0 7h0 8d0 9d0 Tc2",
            "win": -160,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:13:37",
    "roomId": "21915244"
}


{
    "stakes": 20,
    "handData": {"210330062206-21915244-0000016-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5679594",
            "orderIndex": 1,
            "hero": false,
            "dead": "3c1 5c2 Qc3 Jh4",
            "rows": "As1 4c2 4h4/2c0 Jc1 6d2 2d3 6s3/4s0 5d0 6h0 8s0 Ad4",
            "win": 0,
            "playerId": "pid5679594"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5679560",
            "orderIndex": 0,
            "hero": true,
            "dead": "9s1 9d2 7h3 Tc4",
            "rows": "Qs0 Qh1 2h2/3d0 5h0 4d2 Ah3 7d4/8c0 Kc0 8d1 Kh3 6c4",
            "win": 0,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:14:59",
    "roomId": "21915244"
}


{
    "stakes": 20,
    "handData": {"210330062206-21915244-0000017-1": [
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "pid5679594",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jc1 Jh2 3s3 4c4",
            "rows": "Ad0 Qc1 5c3/2h0 6c0 9c1 Ks2 Kh4/3d0 Td0 2d2 Qd3 5d4",
            "win": -100,
            "playerId": "pid5679594"
        },
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid5679560",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jd1 9h2 7c3 7d4",
            "rows": "Kc3 Ac3 Kd4/3c0 8d0 7h1 7s1 8s2/Tc0 Ts0 Qs0 4d2 Qh4",
            "win": 97,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:16:21",
    "roomId": "21915244"
}


{
    "stakes": 20,
    "handData": {"210330062206-21915244-0000018-1": [
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid5679594",
            "orderIndex": 1,
            "hero": false,
            "dead": "3h1 2d2 7s3 6s4",
            "rows": "Qc1 2c2 Kc3/5c0 8h0 4h1 4c3 4s4/9d0 9s0 Js0 9h2 Qd4",
            "win": -340,
            "playerId": "pid5679594"
        },
        {
            "inFantasy": true,
            "result": 17,
            "playerName": "pid5679560",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h0 5s0",
            "rows": "8d0 8c0 Ac0/Td0 Jc0 Qs0 Kh0 Ad0/6h0 6d0 6c0 7h0 7c0",
            "win": 330,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:17:05",
    "roomId": "21915244"
}


{
    "stakes": 20,
    "handData": {"210330062206-21915244-0000019-1": [
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid4483271",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qs1 9s2 6d3 2s4",
            "rows": "Ah0 6c3 Ac3/5c0 8c0 5h1 8d2 3h4/4d0 Qd0 4h1 4c2 Jh4",
            "win": 19,
            "playerId": "pid4483271"
        },
        {
            "inFantasy": false,
            "result": -38,
            "playerName": "pid5679594",
            "orderIndex": 1,
            "hero": false,
            "dead": "Td1 Kh2 Ks3 Jd4",
            "rows": "Kd0 Kc1 9h2/3d0 7c0 2d1 9d4 Qc4/5s0 Js0 8s2 5d3 8h3",
            "win": -760,
            "playerId": "pid5679594"
        },
        {
            "inFantasy": false,
            "result": 37,
            "playerName": "pid5679560",
            "orderIndex": 2,
            "hero": true,
            "dead": "2c1 2h2 6s3 9c4",
            "rows": "Ad0 As3 Jc4/4s0 7h0 7d0 6h2 7s3/Th0 Tc1 Ts1 3s2 3c4",
            "win": 718,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:18:51",
    "roomId": "21915244"
}


{
    "stakes": 20,
    "handData": {"210330062206-21915244-0000020-1": [
        {
            "inFantasy": true,
            "result": 32,
            "playerName": "pid4483271",
            "orderIndex": 2,
            "hero": false,
            "dead": "3c0 7c1 Qc2",
            "rows": "Kh0 Kc0 Ks0/5h0 6h0 7h0 9h0 Qh0/3d0 5d0 Qd0 Kd0 Ad0",
            "win": 0,
            "playerId": "pid4483271"
        },
        {
            "inFantasy": false,
            "result": -53,
            "playerName": "pid5679594",
            "orderIndex": 0,
            "hero": false,
            "dead": "5s1 3h2 7d3 2c4",
            "rows": "Td2 6s4 9c4/8h0 2d1 2s1 6d3 6c3/4h0 4d0 Jh0 Js0 4c2",
            "win": -179,
            "playerId": "pid5679594"
        },
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "pid5679560",
            "orderIndex": 1,
            "hero": true,
            "dead": "2h0 5c0 Jc0",
            "rows": "Ah0 Ac0 As0/8c0 9d0 Th0 Jd0 Qs0/3s0 4s0 8s0 9s0 Ts0",
            "win": 174,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:19:44",
    "roomId": "21915244"
}


{
    "stakes": 20,
    "handData": {"210330062206-21915244-0000021-1": [
        {
            "inFantasy": true,
            "result": 4,
            "playerName": "pid4483271",
            "orderIndex": 0,
            "hero": false,
            "dead": "6d0 5s1 3h2",
            "rows": "Qh0 Qd0 Qc0/6s0 7s0 8c0 9d0 Td0/2c0 5c0 7c0 9c0 Ac0",
            "win": 78,
            "playerId": "pid4483271"
        },
        {
            "inFantasy": true,
            "result": -4,
            "playerName": "pid5679560",
            "orderIndex": 1,
            "hero": true,
            "dead": "5h0 3c0 4h0",
            "rows": "Kc0 Ah0 As0/3d0 4d0 5d0 7d0 8d0/Th0 Tc0 Jh0 Jc0 Js0",
            "win": -80,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:20:12",
    "roomId": "21915244"
}


{
    "stakes": 20,
    "handData": {"210330062206-21915244-0000022-1": [
        {
            "inFantasy": true,
            "result": 39,
            "playerName": "pid4483271",
            "orderIndex": 1,
            "hero": false,
            "dead": "6h0 Jd1 9s2",
            "rows": "Qd0 Kc0 Ks0/4d0 4c0 5h0 8c0 8s0/Th0 Jh0 Qh0 Kh0 Ah0",
            "win": 757,
            "playerId": "pid4483271"
        },
        {
            "inFantasy": false,
            "result": -39,
            "playerName": "pid5679560",
            "orderIndex": 0,
            "hero": true,
            "dead": "6d1 2h2 3s3 7h4",
            "rows": "Js2 Ts3 As4/3c0 7c0 Qc1 Qs2 2d3/5s0 9h0 9d0 5d1 Kd4",
            "win": -780,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:21:00",
    "roomId": "21915244"
}


{
    "stakes": 20,
    "handData": {"210330062206-21915244-0000023-1": [
        {
            "inFantasy": true,
            "result": 20,
            "playerName": "pid4483271",
            "orderIndex": 0,
            "hero": false,
            "dead": "6h0 Ts1 7c2",
            "rows": "Jh0 Ks0 Ac0/2d0 4d0 7d0 8d0 Jd0/5d0 5s0 9h0 9d0 9c0",
            "win": 388,
            "playerId": "pid4483271"
        },
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid5679560",
            "orderIndex": 1,
            "hero": true,
            "dead": "2c1 3c2 2s3 Kd4",
            "rows": "Ah0 As0 4h4/7s0 5c1 6s2 5h3 7h3/9s0 Tc0 Qs1 Qc2 3h4",
            "win": -400,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:21:46",
    "roomId": "21915244"
}


{
    "stakes": 20,
    "handData": {"210330062206-21915244-0000024-1": [
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "pid5679594",
            "orderIndex": 0,
            "hero": false,
            "dead": "2d1 8d2 Ad3 4c4",
            "rows": "Kh0 Kc0 8h4/3c0 6h2 6c2 3h3 Qh3/2s0 4s0 6s1 Ks1 Ts4",
            "win": 349,
            "playerId": "pid5679594"
        },
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid5679560",
            "orderIndex": 1,
            "hero": true,
            "dead": "8s1 6d2 2h3 Js4",
            "rows": "As0 Ac1 4h3/3d0 7h0 5s1 7s2 Jc4/9d0 9c0 Jd2 Qs3 7d4",
            "win": -360,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:23:05",
    "roomId": "21915244"
}


{
    "stakes": 20,
    "handData": {"210330062206-21915244-0000025-1": [
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "pid5679594",
            "orderIndex": 1,
            "hero": false,
            "dead": "7d0 4d1",
            "rows": "Tc0 Qd0 Qc0/6s0 7s0 9s0 Ts0 As0/5h0 5d0 Jh0 Jd0 Js0",
            "win": 407,
            "playerId": "pid5679594"
        },
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "pid5679560",
            "orderIndex": 0,
            "hero": true,
            "dead": "5c1 Th2 Kc3 5s4",
            "rows": "Ad1 Kh3 8s4/4c0 2h2 6c2 2s3 2d4/3h0 4h0 7h0 8h0 Qh1",
            "win": -420,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:23:50",
    "roomId": "21915244"
}


{
    "stakes": 20,
    "handData": {"210330062206-21915244-0000026-1": [
        {
            "inFantasy": false,
            "result": 8,
            "playerName": "pid5679594",
            "orderIndex": 0,
            "hero": false,
            "dead": "5c1 Td2 6s3 Ah4",
            "rows": "Qc0 Kc2 Ts3/2d0 3h0 As2 7d3 4s4/7s0 8c0 Th1 Jc1 9c4",
            "win": 153,
            "playerId": "pid5679594"
        },
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid5679560",
            "orderIndex": 1,
            "hero": true,
            "dead": "Js1 5s2 8h3 Tc4",
            "rows": "Qd3 Qs3 7c4/4c0 8d0 3d1 3s2 8s2/2h0 7h0 Jh0 6h1 2s4",
            "win": -158,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:25:23",
    "roomId": "21915244"
}


{
    "stakes": 20,
    "handData": {"210330062206-21915244-0000027-1": [
        {
            "inFantasy": false,
            "result": -1,
            "playerName": "pid5679594",
            "orderIndex": 1,
            "hero": false,
            "dead": "7s1 4h2 7h3 Qs4",
            "rows": "9h2 Th3 3s4/8c0 Jc0 Jh1 3c3 Jd4/Td0 Qd0 Ad0 3d1 8d2",
            "win": -20,
            "playerId": "pid5679594"
        },
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid5679560",
            "orderIndex": 0,
            "hero": true,
            "dead": "9s1 Ks2 4d3 2d4",
            "rows": "Kh0 Kd1 5s4/4s0 As1 8s2 Ac2 Kc3/6h0 6s0 Qc0 7c3 6c4",
            "win": 19,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:26:48",
    "roomId": "21915244"
}


{
    "stakes": 20,
    "handData": {"210330062206-21915244-0000028-1": [
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid5679594",
            "orderIndex": 0,
            "hero": false,
            "dead": "3s1 9h2 2h3 4s4",
            "rows": "Ac1 5c3 Kd4/5s0 7h0 4d2 6h2 3c4/9s0 Tc0 Qh0 Kh1 Jh3",
            "win": -340,
            "playerId": "pid5679594"
        },
        {
            "inFantasy": true,
            "result": 17,
            "playerName": "pid5679560",
            "orderIndex": 1,
            "hero": true,
            "dead": "8c0 Th0",
            "rows": "Jd0 Ah0 As0/4c0 5d0 6d0 7s0 8d0/2s0 6s0 8s0 Qs0 Ks0",
            "win": 330,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:27:35",
    "roomId": "21915244"
}


{
    "stakes": 20,
    "handData": {"210330062206-21915244-0000029-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5679594",
            "orderIndex": 1,
            "hero": false,
            "dead": "5s1 Ts2 4s3 7c4",
            "rows": "Qh1 Qd2 Ad4/2h0 3h0 3s0 9h3 7s4/7d0 8d0 6d1 5d2 4d3",
            "win": 0,
            "playerId": "pid5679594"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5679560",
            "orderIndex": 0,
            "hero": true,
            "dead": "9c1 Qc2 Ah3 5h4",
            "rows": "Ac0 As0 Kh3/4c0 3c2 6h2 4h3 2c4/8h0 Jd0 8c1 Jh1 2d4",
            "win": 0,
            "playerId": "pid5679560"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:29:10",
    "roomId": "21915244"
}


