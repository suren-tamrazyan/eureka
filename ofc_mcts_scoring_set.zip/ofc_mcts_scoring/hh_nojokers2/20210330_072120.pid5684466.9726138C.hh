{
    "stakes": 0.2,
    "handData": {"210330114639-21933155-0000000-1": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5450708",
            "orderIndex": 1,
            "hero": false,
            "dead": "8d1 2c2 Jc3 Th4",
            "rows": "Ah0 Jd2 2s3/4d0 6h0 8h1 7h3 Ts4/5s0 Ks0 Qs1 Qc2 3s4",
            "win": -2.4,
            "playerId": "pid5450708"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid5684466",
            "orderIndex": 0,
            "hero": true,
            "dead": "9c1 6c2 4h3 7c4",
            "rows": "Jh0 Qd1 Js4/Kh0 Kc0 5c3 7d3 6s4/7s0 8s0 9s1 8c2 9h2",
            "win": 2.3,
            "playerId": "pid5684466"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:21:20",
    "roomId": "21933155"
}


{
    "stakes": 0.2,
    "handData": {"210330114639-21933155-0000001-1": [
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid5450708",
            "orderIndex": 0,
            "hero": false,
            "dead": "4c1 6h2 4h3 Qd4",
            "rows": "Ah0 Ad0 8c2/2d0 3d1 2h3 Ac3 7d4/Td0 Js0 Ks1 Ts2 7h4",
            "win": -3.2,
            "playerId": "pid5450708"
        },
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid5027364",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jc1 3s2 3h3 5s4",
            "rows": "Kc0 Qh2 As4/2c0 4d0 5c0 Kd3 5h4/9h0 8d1 9d1 6d2 9c3",
            "win": 0.2,
            "playerId": "pid5027364"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "pid5684466",
            "orderIndex": 2,
            "hero": true,
            "dead": "3c1 Jh2 8s3 Tc4",
            "rows": "Jd3 Qc3 Th4/5d0 6c0 8h0 7s2 7c4/9s0 Qs0 2s1 6s1 4s2",
            "win": 2.9,
            "playerId": "pid5684466"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:23:05",
    "roomId": "21933155"
}


{
    "stakes": 0.2,
    "handData": {"210330114639-21933155-0000002-1": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5450708",
            "orderIndex": 2,
            "hero": false,
            "dead": "9s1 6d2 Js3 2s4",
            "rows": "Ad0 Kd2 Ah2/5c0 5s0 2d1 2c3 Ks4/Th0 Tc0 4s1 8c3 Qh4",
            "win": -2.4,
            "playerId": "pid5450708"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid5027364",
            "orderIndex": 0,
            "hero": false,
            "dead": "7s1 2h2 8h3 8s4",
            "rows": "Kh1 4c2 Qd3/5d0 7h0 7d0 3s1 Td4/9d0 Jc0 6h2 Jh3 As4",
            "win": 2.3,
            "playerId": "pid5027364"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5684466",
            "orderIndex": 1,
            "hero": true,
            "dead": "4d1 6c2 4h3 Qc4",
            "rows": "Qs0 6s1 3d3/3c0 8d0 Kc1 7c3 3h4/5h0 9h0 9c2 Ac2 Jd4",
            "win": 0,
            "playerId": "pid5684466"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:25:07",
    "roomId": "21933155"
}


{
    "stakes": 0.2,
    "handData": {"210330114639-21933155-0000003-1": [
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid5450708",
            "orderIndex": 1,
            "hero": false,
            "dead": "2h1 Jd2 6h3 4h4",
            "rows": "Qc1 Kc4 Ac4/6d0 8d0 9h1 5d2 8h3/5s0 7s0 Qs0 Ts2 Ks3",
            "win": -2.8,
            "playerId": "pid5450708"
        },
        {
            "inFantasy": false,
            "result": 28,
            "playerName": "pid5027364",
            "orderIndex": 2,
            "hero": false,
            "dead": "2s1 8s2 9s3 2c4",
            "rows": "Qh3 Ad4 As4/7h0 7d0 3s1 7c2 Js3/5c0 6c0 9c0 Jc1 3c2",
            "win": 5.4,
            "playerId": "pid5027364"
        },
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid5684466",
            "orderIndex": 0,
            "hero": true,
            "dead": "5h1 8c2 Th3 3d4",
            "rows": "Qd0 Td2 Tc2/Kh0 Kd0 Jh1 9d3 Ah3/2d0 4s0 4c1 3h4 4d4",
            "win": -2.8,
            "playerId": "pid5684466"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:26:14",
    "roomId": "21933155"
}


{
    "stakes": 0.2,
    "handData": {"210330114639-21933155-0000004-1": [
        {
            "inFantasy": false,
            "result": 8,
            "playerName": "pid5450708",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jh1 Qc2 Ac3 6d4",
            "rows": "Kd2 Kc2 8c4/2s0 4h0 4c0 4s3 Ks4/6c0 8s0 6s1 Th1 6h3",
            "win": 1.6,
            "playerId": "pid5450708"
        },
        {
            "inFantasy": true,
            "result": 31,
            "playerName": "pid5027364",
            "orderIndex": 1,
            "hero": false,
            "dead": "2d0 2h1 Jc2",
            "rows": "Td0 Tc0 Ad0/5h0 7h0 9h0 Qh0 Kh0/3s0 5s0 7s0 Qs0 As0",
            "win": 6,
            "playerId": "pid5027364"
        },
        {
            "inFantasy": false,
            "result": -39,
            "playerName": "pid5684466",
            "orderIndex": 2,
            "hero": true,
            "dead": "2c1 8h2 8d3 3h4",
            "rows": "Ah0 Ts3 Qd4/7d0 7c0 9c1 3d2 3c3/5d0 Jd0 5c1 Js2 9s4",
            "win": -7.8,
            "playerId": "pid5684466"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:27:49",
    "roomId": "21933155"
}


{
    "stakes": 0.2,
    "handData": {"210330114639-21933155-0000005-1": [
        {
            "inFantasy": true,
            "result": 4,
            "playerName": "pid5450708",
            "orderIndex": 2,
            "hero": false,
            "dead": "7d0 3c1",
            "rows": "8c0 Kd0 Ks0/7s0 9d0 9c0 Jd0 Jc0/Qh0 Qd0 Ah0 Ad0 As0",
            "win": 0.8,
            "playerId": "pid5450708"
        },
        {
            "inFantasy": false,
            "result": 14,
            "playerName": "pid5027364",
            "orderIndex": 0,
            "hero": false,
            "dead": "8s1 6s2 7h3 2h4",
            "rows": "Kh0 Kc0 5h4/2s0 5d0 2d1 5s2 3s3/Th0 Jh1 Tc2 Td3 Ts4",
            "win": 2.7,
            "playerId": "pid5027364"
        },
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid5684466",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qs1 3h2 4s3 3d4",
            "rows": "Ac0 9h4 Js4/2c0 6c0 6d2 7c2 6h3/4h0 4c0 8h1 8d1 4d3",
            "win": -3.6,
            "playerId": "pid5684466"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:30:00",
    "roomId": "21933155"
}


{
    "stakes": 0.2,
    "handData": {"210330114639-21933155-0000006-1": [
        {
            "inFantasy": false,
            "result": -43,
            "playerName": "pid5450708",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jh1 Th2 8s3 7h4",
            "rows": "Ah0 Td1 3d2/2d0 6s0 4c2 5d3 Ac4/9d0 9c0 Qc1 Kh3 Qh4",
            "win": -8.6,
            "playerId": "pid5450708"
        },
        {
            "inFantasy": true,
            "result": 68,
            "playerName": "pid5027364",
            "orderIndex": 2,
            "hero": false,
            "dead": "Ad0 9h1",
            "rows": "7d0 7c0 7s0/2s0 Ts0 Qs0 Ks0 As0/6h0 6d0 6c0 8d0 8c0",
            "win": 13.2,
            "playerId": "pid5027364"
        },
        {
            "inFantasy": false,
            "result": -25,
            "playerName": "pid5684466",
            "orderIndex": 0,
            "hero": true,
            "dead": "9s1 2c2 2h3 5s4",
            "rows": "3s2 Kd2 3h4/4s0 5h0 8h1 4d3 4h4/Tc0 Jd0 Js0 Jc1 Qd3",
            "win": -5,
            "playerId": "pid5684466"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:31:39",
    "roomId": "21933155"
}


{
    "stakes": 0.2,
    "handData": {"210330114639-21933155-0000007-1": [
        {
            "inFantasy": false,
            "result": -38,
            "playerName": "pid5450708",
            "orderIndex": 0,
            "hero": false,
            "dead": "6c1 2s2 6s3 4s4",
            "rows": "As0 6d2 Td4/2c0 5h0 5d0 3h1 2d2/Kc0 Jd1 5s3 Jc3 3s4",
            "win": -3,
            "playerId": "pid5450708"
        },
        {
            "inFantasy": true,
            "result": 35,
            "playerName": "pid5027364",
            "orderIndex": 1,
            "hero": false,
            "dead": "6h0 3d1",
            "rows": "7h0 9d0 Ac0/4h0 4d0 Th0 Tc0 Ts0/8d0 8c0 Qh0 Qd0 Qs0",
            "win": 2.9,
            "playerId": "pid5027364"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid5684466",
            "orderIndex": 2,
            "hero": true,
            "dead": "Ah1 7s2 9s3 5c4",
            "rows": "Ad2 Kh3 Kd3/7d0 9c0 7c1 4c2 9h4/8h0 8s0 Js0 Jh1 Qc4",
            "win": 0,
            "playerId": "pid5684466"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:33:35",
    "roomId": "21933155"
}


{
    "stakes": 0.2,
    "handData": {"210330114639-21933155-0000008-1": [
        {
            "inFantasy": false,
            "result": -28,
            "playerName": "pid5027364",
            "orderIndex": 1,
            "hero": false,
            "dead": "6d1 2d2 6c3 Ts4",
            "rows": "Ac0 As0 Jd4/4d0 4s1 5c2 7s3 Jh4/3h0 Kh0 6h1 Th2 2h3",
            "win": -5.6,
            "playerId": "pid5027364"
        },
        {
            "inFantasy": true,
            "result": 28,
            "playerName": "pid5684466",
            "orderIndex": 0,
            "hero": true,
            "dead": "3s0 4c0",
            "rows": "9d0 Td0 Ah0/2c0 2s0 Qh0 Qd0 Qs0/7c0 8h0 8d0 8c0 8s0",
            "win": 5.4,
            "playerId": "pid5684466"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:34:18",
    "roomId": "21933155"
}


{
    "stakes": 0.2,
    "handData": {"210330114639-21933155-0000009-1": [
        {
            "inFantasy": false,
            "result": -23,
            "playerName": "pid5027364",
            "orderIndex": 0,
            "hero": false,
            "dead": "7d1 5d2 5h3 6c4",
            "rows": "Kh0 Qc1 Js4/2d0 4d1 4s2 2h3 7c3/8c0 8s0 Ts0 8d2 9s4",
            "win": -4.6,
            "playerId": "pid5027364"
        },
        {
            "inFantasy": true,
            "result": 23,
            "playerName": "pid5684466",
            "orderIndex": 1,
            "hero": true,
            "dead": "9d0 Kd0",
            "rows": "Td0 Tc0 Ac0/2s0 3s0 5s0 6s0 As0/3h0 6h0 8h0 Qh0 Ah0",
            "win": 4.5,
            "playerId": "pid5684466"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:34:58",
    "roomId": "21933155"
}


{
    "stakes": 0.2,
    "handData": {"210330114639-21933155-0000010-1": [
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid5450708",
            "orderIndex": 0,
            "hero": false,
            "dead": "3d1 6h2 Kc3 2d4",
            "rows": "Kd1 Td2 3h3/4d0 5h0 Jd1 8s3 8h4/9c0 Qh0 Qd0 Qs2 4s4",
            "win": -3.8,
            "playerId": "pid5450708"
        },
        {
            "inFantasy": false,
            "result": 19,
            "playerName": "pid5684466",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jc1 Tc2 5s3 7h4",
            "rows": "Ac2 8c4 As4/2c0 5d0 2h1 5c1 8d2/3s0 6s0 7s0 9s3 Ts3",
            "win": 3.7,
            "playerId": "pid5684466"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:36:19",
    "roomId": "21933155"
}


{
    "stakes": 0.2,
    "handData": {"210330114639-21933155-0000011-1": [
        {
            "inFantasy": false,
            "result": -23,
            "playerName": "pid5450708",
            "orderIndex": 1,
            "hero": false,
            "dead": "2c1 3c2 9c3 7s4",
            "rows": "Js1 8s2 Qs3/4d0 6d0 9d1 2d2 Qd4/2h0 3h0 9h0 Th3 5h4",
            "win": -4.6,
            "playerId": "pid5450708"
        },
        {
            "inFantasy": true,
            "result": 23,
            "playerName": "pid5684466",
            "orderIndex": 0,
            "hero": true,
            "dead": "6h0 2s0 Jd0",
            "rows": "Kd0 Ah0 Ad0/7d0 8h0 9s0 Ts0 Jh0/4c0 6c0 8c0 Qc0 Kc0",
            "win": 4.5,
            "playerId": "pid5684466"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:37:02",
    "roomId": "21933155"
}


{
    "stakes": 0.2,
    "handData": {"210330114639-21933155-0000012-1": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid5450708",
            "orderIndex": 0,
            "hero": false,
            "dead": "Kc1 Td2 Jh3 8s4",
            "rows": "Ad0 Ac1 Jd4/3d0 6c1 6s2 Ks3 Kd4/4s0 5s0 Ts0 As2 9s3",
            "win": 2.3,
            "playerId": "pid5450708"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5684466",
            "orderIndex": 1,
            "hero": true,
            "dead": "6d1 5h2 3c3 Ah4",
            "rows": "Qh2 Qd2 3h3/2h0 8c0 8h1 2c3 4c4/7h0 7d0 9h0 9c1 4h4",
            "win": -2.4,
            "playerId": "pid5684466"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:38:15",
    "roomId": "21933155"
}


{
    "stakes": 0.2,
    "handData": {"210330114639-21933155-0000013-1": [
        {
            "inFantasy": true,
            "result": 18,
            "playerName": "pid5450708",
            "orderIndex": 1,
            "hero": false,
            "dead": "5c0 9d1 3d2",
            "rows": "Qh0 Qd0 Qs0/3h0 4s0 5h0 6d0 7c0/7h0 8d0 9s0 Ts0 Jh0",
            "win": 3.5,
            "playerId": "pid5450708"
        },
        {
            "inFantasy": true,
            "result": -18,
            "playerName": "pid5684466",
            "orderIndex": 0,
            "hero": true,
            "dead": "4d0",
            "rows": "8h0 8c0 Ad0/9h0 9c0 Tc0 Jc0 Ks0/2h0 2d0 2c0 6c0 6s0",
            "win": -3.6,
            "playerId": "pid5684466"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:38:51",
    "roomId": "21933155"
}


{
    "stakes": 0.2,
    "handData": {"210330114639-21933155-0000014-1": [
        {
            "inFantasy": true,
            "result": 50,
            "playerName": "pid5450708",
            "orderIndex": 0,
            "hero": false,
            "dead": "8h0 8c1 7c2",
            "rows": "Ah0 Ad0 Ac0/Jh0 Jd0 Jc0 Qh0 Qs0/4d0 Th0 Td0 Tc0 Ts0",
            "win": 9.7,
            "playerId": "pid5450708"
        },
        {
            "inFantasy": false,
            "result": -50,
            "playerName": "pid5684466",
            "orderIndex": 1,
            "hero": true,
            "dead": "9s1 3d2 As3 8d4",
            "rows": "Kc1 Ks2 7s4/4c0 5s0 6h1 6s2 2s4/7h0 7d0 Qd0 3h3 3c3",
            "win": -10,
            "playerId": "pid5684466"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:39:37",
    "roomId": "21933155"
}


{
    "stakes": 0.2,
    "handData": {"210330114639-21933155-0000015-1": [
        {
            "inFantasy": true,
            "result": 9,
            "playerName": "pid5450708",
            "orderIndex": 1,
            "hero": false,
            "dead": "3d0 8s1 9s2",
            "rows": "2h0 2d0 2s0/6h0 6d0 6s0 Kc0 As0/4h0 8h0 9h0 Qh0 Ah0",
            "win": 1.7,
            "playerId": "pid5450708"
        },
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "pid5684466",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jd1 8d2 Td3 4d4",
            "rows": "Ad0 Kh3 Ac4/7d0 Ts0 5s1 7h1 5h2/9c0 Qc0 6c2 5c3 Tc4",
            "win": -1.8,
            "playerId": "pid5684466"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:40:25",
    "roomId": "21933155"
}


{
    "stakes": 0.2,
    "handData": {"210330114639-21933155-0000016-1": [
        {
            "inFantasy": true,
            "result": 4,
            "playerName": "pid5450708",
            "orderIndex": 0,
            "hero": false,
            "dead": "2h0 8c1 Tc2",
            "rows": "Kh0 Ks0 Ad0/6h0 6d0 6s0 9d0 9c0/7c0 7s0 Jh0 Jd0 Js0",
            "win": 0.8,
            "playerId": "pid5450708"
        },
        {
            "inFantasy": true,
            "result": -4,
            "playerName": "pid5684466",
            "orderIndex": 1,
            "hero": true,
            "dead": "6c0 8s0 7h0",
            "rows": "Qh0 Ac0 As0/3d0 5d0 7d0 8d0 Qd0/2c0 2s0 Th0 Td0 Ts0",
            "win": -0.8,
            "playerId": "pid5684466"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:41:08",
    "roomId": "21933155"
}


{
    "stakes": 0.2,
    "handData": {"210330114639-21933155-0000017-1": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5450708",
            "orderIndex": 1,
            "hero": false,
            "dead": "7c1 2c2 9h3 5h4",
            "rows": "Ah0 Th2 Kc4/6s0 8d0 3h1 3s1 Jh4/Qd0 Qc0 5d2 5c3 Kh3",
            "win": 1.2,
            "playerId": "pid5450708"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5684466",
            "orderIndex": 0,
            "hero": true,
            "dead": "3d1 3c2 Qs3 Ks4",
            "rows": "As0 Js3 Td4/2d0 4h0 2s1 8s2 8c3/8h0 Ts0 7d1 6d2 4d4",
            "win": -1.2,
            "playerId": "pid5684466"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:41:59",
    "roomId": "21933155"
}


{
    "stakes": 0.2,
    "handData": {"210330114639-21933155-0000018-1": [
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid5450708",
            "orderIndex": 0,
            "hero": false,
            "dead": "6s1 Ad2 5h3 5d4",
            "rows": "Kc2 Ks2 7c4/3c0 4h0 6h1 6d1 4c3/8h0 8d0 9s0 9c3 7h4",
            "win": 1,
            "playerId": "pid5450708"
        },
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "pid5684466",
            "orderIndex": 1,
            "hero": true,
            "dead": "2c1 Jd2 4s3 7d4",
            "rows": "As0 Jc3 5s4/Qd0 Qc1 2d2 3s3 3h4/8s0 9h0 Th0 7s1 Jh2",
            "win": -1,
            "playerId": "pid5684466"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:43:11",
    "roomId": "21933155"
}


{
    "stakes": 0.2,
    "handData": {"210330114639-21933155-0000019-1": [
        {
            "inFantasy": true,
            "result": 15,
            "playerName": "pid5450708",
            "orderIndex": 1,
            "hero": false,
            "dead": "3c0 9s1",
            "rows": "8h0 8d0 8c0/7h0 Th0 Td0 Ts0 Qd0/3h0 4d0 5h0 6s0 7s0",
            "win": 2.9,
            "playerId": "pid5450708"
        },
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid5684466",
            "orderIndex": 0,
            "hero": true,
            "dead": "8s1 6h2 4s3 6c4",
            "rows": "Kh2 7c4 Qc4/3d0 7d0 9c1 3s3 9h3/2s0 Jc0 Js0 2c1 Jh2",
            "win": -3,
            "playerId": "pid5684466"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:43:57",
    "roomId": "21933155"
}


{
    "stakes": 0.2,
    "handData": {"210330114639-21933155-0000020-1": [
        {
            "inFantasy": true,
            "result": 14,
            "playerName": "pid5450708",
            "orderIndex": 0,
            "hero": false,
            "dead": "2h0 2d1",
            "rows": "3s0 4h0 4c0/9s0 Tc0 Jc0 Qc0 Kh0/6d0 9d0 Jd0 Qd0 Ad0",
            "win": 0.3,
            "playerId": "pid5450708"
        },
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid5684466",
            "orderIndex": 1,
            "hero": true,
            "dead": "9c1 Td2 7h3 3d4",
            "rows": "Ks1 As3 Qh4/2c0 6h0 5s1 2s2 3h4/8d0 8c0 Jh0 8s2 Ts3",
            "win": -0.3,
            "playerId": "pid5684466"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:45:38",
    "roomId": "21933155"
}


