{
    "stakes": 10,
    "handData": {"210330174927-21946898-0000032-1": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "pid5684164",
            "orderIndex": 0,
            "hero": true,
            "dead": "6s1 Kd2 2s3 5d4",
            "rows": "Ah3 8d4 Qd4/3h0 4c0 3s1 7h1 7s3/9d0 Tc0 Ts0 9h2 Th2",
            "win": 233,
            "playerId": "pid5684164"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid4735023",
            "orderIndex": 1,
            "hero": false,
            "dead": "3c1 2d2 Kc3 Ac4",
            "rows": "As0 4h3 4d3/4s0 6d0 6c1 Qh2 Qc2/9s0 Jc0 8h1 8c4 Js4",
            "win": -120,
            "playerId": "pid4735023"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid3842150",
            "orderIndex": 2,
            "hero": false,
            "dead": "3d1 Td2 6h3 8s4",
            "rows": "Kh0 7d3 Ks3/Qs0 5h1 2h2 5s2 Ad4/2c0 5c0 9c0 7c1 Jd4",
            "win": -120,
            "playerId": "pid3842150"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:26:07",
    "roomId": "21946898"
}


{
    "stakes": 10,
    "handData": {"210330174927-21946898-0000033-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5684164",
            "orderIndex": 2,
            "hero": true,
            "dead": "9h1 4s2 2c3 Js4",
            "rows": "4h2 6h3 9s3/2h0 4d0 3s1 Ah1 3h4/6s0 9c0 Td0 7h2 8s4",
            "win": 0,
            "playerId": "pid5684164"
        },
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid4735023",
            "orderIndex": 0,
            "hero": false,
            "dead": "Tc1 5h2 8h3 Qh4",
            "rows": "Kd0 Qd2 Ks3/8d0 Ac1 As1 4c2 7s3/6d0 6c0 Th0 3d4 Jc4",
            "win": -180,
            "playerId": "pid4735023"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "pid3842150",
            "orderIndex": 1,
            "hero": false,
            "dead": "3c1 2s2 8c3 7c4",
            "rows": "Qc0 Jh4 Kc4/Kh1 5c2 5s2 Ts3 Qs3/5d0 9d0 Jd0 Ad0 2d1",
            "win": 175,
            "playerId": "pid3842150"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:28:24",
    "roomId": "21946898"
}


{
    "stakes": 10,
    "handData": {"210330174927-21946898-0000034-1": [
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid5684164",
            "orderIndex": 1,
            "hero": true,
            "dead": "5h1 Js2 Ks3 Ts4",
            "rows": "Qc0 9d2 9h4/2h0 3d1 3s1 4d2 2c3/6d0 6s0 7d0 Kc3 7c4",
            "win": -105,
            "playerId": "pid5684164"
        },
        {
            "inFantasy": false,
            "result": 48,
            "playerName": "pid4735023",
            "orderIndex": 2,
            "hero": false,
            "dead": "Jd1 Qd2 Qh3 6c4",
            "rows": "Ac0 Ad3 5c4/5s0 9s0 7s2 As3 8s4/6h0 Jh0 Kh1 Ah1 4h2",
            "win": 373,
            "playerId": "pid4735023"
        },
        {
            "inFantasy": false,
            "result": -28,
            "playerName": "pid3842150",
            "orderIndex": 0,
            "hero": false,
            "dead": "Tc1 8h2 7h3 8c4",
            "rows": "Kd2 2d3 2s3/3h0 4s1 5d1 4c2 Th4/8d0 Td0 Jc0 Qs0 9c4",
            "win": -280,
            "playerId": "pid3842150"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:30:45",
    "roomId": "21946898"
}


{
    "stakes": 10,
    "handData": {"210330174927-21946898-0000035-1": [
        {
            "inFantasy": false,
            "result": -31,
            "playerName": "pid5684164",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jc1 Jd2 3s3 4s4",
            "rows": "Qh1 Kd2 Ac4/4c0 7h0 7c0 5c1 7s4/6s0 9s0 6d2 9d3 9c3",
            "win": -310,
            "playerId": "pid5684164"
        },
        {
            "inFantasy": true,
            "result": 64,
            "playerName": "pid4735023",
            "orderIndex": 1,
            "hero": false,
            "dead": "6c0 4d1 As2",
            "rows": "8h0 8c0 8s0/3h0 4h0 5h0 6h0 Kh0/2h0 2d0 2c0 2s0 7d0",
            "win": 621,
            "playerId": "pid4735023"
        },
        {
            "inFantasy": false,
            "result": -33,
            "playerName": "pid3842150",
            "orderIndex": 2,
            "hero": false,
            "dead": "Qs1 Ad2 9h3 Ts4",
            "rows": "Ks1 Kc2 Tc3/3d0 8d0 Th0 3c1 Td2/Jh0 Js0 Qd3 5d4 5s4",
            "win": -330,
            "playerId": "pid3842150"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:31:54",
    "roomId": "21946898"
}


{
    "stakes": 10,
    "handData": {"210330174927-21946898-0000036-1": [
        {
            "inFantasy": false,
            "result": -50,
            "playerName": "pid5684164",
            "orderIndex": 2,
            "hero": true,
            "dead": "3s1 2c2 Td3 Ks4",
            "rows": "9c2 Kh3 Kc4/6s0 7c0 4s1 Ad3 9s4/4h0 Qh0 Ah0 6h1 7h2",
            "win": -318,
            "playerId": "pid5684164"
        },
        {
            "inFantasy": true,
            "result": 43,
            "playerName": "pid4735023",
            "orderIndex": 0,
            "hero": false,
            "dead": "3c0 2h1 9h2",
            "rows": "Tc0 Ac0 As0/3d0 8d0 9d0 Qd0 Kd0/5h0 5c0 Jd0 Jc0 Js0",
            "win": 308,
            "playerId": "pid4735023"
        },
        {
            "inFantasy": true,
            "result": 7,
            "playerName": "pid3842150",
            "orderIndex": 1,
            "hero": false,
            "dead": "2d0 6d1",
            "rows": "Th0 Ts0 Qc0/2s0 3h0 4d0 5s0 6c0/7d0 7s0 8h0 8c0 8s0",
            "win": 0,
            "playerId": "pid3842150"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:33:52",
    "roomId": "21946898"
}


{
    "stakes": 10,
    "handData": {"210330174927-21946898-0000037-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5684164",
            "orderIndex": 0,
            "hero": true,
            "dead": "6c1 9d2 7s3 2s4",
            "rows": "Kc1 4s4 8d4/5d0 5c2 8s2 5s3 Js3/2h0 4h0 7h0 9h0 Jh1",
            "win": -60,
            "playerId": "pid5684164"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5011126",
            "orderIndex": 1,
            "hero": false,
            "dead": "2c1 Qd2 Qc3 Td4",
            "rows": "As0 Kd3 Ac3/3h0 4c0 6s1 3d2 3c2/9s0 Tc0 8h1 7d4 Jd4",
            "win": 58,
            "playerId": "pid5011126"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:34:53",
    "roomId": "21946898"
}


{
    "stakes": 10,
    "handData": {"210330174927-21946898-0000038-1": [
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid5684164",
            "orderIndex": 1,
            "hero": true,
            "dead": "9d1 6h2 9c3 Qc4",
            "rows": "Kd0 Ac1 Kc2/2s0 8s0 4s3 8h3 8d4/Tc0 Jc0 Jh1 Jd2 Th4",
            "win": 48,
            "playerId": "pid5684164"
        },
        {
            "inFantasy": true,
            "result": -5,
            "playerName": "pid5011126",
            "orderIndex": 0,
            "hero": false,
            "dead": "6d0 9h1 5d2",
            "rows": "3h0 3c0 Qd0/5h0 6s0 7c0 8c0 9s0/2h0 2d0 Ah0 Ad0 As0",
            "win": -50,
            "playerId": "pid5011126"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:35:38",
    "roomId": "21946898"
}


{
    "stakes": 10,
    "handData": {"210330174927-21946898-0000039-1": [
        {
            "inFantasy": true,
            "result": 15,
            "playerName": "pid5684164",
            "orderIndex": 0,
            "hero": true,
            "dead": "3s0 4h0",
            "rows": "Kd0 Ah0 Ac0/2d0 2s0 Td0 Jh0 Js0/5h0 5s0 7c0 Qh0 Qc0",
            "win": 145,
            "playerId": "pid5684164"
        },
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid5011126",
            "orderIndex": 1,
            "hero": false,
            "dead": "9d1 6h2 Ks3 9h4",
            "rows": "Qd1 Kh2 9c3/2c0 7s0 3h1 5c3 6s4/8h0 8c0 Jc0 Tc2 4d4",
            "win": -150,
            "playerId": "pid5011126"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:36:32",
    "roomId": "21946898"
}


