{
    "stakes": 5,
    "handData": {"210330104921-21930314-0000000-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5011126",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jd1 2s2 7s3 9d4",
            "rows": "Ks0 As0 Kc1/Td1 6d2 5s3 6h3 3c4/4h0 5h0 Jh0 9h2 9c4",
            "win": 0,
            "playerId": "pid5011126"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5674244",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ac1 5c2 Th3 Tc4",
            "rows": "Ah1 Ad1 Kh3/2d0 7h0 Jc0 7c2 8c4/6s0 Qs0 8h2 8s3 4s4",
            "win": 0,
            "playerId": "pid5674244"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:28:45",
    "roomId": "21930314"
}


{
    "stakes": 5,
    "handData": {"210330104921-21930314-0000001-1": [
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid5011126",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jc1 4c2 2h3 3d4",
            "rows": "Ks1 Qh2 Kh3/4s0 5h0 6s0 3s1 7c2/7d0 9d0 3h3 5s4 7h4",
            "win": -90,
            "playerId": "pid5011126"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "pid5674244",
            "orderIndex": 1,
            "hero": true,
            "dead": "9h1 6h2 Ad3 2d4",
            "rows": "Kd0 Jd4 As4/2s0 Ts0 8s2 7s3 9s3/5c0 6c0 9c1 Qc1 2c2",
            "win": 87,
            "playerId": "pid5674244"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:30:17",
    "roomId": "21930314"
}


{
    "stakes": 5,
    "handData": {"210330104921-21930314-0000002-1": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5011126",
            "orderIndex": 1,
            "hero": false,
            "dead": "7h1 7s2 Jh3 4d4",
            "rows": "Td1 Ks2 Ac4/6d0 Jc0 Js1 4c2 8c3/9c0 9s0 Qd0 As3 9h4",
            "win": 29,
            "playerId": "pid5011126"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5674244",
            "orderIndex": 0,
            "hero": true,
            "dead": "Th1 3h2 Kc3 Tc4",
            "rows": "Ad1 Kh3 9d4/Qh0 Qc0 2h1 2d2 8h2/3s0 8s0 Ts0 6s3 5d4",
            "win": -30,
            "playerId": "pid5674244"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:31:17",
    "roomId": "21930314"
}


{
    "stakes": 5,
    "handData": {"210330104921-21930314-0000003-1": [
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "pid5011126",
            "orderIndex": 0,
            "hero": false,
            "dead": "Td1 2s2 2d3 Ad4",
            "rows": "Ks0 Kh2 Kd4/3d0 5d0 9d1 Qd2 7d3/7c0 Jc0 Qc1 9c3 6d4",
            "win": -105,
            "playerId": "pid5011126"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "pid5674244",
            "orderIndex": 1,
            "hero": true,
            "dead": "8s1 Jd2 9h3 4c4",
            "rows": "Ac2 Js3 Ah3/4s0 Tc0 Th1 5s4 Ts4/3h0 4h0 5h0 Jh1 8h2",
            "win": 102,
            "playerId": "pid5674244"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:32:35",
    "roomId": "21930314"
}


{
    "stakes": 5,
    "handData": {"210330104921-21930314-0000004-1": [
        {
            "inFantasy": false,
            "result": -13,
            "playerName": "pid5011126",
            "orderIndex": 1,
            "hero": false,
            "dead": "4d1 Kd2 7h3 Jc4",
            "rows": "Ac1 Ah2 Ks4/2d0 2s0 8d0 5h2 8s3/9h0 Ts0 Td1 9d3 8c4",
            "win": -65,
            "playerId": "pid5011126"
        },
        {
            "inFantasy": true,
            "result": 13,
            "playerName": "pid5674244",
            "orderIndex": 0,
            "hero": true,
            "dead": "7d0 6d0 Js0",
            "rows": "Qd0 Ad0 As0/3c0 4c0 5c0 9c0 Qc0/2h0 3h0 4h0 Jh0 Qh0",
            "win": 63,
            "playerId": "pid5674244"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:33:40",
    "roomId": "21930314"
}


{
    "stakes": 5,
    "handData": {"210330104921-21930314-0000005-1": [
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "pid5011126",
            "orderIndex": 0,
            "hero": false,
            "dead": "3h0 4h1 9c2",
            "rows": "6h0 6d0 Jc0/4s0 5s0 7s0 Js0 As0/2d0 2c0 Th0 Td0 Tc0",
            "win": 18,
            "playerId": "pid5011126"
        },
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "pid5674244",
            "orderIndex": 1,
            "hero": true,
            "dead": "6s1 8s2 3d3 7d4",
            "rows": "Kh0 Ks1 Kc3/5h0 7h2 Qh3 2s4 5c4/8d0 Jd0 Qd0 4d1 Ad2",
            "win": -19,
            "playerId": "pid5674244"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:34:26",
    "roomId": "21930314"
}


{
    "stakes": 5,
    "handData": {"210330104921-21930314-0000006-1": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5011126",
            "orderIndex": 1,
            "hero": false,
            "dead": "7h1 3d2 6c3 9s4",
            "rows": "Kh0 Ks1 7c3/2s0 4h0 5d2 5c2 4d4/Jd0 Qc0 Jc1 8h3 Ad4",
            "win": -60,
            "playerId": "pid5011126"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid5674244",
            "orderIndex": 0,
            "hero": true,
            "dead": "Tc1 Jh2 8c3 6s4",
            "rows": "Kd0 9d3 9c3/As1 Th2 Ah2 3s4 5s4/8d0 9h0 Td0 Js0 7s1",
            "win": 58,
            "playerId": "pid5674244"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:35:18",
    "roomId": "21930314"
}


{
    "stakes": 5,
    "handData": {"210330104921-21930314-0000007-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5011126",
            "orderIndex": 0,
            "hero": false,
            "dead": "Js1 4h2 4c3 Ks4",
            "rows": "Kc1 8d2 Kd2/3c0 9s0 2h1 Ad3 2c4/6d0 6s0 Qs0 Th3 Td4",
            "win": 0,
            "playerId": "pid5011126"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5674244",
            "orderIndex": 1,
            "hero": true,
            "dead": "4d1 6h2 Qc3 Jd4",
            "rows": "Ac0 As1 6c4/3d0 5s0 5d2 4s3 5c4/9c0 Qd0 Jh1 9d2 Qh3",
            "win": 0,
            "playerId": "pid5674244"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:36:44",
    "roomId": "21930314"
}


{
    "stakes": 5,
    "handData": {"210330104921-21930314-0000008-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5011126",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jc1 2c2 2s3 Ad4",
            "rows": "Ac0 As1 4s2/5c0 Th0 7d2 5s3 8s4/9s0 Qs0 Qc1 Ks3 9d4",
            "win": -30,
            "playerId": "pid5011126"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5674244",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ah1 6s2 2d3 2h4",
            "rows": "Td3 3s4 Qh4/5d0 6d0 8h1 8d1 5h3/9h0 Tc0 Ts0 3d2 3c2",
            "win": 29,
            "playerId": "pid5674244"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:37:28",
    "roomId": "21930314"
}


{
    "stakes": 5,
    "handData": {"210330104921-21930314-0000009-1": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid5011126",
            "orderIndex": 0,
            "hero": false,
            "dead": "2c1 7h2 3s3 Tc4",
            "rows": "Jh2 Td3 Jd3/4h0 8d0 9d0 4d1 9c4/6s0 Qs0 9s1 6c2 Qc4",
            "win": 58,
            "playerId": "pid5011126"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5674244",
            "orderIndex": 1,
            "hero": true,
            "dead": "Ks1 9h2 2s3 Th4",
            "rows": "Kh1 Qh2 2h3/3h0 3d0 5s0 Ts2 Kc4/4c0 Jc0 Ac1 Ah3 5c4",
            "win": -60,
            "playerId": "pid5674244"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:38:46",
    "roomId": "21930314"
}


{
    "stakes": 5,
    "handData": {"210330104921-21930314-0000010-1": [
        {
            "inFantasy": false,
            "result": 2,
            "playerName": "pid5011126",
            "orderIndex": 2,
            "hero": false,
            "dead": "Jd1 Ts2 5h3 Td4",
            "rows": "9h3 Qs4 As4/4d0 3h1 4s1 3c2 5s3/7d0 7c0 Qd0 Qc0 7h2",
            "win": 10,
            "playerId": "pid5011126"
        },
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid5655711",
            "orderIndex": 0,
            "hero": false,
            "dead": "Ah1 2s2 4h3 6d4",
            "rows": "Kc0 Kd1 4c4/3d0 Ac1 6c2 Ad3 3s4/8d0 Th0 Js0 8s2 8h3",
            "win": 48,
            "playerId": "pid5655711"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5674244",
            "orderIndex": 1,
            "hero": true,
            "dead": "2h1 2c2 9s3 6h4",
            "rows": "Qh0 Ks2 9c4/5d0 Jh1 Jc1 5c2 2d4/7s0 8c0 9d0 6s3 Tc3",
            "win": -60,
            "playerId": "pid5674244"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:40:29",
    "roomId": "21930314"
}


{
    "stakes": 5,
    "handData": {"210330104921-21930314-0000011-1": [
        {
            "inFantasy": false,
            "result": -31,
            "playerName": "pid5011126",
            "orderIndex": 1,
            "hero": false,
            "dead": "7c1 8c2 2h3 Jc4",
            "rows": "Ac1 Ad2 Jh3/7h0 9s0 5h3 Qs4 Kh4/2d0 6d0 Kd0 Qd1 3d2",
            "win": -155,
            "playerId": "pid5011126"
        },
        {
            "inFantasy": true,
            "result": 28,
            "playerName": "pid5655711",
            "orderIndex": 2,
            "hero": false,
            "dead": "2c0 9c1",
            "rows": "Td0 Tc0 Jd0/3c0 4s0 5s0 6s0 7s0/4h0 8h0 9h0 Qh0 Ah0",
            "win": 136,
            "playerId": "pid5655711"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid5674244",
            "orderIndex": 0,
            "hero": true,
            "dead": "2s1 9d2 6c3 4d4",
            "rows": "Th2 8d3 Kc4/3s0 5d1 6h1 4c2 7d3/Ts0 Js0 Ks0 As0 Qc4",
            "win": 15,
            "playerId": "pid5674244"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:41:41",
    "roomId": "21930314"
}


{
    "stakes": 5,
    "handData": {"210330104921-21930314-0000012-1": [
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5011126",
            "orderIndex": 0,
            "hero": false,
            "dead": "5d1 2c2 3h3 4c4",
            "rows": "Kh0 Ad1 7h3/6c0 9d0 7c1 8c2 Ac4/Ts0 Qh0 9s2 Jd3 Jc4",
            "win": -50,
            "playerId": "pid5011126"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5655711",
            "orderIndex": 1,
            "hero": false,
            "dead": "9h1 Qs2 Tc3 8d4",
            "rows": "Kc0 Ks1 Ah2/5s0 8h0 5c2 As3 6d4/4d0 7d0 Js1 4s3 3d4",
            "win": -50,
            "playerId": "pid5655711"
        },
        {
            "inFantasy": false,
            "result": 20,
            "playerName": "pid5674244",
            "orderIndex": 2,
            "hero": true,
            "dead": "Kd1 3s2 7s3 3c4",
            "rows": "6s3 9c4 Jh4/Td0 Qd0 Qc0 2d1 2s1/4h0 6h0 5h2 Th2 2h3",
            "win": 97,
            "playerId": "pid5674244"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:43:55",
    "roomId": "21930314"
}


{
    "stakes": 5,
    "handData": {"210330104921-21930314-0000013-1": [
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid5011126",
            "orderIndex": 2,
            "hero": false,
            "dead": "4d1 2h2 4s3 6c4",
            "rows": "Qs1 Ac2 Ks3/2c0 5s0 8c1 3c3 4h4/Tc0 Jc0 Js0 Th2 Kh4",
            "win": -41,
            "playerId": "pid5011126"
        },
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "pid5655711",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qd1 Qh2 3d3 Ah4",
            "rows": "As0 4c3 9c4/6s0 8s0 9h2 9s3 Kd4/Jh0 Jd0 5d1 5c1 7d2",
            "win": -25,
            "playerId": "pid5655711"
        },
        {
            "inFantasy": false,
            "result": 22,
            "playerName": "pid5674244",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qc1 8h2 3h3 8d4",
            "rows": "Kc1 Td3 Ts4/5h0 6d0 2d2 6h2 2s3/7c0 7s0 9d0 7h1 3s4",
            "win": 64,
            "playerId": "pid5674244"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:45:49",
    "roomId": "21930314"
}


{
    "stakes": 5,
    "handData": {"210330104921-21930314-0000014-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5655711",
            "orderIndex": 1,
            "hero": false,
            "dead": "6c1 8d2 6s3 4h4",
            "rows": "Kc1 7h3 7s4/5d0 8h0 8s1 2c2 5h4/3c0 3s0 9d0 3d2 3h3",
            "win": 0,
            "playerId": "pid5655711"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5674244",
            "orderIndex": 0,
            "hero": true,
            "dead": "5c1 5s2 9h3 2h4",
            "rows": "Ad0 Ac1 Jd3/4d0 6h0 7c0 6d1 4s4/Js0 Ts2 Ks2 9s3 As4",
            "win": 0,
            "playerId": "pid5674244"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:47:18",
    "roomId": "21930314"
}


{
    "stakes": 5,
    "handData": {"210330104921-21930314-0000015-1": [
        {
            "inFantasy": false,
            "result": -29,
            "playerName": "pid5655711",
            "orderIndex": 0,
            "hero": false,
            "dead": "Kd1 Js2 Qd3 8c4",
            "rows": "Qc0 Qs2 Kh3/9d0 Td0 Tc1 5d3 8s4/4h0 6h0 8h1 5s2 3h4",
            "win": -145,
            "playerId": "pid5655711"
        },
        {
            "inFantasy": true,
            "result": 29,
            "playerName": "pid5674244",
            "orderIndex": 1,
            "hero": true,
            "dead": "3d0 5h0 9s0",
            "rows": "Ts0 Ah0 As0/2c0 3c0 4c0 5c0 9c0/7h0 7c0 7s0 Jh0 Jd0",
            "win": 141,
            "playerId": "pid5674244"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:48:29",
    "roomId": "21930314"
}


