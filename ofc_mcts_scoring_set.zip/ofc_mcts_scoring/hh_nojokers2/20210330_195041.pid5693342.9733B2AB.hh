{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000045-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5693342",
            "orderIndex": 1,
            "hero": true,
            "dead": "Kc1 5s2 3d3 Ks4",
            "rows": "As0 8d3 Ts4/2d0 6c0 4d1 2h2 4h2/7c0 Js0 9h1 9d3 Tc4",
            "win": 0,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid1657535",
            "orderIndex": 0,
            "hero": false,
            "dead": "5d1 3s2 6h3 3c4",
            "rows": "Ad1 7s3 6d4/2c0 4c0 8c0 9s3 5c4/3h0 Qh0 5h1 Qc2 Qs2",
            "win": 0,
            "playerId": "pid1657535"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:50:41",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000046-1": [
        {
            "inFantasy": false,
            "result": 13,
            "playerName": "pid5693342",
            "orderIndex": 0,
            "hero": true,
            "dead": "2d1 9d2 5s3 7d4",
            "rows": "Ah0 6c4 Ad4/8s1 9s1 7s2 3s3 Js3/6h0 8h0 Th0 Kh0 Qh2",
            "win": 2.5,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": false,
            "result": -13,
            "playerName": "pid1657535",
            "orderIndex": 1,
            "hero": false,
            "dead": "9h1 Td2 5d3 3d4",
            "rows": "As0 Jd3 Ac3/6s0 7h0 4s1 4h4 6d4/8c0 Jc0 Qc1 Jh2 Qd2",
            "win": -2.6,
            "playerId": "pid1657535"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:51:33",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000047-1": [
        {
            "inFantasy": true,
            "result": 5,
            "playerName": "pid5693342",
            "orderIndex": 1,
            "hero": true,
            "dead": "3d0 9c0 3c0",
            "rows": "Jd0 Js0 Qd0/5c0 6h0 7c0 8h0 9d0/4h0 4s0 Th0 Tc0 Ts0",
            "win": 1,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": true,
            "result": -5,
            "playerName": "pid1657535",
            "orderIndex": 0,
            "hero": false,
            "dead": "4c0 2s1 7h2",
            "rows": "9h0 Kd0 Ks0/8s0 Jh0 Jc0 Qh0 Qs0/5d0 6d0 7d0 8d0 Ad0",
            "win": -1,
            "playerId": "pid1657535"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:52:06",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000048-1": [
        {
            "inFantasy": false,
            "result": 28,
            "playerName": "pid5693342",
            "orderIndex": 0,
            "hero": true,
            "dead": "7c1 7d2 2s3 5d4",
            "rows": "Ah0 8d3 Kc4/3c0 3h1 6c1 5s2 3s4/4d0 4c0 Kd0 4h2 Ks3",
            "win": 5.4,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid1503276",
            "orderIndex": 1,
            "hero": false,
            "dead": "8s1 6s2 Jd3 Jh4",
            "rows": "Kh0 Tc3 Qc4/As0 7h1 Jc1 Js2 5h4/2d0 9d0 Qd0 9h2 Qh3",
            "win": -1.6,
            "playerId": "pid1503276"
        },
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid1657535",
            "orderIndex": 2,
            "hero": false,
            "dead": "Ts1 8h2 4s3 3d4",
            "rows": "Ad2 Ac3 7s4/5c0 6h1 6d1 2h2 2c3/8c0 9s0 Td0 Qs0 9c4",
            "win": -4,
            "playerId": "pid1657535"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:53:43",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000049-1": [
        {
            "inFantasy": false,
            "result": -24,
            "playerName": "pid5693342",
            "orderIndex": 2,
            "hero": true,
            "dead": "Td1 3d2 4c3 Ts4",
            "rows": "Ad0 Ks1 3c3/6c0 7s0 6h2 Js3 3h4/5h0 9h0 5c1 5s2 Qh4",
            "win": -4.8,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": false,
            "result": 7,
            "playerName": "pid1503276",
            "orderIndex": 0,
            "hero": false,
            "dead": "Tc1 Jc2 4h3 5d4",
            "rows": "Kc0 Kd2 As3/9s0 6d1 6s1 9d2 7d4/2d0 2c0 Qd0 2s3 Kh4",
            "win": 1.4,
            "playerId": "pid1503276"
        },
        {
            "inFantasy": false,
            "result": 17,
            "playerName": "pid1657535",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jd1 Jh2 8c3 3s4",
            "rows": "Ac0 Qc1 Ah3/4s0 2h1 7c2 7h3 4d4/8h0 8s0 Th0 8d2 Qs4",
            "win": 3.3,
            "playerId": "pid1657535"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:55:29",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000050-1": [
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "pid5693342",
            "orderIndex": 1,
            "hero": true,
            "dead": "8c1 7d2 4h3 9s4",
            "rows": "Kd1 Th3 Tc4/3s0 4d0 3d1 7h2 7c3/6d0 6c0 Js0 6s2 Jc4",
            "win": -4.2,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": true,
            "result": 0,
            "playerName": "pid1503276",
            "orderIndex": 2,
            "hero": false,
            "dead": "7s0 2h1",
            "rows": "9h0 Qc0 Qs0/3c0 4c0 5c0 9c0 Ac0/5d0 Td0 Jd0 Qd0 Ad0",
            "win": 0,
            "playerId": "pid1503276"
        },
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "pid1657535",
            "orderIndex": 0,
            "hero": false,
            "dead": "4s0 8d1 9d2",
            "rows": "2d0 2c0 2s0/3h0 5h0 6h0 Qh0 Ah0/5s0 8s0 Ts0 Ks0 As0",
            "win": 4.1,
            "playerId": "pid1657535"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:56:43",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000051-1": [
        {
            "inFantasy": false,
            "result": -2,
            "playerName": "pid5693342",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ts1 Jd2 2d3 3d4",
            "rows": "Kh0 Ah1 As2/9s0 7d1 7c3 9d4 Ad4/6d0 6c0 Qc0 6h2 6s3",
            "win": -0.4,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": false,
            "result": -39,
            "playerName": "pid1503276",
            "orderIndex": 1,
            "hero": false,
            "dead": "2c1 7h2 7s3 2h4",
            "rows": "Kd0 Qh3 Qd3/3c0 5c0 4s2 5s2 5d4/8s0 Td0 8d1 8c1 Ks4",
            "win": -7.8,
            "playerId": "pid1503276"
        },
        {
            "inFantasy": true,
            "result": 41,
            "playerName": "pid1657535",
            "orderIndex": 2,
            "hero": false,
            "dead": "Qs0 3s1 2s2",
            "rows": "Jh0 Jc0 Js0/3h0 4h0 5h0 8h0 9h0/4c0 9c0 Tc0 Kc0 Ac0",
            "win": 8,
            "playerId": "pid1657535"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:57:47",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000052-1": [
        {
            "inFantasy": true,
            "result": -1,
            "playerName": "pid5693342",
            "orderIndex": 2,
            "hero": true,
            "dead": "3d0 8s0 8d0",
            "rows": "Jd0 Jc0 Kc0/2c0 3h0 4s0 5s0 6h0/Th0 Tc0 Ad0 Ac0 As0",
            "win": -0.2,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": true,
            "result": -22,
            "playerName": "pid1503276",
            "orderIndex": 0,
            "hero": false,
            "dead": "4d0",
            "rows": "6d0 9d0 Js0/3c0 4c0 7c0 8c0 9c0/5h0 7h0 8h0 9h0 Qh0",
            "win": -4.4,
            "playerId": "pid1503276"
        },
        {
            "inFantasy": true,
            "result": 23,
            "playerName": "pid1657535",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jh0 2s1 4h2",
            "rows": "Td0 Ts0 Ah0/5d0 5c0 Qd0 Qc0 Qs0/6c0 6s0 Kh0 Kd0 Ks0",
            "win": 4.5,
            "playerId": "pid1657535"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:58:36",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000053-1": [
        {
            "inFantasy": false,
            "result": 19,
            "playerName": "pid5693342",
            "orderIndex": 1,
            "hero": true,
            "dead": "8h1 7s2 Ac3 4h4",
            "rows": "Qh0 5s4 Qd4/2h0 6c1 Kd1 2s2 Kh3/6d0 7d0 8s0 9d2 Th3",
            "win": 3.7,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": false,
            "result": 8,
            "playerName": "pid1503276",
            "orderIndex": 2,
            "hero": false,
            "dead": "Kc1 2d2 7c3 5d4",
            "rows": "As2 Qs3 Td4/3s0 6s0 3d2 6h3 9s4/8d0 8c0 Jd0 Jh1 Js1",
            "win": 1.6,
            "playerId": "pid1503276"
        },
        {
            "inFantasy": false,
            "result": -27,
            "playerName": "pid1657535",
            "orderIndex": 0,
            "hero": false,
            "dead": "Ks1 2c2 9c3 9h4",
            "rows": "Ad0 Jc3 Ah3/4d0 4c0 7h0 3h2 4s4/Qc0 5h1 5c1 Tc2 Ts4",
            "win": -5.4,
            "playerId": "pid1657535"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 17:00:28",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000054-1": [
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "pid5693342",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h0",
            "rows": "5s0 7c0 7s0/3s0 8h0 8d0 Tc0 Ah0/6d0 6c0 Qh0 Qc0 Qs0",
            "win": 4.1,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": false,
            "result": -22,
            "playerName": "pid1503276",
            "orderIndex": 1,
            "hero": false,
            "dead": "4h1 8c2 9d3 4d4",
            "rows": "Qd0 Kh2 Kd2/5d0 5c0 5h1 3h3 9c4/Ts0 Js0 4s1 Jc3 Th4",
            "win": -4.4,
            "playerId": "pid1503276"
        },
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid1657535",
            "orderIndex": 2,
            "hero": false,
            "dead": "2s1 4c2 Jd3 9h4",
            "rows": "Ks0 Jh3 As4/3d0 6h0 Ad1 7d2 Ac4/7h0 Td0 8s1 6s2 9s3",
            "win": 0.2,
            "playerId": "pid1657535"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 17:01:54",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000055-1": [
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "pid5693342",
            "orderIndex": 2,
            "hero": true,
            "dead": "5s1 2h2 Qh3 8c4",
            "rows": "Ah3 Qc4 Qs4/3h0 4s0 2s1 6d2 5h3/2d0 8d0 Qd0 Kd1 Jd2",
            "win": 5.2,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid1503276",
            "orderIndex": 0,
            "hero": false,
            "dead": "3d1 6c2 9d3 3c4",
            "rows": "As2 Kh3 8s4/7s0 Js0 7h1 Jc3 5d4/Td0 Tc0 Ts0 5c1 Th2",
            "win": 1,
            "playerId": "pid1503276"
        },
        {
            "inFantasy": false,
            "result": -32,
            "playerName": "pid1657535",
            "orderIndex": 1,
            "hero": false,
            "dead": "4c1 Jh2 3s3 9c4",
            "rows": "Ks0 Ac2 9s4/2c0 4h0 4d0 8h2 Kc4/9h0 7d1 7c1 6h3 6s3",
            "win": -6.4,
            "playerId": "pid1657535"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 17:03:29",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000056-1": [
        {
            "inFantasy": true,
            "result": 17,
            "playerName": "pid5693342",
            "orderIndex": 1,
            "hero": true,
            "dead": "2h0",
            "rows": "7d0 9s0 Jh0/4c0 6c0 9c0 Jc0 Qc0/3h0 3d0 3c0 3s0 5h0",
            "win": 3.3,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": false,
            "result": -28,
            "playerName": "pid1503276",
            "orderIndex": 2,
            "hero": false,
            "dead": "Td1 8h2 2c3 8c4",
            "rows": "Ac1 9d2 Qd4/2d0 5d0 4s1 4h3 5c4/7h0 7s0 Qs0 7c2 Qh3",
            "win": -5.6,
            "playerId": "pid1503276"
        },
        {
            "inFantasy": false,
            "result": 11,
            "playerName": "pid1657535",
            "orderIndex": 0,
            "hero": false,
            "dead": "9h1 Ts2 4d3 2s4",
            "rows": "Ah2 As2 Tc3/6s0 8s0 6h1 8d1 Ad4/Jd0 Kh0 Kd0 Ks3 Js4",
            "win": 2.1,
            "playerId": "pid1657535"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 17:04:24",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000057-1": [
        {
            "inFantasy": true,
            "result": 14,
            "playerName": "pid5693342",
            "orderIndex": 0,
            "hero": true,
            "dead": "2s0",
            "rows": "4d0 Ts0 Qd0/2c0 3c0 7c0 8c0 9c0/5h0 8h0 9h0 Jh0 Qh0",
            "win": 0.2,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": false,
            "result": -39,
            "playerName": "pid1503276",
            "orderIndex": 1,
            "hero": false,
            "dead": "6h1 Jc2 Kh3 6c4",
            "rows": "Ks0 Kd1 Js3/4c0 8s0 3s2 4s2 3h4/7h0 Th0 7d1 Ah3 9s4",
            "win": -0.2,
            "playerId": "pid1503276"
        },
        {
            "inFantasy": true,
            "result": 25,
            "playerName": "pid1657535",
            "orderIndex": 2,
            "hero": false,
            "dead": "Tc0 2h1 5c2",
            "rows": "Qc0 Qs0 Kc0/3d0 4h0 5s0 6s0 7s0/2d0 6d0 9d0 Td0 Ad0",
            "win": 0,
            "playerId": "pid1657535"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 17:05:23",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000058-1": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5693342",
            "orderIndex": 1,
            "hero": true,
            "dead": "Th1 4h2 Js3 5h4",
            "rows": "As1 9d2 Jh3/3s0 Qh1 8h2 Ah3 Qd4/2c0 9c0 Tc0 Jc0 6c4",
            "win": -2.4,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid1657535",
            "orderIndex": 0,
            "hero": false,
            "dead": "Td1 Kc2 7c3 3d4",
            "rows": "Kh0 Ad4 Ac4/2s0 4d1 3c2 5s2 6s3/9h0 Ts0 Jd0 7d1 8s3",
            "win": 2.3,
            "playerId": "pid1657535"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 17:06:36",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000059-1": [
        {
            "inFantasy": false,
            "result": -24,
            "playerName": "pid5693342",
            "orderIndex": 0,
            "hero": true,
            "dead": "4h1 5d2 4d3 2c4",
            "rows": "Kh0 7c3 Ks3/6d0 Tc0 Jc1 6h2 Jd2/9s0 Qs0 3s1 3h4 Qd4",
            "win": -4.8,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": true,
            "result": 24,
            "playerName": "pid1657535",
            "orderIndex": 1,
            "hero": false,
            "dead": "6c0 2s1 7d2",
            "rows": "8d0 8c0 8s0/Ts0 Js0 Qh0 Kc0 As0/3d0 3c0 5h0 5c0 5s0",
            "win": 4.7,
            "playerId": "pid1657535"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 17:07:24",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000060-1": [
        {
            "inFantasy": true,
            "result": -1,
            "playerName": "pid5693342",
            "orderIndex": 1,
            "hero": true,
            "dead": "4c0 4h0",
            "rows": "Qh0 Qs0 Ah0/2d0 3d0 9d0 Td0 Kd0/8h0 8d0 8c0 8s0 Ks0",
            "win": -0.2,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": true,
            "result": 1,
            "playerName": "pid1657535",
            "orderIndex": 0,
            "hero": false,
            "dead": "Kc0 7h1 Tc2",
            "rows": "Jh0 Jd0 Jc0/2h0 3c0 4d0 5h0 Ad0/2s0 5s0 6s0 Ts0 As0",
            "win": 0.2,
            "playerId": "pid1657535"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 17:07:57",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000061-1": [
        {
            "inFantasy": true,
            "result": -2,
            "playerName": "pid5693342",
            "orderIndex": 0,
            "hero": true,
            "dead": "5d0 5s0",
            "rows": "Qd0 Ah0 Ac0/7c0 7s0 9s0 Tc0 Ts0/2h0 4h0 8h0 9h0 Qh0",
            "win": -0.4,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": true,
            "result": 2,
            "playerName": "pid1657535",
            "orderIndex": 1,
            "hero": false,
            "dead": "8s0 6h1 2s2",
            "rows": "Th0 Jh0 Qs0/3d0 7d0 8d0 Kd0 Ad0/4d0 4c0 4s0 5h0 5c0",
            "win": 0.4,
            "playerId": "pid1657535"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 17:08:32",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000062-1": [
        {
            "inFantasy": false,
            "result": -7,
            "playerName": "pid5693342",
            "orderIndex": 2,
            "hero": true,
            "dead": "3c1 3d2 Jd3 7h4",
            "rows": "Kc0 Ts3 6c4/2c0 2s0 4h0 5h1 2h4/Qs0 Tc1 9h2 Jc2 8s3",
            "win": -1.4,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": false,
            "result": -31,
            "playerName": "pid1481429",
            "orderIndex": 0,
            "hero": false,
            "dead": "8c1 3h2 6d3 5c4",
            "rows": "Ac0 Ks1 Ah2/Qh0 Th1 Kh2 Jh3 Kd4/7d0 7c0 7s0 8d3 Qc4",
            "win": -6.2,
            "playerId": "pid1481429"
        },
        {
            "inFantasy": false,
            "result": 38,
            "playerName": "pid1657535",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qd1 Td2 6h3 8h4",
            "rows": "As1 Ad3 9d4/2d0 4c0 4s0 4d1 9c4/6s0 9s0 3s2 Js2 5s3",
            "win": 7.4,
            "playerId": "pid1657535"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 17:10:45",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000063-1": [
        {
            "inFantasy": false,
            "result": -60,
            "playerName": "pid5693342",
            "orderIndex": 1,
            "hero": true,
            "dead": "Kd1 7s2 6c3 Ah4",
            "rows": "Qc0 Ks2 Qh3/3h0 3d1 8s1 Ts2 7d4/2d0 2s0 Jd0 2c3 2h4",
            "win": -12,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": false,
            "result": 25,
            "playerName": "pid1481429",
            "orderIndex": 2,
            "hero": false,
            "dead": "Td1 3s2 Ad3 3c4",
            "rows": "Kh1 9s2 As4/6s0 9c0 9h1 6h2 6d4/4d0 4s0 Jc0 4h3 4c3",
            "win": 4.8,
            "playerId": "pid1481429"
        },
        {
            "inFantasy": true,
            "result": 35,
            "playerName": "pid1657535",
            "orderIndex": 0,
            "hero": false,
            "dead": "9d0 Jh1 Tc2",
            "rows": "8h0 8d0 8c0/Th0 Js0 Qd0 Kc0 Ac0/5d0 5c0 5s0 7h0 7c0",
            "win": 6.8,
            "playerId": "pid1657535"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 17:11:48",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000064-1": [
        {
            "inFantasy": false,
            "result": -37,
            "playerName": "pid5693342",
            "orderIndex": 0,
            "hero": true,
            "dead": "2c1 2s2 Ts3 Ah4",
            "rows": "Ad0 Ac0 Js3/5d0 7h1 8d2 7c3 Jc4/9h0 9c0 Kh1 Kd2 Jh4",
            "win": -7.4,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": false,
            "result": -13,
            "playerName": "pid1481429",
            "orderIndex": 1,
            "hero": false,
            "dead": "4c1 2h2 Qs3 4s4",
            "rows": "Ks2 As3 Tc4/5h0 8c0 6s1 5c3 8h4/3d0 Jd0 Qd0 7d1 2d2",
            "win": -2.6,
            "playerId": "pid1481429"
        },
        {
            "inFantasy": true,
            "result": 50,
            "playerName": "pid1657535",
            "orderIndex": 2,
            "hero": false,
            "dead": "9d0 4d1 3h2",
            "rows": "Qh0 Qc0 Kc0/3s0 5s0 7s0 8s0 9s0/6h0 6d0 6c0 Th0 Td0",
            "win": 9.7,
            "playerId": "pid1657535"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 17:12:41",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000065-1": [
        {
            "inFantasy": false,
            "result": 20,
            "playerName": "pid5693342",
            "orderIndex": 2,
            "hero": true,
            "dead": "2s1 5d2 3h3 As4",
            "rows": "Kc0 9s3 9d4/6d0 9c0 3d1 6c1 3s2/4h0 Qh0 4s2 8h3 8d4",
            "win": 3.9,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid1481429",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jh1 8s2 7c3 Qd4",
            "rows": "Ad1 Kh2 Ac3/4c0 2d1 5s3 5c4 7h4/8c0 9h0 Td0 Jd0 7s2",
            "win": -2,
            "playerId": "pid1481429"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid1657535",
            "orderIndex": 1,
            "hero": false,
            "dead": "3c1 4d2 6h3 6s4",
            "rows": "Ah0 Jc3 Ks4/2c0 Ts0 5h1 Th1 2h3/Qc0 Kd0 Tc2 Js2 Qs4",
            "win": -2,
            "playerId": "pid1657535"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 17:14:54",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000066-1": [
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "pid5693342",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jc1 9c2 5c3 Ah4",
            "rows": "Ad0 Qc3 Qs3/4d0 8c0 Ks1 4c2 6d4/5h0 Th0 9h1 7h2 5d4",
            "win": -4.2,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "pid1481429",
            "orderIndex": 2,
            "hero": false,
            "dead": "2s1 6h2 5s3 Ts4",
            "rows": "Kh0 Ac1 As2/6c0 7c0 7d1 6s3 4h4/Js0 Qh0 Qd2 Jh3 Td4",
            "win": 5.8,
            "playerId": "pid1481429"
        },
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "pid1657535",
            "orderIndex": 0,
            "hero": false,
            "dead": "Kc1 Kd2 3c3 3h4",
            "rows": "Jd2 2h3 8h4/2d0 7s0 3d1 3s1 2c2/8d0 9d0 9s0 Tc3 8s4",
            "win": -1.8,
            "playerId": "pid1657535"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 17:16:24",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000067-1": [
        {
            "inFantasy": false,
            "result": -49,
            "playerName": "pid5693342",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jd1 6h2 2s3 Kd4",
            "rows": "Ac0 Js3 Ts4/4c0 5d0 5s1 3h2 3c2/7s0 8d0 8s1 4h3 9c4",
            "win": -9.8,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": true,
            "result": 42,
            "playerName": "pid1481429",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qc0 4d1 5c2",
            "rows": "Jh0 Jc0 Ks0/7h0 7d0 7c0 9h0 9d0/3d0 3s0 Th0 Td0 Tc0",
            "win": 8.1,
            "playerId": "pid1481429"
        },
        {
            "inFantasy": false,
            "result": 7,
            "playerName": "pid1657535",
            "orderIndex": 2,
            "hero": false,
            "dead": "Qh1 5h2 Kh3 6c4",
            "rows": "Ah0 Kc1 Ad2/2d0 6d1 2h2 8h3 8c3/4s0 6s0 9s0 Qs4 As4",
            "win": 1.4,
            "playerId": "pid1657535"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 17:17:32",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000068-1": [
        {
            "inFantasy": false,
            "result": -31,
            "playerName": "pid5693342",
            "orderIndex": 2,
            "hero": true,
            "dead": "4s1 8d2 6s3 2h4",
            "rows": "Ac1 Kc2 4d4/9d0 3c1 3h2 9c3 Td3/7h0 7d0 Qc0 Qs0 7s4",
            "win": -6.2,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid1481429",
            "orderIndex": 0,
            "hero": false,
            "dead": "As1 Qd2 3s3 8s4",
            "rows": "Ks2 5s3 9s4/7c0 Tc0 4c1 5c1 8c3/8h0 Kh0 Ah0 4h2 Jh4",
            "win": -3,
            "playerId": "pid1481429"
        },
        {
            "inFantasy": true,
            "result": 46,
            "playerName": "pid1657535",
            "orderIndex": 1,
            "hero": false,
            "dead": "Ts0 2c1 6c2",
            "rows": "Jd0 Jc0 Js0/5h0 6h0 9h0 Th0 Qh0/3d0 5d0 6d0 Kd0 Ad0",
            "win": 8.9,
            "playerId": "pid1657535"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 17:18:44",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000069-1": [
        {
            "inFantasy": false,
            "result": -32,
            "playerName": "pid5693342",
            "orderIndex": 1,
            "hero": true,
            "dead": "5d1 7s2 2s3 6d4",
            "rows": "Qd0 6s1 5s4/3h0 9h0 4h3 Th3 Qs4/8c0 Tc0 2c1 4c2 Qc2",
            "win": -6.4,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid1481429",
            "orderIndex": 2,
            "hero": false,
            "dead": "4d1 3d2 7d3 5h4",
            "rows": "8d3 Kd3 Jc4/6c0 9d0 Td1 7h2 8h2/3s0 Js0 As0 Ts1 Ks4",
            "win": -1.6,
            "playerId": "pid1481429"
        },
        {
            "inFantasy": true,
            "result": 40,
            "playerName": "pid1657535",
            "orderIndex": 0,
            "hero": false,
            "dead": "8s0 4s1 6h2",
            "rows": "Jh0 Jd0 Kh0/3c0 5c0 7c0 9c0 Kc0/2h0 2d0 Ah0 Ad0 Ac0",
            "win": 7.8,
            "playerId": "pid1657535"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 17:20:27",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000070-1": [
        {
            "inFantasy": false,
            "result": 19,
            "playerName": "pid5693342",
            "orderIndex": 0,
            "hero": true,
            "dead": "Td1 7h2 4d3 Ts4",
            "rows": "Ks0 Ah1 Tc4/5h0 9h0 8d1 5d3 Kc4/Qd0 Qs0 2d2 2s2 Qc3",
            "win": 3.7,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid1481429",
            "orderIndex": 1,
            "hero": false,
            "dead": "7d1 Js2 4s3 Ac4",
            "rows": "Kd0 Ad1 As1/4c0 3c2 6d2 5c3 5s3/2h0 6h0 Th0 2c4 3h4",
            "win": -3.6,
            "playerId": "pid1481429"
        },
        {
            "inFantasy": false,
            "result": -1,
            "playerName": "pid1657535",
            "orderIndex": 2,
            "hero": false,
            "dead": "Jc1 8h2 Qh3 4h4",
            "rows": "8c2 Kh3 9s4/3s0 6s0 6c1 8s1 3d2/7c0 7s0 9d0 Jd3 Jh4",
            "win": -0.2,
            "playerId": "pid1657535"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 17:21:55",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000071-1": [
        {
            "inFantasy": false,
            "result": 11,
            "playerName": "pid5693342",
            "orderIndex": 2,
            "hero": true,
            "dead": "Kd1 9h2 5h3 6s4",
            "rows": "Kh0 Ks0 7d4/5d0 7h0 5s1 4h2 7c3/Jc0 3h1 Tc2 3d3 Jh4",
            "win": 2.1,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": false,
            "result": 19,
            "playerName": "pid1481429",
            "orderIndex": 0,
            "hero": false,
            "dead": "2s1 5c2 2c3 6c4",
            "rows": "4s3 4d4 8h4/Td0 Qd0 9c1 Js1 Kc2/Ad0 Ac0 As0 Th2 Ts3",
            "win": 3.7,
            "playerId": "pid1481429"
        },
        {
            "inFantasy": false,
            "result": -30,
            "playerName": "pid1657535",
            "orderIndex": 1,
            "hero": false,
            "dead": "Ah1 3c2 2h3 4c4",
            "rows": "Qh1 Qs3 Qc4/9s0 7s1 8s2 6h3 3s4/2d0 6d0 8d0 9d0 Jd2",
            "win": -6,
            "playerId": "pid1657535"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 17:24:02",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000072-1": [
        {
            "inFantasy": true,
            "result": 46,
            "playerName": "pid5693342",
            "orderIndex": 1,
            "hero": true,
            "dead": "6d0 4c0",
            "rows": "Qc0 Kh0 Ks0/3h0 7h0 8h0 Jh0 Ah0/2s0 3s0 4s0 5s0 6s0",
            "win": 8.9,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid1481429",
            "orderIndex": 2,
            "hero": false,
            "dead": "8s1 4h2 Ts3 2d4",
            "rows": "Ac0 Th4 As4/6h0 6c1 Td2 Tc2 2h3/4d0 8d0 Jd0 9d1 Ad3",
            "win": -3.4,
            "playerId": "pid1481429"
        },
        {
            "inFantasy": false,
            "result": -29,
            "playerName": "pid1657535",
            "orderIndex": 0,
            "hero": false,
            "dead": "8c1 3c2 3d3 7d4",
            "rows": "7s2 7c3 9c4/5h0 5d0 2c1 5c1 9h2/Jc0 Qd0 Qs0 Qh3 Js4",
            "win": -5.8,
            "playerId": "pid1657535"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 17:24:54",
    "roomId": "21958502"
}


{
    "stakes": 0.2,
    "handData": {"210330222537-21958502-0000073-1": [
        {
            "inFantasy": true,
            "result": 24,
            "playerName": "pid5693342",
            "orderIndex": 0,
            "hero": true,
            "dead": "3c0 2d0",
            "rows": "5c0 8h0 Ah0/3s0 5s0 6s0 8s0 9s0/7h0 7d0 Td0 Tc0 Ts0",
            "win": 4.7,
            "playerId": "pid5693342"
        },
        {
            "inFantasy": true,
            "result": 13,
            "playerName": "pid1481429",
            "orderIndex": 1,
            "hero": false,
            "dead": "9h0 Jd1 9c2",
            "rows": "Jh0 Ac0 As0/2s0 Qh0 Qd0 Kd0 Ks0/4h0 5d0 6d0 7s0 8c0",
            "win": 2.5,
            "playerId": "pid1481429"
        },
        {
            "inFantasy": false,
            "result": -37,
            "playerName": "pid1657535",
            "orderIndex": 2,
            "hero": false,
            "dead": "Qs1 Jc2 7c3 2c4",
            "rows": "Kh0 Kc0 Qc3/3d0 6h0 3h2 6c2 2h4/8d0 4d1 9d1 4c3 Js4",
            "win": -7.4,
            "playerId": "pid1657535"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 17:27:54",
    "roomId": "21958502"
}


