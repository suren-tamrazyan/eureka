{
    "stakes": 20,
    "handData": {"210330115059-21933348-0000001-1": [
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid5539584",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qh1 4c2 6h3 3d4",
            "rows": "2h0 Kh0 Ks0/6c0 7s0 6s1 7d1 4h3/Qc2 Ad2 5s3 4d4 Ac4",
            "win": -400,
            "playerId": "pid5539584"
        },
        {
            "inFantasy": false,
            "result": 20,
            "playerName": "pid5684223",
            "orderIndex": 0,
            "hero": true,
            "dead": "7h1 5d2 4s3 As4",
            "rows": "Kc0 6d3 Kd4/3h0 3s0 9h1 Tc2 Th3/8d0 Jd0 8s1 8h2 Jc4",
            "win": 388,
            "playerId": "pid5684223"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:31:57",
    "roomId": "21933348"
}


{
    "stakes": 20,
    "handData": {"210330115059-21933348-0000002-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5539584",
            "orderIndex": 0,
            "hero": false,
            "dead": "3c1 7s2 2s3 6s4",
            "rows": "Ac2 As3 Kc4/6c0 7c1 Tc1 Th2 7h3/4d0 4c0 Qh0 Qd0 Kh4",
            "win": 0,
            "playerId": "pid5539584"
        },
        {
            "inFantasy": true,
            "result": 0,
            "playerName": "pid5684223",
            "orderIndex": 1,
            "hero": true,
            "dead": "2d0 3d0",
            "rows": "5d0 5s0 8s0/8d0 9s0 Ts0 Jc0 Qc0/2h0 6h0 8h0 Jh0 Ah0",
            "win": 0,
            "playerId": "pid5684223"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:32:39",
    "roomId": "21933348"
}


{
    "stakes": 20,
    "handData": {"210330115059-21933348-0000003-1": [
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "pid5539584",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qh0 2h1 Jh2",
            "rows": "6c0 6s0 Kc0/7d0 8d0 9d0 Td0 Ad0/3c0 3s0 5h0 5d0 5c0",
            "win": 349,
            "playerId": "pid5539584"
        },
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "pid5684223",
            "orderIndex": 0,
            "hero": true,
            "dead": "6h1 2s2 7h3 Qs4",
            "rows": "As0 Ac2 8h3/5s0 8c0 8s1 Jc2 4s4/4d0 Kd0 Ks1 4c3 2c4",
            "win": -360,
            "playerId": "pid5684223"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:33:33",
    "roomId": "21933348"
}


{
    "stakes": 20,
    "handData": {"210330115059-21933348-0000004-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5539584",
            "orderIndex": 0,
            "hero": false,
            "dead": "6d1 6s2 Qh3 2s4",
            "rows": "Qd0 Qs2 Ts3/5h0 7h1 7d1 8d3 8s4/9d0 9c0 Jh0 Ac2 3s4",
            "win": 0,
            "playerId": "pid5539584"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5684223",
            "orderIndex": 1,
            "hero": true,
            "dead": "9h1 4s2 9s3 Ad4",
            "rows": "Kd0 4c2 Kc2/3c0 5c0 2c1 2d3 8c4/6h0 Th0 Td1 Tc3 8h4",
            "win": 0,
            "playerId": "pid5684223"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:35:03",
    "roomId": "21933348"
}


{
    "stakes": 20,
    "handData": {"210330115059-21933348-0000005-1": [
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "pid5539584",
            "orderIndex": 1,
            "hero": false,
            "dead": "8d1 8s2 6d3 9c4",
            "rows": "Ad0 Qs3 Qh4/5s0 6h0 2h1 5c1 5h3/3c0 Kc0 Kd2 Ks2 9d4",
            "win": -100,
            "playerId": "pid5539584"
        },
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid5684223",
            "orderIndex": 0,
            "hero": true,
            "dead": "5d1 3d2 2s3 Qc4",
            "rows": "Ah2 Tc3 Td4/7h0 8c0 4d1 7s2 7d3/3s0 Jd0 Js0 Jh1 3h4",
            "win": 97,
            "playerId": "pid5684223"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:36:07",
    "roomId": "21933348"
}


{
    "stakes": 20,
    "handData": {"210330115059-21933348-0000006-1": [
        {
            "inFantasy": true,
            "result": 19,
            "playerName": "pid5539584",
            "orderIndex": 0,
            "hero": false,
            "dead": "2s0",
            "rows": "Qh0 Qc0 Ac0/6h0 8d0 Tc0 Kd0 Ks0/4h0 4d0 4c0 9c0 9s0",
            "win": 369,
            "playerId": "pid5539584"
        },
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid5684223",
            "orderIndex": 1,
            "hero": true,
            "dead": "9h1 2h2 9d3 6d4",
            "rows": "Ad1 Jh3 3c4/3d0 7s1 7c2 Ts2 7d3/5c0 5s0 Qd0 Qs0 2d4",
            "win": -380,
            "playerId": "pid5684223"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:36:57",
    "roomId": "21933348"
}


{
    "stakes": 20,
    "handData": {"210330115059-21933348-0000007-1": [
        {
            "inFantasy": false,
            "result": -4,
            "playerName": "pid5539584",
            "orderIndex": 1,
            "hero": false,
            "dead": "3s1 2c2 Jh3 7c4",
            "rows": "Ah1 Ad1 3d4/3c0 4d0 5h0 4c2 5c2/9c0 9s0 Th3 Tc3 2s4",
            "win": -80,
            "playerId": "pid5539584"
        },
        {
            "inFantasy": false,
            "result": 4,
            "playerName": "pid5684223",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qs1 As2 3h3 5s4",
            "rows": "Ks2 8s3 Kd4/6h0 9h0 6s1 9d2 2h3/5d0 6d0 7d0 Qd1 8d4",
            "win": 78,
            "playerId": "pid5684223"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:38:00",
    "roomId": "21933348"
}


{
    "stakes": 20,
    "handData": {"210330115059-21933348-0000008-1": [
        {
            "inFantasy": true,
            "result": 29,
            "playerName": "pid5539584",
            "orderIndex": 0,
            "hero": false,
            "dead": "7s0 As1 Ts2",
            "rows": "Kh0 Kc0 Ks0/2h0 3h0 5h0 Qh0 Ah0/3d0 3c0 3s0 8d0 8c0",
            "win": 563,
            "playerId": "pid5539584"
        },
        {
            "inFantasy": true,
            "result": -29,
            "playerName": "pid5684223",
            "orderIndex": 1,
            "hero": true,
            "dead": "4h0 8h0",
            "rows": "6d0 6c0 Ac0/9d0 9s0 Th0 Qs0 Kd0/2d0 2s0 Jh0 Jc0 Js0",
            "win": -580,
            "playerId": "pid5684223"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:38:36",
    "roomId": "21933348"
}


{
    "stakes": 20,
    "handData": {"210330115059-21933348-0000009-1": [
        {
            "inFantasy": true,
            "result": 26,
            "playerName": "pid5539584",
            "orderIndex": 1,
            "hero": false,
            "dead": "Kd0 7d1 2d2",
            "rows": "4h0 4c0 4s0/Ts0 Jh0 Qc0 Kh0 As0/2s0 3s0 6s0 9s0 Js0",
            "win": 236,
            "playerId": "pid5539584"
        },
        {
            "inFantasy": false,
            "result": -26,
            "playerName": "pid5684223",
            "orderIndex": 0,
            "hero": true,
            "dead": "6d1 8s2 8c3 Qh4",
            "rows": "Ac1 Ah2 9h3/7c0 Jd0 Tc1 Th3 2c4/5h0 5d0 5s0 3d2 2h4",
            "win": -243,
            "playerId": "pid5684223"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 04:39:57",
    "roomId": "21933348"
}


