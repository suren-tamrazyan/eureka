{
    "stakes": 20,
    "handData": {"210330232137-21961869-0000000-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5172376",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jc1 7s2 7h3 2c4",
            "rows": "Qs0 Kh0 Qc2/As0 8c2 Ts3 9h4 9s4/5c0 6h0 2h1 3c1 4c3",
            "win": 0,
            "playerId": "pid5172376"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid144737",
            "orderIndex": 0,
            "hero": false,
            "dead": "6d1 3d2 4d3 3s4",
            "rows": "Ah0 9c1 Ad4/5h0 Tc0 7c1 5s2 7d3/Js0 Ks0 8d2 8s3 5d4",
            "win": 0,
            "playerId": "pid144737"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": false,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:01:57",
    "roomId": "21961869"
}


{
    "stakes": 20,
    "handData": {"210330232137-21961869-0000001-1": [
        {
            "inFantasy": false,
            "result": 20,
            "playerName": "pid5172376",
            "orderIndex": 1,
            "hero": false,
            "dead": "Tc1 4s2 2c3 7d4",
            "rows": "Qh2 Kh3 Td4/6s0 7c0 7s1 7h2 Js3/2d0 4d0 Ad0 3s1 5h4",
            "win": 388,
            "playerId": "pid5172376"
        },
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid144737",
            "orderIndex": 2,
            "hero": false,
            "dead": "2h1 Qs2 9d3 Kd4",
            "rows": "As1 Ah3 Ks4/9s0 Jh0 5s1 Jc3 3d4/4c0 8c0 Qc0 5c2 Ac2",
            "win": -320,
            "playerId": "pid144737"
        },
        {
            "inFantasy": false,
            "result": -4,
            "playerName": "pid5679019",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ts1 Qd2 5d3 6h4",
            "rows": "Kc0 2s4 9h4/3h0 9c0 3c1 6d2 6c2/8d0 Jd0 Th1 8h3 8s3",
            "win": -80,
            "playerId": "pid5679019"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:04:16",
    "roomId": "21961869"
}


{
    "stakes": 20,
    "handData": {"210330232137-21961869-0000002-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5172376",
            "orderIndex": 0,
            "hero": false,
            "dead": "7h1 7d2 9h3 2d4",
            "rows": "Qh0 Qd3 Ks3/8s0 Js0 5h1 5d1 4h4/4c0 Kc0 9c2 Jc2 Tc4",
            "win": -120,
            "playerId": "pid5172376"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid144737",
            "orderIndex": 1,
            "hero": false,
            "dead": "7s1 Qc2 3h3 4d4",
            "rows": "Kh0 Qs2 Ac4/2s0 3s1 As1 Ah2 5c3/6h0 6d0 Jd0 8c3 9d4",
            "win": -120,
            "playerId": "pid144737"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid5679019",
            "orderIndex": 2,
            "hero": true,
            "dead": "Kd1 4s2 Ts3 6s4",
            "rows": "Ad0 Th2 9s4/2c0 5s0 7c1 2h3 Td4/3d0 3c0 8d1 8h2 6c3",
            "win": 233,
            "playerId": "pid5679019"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:06:16",
    "roomId": "21961869"
}


{
    "stakes": 20,
    "handData": {"210330232137-21961869-0000003-1": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid144737",
            "orderIndex": 1,
            "hero": false,
            "dead": "7c1 8h2 2h3 5s4",
            "rows": "As0 Jd2 Jh4/4c0 8c0 8s1 6s2 6c4/Kc0 Ks0 3h1 5h3 5c3",
            "win": 233,
            "playerId": "pid144737"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5679019",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qs1 Qd2 6h3 Kh4",
            "rows": "Qh0 Qc1 Ts4/2d0 7d1 8d2 Td3 Ad3/9d0 9c0 Js0 9s2 6d4",
            "win": -240,
            "playerId": "pid5679019"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:07:19",
    "roomId": "21961869"
}


{
    "stakes": 20,
    "handData": {"210330232137-21961869-0000004-1": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid144737",
            "orderIndex": 0,
            "hero": false,
            "dead": "Tc1 Ks2 6c3 5d4",
            "rows": "Qd1 As1 8s3/2c0 3h0 7d2 3d4 7h4/4c0 4s0 9s0 Jc2 Jd3",
            "win": 116,
            "playerId": "pid144737"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5679019",
            "orderIndex": 1,
            "hero": true,
            "dead": "5s1 Kh2 Qs3 6s4",
            "rows": "Ac0 Ad2 2d4/7s0 Jh2 9d3 9c3 2h4/8h0 8d0 Kd0 8c1 Kc1",
            "win": -120,
            "playerId": "pid5679019"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:08:31",
    "roomId": "21961869"
}


{
    "stakes": 20,
    "handData": {"210330232137-21961869-0000005-1": [
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid144737",
            "orderIndex": 1,
            "hero": false,
            "dead": "Kh1 Jh2 9c3 3s4",
            "rows": "Ad0 As2 Jd4/4s0 6c1 4h2 5c3 7s4/8h0 8s0 Td0 Th1 8d3",
            "win": -200,
            "playerId": "pid144737"
        },
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid5679019",
            "orderIndex": 0,
            "hero": true,
            "dead": "5h1 4d2 2d3 5d4",
            "rows": "Kd2 Ac3 2s4/6s0 7d0 7c2 7h3 Qc4/9h0 Js0 Qd0 Ts1 Kc1",
            "win": 194,
            "playerId": "pid5679019"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:09:22",
    "roomId": "21961869"
}


{
    "stakes": 20,
    "handData": {"210330232137-21961869-0000006-1": [
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid144737",
            "orderIndex": 0,
            "hero": false,
            "dead": "9d1 Kh2 9h3 9s4",
            "rows": "Qd1 Qs2 Kc3/4s0 5s0 5h1 7d3 4h4/3h0 3c0 Jh0 Jd2 Qh4",
            "win": -320,
            "playerId": "pid144737"
        },
        {
            "inFantasy": false,
            "result": 16,
            "playerName": "pid5679019",
            "orderIndex": 1,
            "hero": true,
            "dead": "2h1 4d2 7c3 7h4",
            "rows": "Ad2 Js4 Ac4/Th0 9c1 7s2 6d3 8d3/4c0 6c0 Tc0 Jc0 5c1",
            "win": 310,
            "playerId": "pid5679019"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:10:32",
    "roomId": "21961869"
}


{
    "stakes": 20,
    "handData": {"210330232137-21961869-0000007-1": [
        {
            "inFantasy": true,
            "result": 3,
            "playerName": "pid144737",
            "orderIndex": 1,
            "hero": false,
            "dead": "2h0",
            "rows": "9d0 Ts0 Qh0/2c0 7c0 Qc0 Kc0 Ac0/4h0 4c0 4s0 5h0 5d0",
            "win": 58,
            "playerId": "pid144737"
        },
        {
            "inFantasy": true,
            "result": -3,
            "playerName": "pid5679019",
            "orderIndex": 0,
            "hero": true,
            "dead": "3c0 5c0 3h0",
            "rows": "8d0 Kd0 Ks0/6h0 6d0 8h0 Td0 Tc0/2s0 5s0 9s0 Qs0 As0",
            "win": -60,
            "playerId": "pid5679019"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:11:06",
    "roomId": "21961869"
}


{
    "stakes": 20,
    "handData": {"210330232137-21961869-0000008-1": [
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid144737",
            "orderIndex": 0,
            "hero": false,
            "dead": "7d1 8d2 2s3 6s4",
            "rows": "Th2 4d3 5d3/5s0 6h0 3s1 4s1 2h2/Jc0 Qd0 Qc0 Td4 Ks4",
            "win": -300,
            "playerId": "pid144737"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "pid5679019",
            "orderIndex": 1,
            "hero": true,
            "dead": "3d1 3h2 8s3 As4",
            "rows": "Ah0 Qh2 Ad3/Tc0 6c1 7c1 7s3 6d4/9h0 9d0 Kh0 9s2 4c4",
            "win": 291,
            "playerId": "pid5679019"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:12:16",
    "roomId": "21961869"
}


{
    "stakes": 20,
    "handData": {"210330232137-21961869-0000009-1": [
        {
            "inFantasy": false,
            "result": -23,
            "playerName": "pid144737",
            "orderIndex": 1,
            "hero": false,
            "dead": "9d1 4c2 7h3 5s4",
            "rows": "As0 Th3 Ac4/6h0 6d1 6s2 9s2 8s3/5d0 8d0 Td0 Jd1 Jc4",
            "win": -147,
            "playerId": "pid144737"
        },
        {
            "inFantasy": true,
            "result": 23,
            "playerName": "pid5679019",
            "orderIndex": 0,
            "hero": true,
            "dead": "4s0 2d0 2s0",
            "rows": "7c0 8h0 8c0/9h0 Tc0 Jh0 Qs0 Kh0/3h0 3d0 3c0 3s0 9c0",
            "win": 143,
            "playerId": "pid5679019"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:12:48",
    "roomId": "21961869"
}


{
    "stakes": 20,
    "handData": {"210330232137-21961869-0000010-1": [
        {
            "inFantasy": false,
            "result": 2,
            "playerName": "pid144737",
            "orderIndex": 0,
            "hero": false,
            "dead": "8s1 7d2 Jh3 3c4",
            "rows": "Ac0 Ad3 Js4/3h0 3d0 Jc1 2d2 2s2/Td0 Qc0 Tc1 Qd3 6h4",
            "win": 39,
            "playerId": "pid144737"
        },
        {
            "inFantasy": false,
            "result": -2,
            "playerName": "pid5679019",
            "orderIndex": 1,
            "hero": true,
            "dead": "3s1 Ts2 7h3 2h4",
            "rows": "Kh0 Ah3 Ks4/6d0 8c0 5c1 5h3 6c4/7c0 7s0 Jd1 9d2 9s2",
            "win": -40,
            "playerId": "pid5679019"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:13:56",
    "roomId": "21961869"
}


{
    "stakes": 20,
    "handData": {"210330232137-21961869-0000011-1": [
        {
            "inFantasy": true,
            "result": 2,
            "playerName": "pid144737",
            "orderIndex": 1,
            "hero": false,
            "dead": "2c0 2s1 3c2",
            "rows": "5c0 Qh0 Qd0/5s0 6d0 7c0 8s0 9d0/3h0 6h0 7h0 Th0 Jh0",
            "win": 39,
            "playerId": "pid144737"
        },
        {
            "inFantasy": true,
            "result": -2,
            "playerName": "pid5679019",
            "orderIndex": 0,
            "hero": true,
            "dead": "9h0 4c0",
            "rows": "Jc0 Qc0 Kh0/2d0 3d0 5d0 Td0 Kd0/7s0 9s0 Ts0 Js0 As0",
            "win": -40,
            "playerId": "pid5679019"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:14:27",
    "roomId": "21961869"
}


{
    "stakes": 20,
    "handData": {"210330232137-21961869-0000012-1": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid144737",
            "orderIndex": 0,
            "hero": false,
            "dead": "3d1 5h2 4c3 8d4",
            "rows": "Kd0 8c3 Jc4/4h0 Ad0 3s2 5d2 As3/7d0 7s0 9h1 9d1 Jd4",
            "win": -240,
            "playerId": "pid144737"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid5679019",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qc1 7h2 9c3 Kc4",
            "rows": "2s3 Td3 Ah4/4d0 6s0 7c1 5c2 3c4/9s0 Th0 Jh0 Qh1 8s2",
            "win": 233,
            "playerId": "pid5679019"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:15:42",
    "roomId": "21961869"
}


{
    "stakes": 20,
    "handData": {"210330232137-21961869-0000013-1": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid144737",
            "orderIndex": 1,
            "hero": false,
            "dead": "9s1 3c2 3s3 2s4",
            "rows": "Jh1 Ks2 7d3/5d0 6c0 6s0 2h2 6h4/4h0 Qh0 Qd1 Qs3 Th4",
            "win": 58,
            "playerId": "pid144737"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "pid5679019",
            "orderIndex": 0,
            "hero": true,
            "dead": "9d1 Qc2 5h3 4s4",
            "rows": "Ac0 5c4 6d4/3h0 7h1 7s1 8h3 8d3/2d0 Jd0 Kd0 2c2 Js2",
            "win": -60,
            "playerId": "pid5679019"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:16:37",
    "roomId": "21961869"
}


{
    "stakes": 20,
    "handData": {"210330232137-21961869-0000014-1": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid144737",
            "orderIndex": 0,
            "hero": false,
            "dead": "Ah1 Ad2 6c3 5c4",
            "rows": "Ac0 As0 Jd2/4d0 4s0 3d1 3h3 8c4/Tc0 6d1 Kc2 6h3 Kd4",
            "win": 58,
            "playerId": "pid144737"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "pid5679019",
            "orderIndex": 1,
            "hero": true,
            "dead": "3s1 8d2 3c3 Kh4",
            "rows": "Qs1 7c3 Qh4/2c0 2s0 7d0 5d1 7h2/Th0 Jh0 Js2 2d3 Td4",
            "win": -60,
            "playerId": "pid5679019"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:18:00",
    "roomId": "21961869"
}


{
    "stakes": 20,
    "handData": {"210330232137-21961869-0000015-1": [
        {
            "inFantasy": true,
            "result": 27,
            "playerName": "pid144737",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jc0 Qh1 Jd2",
            "rows": "Kd0 Kc0 Ks0/4d0 5d0 6c0 7c0 8c0/5s0 6s0 7s0 Ts0 As0",
            "win": 524,
            "playerId": "pid144737"
        },
        {
            "inFantasy": true,
            "result": -27,
            "playerName": "pid5679019",
            "orderIndex": 0,
            "hero": true,
            "dead": "4c0",
            "rows": "9c0 9s0 Qs0/2c0 6d0 8d0 Th0 Tc0/3h0 4h0 6h0 8h0 Kh0",
            "win": -540,
            "playerId": "pid5679019"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:18:32",
    "roomId": "21961869"
}


{
    "stakes": 20,
    "handData": {"210330232137-21961869-0000016-1": [
        {
            "inFantasy": true,
            "result": 20,
            "playerName": "pid144737",
            "orderIndex": 0,
            "hero": false,
            "dead": "3s0 5s1 7d2",
            "rows": "2h0 2d0 2c0/3c0 5c0 9c0 Tc0 Qc0/9d0 Td0 Qd0 Kd0 Ad0",
            "win": 388,
            "playerId": "pid144737"
        },
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid5679019",
            "orderIndex": 1,
            "hero": true,
            "dead": "3d1 9h2 Ah3 Js4",
            "rows": "Ac1 Kh2 Kc2/6s0 8d0 8h1 6h3 Qh4/Th0 Jh0 Jc0 7h3 Jd4",
            "win": -400,
            "playerId": "pid5679019"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:19:21",
    "roomId": "21961869"
}


{
    "stakes": 20,
    "handData": {"210330232137-21961869-0000017-1": [
        {
            "inFantasy": true,
            "result": -8,
            "playerName": "pid144737",
            "orderIndex": 1,
            "hero": false,
            "dead": "5c0 8d1 Jd2",
            "rows": "Ah0 Ad0 As0/3h0 5h0 6h0 9h0 Th0/4d0 4c0 9d0 9c0 9s0",
            "win": -160,
            "playerId": "pid144737"
        },
        {
            "inFantasy": true,
            "result": 8,
            "playerName": "pid5679019",
            "orderIndex": 0,
            "hero": true,
            "dead": "Td0 2h0",
            "rows": "Kd0 Kc0 Ks0/8h0 8c0 8s0 Qd0 Qc0/7h0 7d0 7c0 7s0 Js0",
            "win": 155,
            "playerId": "pid5679019"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:19:59",
    "roomId": "21961869"
}


{
    "stakes": 20,
    "handData": {"210330232137-21961869-0000018-1": [
        {
            "inFantasy": true,
            "result": -10,
            "playerName": "pid144737",
            "orderIndex": 0,
            "hero": false,
            "dead": "3h0 5s1 9c2",
            "rows": "Qd0 Qc0 As0/Tc0 Ts0 Jd0 Js0 Kc0/4h0 4d0 7h0 7d0 7s0",
            "win": -200,
            "playerId": "pid144737"
        },
        {
            "inFantasy": true,
            "result": 10,
            "playerName": "pid5679019",
            "orderIndex": 1,
            "hero": true,
            "dead": "6s0 3c0",
            "rows": "9d0 Kh0 Kd0/5h0 6h0 9h0 Th0 Jh0/2h0 2c0 2s0 8h0 8s0",
            "win": 194,
            "playerId": "pid5679019"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:20:34",
    "roomId": "21961869"
}


{
    "stakes": 20,
    "handData": {"210330232137-21961869-0000019-1": [
        {
            "inFantasy": false,
            "result": 8,
            "playerName": "pid144737",
            "orderIndex": 1,
            "hero": false,
            "dead": "6h1 Qc2 5c3 5s4",
            "rows": "Ah0 Ac0 Kc4/4h0 7d0 2h1 7c2 2c3/Js0 8h1 8c2 8s3 9c4",
            "win": 155,
            "playerId": "pid144737"
        },
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid5679019",
            "orderIndex": 0,
            "hero": true,
            "dead": "Kh1 Jc2 2d3 6d4",
            "rows": "Ad2 8d3 Kd4/6s0 7s0 3c1 3s1 7h4/4d0 Th0 Ts0 9s2 Td3",
            "win": -160,
            "playerId": "pid5679019"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:21:27",
    "roomId": "21961869"
}


{
    "stakes": 20,
    "handData": {"210330232137-21961869-0000020-1": [
        {
            "inFantasy": true,
            "result": 8,
            "playerName": "pid144737",
            "orderIndex": 0,
            "hero": false,
            "dead": "6d0 9d1 7s2",
            "rows": "Jc0 Qc0 Kd0/4h0 5h0 Qh0 Kh0 Ah0/2h0 2c0 Th0 Td0 Ts0",
            "win": 155,
            "playerId": "pid144737"
        },
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid5679019",
            "orderIndex": 1,
            "hero": true,
            "dead": "3c1 7h2 3d3 8c4",
            "rows": "6h2 9h4 Jd4/2d0 7d0 Ad1 5d2 Qd3/3s0 8s0 As0 Ks1 2s3",
            "win": -160,
            "playerId": "pid5679019"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:23:03",
    "roomId": "21961869"
}


{
    "stakes": 20,
    "handData": {"210330232137-21961869-0000021-1": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5131182",
            "orderIndex": 1,
            "hero": false,
            "dead": "5c1 8s2 5d3 4s4",
            "rows": "Kc0 Ac2 8h4/7h0 7s0 Tc1 2c3 2h4/Qh0 Qs0 Qc1 9c2 6d3",
            "win": 116,
            "playerId": "pid5131182"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5679019",
            "orderIndex": 0,
            "hero": true,
            "dead": "7d1 Ts2 Ks3 Kd4",
            "rows": "As0 Ad3 Js4/4h0 5h0 6c2 3h3 5s4/Jc0 Qd0 8c1 9s1 Th2",
            "win": -120,
            "playerId": "pid5679019"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:24:04",
    "roomId": "21961869"
}


{
    "stakes": 20,
    "handData": {"210330232137-21961869-0000022-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5131182",
            "orderIndex": 0,
            "hero": false,
            "dead": "2h1 7d2 Tc3 6h4",
            "rows": "Ad0 Ts3 9d4/8h0 8s0 3d1 6d1 4h3/Qc0 Ks0 2c2 Qd2 7h4",
            "win": -120,
            "playerId": "pid5131182"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5679019",
            "orderIndex": 1,
            "hero": true,
            "dead": "3h1 9h2 8c3 4c4",
            "rows": "Kh0 Ac1 8d4/6c0 7c1 7s2 9s3 6s4/5d0 5s0 Js0 5h2 Qh3",
            "win": 116,
            "playerId": "pid5679019"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:25:41",
    "roomId": "21961869"
}


{
    "stakes": 20,
    "handData": {"210330232137-21961869-0000023-1": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5131182",
            "orderIndex": 1,
            "hero": false,
            "dead": "Ah1 5s2 Ad3 4s4",
            "rows": "Kh0 Ac1 7h2/3h0 4c0 2h2 9h3 9d3/Js0 Qd0 Qs1 8d4 Ts4",
            "win": -240,
            "playerId": "pid5131182"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid5679019",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jd1 3s2 6c3 7d4",
            "rows": "Kd0 As1 Tc4/2c0 Th1 8c2 2d3 Td3/5h0 5d0 5c0 6s2 6h4",
            "win": 233,
            "playerId": "pid5679019"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:26:46",
    "roomId": "21961869"
}


{
    "stakes": 20,
    "handData": {"210330232137-21961869-0000024-1": [
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid5131182",
            "orderIndex": 0,
            "hero": false,
            "dead": "6s1 4h2 3s3 2c4",
            "rows": "Kc0 5d3 Ah3/5c0 7d0 3h1 7s2 3c4/Js0 Qd0 Kh1 9h2 Ad4",
            "win": -160,
            "playerId": "pid5131182"
        },
        {
            "inFantasy": false,
            "result": 8,
            "playerName": "pid5679019",
            "orderIndex": 1,
            "hero": true,
            "dead": "2d1 9s2 9d3 8h4",
            "rows": "Kd1 4d3 Th4/5h0 5s0 6d0 2s2 2h3/8c0 Ts0 9c1 7h2 Jh4",
            "win": 155,
            "playerId": "pid5679019"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:28:02",
    "roomId": "21961869"
}


{
    "stakes": 20,
    "handData": {"210330232137-21961869-0000025-1": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid5131182",
            "orderIndex": 1,
            "hero": false,
            "dead": "3s1 7s2 3d3 5h4",
            "rows": "Ks0 Qh3 6d4/2d0 2s0 8d1 8s2 4s3/9c0 9s0 Tc1 9d2 Ts4",
            "win": 58,
            "playerId": "pid5131182"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "pid5679019",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h1 7d2 Jd3 Td4",
            "rows": "As0 Kc2 9h4/3c0 3h1 Qd1 Qc2 5s3/5d0 6s0 7h0 4d3 8c4",
            "win": -60,
            "playerId": "pid5679019"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:28:55",
    "roomId": "21961869"
}


{
    "stakes": 20,
    "handData": {"210330232137-21961869-0000026-1": [
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "pid5131182",
            "orderIndex": 0,
            "hero": false,
            "dead": "2c1 9h2 Jh3 6h4",
            "rows": "Ac1 Qd2 Jc4/7c0 8h0 5s1 Kd3 Kc3/3h0 3s0 Ts0 Td2 6s4",
            "win": -420,
            "playerId": "pid5131182"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "pid5679019",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qc1 Tc2 Kh3 5c4",
            "rows": "Ah1 6c2 Ad3/4h0 7s0 9s1 7h2 9c4/8d0 8c0 Jd0 Js3 8s4",
            "win": 407,
            "playerId": "pid5679019"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:30:10",
    "roomId": "21961869"
}


{
    "stakes": 20,
    "handData": {"210330232137-21961869-0000027-1": [
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "pid5131182",
            "orderIndex": 1,
            "hero": false,
            "dead": "5s1 5d2 2s3 4h4",
            "rows": "Ad3 Ac3 Th4/3d0 2d1 3c1 2c2 Jc2/5h0 6d0 8c0 9h0 9s4",
            "win": -234,
            "playerId": "pid5131182"
        },
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "pid5679019",
            "orderIndex": 0,
            "hero": true,
            "dead": "3h0 6h0 6c0",
            "rows": "Kc0 Ah0 As0/9c0 Td0 Tc0 Jh0 Js0/8d0 8s0 Qh0 Qc0 Qs0",
            "win": 227,
            "playerId": "pid5679019"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:30:45",
    "roomId": "21961869"
}


{
    "stakes": 20,
    "handData": {"210330232137-21961869-0000028-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid436345",
            "orderIndex": 0,
            "hero": false,
            "dead": "2c1 8h2 8d3 2h4",
            "rows": "Qd0 Kc1 Kd2/3h0 3s1 9c2 9s3 Ah4/7d0 Jh0 Js0 Td3 6c4",
            "win": 0,
            "playerId": "pid436345"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5679019",
            "orderIndex": 1,
            "hero": true,
            "dead": "7c1 Jc2 4d3 As4",
            "rows": "Qc0 8c1 3d3/2d0 5d1 4h2 5h2 Jd3/7s0 8s0 Ks0 3c4 9d4",
            "win": 0,
            "playerId": "pid5679019"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:32:17",
    "roomId": "21961869"
}


{
    "stakes": 20,
    "handData": {"210330232137-21961869-0000029-1": [
        {
            "inFantasy": false,
            "result": -2,
            "playerName": "pid436345",
            "orderIndex": 1,
            "hero": false,
            "dead": "Ks1 8c2 5c3 8s4",
            "rows": "Kc2 Qs3 Ah4/7s0 7h1 7c1 9d2 Th4/2c0 3h0 4d0 Ac0 5h3",
            "win": -40,
            "playerId": "pid436345"
        },
        {
            "inFantasy": false,
            "result": 2,
            "playerName": "pid5679019",
            "orderIndex": 0,
            "hero": true,
            "dead": "8h1 4c2 Td3 6s4",
            "rows": "Kh0 Ad3 Qh4/6d0 7d0 Jh2 Jc2 6h4/9h0 9c0 3d1 3s1 9s3",
            "win": 39,
            "playerId": "pid5679019"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:33:12",
    "roomId": "21961869"
}


{
    "stakes": 20,
    "handData": {"210330232137-21961869-0000030-1": [
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid436345",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qh1 9c2 5c3 6s4",
            "rows": "Ac2 7s4 Js4/2c0 4d0 2d1 2s2 6h3/8d0 9h0 Tc0 7d1 6d3",
            "win": -280,
            "playerId": "pid436345"
        },
        {
            "inFantasy": false,
            "result": 14,
            "playerName": "pid5679019",
            "orderIndex": 1,
            "hero": true,
            "dead": "7h1 5s2 Qs3 Jd4",
            "rows": "Ks0 Kc1 As4/3c0 3s0 3d2 Kh3 Ah4/Jc0 Qc0 Ts1 9s2 8h3",
            "win": 272,
            "playerId": "pid5679019"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:34:28",
    "roomId": "21961869"
}


{
    "stakes": 20,
    "handData": {"210330232137-21961869-0000031-1": [
        {
            "inFantasy": false,
            "result": 4,
            "playerName": "pid436345",
            "orderIndex": 1,
            "hero": false,
            "dead": "Kh1 6d2 6h3 8h4",
            "rows": "As3 9s4 Ad4/2s0 4s0 6s1 7s1 3s2/2c0 3c0 Kc0 Tc2 Jc3",
            "win": 78,
            "playerId": "pid436345"
        },
        {
            "inFantasy": true,
            "result": -4,
            "playerName": "pid5679019",
            "orderIndex": 0,
            "hero": true,
            "dead": "4c0 4h0",
            "rows": "5h0 9d0 9c0/2d0 3d0 5d0 7d0 Td0/8s0 Ts0 Js0 Qs0 Ks0",
            "win": -80,
            "playerId": "pid5679019"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:35:03",
    "roomId": "21961869"
}


{
    "stakes": 20,
    "handData": {"210330232137-21961869-0000032-1": [
        {
            "inFantasy": true,
            "result": 28,
            "playerName": "pid436345",
            "orderIndex": 0,
            "hero": false,
            "dead": "4c0 3d1 2h2",
            "rows": "9h0 Ts0 As0/Jh0 Jd0 Js0 Kd0 Ks0/7h0 7d0 7c0 7s0 8s0",
            "win": 543,
            "playerId": "pid436345"
        },
        {
            "inFantasy": false,
            "result": -28,
            "playerName": "pid5679019",
            "orderIndex": 1,
            "hero": true,
            "dead": "5h1 3h2 Jc3 Ad4",
            "rows": "9d2 Kh3 Qd4/2c0 Th0 6d1 6c1 2d2/3s0 5s0 6s0 2s3 3c4",
            "win": -560,
            "playerId": "pid5679019"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:36:27",
    "roomId": "21961869"
}


{
    "stakes": 20,
    "handData": {"210330232137-21961869-0000033-1": [
        {
            "inFantasy": true,
            "result": 14,
            "playerName": "pid436345",
            "orderIndex": 1,
            "hero": false,
            "dead": "4s0 3c1 7s2",
            "rows": "2c0 2s0 Ac0/8d0 9s0 Td0 Jd0 Qc0/4h0 8h0 9h0 Qh0 Kh0",
            "win": 272,
            "playerId": "pid436345"
        },
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid5679019",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qd1 2h2 Kd3 Js4",
            "rows": "Ad0 4d2 Ah2/3s0 8s0 Ts1 3h4 7h4/7c0 Tc0 Kc1 5h3 Jh3",
            "win": -280,
            "playerId": "pid5679019"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:38:03",
    "roomId": "21961869"
}


