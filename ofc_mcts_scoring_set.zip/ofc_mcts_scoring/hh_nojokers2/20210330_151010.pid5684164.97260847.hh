{
    "stakes": 10,
    "handData": {"210330195634-21951805-0000000-1": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "pid3929467",
            "orderIndex": 1,
            "hero": false,
            "dead": "5s1 8d2 4c3 Jc4",
            "rows": "As0 Kc2 9d3/2d0 7c0 6d3 Qd4 Qs4/9h0 Js0 8s1 Ts1 7s2",
            "win": -30,
            "playerId": "pid3929467"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid5684164",
            "orderIndex": 0,
            "hero": true,
            "dead": "6s1 9s2 Kh3 2s4",
            "rows": "3s3 5d3 8c4/2c0 5h0 6h1 Th2 Tc2/4h0 4s0 Qh0 4d1 Qc4",
            "win": 29,
            "playerId": "pid5684164"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 12:10:10",
    "roomId": "21951805"
}


