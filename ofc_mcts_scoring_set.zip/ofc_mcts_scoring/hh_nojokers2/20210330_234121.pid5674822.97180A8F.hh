{
    "stakes": 10,
    "handData": {"210331020159-21969381-0000000-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid2813203",
            "orderIndex": 1,
            "hero": false,
            "dead": "6h1 4s2 4c3 Ts4",
            "rows": "Kd1 Ks3 Qd4/6d0 6c0 3s1 9d3 Ah4/7s0 Jh0 Jc0 5d2 5s2",
            "win": 0,
            "playerId": "pid2813203"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5674822",
            "orderIndex": 0,
            "hero": true,
            "dead": "8c1 3h2 9h3 Kc4",
            "rows": "Ac0 As3 3c4/5h0 6s0 5c1 4h2 4d3/7d0 Td0 7c1 8s2 2d4",
            "win": 0,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 20:41:21",
    "roomId": "21969381"
}


{
    "stakes": 10,
    "handData": {"210331020159-21969381-0000001-1": [
        {
            "inFantasy": false,
            "result": 8,
            "playerName": "pid2813203",
            "orderIndex": 0,
            "hero": false,
            "dead": "Ah1 3d2 Ts3 4s4",
            "rows": "Qs0 Qd4 Kd4/7d0 6s1 6d2 6c3 Jd3/4c0 Tc0 Ac0 9c1 3c2",
            "win": 78,
            "playerId": "pid2813203"
        },
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid5674822",
            "orderIndex": 1,
            "hero": true,
            "dead": "5c1 9s2 5s3 9d4",
            "rows": "Qc1 5d4 Js4/2c0 3s0 2h1 Th3 Td3/8d0 8c0 Jc0 8s2 Jh2",
            "win": -80,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 20:42:36",
    "roomId": "21969381"
}


{
    "stakes": 10,
    "handData": {"210331020159-21969381-0000002-1": [
        {
            "inFantasy": true,
            "result": 7,
            "playerName": "pid2813203",
            "orderIndex": 1,
            "hero": false,
            "dead": "3s0",
            "rows": "7d0 9c0 Qd0/6c0 7c0 8h0 9h0 Ts0/2h0 Jh0 Jd0 Jc0 Js0",
            "win": 68,
            "playerId": "pid2813203"
        },
        {
            "inFantasy": false,
            "result": -7,
            "playerName": "pid5674822",
            "orderIndex": 0,
            "hero": true,
            "dead": "2s1 Qc2 5d3 7h4",
            "rows": "Ks0 Kc1 Qh4/5h0 6d0 As2 Kh3 Ad4/9s0 Th0 8d1 9d2 Tc3",
            "win": -70,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 20:43:32",
    "roomId": "21969381"
}


{
    "stakes": 10,
    "handData": {"210331020159-21969381-0000003-1": [
        {
            "inFantasy": true,
            "result": 10,
            "playerName": "pid2813203",
            "orderIndex": 0,
            "hero": false,
            "dead": "4h0",
            "rows": "6c0 Kd0 Ac0/2h0 2c0 3d0 3c0 3s0/7s0 8s0 9s0 Ts0 Js0",
            "win": 97,
            "playerId": "pid2813203"
        },
        {
            "inFantasy": true,
            "result": -10,
            "playerName": "pid5674822",
            "orderIndex": 1,
            "hero": true,
            "dead": "4c0 3h0",
            "rows": "8d0 Jc0 As0/5h0 5c0 5s0 9d0 9c0/6h0 6d0 6s0 Kh0 Ks0",
            "win": -100,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 20:44:05",
    "roomId": "21969381"
}


{
    "stakes": 10,
    "handData": {"210331020159-21969381-0000004-1": [
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "pid2813203",
            "orderIndex": 1,
            "hero": false,
            "dead": "3c0",
            "rows": "8s0 Kd0 Ks0/8h0 Jd0 Js0 Qh0 Qd0/4h0 4c0 4s0 9d0 9c0",
            "win": 58,
            "playerId": "pid2813203"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5674822",
            "orderIndex": 0,
            "hero": true,
            "dead": "6h1 Qs2 2s3 6c4",
            "rows": "Ad0 Th4 Ac4/3s0 6d0 7h1 7s1 6s3/2c0 Jc0 5d2 5s2 5c3",
            "win": -60,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 20:44:54",
    "roomId": "21969381"
}


{
    "stakes": 10,
    "handData": {"210331020159-21969381-0000005-1": [
        {
            "inFantasy": false,
            "result": -23,
            "playerName": "pid2813203",
            "orderIndex": 0,
            "hero": false,
            "dead": "3h1 Td2 Th3 2h4",
            "rows": "Kc2 2d3 6s3/4h0 5s1 7d1 6d2 5h4/9h0 Tc0 Qd0 Ks0 7s4",
            "win": -190,
            "playerId": "pid2813203"
        },
        {
            "inFantasy": true,
            "result": 23,
            "playerName": "pid5674822",
            "orderIndex": 1,
            "hero": true,
            "dead": "3d0 3s0 2s0",
            "rows": "Qh0 Qs0 Kh0/7h0 7c0 8c0 9d0 9c0/5d0 Jh0 Jd0 Jc0 Js0",
            "win": 184,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 20:45:29",
    "roomId": "21969381"
}


{
    "stakes": 10,
    "handData": {"210331020159-21969381-0000006-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid2813203",
            "orderIndex": 1,
            "hero": false,
            "dead": "3d1 9h2 3s3 Td4",
            "rows": "Kc0 Ah4 Ad4/8c0 4s1 9d1 4d2 9c2/2d0 2c0 Jh0 Jc3 Js3",
            "win": 0,
            "playerId": "pid2813203"
        },
        {
            "inFantasy": true,
            "result": 0,
            "playerName": "pid5674822",
            "orderIndex": 0,
            "hero": true,
            "dead": "5d0 2s0 2h0",
            "rows": "8s0 Kh0 Kd0/8h0 9s0 Ts0 Jd0 Qd0/4c0 5c0 Tc0 Qc0 Ac0",
            "win": 0,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 20:46:08",
    "roomId": "21969381"
}


{
    "stakes": 10,
    "handData": {"210331020159-21969381-0000007-1": [
        {
            "inFantasy": true,
            "result": 23,
            "playerName": "pid2813203",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qd0 8c1 Kd2",
            "rows": "Td0 Tc0 Ad0/2h0 3h0 4h0 7h0 8h0/3s0 4s0 6s0 Qs0 Ks0",
            "win": 223,
            "playerId": "pid2813203"
        },
        {
            "inFantasy": false,
            "result": -23,
            "playerName": "pid5674822",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jc1 3d2 9d3 9h4",
            "rows": "Ac0 Ah1 8d3/4d0 7c0 8s1 6d2 7s4/5h0 Qh0 Kh2 As3 3c4",
            "win": -230,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 20:48:04",
    "roomId": "21969381"
}


