{
    "stakes": 10,
    "handData": {"210331020527-21969673-0000000-1": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5680756",
            "orderIndex": 1,
            "hero": false,
            "dead": "5s1 8s2 9s3 Ts4",
            "rows": "Ks0 Kc2 Td3/4s0 6d0 2d1 As3 4h4/3h0 3c0 7d1 7h2 5d4",
            "win": -120,
            "playerId": "pid5680756"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid5674822",
            "orderIndex": 0,
            "hero": true,
            "dead": "Kh1 Kd2 2h3 Th4",
            "rows": "Js2 4c4 Ad4/Qs0 Qd1 8d2 6c3 Qh3/5c0 9c0 Tc0 Ac0 7c1",
            "win": 116,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 20:20:41",
    "roomId": "21969673"
}


{
    "stakes": 10,
    "handData": {"210331020527-21969673-0000001-1": [
        {
            "inFantasy": false,
            "result": -39,
            "playerName": "pid5680756",
            "orderIndex": 0,
            "hero": false,
            "dead": "4h1 3h2 4c3 6h4",
            "rows": "Td2 9h3 Ad3/7d0 8s0 9s1 9d2 6s4/2h0 Qd0 Qs0 5d1 Th4",
            "win": -380,
            "playerId": "pid5680756"
        },
        {
            "inFantasy": false,
            "result": 20,
            "playerName": "pid4483271",
            "orderIndex": 1,
            "hero": false,
            "dead": "8c1 8h2 2c3 Ks4",
            "rows": "Kd0 Kh1 Jd4/4d0 6d0 5c1 4s2 5h4/7c0 7s0 Js2 7h3 Jc3",
            "win": 194,
            "playerId": "pid4483271"
        },
        {
            "inFantasy": false,
            "result": 19,
            "playerName": "pid5674822",
            "orderIndex": 2,
            "hero": true,
            "dead": "5s1 6c2 Qh3 2s4",
            "rows": "As2 Ah3 Kc4/2d0 3d0 3s1 3c2 Ac4/Tc0 Jh0 Qc0 9c1 8d3",
            "win": 175,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 20:22:38",
    "roomId": "21969673"
}


{
    "stakes": 10,
    "handData": {"210331020527-21969673-0000002-1": [
        {
            "inFantasy": true,
            "result": 3,
            "playerName": "pid4483271",
            "orderIndex": 1,
            "hero": false,
            "dead": "2s0 5h1",
            "rows": "8h0 Qc0 Kc0/3h0 3d0 3c0 Td0 Tc0/6h0 6s0 Jh0 Jd0 Jc0",
            "win": 29,
            "playerId": "pid4483271"
        },
        {
            "inFantasy": true,
            "result": -3,
            "playerName": "pid5674822",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h0 2c0 3s0",
            "rows": "4d0 4c0 9c0/8c0 9d0 Th0 Js0 Qd0/5s0 7h0 7d0 7c0 7s0",
            "win": -30,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 20:23:19",
    "roomId": "21969673"
}


{
    "stakes": 10,
    "handData": {"210331020527-21969673-0000003-1": [
        {
            "inFantasy": false,
            "result": -11,
            "playerName": "pid4483271",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qh1 2s2 5d3 2c4",
            "rows": "Kd0 As1 Qc3/7h0 7c0 9h2 6s3 Jc4/8s0 Ts0 8h1 Tc2 Td4",
            "win": -110,
            "playerId": "pid4483271"
        },
        {
            "inFantasy": true,
            "result": 11,
            "playerName": "pid5674822",
            "orderIndex": 1,
            "hero": true,
            "dead": "2h0 3c0 8c0",
            "rows": "9c0 9s0 Th0/4d0 7d0 8d0 9d0 Jd0/3s0 4s0 5s0 7s0 Qs0",
            "win": 107,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 20:24:09",
    "roomId": "21969673"
}


{
    "stakes": 10,
    "handData": {"210331020527-21969673-0000004-1": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5680756",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jd1 Kh2 Th3 7c4",
            "rows": "As0 Ad2 7s4/5h0 4d1 7h2 4c3 4s3/9c0 Tc0 Jc0 Ks1 3h4",
            "win": -120,
            "playerId": "pid5680756"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "pid4483271",
            "orderIndex": 2,
            "hero": false,
            "dead": "2s1 5c2 3c3 6c4",
            "rows": "9s3 3s4 Ts4/8h0 Js0 Qh1 Qs1 Qd3/5d0 Td0 Kd0 6d2 8d2",
            "win": 233,
            "playerId": "pid4483271"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5674822",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h1 6s2 8s3 Qc4",
            "rows": "Kc0 9h3 Jh4/5s0 Ah0 2c2 4h2 3d3/7d0 9d0 6h1 8c1 2d4",
            "win": -120,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 20:26:17",
    "roomId": "21969673"
}


{
    "stakes": 10,
    "handData": {"210331020527-21969673-0000005-1": [
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid5680756",
            "orderIndex": 0,
            "hero": false,
            "dead": "9s1 3d2 6d3 5h4",
            "rows": "Ac3 4c4 Jd4/Ts0 Qd0 4s2 Qs2 Qh3/3c0 5c0 6c0 2s1 4h1",
            "win": 48,
            "playerId": "pid5680756"
        },
        {
            "inFantasy": false,
            "result": -13,
            "playerName": "pid4483271",
            "orderIndex": 1,
            "hero": false,
            "dead": "8d1 4d2 Ad3 3h4",
            "rows": "Kh0 7c4 Js4/7h0 7d0 5d1 6h2 7s3/9c0 Td0 Th1 Jh2 Tc3",
            "win": -130,
            "playerId": "pid4483271"
        },
        {
            "inFantasy": false,
            "result": 8,
            "playerName": "pid5674822",
            "orderIndex": 2,
            "hero": true,
            "dead": "Jc1 9h2 2d3 5s4",
            "rows": "Ks1 Kd2 Qc3/2c0 3s0 Ah1 As3 2h4/8h0 8s0 9d0 8c2 Kc4",
            "win": 78,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 20:28:24",
    "roomId": "21969673"
}


{
    "stakes": 10,
    "handData": {"210331020527-21969673-0000006-1": [
        {
            "inFantasy": false,
            "result": 16,
            "playerName": "pid5680756",
            "orderIndex": 2,
            "hero": false,
            "dead": "4h1 Jh2 3s3 6h4",
            "rows": "Qs0 5h3 Qc3/7h0 Kd0 9d1 Kh2 9c4/6c0 Jc0 Ac1 3c2 8c4",
            "win": 155,
            "playerId": "pid5680756"
        },
        {
            "inFantasy": false,
            "result": -34,
            "playerName": "pid4483271",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jd1 3d2 9s3 3h4",
            "rows": "Kc2 Ah2 Ad3/5d0 5s0 7d0 7c1 4c4/8s0 Ts0 Th1 2c3 5c4",
            "win": -340,
            "playerId": "pid4483271"
        },
        {
            "inFantasy": true,
            "result": 18,
            "playerName": "pid5674822",
            "orderIndex": 1,
            "hero": true,
            "dead": "4d0 8d0",
            "rows": "Qh0 Qd0 As0/2h0 2d0 2s0 Td0 Ks0/6d0 7s0 8h0 9h0 Tc0",
            "win": 175,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 20:30:01",
    "roomId": "21969673"
}


{
    "stakes": 10,
    "handData": {"210331020527-21969673-0000007-1": [
        {
            "inFantasy": true,
            "result": 10,
            "playerName": "pid5680756",
            "orderIndex": 1,
            "hero": false,
            "dead": "8c0",
            "rows": "4d0 6h0 6d0/Tc0 Jd0 Qh0 Kc0 As0/2s0 3s0 4s0 Js0 Ks0",
            "win": 97,
            "playerId": "pid5680756"
        },
        {
            "inFantasy": false,
            "result": -11,
            "playerName": "pid4483271",
            "orderIndex": 2,
            "hero": false,
            "dead": "2d1 2c2 3h3 5h4",
            "rows": "Qd0 9s3 Jh4/3c0 5d1 2h2 6c3 4h4/7h0 8s0 Th0 6s1 9d2",
            "win": -110,
            "playerId": "pid4483271"
        },
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid5674822",
            "orderIndex": 0,
            "hero": true,
            "dead": "8d1 3d2 5s3 Kh4",
            "rows": "Ad2 Kd3 Ah4/4c0 9h0 Ts1 9c2 Td3/7d0 7c0 Qs0 Jc1 Qc4",
            "win": 10,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 20:31:42",
    "roomId": "21969673"
}


{
    "stakes": 10,
    "handData": {"210331020527-21969673-0000008-1": [
        {
            "inFantasy": false,
            "result": -62,
            "playerName": "pid5680756",
            "orderIndex": 0,
            "hero": false,
            "dead": "Js1 3c2 Th3 6d4",
            "rows": "Kc0 Kh1 Qs3/4s0 5h1 2d2 2s2 7h4/7c0 7s0 8d0 7d3 3h4",
            "win": -620,
            "playerId": "pid5680756"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid4483271",
            "orderIndex": 1,
            "hero": false,
            "dead": "8s1 8c2 3d3 Qd4",
            "rows": "Qh1 Ad2 As3/2h0 6h0 6s1 6c3 Ks4/9h0 9s0 Ts0 Td2 9c4",
            "win": 58,
            "playerId": "pid4483271"
        },
        {
            "inFantasy": true,
            "result": 56,
            "playerName": "pid5674822",
            "orderIndex": 2,
            "hero": true,
            "dead": "Kd0 3s0 9d0",
            "rows": "Jh0 Jd0 Jc0/2c0 4c0 Tc0 Qc0 Ac0/4h0 4d0 5d0 5c0 5s0",
            "win": 543,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 20:33:01",
    "roomId": "21969673"
}


{
    "stakes": 10,
    "handData": {"210331020527-21969673-0000009-1": [
        {
            "inFantasy": false,
            "result": -41,
            "playerName": "pid5680756",
            "orderIndex": 2,
            "hero": false,
            "dead": "5d1 7h2 2h3 2c4",
            "rows": "9h3 9s3 Ks4/3c0 6s0 3d1 Ts1 6c2/Jh0 Jc0 Qc0 Qd2 8h4",
            "win": -60,
            "playerId": "pid5680756"
        },
        {
            "inFantasy": true,
            "result": 9,
            "playerName": "pid4483271",
            "orderIndex": 0,
            "hero": false,
            "dead": "7c0 9c1 8c2",
            "rows": "Qs0 Ah0 Ad0/3s0 4d0 4c0 4s0 5s0/7d0 8d0 9d0 Jd0 Kd0",
            "win": 58,
            "playerId": "pid4483271"
        },
        {
            "inFantasy": true,
            "result": 32,
            "playerName": "pid5674822",
            "orderIndex": 1,
            "hero": true,
            "dead": "6d0 5c0 Js0",
            "rows": "Kh0 Kc0 As0/3h0 4h0 5h0 6h0 Qh0/2d0 2s0 Th0 Td0 Tc0",
            "win": 0,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 20:34:26",
    "roomId": "21969673"
}


