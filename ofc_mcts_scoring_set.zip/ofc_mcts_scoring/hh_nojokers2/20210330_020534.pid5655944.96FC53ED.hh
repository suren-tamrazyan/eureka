{
    "stakes": 20,
    "handData": {"210330062448-21915401-0000000-1": [
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid2634961",
            "orderIndex": 1,
            "hero": false,
            "dead": "Js1 5c2 Td3 7h4",
            "rows": "Qd0 Kc2 Th4/3h0 8h0 4h1 3s2 4c4/7s0 9s0 7c1 7d3 9c3",
            "win": -160,
            "playerId": "pid2634961"
        },
        {
            "inFantasy": false,
            "result": 8,
            "playerName": "pid5655944",
            "orderIndex": 0,
            "hero": true,
            "dead": "Kd1 Jh2 9d3 4d4",
            "rows": "Ac1 As2 Jc4/2s0 8s0 8d1 2c2 6d3/5h0 9h0 Kh0 Qh3 6h4",
            "win": 155,
            "playerId": "pid5655944"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:05:34",
    "roomId": "21915401"
}


{
    "stakes": 20,
    "handData": {"210330062448-21915401-0000001-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid2634961",
            "orderIndex": 0,
            "hero": false,
            "dead": "Kh1 Ad2 7c3 7h4",
            "rows": "Ac1 As1 7d2/6s0 8d0 5c2 5h3 6h4/2d0 2c0 Qs0 Qc3 Ts4",
            "win": -120,
            "playerId": "pid2634961"
        },
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "pid5655944",
            "orderIndex": 1,
            "hero": true,
            "dead": "2s0 4h0 5s0",
            "rows": "Th0 Qh0 Ah0/4d0 5d0 6d0 Qd0 Kd0/8c0 8s0 Jd0 Jc0 Js0",
            "win": 116,
            "playerId": "pid5655944"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:06:17",
    "roomId": "21915401"
}


{
    "stakes": 20,
    "handData": {"210330062448-21915401-0000002-1": [
        {
            "inFantasy": true,
            "result": 25,
            "playerName": "pid2634961",
            "orderIndex": 1,
            "hero": false,
            "dead": "7c0 Td1 4h2",
            "rows": "Ks0 Ah0 Ac0/8c0 9h0 Tc0 Jd0 Qc0/2h0 2d0 3h0 3d0 3s0",
            "win": 485,
            "playerId": "pid2634961"
        },
        {
            "inFantasy": false,
            "result": -25,
            "playerName": "pid5655944",
            "orderIndex": 0,
            "hero": true,
            "dead": "3c1 4d2 2s3 Kh4",
            "rows": "Qh0 8h3 Qd3/5d0 6h0 9d2 9s2 Jh4/2c0 Jc0 9c1 Kc1 7s4",
            "win": -500,
            "playerId": "pid5655944"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:08:06",
    "roomId": "21915401"
}


