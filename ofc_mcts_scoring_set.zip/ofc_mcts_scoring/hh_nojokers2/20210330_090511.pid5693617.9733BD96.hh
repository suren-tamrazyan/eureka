{
    "stakes": 100,
    "handData": {"210330135626-21938641-0000000-1": [
        {
            "inFantasy": false,
            "result": 8,
            "playerName": "pid3983767",
            "orderIndex": 1,
            "hero": false,
            "dead": "Kc1 3h2 7d3 2d4",
            "rows": "Ah0 8c3 Tc4/5s0 6h0 9d2 9s2 4h4/4d0 4c0 Qd1 Qs1 Qh3",
            "win": 776,
            "playerId": "pid3983767"
        },
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid5693617",
            "orderIndex": 0,
            "hero": true,
            "dead": "3c1 6s2 6c3 9h4",
            "rows": "8h2 2s3 Th4/5h0 Jd0 3d1 Qc3 5c4/7s0 8s0 Ks0 Ts1 4s2",
            "win": -800,
            "playerId": "pid5693617"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:05:11",
    "roomId": "21938641"
}


{
    "stakes": 100,
    "handData": {"210330135626-21938641-0000001-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid3983767",
            "orderIndex": 0,
            "hero": false,
            "dead": "Tc1 Ts2 3h3 Kd4",
            "rows": "Ks2 3c3 Kc3/2c0 5d0 5s0 8c2 Jd4/9d0 Th0 8d1 Js1 Qs4",
            "win": 0,
            "playerId": "pid3983767"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5693617",
            "orderIndex": 1,
            "hero": true,
            "dead": "6c1 6h2 7d3 Ah4",
            "rows": "Ad0 As1 Jh4/5c0 6d0 6s0 4c1 4h3/Td0 Jc2 Qd2 8s3 2h4",
            "win": 0,
            "playerId": "pid5693617"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:06:29",
    "roomId": "21938641"
}


{
    "stakes": 100,
    "handData": {"210330135626-21938641-0000002-1": [
        {
            "inFantasy": false,
            "result": -23,
            "playerName": "pid3983767",
            "orderIndex": 2,
            "hero": false,
            "dead": "7h1 7c2 2c3 6s4",
            "rows": "5c1 Ad3 5h4/3h0 4s0 8s1 3s2 8d2/9s0 Qd0 Qc0 9d3 Jc4",
            "win": -2300,
            "playerId": "pid3983767"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "pid5693617",
            "orderIndex": 0,
            "hero": true,
            "dead": "6h1 5d2 Th3 9c4",
            "rows": "Kd0 Ah3 Ks4/2s0 4c0 2d1 Js2 Jh4/9h0 Jd0 Qs1 Ts2 8h3",
            "win": 2328,
            "playerId": "pid5693617"
        },
        {
            "inFantasy": false,
            "result": -1,
            "playerName": "pid5451053",
            "orderIndex": 1,
            "hero": false,
            "dead": "Td1 8c2 4h3 Qh4",
            "rows": "Kc0 Kh1 Tc3/2h0 3d0 5s0 As3 Ac4/7d0 7s1 6d2 6c2 3c4",
            "win": -100,
            "playerId": "pid5451053"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:08:29",
    "roomId": "21938641"
}


{
    "stakes": 100,
    "handData": {"210330135626-21938641-0000003-1": [
        {
            "inFantasy": false,
            "result": -35,
            "playerName": "pid3983767",
            "orderIndex": 1,
            "hero": false,
            "dead": "2s1 Td2 5d3 As4",
            "rows": "Ah0 Ac2 7h3/4d0 Qd1 Kd1 Ks2 Th4/3c0 Jc0 Qc0 Jd3 Js4",
            "win": -3476,
            "playerId": "pid3983767"
        },
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "pid5693617",
            "orderIndex": 2,
            "hero": true,
            "dead": "5c0 2d0",
            "rows": "7d0 7s0 Ad0/6h0 9c0 9s0 Ts0 Kc0/4c0 4s0 8h0 8d0 8c0",
            "win": 559,
            "playerId": "pid5693617"
        },
        {
            "inFantasy": true,
            "result": 29,
            "playerName": "pid5451053",
            "orderIndex": 0,
            "hero": false,
            "dead": "6d0 8s1",
            "rows": "Tc0 Qh0 Qs0/2c0 3s0 4h0 5s0 6c0/3h0 5h0 9h0 Jh0 Kh0",
            "win": 2813,
            "playerId": "pid5451053"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:09:37",
    "roomId": "21938641"
}


{
    "stakes": 100,
    "handData": {"210330135626-21938641-0000004-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5693617",
            "orderIndex": 1,
            "hero": true,
            "dead": "3c1 9d2 8s3 Th4",
            "rows": "Ah0 Kh2 Kd3/7h0 7s0 6d1 2d2 5c4/Jh0 Qh0 Js1 8h3 2s4",
            "win": 0,
            "playerId": "pid5693617"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid3983767",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qc1 Ac2 2c3 Qs4",
            "rows": "Ad0 6h2 As2/Jc0 4c1 9c1 5h4 9h4/3h0 3s0 Ks0 3d3 Kc3",
            "win": 0,
            "playerId": "pid3983767"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:10:56",
    "roomId": "21938641"
}


{
    "stakes": 100,
    "handData": {"210330135626-21938641-0000005-1": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5693617",
            "orderIndex": 0,
            "hero": true,
            "dead": "2s1 7c2 Ks3 6c4",
            "rows": "Ah0 Ac1 Kd3/4s0 8d0 3c1 8s2 4h3/9d0 9c0 Qs2 4d4 5h4",
            "win": -1200,
            "playerId": "pid5693617"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid3983767",
            "orderIndex": 1,
            "hero": false,
            "dead": "Js1 6h2 Th3 Ad4",
            "rows": "As0 8h3 6d4/2h0 4c0 5s0 Jh3 5c4/Td0 3h1 3d1 Tc2 Ts2",
            "win": 1164,
            "playerId": "pid3983767"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:14:49",
    "roomId": "21938641"
}


{
    "stakes": 100,
    "handData": {"210330135626-21938641-0000007-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5693617",
            "orderIndex": 0,
            "hero": true,
            "dead": "2s1 8c2 9d3 Qc4",
            "rows": "Kd0 3s3 Qd3/5d0 7h0 9h1 9s2 Kh4/4c0 Jc0 4h1 Tc2 Td4",
            "win": 0,
            "playerId": "pid5693617"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid3983767",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Ad1 Ts3 Kc3/3d0 5s0 8h1 8s2/2h0 Jh0 Js0 Qs2",
            "win": 0,
            "playerId": "pid3983767"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:16:08",
    "roomId": "21938641"
}


{
    "stakes": 100,
    "handData": {"210330135626-21938641-0000008-1": [
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid5693617",
            "orderIndex": 0,
            "hero": true,
            "dead": "2s1 8c2 9d3 Qc4",
            "rows": "3s0 Qd1 Kd3/7h1 Kh2 9h3 5d4 9s4/4h0 Td0 Tc0 Jc0 4c2",
            "win": 97,
            "playerId": "pid5693617"
        },
        {
            "inFantasy": false,
            "result": -1,
            "playerName": "pid3983767",
            "orderIndex": 1,
            "hero": false,
            "dead": "6c1 Ks2 6d3 3h4",
            "rows": "Ts0 Ad1 Kc3/3d0 Ac1 8h2 8s2 5s4/2h0 Jh0 Js0 Qs3 7c4",
            "win": -100,
            "playerId": "pid3983767"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:16:14",
    "roomId": "21938641"
}


{
    "stakes": 100,
    "handData": {"210330135626-21938641-0000008-1": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid5693617",
            "orderIndex": 1,
            "hero": true,
            "dead": "7s1 3d2 Ah3 8h4",
            "rows": "Ks1 Kc3 Qh4/3h0 3c0 2s2 5h2 5c4/9h0 Td0 Js0 Jd1 Jc3",
            "win": 291,
            "playerId": "pid5693617"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "pid3983767",
            "orderIndex": 0,
            "hero": false,
            "dead": "Tc1 8d2 4c3 5s4",
            "rows": "Kd0 Ad1 7d4/6h0 4d1 2c2 6c2 2h4/3s0 8s0 9s0 4s3 Ts3",
            "win": -300,
            "playerId": "pid3983767"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:17:23",
    "roomId": "21938641"
}


{
    "stakes": 100,
    "handData": {"210330135626-21938641-0000009-1": [
        {
            "inFantasy": true,
            "result": -13,
            "playerName": "pid5693617",
            "orderIndex": 0,
            "hero": true,
            "dead": "5c0 9h0",
            "rows": "Th0 Ts0 Ks0/6d0 6s0 8d0 8s0 Qc0/2d0 3s0 4s0 5h0 Ah0",
            "win": -1300,
            "playerId": "pid5693617"
        },
        {
            "inFantasy": false,
            "result": 13,
            "playerName": "pid3983767",
            "orderIndex": 1,
            "hero": false,
            "dead": "8c1 Js2 4h3 3d4",
            "rows": "Kh0 Kd0 7h4/3h0 7c1 7s1 7d2 Qh4/Td0 Qd0 Jd2 4d3 9d3",
            "win": 1261,
            "playerId": "pid3983767"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:18:05",
    "roomId": "21938641"
}


{
    "stakes": 100,
    "handData": {"210330135626-21938641-0000010-1": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5693617",
            "orderIndex": 1,
            "hero": true,
            "dead": "9c1 5s2 8s3 4s4",
            "rows": "Qc3 Ah3 9s4/5c0 Ts0 Tc1 Td2 9h4/7h0 Qh0 Kh0 6h1 8h2",
            "win": -1200,
            "playerId": "pid5693617"
        },
        {
            "inFantasy": true,
            "result": 12,
            "playerName": "pid3983767",
            "orderIndex": 0,
            "hero": false,
            "dead": "2d0 4d1",
            "rows": "5h0 Ad0 As0/7s0 8d0 9d0 Th0 Jc0/2c0 3c0 4c0 8c0 Kc0",
            "win": 1164,
            "playerId": "pid3983767"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:18:56",
    "roomId": "21938641"
}


{
    "stakes": 100,
    "handData": {"210330135626-21938641-0000011-1": [
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid5693617",
            "orderIndex": 0,
            "hero": true,
            "dead": "5c1 3s2 2s3 Kc4",
            "rows": "Ac1 As1 Qs3/5h0 7d0 6s3 4h4 6c4/7c0 8c0 Tc0 6h2 9d2",
            "win": -1500,
            "playerId": "pid5693617"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "pid3983767",
            "orderIndex": 1,
            "hero": false,
            "dead": "Kh1 Td2 9c3 4s4",
            "rows": "Ah0 Ad3 Ks4/2c0 8s0 2d1 Jh2 Jd2/3d0 Qd0 3c1 Js3 3h4",
            "win": 1455,
            "playerId": "pid3983767"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:20:00",
    "roomId": "21938641"
}


{
    "stakes": 100,
    "handData": {"210330135626-21938641-0000012-1": [
        {
            "inFantasy": false,
            "result": -29,
            "playerName": "pid5693617",
            "orderIndex": 1,
            "hero": true,
            "dead": "4d1 5c2 6h3 Ad4",
            "rows": "Kd1 Qs2 Ks3/2h0 Th0 7s1 Ts2 Qh4/8d0 Jh0 Jc0 Js3 9d4",
            "win": -2857,
            "playerId": "pid5693617"
        },
        {
            "inFantasy": true,
            "result": 29,
            "playerName": "pid3983767",
            "orderIndex": 0,
            "hero": false,
            "dead": "8s0 5d1 7d2",
            "rows": "Kh0 Ah0 As0/4c0 7c0 8c0 Qc0 Kc0/2c0 2s0 6d0 6c0 6s0",
            "win": 2771,
            "playerId": "pid3983767"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:20:53",
    "roomId": "21938641"
}


