{
    "stakes": 0.2,
    "handData": {"210330114836-21933249-0000000-1": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5478342",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jh1 Kd2 6s3 Jc4",
            "rows": "As1 Kc2 2d4/3d0 4c0 Th1 3s3 4s3/7h0 7c0 8c0 7d2 Tc4",
            "win": 1.2,
            "playerId": "pid5478342"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid517295",
            "orderIndex": 0,
            "hero": false,
            "dead": "8h1 6d2 5d3 3c4",
            "rows": "Ah0 Ac0 6h2/2c0 4h0 9d1 4d3 8s4/5s0 Qh1 Qc2 5c3 Qs4",
            "win": -1.2,
            "playerId": "pid517295"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": false,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:03:48",
    "roomId": "21933249"
}


{
    "stakes": 0.2,
    "handData": {"210330114836-21933249-0000001-1": [
        {
            "inFantasy": false,
            "result": 14,
            "playerName": "pid5478342",
            "orderIndex": 1,
            "hero": false,
            "dead": "3s1 Qs2 Kd3 Ks4",
            "rows": "Qh2 Kh3 7d4/5d0 9s0 8s1 9d3 2h4/6c0 7c0 Jc0 Ac1 5c2",
            "win": 2.7,
            "playerId": "pid5478342"
        },
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid517295",
            "orderIndex": 2,
            "hero": false,
            "dead": "9c1 6d2 6s3 6h4",
            "rows": "As0 Ad2 8h3/3d0 3c0 4s2 7h3 Ah4/Td0 Qd0 Th1 Tc1 9h4",
            "win": -3.2,
            "playerId": "pid517295"
        },
        {
            "inFantasy": false,
            "result": 2,
            "playerName": "pid5688836",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jd1 3h2 Js3 2d4",
            "rows": "Qc1 Kc2 7s4/2c0 2s0 5s0 5h3 Jh3/8d0 Ts0 8c1 4d2 4h4",
            "win": 0.4,
            "playerId": "pid5688836"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:05:40",
    "roomId": "21933249"
}


{
    "stakes": 0.2,
    "handData": {"210330114836-21933249-0000002-1": [
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid5478342",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qd1 9h2 Kh3 2c4",
            "rows": "Ac0 Kc3 Th4/2h0 5d0 2s1 3c2 3s4/7s0 8c0 8s1 Ts2 7h3",
            "win": -3,
            "playerId": "pid5478342"
        },
        {
            "inFantasy": false,
            "result": 42,
            "playerName": "pid517295",
            "orderIndex": 1,
            "hero": false,
            "dead": "7c1 3d2 Qh3 4h4",
            "rows": "Kd0 As3 Ad4/4c0 6h0 3h1 5c2 7d4/Jh0 Qs0 9c1 8d2 Td3",
            "win": 8.1,
            "playerId": "pid517295"
        },
        {
            "inFantasy": false,
            "result": -27,
            "playerName": "pid5688836",
            "orderIndex": 2,
            "hero": true,
            "dead": "9s1 Qc2 6c3 Ah4",
            "rows": "Ks0 Js1 Jd3/5h0 6s0 5s2 6d2 4d3/8h0 9d0 Jc1 4s4 Tc4",
            "win": -5.4,
            "playerId": "pid5688836"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:07:27",
    "roomId": "21933249"
}


{
    "stakes": 0.2,
    "handData": {"210330114836-21933249-0000003-1": [
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid5478342",
            "orderIndex": 2,
            "hero": false,
            "dead": "5c1 Td2 2d3 3s4",
            "rows": "Ah0 Ac0 7h4/4d0 6h0 6d1 4s2 5s4/Jc0 9c1 Kc2 Js3 Kd3",
            "win": -3.2,
            "playerId": "pid5478342"
        },
        {
            "inFantasy": true,
            "result": 38,
            "playerName": "pid517295",
            "orderIndex": 0,
            "hero": false,
            "dead": "As0 3d1 8c2",
            "rows": "7d0 7c0 7s0/2s0 3c0 4c0 5d0 6s0/2h0 3h0 4h0 8h0 Kh0",
            "win": 7.4,
            "playerId": "pid517295"
        },
        {
            "inFantasy": false,
            "result": -22,
            "playerName": "pid5688836",
            "orderIndex": 1,
            "hero": true,
            "dead": "Tc1 9d2 Ts3 9s4",
            "rows": "Th0 Ks1 Qs3/2c0 6c0 5h2 Jh4 Ad4/8d0 Qd0 Qc1 8s2 Qh3",
            "win": -4.4,
            "playerId": "pid5688836"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:09:09",
    "roomId": "21933249"
}


{
    "stakes": 0.2,
    "handData": {"210330114836-21933249-0000004-1": [
        {
            "inFantasy": true,
            "result": 35,
            "playerName": "pid5478342",
            "orderIndex": 1,
            "hero": false,
            "dead": "8d0 2s1 9h2",
            "rows": "Th0 Ac0 As0/3d0 3s0 7h0 7d0 7c0/4h0 4c0 Qh0 Qd0 Qs0",
            "win": 6.8,
            "playerId": "pid5478342"
        },
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "pid517295",
            "orderIndex": 2,
            "hero": false,
            "dead": "Kd0 Ad1 2h2",
            "rows": "6h0 6d0 6c0/3c0 5c0 8c0 9c0 Jc0/5s0 7s0 Ts0 Js0 Ks0",
            "win": 3.5,
            "playerId": "pid517295"
        },
        {
            "inFantasy": false,
            "result": -65,
            "playerName": "pid5688836",
            "orderIndex": 0,
            "hero": true,
            "dead": "8s1 2c2 8h3 6s4",
            "rows": "Ah0 Kc2 Kh3/3h0 5h0 5d1 2d4 4s4/Tc0 Jd0 9s1 Td2 9d3",
            "win": -10.6,
            "playerId": "pid5688836"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:09:58",
    "roomId": "21933249"
}


{
    "stakes": 0.2,
    "handData": {"210330114836-21933249-0000005-1": [
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "pid5478342",
            "orderIndex": 1,
            "hero": false,
            "dead": "As1 2h2 5s3 Jh4",
            "rows": "Ad0 Ac0 8d3/3h0 4s0 3s1 6d1 3d3/Tc0 Qd2 Kc2 6c4 7s4",
            "win": -4.2,
            "playerId": "pid5478342"
        },
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "pid517295",
            "orderIndex": 0,
            "hero": false,
            "dead": "5d0 8c1 9s2",
            "rows": "Td0 Qh0 Qs0/2d0 3c0 4c0 5c0 6s0/5h0 8h0 9h0 Th0 Kh0",
            "win": 4.1,
            "playerId": "pid517295"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": false,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:11:05",
    "roomId": "21933249"
}


{
    "stakes": 0.2,
    "handData": {"210330114836-21933249-0000006-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5478342",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qh1 5s2 3d3 Tc4",
            "rows": "Kh0 Kc0 5d3/2c0 6h1 Ah2 As2 8c3/7s0 9s0 4s1 9d4 Qd4",
            "win": -1.2,
            "playerId": "pid5478342"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5688836",
            "orderIndex": 0,
            "hero": true,
            "dead": "7c1 Jc2 2s3 7d4",
            "rows": "Ac0 9c3 Qs4/3c0 4h0 5c0 4d2 3s3/Td0 Jh1 Kd1 Jd2 Ts4",
            "win": 1.2,
            "playerId": "pid5688836"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:12:49",
    "roomId": "21933249"
}


