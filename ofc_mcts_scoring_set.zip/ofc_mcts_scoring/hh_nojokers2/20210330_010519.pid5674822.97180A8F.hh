{
    "stakes": 20,
    "handData": {"210330040140-21907581-0000000-1": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid5674822",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qd1 4h2 7c3 6c4",
            "rows": "2d3 Jh4 As4/3d0 3s0 7d0 5h2 3c3/4s0 Ts0 9s1 Qs1 8s2",
            "win": 233,
            "playerId": "pid5674822"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid4399795",
            "orderIndex": 0,
            "hero": false,
            "dead": "Js1 Jc2 4c3 2s4",
            "rows": "Ks2 Ac3 Ad4/2c0 5d0 6d0 4d1 3h2/8h0 9h0 7h1 5s3 7s4",
            "win": -240,
            "playerId": "pid4399795"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 22:05:19",
    "roomId": "21907581"
}


{
    "stakes": 20,
    "handData": {"210330040140-21907581-0000001-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5674822",
            "orderIndex": 0,
            "hero": true,
            "dead": "4h1 3h2 5s3 3s4",
            "rows": "Kd0 Qh3 Kc3/3c0 8h1 6c2 6s2 8s4/7d0 7c0 Ts0 Jd1 Jh4",
            "win": -120,
            "playerId": "pid5674822"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid4399795",
            "orderIndex": 1,
            "hero": false,
            "dead": "8c1 Qd2 5c3 9s4",
            "rows": "Qc0 Qs1 Ac4/4d0 4s0 6d2 4c3 5d3/2h0 7h0 Ah1 9h2 Kh4",
            "win": 116,
            "playerId": "pid4399795"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 22:06:04",
    "roomId": "21907581"
}


{
    "stakes": 20,
    "handData": {"210330040140-21907581-0000002-1": [
        {
            "inFantasy": true,
            "result": -1,
            "playerName": "pid5674822",
            "orderIndex": 1,
            "hero": true,
            "dead": "3s0 6c0",
            "rows": "7c0 8s0 Qs0/2d0 5d0 6d0 9d0 Jd0/2h0 3h0 5h0 Jh0 Kh0",
            "win": -20,
            "playerId": "pid5674822"
        },
        {
            "inFantasy": true,
            "result": 1,
            "playerName": "pid4399795",
            "orderIndex": 0,
            "hero": false,
            "dead": "2c0",
            "rows": "7h0 7d0 Ac0/4d0 8h0 Jc0 Js0 Qd0/3c0 Th0 Td0 Tc0 Ts0",
            "win": 19,
            "playerId": "pid4399795"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 22:06:30",
    "roomId": "21907581"
}


{
    "stakes": 20,
    "handData": {"210330040140-21907581-0000003-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5674822",
            "orderIndex": 0,
            "hero": true,
            "dead": "3c1 5s2 7s3 6d4",
            "rows": "Kh0 Kc1 7c3/6s0 Ac1 8s2 8c3 Ah4/Jc0 Qh0 Qc0 Jd2 Js4",
            "win": -120,
            "playerId": "pid5674822"
        },
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "pid4399795",
            "orderIndex": 1,
            "hero": false,
            "dead": "4d0",
            "rows": "Qd0 Qs0 Ad0/2h0 4h0 5h0 7h0 Jh0/9h0 9c0 9s0 Tc0 Ts0",
            "win": 116,
            "playerId": "pid4399795"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 22:07:11",
    "roomId": "21907581"
}


{
    "stakes": 20,
    "handData": {"210330040140-21907581-0000004-1": [
        {
            "inFantasy": true,
            "result": 2,
            "playerName": "pid5674822",
            "orderIndex": 1,
            "hero": true,
            "dead": "2h0 2c0",
            "rows": "Kc0 Ad0 As0/3h0 3s0 6d0 6c0 9s0/4d0 5s0 6s0 7h0 8c0",
            "win": 39,
            "playerId": "pid5674822"
        },
        {
            "inFantasy": false,
            "result": -2,
            "playerName": "pid4399795",
            "orderIndex": 0,
            "hero": false,
            "dead": "Tc1 Kh2 Jh3 2s4",
            "rows": "Ac0 Ah2 Ks4/3d0 5d0 5c1 7c2 7d3/9c0 Qc0 9d1 9h3 3c4",
            "win": -40,
            "playerId": "pid4399795"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 22:07:53",
    "roomId": "21907581"
}


{
    "stakes": 20,
    "handData": {"210330040140-21907581-0000005-1": [
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid5674822",
            "orderIndex": 0,
            "hero": true,
            "dead": "8h1 Qs2 Qd3 2d4",
            "rows": "As2 Ks3 5d4/6h0 Th0 3h1 3d1 6c2/7d0 Jh0 Js0 7c3 4s4",
            "win": -400,
            "playerId": "pid5674822"
        },
        {
            "inFantasy": true,
            "result": 20,
            "playerName": "pid4399795",
            "orderIndex": 1,
            "hero": false,
            "dead": "8d0 5c1 2c2",
            "rows": "Kh0 Kd0 Ah0/2h0 3s0 4c0 5h0 6s0/8c0 9s0 Tc0 Jd0 Qh0",
            "win": 388,
            "playerId": "pid4399795"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 22:08:44",
    "roomId": "21907581"
}


{
    "stakes": 20,
    "handData": {"210330040140-21907581-0000006-1": [
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid5674822",
            "orderIndex": 1,
            "hero": true,
            "dead": "Td1 3h2 9d3 9s4",
            "rows": "As0 Ah1 6c2/Jc0 4s1 5c2 3d4 4h4/7d0 7c0 Kd0 2c3 8s3",
            "win": -280,
            "playerId": "pid5674822"
        },
        {
            "inFantasy": false,
            "result": 14,
            "playerName": "pid4399795",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qh1 8h2 7h3 5d4",
            "rows": "Ac0 Ks3 Kh4/2d0 3s0 2s1 3c2 8c2/Tc0 Jd0 Jh1 Qc3 Qd4",
            "win": 272,
            "playerId": "pid4399795"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 22:10:03",
    "roomId": "21907581"
}


{
    "stakes": 20,
    "handData": {"210330040140-21907581-0000007-1": [
        {
            "inFantasy": false,
            "result": -28,
            "playerName": "pid5674822",
            "orderIndex": 0,
            "hero": true,
            "dead": "5c1 Tc2 Ts3 Jh4",
            "rows": "Qc0 Qh1 7h4/4s0 5h2 7s2 9s3 3h4/7d0 8d0 9d0 2d1 2c3",
            "win": -332,
            "playerId": "pid5674822"
        },
        {
            "inFantasy": true,
            "result": 28,
            "playerName": "pid4399795",
            "orderIndex": 1,
            "hero": false,
            "dead": "5d0 3c1",
            "rows": "7c0 Kh0 Kd0/2s0 5s0 8s0 Qs0 As0/6h0 6d0 6s0 9h0 9c0",
            "win": 322,
            "playerId": "pid4399795"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 22:12:45",
    "roomId": "21907581"
}


