{
    "stakes": 10,
    "handData": {"210330113952-21932890-0000001-1": [
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "pid301738",
            "orderIndex": 0,
            "hero": false,
            "dead": "7d1 2d2 5c3 Qd4",
            "rows": "4c2 Qc3 4h4/7h0 6d1 6c1 Td2 Kh4/5s0 9s0 Qs0 As0 7s3",
            "win": -90,
            "playerId": "pid301738"
        },
        {
            "inFantasy": true,
            "result": 9,
            "playerName": "pid3842150",
            "orderIndex": 1,
            "hero": false,
            "dead": "4d0",
            "rows": "5d0 9h0 Ah0/2s0 4s0 8s0 Ts0 Js0/3c0 7c0 Tc0 Kc0 Ac0",
            "win": 87,
            "playerId": "pid3842150"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": false,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:05:30",
    "roomId": "21932890"
}


{
    "stakes": 10,
    "handData": {"210330113952-21932890-0000002-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid301738",
            "orderIndex": 2,
            "hero": false,
            "dead": "4s1 7s2 Th3 6s4",
            "rows": "Ad0 As0 Jd3/Jh0 3h1 6h1 3d2 6c3/Qh0 Qs0 2d2 8d4 Kc4",
            "win": -60,
            "playerId": "pid301738"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid3842150",
            "orderIndex": 0,
            "hero": false,
            "dead": "8h1 8s2 2c3 Jc4",
            "rows": "Kd1 Js2 Qc3/6d0 7d0 4c1 4d3 Ah4/9h0 9c0 Ts0 3c2 9s4",
            "win": 116,
            "playerId": "pid3842150"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5684223",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qd1 3s2 4h3 5c4",
            "rows": "Kh0 9d2 5h4/2s0 7h0 5s1 7c1 5d3/8c0 Tc0 Ac2 Td3 2h4",
            "win": -60,
            "playerId": "pid5684223"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:08:23",
    "roomId": "21932890"
}


{
    "stakes": 10,
    "handData": {"210330113952-21932890-0000003-1": [
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid301738",
            "orderIndex": 1,
            "hero": false,
            "dead": "Kc1 3s2 2d3 Jd4",
            "rows": "Kd0 2h1 Ks1/3h0 3d0 9s2 Ts3 9c4/4h0 4d0 Qc2 7d3 Ac4",
            "win": -190,
            "playerId": "pid301738"
        },
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid3842150",
            "orderIndex": 2,
            "hero": false,
            "dead": "Jc1 5s2 6s3 3c4",
            "rows": "Ad0 6d2 As3/2c0 5c0 6h0 5d1 6c1/Qd0 8c2 Jh3 8s4 Kh4",
            "win": -190,
            "playerId": "pid3842150"
        },
        {
            "inFantasy": false,
            "result": 38,
            "playerName": "pid5684223",
            "orderIndex": 0,
            "hero": true,
            "dead": "8h1 5h2 Td3 8d4",
            "rows": "Qh0 Ah1 Qs4/2s0 9h0 4s2 4c3 9d3/7c0 Tc0 7h1 7s2 Th4",
            "win": 369,
            "playerId": "pid5684223"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:10:59",
    "roomId": "21932890"
}


{
    "stakes": 10,
    "handData": {"210330113952-21932890-0000004-1": [
        {
            "inFantasy": false,
            "result": -22,
            "playerName": "pid301738",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jc1 As2 8d3 5h4",
            "rows": "Kd0 7d3 6s4/2d0 Th0 Td1 2c2 Ah3/9s0 Qs0 9c1 9d2 5d4",
            "win": -30,
            "playerId": "pid301738"
        },
        {
            "inFantasy": false,
            "result": -34,
            "playerName": "pid3842150",
            "orderIndex": 1,
            "hero": false,
            "dead": "2h1 Qd2 8c3 4h4",
            "rows": "Ad0 Ac0 Qc4/5c0 8h0 8s1 3c2 3s3/Ts0 Jd1 Jh2 6c3 5s4",
            "win": -340,
            "playerId": "pid3842150"
        },
        {
            "inFantasy": true,
            "result": 56,
            "playerName": "pid5684223",
            "orderIndex": 2,
            "hero": true,
            "dead": "3d0",
            "rows": "Tc0 Kc0 Ks0/3h0 6h0 9h0 Qh0 Kh0/4c0 4s0 7h0 7c0 7s0",
            "win": 359,
            "playerId": "pid5684223"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:12:39",
    "roomId": "21932890"
}


{
    "stakes": 10,
    "handData": {"210330113952-21932890-0000005-1": [
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid3842150",
            "orderIndex": 1,
            "hero": false,
            "dead": "9c1 Th2 2s3 Jc4",
            "rows": "Tc1 Kc1 Qc2/3h0 4c0 7s0 2c2 6d4/5d0 Jd0 8h3 8c3 8s4",
            "win": -180,
            "playerId": "pid3842150"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "pid5684223",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jh1 Js2 Kd3 5c4",
            "rows": "9s2 9h3 8d4/6c0 Ts0 2h1 6h1 6s3/4h0 Qd0 Qs0 Qh2 4s4",
            "win": 175,
            "playerId": "pid5684223"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:13:43",
    "roomId": "21932890"
}


