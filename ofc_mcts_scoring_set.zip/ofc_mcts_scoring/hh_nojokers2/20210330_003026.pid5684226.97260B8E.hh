{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000000-1": [
        {
            "inFantasy": false,
            "result": 14,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "3d1 5s2 3c3 As4",
            "rows": "Ks1 Kc2 Ad4/4h0 4c0 7s0 2s2 2c3/Td0 Tc0 9h1 6d3 6s4",
            "win": 2.7,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ts1 7c2 3s3 Ac4",
            "rows": "Ah0 Kh3 Th4/5h0 Jc0 7h1 Js1 Jh3/8d0 Qd0 7d2 Jd2 9s4",
            "win": -2.8,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 21:30:26",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000001-1": [
        {
            "inFantasy": true,
            "result": 15,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "6s0 4d1",
            "rows": "Jc0 Qs0 Ac0/5h0 7h0 Th0 Qh0 Kh0/2d0 2c0 8h0 8d0 8s0",
            "win": 2.9,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qc1 Js2 Ts3 2h4",
            "rows": "Kd0 As3 9s4/4h0 6d0 3h1 4c2 3c3/8c0 9h0 7s1 7c2 7d4",
            "win": -3,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 21:31:16",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000002-1": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid1087966",
            "orderIndex": 2,
            "hero": false,
            "dead": "8d1 Qc2 9d3 3d4",
            "rows": "Kc1 Ah2 Kh3/3h0 4s0 4c1 3c2 9h3/7h0 7d0 7c0 6h4 As4",
            "win": 0.6,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": 8,
            "playerName": "pid5118808",
            "orderIndex": 0,
            "hero": false,
            "dead": "3s1 Kd2 2s3 4h4",
            "rows": "Ad0 Ac3 5c4/2h0 6s0 6d1 8c1 8s2/Th0 Jc0 Jd2 9c3 Td4",
            "win": 1.6,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": -11,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "6c1 2c2 Tc3 Js4",
            "rows": "9s2 Jh3 8h4/2d0 4d0 Qd2 5d3 5h4/5s0 7s0 Qs0 Ts1 Ks1",
            "win": -2.2,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 21:32:47",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000003-1": [
        {
            "inFantasy": true,
            "result": 42,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "Tc0 3c1",
            "rows": "Qc0 Kh0 Kc0/2d0 4d0 6d0 Td0 Jd0/5h0 5d0 5s0 8h0 8s0",
            "win": 8.1,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": true,
            "result": 0,
            "playerName": "pid5118808",
            "orderIndex": 2,
            "hero": false,
            "dead": "4c0 2c1 3d2",
            "rows": "9c0 9s0 Kd0/3s0 4s0 5c0 6h0 7h0/2s0 7s0 Ts0 Js0 Qs0",
            "win": 0,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": -42,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qd1 As2 7d3 Jc4",
            "rows": "Ks0 Qh1 Ac4/4h0 Ah0 Ad1 2h2 Jh3/6c0 7c0 9h2 8c3 Th4",
            "win": -8.4,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 21:34:02",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000004-1": [
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "Ts1 4s2 4d3 2h4",
            "rows": "7d2 Qh3 7h4/5s0 8c0 8d1 9c1 5d2/6h0 6d0 Jh0 9d3 4c4",
            "win": -2,
            "playerId": "pid1087966"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5118808",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qc1 Ah2 4h3 7s4",
            "rows": "As0 Ad1 Qs2/3d0 9s0 3c2 3s3 8h3/Th0 Td0 Kd1 Jd4 Kh4",
            "win": -2,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": 20,
            "playerName": "pid5684226",
            "orderIndex": 2,
            "hero": true,
            "dead": "2c1 2d2 6c3 3h4",
            "rows": "Jc1 Tc3 Kc4/Qd0 5c1 7c2 Ac3 9h4/2s0 6s0 8s0 Ks0 Js2",
            "win": 3.9,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 21:35:45",
    "roomId": "21907751"
}


