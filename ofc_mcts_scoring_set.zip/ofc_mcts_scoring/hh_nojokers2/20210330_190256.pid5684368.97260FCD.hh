{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000039-1": [
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid5118808",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jh1 9c2 8h3 Js4",
            "rows": "Ah0 Qh2 Kh4/4d0 6h0 3h1 4h3 6c4/2c0 Kc0 2h1 Ks2 2s3",
            "win": 1.9,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5684368",
            "orderIndex": 0,
            "hero": true,
            "dead": "7c1 Td2 6d3 5h4",
            "rows": "Ac0 9d3 Kd4/4c0 4s0 5c1 5d2 3s4/9h0 Jd0 Tc1 Qd2 8c3",
            "win": -2,
            "playerId": "pid5684368"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:02:56",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000040-1": [
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid5118808",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jh1 2h2 3h3 3d4",
            "rows": "Ac0 Kh2 Js3/5s0 7h0 9c1 7c3 8h4/4c0 Tc0 4s1 4d2 3c4",
            "win": -3.4,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": 17,
            "playerName": "pid5684368",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jc1 2s2 8s3 7s4",
            "rows": "Qs0 As1 Qh3/6c0 Kc0 Ks1 3s4 Ad4/7d0 8d0 5d2 Kd2 Td3",
            "win": 3.3,
            "playerId": "pid5684368"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:04:00",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000041-1": [
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid5118808",
            "orderIndex": 1,
            "hero": false,
            "dead": "2h1 5h2 Qc3 3d4",
            "rows": "As0 7s2 Kc4/4c0 6d0 5d1 7h1 3s3/8s0 Qh0 Ts2 9h3 Ks4",
            "win": -3.8,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": true,
            "result": 19,
            "playerName": "pid5684368",
            "orderIndex": 0,
            "hero": true,
            "dead": "2d0",
            "rows": "Kd0 Ah0 Ac0/3h0 Jh0 Jd0 Js0 Qs0/5c0 6c0 7d0 8c0 9s0",
            "win": 3.7,
            "playerId": "pid5684368"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:04:32",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000042-1": [
        {
            "inFantasy": false,
            "result": 19,
            "playerName": "pid5118808",
            "orderIndex": 0,
            "hero": false,
            "dead": "8h1 Jh2 Jc3 3h4",
            "rows": "Ah0 Ac3 Ks4/4h0 4s0 6c1 Qs1 6s2/Td0 Kd0 2d2 Jd3 7d4",
            "win": 3.7,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid5684368",
            "orderIndex": 1,
            "hero": true,
            "dead": "9h1 2h2 Th3 Kh4",
            "rows": "Qd2 Ad2 5h4/7s0 9s0 3s1 8s3 2c4/3c0 8c0 Kc0 9c1 Qc3",
            "win": -3.8,
            "playerId": "pid5684368"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:05:37",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000043-1": [
        {
            "inFantasy": true,
            "result": 10,
            "playerName": "pid5118808",
            "orderIndex": 1,
            "hero": false,
            "dead": "2d0 Js1 5d2",
            "rows": "Kc0 Ah0 Ac0/7h0 7s0 8h0 8d0 Qc0/3h0 3d0 6h0 6d0 6c0",
            "win": 1.9,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5684368",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jc1 9s2 3c3 2c4",
            "rows": "5s3 As3 Ks4/4s0 7c0 8s1 7d2 Qs4/9d0 9c0 Tc0 Th1 Ts2",
            "win": -2,
            "playerId": "pid5684368"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:06:25",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000044-1": [
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "pid5118808",
            "orderIndex": 0,
            "hero": false,
            "dead": "2d1 5d2 3d3 Th4",
            "rows": "As1 Kh3 Jc4/9d0 8h1 8d2 Qs2 9h4/2c0 3c0 4d0 5h0 6s3",
            "win": -1,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid5684368",
            "orderIndex": 1,
            "hero": true,
            "dead": "7d1 Td2 8c3 5s4",
            "rows": "7s3 7c4 Ac4/2h0 6d0 Jh1 Qh2 Qc2/8s0 Ts0 Ks0 9s1 2s3",
            "win": 1,
            "playerId": "pid5684368"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:07:31",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000045-1": [
        {
            "inFantasy": false,
            "result": 14,
            "playerName": "pid5118808",
            "orderIndex": 1,
            "hero": false,
            "dead": "2d1 4h2 7s3 Kh4",
            "rows": "Kd2 Ks3 6c4/Tc0 Js0 9h1 9d2 Jh4/5d0 Qh0 Qc0 8s1 8c3",
            "win": 2.7,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid5684368",
            "orderIndex": 0,
            "hero": true,
            "dead": "4c1 Td2 5c3 Ad4",
            "rows": "As0 Ah2 9s3/2c0 4s0 5h0 3d3 6d4/Qd0 9c1 Th1 Jc2 5s4",
            "win": -2.8,
            "playerId": "pid5684368"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:08:23",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000046-1": [
        {
            "inFantasy": true,
            "result": 19,
            "playerName": "pid5118808",
            "orderIndex": 0,
            "hero": false,
            "dead": "Kd0 2d1",
            "rows": "Th0 Td0 As0/4c0 5s0 6d0 7s0 8s0/2h0 3h0 5h0 9h0 Qh0",
            "win": 3.7,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid5684368",
            "orderIndex": 1,
            "hero": true,
            "dead": "2c1 7h2 2s3 Kh4",
            "rows": "Ac0 Ad1 7d3/6c0 8d0 5c1 5d2 Qc4/Qs0 Ks0 Qd2 9s3 Jd4",
            "win": -3.8,
            "playerId": "pid5684368"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:09:09",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000047-1": [
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid5118808",
            "orderIndex": 1,
            "hero": false,
            "dead": "6s1 6d2 Kh3 3h4",
            "rows": "Kd0 As1 Ac2/2c0 5d2 2d3 2s4 Td4/9s0 Jh0 Qh0 8h1 Th3",
            "win": 0.2,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": -1,
            "playerName": "pid5684368",
            "orderIndex": 0,
            "hero": true,
            "dead": "4d1 Qd2 7d3 5s4",
            "rows": "Ah1 Ad1 6h4/2h0 Ts2 8d3 8s3 Tc4/4c0 5c0 9c0 Jc0 3c2",
            "win": -0.2,
            "playerId": "pid5684368"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:10:11",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000048-1": [
        {
            "inFantasy": true,
            "result": 15,
            "playerName": "pid5118808",
            "orderIndex": 0,
            "hero": false,
            "dead": "6c0 3s1 5h2",
            "rows": "7s0 Qc0 Qs0/3d0 5d0 8d0 Kd0 Ad0/7c0 Th0 Td0 Tc0 Ts0",
            "win": 2.9,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": true,
            "result": -15,
            "playerName": "pid5684368",
            "orderIndex": 1,
            "hero": true,
            "dead": "4d0 8h0 8c0",
            "rows": "Ks0 Ah0 As0/9h0 9d0 Jh0 Jc0 Qd0/2c0 3h0 4h0 5s0 6s0",
            "win": -3,
            "playerId": "pid5684368"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:10:46",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000049-1": [
        {
            "inFantasy": true,
            "result": 22,
            "playerName": "pid5118808",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jh0 5c1 Qh2",
            "rows": "Kd0 Kc0 Ad0/2d0 3c0 4h0 5h0 6c0/3s0 4s0 5s0 Js0 As0",
            "win": 4.3,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": -22,
            "playerName": "pid5684368",
            "orderIndex": 0,
            "hero": true,
            "dead": "2c1 2h2 7s3 8d4",
            "rows": "Kh0 Qc1 8h4/Ts0 Ac0 3h2 Jc2 Ah3/6d0 9d0 6s1 7h3 6h4",
            "win": -4.4,
            "playerId": "pid5684368"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:11:30",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000050-1": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5118808",
            "orderIndex": 0,
            "hero": false,
            "dead": "6c1 8s2 5h3 9d4",
            "rows": "Ac0 Ah1 6s3/Jc0 Qs0 2h2 Jd2 Ad4/4d0 Kd0 4c1 4s3 Kc4",
            "win": -2.4,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid5684368",
            "orderIndex": 1,
            "hero": true,
            "dead": "2c1 8c2 5s3 5c4",
            "rows": "Td3 As3 4h4/9h0 3d1 8d1 9s2 3h4/Th0 Ts0 Qd0 Qc0 Qh2",
            "win": 2.3,
            "playerId": "pid5684368"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:12:39",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000051-1": [
        {
            "inFantasy": false,
            "result": 31,
            "playerName": "pid5118808",
            "orderIndex": 1,
            "hero": false,
            "dead": "2d1 8s2 Jd3 Th4",
            "rows": "Ah0 Qh3 Qc3/4c0 6d0 6c0 4s2 6h4/9d0 9h1 Kc1 Kh2 9c4",
            "win": 6,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": -31,
            "playerName": "pid5684368",
            "orderIndex": 0,
            "hero": true,
            "dead": "7c1 2c2 2s3 Ts4",
            "rows": "Ac0 Ad2 Td4/3d0 5s0 6s0 3c1 4h4/Tc0 8c1 9s2 7s3 Jh3",
            "win": -6.2,
            "playerId": "pid5684368"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:13:38",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000052-1": [
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "pid5118808",
            "orderIndex": 0,
            "hero": false,
            "dead": "2d0",
            "rows": "3d0 8s0 Jh0/7c0 8c0 Jc0 Qc0 Ac0/6d0 6c0 6s0 9h0 9d0",
            "win": 1.2,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5684368",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jd1 9s2 4h3 5d4",
            "rows": "Ad0 Ts2 Ah4/7h0 3h1 Qh1 Qs2 7d3/2s0 Kc0 Ks0 2c3 7s4",
            "win": -1.2,
            "playerId": "pid5684368"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:14:25",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000053-1": [
        {
            "inFantasy": false,
            "result": -25,
            "playerName": "pid5118808",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qd1 7c2 6h3 Js4",
            "rows": "Ad0 As0 Tc3/3c0 9c1 8d2 9d2 7h4/4h0 4s0 Kh1 Jd3 Kc4",
            "win": -0.9,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": true,
            "result": 25,
            "playerName": "pid5684368",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jh0 4d0 9h0",
            "rows": "Qh0 Qs0 Ah0/2s0 5s0 6s0 8s0 9s0/2c0 4c0 5c0 6c0 Qc0",
            "win": 0.9,
            "playerId": "pid5684368"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:15:03",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000054-1": [
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid5118808",
            "orderIndex": 0,
            "hero": false,
            "dead": "6c1 3d2 2d3 3s4",
            "rows": "Ac0 Kh3 9h4/5s0 2c1 2s1 5h2 3c3/7h0 7d0 Ts0 Qh2 6d4",
            "win": -3.2,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": 16,
            "playerName": "pid5684368",
            "orderIndex": 1,
            "hero": true,
            "dead": "8s1 Qd2 Qs3 6s4",
            "rows": "Kc0 Ks2 Qc3/3h1 As1 4s2 9d4 Ad4/7s0 8h0 Th0 Js0 9s3",
            "win": 3.1,
            "playerId": "pid5684368"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:16:05",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000055-1": [
        {
            "inFantasy": false,
            "result": 11,
            "playerName": "pid5118808",
            "orderIndex": 1,
            "hero": false,
            "dead": "8h1 Ts2 Jh3 6c4",
            "rows": "Kd0 Ks0 Kc4/2d2 Ah2 Ad3 As3 9h4/3s0 4s0 6h0 5s1 7c1",
            "win": 2.1,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": true,
            "result": -11,
            "playerName": "pid5684368",
            "orderIndex": 0,
            "hero": true,
            "dead": "9s0 Td0",
            "rows": "Qd0 Qc0 Ac0/2s0 3h0 4c0 5h0 6s0/7h0 8c0 9d0 Th0 Js0",
            "win": -2.2,
            "playerId": "pid5684368"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:16:36",
    "roomId": "21950775"
}


{
    "stakes": 0.2,
    "handData": {"210330192443-21950775-0000056-1": [
        {
            "inFantasy": true,
            "result": 24,
            "playerName": "pid5118808",
            "orderIndex": 0,
            "hero": false,
            "dead": "3d0 4h1 Jd2",
            "rows": "Qs0 Kd0 Ks0/2c0 3s0 4s0 5s0 6h0/9d0 9c0 9s0 Th0 Td0",
            "win": 4.7,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": -24,
            "playerName": "pid5684368",
            "orderIndex": 1,
            "hero": true,
            "dead": "7c1 3c2 Qc3 Qd4",
            "rows": "Ts1 Kc2 4d4/5d0 8c0 2s1 5c2 5h3/6c0 6s0 Js0 Jc3 2h4",
            "win": -4.8,
            "playerId": "pid5684368"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 16:17:29",
    "roomId": "21950775"
}


