{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000002-1": [
        {
            "inFantasy": false,
            "result": 17,
            "playerName": "pid2813203",
            "orderIndex": 1,
            "hero": false,
            "dead": "9c1 9h2 3s3 5s4",
            "rows": "Ah0 Td4 As4/Qs0 Qh1 Jd2 Js2 Tc3/3c0 4d0 6d0 7d1 5d3",
            "win": 107,
            "playerId": "pid2813203"
        },
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid5683634",
            "orderIndex": 0,
            "hero": false,
            "dead": "4h1 5h2 Ad3 6s4",
            "rows": "Qd0 7c3 Ac4/2h0 8d0 5c1 8c1 6h3/9s0 Ts0 9d2 Th2 8s4",
            "win": -110,
            "playerId": "pid5683634"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": false,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 20:49:37",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000003-1": [
        {
            "inFantasy": true,
            "result": 18,
            "playerName": "pid2813203",
            "orderIndex": 0,
            "hero": false,
            "dead": "2h0 7d1 8c2",
            "rows": "Kc0 Ks0 As0/4c0 4s0 9d0 9c0 Qs0/6h0 7h0 Th0 Jh0 Ah0",
            "win": 175,
            "playerId": "pid2813203"
        },
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid5683634",
            "orderIndex": 1,
            "hero": false,
            "dead": "3d1 Qc2 8s3 8d4",
            "rows": "Ac2 9s3 Ad3/5d0 Jd0 Js1 2s2 8h4/3h0 9h0 Qh0 4h1 Ts4",
            "win": -180,
            "playerId": "pid5683634"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": false,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 20:50:23",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000004-1": [
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid5683634",
            "orderIndex": 1,
            "hero": false,
            "dead": "Th1 4d2 9h3 Jc4",
            "rows": "Ad3 6d4 Qd4/2d0 Kd0 Ks1 4h2 4s3/4c0 7c0 Ac0 Kc1 Qc2",
            "win": 48,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "pid5674822",
            "orderIndex": 0,
            "hero": true,
            "dead": "Js1 5c2 9s3 2s4",
            "rows": "As0 Kh2 8c3/9d0 Tc0 6s1 9c1 7s3/3h0 Qh0 3c2 6c4 Qs4",
            "win": -50,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 20:51:49",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000005-1": [
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid5683634",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jd1 5c2 2h3 6s4",
            "rows": "Ad0 5h3 Qd4/2c0 6c0 8c1 6d2 3d3/8h0 9h0 Qh1 Js2 Ts4",
            "win": -80,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": false,
            "result": 8,
            "playerName": "pid5674822",
            "orderIndex": 1,
            "hero": true,
            "dead": "9d1 4c2 Td3 3c4",
            "rows": "Qc0 As2 8s4/2d0 2s1 Kd2 7c3 7d4/3h0 6h0 Ah0 4h1 Th3",
            "win": 78,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 20:53:09",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000006-1": [
        {
            "inFantasy": false,
            "result": 7,
            "playerName": "pid5683634",
            "orderIndex": 1,
            "hero": false,
            "dead": "3s1 9d2 As3 Kd4",
            "rows": "Ah0 Ad0 2d3/5s0 6c1 6s2 Th2 5c4/8h0 Jc0 Jh1 4h3 Js4",
            "win": 68,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": false,
            "result": -7,
            "playerName": "pid5674822",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ac1 Kc2 7h3 7s4",
            "rows": "Kh0 Ks0 Td4/2s0 3h1 4s1 2c2 3c3/8c0 9s0 Qc2 9c3 8s4",
            "win": -70,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 20:54:33",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000007-1": [
        {
            "inFantasy": true,
            "result": -14,
            "playerName": "pid5683634",
            "orderIndex": 0,
            "hero": false,
            "dead": "2h0 3c1 5s2",
            "rows": "Ks0 Ac0 As0/8h0 8s0 Th0 Td0 Jd0/4c0 5c0 9c0 Jc0 Qc0",
            "win": -140,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": true,
            "result": 14,
            "playerName": "pid5674822",
            "orderIndex": 1,
            "hero": true,
            "dead": "5d0 3d0",
            "rows": "6h0 6c0 6s0/2s0 3s0 4s0 Ts0 Qs0/3h0 5h0 9h0 Jh0 Qh0",
            "win": 136,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 20:55:08",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000008-1": [
        {
            "inFantasy": false,
            "result": -1,
            "playerName": "pid5683634",
            "orderIndex": 1,
            "hero": false,
            "dead": "2d1 5d2 7h3 Td4",
            "rows": "Ad0 As3 Qd4/Ts0 7d2 7c2 7s3 8d4/3c0 4c0 Jc0 9c1 Kc1",
            "win": -10,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": true,
            "result": 1,
            "playerName": "pid5674822",
            "orderIndex": 0,
            "hero": true,
            "dead": "2s0 3d0",
            "rows": "4d0 Ah0 Ac0/9h0 Tc0 Js0 Qc0 Kd0/2h0 5h0 6h0 Jh0 Qh0",
            "win": 10,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 20:55:59",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000009-1": [
        {
            "inFantasy": true,
            "result": 8,
            "playerName": "pid5683634",
            "orderIndex": 0,
            "hero": false,
            "dead": "8s0 3c1 5c2",
            "rows": "2h0 2s0 Kh0/7d0 8d0 9c0 Ts0 Jc0/6h0 7h0 8h0 9h0 Th0",
            "win": 78,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid5674822",
            "orderIndex": 1,
            "hero": true,
            "dead": "5d1 3s2 5s3 4d4",
            "rows": "Ks0 Jh3 Kc4/Ac0 Ah1 5h2 7s3 2c4/3d0 Td0 Jd0 9d1 Qd2",
            "win": -80,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 20:56:50",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000010-1": [
        {
            "inFantasy": true,
            "result": 8,
            "playerName": "pid5683634",
            "orderIndex": 1,
            "hero": false,
            "dead": "4h0 9h1 8s2",
            "rows": "Qc0 Ah0 Ac0/3h0 3s0 7c0 7s0 Js0/2d0 6d0 9d0 Jd0 Qd0",
            "win": 78,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": true,
            "result": -8,
            "playerName": "pid5674822",
            "orderIndex": 0,
            "hero": true,
            "dead": "7d0 6c0",
            "rows": "Th0 Jh0 Qh0/2h0 3c0 4d0 8d0 Ks0/4c0 4s0 5d0 5c0 5s0",
            "win": -80,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 20:57:21",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000011-1": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid4483271",
            "orderIndex": 0,
            "hero": false,
            "dead": "8s1 Kc2 9h3 3c4",
            "rows": "As0 Qh1 Ad2/2h0 6s0 5c1 Kh3 Ac3/3d0 7d0 7s2 2c4 4s4",
            "win": -120,
            "playerId": "pid4483271"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5683634",
            "orderIndex": 1,
            "hero": false,
            "dead": "5d1 Ts2 Jh3 7h4",
            "rows": "Qd1 Qc1 Js4/4h0 6d2 8d2 6h3 6c3/Td0 Jc0 Qs0 Kd0 3h4",
            "win": -120,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "pid5674822",
            "orderIndex": 2,
            "hero": true,
            "dead": "2d1 8h2 Ah3 7c4",
            "rows": "Ks2 8c3 Jd4/3s0 4d0 4c1 5s3 5h4/9d0 9s0 Tc0 Th1 9c2",
            "win": 233,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 20:59:22",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000012-1": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid4483271",
            "orderIndex": 2,
            "hero": false,
            "dead": "Qd1 4c2 Js3 5c4",
            "rows": "Kh0 Kd2 As4/2d0 3c0 2h1 5h2 5s3/8s0 9c0 9s1 3d3 Td4",
            "win": -120,
            "playerId": "pid4483271"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5683634",
            "orderIndex": 0,
            "hero": false,
            "dead": "Ks1 8h2 Ah3 8d4",
            "rows": "Ad0 Ac1 8c3/4h0 9d0 Th2 Tc2 7c4/Jh0 Jd0 Kc1 Jc3 3s4",
            "win": -120,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "pid5674822",
            "orderIndex": 1,
            "hero": true,
            "dead": "9h1 4s2 6c3 3h4",
            "rows": "4d3 7h4 Qh4/5d0 7s0 2c1 2s1 7d3/6d0 6s0 Qc0 6h2 Qs2",
            "win": 233,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 21:01:51",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000013-1": [
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "pid4483271",
            "orderIndex": 1,
            "hero": false,
            "dead": "Ks1 8c2 3h3 Tc4",
            "rows": "Ac0 Ad1 6d4/3c0 4d1 3s2 4c2 2d3/7h0 8d0 9h0 6h3 5s4",
            "win": 87,
            "playerId": "pid4483271"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid5683634",
            "orderIndex": 2,
            "hero": false,
            "dead": "Qh1 2h2 Qd3 6s4",
            "rows": "Kd0 Js2 8s4/8h0 5c1 6c1 4h3 7c3/9d0 9c0 Ts0 9s2 Th4",
            "win": 29,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5674822",
            "orderIndex": 0,
            "hero": true,
            "dead": "3d1 Td2 5h3 4s4",
            "rows": "Kh0 Kc2 7d3/5d0 7s0 Ah1 As1 2s4/2c0 Jc0 Jd2 Qc3 Qs4",
            "win": -120,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 21:03:47",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000014-1": [
        {
            "inFantasy": true,
            "result": 2,
            "playerName": "pid4483271",
            "orderIndex": 0,
            "hero": false,
            "dead": "4d0 2s1 5c2",
            "rows": "Kh0 Ks0 Ad0/6s0 7h0 8c0 9s0 Tc0/4h0 6h0 9h0 Th0 Qh0",
            "win": 19,
            "playerId": "pid4483271"
        },
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid5683634",
            "orderIndex": 1,
            "hero": false,
            "dead": "5d1 7c2 2d3 2c4",
            "rows": "8h1 5s3 8d4/6c0 Jc0 4c2 Qc3 3c4/4s0 Ts0 Qs0 3s1 Js2",
            "win": 10,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": true,
            "result": -3,
            "playerName": "pid5674822",
            "orderIndex": 2,
            "hero": true,
            "dead": "3d0 2h0",
            "rows": "9c0 Jh0 Kc0/6d0 7d0 8s0 Ah0 Ac0/9d0 Td0 Jd0 Qd0 Kd0",
            "win": -30,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 21:04:53",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000015-1": [
        {
            "inFantasy": false,
            "result": 2,
            "playerName": "pid4483271",
            "orderIndex": 2,
            "hero": false,
            "dead": "4h1 Td2 5d3 Jc4",
            "rows": "Qh1 Qc2 5c3/Jd1 2h2 2d3 2s4 Ah4/5s0 6d0 7h0 8h0 9s0",
            "win": 19,
            "playerId": "pid4483271"
        },
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "pid5683634",
            "orderIndex": 0,
            "hero": false,
            "dead": "8c1 7c2 8d3 9d4",
            "rows": "Kc0 Ks0 Js4/Tc0 As1 Ac2 5h3 Kd4/4d0 Qd0 3d1 3c2 3s3",
            "win": -90,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": true,
            "result": 7,
            "playerName": "pid5674822",
            "orderIndex": 1,
            "hero": true,
            "dead": "2c0 4c0",
            "rows": "6c0 7d0 Ad0/6s0 7s0 8s0 Ts0 Qs0/3h0 6h0 Th0 Jh0 Kh0",
            "win": 68,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 21:06:24",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000016-1": [
        {
            "inFantasy": true,
            "result": -1,
            "playerName": "pid4483271",
            "orderIndex": 1,
            "hero": false,
            "dead": "3s0",
            "rows": "9h0 Jc0 Js0/5d0 6s0 7s0 8d0 9s0/4h0 4s0 Kh0 Kc0 Ks0",
            "win": -10,
            "playerId": "pid4483271"
        },
        {
            "inFantasy": true,
            "result": 7,
            "playerName": "pid5683634",
            "orderIndex": 2,
            "hero": false,
            "dead": "2h0 4d1",
            "rows": "8h0 8c0 8s0/6h0 Qh0 Ah0 Ac0 As0/9d0 Tc0 Jh0 Qc0 Kd0",
            "win": 68,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5674822",
            "orderIndex": 0,
            "hero": true,
            "dead": "Td1 Jd2 7h3 3d4",
            "rows": "Qs2 Ts3 Qd4/5s0 6d0 2d1 3c3 4c4/2c0 5c0 7c0 6c1 9c2",
            "win": -60,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 21:07:21",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000017-1": [
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid4483271",
            "orderIndex": 0,
            "hero": false,
            "dead": "3d1 Td2 8d3 2d4",
            "rows": "Kc0 Qc3 Ad4/4c0 5d0 6c1 3s2 2s4/2h0 Jh0 Th1 Qh2 9h3",
            "win": -200,
            "playerId": "pid4483271"
        },
        {
            "inFantasy": true,
            "result": 9,
            "playerName": "pid5683634",
            "orderIndex": 1,
            "hero": false,
            "dead": "3c0 5h1",
            "rows": "Ts0 Qd0 Qs0/5s0 6h0 6d0 Jd0 Js0/7h0 7d0 7c0 7s0 8h0",
            "win": 87,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": true,
            "result": 11,
            "playerName": "pid5674822",
            "orderIndex": 2,
            "hero": true,
            "dead": "2c0",
            "rows": "Tc0 Ac0 As0/3h0 4h0 4d0 4s0 9s0/8c0 8s0 Kh0 Kd0 Ks0",
            "win": 107,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 21:08:08",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000018-1": [
        {
            "inFantasy": false,
            "result": -24,
            "playerName": "pid4483271",
            "orderIndex": 2,
            "hero": false,
            "dead": "4c1 3c2 3d3 5c4",
            "rows": "Ac1 Ah2 As4/7d0 8s0 8d2 4s3 6h4/9h0 Th0 Jh0 2h1 5h3",
            "win": -175,
            "playerId": "pid4483271"
        },
        {
            "inFantasy": true,
            "result": 19,
            "playerName": "pid5683634",
            "orderIndex": 0,
            "hero": false,
            "dead": "5s0 6d1",
            "rows": "Ts0 Kh0 Kc0/2s0 7h0 7c0 8h0 8c0/3h0 3s0 9d0 9c0 Qh0",
            "win": 170,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid5674822",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qd1 6c2 9s3 4d4",
            "rows": "Ad0 Qc2 Jd4/2d0 Kd2 Td3 Tc3 4h4/7s0 Js0 Qs0 6s1 Ks1",
            "win": 0,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 21:09:39",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000019-1": [
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid5683634",
            "orderIndex": 1,
            "hero": false,
            "dead": "5h1 9c2 3h3 Ks4",
            "rows": "Qh2 6d4 Ts4/2s0 5c1 4d2 4h3 4s3/7s0 8c0 9s0 Tc0 Jc1",
            "win": 97,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5674822",
            "orderIndex": 0,
            "hero": true,
            "dead": "Td1 9d2 Th3 7c4",
            "rows": "Ad0 Ac0 6s4/5s0 Qc1 2h3 Qs3 4c4/6h0 7h0 9h1 8h2 Kh2",
            "win": -100,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 21:11:09",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000020-1": [
        {
            "inFantasy": false,
            "result": -22,
            "playerName": "pid4483271",
            "orderIndex": 0,
            "hero": false,
            "dead": "9s1 5h2 4h3 6h4",
            "rows": "Kd2 9h4 Th4/3d0 6c0 4c1 4s1 6d3/2h0 2s0 Jc0 8d2 2c3",
            "win": -220,
            "playerId": "pid4483271"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "pid5683634",
            "orderIndex": 1,
            "hero": false,
            "dead": "Js1 3s2 7c3 3c4",
            "rows": "Qc1 Ah1 Ad3/9c0 Td0 5d2 9d2 Tc4/8s0 Kc0 Ks0 8c3 7d4",
            "win": 87,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": false,
            "result": 13,
            "playerName": "pid5674822",
            "orderIndex": 2,
            "hero": true,
            "dead": "2d1 Jd2 4d3 8h4",
            "rows": "Qs0 Qd1 5c3/Ac0 As0 Ts2 7s3 6s4/7h0 Jh0 Qh1 3h2 Kh4",
            "win": 126,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 21:13:13",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000021-1": [
        {
            "inFantasy": false,
            "result": -54,
            "playerName": "pid4483271",
            "orderIndex": 2,
            "hero": false,
            "dead": "Qd1 3c2 6s3 2d4",
            "rows": "Ah0 Ad1 Jc3/4s0 Ts1 5d2 7c4 Th4/9d0 9c0 Kd0 Ks2 Kh3",
            "win": -280,
            "playerId": "pid4483271"
        },
        {
            "inFantasy": true,
            "result": 49,
            "playerName": "pid5683634",
            "orderIndex": 0,
            "hero": false,
            "dead": "Td0 2s1 Ac2",
            "rows": "8h0 8d0 8s0/3h0 5h0 6h0 9h0 Jh0/3s0 5s0 7s0 9s0 Qs0",
            "win": 272,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": true,
            "result": 5,
            "playerName": "pid5674822",
            "orderIndex": 1,
            "hero": true,
            "dead": "7d0",
            "rows": "Jd0 Js0 Qh0/3d0 4c0 5c0 6d0 7h0/6c0 8c0 Tc0 Qc0 Kc0",
            "win": 0,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 21:14:03",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000022-1": [
        {
            "inFantasy": true,
            "result": 10,
            "playerName": "pid5683634",
            "orderIndex": 1,
            "hero": false,
            "dead": "3h0 2h1 4s2",
            "rows": "Qd0 Qs0 Kd0/2s0 3c0 4d0 5s0 Ah0/5c0 6h0 7s0 8c0 9h0",
            "win": 97,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5674822",
            "orderIndex": 0,
            "hero": true,
            "dead": "6c1 Qh2 3s3 4h4",
            "rows": "As1 7c3 Tc4/9c0 Jh0 5h1 9s3 8s4/3d0 6d0 8d0 7d2 Td2",
            "win": -100,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 21:14:52",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000023-1": [
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid5683634",
            "orderIndex": 0,
            "hero": false,
            "dead": "8h1 Kh2 5d3 6h4",
            "rows": "Kd0 7c3 7s4/4h0 Tc2 Ts2 3c3 4d4/3s0 4s0 5s0 2h1 6d1",
            "win": 97,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5674822",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jh1 9d2 8c3 Js4",
            "rows": "As0 8s2 9c3/3d0 5c1 2d2 Ks3 Jd4/9h0 Th0 Jc0 Kc1 4c4",
            "win": -100,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 21:16:10",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000024-1": [
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid5683634",
            "orderIndex": 1,
            "hero": false,
            "dead": "Ts1 9s2 4c3 Jd4",
            "rows": "Ad2 Ac2 2c3/6c0 8d0 7d1 8s3 Tc4/3h0 3d0 3c0 Jc1 Th4",
            "win": -200,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": false,
            "result": 20,
            "playerName": "pid5674822",
            "orderIndex": 0,
            "hero": true,
            "dead": "7h1 Kh2 Jh3 Qc4",
            "rows": "As2 Kc3 Ks3/8h0 9c0 9h2 5h4 5s4/4h0 Qh0 Qd0 4s1 Qs1",
            "win": 194,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 21:17:37",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000025-1": [
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid5683634",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jc1 4d2 3c3 2h4",
            "rows": "Kh0 Kc0 Ah3/7c0 6c1 8d1 9d2 Th3/4s0 5s0 8s2 7h4 9s4",
            "win": -160,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": true,
            "result": 16,
            "playerName": "pid5674822",
            "orderIndex": 1,
            "hero": true,
            "dead": "2s0 2c0",
            "rows": "Qc0 Kd0 Ks0/3h0 3s0 Td0 Ts0 Jh0/5h0 6d0 7d0 8h0 9c0",
            "win": 155,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 21:18:35",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000026-1": [
        {
            "inFantasy": false,
            "result": 20,
            "playerName": "pid5683634",
            "orderIndex": 1,
            "hero": false,
            "dead": "4d1 3s2 8s3 7c4",
            "rows": "Kd1 As2 Ks4/8d0 Td0 5c1 5h3 8h3/9h0 9c0 Qs0 Qc2 9s4",
            "win": 194,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid5674822",
            "orderIndex": 0,
            "hero": true,
            "dead": "9d1 2c2 2s3 2d4",
            "rows": "Kc0 Ah2 Ts4/3c0 4h0 7h1 3h2 7d4/6d0 6s0 Jd1 Jc3 Qd3",
            "win": -200,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 21:19:56",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000027-1": [
        {
            "inFantasy": true,
            "result": 18,
            "playerName": "pid5683634",
            "orderIndex": 0,
            "hero": false,
            "dead": "5h0 3h1",
            "rows": "6c0 Kh0 Ah0/2d0 4d0 5d0 Td0 Qd0/2s0 3s0 7s0 Ts0 Qs0",
            "win": 175,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid5674822",
            "orderIndex": 1,
            "hero": true,
            "dead": "3c1 5c2 Kd3 Ks4",
            "rows": "Qh1 Ad3 8d4/6h0 9s0 Jh2 Js2 9d3/Tc0 Kc0 Ac0 Jc1 7h4",
            "win": -180,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 21:20:43",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000028-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5683634",
            "orderIndex": 1,
            "hero": false,
            "dead": "2h1 Ts2 8d3 Qd4",
            "rows": "As0 Ac2 Kh4/5d0 Jd0 4d1 5h2 2s4/2c0 Kc0 6c1 3c3 Jc3",
            "win": -60,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5674822",
            "orderIndex": 0,
            "hero": true,
            "dead": "4h1 Qh2 Qc3 5s4",
            "rows": "3d1 Kd2 Ad3/6s0 8s0 7s1 7c2 8h4/9h0 Td0 Tc0 9s3 Jh4",
            "win": 58,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 21:22:10",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000029-1": [
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid5683634",
            "orderIndex": 0,
            "hero": false,
            "dead": "4c1 7c2 3c3 Jd4",
            "rows": "Ah1 Kh2 7s4/8c0 Td0 2h1 Tc3 2d4/2s0 4s0 5s0 Ks2 6s3",
            "win": 97,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5674822",
            "orderIndex": 1,
            "hero": true,
            "dead": "2c1 3d2 9d3 4h4",
            "rows": "Ad0 9h3 8s4/3h0 3s0 7d0 6d2 Jc4/Jh0 Ts1 Kc1 Th2 Kd3",
            "win": -100,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 21:23:26",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000030-1": [
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid5683634",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qc1 9c2 7d3 2s4",
            "rows": "Qd0 Kh0 2c4/Ac0 6c1 2d2 3h2 Ah3/4s0 Js0 9s1 Jd3 Jh4",
            "win": 10,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": false,
            "result": -1,
            "playerName": "pid5674822",
            "orderIndex": 0,
            "hero": true,
            "dead": "3c1 3d2 4h3 5c4",
            "rows": "As1 Kc2 Qh3/2h0 7c0 7s0 9d2 Ks3/8d0 Td0 Th1 4d4 6d4",
            "win": -10,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 21:24:55",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000031-1": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5683634",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jc1 4h2 5d3 8d4",
            "rows": "Qs2 Kh2 Js4/2c0 5c0 2h1 5s1 6c3/3h0 9d0 9s0 3d3 Jh4",
            "win": 58,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5674822",
            "orderIndex": 1,
            "hero": true,
            "dead": "Ks1 Ad2 2s3 Kc4",
            "rows": "Ac0 Ah1 3c3/7h0 7d1 6h2 7c3 6s4/Td0 Tc0 Qd0 Qh2 5h4",
            "win": -60,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 21:26:15",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000032-1": [
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid5683634",
            "orderIndex": 1,
            "hero": false,
            "dead": "6h1 4s2 2h3 3h4",
            "rows": "Qs3 As3 3d4/5d0 6d1 5s2 Js2 Td4/5h0 7h0 9h0 Qh0 Th1",
            "win": 97,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5674822",
            "orderIndex": 0,
            "hero": true,
            "dead": "6s1 5c2 6c3 8d4",
            "rows": "Kc0 Ks0 7c4/4c0 2s1 2d3 Ac3 3c4/9c0 Ts0 8s1 Jh2 Qd2",
            "win": -100,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 21:27:37",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000033-1": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "pid5683634",
            "orderIndex": 0,
            "hero": false,
            "dead": "7h1 5c2 Th3 Ks4",
            "rows": "Ad1 8c4 8s4/9s0 Qh0 Js1 Jd2 Qd2/3h0 3d0 3s0 4h3 4d3",
            "win": 145,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid5674822",
            "orderIndex": 1,
            "hero": true,
            "dead": "9c1 8h2 2s3 Jh4",
            "rows": "Ac0 Qc1 4s4/2h0 Ts0 6c2 6s2 2c3/Kd0 Kc0 7d1 5s3 Kh4",
            "win": -150,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 21:28:55",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000034-1": [
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid5683634",
            "orderIndex": 1,
            "hero": false,
            "dead": "9h1 8c2 7c3 Kh4",
            "rows": "Ad0 Ks2 Ts4/2s0 4h1 3s3 6h3 4s4/3c0 5c0 Qc0 2c1 9c2",
            "win": -170,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": false,
            "result": 17,
            "playerName": "pid5674822",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qh1 8h2 Td3 Js4",
            "rows": "Ac1 Kd3 Ah4/Jc0 Tc2 Jd2 Jh3 7d4/5s0 7s0 9s0 As0 8s1",
            "win": 165,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 21:30:16",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000035-1": [
        {
            "inFantasy": false,
            "result": -33,
            "playerName": "pid5683634",
            "orderIndex": 0,
            "hero": false,
            "dead": "3h1 6c2 2s3 5h4",
            "rows": "Ad0 Ac0 2c3/2h0 2d0 4c1 4h2 Ah3/Qh0 Jd1 8h2 9d4 Kd4",
            "win": -330,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": true,
            "result": 33,
            "playerName": "pid5674822",
            "orderIndex": 1,
            "hero": true,
            "dead": "5s0 6h0 Js0",
            "rows": "9h0 9c0 9s0/Ts0 Jh0 Qc0 Kc0 As0/7h0 7d0 8d0 8c0 8s0",
            "win": 320,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 21:31:00",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000036-1": [
        {
            "inFantasy": false,
            "result": -29,
            "playerName": "pid5683634",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qs1 Tc2 7h3 Th4",
            "rows": "Kc0 7d3 Jd4/3c0 5h0 4s2 2d3 7c4/9d0 Ts0 8c1 Jc1 7s2",
            "win": -290,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": true,
            "result": 29,
            "playerName": "pid5674822",
            "orderIndex": 0,
            "hero": true,
            "dead": "4c0 5s0 6h0",
            "rows": "Jh0 Ah0 As0/6d0 Td0 Qd0 Kd0 Ad0/2c0 2s0 8h0 8d0 8s0",
            "win": 281,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 21:31:46",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000037-1": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5683634",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qs1 5d2 3s3 9d4",
            "rows": "Ac0 4d2 5h3/8c0 Ts0 9c1 Ad3 6h4/2h0 Kh0 Jh1 2c2 Ah4",
            "win": -120,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid5674822",
            "orderIndex": 1,
            "hero": true,
            "dead": "9s1 As2 7d3 5s4",
            "rows": "Qc1 Jd3 Js4/4c0 7s0 5c1 Kd2 Kc2/3h0 3c0 Th0 3d3 8d4",
            "win": 116,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 21:33:14",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000038-1": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5683634",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jh1 5s2 4c3 As4",
            "rows": "Ac0 Th2 8h4/2d0 Qh1 Qs1 2s2 7c3/9h0 Kh0 Kd0 3c3 8c4",
            "win": -120,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid5674822",
            "orderIndex": 0,
            "hero": true,
            "dead": "Tc1 Jc2 Ks3 4h4",
            "rows": "Ah0 Kc3 9d4/2h0 2c0 5d1 4d2 4s3/6s0 7h0 6c1 7s2 7d4",
            "win": 116,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 21:34:39",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000039-1": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid5683634",
            "orderIndex": 0,
            "hero": false,
            "dead": "Tc1 5c2 2s3 Jd4",
            "rows": "7c3 7s4 Qc4/6d0 8s1 6s2 8c2 Ts3/4h0 8h0 9h0 Th0 5h1",
            "win": 116,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5674822",
            "orderIndex": 1,
            "hero": true,
            "dead": "2c1 6h2 Ac3 Ks4",
            "rows": "As0 Ah2 4s3/9d0 9c0 Jc1 Js1 5s2/7d0 Td0 Kh3 2d4 Qh4",
            "win": -120,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 21:35:58",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000040-1": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "pid5683634",
            "orderIndex": 1,
            "hero": false,
            "dead": "As1 6s2 Kd3 2d4",
            "rows": "Ah0 Ad0 7c4/2s0 7h1 7s1 2c3 4d4/8h0 Th0 Qd2 Qs2 Tc3",
            "win": 145,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid5674822",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ts1 4s2 Js3 8c4",
            "rows": "Kh0 Qc1 7d3/9c0 Ac0 4h1 Kc2 5c3/3d0 6d0 3s2 4c4 Qh4",
            "win": -150,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 21:37:20",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000041-1": [
        {
            "inFantasy": true,
            "result": 4,
            "playerName": "pid5683634",
            "orderIndex": 0,
            "hero": false,
            "dead": "6d0 5h1 2c2",
            "rows": "Qh0 Qc0 Ad0/7d0 8h0 9d0 Th0 Jh0/3s0 4s0 8s0 Js0 Ks0",
            "win": 39,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": false,
            "result": -4,
            "playerName": "pid5674822",
            "orderIndex": 1,
            "hero": true,
            "dead": "7h1 7s2 9s3 Ts4",
            "rows": "Qd1 Kh4 Kc4/3d0 6s0 9h2 Ah3 As3/4c0 8c0 Tc0 5c1 7c2",
            "win": -40,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 21:38:08",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000042-1": [
        {
            "inFantasy": false,
            "result": -24,
            "playerName": "pid5683634",
            "orderIndex": 1,
            "hero": false,
            "dead": "9h1 9d2 8s3 2d4",
            "rows": "Kd0 Kh2 3s4/5s0 4c1 2s2 3h3 8h4/7c0 7s0 Qs0 7d1 7h3",
            "win": -240,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": true,
            "result": 24,
            "playerName": "pid5674822",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h0 3c0",
            "rows": "Qc0 Ks0 Ad0/4h0 4d0 4s0 5h0 5c0/Td0 Tc0 Jd0 Jc0 Js0",
            "win": 233,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 21:38:54",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000043-1": [
        {
            "inFantasy": false,
            "result": 7,
            "playerName": "pid5683634",
            "orderIndex": 0,
            "hero": false,
            "dead": "9h1 7c2 3s3 Qs4",
            "rows": "4d3 Ad3 4h4/5c0 7s0 5d1 7d2 9c2/2h0 2d0 2c0 6s1 6d4",
            "win": 68,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": false,
            "result": -7,
            "playerName": "pid5674822",
            "orderIndex": 1,
            "hero": true,
            "dead": "6c1 5s2 7h3 8s4",
            "rows": "Ts3 Ac3 Ks4/3c0 Jh0 4c1 3d2 Jd2/9d0 9s0 Qc0 Qd1 Kh4",
            "win": -70,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 21:40:12",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000044-1": [
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid5683634",
            "orderIndex": 1,
            "hero": false,
            "dead": "Ad1 3d2 2c3 Kc4",
            "rows": "Kd0 5c4 6s4/5h0 7h1 9h1 Qd3 Qs3/8s0 9s0 Js0 3s2 Ts2",
            "win": 97,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5674822",
            "orderIndex": 0,
            "hero": true,
            "dead": "4s1 Qh2 Kh3 Ks4",
            "rows": "As0 Ah1 Td4/2s0 3c2 4h2 Jh3 7c4/5d0 8d0 Jd0 6d1 Th3",
            "win": -100,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 21:41:38",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000045-1": [
        {
            "inFantasy": false,
            "result": 8,
            "playerName": "pid5683634",
            "orderIndex": 0,
            "hero": false,
            "dead": "Kd1 Qd2 Kc3 Th4",
            "rows": "Ac1 Qs2 Ad4/7s0 8h0 7h1 6c3 7c3/9d0 Jh0 Jd0 Jc2 Qc4",
            "win": 78,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid5674822",
            "orderIndex": 1,
            "hero": true,
            "dead": "4s1 5c2 4d3 6s4",
            "rows": "As2 2c4 2s4/Js0 Tc1 3s2 3h3 Td3/4h0 5h0 6h0 9h0 Qh1",
            "win": -80,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 21:42:54",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000046-1": [
        {
            "inFantasy": true,
            "result": 35,
            "playerName": "pid5683634",
            "orderIndex": 1,
            "hero": false,
            "dead": "As0 Qh1 9h2",
            "rows": "Kh0 Kd0 Kc0/2s0 3d0 4d0 5c0 Ah0/3c0 6c0 7c0 Tc0 Qc0",
            "win": 339,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": false,
            "result": -35,
            "playerName": "pid5674822",
            "orderIndex": 0,
            "hero": true,
            "dead": "7h1 8h2 6h3 Jh4",
            "rows": "Ad2 Ac3 9d4/2h0 2d0 4h0 Jc2 Jd3/9c0 Js0 8s1 Th1 3h4",
            "win": -350,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 21:43:45",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000047-1": [
        {
            "inFantasy": true,
            "result": 28,
            "playerName": "pid5683634",
            "orderIndex": 0,
            "hero": false,
            "dead": "7d0 3c1 4s2",
            "rows": "Kh0 Kd0 Ks0/Td0 Js0 Ad0 Ac0 As0/2h0 2s0 6d0 6c0 6s0",
            "win": 272,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": false,
            "result": -28,
            "playerName": "pid5674822",
            "orderIndex": 1,
            "hero": true,
            "dead": "9d1 7s2 9s3 Jh4",
            "rows": "Qs0 Kc3 Qd4/7h0 2d1 3s1 7c2 3d3/5h0 5c0 Tc0 8d2 8c4",
            "win": -280,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 21:44:32",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000048-1": [
        {
            "inFantasy": true,
            "result": 1,
            "playerName": "pid5683634",
            "orderIndex": 1,
            "hero": false,
            "dead": "3d0 5c1 8s2",
            "rows": "Kh0 Ah0 As0/7d0 7c0 7s0 Jh0 Qd0/4h0 4s0 Th0 Td0 Tc0",
            "win": 10,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": true,
            "result": -1,
            "playerName": "pid5674822",
            "orderIndex": 0,
            "hero": true,
            "dead": "3s0",
            "rows": "Qh0 Qc0 Ad0/5h0 6s0 7h0 8c0 9h0/2h0 2d0 2s0 Jd0 Jc0",
            "win": -10,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 21:45:15",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000049-1": [
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid5683634",
            "orderIndex": 0,
            "hero": false,
            "dead": "6c1 9h2 Qs3 6s4",
            "rows": "Kc0 3s3 9d4/5h0 4c1 4s2 Jh2 Jd4/6d0 7d0 Td0 4d1 Qd3",
            "win": 97,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5674822",
            "orderIndex": 1,
            "hero": true,
            "dead": "Th1 8d2 3d3 Ts4",
            "rows": "Ad0 Js3 9s4/2h1 Qh1 7h2 8h3 5s4/5c0 7c0 Tc0 Qc0 Jc2",
            "win": -100,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 21:46:33",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000050-1": [
        {
            "inFantasy": false,
            "result": 17,
            "playerName": "pid5683634",
            "orderIndex": 1,
            "hero": false,
            "dead": "7h1 Ah2 Tc3 2h4",
            "rows": "Ad0 Ks1 Ac4/3s0 Qd0 4h2 4s2 Qc3/6c0 7d0 5c1 8d3 9s4",
            "win": 165,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid5674822",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ts1 Qh2 Kc3 9d4",
            "rows": "Kd0 Kh1 9h4/2s0 3d0 3c1 As2 2d3/6h0 7s0 Th2 6s3 5d4",
            "win": -170,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 21:47:56",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000051-1": [
        {
            "inFantasy": true,
            "result": 20,
            "playerName": "pid5683634",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jc0 5h1 3c2",
            "rows": "9h0 9d0 9s0/4d0 5d0 6h0 7d0 8d0/Th0 Jh0 Qc0 Kd0 Ad0",
            "win": 67,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid5674822",
            "orderIndex": 1,
            "hero": true,
            "dead": "8s1 6s2 4h3 4c4",
            "rows": "Kh0 Ts4 Js4/Ac0 5s1 Ah2 3d3 8h3/5c0 6c0 8c0 Tc1 2c2",
            "win": -69,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 21:48:53",
    "roomId": "21977242"
}


{
    "stakes": 10,
    "handData": {"210331043904-21977242-0000052-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5683634",
            "orderIndex": 1,
            "hero": false,
            "dead": "7c1 Jh2 Js3 Jd4",
            "rows": "Ah0 As2 Td3/6d0 4s1 9c2 5d4 5s4/Qc0 Qs0 Kd0 Kc1 Ts3",
            "win": -60,
            "playerId": "pid5683634"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5674822",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ks1 6c2 4h3 3s4",
            "rows": "Qh0 Ad2 9h4/3d0 7h1 7d1 2c2 2h3/8c0 8s0 Tc0 8d3 6h4",
            "win": 58,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 21:50:28",
    "roomId": "21977242"
}


