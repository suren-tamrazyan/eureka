{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000054-1": [
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid3182099",
            "orderIndex": 1,
            "hero": false,
            "dead": "9d1 9h2 Js3 3d4",
            "rows": "Kd0 Ks0 Jc3/2c0 5c0 5s2 6c3 8c4/Th0 7h1 7d1 Td2 8h4",
            "win": -2.8,
            "playerId": "pid3182099"
        },
        {
            "inFantasy": false,
            "result": 14,
            "playerName": "pid5679753",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ts1 3h2 3s3 2s4",
            "rows": "Kh0 Kc0 7c4/Ac0 As0 5d2 8d2 2h4/Qd0 6s1 Qh1 4h3 4c3",
            "win": 2.7,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:42:58",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000055-1": [
        {
            "inFantasy": false,
            "result": -28,
            "playerName": "pid3182099",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jh1 3d2 5s3 3s4",
            "rows": "Ah0 Kd2 Jd4/2c0 5d0 5h1 9d3 9h4/6h0 7c0 Th1 6c2 Td3",
            "win": -5.6,
            "playerId": "pid3182099"
        },
        {
            "inFantasy": true,
            "result": 28,
            "playerName": "pid5679753",
            "orderIndex": 1,
            "hero": true,
            "dead": "3c0 2d0",
            "rows": "6d0 Kc0 Ks0/6s0 8s0 9s0 Js0 Qs0/4h0 4c0 Ad0 Ac0 As0",
            "win": 5.4,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:43:35",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000056-1": [
        {
            "inFantasy": false,
            "result": 16,
            "playerName": "pid3182099",
            "orderIndex": 1,
            "hero": false,
            "dead": "3d1 3s2 7c3 2d4",
            "rows": "Kh0 Ah2 Kd3/5d0 6h0 5s2 5c3 4s4/9h0 9d0 8c1 9c1 Tc4",
            "win": 3.1,
            "playerId": "pid3182099"
        },
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid5679753",
            "orderIndex": 0,
            "hero": true,
            "dead": "Js1 7h2 Jd3 Kc4",
            "rows": "Ac0 Ad1 Jh4/2s0 5h0 2c2 3c3 7s4/4h0 4d0 Qd1 Qc2 4c3",
            "win": -3.2,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:44:24",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000057-1": [
        {
            "inFantasy": true,
            "result": 5,
            "playerName": "pid3182099",
            "orderIndex": 0,
            "hero": false,
            "dead": "2h0 7s1",
            "rows": "9c0 Jc0 Js0/2d0 6d0 6c0 8h0 8s0/4h0 4s0 5h0 5d0 5s0",
            "win": 1,
            "playerId": "pid3182099"
        },
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "pid5679753",
            "orderIndex": 1,
            "hero": true,
            "dead": "Ks1 Qh2 7h3 Qs4",
            "rows": "Kh1 Kc1 8d3/5c0 6h0 Ah2 Qd4 Ac4/Tc0 Ts0 Jd0 8c2 Td3",
            "win": -1,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:45:12",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000058-1": [
        {
            "inFantasy": false,
            "result": -25,
            "playerName": "pid3182099",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jh1 8d2 Ah3 7h4",
            "rows": "As0 Ad2 Ks4/4c0 5d1 7d1 3d3 2s4/2h0 2d0 Qh0 Qd2 2c3",
            "win": -5,
            "playerId": "pid3182099"
        },
        {
            "inFantasy": true,
            "result": 25,
            "playerName": "pid5679753",
            "orderIndex": 0,
            "hero": true,
            "dead": "3h0 8s0",
            "rows": "9d0 Th0 Td0/9c0 Tc0 Qc0 Kc0 Ac0/4d0 4s0 5h0 5c0 5s0",
            "win": 4.8,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:46:01",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000059-1": [
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid3182099",
            "orderIndex": 0,
            "hero": false,
            "dead": "4s1 Jh2 Td3 Kc4",
            "rows": "Ks0 3h4 9d4/2s0 3c1 4d2 Qd3 Kh3/7d0 7c0 7s0 9h1 9s2",
            "win": 0.2,
            "playerId": "pid3182099"
        },
        {
            "inFantasy": false,
            "result": -1,
            "playerName": "pid5679753",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qs1 2h2 3d3 8d4",
            "rows": "9c2 As3 8h4/6s0 5s1 Jc2 6h3 5h4/2c0 4c0 6c0 Qc0 8c1",
            "win": -0.2,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:47:29",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000060-1": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid3182099",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qd1 2c2 3c3 7s4",
            "rows": "6s3 As3 Qs4/4d0 Js0 7c1 4s2 Jc4/3h0 9h0 Th0 2h1 6h2",
            "win": -2.4,
            "playerId": "pid3182099"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid5679753",
            "orderIndex": 0,
            "hero": true,
            "dead": "6d1 Tc2 2d3 4c4",
            "rows": "Ac0 Kd2 9s4/Qc0 Td1 Ts1 Jh2 Qh4/8d0 8c0 8s0 3d3 8h3",
            "win": 2.3,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:48:17",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000061-1": [
        {
            "inFantasy": false,
            "result": 4,
            "playerName": "pid3182099",
            "orderIndex": 0,
            "hero": false,
            "dead": "2c1 Tc2 2h3 7d4",
            "rows": "Ks2 Qd3 Qc3/5c0 9s0 5s1 9h4 Qh4/3d0 3s0 Td0 Jc1 Jh2",
            "win": 0.8,
            "playerId": "pid3182099"
        },
        {
            "inFantasy": false,
            "result": -4,
            "playerName": "pid5679753",
            "orderIndex": 1,
            "hero": true,
            "dead": "9d1 5d2 2d3 2s4",
            "rows": "Qs1 6d3 Jd3/3c0 6s0 7c2 7s2 6h4/4h0 Th0 Ah0 8h1 3h4",
            "win": -0.8,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:49:44",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000062-1": [
        {
            "inFantasy": true,
            "result": 24,
            "playerName": "pid3182099",
            "orderIndex": 1,
            "hero": false,
            "dead": "4c0",
            "rows": "9s0 Jc0 Ac0/2h0 2s0 3h0 3d0 3c0/5h0 5c0 5s0 6c0 6s0",
            "win": 4.7,
            "playerId": "pid3182099"
        },
        {
            "inFantasy": false,
            "result": -24,
            "playerName": "pid5679753",
            "orderIndex": 0,
            "hero": true,
            "dead": "7c1 8h2 8s3 Kc4",
            "rows": "Ah1 Kh3 Ks3/2d0 4h0 3s2 Jh4 Qc4/7h0 9c0 Ts0 8c1 Jd2",
            "win": -4.8,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:50:34",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000063-1": [
        {
            "inFantasy": false,
            "result": -11,
            "playerName": "pid3182099",
            "orderIndex": 0,
            "hero": false,
            "dead": "3h1 2d2 3d3 2h4",
            "rows": "Kd1 Qc2 Jc4/4h0 8c0 6h2 8s3 5d4/Ad0 Ac0 As0 Tc1 5c3",
            "win": -2.2,
            "playerId": "pid3182099"
        },
        {
            "inFantasy": false,
            "result": 11,
            "playerName": "pid5679753",
            "orderIndex": 1,
            "hero": true,
            "dead": "8d1 Qh2 3c3 5s4",
            "rows": "Qs0 Kc3 Kh4/6d0 7h0 4d1 7d2 7c3/9h0 9d0 2s1 9c2 Qd4",
            "win": 2.1,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:52:11",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000064-1": [
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid3182099",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qs1 Ac2 Td3 8c4",
            "rows": "Kh0 Kc1 Jh3/5d0 6s0 6d1 4d4 Qd4/2h0 2d0 8h2 8d2 8s3",
            "win": -3.2,
            "playerId": "pid3182099"
        },
        {
            "inFantasy": true,
            "result": 16,
            "playerName": "pid5679753",
            "orderIndex": 0,
            "hero": true,
            "dead": "6h0 4c0",
            "rows": "9d0 9s0 Ah0/7d0 Th0 Ts0 Qh0 Kd0/5c0 5s0 Jd0 Jc0 Js0",
            "win": 3.1,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:52:49",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000065-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid3182099",
            "orderIndex": 0,
            "hero": false,
            "dead": "Kd1 2h2 Qs3 3s4",
            "rows": "Ah0 Qh2 Ts4/6d1 7d1 3d2 4d3 8d3/2c0 4c0 8c0 Tc0 9h4",
            "win": -1.2,
            "playerId": "pid3182099"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5679753",
            "orderIndex": 1,
            "hero": true,
            "dead": "4s1 5s2 8h3 6s4",
            "rows": "Qc1 As1 Kc4/6h0 8s0 5c2 Kh3 Ks3/3h0 Jh0 Jd0 3c2 Th4",
            "win": 1.2,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:54:02",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000066-1": [
        {
            "inFantasy": false,
            "result": 20,
            "playerName": "pid3182099",
            "orderIndex": 1,
            "hero": false,
            "dead": "Ks1 6d2 5c3 4c4",
            "rows": "2d2 Kh3 2s4/3s0 9s0 3d1 3h3 9c4/8d0 8c0 Qc0 Qd1 8s2",
            "win": 3.9,
            "playerId": "pid3182099"
        },
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid5679753",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qs1 7c2 6h3 7s4",
            "rows": "Ac1 Kc3 7h4/4h0 4s0 4d1 9h2 Ts4/8h0 9d0 Th0 7d2 Jd3",
            "win": -4,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:54:59",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000067-1": [
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid3182099",
            "orderIndex": 0,
            "hero": false,
            "dead": "8h1 2d2 6h3 2s4",
            "rows": "Kd0 Ks1 Ts3/4h0 9d0 As1 Ad2 9s4/Jd0 Jc0 3d2 Jh3 Ah4",
            "win": 1,
            "playerId": "pid3182099"
        },
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "pid5679753",
            "orderIndex": 1,
            "hero": true,
            "dead": "4s1 Kh2 8s3 Tc4",
            "rows": "7s1 5d2 Ac4/5h0 Th0 2h2 Qh3 Td4/2c0 7c0 9c0 Kc1 Qc3",
            "win": -1,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:56:39",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000068-1": [
        {
            "inFantasy": true,
            "result": 14,
            "playerName": "pid3182099",
            "orderIndex": 1,
            "hero": false,
            "dead": "6h0 2h1",
            "rows": "9h0 9d0 Ad0/4c0 Th0 Jc0 Js0 Qc0/3s0 6s0 7s0 Ts0 Qs0",
            "win": 2.7,
            "playerId": "pid3182099"
        },
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid5679753",
            "orderIndex": 0,
            "hero": true,
            "dead": "2c1 Qh2 3c3 8c4",
            "rows": "Ac0 9c3 Qd3/4d0 7d0 Jd1 8d2 Td2/9s0 Ks0 5s1 3d4 7c4",
            "win": -2.8,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:57:29",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000069-1": [
        {
            "inFantasy": false,
            "result": 8,
            "playerName": "pid3182099",
            "orderIndex": 0,
            "hero": false,
            "dead": "Js1 8c2 8d3 4c4",
            "rows": "Td2 Kc3 Jc4/Qc0 Qh1 4s2 4h3 7s4/5s0 6c0 7h0 8h0 4d1",
            "win": 1.6,
            "playerId": "pid3182099"
        },
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid5679753",
            "orderIndex": 1,
            "hero": true,
            "dead": "7c1 6d2 Ac3 Ks4",
            "rows": "As0 Kd3 Ah3/2d0 3d0 5h0 2s1 9d4/8s0 Tc1 9s2 Jd2 2h4",
            "win": -1.6,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:58:58",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000070-1": [
        {
            "inFantasy": false,
            "result": -1,
            "playerName": "pid3182099",
            "orderIndex": 1,
            "hero": false,
            "dead": "3c1 5c2 6c3 4c4",
            "rows": "Ad0 9s1 9c4/8d0 Jd0 5d2 5h3 Jc4/Qd0 Qc0 7c1 Qs2 7d3",
            "win": -0.2,
            "playerId": "pid3182099"
        },
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid5679753",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jh1 2c2 Kc3 8c4",
            "rows": "Kd1 2d3 Kh3/3d0 3s0 6h0 5s2 3h4/9h0 Tc0 Ts1 Th2 4h4",
            "win": 0.2,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:59:58",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000071-1": [
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid3182099",
            "orderIndex": 0,
            "hero": false,
            "dead": "2c1 8h2 2d3 Qh4",
            "rows": "As1 Kd2 6h3/5h0 3c1 Jh2 7d3 7h4/2s0 3s0 6s0 8s0 4d4",
            "win": -2.8,
            "playerId": "pid3182099"
        },
        {
            "inFantasy": true,
            "result": 14,
            "playerName": "pid5679753",
            "orderIndex": 1,
            "hero": true,
            "dead": "2h0 5d0",
            "rows": "9h0 9d0 Jd0/6d0 7s0 Th0 Tc0 Qs0/4c0 5c0 7c0 Qc0 Kc0",
            "win": 2.7,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:00:39",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000072-1": [
        {
            "inFantasy": false,
            "result": 20,
            "playerName": "pid3182099",
            "orderIndex": 2,
            "hero": false,
            "dead": "6d1 As2 4h3 3d4",
            "rows": "Ks1 7s3 9s4/Td0 Qh0 Ah2 Kc3 5h4/2c0 8c0 Jc0 Tc1 7c2",
            "win": 3.9,
            "playerId": "pid3182099"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5679753",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jd1 Jh2 4c3 Kh4",
            "rows": "Ad0 Ac2 Kd3/2h0 5d0 6c1 8s4 9d4/3s0 Qs0 4s1 Qd2 4d3",
            "win": -2,
            "playerId": "pid5679753"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid3798060",
            "orderIndex": 1,
            "hero": false,
            "dead": "3h1 6s2 5c3 5s4",
            "rows": "8h3 7d4 Th4/9c1 Qc1 8d2 9h2 7h3/2s0 3c0 6h0 Ts0 Js0",
            "win": -2,
            "playerId": "pid3798060"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:02:06",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000073-1": [
        {
            "inFantasy": false,
            "result": -22,
            "playerName": "pid3182099",
            "orderIndex": 1,
            "hero": false,
            "dead": "4s1 5c2 3c3 4d4",
            "rows": "Ah0 As1 4h2/2c0 6d0 Ac2 4c3 6h4/7s0 Kh0 Kc1 Jc3 Qc4",
            "win": -4.4,
            "playerId": "pid3182099"
        },
        {
            "inFantasy": false,
            "result": 13,
            "playerName": "pid5679753",
            "orderIndex": 2,
            "hero": true,
            "dead": "7d1 9h2 2d3 2h4",
            "rows": "Qd2 3h3 9c4/7c0 7h1 Jh1 6s2 Qs4/Td0 Ts0 Kd0 Ks0 Th3",
            "win": 2.5,
            "playerId": "pid5679753"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "pid3798060",
            "orderIndex": 0,
            "hero": false,
            "dead": "6c1 8h2 8c3 2s4",
            "rows": "Ad2 3d3 3s4/5h0 5d0 9d2 5s3 8d4/8s0 9s0 Tc0 Js1 Qh1",
            "win": 1.7,
            "playerId": "pid3798060"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:03:43",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000074-1": [
        {
            "inFantasy": false,
            "result": -27,
            "playerName": "pid3182099",
            "orderIndex": 0,
            "hero": false,
            "dead": "5d1 5s2 2d3 2c4",
            "rows": "Ad0 As1 8c3/9c0 Td0 6s2 4s4 9d4/Qh0 Kh0 8h1 Kc2 Kd3",
            "win": -5.4,
            "playerId": "pid3182099"
        },
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "pid5679753",
            "orderIndex": 1,
            "hero": true,
            "dead": "Th1 6h2 3c3 7s4",
            "rows": "Ts3 Qd3 7c4/2s0 9h0 2h1 4d2 4h4/4c0 5h0 6c0 8d1 7d2",
            "win": -1.8,
            "playerId": "pid5679753"
        },
        {
            "inFantasy": false,
            "result": 36,
            "playerName": "pid3798060",
            "orderIndex": 2,
            "hero": false,
            "dead": "Ks1 Qc2 6d3 Jh4",
            "rows": "Ah0 Ac1 Qs2/3d0 5c0 3h3 3s3 Js4/7h0 8s0 Tc1 Jc2 9s4",
            "win": 7,
            "playerId": "pid3798060"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:05:33",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000075-1": [
        {
            "inFantasy": false,
            "result": -33,
            "playerName": "pid3182099",
            "orderIndex": 2,
            "hero": false,
            "dead": "9d1 4s2 3d3 3h4",
            "rows": "Ah0 5h3 8c4/2c0 4h0 6d2 6s2 4c4/7s0 8d0 Jd1 Js1 Jc3",
            "win": -6.6,
            "playerId": "pid3182099"
        },
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid5679753",
            "orderIndex": 0,
            "hero": true,
            "dead": "3c1 2d2 7h3 3s4",
            "rows": "Ks2 Ad3 As4/5d0 7d0 5c1 7c1 2h2/9s0 Tc0 Ts0 Qh3 Td4",
            "win": 0.2,
            "playerId": "pid5679753"
        },
        {
            "inFantasy": true,
            "result": 32,
            "playerName": "pid3798060",
            "orderIndex": 1,
            "hero": false,
            "dead": "5s0 4d1 2s2",
            "rows": "9c0 Qc0 Qs0/8s0 9h0 Th0 Jh0 Qd0/6h0 6c0 Kh0 Kd0 Kc0",
            "win": 6.2,
            "playerId": "pid3798060"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:06:59",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000076-1": [
        {
            "inFantasy": false,
            "result": -47,
            "playerName": "pid3182099",
            "orderIndex": 1,
            "hero": false,
            "dead": "7d1 3h2 9c3 6c4",
            "rows": "Ad2 Ac3 As4/2d0 5d0 5s2 Kc3 6d4/4c0 Tc0 Jc0 5c1 7c1",
            "win": -1.1,
            "playerId": "pid3182099"
        },
        {
            "inFantasy": true,
            "result": 67,
            "playerName": "pid5679753",
            "orderIndex": 2,
            "hero": true,
            "dead": "Td0 3s0 9s0",
            "rows": "8h0 8c0 8s0/5h0 7h0 9h0 Kh0 Ah0/4h0 4d0 4s0 Qh0 Qs0",
            "win": 4.9,
            "playerId": "pid5679753"
        },
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid3798060",
            "orderIndex": 0,
            "hero": false,
            "dead": "2s1 7s2 Qd3 2h4",
            "rows": "Ts2 Ks3 Th4/3d0 3c0 8d0 6s1 6h3/Jd0 Qc0 Js1 Jh2 9d4",
            "win": -4,
            "playerId": "pid3798060"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:08:12",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000077-1": [
        {
            "inFantasy": true,
            "result": 26,
            "playerName": "pid5679753",
            "orderIndex": 0,
            "hero": true,
            "dead": "7c0 8d0 Th0",
            "rows": "Kh0 Ks0 Ac0/2d0 2c0 4h0 4d0 4c0/5h0 5c0 Qh0 Qc0 Qs0",
            "win": 5,
            "playerId": "pid5679753"
        },
        {
            "inFantasy": false,
            "result": -26,
            "playerName": "pid3798060",
            "orderIndex": 1,
            "hero": false,
            "dead": "6s1 2s2 4s3 6c4",
            "rows": "As0 7d4 Td4/3h0 5d0 8h2 8s2 5s3/9s0 Jc0 9d1 Jd1 9c3",
            "win": -5.2,
            "playerId": "pid3798060"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:08:43",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000078-1": [
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid3182099",
            "orderIndex": 1,
            "hero": false,
            "dead": "6c1 Jh2 8c3 4s4",
            "rows": "Tc1 Jd4 Ah4/2d0 3h0 3c2 7d3 7s3/5d0 5s0 7h0 Js1 5h2",
            "win": -3.8,
            "playerId": "pid3182099"
        },
        {
            "inFantasy": false,
            "result": 36,
            "playerName": "pid5679753",
            "orderIndex": 2,
            "hero": true,
            "dead": "2h1 Kd2 2c3 Qh4",
            "rows": "Kc0 Kh1 6s2/Qc1 3s2 4h3 4d3 4c4/6d0 7c0 9s0 Th0 8s4",
            "win": 7,
            "playerId": "pid5679753"
        },
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid3798060",
            "orderIndex": 0,
            "hero": false,
            "dead": "3d1 5c2 Ad3 Ac4",
            "rows": "2s0 As2 Qs4/6h0 8d1 Ks2 Td3 Ts3/9h0 Jc0 Qd0 9c1 9d4",
            "win": -3.4,
            "playerId": "pid3798060"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:10:51",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000079-1": [
        {
            "inFantasy": false,
            "result": -36,
            "playerName": "pid3182099",
            "orderIndex": 0,
            "hero": false,
            "dead": "Td1 Qc2 Qh3 2s4",
            "rows": "Ah1 Kd2 Jh4/2c0 3h0 3s0 2h1 4h3/7h0 7s0 9c2 5s3 8h4",
            "win": -7.2,
            "playerId": "pid3182099"
        },
        {
            "inFantasy": true,
            "result": 28,
            "playerName": "pid5679753",
            "orderIndex": 1,
            "hero": true,
            "dead": "6c0 5c0",
            "rows": "Th0 Tc0 Ad0/3c0 4s0 5h0 6h0 7d0/9h0 9d0 Jd0 Jc0 Js0",
            "win": 5.4,
            "playerId": "pid5679753"
        },
        {
            "inFantasy": false,
            "result": 8,
            "playerName": "pid3798060",
            "orderIndex": 2,
            "hero": false,
            "dead": "9s1 2d2 Kc3 7c4",
            "rows": "Ac0 8d4 As4/4d0 4c0 6d0 6s2 5d3/Qd0 8c1 8s1 Ks2 Kh3",
            "win": 1.6,
            "playerId": "pid3798060"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:12:02",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000080-1": [
        {
            "inFantasy": false,
            "result": -32,
            "playerName": "pid3182099",
            "orderIndex": 2,
            "hero": false,
            "dead": "Qs1 5d2 5h3 6s4",
            "rows": "Kc1 Th3 Qc4/7s0 8h0 4h1 7d3 8c4/3h0 3c0 Tc0 9h2 9c2",
            "win": -6.4,
            "playerId": "pid3182099"
        },
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid5679753",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ts1 4c2 2c3 Kd4",
            "rows": "Kh0 Js2 Ad3/2s0 Ah0 2d1 Ac2 7c3/4d0 6c0 7h1 5s4 8s4",
            "win": -2.8,
            "playerId": "pid5679753"
        },
        {
            "inFantasy": true,
            "result": 46,
            "playerName": "pid3798060",
            "orderIndex": 1,
            "hero": false,
            "dead": "2h0 5c1 3d2",
            "rows": "6h0 Jc0 Qh0/3s0 4s0 9s0 Ks0 As0/8d0 9d0 Td0 Jd0 Qd0",
            "win": 8.9,
            "playerId": "pid3798060"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:12:55",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000081-1": [
        {
            "inFantasy": false,
            "result": -35,
            "playerName": "pid3182099",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qh1 8d2 7d3 3s4",
            "rows": "Kh1 8s3 9s3/2c0 4s0 6h2 4c4 8h4/3d0 9d0 Kd0 Jd1 Qd2",
            "win": -2.6,
            "playerId": "pid3182099"
        },
        {
            "inFantasy": false,
            "result": -1,
            "playerName": "pid5679753",
            "orderIndex": 2,
            "hero": true,
            "dead": "2h1 2d2 4d3 Tc4",
            "rows": "Ah0 Ad0 Kc4/7s0 3h1 7c1 7h2 Js3/9c0 Jh0 Ks2 Td3 Qs4",
            "win": -0.2,
            "playerId": "pid5679753"
        },
        {
            "inFantasy": true,
            "result": 36,
            "playerName": "pid3798060",
            "orderIndex": 0,
            "hero": false,
            "dead": "4h0 6d1 2s2",
            "rows": "9h0 Th0 Ts0/3c0 6c0 8c0 Jc0 Qc0/5h0 5d0 5c0 5s0 6s0",
            "win": 2.7,
            "playerId": "pid3798060"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:14:39",
    "roomId": "21938386"
}


{
    "stakes": 0.2,
    "handData": {"210330134954-21938386-0000082-1": [
        {
            "inFantasy": true,
            "result": 7,
            "playerName": "pid5679753",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jc0 2d0 4c0",
            "rows": "Kd0 Ah0 Ac0/3s0 4d0 5d0 6s0 7c0/8d0 8c0 8s0 Td0 Ts0",
            "win": 1.4,
            "playerId": "pid5679753"
        },
        {
            "inFantasy": true,
            "result": -7,
            "playerName": "pid3798060",
            "orderIndex": 1,
            "hero": false,
            "dead": "2c0 2s1 Qd2",
            "rows": "Kh0 Ks0 As0/3h0 4h0 5h0 6h0 7d0/8h0 9d0 Th0 Js0 Qh0",
            "win": -1.4,
            "playerId": "pid3798060"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:16:06",
    "roomId": "21938386"
}


