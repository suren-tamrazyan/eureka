{
    "stakes": 5,
    "handData": {"210330193636-21951147-0000000-1": [
        {
            "inFantasy": false,
            "result": -28,
            "playerName": "pid1118940",
            "orderIndex": 2,
            "hero": false,
            "dead": "5h1 Qc2 8s3 4s4",
            "rows": "Kh0 Kc1 Qh2/6s0 7s0 Ah1 7h2 4h4/3d0 8d0 4d3 Td3 Qd4",
            "win": -140,
            "playerId": "pid1118940"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "pid5689060",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qs1 6h2 6d3 Ks4",
            "rows": "7c2 9s3 9h4/3s0 Js0 Jd1 8h3 Jc4/4c0 5c0 Tc0 8c1 2c2",
            "win": 101.8,
            "playerId": "pid5689060"
        },
        {
            "inFantasy": false,
            "result": 7,
            "playerName": "pid5597356",
            "orderIndex": 1,
            "hero": false,
            "dead": "9d1 5d2 5s3 3h4",
            "rows": "Kd1 Jh2 9c4/3c0 6c0 Ac1 7d2 Ad3/2h0 2s0 Th0 Ts3 2d4",
            "win": 33.9,
            "playerId": "pid5597356"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:02:10",
    "roomId": "21951147"
}


{
    "stakes": 5,
    "handData": {"210330193636-21951147-0000001-1": [
        {
            "inFantasy": false,
            "result": 2,
            "playerName": "pid1118940",
            "orderIndex": 1,
            "hero": false,
            "dead": "9s1 Js2 Qc3 3s4",
            "rows": "Qd1 As3 5s4/4h0 4c0 8s2 Td3 4d4/2c0 7c0 Tc0 Ac1 3c2",
            "win": 9.7,
            "playerId": "pid1118940"
        },
        {
            "inFantasy": false,
            "result": -25,
            "playerName": "pid5689060",
            "orderIndex": 2,
            "hero": true,
            "dead": "6c1 9d2 Th3 5h4",
            "rows": "Ad0 Kh2 Qh3/2h0 3h0 6h1 6s2 Kc3/8d0 Jc0 Jh1 4s4 7s4",
            "win": -125,
            "playerId": "pid5689060"
        },
        {
            "inFantasy": false,
            "result": 23,
            "playerName": "pid5597356",
            "orderIndex": 0,
            "hero": false,
            "dead": "Ts1 5c2 7h3 Ah4",
            "rows": "8c2 Kd4 Ks4/9h0 Qs0 9c1 2d3 2s3/5d0 6d0 7d0 Jd1 3d2",
            "win": 111.5,
            "playerId": "pid5597356"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:04:01",
    "roomId": "21951147"
}


{
    "stakes": 5,
    "handData": {"210330193636-21951147-0000002-1": [
        {
            "inFantasy": false,
            "result": -61,
            "playerName": "pid1118940",
            "orderIndex": 0,
            "hero": false,
            "dead": "8s1 4d2 2s3 3d4",
            "rows": "Kh0 Ah0 Ad2/7c0 Th1 9d2 5c4 8h4/Jd0 Qd0 Js1 4c3 Qh3",
            "win": -305,
            "playerId": "pid1118940"
        },
        {
            "inFantasy": false,
            "result": -37,
            "playerName": "pid5689060",
            "orderIndex": 1,
            "hero": true,
            "dead": "3h1 Qs2 7s3 4h4",
            "rows": "3s3 9s4 As4/2h0 2d0 2c1 7d1 3c3/5s0 7h0 8c0 6h2 9c2",
            "win": -185,
            "playerId": "pid5689060"
        },
        {
            "inFantasy": true,
            "result": 98,
            "playerName": "pid5597356",
            "orderIndex": 2,
            "hero": false,
            "dead": "4s0 8d1",
            "rows": "Ts0 Kd0 Ks0/5h0 5d0 6d0 6c0 6s0/Tc0 Jc0 Qc0 Kc0 Ac0",
            "win": 480,
            "playerId": "pid5597356"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:05:39",
    "roomId": "21951147"
}


{
    "stakes": 5,
    "handData": {"210330193636-21951147-0000003-1": [
        {
            "inFantasy": false,
            "result": 14,
            "playerName": "pid1118940",
            "orderIndex": 2,
            "hero": false,
            "dead": "2c1 6h2 4d3 9s4",
            "rows": "Kd0 Kh1 9h3/3h0 3c0 3d2 Tc2 7s3/8h0 Jh0 Jc1 Th4 Jd4",
            "win": 62.8,
            "playerId": "pid1118940"
        },
        {
            "inFantasy": false,
            "result": -33,
            "playerName": "pid5689060",
            "orderIndex": 0,
            "hero": true,
            "dead": "5c1 3s2 Ts3 4s4",
            "rows": "Ks2 2h3 2s3/6d0 8d1 9d1 6c2 As4/7d0 7c0 Qd0 Qs0 Td4",
            "win": -159.7,
            "playerId": "pid5689060"
        },
        {
            "inFantasy": true,
            "result": 19,
            "playerName": "pid5597356",
            "orderIndex": 1,
            "hero": false,
            "dead": "2d0 4h1",
            "rows": "Qh0 Qc0 Kc0/5h0 Js0 Ah0 Ad0 Ac0/5s0 6s0 7h0 8c0 9c0",
            "win": 92.1,
            "playerId": "pid5597356"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:06:52",
    "roomId": "21951147"
}


{
    "stakes": 5,
    "handData": {"210330193636-21951147-0000004-1": [
        {
            "inFantasy": true,
            "result": 17,
            "playerName": "pid1118940",
            "orderIndex": 1,
            "hero": false,
            "dead": "4h0 4d1",
            "rows": "9c0 Td0 Tc0/5s0 7h0 7s0 8h0 8s0/2d0 2c0 3h0 3c0 3s0",
            "win": 82.4,
            "playerId": "pid1118940"
        },
        {
            "inFantasy": false,
            "result": 16,
            "playerName": "pid5689060",
            "orderIndex": 2,
            "hero": true,
            "dead": "4s1 Qh2 Ks3 Th4",
            "rows": "Kh0 Kc3 Js4/5d0 Ad0 As2 8c3 5h4/9s0 Jc0 Ts1 Qd1 8d2",
            "win": 77.6,
            "playerId": "pid5689060"
        },
        {
            "inFantasy": false,
            "result": -33,
            "playerName": "pid5597356",
            "orderIndex": 0,
            "hero": false,
            "dead": "6c1 7c2 9d3 3d4",
            "rows": "Ah0 Ac1 Qs3/2s0 5c0 6d2 2h3 6s4/9h0 Kd0 Jh1 Qc2 7d4",
            "win": -165,
            "playerId": "pid5597356"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:08:22",
    "roomId": "21951147"
}


{
    "stakes": 5,
    "handData": {"210330193636-21951147-0000005-1": [
        {
            "inFantasy": false,
            "result": -45,
            "playerName": "pid1118940",
            "orderIndex": 0,
            "hero": false,
            "dead": "7d1 2d2 5d3 2h4",
            "rows": "Qc1 Ac2 5c4/5h0 6c0 3s1 3d2 6h3/Th0 Ts0 Jc0 4c3 Td4",
            "win": -209.7,
            "playerId": "pid1118940"
        },
        {
            "inFantasy": true,
            "result": 46,
            "playerName": "pid5689060",
            "orderIndex": 1,
            "hero": true,
            "dead": "7s0 6d0",
            "rows": "Jh0 Js0 Ah0/4h0 4d0 9d0 9c0 9s0/8h0 8d0 Kh0 Kd0 Kc0",
            "win": 203.4,
            "playerId": "pid5689060"
        },
        {
            "inFantasy": false,
            "result": -1,
            "playerName": "pid5597356",
            "orderIndex": 2,
            "hero": false,
            "dead": "2s1 6s2 3c3 2c4",
            "rows": "Ks0 As2 Ad3/7h0 8s0 7c1 8c4 9h4/Qd0 Qs0 4s1 Qh2 Tc3",
            "win": 0,
            "playerId": "pid5597356"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:09:34",
    "roomId": "21951147"
}


{
    "stakes": 5,
    "handData": {"210330193636-21951147-0000006-1": [
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid1118940",
            "orderIndex": 2,
            "hero": false,
            "dead": "5s1 Qd2 6c3 7d4",
            "rows": "2s0 Jh0 Kh1/3h2 5c2 8h3 8d4 Qc4/9h0 9d0 Ah0 9s1 Jc3",
            "win": -0.2,
            "playerId": "pid1118940"
        },
        {
            "inFantasy": false,
            "result": -27,
            "playerName": "pid5689060",
            "orderIndex": 0,
            "hero": true,
            "dead": "6s1 5d2 4s3 Jd4",
            "rows": "Qh1 Qs1 Ad3/2h0 2c0 3d0 4d4 9c4/4h0 Th0 4c2 Td2 Ts3",
            "win": -135,
            "playerId": "pid5689060"
        },
        {
            "inFantasy": true,
            "result": 42,
            "playerName": "pid5597356",
            "orderIndex": 1,
            "hero": false,
            "dead": "8c0 5h1 2d2",
            "rows": "Js0 Ac0 As0/6h0 6d0 7h0 7s0 Tc0/3c0 3s0 Kd0 Kc0 Ks0",
            "win": 131.1,
            "playerId": "pid5597356"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:10:49",
    "roomId": "21951147"
}


{
    "stakes": 5,
    "handData": {"210330193636-21951147-0000007-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5526050",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jh1 Jc2 Qc3 Qs4",
            "rows": "As0 Kc1 Kh3/4s0 7d0 5h1 5s3 Qd4/Th0 Ts0 2c2 6h2 5c4",
            "win": -30,
            "playerId": "pid5526050"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5689060",
            "orderIndex": 0,
            "hero": true,
            "dead": "Tc1 3c2 7c3 4c4",
            "rows": "Ks0 Ad3 9c4/6s0 5d1 3d2 6c2 9h4/8d0 8s0 Jd0 8c1 9d3",
            "win": 29.1,
            "playerId": "pid5689060"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:12:12",
    "roomId": "21951147"
}


{
    "stakes": 5,
    "handData": {"210330193636-21951147-0000008-1": [
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid5526050",
            "orderIndex": 1,
            "hero": false,
            "dead": "2c1 2d2 3s3 4h4",
            "rows": "5c2 Ad3 8c4/9d0 Jh0 Qc1 9s3 7d4/6s0 Qs0 Ks0 Ts1 5s2",
            "win": 4.8,
            "playerId": "pid5526050"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "pid5689060",
            "orderIndex": 2,
            "hero": true,
            "dead": "5h1 7s2 Th3 4s4",
            "rows": "As2 Qh4 Kd4/Td0 Qd0 6d1 8d2 4d3/9c0 Tc0 Kc0 4c1 Jc3",
            "win": 130.9,
            "playerId": "pid5689060"
        },
        {
            "inFantasy": false,
            "result": -28,
            "playerName": "pid5621024",
            "orderIndex": 0,
            "hero": false,
            "dead": "Js1 8h2 6h3 Kh4",
            "rows": "Ac2 Jd3 Ah4/3d0 2h1 2s1 3h2 7h3/6c0 7c0 8s0 9h0 3c4",
            "win": -140,
            "playerId": "pid5621024"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:14:04",
    "roomId": "21951147"
}


{
    "stakes": 5,
    "handData": {"210330193636-21951147-0000009-1": [
        {
            "inFantasy": false,
            "result": 13,
            "playerName": "pid5526050",
            "orderIndex": 0,
            "hero": false,
            "dead": "5c1 Qh2 Kd3 3s4",
            "rows": "Qc3 8c4 Qd4/7s0 8h0 7h1 Tc1 Td3/2d0 3d0 6d0 2h2 2s2",
            "win": 63,
            "playerId": "pid5526050"
        },
        {
            "inFantasy": false,
            "result": 14,
            "playerName": "pid5689060",
            "orderIndex": 1,
            "hero": true,
            "dead": "5d1 9h2 6s3 4d4",
            "rows": "Jc3 9s4 Jd4/2c0 Ah0 Ad0 8d2 Ts3/5h0 6h0 3c1 4s1 7d2",
            "win": 67.9,
            "playerId": "pid5689060"
        },
        {
            "inFantasy": false,
            "result": -27,
            "playerName": "pid5621024",
            "orderIndex": 2,
            "hero": false,
            "dead": "8s1 Jh2 Kc3 3h4",
            "rows": "As0 Ac1 7c4/9d0 Ks1 Kh2 9c3 Qs3/4h0 5s0 6c0 4c2 Js4",
            "win": -135,
            "playerId": "pid5621024"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:15:59",
    "roomId": "21951147"
}


{
    "stakes": 5,
    "handData": {"210330193636-21951147-0000010-1": [
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "pid5526050",
            "orderIndex": 2,
            "hero": false,
            "dead": "6c0",
            "rows": "7c0 Td0 Kh0/2h0 2c0 2s0 Jd0 Js0/9h0 9s0 Qd0 Qc0 Qs0",
            "win": 145.5,
            "playerId": "pid5526050"
        },
        {
            "inFantasy": false,
            "result": -4,
            "playerName": "pid5689060",
            "orderIndex": 0,
            "hero": true,
            "dead": "As1 Ah2 4h3 3c4",
            "rows": "Kc0 Kd1 5h3/5c0 5s0 4c1 4d2 8h3/6h0 6d0 Tc2 3d4 Ts4",
            "win": -20,
            "playerId": "pid5689060"
        },
        {
            "inFantasy": false,
            "result": -26,
            "playerName": "pid5621024",
            "orderIndex": 1,
            "hero": false,
            "dead": "5d1 Th2 4s3 3s4",
            "rows": "Qh1 Ad2 8s4/8d0 Jc0 3h1 8c2 Jh3/7h0 7d0 7s0 2d3 6s4",
            "win": -130,
            "playerId": "pid5621024"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:17:18",
    "roomId": "21951147"
}


{
    "stakes": 5,
    "handData": {"210330193636-21951147-0000011-1": [
        {
            "inFantasy": false,
            "result": -42,
            "playerName": "pid5526050",
            "orderIndex": 1,
            "hero": false,
            "dead": "5s1 Qc2 3h3 3d4",
            "rows": "Ac1 As3 Kh4/2s0 4c0 6d0 6c2 6s3/9c0 Th0 8c1 9s2 7s4",
            "win": -210,
            "playerId": "pid5526050"
        },
        {
            "inFantasy": true,
            "result": 42,
            "playerName": "pid5689060",
            "orderIndex": 2,
            "hero": true,
            "dead": "4s0 2c0",
            "rows": "Kd0 Ks0 Ad0/2d0 4d0 5d0 Td0 Qd0/2h0 5h0 7h0 8h0 Ah0",
            "win": 203.7,
            "playerId": "pid5689060"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5621024",
            "orderIndex": 0,
            "hero": false,
            "dead": "4h1 6h2 Ts3 Jh4",
            "rows": "Jd1 Js3 9d4/Qs0 Qh1 3s2 8d2 8s3/3c0 5c0 7c0 Tc0 Jc4",
            "win": 0,
            "playerId": "pid5621024"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:18:38",
    "roomId": "21951147"
}


{
    "stakes": 5,
    "handData": {"210330193636-21951147-0000012-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5526050",
            "orderIndex": 1,
            "hero": false,
            "dead": "6d1 5c2 Td3 4d4",
            "rows": "Ks0 8s4 Jh4/4c0 Jc0 8c1 2c2 2s3/5h0 8h0 6h1 7h2 Th3",
            "win": -30,
            "playerId": "pid5526050"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5689060",
            "orderIndex": 0,
            "hero": true,
            "dead": "Js1 3c2 7s3 2h4",
            "rows": "Ac0 As0 7c4/3d0 3s1 5s2 9c2 9h3/Tc0 Qs0 Qh1 Qc3 4s4",
            "win": 29.1,
            "playerId": "pid5689060"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:19:46",
    "roomId": "21951147"
}


{
    "stakes": 5,
    "handData": {"210330193636-21951147-0000013-1": [
        {
            "inFantasy": false,
            "result": -32,
            "playerName": "pid5526050",
            "orderIndex": 0,
            "hero": false,
            "dead": "6s1 Qc2 Jh3 5h4",
            "rows": "Ac0 Ah1 Qs4/2s0 6h0 6c1 3h2 3c2/8s0 9s0 7h3 9h3 5s4",
            "win": -160,
            "playerId": "pid5526050"
        },
        {
            "inFantasy": true,
            "result": 32,
            "playerName": "pid5689060",
            "orderIndex": 1,
            "hero": true,
            "dead": "2h0 Kh0 4h0",
            "rows": "Th0 Td0 Ts0/5c0 6d0 7c0 8d0 9c0/2d0 4d0 5d0 Jd0 Kd0",
            "win": 155.2,
            "playerId": "pid5689060"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:20:23",
    "roomId": "21951147"
}


{
    "stakes": 5,
    "handData": {"210330193636-21951147-0000014-1": [
        {
            "inFantasy": false,
            "result": -13,
            "playerName": "pid5526050",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jc1 7h2 Jd3 4d4",
            "rows": "Qs1 7s3 Jh4/4s0 6c0 8s0 7d3 5s4/9h0 Th0 9c1 9d2 Tc2",
            "win": -65,
            "playerId": "pid5526050"
        },
        {
            "inFantasy": true,
            "result": 13,
            "playerName": "pid5689060",
            "orderIndex": 0,
            "hero": true,
            "dead": "5h0 6s0 7c0",
            "rows": "8h0 8d0 8c0/Ts0 Ks0 Ah0 Ad0 Ac0/2h0 2d0 3d0 3c0 3s0",
            "win": 63,
            "playerId": "pid5689060"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:21:02",
    "roomId": "21951147"
}


{
    "stakes": 5,
    "handData": {"210330193636-21951147-0000015-1": [
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "pid5526050",
            "orderIndex": 0,
            "hero": false,
            "dead": "9s1 Td2 3d3 7h4",
            "rows": "Ac0 5s3 Kc4/4c0 4s0 2h2 7c2 2s3/8h0 Th0 7d1 9h1 Jc4",
            "win": -105,
            "playerId": "pid5526050"
        },
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "pid5689060",
            "orderIndex": 1,
            "hero": true,
            "dead": "3h0 3s0 Tc0",
            "rows": "Jh0 Ah0 As0/4h0 5d0 6s0 7s0 8c0/2d0 4d0 8d0 Kd0 Ad0",
            "win": 101.8,
            "playerId": "pid5689060"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:21:52",
    "roomId": "21951147"
}


{
    "stakes": 5,
    "handData": {"210330193636-21951147-0000016-1": [
        {
            "inFantasy": false,
            "result": 11,
            "playerName": "pid5526050",
            "orderIndex": 2,
            "hero": false,
            "dead": "4h1 7h2 8s3 4s4",
            "rows": "9s1 Td4 Ah4/7s0 Jh0 Jd1 5s2 Js3/4c0 8c0 Ac0 7c2 Jc3",
            "win": 53.3,
            "playerId": "pid5526050"
        },
        {
            "inFantasy": false,
            "result": -26,
            "playerName": "pid5689060",
            "orderIndex": 0,
            "hero": true,
            "dead": "9c1 Kd2 5c3 3h4",
            "rows": "Ad0 7d3 6c4/3d0 Qs0 Tc1 Ts1 4d4/8h0 9h0 2d2 2c2 9d3",
            "win": -130,
            "playerId": "pid5689060"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "pid1251760",
            "orderIndex": 1,
            "hero": false,
            "dead": "2h1 Kc2 2s3 5h4",
            "rows": "Ks0 As0 Kh2/3s0 3c1 5d3 6s3 6d4/8d0 Th0 Qh1 Qd2 Qc4",
            "win": 72.7,
            "playerId": "pid1251760"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:23:22",
    "roomId": "21951147"
}


{
    "stakes": 5,
    "handData": {"210330193636-21951147-0000017-1": [
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5526050",
            "orderIndex": 1,
            "hero": false,
            "dead": "2h1 5h2 2s3 4s4",
            "rows": "2c2 3s2 Th4/9s0 Ts0 Jh0 Qh1 Kc3/2d0 5d0 Kd1 Ad3 8d4",
            "win": -50,
            "playerId": "pid5526050"
        },
        {
            "inFantasy": false,
            "result": -30,
            "playerName": "pid5689060",
            "orderIndex": 2,
            "hero": true,
            "dead": "Jd1 Ks2 6c3 7s4",
            "rows": "Ah0 Qs3 Jc4/3c0 4h0 4c0 3h2 6h3/8h0 6d1 7d1 5c2 4d4",
            "win": -150,
            "playerId": "pid5689060"
        },
        {
            "inFantasy": true,
            "result": 40,
            "playerName": "pid1251760",
            "orderIndex": 0,
            "hero": false,
            "dead": "3d0 8c1",
            "rows": "Td0 Tc0 Qc0/5s0 6s0 8s0 Js0 As0/7h0 7c0 9h0 9d0 9c0",
            "win": 194,
            "playerId": "pid1251760"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:24:46",
    "roomId": "21951147"
}


{
    "stakes": 5,
    "handData": {"210330193636-21951147-0000018-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5526050",
            "orderIndex": 0,
            "hero": false,
            "dead": "Kh1 9c2 5c3 5s4",
            "rows": "As2 Th3 Qc3/3c0 4h0 6h1 6c2 9d4/5d0 Jd0 Kd0 8d1 Td4",
            "win": 0,
            "playerId": "pid5526050"
        },
        {
            "inFantasy": false,
            "result": 19,
            "playerName": "pid5689060",
            "orderIndex": 1,
            "hero": true,
            "dead": "4s1 2h2 3d3 2c4",
            "rows": "Kc0 Ks0 8c4/Jh0 Ad0 Qh2 Jc3 Qd3/6s0 7d1 9h1 7s2 7h4",
            "win": 92.1,
            "playerId": "pid5689060"
        },
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid1251760",
            "orderIndex": 2,
            "hero": false,
            "dead": "Qs1 3h2 6d3 3s4",
            "rows": "Ac1 7c2 Js4/8s0 8h1 9s2 Ah3 Tc4/2d0 4d0 4c0 5h0 2s3",
            "win": -95,
            "playerId": "pid1251760"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:26:41",
    "roomId": "21951147"
}


{
    "stakes": 5,
    "handData": {"210330193636-21951147-0000019-1": [
        {
            "inFantasy": false,
            "result": -29,
            "playerName": "pid5526050",
            "orderIndex": 2,
            "hero": false,
            "dead": "5s1 4s2 2s3 Kh4",
            "rows": "Kd0 Ks0 Ac2/3h0 4h1 As1 Ad2 3s4/9h0 Td0 6h3 7d3 Th4",
            "win": -145,
            "playerId": "pid5526050"
        },
        {
            "inFantasy": true,
            "result": 34,
            "playerName": "pid5689060",
            "orderIndex": 0,
            "hero": true,
            "dead": "8s0 Js0",
            "rows": "6d0 6s0 Qd0/2c0 5c0 6c0 7c0 9c0/5h0 8h0 Jh0 Qh0 Ah0",
            "win": 164.9,
            "playerId": "pid5689060"
        },
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "pid1251760",
            "orderIndex": 1,
            "hero": false,
            "dead": "3c1 7h2 8c3 2d4",
            "rows": "Kc0 9s2 2h4/Ts0 4c1 Qc1 Jc3 Qs3/4d0 5d0 9d0 3d2 8d4",
            "win": -25,
            "playerId": "pid1251760"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:28:15",
    "roomId": "21951147"
}


{
    "stakes": 5,
    "handData": {"210330193636-21951147-0000020-1": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid5526050",
            "orderIndex": 1,
            "hero": false,
            "dead": "8d1 Tc2 Js3 4d4",
            "rows": "Ts1 Ks2 Qh4/2h0 3h0 3s0 6s2 6d3/4h0 9c0 4c1 Jh3 4s4",
            "win": 58.2,
            "playerId": "pid5526050"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5689060",
            "orderIndex": 2,
            "hero": true,
            "dead": "9h1 2d2 As3 Kc4",
            "rows": "Qc0 Qs2 Jc4/2c0 5h0 2s1 6h1 5d2/7d0 Td0 6c3 9s3 5s4",
            "win": -30,
            "playerId": "pid5689060"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid1251760",
            "orderIndex": 0,
            "hero": false,
            "dead": "7c1 8s2 Kh3 Qd4",
            "rows": "Ah0 Kd1 Ad3/5c0 8c0 8h1 7h2 7s4/3d0 3c0 Jd2 9d3 Ac4",
            "win": -30,
            "playerId": "pid1251760"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:30:31",
    "roomId": "21951147"
}


{
    "stakes": 5,
    "handData": {"210330193636-21951147-0000021-1": [
        {
            "inFantasy": false,
            "result": -39,
            "playerName": "pid5526050",
            "orderIndex": 0,
            "hero": false,
            "dead": "Ks1 2d2 7h3 Kh4",
            "rows": "As0 9d2 6c4/4d0 4c0 4h1 3s2 5h3/8c0 Tc0 Th1 8d3 5d4",
            "win": -195,
            "playerId": "pid5526050"
        },
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid5689060",
            "orderIndex": 1,
            "hero": true,
            "dead": "4s1 Jc2 3d3 3c4",
            "rows": "2s1 5s3 9c4/3h0 6h0 Jh2 Ah3 Js4/7d0 Kd0 Ad0 6d1 Qd2",
            "win": -75,
            "playerId": "pid5689060"
        },
        {
            "inFantasy": false,
            "result": 54,
            "playerName": "pid1251760",
            "orderIndex": 2,
            "hero": false,
            "dead": "Td1 Jd2 8h3 2h4",
            "rows": "Ac1 9h4 Qh4/2c0 7c0 Qc1 Kc2 5c3/6s0 7s0 9s0 8s2 Ts3",
            "win": 261.9,
            "playerId": "pid1251760"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:32:24",
    "roomId": "21951147"
}


{
    "stakes": 5,
    "handData": {"210330193636-21951147-0000022-1": [
        {
            "inFantasy": false,
            "result": 7,
            "playerName": "pid5689060",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jc1 7d2 5h3 Ts4",
            "rows": "9s3 Jd4 Kh4/2h0 4d0 3h1 3d2 3c2/4s0 6s0 8s0 As1 3s3",
            "win": 33.9,
            "playerId": "pid5689060"
        },
        {
            "inFantasy": false,
            "result": -7,
            "playerName": "pid1251760",
            "orderIndex": 0,
            "hero": false,
            "dead": "2c1 4h2 4c3 6h4",
            "rows": "Kd0 Ac1 Qc4/5d0 5s1 Tc2 Kc3 Ks3/8h0 8c0 9c0 8d2 6d4",
            "win": -35,
            "playerId": "pid1251760"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:33:32",
    "roomId": "21951147"
}


{
    "stakes": 5,
    "handData": {"210330193636-21951147-0000023-1": [
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid5689060",
            "orderIndex": 0,
            "hero": true,
            "dead": "Tc1 Qs2 6c3 2d4",
            "rows": "Kc0 9c3 Kh4/4h0 5s1 7c1 6d2 8s4/5d0 7d0 Qd0 Ad2 Jd3",
            "win": 24.2,
            "playerId": "pid5689060"
        },
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "pid1251760",
            "orderIndex": 1,
            "hero": false,
            "dead": "8d1 2c2 5c3 7h4",
            "rows": "3c2 Jc3 Ks4/3s0 6s0 2s1 7s1 9s4/2h0 Jh0 Ah0 6h2 5h3",
            "win": -25,
            "playerId": "pid1251760"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:34:19",
    "roomId": "21951147"
}


{
    "stakes": 5,
    "handData": {"210330193636-21951147-0000024-1": [
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "pid5689060",
            "orderIndex": 1,
            "hero": true,
            "dead": "4h0 3h0",
            "rows": "Qd0 Qs0 Ks0/7h0 7c0 9d0 Th0 Ts0/5c0 5s0 8h0 8d0 8c0",
            "win": 29.1,
            "playerId": "pid5689060"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid1251760",
            "orderIndex": 0,
            "hero": false,
            "dead": "2s1 7d2 6s3 Kc4",
            "rows": "Kh0 Kd0 4c4/6h0 Ad1 7s2 Ah2 8s3/Tc0 Jd0 Jc1 9h3 Js4",
            "win": -30,
            "playerId": "pid1251760"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:34:51",
    "roomId": "21951147"
}


{
    "stakes": 5,
    "handData": {"210330193636-21951147-0000025-1": [
        {
            "inFantasy": false,
            "result": -7,
            "playerName": "pid5689060",
            "orderIndex": 0,
            "hero": true,
            "dead": "7s1 7d2 6c3 8d4",
            "rows": "Ad0 Ac0 Ks4/6s0 6h1 6d3 Th3 9c4/2c0 Qc0 2h1 2d2 Qd2",
            "win": -35,
            "playerId": "pid5689060"
        },
        {
            "inFantasy": true,
            "result": 7,
            "playerName": "pid1251760",
            "orderIndex": 1,
            "hero": false,
            "dead": "8h0 9s1",
            "rows": "Jc0 Ah0 As0/7h0 9h0 Jh0 Qh0 Kh0/3d0 3c0 3s0 4d0 4s0",
            "win": 33.9,
            "playerId": "pid1251760"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:35:39",
    "roomId": "21951147"
}


{
    "stakes": 5,
    "handData": {"210330193636-21951147-0000026-1": [
        {
            "inFantasy": true,
            "result": 38,
            "playerName": "pid5689060",
            "orderIndex": 1,
            "hero": true,
            "dead": "9s0 3s0 4c0",
            "rows": "Ah0 Ad0 As0/3d0 4h0 5c0 6s0 7d0/Jd0 Js0 Kh0 Kd0 Kc0",
            "win": 184.3,
            "playerId": "pid5689060"
        },
        {
            "inFantasy": false,
            "result": -38,
            "playerName": "pid1251760",
            "orderIndex": 0,
            "hero": false,
            "dead": "7c1 6c2 2s3 2d4",
            "rows": "9d2 Ac2 6d3/3h0 Tc0 8s1 Td1 5d3/Jc0 Qh0 Qd0 5s4 6h4",
            "win": -190,
            "playerId": "pid1251760"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:36:08",
    "roomId": "21951147"
}


{
    "stakes": 5,
    "handData": {"210330193636-21951147-0000027-1": [
        {
            "inFantasy": true,
            "result": 19,
            "playerName": "pid5689060",
            "orderIndex": 0,
            "hero": true,
            "dead": "7h0 3s0 3c0",
            "rows": "8d0 8s0 Ts0/Th0 Jh0 Qs0 Kc0 Ah0/4h0 4d0 4s0 5d0 5c0",
            "win": 92.1,
            "playerId": "pid5689060"
        },
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid1251760",
            "orderIndex": 1,
            "hero": false,
            "dead": "9s1 Js2 3d3 2h4",
            "rows": "Ad0 Jc3 Td4/2c0 6c0 2d1 7s3 Ac4/8h0 Kh0 9h1 8c2 9d2",
            "win": -95,
            "playerId": "pid1251760"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:36:35",
    "roomId": "21951147"
}


{
    "stakes": 5,
    "handData": {"210330193636-21951147-0000028-1": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid1118940",
            "orderIndex": 1,
            "hero": false,
            "dead": "7d1 2c2 3d3 2h4",
            "rows": "Kd1 Ac2 Jd4/Ts0 8c1 4h2 4c3 3s4/9h0 9d0 Jh0 Jc0 3c3",
            "win": 58.2,
            "playerId": "pid1118940"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5689060",
            "orderIndex": 2,
            "hero": true,
            "dead": "5s1 8s2 Js3 Tc4",
            "rows": "Qc0 Qs1 Kc2/2s0 4d0 5c1 As3 Td4/3h0 6h0 6d2 7s3 6s4",
            "win": -30,
            "playerId": "pid5689060"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid1251760",
            "orderIndex": 0,
            "hero": false,
            "dead": "8h1 7h2 9c3 Ah4",
            "rows": "Ks0 Ad0 Kh1/Qh1 Qd2 2d3 5h3 5d4/7c0 8d0 9s0 Th2 4s4",
            "win": -30,
            "playerId": "pid1251760"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:38:16",
    "roomId": "21951147"
}


