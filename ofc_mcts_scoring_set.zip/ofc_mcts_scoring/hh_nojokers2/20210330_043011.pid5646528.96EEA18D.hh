{
    "stakes": 1,
    "handData": {"210330023644-21903504-0000000-1": [
        {
            "inFantasy": false,
            "result": -7,
            "playerName": "pid1277366",
            "orderIndex": 1,
            "hero": false,
            "dead": "6c1 7c2 Td3 9c4",
            "rows": "Ac2 6s3 Jh4/2h0 8d1 2s2 Qc3 Ad4/5s0 7s0 Js0 Ks0 4s1",
            "win": -7,
            "playerId": "pid1277366"
        },
        {
            "inFantasy": false,
            "result": 7,
            "playerName": "pid5646528",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qh1 5c2 As3 9d4",
            "rows": "Kc0 Kh1 Ah4/3d0 3s0 Th3 Ts3 8s4/6d0 7h0 8c1 9s2 Tc2",
            "win": 6.8,
            "playerId": "pid5646528"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "898406",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:30:11",
    "roomId": "21903504"
}


{
    "stakes": 1,
    "handData": {"210330023644-21903504-0000001-1": [
        {
            "inFantasy": false,
            "result": -4,
            "playerName": "pid1277366",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qs1 2c2 8s3 2d4",
            "rows": "Ad0 Ah1 3c4/5s0 6h0 3h2 6c3 6s4/8c0 9c0 Ts1 7c2 Jc3",
            "win": -4,
            "playerId": "pid1277366"
        },
        {
            "inFantasy": true,
            "result": 4,
            "playerName": "pid5646528",
            "orderIndex": 1,
            "hero": true,
            "dead": "7s0 4s0",
            "rows": "Jh0 Kc0 Ks0/2s0 3s0 4h0 5h0 Ac0/3d0 5d0 7d0 9d0 Jd0",
            "win": 3.9,
            "playerId": "pid5646528"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "898406",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:30:49",
    "roomId": "21903504"
}


{
    "stakes": 1,
    "handData": {"210330023644-21903504-0000002-1": [
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "pid1277366",
            "orderIndex": 1,
            "hero": false,
            "dead": "4h0 5s1 6s2",
            "rows": "8d0 Ac0 As0/8h0 9d0 Td0 Js0 Qd0/2c0 3c0 7c0 9c0 Kc0",
            "win": 20.4,
            "playerId": "pid1277366"
        },
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "pid5646528",
            "orderIndex": 0,
            "hero": true,
            "dead": "5c1 4d2 4s3 3s4",
            "rows": "Qh3 4c4 Jc4/2d0 6c0 2h1 5d2 6d2/9h0 Ts0 Jd0 7d1 8s3",
            "win": -21,
            "playerId": "pid5646528"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "898406",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:32:37",
    "roomId": "21903504"
}


