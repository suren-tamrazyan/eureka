{
    "stakes": 10,
    "handData": {"210330060030-21914126-0000019-1": [
        {
            "inFantasy": false,
            "result": 4,
            "playerName": "pid5172376",
            "orderIndex": 1,
            "hero": false,
            "dead": "8c1 9s2 Ah3 2d4",
            "rows": "Kc0 Kh2 3d4/7h0 8d1 6s3 7s3 6d4/5d0 5c0 Qs0 Qc1 Qd2",
            "win": 39,
            "playerId": "pid5172376"
        },
        {
            "inFantasy": false,
            "result": -4,
            "playerName": "pid5682370",
            "orderIndex": 0,
            "hero": false,
            "dead": "7d1 4c2 9d3 5h4",
            "rows": "Ac0 As1 5s4/Tc0 Ts0 3s2 9h2 9c3/Jc0 Qh0 Jh1 Jd3 6c4",
            "win": -40,
            "playerId": "pid5682370"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": false,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:55:03",
    "roomId": "21914126"
}


{
    "stakes": 10,
    "handData": {"210330060030-21914126-0000020-1": [
        {
            "inFantasy": true,
            "result": 17,
            "playerName": "pid5172376",
            "orderIndex": 0,
            "hero": false,
            "dead": "Kc0 3s1",
            "rows": "9d0 9c0 Ac0/2d0 2c0 2s0 4h0 4d0/7h0 7d0 Jh0 Jd0 Jc0",
            "win": 165,
            "playerId": "pid5172376"
        },
        {
            "inFantasy": true,
            "result": -17,
            "playerName": "pid5682370",
            "orderIndex": 1,
            "hero": false,
            "dead": "2h0 3h1 7s2",
            "rows": "6h0 6d0 Ah0/Td0 Js0 Qc0 Ks0 Ad0/5d0 5c0 8h0 8c0 8s0",
            "win": -170,
            "playerId": "pid5682370"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": false,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:55:37",
    "roomId": "21914126"
}


{
    "stakes": 10,
    "handData": {"210330060030-21914126-0000021-1": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5682370",
            "orderIndex": 1,
            "hero": false,
            "dead": "2d1 9d2 4s3 5h4",
            "rows": "As0 Qd3 7s4/5d0 7d0 5c1 Tc2 Ts3/Jd0 Js0 Kh1 8s2 Jc4",
            "win": 58,
            "playerId": "pid5682370"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5684417",
            "orderIndex": 0,
            "hero": true,
            "dead": "5s1 7c2 4h3 8c4",
            "rows": "Jh1 Kc2 3d4/4c0 6h0 9s1 6s2 9h3/2h0 2s0 Qs0 Th3 3h4",
            "win": -60,
            "playerId": "pid5684417"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:56:56",
    "roomId": "21914126"
}


{
    "stakes": 10,
    "handData": {"210330060030-21914126-0000022-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5682370",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jh1 9c2 6h3 5s4",
            "rows": "Qh0 Jc2 Qs4/9s0 Kd0 Kc0 7d2 Jd4/5d0 2s1 4c1 3s3 6c3",
            "win": 0,
            "playerId": "pid5682370"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5684417",
            "orderIndex": 1,
            "hero": true,
            "dead": "Js1 5c2 3d3 4s4",
            "rows": "3c2 8d3 Ac3/7s0 8s0 9d1 Tc1 6d4/4h0 5h0 Kh0 9h2 Ah4",
            "win": 0,
            "playerId": "pid5684417"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:58:22",
    "roomId": "21914126"
}


{
    "stakes": 10,
    "handData": {"210330060030-21914126-0000023-1": [
        {
            "inFantasy": true,
            "result": -5,
            "playerName": "pid5682370",
            "orderIndex": 1,
            "hero": false,
            "dead": "3h0",
            "rows": "4h0 4d0 9d0/5c0 7h0 7d0 Tc0 Kh0/2s0 3s0 6s0 Js0 As0",
            "win": -50,
            "playerId": "pid5682370"
        },
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid5684417",
            "orderIndex": 0,
            "hero": true,
            "dead": "Th1 5d2 6c3 8s4",
            "rows": "Kc1 Kd2 8h4/3d0 3c0 Jh0 8d3 Jc3/7s0 Qs0 9s1 Qc2 Qh4",
            "win": 48,
            "playerId": "pid5684417"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:59:09",
    "roomId": "21914126"
}


{
    "stakes": 10,
    "handData": {"210330060030-21914126-0000024-1": [
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "pid5682370",
            "orderIndex": 0,
            "hero": false,
            "dead": "7c1 4h2 3d3 5s4",
            "rows": "Kh0 Qs2 Qd3/8s0 2s1 5c1 As2 3h4/6h0 6s0 Jd0 9s3 Td4",
            "win": -210,
            "playerId": "pid5682370"
        },
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "pid5684417",
            "orderIndex": 1,
            "hero": true,
            "dead": "5d0 Ts0",
            "rows": "Ks0 Ad0 Ac0/2h0 3s0 4c0 5h0 Ah0/8c0 9c0 Th0 Jh0 Qh0",
            "win": 204,
            "playerId": "pid5684417"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 23:59:54",
    "roomId": "21914126"
}


{
    "stakes": 10,
    "handData": {"210330060030-21914126-0000025-1": [
        {
            "inFantasy": false,
            "result": 4,
            "playerName": "pid5682370",
            "orderIndex": 1,
            "hero": false,
            "dead": "7h1 Ts2 2s3 Jc4",
            "rows": "Ad0 Ac2 8s4/5s0 8c0 6c1 Ah3 As3/Qd0 Qs0 3c1 3d2 9s4",
            "win": 39,
            "playerId": "pid5682370"
        },
        {
            "inFantasy": false,
            "result": -4,
            "playerName": "pid5684417",
            "orderIndex": 0,
            "hero": true,
            "dead": "6s1 5c2 6d3 Js4",
            "rows": "Kc2 Jh3 8d4/7s0 2c1 7c1 9h3 Kd4/4c0 4s0 Th0 Td0 4d2",
            "win": -40,
            "playerId": "pid5684417"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:01:19",
    "roomId": "21914126"
}


{
    "stakes": 10,
    "handData": {"210330060030-21914126-0000026-1": [
        {
            "inFantasy": true,
            "result": 8,
            "playerName": "pid5682370",
            "orderIndex": 0,
            "hero": false,
            "dead": "8s0 Th1 9s2",
            "rows": "Kd0 Ks0 Ac0/2h0 3c0 4h0 5s0 6d0/2d0 5d0 7d0 8d0 Td0",
            "win": 78,
            "playerId": "pid5682370"
        },
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid5684417",
            "orderIndex": 1,
            "hero": true,
            "dead": "Js1 3d2 6c3 Jc4",
            "rows": "As0 Ad1 Qc4/9h0 6s1 6h2 9d2 Jd3/Qh0 Qs0 Kh0 8h3 Qd4",
            "win": -80,
            "playerId": "pid5684417"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:02:06",
    "roomId": "21914126"
}


{
    "stakes": 10,
    "handData": {"210330060030-21914126-0000027-1": [
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "pid5682370",
            "orderIndex": 1,
            "hero": false,
            "dead": "6h1 9c2 5d3 Ad4",
            "rows": "Tc2 7d3 4d4/2h0 Jd0 3c1 8c3 7h4/5s0 6s0 Ks0 Qs1 8s2",
            "win": -205,
            "playerId": "pid5682370"
        },
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "pid5684417",
            "orderIndex": 0,
            "hero": true,
            "dead": "3d0 4s0 5h0",
            "rows": "Kd0 Ah0 As0/9s0 Ts0 Jc0 Qh0 Kh0/2d0 2c0 2s0 7c0 7s0",
            "win": 199,
            "playerId": "pid5684417"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:02:59",
    "roomId": "21914126"
}


{
    "stakes": 10,
    "handData": {"210330060030-21914126-0000028-1": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5682370",
            "orderIndex": 0,
            "hero": false,
            "dead": "Ks1 Kc2 Jc3 2d4",
            "rows": "Ad0 9h4 Qs4/5c0 6d1 7h1 5d2 7s3/9d0 Ts0 Jh0 Tc2 9s3",
            "win": 58,
            "playerId": "pid5682370"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5684417",
            "orderIndex": 1,
            "hero": true,
            "dead": "6h1 5h2 Kh3 Kd4",
            "rows": "Ac1 8h3 8d3/3h0 Jd0 4c1 Js2 Qc4/2s0 4s0 6s0 3s2 3d4",
            "win": -60,
            "playerId": "pid5684417"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:04:15",
    "roomId": "21914126"
}


{
    "stakes": 10,
    "handData": {"210330060030-21914126-0000029-1": [
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid5682370",
            "orderIndex": 1,
            "hero": false,
            "dead": "9h1 Ts2 2c3 2d4",
            "rows": "Qh1 Qs3 Tc4/4c0 7c1 4s2 Td2 7d4/7h0 8d0 9d0 Th0 Jc3",
            "win": 10,
            "playerId": "pid5682370"
        },
        {
            "inFantasy": false,
            "result": -1,
            "playerName": "pid5684417",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jh1 As2 Qd3 Ad4",
            "rows": "Ah0 Ac0 8h4/3c0 6h0 5h2 3s3 6s4/9s0 9c1 Kc1 Jd2 Js3",
            "win": -10,
            "playerId": "pid5684417"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:05:35",
    "roomId": "21914126"
}


{
    "stakes": 10,
    "handData": {"210330060030-21914126-0000030-1": [
        {
            "inFantasy": true,
            "result": -26,
            "playerName": "pid5682370",
            "orderIndex": 0,
            "hero": false,
            "dead": "6h0",
            "rows": "Qc0 Ac0 As0/2d0 2s0 7d0 Kh0 Kc0/7c0 8d0 9s0 Ts0 Js0",
            "win": -260,
            "playerId": "pid5682370"
        },
        {
            "inFantasy": true,
            "result": 26,
            "playerName": "pid5684417",
            "orderIndex": 1,
            "hero": true,
            "dead": "4c0 Jd0 2h0",
            "rows": "5h0 5d0 5c0/7h0 8h0 9h0 Qh0 Ah0/3h0 3d0 3c0 3s0 Qs0",
            "win": 252,
            "playerId": "pid5684417"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:06:12",
    "roomId": "21914126"
}


{
    "stakes": 10,
    "handData": {"210330060030-21914126-0000031-1": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "pid5682370",
            "orderIndex": 1,
            "hero": false,
            "dead": "8d1 7d2 Ac3 8s4",
            "rows": "Ks0 Kc2 Qd4/2h0 7s0 Ad1 As1 Th3/4c0 5c0 5s2 9d3 5h4",
            "win": -30,
            "playerId": "pid5682370"
        },
        {
            "inFantasy": true,
            "result": 3,
            "playerName": "pid5684417",
            "orderIndex": 0,
            "hero": true,
            "dead": "3d0 4s0 9s0",
            "rows": "Jh0 Jc0 Qs0/2d0 2c0 6c0 6s0 Td0/3h0 8h0 9h0 Kh0 Ah0",
            "win": 29,
            "playerId": "pid5684417"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:06:56",
    "roomId": "21914126"
}


{
    "stakes": 10,
    "handData": {"210330060030-21914126-0000032-1": [
        {
            "inFantasy": true,
            "result": 23,
            "playerName": "pid5682370",
            "orderIndex": 0,
            "hero": false,
            "dead": "7s0 4d1",
            "rows": "Td0 Ts0 Jd0/4c0 8c0 Jc0 Qc0 Kc0/3h0 5h0 6h0 9h0 Ah0",
            "win": 223,
            "playerId": "pid5682370"
        },
        {
            "inFantasy": false,
            "result": -23,
            "playerName": "pid5684417",
            "orderIndex": 1,
            "hero": true,
            "dead": "6c1 Th2 6d3 9d4",
            "rows": "Ad0 Qd1 7c4/2h0 7h0 5d1 7d2 5c3/4s0 Ks0 9s2 6s3 3d4",
            "win": -230,
            "playerId": "pid5684417"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:07:37",
    "roomId": "21914126"
}


{
    "stakes": 10,
    "handData": {"210330060030-21914126-0000033-1": [
        {
            "inFantasy": false,
            "result": 20,
            "playerName": "pid5682370",
            "orderIndex": 1,
            "hero": false,
            "dead": "8h1 6d2 4h3 8s4",
            "rows": "Kd0 Ah2 Kh4/3c0 Tc0 3d1 5h2 3h3/9s0 Js0 7s1 As3 6s4",
            "win": 194,
            "playerId": "pid5682370"
        },
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid5684417",
            "orderIndex": 0,
            "hero": true,
            "dead": "9c1 5s2 9d3 Ts4",
            "rows": "Jd2 Kc3 Ac4/7d0 6h1 8d1 7h2 8c3/2d0 2c0 Qh0 Qd0 9h4",
            "win": -200,
            "playerId": "pid5684417"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:09:07",
    "roomId": "21914126"
}


{
    "stakes": 10,
    "handData": {"210330060030-21914126-0000034-1": [
        {
            "inFantasy": true,
            "result": 24,
            "playerName": "pid5682370",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jc0 2c1",
            "rows": "Kh0 Kc0 Ks0/2s0 3c0 4d0 5s0 Ad0/8c0 9s0 Th0 Jd0 Qc0",
            "win": 233,
            "playerId": "pid5682370"
        },
        {
            "inFantasy": false,
            "result": -24,
            "playerName": "pid5684417",
            "orderIndex": 1,
            "hero": true,
            "dead": "Tc1 6h2 4s3 6c4",
            "rows": "Ts2 Jh2 Qd4/3d0 3s0 7s0 4h1 Qh4/5d0 8d0 Td1 2d3 6d3",
            "win": -240,
            "playerId": "pid5684417"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:09:53",
    "roomId": "21914126"
}


{
    "stakes": 10,
    "handData": {"210330060030-21914126-0000035-1": [
        {
            "inFantasy": true,
            "result": 18,
            "playerName": "pid5682370",
            "orderIndex": 1,
            "hero": false,
            "dead": "8c0 Jh1",
            "rows": "Kh0 Kd0 Ac0/2h0 2d0 3h0 3c0 Qc0/4s0 7s0 8s0 Ts0 Qs0",
            "win": 175,
            "playerId": "pid5682370"
        },
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid5684417",
            "orderIndex": 0,
            "hero": true,
            "dead": "Kc1 Ks2 3d3 Jc4",
            "rows": "Ad1 2s2 3s2/8d0 9s0 Js1 6d3 6c3/6h0 Qh0 Ah0 7d4 As4",
            "win": -180,
            "playerId": "pid5684417"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:10:44",
    "roomId": "21914126"
}


{
    "stakes": 10,
    "handData": {"210330060030-21914126-0000036-1": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "pid5682370",
            "orderIndex": 0,
            "hero": false,
            "dead": "Td1 Ts2 6h3 8d4",
            "rows": "Ac0 Ks2 As3/4c0 5d0 2s1 2h2 4s4/7c0 7s0 Qd1 Qh3 Ad4",
            "win": 128,
            "playerId": "pid5682370"
        },
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid5684417",
            "orderIndex": 1,
            "hero": true,
            "dead": "2d1 Js2 6s3 Kd4",
            "rows": "Kc0 Ah2 3h3/3d0 Jd1 Jc1 Jh2 4h3/6c0 7h0 9d0 Tc4 Qc4",
            "win": -132,
            "playerId": "pid5684417"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:12:04",
    "roomId": "21914126"
}


{
    "stakes": 10,
    "handData": {"210330060030-21914126-0000037-1": [
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid5682370",
            "orderIndex": 1,
            "hero": false,
            "dead": "Td1 Th2 3d3 Ad4",
            "rows": "Kc0 Ac3 5s4/2h0 Qh1 Jh2 2c3 7c4/3h0 3s0 9d0 3c1 9h2",
            "win": -140,
            "playerId": "pid5682370"
        },
        {
            "inFantasy": false,
            "result": 14,
            "playerName": "pid5684417",
            "orderIndex": 0,
            "hero": true,
            "dead": "2s1 Qd2 Js3 2d4",
            "rows": "Kd1 Ks2 8h4/5c0 7d0 6d1 6c2 7h4/4s0 Tc0 Ts0 4h3 4d3",
            "win": 136,
            "playerId": "pid5684417"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:13:25",
    "roomId": "21914126"
}


{
    "stakes": 10,
    "handData": {"210330060030-21914126-0000038-1": [
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid5682370",
            "orderIndex": 0,
            "hero": false,
            "dead": "Js1 4d2 4s3 5s4",
            "rows": "Jh2 Td3 Ts4/2h0 2s0 6d0 7h2 7c3/3c0 3s0 8d1 8s1 3h4",
            "win": -180,
            "playerId": "pid5682370"
        },
        {
            "inFantasy": true,
            "result": 18,
            "playerName": "pid5684417",
            "orderIndex": 1,
            "hero": true,
            "dead": "3d0 6h0",
            "rows": "Jc0 Ah0 Ac0/7s0 8c0 9h0 Tc0 Jd0/9s0 Kh0 Kd0 Kc0 Ks0",
            "win": 175,
            "playerId": "pid5684417"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:14:10",
    "roomId": "21914126"
}


{
    "stakes": 10,
    "handData": {"210330060030-21914126-0000039-1": [
        {
            "inFantasy": false,
            "result": -4,
            "playerName": "pid5682370",
            "orderIndex": 1,
            "hero": false,
            "dead": "Kh1 Qh2 9c3 9h4",
            "rows": "Ad0 Qs3 Tc4/2d0 3s0 2h2 4s2 3h4/5h0 5d0 8c1 8s1 8d3",
            "win": -40,
            "playerId": "pid5682370"
        },
        {
            "inFantasy": true,
            "result": 4,
            "playerName": "pid5684417",
            "orderIndex": 0,
            "hero": true,
            "dead": "2s0 3c0",
            "rows": "9d0 Ah0 Ac0/6d0 7h0 7c0 Jd0 Jc0/6s0 Th0 Ts0 Qd0 Qc0",
            "win": 39,
            "playerId": "pid5684417"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:15:05",
    "roomId": "21914126"
}


