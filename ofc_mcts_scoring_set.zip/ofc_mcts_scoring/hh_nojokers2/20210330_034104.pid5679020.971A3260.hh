{
    "stakes": 0.2,
    "handData": {"210330082419-21921994-0000000-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "3c1 2h2 Tc3 4d4",
            "rows": "6c1 7c2 3s4/9c0 Td0 Jh1 9h2 Ah3/4s0 5s0 8s0 Js3 2s4",
            "win": -1.2,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5602883",
            "orderIndex": 0,
            "hero": false,
            "dead": "Ad1 9d2 2c3 3h4",
            "rows": "Qd2 As2 Kh4/5c0 Jd0 8d1 8c1 5d4/4h0 8h0 Qh0 5h3 6h3",
            "win": 1.2,
            "playerId": "pid5602883"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:41:04",
    "roomId": "21921994"
}


{
    "stakes": 0.2,
    "handData": {"210330082419-21921994-0000001-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "6s1 9s2 7c3 Ad4",
            "rows": "Jd0 Kc2 Kd3/3c0 6c0 6d1 8c4 Tc4/4h0 Qh0 Th1 8h2 7h3",
            "win": 0,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5602883",
            "orderIndex": 1,
            "hero": false,
            "dead": "6h1 Ts2 2d3 3h4",
            "rows": "Ks0 4c3 4d4/2h0 2s0 7s1 5d2 5c2/Jc0 Qd0 Td1 9h3 9d4",
            "win": 0,
            "playerId": "pid5602883"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:41:53",
    "roomId": "21921994"
}


{
    "stakes": 0.2,
    "handData": {"210330082419-21921994-0000002-1": [
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qs1 4h2 6h3 Th4",
            "rows": "Kc0 9h3 5s4/2h0 Ah0 3d1 3s1 3h2/6s0 7d0 9c2 5d3 4d4",
            "win": -4.2,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "pid5602883",
            "orderIndex": 0,
            "hero": false,
            "dead": "Td1 2c2 6c3 4c4",
            "rows": "Ac1 Ad2 7s3/5h0 8d0 8s0 5c2 9s4/Jd0 Qc0 Qd1 Jc3 Js4",
            "win": 4.1,
            "playerId": "pid5602883"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:43:05",
    "roomId": "21921994"
}


{
    "stakes": 0.2,
    "handData": {"210330082419-21921994-0000003-1": [
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "6d1 4s2 4h3 9s4",
            "rows": "Kd0 9d2 9h3/Th0 As0 Js1 8h2 Ad4/2c0 5c0 2s1 5s3 6c4",
            "win": -3,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": true,
            "result": 15,
            "playerName": "pid5602883",
            "orderIndex": 1,
            "hero": false,
            "dead": "5d0 6s1 2h2",
            "rows": "9c0 Jd0 Ah0/3h0 3d0 3s0 8d0 8c0/Td0 Tc0 Qh0 Qd0 Qc0",
            "win": 2.9,
            "playerId": "pid5602883"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:43:54",
    "roomId": "21921994"
}


{
    "stakes": 0.2,
    "handData": {"210330082419-21921994-0000004-1": [
        {
            "inFantasy": false,
            "result": 16,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "7d1 8c2 Kh3 9s4",
            "rows": "Ad0 Qs2 Kd4/4h0 3c1 3s1 3d3 4c4/2h0 2c0 Jd0 Jc2 Js3",
            "win": 3.1,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid5602883",
            "orderIndex": 0,
            "hero": false,
            "dead": "5h1 2d2 3h3 9d4",
            "rows": "Ac0 Kc2 Qd3/5s0 8h0 6h3 6d4 6s4/Td0 Qc0 9c1 Jh1 Ks2",
            "win": -3.2,
            "playerId": "pid5602883"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:45:01",
    "roomId": "21921994"
}


{
    "stakes": 0.2,
    "handData": {"210330082419-21921994-0000005-1": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "6s1 5d2 4c3 6c4",
            "rows": "As0 9c3 Kh3/2c0 7h0 7s1 5h2 Qs4/Td0 Jh0 Ts1 Js2 8h4",
            "win": 1.2,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5602883",
            "orderIndex": 1,
            "hero": false,
            "dead": "8d1 Tc2 8s3 9d4",
            "rows": "Ad0 Ac2 9s3/4h0 7d0 6h1 6d1 4s4/3c0 Qc0 5c2 3d3 Jd4",
            "win": -1.2,
            "playerId": "pid5602883"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:46:39",
    "roomId": "21921994"
}


{
    "stakes": 0.2,
    "handData": {"210330082419-21921994-0000006-1": [
        {
            "inFantasy": false,
            "result": -11,
            "playerName": "pid4838353",
            "orderIndex": 1,
            "hero": false,
            "dead": "Th1 Jh2 3d3 5h4",
            "rows": "Kd0 Kh2 As3/2d0 4d1 7c1 4s2 2h4/6s0 9d0 9c0 Qs3 Qh4",
            "win": -2.2,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": 11,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "8s1 4h2 Kc3 8c4",
            "rows": "Ac0 Ah1 Js4/3h0 5s0 5c3 Ts3 3s4/7d0 Jd0 8d1 5d2 Qd2",
            "win": 2.1,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:47:33",
    "roomId": "21921994"
}


{
    "stakes": 0.2,
    "handData": {"210330082419-21921994-0000007-1": [
        {
            "inFantasy": true,
            "result": -4,
            "playerName": "pid4838353",
            "orderIndex": 0,
            "hero": false,
            "dead": "3c0 7c1",
            "rows": "Td0 Jd0 Kc0/2h0 3h0 5h0 8h0 Th0/5s0 6s0 9s0 Ts0 Qs0",
            "win": -0.8,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": true,
            "result": 4,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "2s0 7h0 8c0",
            "rows": "Ks0 Ad0 As0/9h0 9d0 Jh0 Js0 Qc0/4h0 4d0 4c0 6h0 6d0",
            "win": 0.8,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:48:09",
    "roomId": "21921994"
}


{
    "stakes": 0.2,
    "handData": {"210330082419-21921994-0000008-1": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid4838353",
            "orderIndex": 1,
            "hero": false,
            "dead": "4c1 2s2 6s3 3h4",
            "rows": "Jc0 4s2 6c4/3d0 6d0 9d1 9c2 Td4/8h0 9h0 Ah1 Kd3 Ks3",
            "win": 1.2,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "3s1 Qd2 Jd3 7c4",
            "rows": "Ad0 Ac0 7d4/2c1 4h2 4d2 Th3 5s4/Tc0 Js0 Qc0 Qs1 Jh3",
            "win": -1.2,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:49:03",
    "roomId": "21921994"
}


{
    "stakes": 0.2,
    "handData": {"210330082419-21921994-0000009-1": [
        {
            "inFantasy": false,
            "result": -1,
            "playerName": "pid4838353",
            "orderIndex": 0,
            "hero": false,
            "dead": "7c1 Ks2 9d3 7s4",
            "rows": "Ah0 Td3 Tc4/2c0 8c0 2d2 8s2 9s4/6s0 Js0 6h1 6d1 Jd3",
            "win": -0.2,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qd1 5d2 Jc3 Ad4",
            "rows": "As0 Qh1 Ac3/Kd0 Kh1 3c3 3h4 7d4/4h0 5s0 6c0 2s2 3s2",
            "win": 0.2,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:50:21",
    "roomId": "21921994"
}


{
    "stakes": 0.2,
    "handData": {"210330082419-21921994-0000010-1": [
        {
            "inFantasy": false,
            "result": -34,
            "playerName": "pid4838353",
            "orderIndex": 1,
            "hero": false,
            "dead": "7h1 7d2 As3 3h4",
            "rows": "Ad0 Ac0 7s3/4d0 4s0 2h1 5s3 9s4/Qd0 Kd1 Qs2 Kh2 Qh4",
            "win": -6.8,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": true,
            "result": 34,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "5d0 6c0 Ks0",
            "rows": "Td0 Tc0 Ts0/3s0 4h0 5h0 6h0 7c0/8h0 8c0 8s0 9h0 9c0",
            "win": 6.6,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:51:00",
    "roomId": "21921994"
}


{
    "stakes": 0.2,
    "handData": {"210330082419-21921994-0000011-1": [
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid4838353",
            "orderIndex": 0,
            "hero": false,
            "dead": "5c1 Kd2 5d3 Ah4",
            "rows": "Ks0 Qd2 9c3/Js0 2s1 7c1 2h3 6c4/5h0 8h0 Th0 8s2 9s4",
            "win": -3,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": true,
            "result": 15,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "4d0 3d0 7h0",
            "rows": "6h0 6s0 Jd0/9d0 Ts0 Jh0 Qs0 Kh0/2c0 3c0 4c0 Tc0 Qc0",
            "win": 2.9,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:51:34",
    "roomId": "21921994"
}


{
    "stakes": 0.2,
    "handData": {"210330082419-21921994-0000012-1": [
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid4838353",
            "orderIndex": 1,
            "hero": false,
            "dead": "3d1 Th2 8h3 5h4",
            "rows": "Kd0 Ah3 Ad3/3h0 6h0 4d2 6c2 6d4/7s0 Qs0 2s1 Ts1 9h4",
            "win": -3.6,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h1 9s2 4c3 Ac4",
            "rows": "Ks1 Qh3 Kc4/Td0 7d2 8d2 Tc3 8c4/3c0 5c0 7c0 Jc0 Qc1",
            "win": 3.5,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:52:21",
    "roomId": "21921994"
}


{
    "stakes": 0.2,
    "handData": {"210330082419-21921994-0000013-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid4838353",
            "orderIndex": 0,
            "hero": false,
            "dead": "8d1 Ks2 6s3 Js4",
            "rows": "Kc1 3h3 Kd4/5h0 7d1 9h2 9d2 5c3/2h0 2d0 2s0 Ts0 Th4",
            "win": 0,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": true,
            "result": 0,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "4d0 6d0",
            "rows": "8h0 8s0 Kh0/2c0 3c0 4c0 6c0 Ac0/3s0 7s0 9s0 Qs0 As0",
            "win": 0,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:52:54",
    "roomId": "21921994"
}


{
    "stakes": 0.2,
    "handData": {"210330082419-21921994-0000014-1": [
        {
            "inFantasy": true,
            "result": 20,
            "playerName": "pid4838353",
            "orderIndex": 1,
            "hero": false,
            "dead": "Kh0 Ts1",
            "rows": "Jh0 Jc0 As0/4c0 5s0 6c0 7d0 8h0/2d0 3d0 4d0 Kd0 Ad0",
            "win": 3.9,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h1 9c2 6h3 Ac4",
            "rows": "Ks1 8c2 8s2/3h0 Jd0 Td1 9s3 Qc4/4s0 Qh0 Qd0 7s3 7h4",
            "win": -4,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:53:44",
    "roomId": "21921994"
}


{
    "stakes": 0.2,
    "handData": {"210330082419-21921994-0000015-1": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "pid4838353",
            "orderIndex": 1,
            "hero": false,
            "dead": "9s1 5h2 3c3 Tc4",
            "rows": "As0 3s4 Ac4/2h0 4h0 8c1 Ah3 Ad3/Ts0 Kh0 Qh1 Td2 Qs2",
            "win": 2.9,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": 14,
            "playerName": "pid5679020",
            "orderIndex": 2,
            "hero": true,
            "dead": "9d1 4s2 5c3 5d4",
            "rows": "Ks0 8h3 4c4/3d0 6d0 6c0 6s2 Th4/7h0 7c1 Js1 7d2 Jc3",
            "win": 2.7,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": -29,
            "playerName": "pid5359358",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jd1 2d2 4d3 2s4",
            "rows": "Kd1 Kc2 8s4/5s0 9c1 7s2 Qd3 Qc3/3h0 6h0 9h0 Jh0 2c4",
            "win": -5.8,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:55:11",
    "roomId": "21921994"
}


{
    "stakes": 0.2,
    "handData": {"210330082419-21921994-0000016-1": [
        {
            "inFantasy": true,
            "result": 29,
            "playerName": "pid4838353",
            "orderIndex": 0,
            "hero": false,
            "dead": "6h0 8d1 9c2",
            "rows": "2h0 2d0 2c0/4h0 4d0 4c0 Kh0 Ad0/7s0 8h0 9s0 Th0 Js0",
            "win": 5.6,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": -32,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "Ac1 5c2 3h3 Jc4",
            "rows": "Kd0 Kc1 Jd4/Jh0 9h1 8c2 Tc3 Qh3/2s0 3s0 As0 4s2 3c4",
            "win": -6.4,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid5359358",
            "orderIndex": 2,
            "hero": false,
            "dead": "6c1 Td2 6s3 6d4",
            "rows": "Ks0 Ah2 9d4/3d0 7c0 7h1 Ts3 8s4/5h0 5d0 Qd1 Qs2 Qc3",
            "win": 0.6,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:56:20",
    "roomId": "21921994"
}


{
    "stakes": 0.2,
    "handData": {"210330082419-21921994-0000017-1": [
        {
            "inFantasy": true,
            "result": 17,
            "playerName": "pid4838353",
            "orderIndex": 2,
            "hero": false,
            "dead": "4c0 Ts1 3h2",
            "rows": "Js0 Ad0 As0/7d0 9h0 9d0 Qh0 Qc0/5h0 5d0 5s0 6h0 6c0",
            "win": 3.3,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": 28,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "5c1 Kh2 6d3 3s4",
            "rows": "Ah0 Td4 Jd4/2c0 4s0 4d2 2h3 2s3/7h0 8c0 7c1 8s1 7s2",
            "win": 5.4,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": -45,
            "playerName": "pid5359358",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qd1 Ks2 3c3 3d4",
            "rows": "Kc0 Kd1 8d2/2d0 Th1 6s2 4h4 8h4/9s0 Jh0 Jc0 9c3 Qs3",
            "win": -9,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:57:22",
    "roomId": "21921994"
}


{
    "stakes": 0.2,
    "handData": {"210330082419-21921994-0000018-1": [
        {
            "inFantasy": false,
            "result": -4,
            "playerName": "pid4838353",
            "orderIndex": 1,
            "hero": false,
            "dead": "9d1 Kd2 3h3 Kc4",
            "rows": "2d1 2s2 3s3/4h0 8h0 7d1 5h2 4c4/9c0 Tc0 Ac0 9h3 Td4",
            "win": -0.8,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": 20,
            "playerName": "pid5679020",
            "orderIndex": 2,
            "hero": true,
            "dead": "Ks1 5s2 Th3 5c4",
            "rows": "Qh0 3d3 3c4/4s0 8c0 6s2 8s3 Jh4/6d0 Jd0 5d1 Qd1 4d2",
            "win": 3.9,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid5359358",
            "orderIndex": 0,
            "hero": false,
            "dead": "2c1 Jc2 Ad3 7c4",
            "rows": "Ah0 As1 2h3/7s0 8d0 7h2 6c3 6h4/Js0 Qc0 Ts1 Qs2 Kh4",
            "win": -3.2,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:58:52",
    "roomId": "21921994"
}


{
    "stakes": 0.2,
    "handData": {"210330082419-21921994-0000019-1": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "pid4838353",
            "orderIndex": 0,
            "hero": false,
            "dead": "Js1 9c2 2s3 7d4",
            "rows": "Qs1 5s3 Jd4/6c0 8c0 2c1 Qc3 Ad4/5h0 5d0 5c0 4d2 4c2",
            "win": -0.6,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": -33,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qd1 Kd2 8s3 Qh4",
            "rows": "Ks0 Kh1 Tc3/Jh0 Jc1 3s2 As3 8d4/6h0 6d0 6s0 9s2 2h4",
            "win": -6.6,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": 36,
            "playerName": "pid5359358",
            "orderIndex": 2,
            "hero": false,
            "dead": "7h1 Kc2 2d3 3h4",
            "rows": "Ah1 Ac3 7c4/4s0 8h0 3d2 3c2 4h3/9h0 9d0 Th0 Ts1 Td4",
            "win": 7,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:00:28",
    "roomId": "21921994"
}


{
    "stakes": 0.2,
    "handData": {"210330082419-21921994-0000020-1": [
        {
            "inFantasy": false,
            "result": -22,
            "playerName": "pid4838353",
            "orderIndex": 2,
            "hero": false,
            "dead": "Ad1 7h2 Qh3 3c4",
            "rows": "3s2 Ah2 Ac3/4c0 8h0 5h1 5d1 6c4/9s0 Td0 Ts0 9d3 Tc4",
            "win": -4.4,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": -22,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "6h1 3h2 3d3 6d4",
            "rows": "Kc0 Qs3 5c4/7d0 4h1 4s1 2c2 7s3/8d0 8c0 Th0 Js2 2h4",
            "win": -4.4,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": true,
            "result": 44,
            "playerName": "pid5359358",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qc0 7c1 Jh2",
            "rows": "9h0 9c0 Kh0/2d0 4d0 Jd0 Qd0 Kd0/2s0 5s0 8s0 Ks0 As0",
            "win": 8.5,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:01:28",
    "roomId": "21921994"
}


{
    "stakes": 0.2,
    "handData": {"210330082419-21921994-0000021-1": [
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid4838353",
            "orderIndex": 1,
            "hero": false,
            "dead": "9s1 8c2 2s3 2h4",
            "rows": "Kh1 5h2 3c3/3h0 6h0 7d0 3s1 7c4/Jc0 Qs0 As2 Ah3 Td4",
            "win": -4,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": 23,
            "playerName": "pid5679020",
            "orderIndex": 2,
            "hero": true,
            "dead": "Qh1 4s2 5c3 9d4",
            "rows": "Js3 8s4 Ks4/7s0 Tc0 6s1 8h2 9c3/4d0 6d0 Jd0 8d1 Ad2",
            "win": 4.5,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "pid5359358",
            "orderIndex": 0,
            "hero": false,
            "dead": "2c1 3d2 Jh3 2d4",
            "rows": "Ac0 Kd2 7h4/4h0 5d0 4c1 5s1 6c4/9h0 Qc0 Th2 Ts3 Qd3",
            "win": -0.6,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:02:59",
    "roomId": "21921994"
}


{
    "stakes": 0.2,
    "handData": {"210330082419-21921994-0000022-1": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid4838353",
            "orderIndex": 0,
            "hero": false,
            "dead": "7s1 5d2 Qs3 9d4",
            "rows": "Ks0 3c2 3d3/2c0 Jd0 4s1 Jc3 7d4/6h0 Th0 Kh1 8h2 9c4",
            "win": -2.4,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "4d1 Jh2 Qd3 8s4",
            "rows": "9s2 Js4 Ah4/3h0 Ts0 Td1 7h2 Tc3/4c0 5c0 7c0 Kc1 Ac3",
            "win": 4.7,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5359358",
            "orderIndex": 2,
            "hero": false,
            "dead": "2d1 8c2 8d3 9h4",
            "rows": "Kd0 As1 Ad3/3s0 5s0 4h3 2h4 5h4/6d0 6s0 Qc1 6c2 Qh2",
            "win": -2.4,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:04:29",
    "roomId": "21921994"
}


{
    "stakes": 0.2,
    "handData": {"210330082419-21921994-0000023-1": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "pid4838353",
            "orderIndex": 2,
            "hero": false,
            "dead": "4d1 Js2 Th3 2c4",
            "rows": "9h3 9s3 8d4/7d0 5s1 5h2 7c2 8s4/6c0 7h0 8h0 9c0 Td1",
            "win": 2.9,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": 7,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "4s1 3c2 3h3 5c4",
            "rows": "Tc2 4c3 Ah4/6h0 Qh0 Qc1 2h3 Ks4/2d0 Jd0 Kd0 Qd1 3d2",
            "win": 1.4,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": -22,
            "playerName": "pid5359358",
            "orderIndex": 1,
            "hero": false,
            "dead": "4h1 7s2 2s3 Ac4",
            "rows": "Ad0 As0 Qs3/9d0 6d1 6s1 5d2 8c4/Ts0 Kh0 Kc2 Jc3 Jh4",
            "win": -4.4,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:05:33",
    "roomId": "21921994"
}


{
    "stakes": 0.2,
    "handData": {"210330082419-21921994-0000024-1": [
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid4838353",
            "orderIndex": 1,
            "hero": false,
            "dead": "8s1 8d2 Td3 8c4",
            "rows": "Kd0 Kh2 Ah4/2h1 4s2 7h3 7d3 Ts4/Th0 Tc0 Jc0 Js0 Jd1",
            "win": -3.2,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": 32,
            "playerName": "pid5679020",
            "orderIndex": 2,
            "hero": true,
            "dead": "3h1 4h2 5h3 5d4",
            "rows": "Ks0 Kc1 Ac4/5s0 6s0 6d2 7c2 6h3/9d0 9s0 2d1 9h3 Qc4",
            "win": 6.2,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid5359358",
            "orderIndex": 0,
            "hero": false,
            "dead": "6c1 2c2 9c3 2s4",
            "rows": "Ad0 3c1 4c4/Jh0 Qd1 4d2 Qh2 8h3/3s0 7s0 Qs0 3d3 5c4",
            "win": -3.2,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:07:18",
    "roomId": "21921994"
}


{
    "stakes": 0.2,
    "handData": {"210330082419-21921994-0000025-1": [
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid4838353",
            "orderIndex": 0,
            "hero": false,
            "dead": "2d1 5s2 6s3 3c4",
            "rows": "Jd2 Ad3 3d4/6h0 8h0 6d1 6c2 5h3/Qs0 Kh0 Kc0 Qc1 Ks4",
            "win": 1.9,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": true,
            "result": 23,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "3s0 7c0",
            "rows": "Qh0 Qd0 Ah0/7h0 9c0 9s0 Jh0 Jc0/2h0 2c0 2s0 4c0 4s0",
            "win": 4.5,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": -33,
            "playerName": "pid5359358",
            "orderIndex": 2,
            "hero": false,
            "dead": "7s1 9h2 9d3 Tc4",
            "rows": "Ac0 Ts3 As3/3h0 4h0 5c1 4d4 Js4/5d0 Td0 8d1 8c2 8s2",
            "win": -6.6,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:08:19",
    "roomId": "21921994"
}


{
    "stakes": 0.2,
    "handData": {"210330082419-21921994-0000026-1": [
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid4838353",
            "orderIndex": 2,
            "hero": false,
            "dead": "7s1 2d2 Kh3 4h4",
            "rows": "Ah0 Ac0 2h3/5s0 6c1 8s2 2c3 Th4/9c0 Ks0 Qd1 Ts2 Kd4",
            "win": -4,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": 11,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qh1 4c2 Qc3 8d4",
            "rows": "5c2 5h3 8h4/7h0 7c0 Tc0 4d3 3h4/3s0 Js0 2s1 As1 Qs2",
            "win": 2.1,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "pid5359358",
            "orderIndex": 1,
            "hero": false,
            "dead": "6h1 Jh2 5d3 7d4",
            "rows": "Kc0 8c4 Jc4/4s0 6s0 6d1 9s2 9h3/Td0 Ad0 Jd1 3d2 9d3",
            "win": 1.7,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:09:59",
    "roomId": "21921994"
}


{
    "stakes": 0.2,
    "handData": {"210330082419-21921994-0000027-1": [
        {
            "inFantasy": false,
            "result": 26,
            "playerName": "pid4838353",
            "orderIndex": 1,
            "hero": false,
            "dead": "6s1 9s2 5h3 Js4",
            "rows": "As0 Ah1 6d4/7s0 4d1 Tc2 Ts2 7c3/3h0 3d0 3c0 Jh3 Jc4",
            "win": 5,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid5679020",
            "orderIndex": 2,
            "hero": true,
            "dead": "5s1 8h2 2h3 7d4",
            "rows": "Qh0 Qd3 Ad4/2s0 Ks0 Kh1 Kc2 Th3/7h0 8d0 9h1 Td2 Jd4",
            "win": 2.3,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": -38,
            "playerName": "pid5359358",
            "orderIndex": 0,
            "hero": false,
            "dead": "8c1 Qc2 4c3 4h4",
            "rows": "Kd1 Qs3 Ac4/2d0 2c0 5d0 4s1 5c2/6h0 9c0 9d2 6c3 8s4",
            "win": -7.6,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:11:30",
    "roomId": "21921994"
}


{
    "stakes": 0.2,
    "handData": {"210330082419-21921994-0000028-1": [
        {
            "inFantasy": true,
            "result": 29,
            "playerName": "pid4838353",
            "orderIndex": 0,
            "hero": false,
            "dead": "7c0 3h1 Qd2",
            "rows": "Jh0 Js0 Ad0/3s0 4s0 5c0 6s0 7h0/8d0 8c0 Kh0 Kd0 Ks0",
            "win": 3.5,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": true,
            "result": -3,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "3d0",
            "rows": "Th0 Td0 Qc0/4c0 7s0 Jc0 Ac0 As0/5h0 5d0 9h0 9d0 9s0",
            "win": -0.6,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": -26,
            "playerName": "pid5359358",
            "orderIndex": 2,
            "hero": false,
            "dead": "8h1 8s2 5s3 6h4",
            "rows": "Qs1 7d4 Ah4/Jd0 4d1 2s2 4h2 2d3/6c0 9c0 Tc0 Kc0 2c3",
            "win": -3,
            "playerId": "pid5359358"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:12:29",
    "roomId": "21921994"
}


{
    "stakes": 0.2,
    "handData": {"210330082419-21921994-0000029-1": [
        {
            "inFantasy": false,
            "result": 8,
            "playerName": "pid4838353",
            "orderIndex": 1,
            "hero": false,
            "dead": "9s1 8d2 7s3 Kh4",
            "rows": "Ts3 Ah3 Ad4/7h0 5h1 6h1 Qh2 2h4/2c0 3c0 8c0 Qc0 Kc2",
            "win": 1.6,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "5s1 3s2 Jh3 2s4",
            "rows": "6s1 7d4 9d4/3d0 Jd0 6d2 Kd2 2d3/5c0 6c0 Ac0 7c1 Tc3",
            "win": -1.6,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:13:20",
    "roomId": "21921994"
}


{
    "stakes": 0.2,
    "handData": {"210330082419-21921994-0000030-1": [
        {
            "inFantasy": true,
            "result": 40,
            "playerName": "pid4838353",
            "orderIndex": 0,
            "hero": false,
            "dead": "2h0 8h1 3c2",
            "rows": "9h0 9d0 9c0/Qc0 Kh0 Kd0 Ks0 Ad0/7s0 8s0 9s0 Ts0 Js0",
            "win": 7.8,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": -40,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qd1 5c2 4h3 Qh4",
            "rows": "As0 2d3 Th4/2c0 4c0 5s0 4d1 5h1/7d0 7c2 Jd2 8d3 6s4",
            "win": -8,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:14:23",
    "roomId": "21921994"
}


{
    "stakes": 0.2,
    "handData": {"210330082419-21921994-0000031-1": [
        {
            "inFantasy": true,
            "result": 8,
            "playerName": "pid4838353",
            "orderIndex": 1,
            "hero": false,
            "dead": "7s0 6c1 6s2",
            "rows": "Jc0 Ad0 Ac0/4d0 5d0 7d0 Jd0 Kd0/9h0 9d0 9s0 Tc0 Ts0",
            "win": 1.6,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "3d1 2d2 2s3 2h4",
            "rows": "Ks0 Td3 7c4/Th0 3h1 7h2 4h3 Ah4/8h0 8d0 Qc0 Qd1 Qs2",
            "win": -1.6,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:15:10",
    "roomId": "21921994"
}


{
    "stakes": 0.2,
    "handData": {"210330082419-21921994-0000032-1": [
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid4838353",
            "orderIndex": 1,
            "hero": false,
            "dead": "4h1 8h2 9d3 3h4",
            "rows": "Ah0 Ad0 Kh4/5h0 5c0 3c1 2c2 2s2/Qd0 9s1 Th3 Tc3 Jc4",
            "win": -2.8,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid5679020",
            "orderIndex": 2,
            "hero": true,
            "dead": "Ac1 8d2 As3 8s4",
            "rows": "Qh0 Kd0 Kc1/2h0 6h1 6c2 2d3 Qs3/3s0 4s0 4c2 3d4 7s4",
            "win": -2.8,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": 28,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "Ts1 6d2 6s3 8c4",
            "rows": "Jd1 Js3 9c4/5d0 4d1 5s2 7c3 7d4/Td0 Jh0 Qc0 Ks0 9h2",
            "win": 5.4,
            "playerId": "pid1087966"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:16:51",
    "roomId": "21921994"
}


{
    "stakes": 0.2,
    "handData": {"210330082419-21921994-0000033-1": [
        {
            "inFantasy": false,
            "result": -27,
            "playerName": "pid4838353",
            "orderIndex": 0,
            "hero": false,
            "dead": "Td1 9d2 3c3 5c4",
            "rows": "Kd0 7d2 5h3/2h0 8h1 Jh2 Ac3 Ks4/6h0 6d0 Qs0 Qh1 5d4",
            "win": -5.4,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": false,
            "result": -4,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "9c1 Jd2 2d3 2s4",
            "rows": "Qc1 Qd2 6s3/3d0 4d0 4s1 3s3 Ad4/8c0 Th0 Tc0 8s2 3h4",
            "win": -0.8,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": false,
            "result": 31,
            "playerName": "pid1087966",
            "orderIndex": 2,
            "hero": false,
            "dead": "5s1 Kh2 8d3 4h4",
            "rows": "As0 Ah1 7s4/9h0 Js2 Ts3 Jc3 9s4/2c0 7c0 Kc0 6c1 4c2",
            "win": 6,
            "playerId": "pid1087966"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:18:30",
    "roomId": "21921994"
}


{
    "stakes": 0.2,
    "handData": {"210330082419-21921994-0000034-1": [
        {
            "inFantasy": false,
            "result": -52,
            "playerName": "pid4838353",
            "orderIndex": 2,
            "hero": false,
            "dead": "3d1 Qc2 Td3 5d4",
            "rows": "5h1 2d3 5s4/7c0 Jd0 Qd2 7d3 Tc4/3s0 8s0 Js0 2s1 Ts2",
            "win": -10.4,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": true,
            "result": 9,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "3h0",
            "rows": "Jc0 Qh0 Kd0/8h0 8d0 8c0 9h0 9s0/6h0 6d0 6c0 6s0 7s0",
            "win": 1.7,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": true,
            "result": 43,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qs0 4d1 4s2",
            "rows": "Kc0 Ks0 Ad0/2h0 4h0 7h0 Jh0 Kh0/2c0 3c0 4c0 5c0 Ac0",
            "win": 8.3,
            "playerId": "pid1087966"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:19:38",
    "roomId": "21921994"
}


{
    "stakes": 0.2,
    "handData": {"210330082419-21921994-0000035-1": [
        {
            "inFantasy": false,
            "result": -49,
            "playerName": "pid4838353",
            "orderIndex": 1,
            "hero": false,
            "dead": "4c1 9s2 7c3 4h4",
            "rows": "7s3 Ac3 Tc4/8c0 Qd0 5c1 Qc1 8s2/2h0 7h0 Th0 9h2 Jh4",
            "win": -6.6,
            "playerId": "pid4838353"
        },
        {
            "inFantasy": true,
            "result": -7,
            "playerName": "pid5679020",
            "orderIndex": 2,
            "hero": true,
            "dead": "2s0",
            "rows": "Jc0 Ks0 As0/2d0 4d0 7d0 8d0 Td0/3h0 3d0 3s0 5d0 5s0",
            "win": -1.4,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": true,
            "result": 56,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "9c0 Ts1 5h2",
            "rows": "Qs0 Ah0 Ad0/Jd0 Js0 Kh0 Kd0 Kc0/4s0 6h0 6d0 6c0 6s0",
            "win": 7.8,
            "playerId": "pid1087966"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:20:22",
    "roomId": "21921994"
}


{
    "stakes": 0.2,
    "handData": {"210330082419-21921994-0000036-1": [
        {
            "inFantasy": false,
            "result": -22,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "7c1 7h2 2s3 Js4",
            "rows": "Kd0 6c4 6s4/3c0 3s1 9d2 Tc2 3h3/5d0 5c0 Qs0 Qd1 5h3",
            "win": -4.4,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": true,
            "result": 22,
            "playerName": "pid1087966",
            "orderIndex": 1,
            "hero": false,
            "dead": "2d0 3d1 4s2",
            "rows": "Ad0 Ac0 As0/9c0 Td0 Jd0 Qh0 Kh0/4h0 6h0 8h0 9h0 Th0",
            "win": 4.3,
            "playerId": "pid1087966"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:21:11",
    "roomId": "21921994"
}


{
    "stakes": 0.2,
    "handData": {"210330082419-21921994-0000037-1": [
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "5d1 2s2 9c3 4h4",
            "rows": "Ks1 Ad3 6s4/Jc0 Th1 8h2 9s2 8d4/4c0 4s0 Qc0 Qs0 Qd3",
            "win": -1.8,
            "playerId": "pid5679020"
        },
        {
            "inFantasy": true,
            "result": 9,
            "playerName": "pid1087966",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jd0 4d1 Td2",
            "rows": "Kh0 Kd0 As0/2c0 6h0 6c0 7c0 7s0/3h0 3c0 3s0 5c0 5s0",
            "win": 1.7,
            "playerId": "pid1087966"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:21:56",
    "roomId": "21921994"
}


{
    "stakes": 0.2,
    "handData": {"210330082419-21921994-0000038-1": [
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid1503276",
            "orderIndex": 0,
            "hero": false,
            "dead": "2s1 6c2 8c3 6s4",
            "rows": "Kh0 Ah2 Jc3/3s0 7s0 7h1 4s3 3c4/9d0 Tc0 Qd1 Th2 Qs4",
            "win": 0.2,
            "playerId": "pid1503276"
        },
        {
            "inFantasy": false,
            "result": -1,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "7d1 Ts2 9c3 6d4",
            "rows": "Qh1 Ks2 As3/2c0 4d0 3d1 5h3 2d4/8h0 8s0 Jh0 Js2 Ad4",
            "win": -0.2,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:23:10",
    "roomId": "21921994"
}


{
    "stakes": 0.2,
    "handData": {"210330082419-21921994-0000039-1": [
        {
            "inFantasy": false,
            "result": 8,
            "playerName": "pid1503276",
            "orderIndex": 1,
            "hero": false,
            "dead": "2d1 4c2 Jh3 3c4",
            "rows": "Ah0 Kc2 5d4/2h0 2c1 6s3 9s3 Ad4/9c0 Td0 Qh0 Js1 8d2",
            "win": 1.6,
            "playerId": "pid1503276"
        },
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qs1 Kd2 Qc3 Ks4",
            "rows": "Ac0 As0 Jc4/4h0 3h1 7d2 Qd3 2s4/Tc0 Jd0 Ts1 5c2 9d3",
            "win": -1.6,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:24:06",
    "roomId": "21921994"
}


{
    "stakes": 0.2,
    "handData": {"210330082419-21921994-0000040-1": [
        {
            "inFantasy": false,
            "result": 4,
            "playerName": "pid1503276",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qs1 Qd2 4h3 2d4",
            "rows": "Ad0 As2 8s4/2s0 6c0 6d1 2h3 5d4/8h0 Tc0 9h1 Js2 7h3",
            "win": 0.8,
            "playerId": "pid1503276"
        },
        {
            "inFantasy": false,
            "result": -4,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "9s1 Jc2 Th3 7s4",
            "rows": "Qh0 4c3 Kc3/3s0 3h1 7c1 Jh2 3c4/7d0 8d0 9d0 Td2 4d4",
            "win": -0.8,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:25:38",
    "roomId": "21921994"
}


{
    "stakes": 0.2,
    "handData": {"210330082419-21921994-0000041-1": [
        {
            "inFantasy": true,
            "result": 35,
            "playerName": "pid1503276",
            "orderIndex": 1,
            "hero": false,
            "dead": "6h0 3h1 5s2",
            "rows": "8c0 9d0 9c0/7d0 8h0 9h0 Td0 Js0/Tc0 Jc0 Qc0 Kc0 Ac0",
            "win": 6.8,
            "playerId": "pid1503276"
        },
        {
            "inFantasy": false,
            "result": -35,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "4d1 5c2 3s3 7c4",
            "rows": "4h1 Ks3 Th4/2d0 3c0 5h0 2c1 Kd4/6s0 Qs0 4s2 As2 7s3",
            "win": -7,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:26:40",
    "roomId": "21921994"
}


{
    "stakes": 0.2,
    "handData": {"210330082419-21921994-0000042-1": [
        {
            "inFantasy": true,
            "result": 19,
            "playerName": "pid1503276",
            "orderIndex": 0,
            "hero": false,
            "dead": "4s0 3h1 2d2",
            "rows": "6d0 6c0 Ac0/5s0 7s0 9s0 Qs0 Ks0/8h0 8d0 8c0 8s0 Jd0",
            "win": 3.7,
            "playerId": "pid1503276"
        },
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "Kc1 2s2 4c3 2c4",
            "rows": "Ad1 Qh3 9d4/3d0 3c0 Td0 Tc1 7d3/6h0 Jh0 Jc2 Js2 6s4",
            "win": -3.8,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:27:53",
    "roomId": "21921994"
}


{
    "stakes": 0.2,
    "handData": {"210330082419-21921994-0000043-1": [
        {
            "inFantasy": true,
            "result": 27,
            "playerName": "pid1503276",
            "orderIndex": 1,
            "hero": false,
            "dead": "4d0 Tc1 7c2",
            "rows": "9h0 9d0 9s0/Js0 Qs0 Kh0 Kd0 Ks0/2c0 3s0 4s0 5c0 As0",
            "win": 5.2,
            "playerId": "pid1503276"
        },
        {
            "inFantasy": false,
            "result": -27,
            "playerName": "pid5679020",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jc1 4h2 7h3 Ac4",
            "rows": "7s2 2s3 Ah3/4c0 6h0 2h1 5d2 6c4/8s0 Th0 Jd0 7d1 8h4",
            "win": -5.4,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:28:55",
    "roomId": "21921994"
}


{
    "stakes": 0.2,
    "handData": {"210330082419-21921994-0000044-1": [
        {
            "inFantasy": true,
            "result": 36,
            "playerName": "pid1503276",
            "orderIndex": 0,
            "hero": false,
            "dead": "9d0 4s1 Ks2",
            "rows": "Qh0 Qc0 Qs0/7d0 8d0 9c0 Td0 Jc0/2h0 2d0 2c0 6d0 6s0",
            "win": 6.8,
            "playerId": "pid1503276"
        },
        {
            "inFantasy": false,
            "result": -36,
            "playerName": "pid5679020",
            "orderIndex": 1,
            "hero": true,
            "dead": "Ad1 Kd2 4c3 Js4",
            "rows": "Qd0 Ac2 As3/3s0 Th0 5h1 5d1 9h4/6c0 7c0 6h2 Jd3 4h4",
            "win": -7,
            "playerId": "pid5679020"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:30:18",
    "roomId": "21921994"
}


