{
    "stakes": 10,
    "handData": {"210331003626-21965318-0000002-1": [
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid284474",
            "orderIndex": 1,
            "hero": false,
            "dead": "Ad1 3s2 5h3 Th4",
            "rows": "Qd3 5c4 5s4/2s0 6s0 2h2 7h2 7d3/8d0 8c0 8s0 Jd1 Jc1",
            "win": -110,
            "playerId": "pid284474"
        },
        {
            "inFantasy": true,
            "result": 19,
            "playerName": "pid2032252",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qs0",
            "rows": "Td0 Tc0 Ks0/6d0 7c0 8h0 9d0 Ts0/4h0 4d0 4c0 4s0 As0",
            "win": 107,
            "playerId": "pid2032252"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": false,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 17:03:18",
    "roomId": "21965318"
}


{
    "stakes": 10,
    "handData": {"210331003626-21965318-0000003-1": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid2032252",
            "orderIndex": 1,
            "hero": false,
            "dead": "2c1 Jh2 Tc3 9d4",
            "rows": "Qc1 Kc2 As4/7h0 4s1 7d3 Ad3 7s4/3d0 4d0 Td0 Jd0 6d2",
            "win": 116,
            "playerId": "pid2032252"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5679019",
            "orderIndex": 0,
            "hero": true,
            "dead": "8d1 8c2 7c3 Ks4",
            "rows": "Ac0 9s3 Ah3/2s0 4h0 6s0 2h4 Kh4/Jc0 Qh1 Kd1 9h2 Th2",
            "win": -120,
            "playerId": "pid5679019"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 17:04:05",
    "roomId": "21965318"
}


{
    "stakes": 10,
    "handData": {"210331003626-21965318-0000004-1": [
        {
            "inFantasy": false,
            "result": -33,
            "playerName": "pid284474",
            "orderIndex": 0,
            "hero": false,
            "dead": "3d1 4c2 2h3 4h4",
            "rows": "Qd0 Qs1 6d3/2c0 Ac0 Kc1 Qh2 9c4/3c0 3s0 7c2 7d3 8h4",
            "win": -330,
            "playerId": "pid284474"
        },
        {
            "inFantasy": false,
            "result": 11,
            "playerName": "pid2032252",
            "orderIndex": 1,
            "hero": false,
            "dead": "4d1 6c2 2d3 2s4",
            "rows": "Ad0 7h2 As4/6h0 8d0 5d1 6s2 5h3/Td0 Ts0 Jc1 Js3 Ks4",
            "win": 107,
            "playerId": "pid2032252"
        },
        {
            "inFantasy": false,
            "result": 22,
            "playerName": "pid5679019",
            "orderIndex": 2,
            "hero": true,
            "dead": "Tc1 9d2 Kd3 8c4",
            "rows": "5c1 9h4 Qc4/8s0 9s0 4s1 5s2 7s2/Th0 Jh0 Kh0 3h3 Ah3",
            "win": 213,
            "playerId": "pid5679019"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 17:05:25",
    "roomId": "21965318"
}


{
    "stakes": 10,
    "handData": {"210331003626-21965318-0000005-1": [
        {
            "inFantasy": false,
            "result": -31,
            "playerName": "pid284474",
            "orderIndex": 2,
            "hero": false,
            "dead": "9s1 2c2 8s3 3d4",
            "rows": "Kd0 Ad2 8h3/2d0 4c0 6c0 3h1 5s1/Jh0 Qd2 Jd3 4d4 Qh4",
            "win": -170,
            "playerId": "pid284474"
        },
        {
            "inFantasy": true,
            "result": 44,
            "playerName": "pid2032252",
            "orderIndex": 0,
            "hero": false,
            "dead": "3c0 2h1 4h2",
            "rows": "Kh0 Ah0 Ac0/8c0 9d0 Td0 Jc0 Qs0/2s0 3s0 7s0 Js0 As0",
            "win": 291,
            "playerId": "pid2032252"
        },
        {
            "inFantasy": false,
            "result": -13,
            "playerName": "pid5679019",
            "orderIndex": 1,
            "hero": true,
            "dead": "Ts1 Th2 9c3 4s4",
            "rows": "Kc2 5d4 Qc4/6h0 5h1 7d2 5c3 7h3/6s0 7c0 8d0 9h0 Tc1",
            "win": -130,
            "playerId": "pid5679019"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 17:06:32",
    "roomId": "21965318"
}


{
    "stakes": 10,
    "handData": {"210331003626-21965318-0000006-1": [
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid2032252",
            "orderIndex": 1,
            "hero": false,
            "dead": "8c1 5c2 6s3 9c4",
            "rows": "Ac1 9h2 6h4/3s0 7s0 2h1 Kc3 Ah3/5d0 Qd0 Ad0 6d2 Td4",
            "win": 97,
            "playerId": "pid2032252"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5679019",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qh1 3h2 7d3 Qs4",
            "rows": "Kd1 Ks2 As3/8s0 Jd0 9s1 8d3 Qc4/3c0 4c0 7c0 5s2 4h4",
            "win": -100,
            "playerId": "pid5679019"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 17:08:18",
    "roomId": "21965318"
}


{
    "stakes": 10,
    "handData": {"210331003626-21965318-0000007-1": [
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid5131182",
            "orderIndex": 1,
            "hero": false,
            "dead": "4s1 Jd2 8d3 6c4",
            "rows": "Ad0 Ks3 Td4/8c0 6s1 7c1 5c2 7s4/2h0 6h0 Jh0 4h2 8h3",
            "win": 48,
            "playerId": "pid5131182"
        },
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "pid5679019",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jc1 9s2 3s3 8s4",
            "rows": "Kh0 Ah2 7h3/4d0 9c0 9h1 2c2 5s3/Tc0 Ts0 Qh1 3h4 Ac4",
            "win": -50,
            "playerId": "pid5679019"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 17:09:22",
    "roomId": "21965318"
}


