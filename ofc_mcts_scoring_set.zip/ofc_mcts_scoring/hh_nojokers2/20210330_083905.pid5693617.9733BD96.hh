{
    "stakes": 100,
    "handData": {"210330092938-21925390-0000000-1": [
        {
            "inFantasy": false,
            "result": 16,
            "playerName": "pid5451053",
            "orderIndex": 1,
            "hero": false,
            "dead": "9d1 2c2 3s3 3c4",
            "rows": "Ks0 Kd2 4d4/Ah0 Ac1 Tc3 Jh3 Jd4/8c0 9h0 Td0 7d1 6s2",
            "win": 1552,
            "playerId": "pid5451053"
        },
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid5693617",
            "orderIndex": 0,
            "hero": true,
            "dead": "2s1 7s2 7c3 Js4",
            "rows": "4s2 5c3 6h4/3d0 Qh1 Qs1 Qd2 2d3/5h0 6c0 7h0 9s0 4h4",
            "win": -1600,
            "playerId": "pid5693617"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:39:05",
    "roomId": "21925390"
}


{
    "stakes": 100,
    "handData": {"210330092938-21925390-0000001-1": [
        {
            "inFantasy": true,
            "result": 16,
            "playerName": "pid5451053",
            "orderIndex": 0,
            "hero": false,
            "dead": "5d0 2h1",
            "rows": "7s0 Kd0 Ks0/2c0 9d0 9s0 Qh0 Qc0/6c0 6s0 8h0 8c0 8s0",
            "win": 1552,
            "playerId": "pid5451053"
        },
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid5693617",
            "orderIndex": 1,
            "hero": true,
            "dead": "4d1 4c2 5c3 8d4",
            "rows": "Ad0 Td3 Js4/3c0 7d0 7h1 2d2 2s4/9h0 Jh0 5h1 Th2 4h3",
            "win": -1600,
            "playerId": "pid5693617"
        }
    ]},
    "appName": "Ppp",
    "price": "1PHP",
    "joined": true,
    "clubId": "19320",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:41:29",
    "roomId": "21925390"
}


