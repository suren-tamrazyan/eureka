{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000004-1": [
        {
            "inFantasy": false,
            "result": -29,
            "playerName": "pid5679885",
            "orderIndex": 1,
            "hero": false,
            "dead": "3c1 Jh2 4d3 Js4",
            "rows": "Ac0 Ah2 8s4/6s0 8h0 8d0 Th2 6d3/Qd0 9h1 9d1 7c3 Kh4",
            "win": -29,
            "playerId": "pid5679885"
        },
        {
            "inFantasy": true,
            "result": 8,
            "playerName": "pid5693395",
            "orderIndex": 2,
            "hero": true,
            "dead": "7s0 5d0",
            "rows": "2h0 2s0 Td0/4s0 5h0 6h0 7h0 8c0/9c0 Tc0 Jd0 Qc0 Kc0",
            "win": 7.8,
            "playerId": "pid5693395"
        },
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "pid4511013",
            "orderIndex": 0,
            "hero": false,
            "dead": "9s0 4c1",
            "rows": "Kd0 Ad0 As0/2d0 2c0 Ts0 Qh0 Qs0/3d0 4h0 5c0 6c0 7d0",
            "win": 20.4,
            "playerId": "pid4511013"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:48:26",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000005-1": [
        {
            "inFantasy": false,
            "result": 50,
            "playerName": "pid5679885",
            "orderIndex": 0,
            "hero": false,
            "dead": "3d1 3c2 6c3 2d4",
            "rows": "4d2 9s3 9d4/Js0 7c1 7s2 7h3 Jc4/6h0 6d0 Kc0 Ks0 Kh1",
            "win": 48.5,
            "playerId": "pid5679885"
        },
        {
            "inFantasy": false,
            "result": -40,
            "playerName": "pid5693395",
            "orderIndex": 1,
            "hero": true,
            "dead": "Ad1 3h2 2h3 Jd4",
            "rows": "Ac0 Kd1 Ah1/2s0 5d0 9c2 5h3 Th4/Qh0 Qc0 4s2 4c3 8h4",
            "win": -40,
            "playerId": "pid5693395"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid4511013",
            "orderIndex": 2,
            "hero": false,
            "dead": "Qs1 7d2 2c3 8d4",
            "rows": "As1 Qd2 4h3/3s0 6s0 5s1 5c2 9h4/8c0 8s0 Td0 Tc3 Ts4",
            "win": -10,
            "playerId": "pid4511013"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:50:17",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000006-1": [
        {
            "inFantasy": false,
            "result": 38,
            "playerName": "pid5679885",
            "orderIndex": 2,
            "hero": false,
            "dead": "8s1 6c2 6d3 Kh4",
            "rows": "Ac2 As2 8c4/2d0 5c1 5h3 Kc3 5s4/8d0 9s0 Ts0 Jc0 Qs1",
            "win": 36.9,
            "playerId": "pid5679885"
        },
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid5693395",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qc1 2c2 Ah3 Js4",
            "rows": "Kd0 Qh1 Ks2/3d0 4h0 Jh3 4d4 Th4/7s0 9h0 8h1 9d2 6s3",
            "win": -19,
            "playerId": "pid5693395"
        },
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid4511013",
            "orderIndex": 1,
            "hero": false,
            "dead": "3c1 2h2 4s3 2s4",
            "rows": "Qd0 4c2 7h3/Tc1 Jd1 Ad2 7c3 3h4/5d0 6h0 7d0 9c0 Td4",
            "win": -19,
            "playerId": "pid4511013"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:52:16",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000007-1": [
        {
            "inFantasy": true,
            "result": 17,
            "playerName": "pid5679885",
            "orderIndex": 1,
            "hero": false,
            "dead": "4h0 8h1 3h2",
            "rows": "Ts0 Kd0 Kc0/2d0 2c0 4d0 7c0 7s0/5d0 5s0 Js0 Qh0 Qc0",
            "win": 16.5,
            "playerId": "pid5679885"
        },
        {
            "inFantasy": false,
            "result": -26,
            "playerName": "pid5693395",
            "orderIndex": 2,
            "hero": true,
            "dead": "2s1 5c2 Td3 6s4",
            "rows": "8c1 9s2 7d4/6d0 Jd0 Ac2 Jc3 Qs3/5h0 Kh0 Ah0 Th1 Ks4",
            "win": -26,
            "playerId": "pid5693395"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "pid4511013",
            "orderIndex": 0,
            "hero": false,
            "dead": "8s1 3s2 Jh3 7h4",
            "rows": "Ad0 Tc2 8d4/3d0 3c0 4s1 2h2 4c3/6h0 9h0 6c1 9c3 9d4",
            "win": 8.7,
            "playerId": "pid4511013"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:53:48",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000008-1": [
        {
            "inFantasy": false,
            "result": -1,
            "playerName": "pid5679885",
            "orderIndex": 0,
            "hero": false,
            "dead": "3s1 9h2 5h3 5s4",
            "rows": "Kh0 Ks2 Ah4/2d0 2c0 4d0 4h1 As4/Tc0 7s1 7c2 6h3 6d3",
            "win": -1,
            "playerId": "pid5679885"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid5693395",
            "orderIndex": 1,
            "hero": true,
            "dead": "9c1 Jd2 7d3 2s4",
            "rows": "Kc0 Kd3 Ac3/3h0 6s0 5d1 3d2 5c4/Td0 Ts0 Qc1 Jh2 Jc4",
            "win": 2.9,
            "playerId": "pid5693395"
        },
        {
            "inFantasy": false,
            "result": -2,
            "playerName": "pid4511013",
            "orderIndex": 2,
            "hero": false,
            "dead": "Js1 Qd2 2h3 8c4",
            "rows": "Ad2 7h4 Th4/4c0 4s0 Qh1 Qs1 6c3/8d0 8s0 9s0 8h2 9d3",
            "win": -2,
            "playerId": "pid4511013"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:55:34",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000009-1": [
        {
            "inFantasy": true,
            "result": 22,
            "playerName": "pid5679885",
            "orderIndex": 2,
            "hero": false,
            "dead": "2d0 6h1",
            "rows": "Kh0 Ah0 Ac0/5d0 5c0 9d0 Jh0 Js0/4d0 4c0 4s0 7h0 7c0",
            "win": 21.3,
            "playerId": "pid5679885"
        },
        {
            "inFantasy": true,
            "result": 3,
            "playerName": "pid5693395",
            "orderIndex": 0,
            "hero": true,
            "dead": "3s0 5s0",
            "rows": "Qd0 Qs0 Kd0/6d0 6c0 8s0 Jd0 Jc0/4h0 5h0 8h0 9h0 Th0",
            "win": 2.9,
            "playerId": "pid5693395"
        },
        {
            "inFantasy": false,
            "result": -25,
            "playerName": "pid4511013",
            "orderIndex": 1,
            "hero": false,
            "dead": "3c1 8d2 7d3 2h4",
            "rows": "As1 6s3 7s3/Qh0 9s2 Td2 3h4 3d4/8c0 9c0 Qc0 Kc0 Tc1",
            "win": -25,
            "playerId": "pid4511013"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:56:34",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000010-1": [
        {
            "inFantasy": false,
            "result": 2,
            "playerName": "pid5679885",
            "orderIndex": 1,
            "hero": false,
            "dead": "7h1 3d2 6h3 4d4",
            "rows": "Ah1 Tc3 5h4/2d0 Qd0 2c1 7c2 Qs3/Jh0 Jd0 Jc0 5c2 5d4",
            "win": 1.9,
            "playerId": "pid5679885"
        },
        {
            "inFantasy": false,
            "result": 23,
            "playerName": "pid5693395",
            "orderIndex": 2,
            "hero": true,
            "dead": "3h1 Td2 Ks3 6c4",
            "rows": "Kh0 Kd3 Qh4/4c0 8h0 8c1 7s3 7d4/5s0 Ts0 9s1 2s2 6s2",
            "win": 22.3,
            "playerId": "pid5693395"
        },
        {
            "inFantasy": false,
            "result": -25,
            "playerName": "pid4511013",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qc1 8d2 Ac3 Ad4",
            "rows": "Kc1 As2 4s3/2h0 6d0 3c1 3s2 4h3/8s0 9c0 Th0 9h4 9d4",
            "win": -25,
            "playerId": "pid4511013"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:58:35",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000011-1": [
        {
            "inFantasy": false,
            "result": -26,
            "playerName": "pid5679885",
            "orderIndex": 0,
            "hero": false,
            "dead": "Tc1 Th2 3h3 2h4",
            "rows": "Ah0 Jd2 Kc3/2d0 5c0 5h1 9c2 Qc3/7d0 8h0 8c1 8s4 Kh4",
            "win": -26,
            "playerId": "pid5679885"
        },
        {
            "inFantasy": true,
            "result": 38,
            "playerName": "pid5693395",
            "orderIndex": 1,
            "hero": true,
            "dead": "Td0 4c0",
            "rows": "Qh0 Ac0 As0/6d0 6c0 7h0 7c0 Js0/3d0 3s0 9h0 9d0 9s0",
            "win": 36.9,
            "playerId": "pid5693395"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid4511013",
            "orderIndex": 2,
            "hero": false,
            "dead": "5d1 2c2 5s3 8d4",
            "rows": "Ad0 Qd1 6h3/3c0 Kd1 Jc2 2s4 Ks4/4s0 6s0 Qs0 Ts2 7s3",
            "win": -12,
            "playerId": "pid4511013"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 05:59:55",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000012-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5693395",
            "orderIndex": 1,
            "hero": true,
            "dead": "9s1 3c2 2h3 8d4",
            "rows": "Kc2 Ad2 As3/2d0 2s0 7c0 7d3 5d4/Td0 Js0 6d1 6c1 6s4",
            "win": 0,
            "playerId": "pid5693395"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid4511013",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qs1 Jd2 8s3 7s4",
            "rows": "Ac0 Ks1 Kd4/2c0 3h1 5c2 5s2 3s4/7h0 9d0 Ts0 6h3 8h3",
            "win": 0,
            "playerId": "pid4511013"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:01:19",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000013-1": [
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "pid5693395",
            "orderIndex": 0,
            "hero": true,
            "dead": "2c0 Kc0 Jd0",
            "rows": "Ah0 Ac0 As0/2d0 3h0 4h0 5d0 6s0/9d0 9s0 Qh0 Qd0 Qc0",
            "win": 20.4,
            "playerId": "pid5693395"
        },
        {
            "inFantasy": true,
            "result": -21,
            "playerName": "pid4511013",
            "orderIndex": 1,
            "hero": false,
            "dead": "5s0 6c1",
            "rows": "Tc0 Js0 Qs0/5h0 7h0 9h0 Jh0 Kh0/4d0 6d0 8d0 Td0 Ad0",
            "win": -21,
            "playerId": "pid4511013"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:01:50",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000014-1": [
        {
            "inFantasy": true,
            "result": 28,
            "playerName": "pid5693395",
            "orderIndex": 1,
            "hero": true,
            "dead": "2h0 3s0 4d0",
            "rows": "8d0 8c0 8s0/8h0 9c0 Td0 Jh0 Qh0/Ts0 Js0 Qd0 Kd0 Ac0",
            "win": 27.2,
            "playerId": "pid5693395"
        },
        {
            "inFantasy": false,
            "result": -28,
            "playerName": "pid4511013",
            "orderIndex": 0,
            "hero": false,
            "dead": "6h1 Qs2 Jc3 7s4",
            "rows": "Kc0 Qc1 As3/3h0 5s0 7c2 7d3 5c4/4h0 4s0 Th1 4c2 6d4",
            "win": -28,
            "playerId": "pid4511013"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:02:36",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000015-1": [
        {
            "inFantasy": true,
            "result": 37,
            "playerName": "pid5693395",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h0 Th0 Qs0",
            "rows": "Jh0 Jd0 Jc0/2c0 4c0 5c0 8c0 Qc0/4d0 5d0 7d0 Td0 Kd0",
            "win": 13.6,
            "playerId": "pid5693395"
        },
        {
            "inFantasy": false,
            "result": -37,
            "playerName": "pid4511013",
            "orderIndex": 1,
            "hero": false,
            "dead": "9d1 As2 4s3 Ac4",
            "rows": "3c0 3h1 3s1/9s0 9c2 Kh2 7h3 Js4/2d0 6d0 Qd0 Qh3 6c4",
            "win": -14,
            "playerId": "pid4511013"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:03:42",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000016-1": [
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid4511013",
            "orderIndex": 1,
            "hero": false,
            "dead": "8c1 2c2 8h3 7h4",
            "rows": "As1 9s4 Jc4/4c0 6d0 6h1 7s2 7c3/5h0 5d0 9c0 Th2 Td3",
            "win": -15,
            "playerId": "pid4511013"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "pid5693395",
            "orderIndex": 0,
            "hero": true,
            "dead": "9h1 2d2 Kd3 3c4",
            "rows": "Kh0 Ks1 Ts4/4s0 Js0 3d2 Ah3 Ac4/8d0 Qd0 8s1 Qc2 Qs3",
            "win": 14.5,
            "playerId": "pid5693395"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:04:45",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000017-1": [
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "pid4511013",
            "orderIndex": 0,
            "hero": false,
            "dead": "Th1 Qh2 8d3 9d4",
            "rows": "Qd1 As3 Qs4/2h0 2c0 3h1 2s2 Qc4/5s0 8s0 Ts0 Ks2 4s3",
            "win": -5,
            "playerId": "pid4511013"
        },
        {
            "inFantasy": true,
            "result": 5,
            "playerName": "pid5693395",
            "orderIndex": 1,
            "hero": true,
            "dead": "9s0 Tc0",
            "rows": "Kc0 Ah0 Ad0/3d0 4h0 5d0 6s0 7c0/2d0 6d0 7d0 Td0 Jd0",
            "win": 4.8,
            "playerId": "pid5693395"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:05:28",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000018-1": [
        {
            "inFantasy": true,
            "result": 20,
            "playerName": "pid4511013",
            "orderIndex": 1,
            "hero": false,
            "dead": "2d0",
            "rows": "Kh0 Ks0 As0/5d0 7h0 7c0 Qh0 Qd0/6h0 6d0 8h0 8d0 8s0",
            "win": 19.4,
            "playerId": "pid4511013"
        },
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid5693395",
            "orderIndex": 0,
            "hero": true,
            "dead": "2s1 Jh2 Th3 5c4",
            "rows": "Ah2 Ad2 Kd3/4c0 Tc0 9c1 8c3 3d4/5s0 7s0 Js0 Qs1 2h4",
            "win": -20,
            "playerId": "pid5693395"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:06:17",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000019-1": [
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "pid4511013",
            "orderIndex": 0,
            "hero": false,
            "dead": "3h1 2h2 6h3 Th4",
            "rows": "Ac0 Kc1 3s2/5c0 8s0 Jh1 Jc3 Ah4/4d0 Qd0 7d2 2d3 8d4",
            "win": -5,
            "playerId": "pid4511013"
        },
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid5693395",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jd1 Js2 5s3 2s4",
            "rows": "Kh0 Ks1 8c3/6d0 7c1 2c2 6s4 7s4/3d0 3c0 Tc0 Ts2 Kd3",
            "win": 4.8,
            "playerId": "pid5693395"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:07:39",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000020-1": [
        {
            "inFantasy": false,
            "result": -23,
            "playerName": "pid4511013",
            "orderIndex": 1,
            "hero": false,
            "dead": "6c1 7s2 3h3 8d4",
            "rows": "Kh0 Qd2 Jd4/2h0 3s2 Th3 Ts3 Ks4/9s0 Qs0 As0 6s1 8s1",
            "win": -23,
            "playerId": "pid4511013"
        },
        {
            "inFantasy": true,
            "result": 23,
            "playerName": "pid5693395",
            "orderIndex": 0,
            "hero": true,
            "dead": "4s0 8h0",
            "rows": "Qh0 Ah0 Ac0/2c0 4c0 7c0 Tc0 Kc0/3d0 9d0 Td0 Kd0 Ad0",
            "win": 22.3,
            "playerId": "pid5693395"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:08:22",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000021-1": [
        {
            "inFantasy": false,
            "result": -4,
            "playerName": "pid4511013",
            "orderIndex": 0,
            "hero": false,
            "dead": "3s1 2d2 6d3 5c4",
            "rows": "Kd2 Qh3 Jc4/9h0 2c1 9d1 7h3 9c4/3c0 4s0 6c0 7s0 5s2",
            "win": -4,
            "playerId": "pid4511013"
        },
        {
            "inFantasy": false,
            "result": 4,
            "playerName": "pid5693395",
            "orderIndex": 1,
            "hero": true,
            "dead": "4d1 Kc2 3h3 2h4",
            "rows": "As0 Ks1 Ah3/6h0 Tc1 Th2 5h3 5d4/Jh0 Js0 Qc0 Qs2 Ts4",
            "win": 3.9,
            "playerId": "pid5693395"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:09:44",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000022-1": [
        {
            "inFantasy": false,
            "result": -29,
            "playerName": "pid4511013",
            "orderIndex": 1,
            "hero": false,
            "dead": "Ks1 4s2 6s3 5d4",
            "rows": "Ad2 4d3 Jd3/6h0 9h0 3h1 5h1 Qh2/7c0 Jc0 Kc0 2c4 Js4",
            "win": -29,
            "playerId": "pid4511013"
        },
        {
            "inFantasy": true,
            "result": 29,
            "playerName": "pid5693395",
            "orderIndex": 0,
            "hero": true,
            "dead": "2s0 7d0 8c0",
            "rows": "9d0 9c0 9s0/4c0 5s0 6d0 7h0 8h0/Td0 Jh0 Qs0 Kd0 Ac0",
            "win": 28.1,
            "playerId": "pid5693395"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:10:22",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000023-1": [
        {
            "inFantasy": false,
            "result": -23,
            "playerName": "pid4511013",
            "orderIndex": 0,
            "hero": false,
            "dead": "9d1 5c2 2d3 Ac4",
            "rows": "Kh1 5h3 Tc4/9c0 Th0 Jd0 Ts1 Jh2/Qc0 Qs0 6h2 8c3 Td4",
            "win": -23,
            "playerId": "pid4511013"
        },
        {
            "inFantasy": true,
            "result": 23,
            "playerName": "pid5693395",
            "orderIndex": 1,
            "hero": true,
            "dead": "2c0 3d0 4d0",
            "rows": "Qh0 Ad0 As0/6d0 6c0 6s0 9h0 Jc0/7h0 7d0 7c0 Kd0 Ks0",
            "win": 22.3,
            "playerId": "pid5693395"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:11:12",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000024-1": [
        {
            "inFantasy": false,
            "result": 14,
            "playerName": "pid4511013",
            "orderIndex": 1,
            "hero": false,
            "dead": "8c1 9h2 Js3 4s4",
            "rows": "7s2 Ad3 5s4/2d0 2s0 2h1 3c2 8s3/6c0 6s0 Qs0 Qd1 6h4",
            "win": 13.6,
            "playerId": "pid4511013"
        },
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid5693395",
            "orderIndex": 0,
            "hero": true,
            "dead": "Kd1 6d2 Td3 Ts4",
            "rows": "As1 Ah3 Tc4/8h0 Th0 7d1 7h2 8d2/9d0 9s0 Jc0 Kc3 2c4",
            "win": -14,
            "playerId": "pid5693395"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:12:14",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000025-1": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid4511013",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jh1 3d2 2d3 Qh4",
            "rows": "Kh1 4d2 Jd3/6h0 7c0 8c0 9d2 Th4/3s0 Qs0 5s1 2s3 Ks4",
            "win": 2.9,
            "playerId": "pid4511013"
        },
        {
            "inFantasy": false,
            "result": -2,
            "playerName": "pid5693395",
            "orderIndex": 2,
            "hero": true,
            "dead": "5h1 Kc2 3h3 Td4",
            "rows": "Qc0 Qd1 Js4/7d0 Jc1 Kd3 Ah3 Ad4/4s0 8s0 As0 8d2 Ac2",
            "win": -2,
            "playerId": "pid5693395"
        },
        {
            "inFantasy": false,
            "result": -1,
            "playerName": "pid83584",
            "orderIndex": 0,
            "hero": false,
            "dead": "6s1 Tc2 7h3 3c4",
            "rows": "2h3 2c3 7s4/5d0 8h0 6d1 6c1 5c4/9h0 9c0 9s0 4h2 4c2",
            "win": -1,
            "playerId": "pid83584"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:14:04",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000026-1": [
        {
            "inFantasy": false,
            "result": -28,
            "playerName": "pid4511013",
            "orderIndex": 0,
            "hero": false,
            "dead": "3s1 8h2 8s3 Th4",
            "rows": "As0 Ks3 Ah3/2d0 Jc0 7d2 Jd2 Ts4/Qh0 Qd0 4h1 4c1 Kd4",
            "win": -28,
            "playerId": "pid4511013"
        },
        {
            "inFantasy": true,
            "result": 27,
            "playerName": "pid5693395",
            "orderIndex": 1,
            "hero": true,
            "dead": "2c0",
            "rows": "Td0 Kh0 Kc0/3h0 3d0 5d0 9c0 9s0/5s0 6s0 7s0 Js0 Qs0",
            "win": 26.2,
            "playerId": "pid5693395"
        },
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid83584",
            "orderIndex": 2,
            "hero": false,
            "dead": "8c1 Ac2 2s3 Tc4",
            "rows": "Qc0 6h3 7c3/5h0 2h1 6c1 4s2 5c4/4d0 6d0 8d0 9d2 Ad4",
            "win": 1,
            "playerId": "pid83584"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:15:10",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000027-1": [
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid4511013",
            "orderIndex": 2,
            "hero": false,
            "dead": "7c1 7s2 2d3 9c4",
            "rows": "8s0 As0 Tc4/3d0 6d1 6c2 5h3 5c4/Th0 Ts0 9s1 Js2 Td3",
            "win": -18,
            "playerId": "pid4511013"
        },
        {
            "inFantasy": false,
            "result": -13,
            "playerName": "pid5693395",
            "orderIndex": 0,
            "hero": true,
            "dead": "4s1 4d2 3c3 3s4",
            "rows": "5s2 9h3 Ad4/Qc0 Jd1 Kd1 Kh3 3h4/2h0 4h0 7h0 Jh0 6h2",
            "win": -13,
            "playerId": "pid5693395"
        },
        {
            "inFantasy": false,
            "result": 31,
            "playerName": "pid83584",
            "orderIndex": 1,
            "hero": false,
            "dead": "2s1 Jc2 6s3 5d4",
            "rows": "Kc0 2c3 Ks3/7d0 Ah1 4c2 9d4 Ac4/8h0 8c0 Qd0 Qs1 Qh2",
            "win": 30.1,
            "playerId": "pid83584"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:16:31",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000028-1": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "pid4511013",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qc1 8h2 9d3 9s4",
            "rows": "Ac0 Kh4 Kc4/Jd0 2d1 5d1 7d2 8d2/Ts0 Qs0 Ks0 3s3 Js3",
            "win": 23.3,
            "playerId": "pid4511013"
        },
        {
            "inFantasy": false,
            "result": -41,
            "playerName": "pid5693395",
            "orderIndex": 2,
            "hero": true,
            "dead": "8c1 8s2 5c3 2c4",
            "rows": "9c2 Ad3 9h4/2h0 Th0 3h1 3c2 Td3/4d0 4s0 Jc0 Jh1 5s4",
            "win": -41,
            "playerId": "pid5693395"
        },
        {
            "inFantasy": true,
            "result": 17,
            "playerName": "pid83584",
            "orderIndex": 0,
            "hero": false,
            "dead": "2s0 4c1",
            "rows": "Kd0 Ah0 As0/5h0 6h0 6c0 6s0 Tc0/7h0 7c0 7s0 Qh0 Qd0",
            "win": 16.5,
            "playerId": "pid83584"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:17:52",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000029-1": [
        {
            "inFantasy": true,
            "result": 16,
            "playerName": "pid4511013",
            "orderIndex": 0,
            "hero": false,
            "dead": "4s0 9s1",
            "rows": "Qc0 Kh0 Ks0/3h0 3c0 5h0 5s0 Jc0/4d0 7d0 Td0 Kd0 Ad0",
            "win": 15.5,
            "playerId": "pid4511013"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5693395",
            "orderIndex": 1,
            "hero": true,
            "dead": "9c1 3d2 Kc3 6d4",
            "rows": "7h2 9d2 Qd4/2s0 Qs0 Jd3 Js3 2d4/8h0 9h0 Jh0 6h1 Ah1",
            "win": -12,
            "playerId": "pid5693395"
        },
        {
            "inFantasy": false,
            "result": -4,
            "playerName": "pid83584",
            "orderIndex": 2,
            "hero": false,
            "dead": "8d1 5d2 6c3 5c4",
            "rows": "Qh0 8s3 As4/2c0 3s0 4h1 2h3 4c4/Th0 Ts0 Tc1 7c2 7s2",
            "win": -4,
            "playerId": "pid83584"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:18:59",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000030-1": [
        {
            "inFantasy": false,
            "result": -1,
            "playerName": "pid5693395",
            "orderIndex": 1,
            "hero": true,
            "dead": "Js1 5c2 3c3 Th4",
            "rows": "Ks2 7h3 7s4/3s0 4h0 4c0 6c1 6h3/8d0 9s0 9c1 8c2 Qh4",
            "win": -1,
            "playerId": "pid5693395"
        },
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid83584",
            "orderIndex": 0,
            "hero": false,
            "dead": "2d1 Ah2 2h3 5d4",
            "rows": "Kd0 9h3 Jd3/4s0 5s0 6s1 4d2 6d4/Jc0 Qd0 Td1 9d2 8h4",
            "win": 1,
            "playerId": "pid83584"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:20:06",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000031-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid4511013",
            "orderIndex": 0,
            "hero": false,
            "dead": "4d1 Td2 3c3 6s4",
            "rows": "Qd0 Qc1 Jc3/8c0 2c2 Kh2 Tc3 7s4/3h0 Th0 Ah0 Jh1 8s4",
            "win": -6,
            "playerId": "pid4511013"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5693395",
            "orderIndex": 1,
            "hero": true,
            "dead": "7h1 6c2 Qh3 Qs4",
            "rows": "Ac0 Kc2 As3/5d0 5c0 2d1 7d2 Js4/8d0 Ts0 8h1 4s3 5s4",
            "win": -6,
            "playerId": "pid5693395"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid83584",
            "orderIndex": 2,
            "hero": false,
            "dead": "4c1 Ks2 9s3 5h4",
            "rows": "Kd1 Ad1 2h2/7c0 9d0 4h2 2s3 9c3/6h0 6d0 Jd0 3d4 3s4",
            "win": 11.6,
            "playerId": "pid83584"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:22:07",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000032-1": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid4511013",
            "orderIndex": 2,
            "hero": false,
            "dead": "9h1 Kd2 Ah3 2d4",
            "rows": "Ad0 As0 Ts4/2s0 3c1 3s1 2h3 5s3/6d0 8d0 6s2 Jc2 9d4",
            "win": -12,
            "playerId": "pid4511013"
        },
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "pid5693395",
            "orderIndex": 0,
            "hero": true,
            "dead": "2c1 Qs2 7h3 5h4",
            "rows": "Kh0 Qd2 5c3/3h0 4s0 Th1 Td2 7s4/8c0 8s0 Js1 Jd3 8h4",
            "win": 23.3,
            "playerId": "pid5693395"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid83584",
            "orderIndex": 1,
            "hero": false,
            "dead": "6c1 6h2 Ac3 7d4",
            "rows": "Ks0 Kc2 Jh4/3d0 5d0 9s1 9c3 7c4/4h0 Qh0 4d1 4c2 Qc3",
            "win": -12,
            "playerId": "pid83584"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:23:31",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000033-1": [
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid4511013",
            "orderIndex": 0,
            "hero": false,
            "dead": "3h1 7h2 2c3 3s4",
            "rows": "Kc1 4d2 Qh4/7c0 Ad1 4s2 Qc3 Ah3/8h0 8c0 9d0 9s0 Qd4",
            "win": 1,
            "playerId": "pid4511013"
        },
        {
            "inFantasy": false,
            "result": -1,
            "playerName": "pid5693395",
            "orderIndex": 1,
            "hero": true,
            "dead": "6s1 5s2 Kd3 Td4",
            "rows": "8s0 7s3 Qs4/3c0 4c0 5d1 9h2 9c2/2h0 Jh0 2s1 Ts3 Th4",
            "win": -1,
            "playerId": "pid5693395"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:25:15",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000034-1": [
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid4511013",
            "orderIndex": 2,
            "hero": false,
            "dead": "2d1 Jc2 Ts3 4d4",
            "rows": "Qc2 6s4 Kh4/7h0 7d0 5d1 6d1 7s3/Th0 Jd0 Qs0 9c2 8h3",
            "win": -14,
            "playerId": "pid4511013"
        },
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid5693395",
            "orderIndex": 0,
            "hero": true,
            "dead": "8s1 Jh2 3c3 9d4",
            "rows": "Ad1 3d3 Tc4/6h0 2s1 5c2 5s3 6c4/8d0 Td0 Js0 Qh0 9s2",
            "win": -20,
            "playerId": "pid5693395"
        },
        {
            "inFantasy": false,
            "result": 34,
            "playerName": "pid1220150",
            "orderIndex": 1,
            "hero": false,
            "dead": "8c1 4c2 3s3 2c4",
            "rows": "Kd0 Kc3 Qd4/4s0 Ac1 As2 Ah3 7c4/4h0 5h0 9h0 2h1 3h2",
            "win": 33,
            "playerId": "pid1220150"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:26:46",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000035-1": [
        {
            "inFantasy": false,
            "result": -1,
            "playerName": "pid4511013",
            "orderIndex": 1,
            "hero": false,
            "dead": "9s1 Qc2 Ts3 5s4",
            "rows": "Tc1 Ac1 2s2/4c0 8d0 Jd2 4d4 6d4/7h0 9h0 Qh0 5h3 6h3",
            "win": -1,
            "playerId": "pid4511013"
        },
        {
            "inFantasy": false,
            "result": -25,
            "playerName": "pid5693395",
            "orderIndex": 2,
            "hero": true,
            "dead": "2d1 2c2 3c3 Kh4",
            "rows": "Ah0 Kd1 8c2/7c0 Td0 5c1 7s3 9c4/6s0 Qs0 3s2 As3 3h4",
            "win": -25,
            "playerId": "pid5693395"
        },
        {
            "inFantasy": true,
            "result": 26,
            "playerName": "pid1220150",
            "orderIndex": 0,
            "hero": false,
            "dead": "Th0 Qd1",
            "rows": "8h0 8s0 Ad0/2h0 5d0 6c0 Kc0 Ks0/4h0 4s0 Jh0 Jc0 Js0",
            "win": 25.2,
            "playerId": "pid1220150"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:28:39",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000036-1": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid4511013",
            "orderIndex": 1,
            "hero": false,
            "dead": "6s1 Ks2 9s3 3d4",
            "rows": "Ad0 Td4 Qd4/3s0 4c0 7c1 5h3 5d3/Jd0 Qh0 Qc1 Tc2 Ts2",
            "win": 5.8,
            "playerId": "pid4511013"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5693395",
            "orderIndex": 0,
            "hero": true,
            "dead": "8d1 Kc2 5s3 Jc4",
            "rows": "Ac0 Kd3 8c4/2d0 2s0 4s0 2c1 Js3/6h0 Th1 2h2 9h2 7s4",
            "win": -6,
            "playerId": "pid5693395"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:29:43",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000037-1": [
        {
            "inFantasy": false,
            "result": 17,
            "playerName": "pid4511013",
            "orderIndex": 0,
            "hero": false,
            "dead": "2c1 3d2 Jc3 2d4",
            "rows": "Kc0 Td4 Ts4/4c0 5d0 6c1 7c1 8c2/9c0 Js0 8s2 Tc3 Qc3",
            "win": 16.5,
            "playerId": "pid4511013"
        },
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid5693395",
            "orderIndex": 1,
            "hero": true,
            "dead": "Kh1 5s2 8d3 Ac4",
            "rows": "As0 Ad1 7d3/3c0 4h0 3h1 2s2 4d3/9s0 Jd0 Kd2 6d4 Qh4",
            "win": -17,
            "playerId": "pid5693395"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:31:12",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000038-1": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid4511013",
            "orderIndex": 1,
            "hero": false,
            "dead": "3d1 Jd2 4d3 9s4",
            "rows": "Kc0 Qd1 Jc3/5d0 7s0 7d1 8s3 8c4/2h0 3h0 Jh2 Qh2 Ad4",
            "win": -12,
            "playerId": "pid4511013"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid5693395",
            "orderIndex": 0,
            "hero": true,
            "dead": "5h1 Ts2 5c3 7c4",
            "rows": "9h1 Ah3 9d4/8d0 Qs0 Qc1 6h3 Ks4/3c0 4c0 5s0 2s2 6c2",
            "win": 11.6,
            "playerId": "pid5693395"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:32:18",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000039-1": [
        {
            "inFantasy": false,
            "result": -1,
            "playerName": "pid4511013",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qc1 7c2 9c3 6h4",
            "rows": "Kd2 Jh3 Ad4/3c0 5s1 2s2 2c3 2h4/8d0 Ts0 Jd0 Qh0 9d1",
            "win": -1,
            "playerId": "pid4511013"
        },
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid5693395",
            "orderIndex": 1,
            "hero": true,
            "dead": "Kc1 3s2 Ks3 Th4",
            "rows": "As1 Jc2 7s4/7h0 4s1 5d2 4h3 7d3/6c0 6s0 8h0 8c0 6d4",
            "win": 1,
            "playerId": "pid5693395"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:33:38",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000040-1": [
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid4511013",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jd1 2c2 8c3 5h4",
            "rows": "Ad0 Kc1 9c4/4h0 4c0 4s2 6s2 7d3/Td0 Qc0 Ts1 Qh3 9s4",
            "win": -8,
            "playerId": "pid4511013"
        },
        {
            "inFantasy": false,
            "result": 8,
            "playerName": "pid5693395",
            "orderIndex": 0,
            "hero": true,
            "dead": "8d1 3d2 6d3 5s4",
            "rows": "Qs2 As3 Kd4/Jc0 2d1 2s1 3h2 7c4/5d0 6h0 7s0 8s0 9d3",
            "win": 7.8,
            "playerId": "pid5693395"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:34:38",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000041-1": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid4511013",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jh1 Th2 Qd3 Ks4",
            "rows": "Kd0 As1 4d3/3d0 6d1 5h2 9c4 9s4/7d0 7c0 Qh0 Jc2 Qs3",
            "win": 5.8,
            "playerId": "pid4511013"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5693395",
            "orderIndex": 1,
            "hero": true,
            "dead": "7s1 5d2 8c3 4s4",
            "rows": "9d1 Ad2 8d3/Td0 Jd0 Tc1 4c2 6s3/2h0 7h0 Kh0 2c4 3h4",
            "win": -6,
            "playerId": "pid5693395"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:36:13",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000042-1": [
        {
            "inFantasy": false,
            "result": -35,
            "playerName": "pid4511013",
            "orderIndex": 1,
            "hero": false,
            "dead": "Th1 9d2 Qs3 5h4",
            "rows": "Ad1 Td4 Qh4/2d0 8d0 2s1 4h2 4s3/5s0 Ts0 Js0 7s2 Ks3",
            "win": -35,
            "playerId": "pid4511013"
        },
        {
            "inFantasy": false,
            "result": 35,
            "playerName": "pid5693395",
            "orderIndex": 0,
            "hero": true,
            "dead": "6d1 Jh2 7d3 8h4",
            "rows": "Kd2 Kc3 Kh4/6h0 7h1 9h1 2h2 Ah3/2c0 8c0 9c0 Ac0 3c4",
            "win": 33.9,
            "playerId": "pid5693395"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:37:16",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000043-1": [
        {
            "inFantasy": false,
            "result": -32,
            "playerName": "pid4511013",
            "orderIndex": 0,
            "hero": false,
            "dead": "3c1 3d2 Ad3 5h4",
            "rows": "Kh0 3h1 7s4/6s0 9h0 8h2 Qd3 Qc3/Jh0 Jd0 Js1 4c2 6c4",
            "win": -32,
            "playerId": "pid4511013"
        },
        {
            "inFantasy": true,
            "result": 32,
            "playerName": "pid5693395",
            "orderIndex": 1,
            "hero": true,
            "dead": "5c0 7c0 9s0",
            "rows": "Jc0 Kc0 Ks0/2h0 2d0 2c0 Th0 Ts0/6h0 6d0 Ah0 Ac0 As0",
            "win": 31,
            "playerId": "pid5693395"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:38:05",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000044-1": [
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid4511013",
            "orderIndex": 1,
            "hero": false,
            "dead": "2d1 5d2 3h3 9c4",
            "rows": "Kc0 8s2 Th3/2s0 4c0 7c1 7s1 4h4/Jh0 Qh0 Js2 Qs3 2h4",
            "win": -14,
            "playerId": "pid4511013"
        },
        {
            "inFantasy": false,
            "result": 14,
            "playerName": "pid5693395",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qc1 9h2 3s3 6h4",
            "rows": "Ah0 5h4 5c4/4s0 5s0 7h2 3c3 6d3/9d0 Jd0 3d1 Ad1 Kd2",
            "win": 13.6,
            "playerId": "pid5693395"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:39:10",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000045-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid4511013",
            "orderIndex": 0,
            "hero": false,
            "dead": "7h1 9d2 2h3 Jc4",
            "rows": "Kd0 Ac1 8d3/5h0 4c2 Qc2 Qh3 5d4/3s0 4s0 9s0 Js1 5c4",
            "win": -6,
            "playerId": "pid4511013"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5693395",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qd1 4h2 2d3 3d4",
            "rows": "Kc0 As1 Jh3/6c0 8h2 9c2 6h3 Kh4/7d0 7c0 Th0 Td1 2s4",
            "win": 5.8,
            "playerId": "pid5693395"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:40:48",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000046-1": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid4511013",
            "orderIndex": 1,
            "hero": false,
            "dead": "8d1 5h2 9s3 8c4",
            "rows": "Ah0 Qc3 Kc3/2h0 Jd1 7c2 2s4 Jc4/Th0 Tc0 Qh0 Td1 Qd2",
            "win": 11.6,
            "playerId": "pid4511013"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5693395",
            "orderIndex": 0,
            "hero": true,
            "dead": "2d1 Js2 9h3 5d4",
            "rows": "Ac0 Qs3 9c4/6c0 6s0 8h1 8s2 Jh3/3s0 Ks0 3d1 3h2 4h4",
            "win": -12,
            "playerId": "pid5693395"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:41:58",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000047-1": [
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "pid4511013",
            "orderIndex": 0,
            "hero": false,
            "dead": "2h1 5h2 Qh3 5s4",
            "rows": "Ah0 Ks2 7s4/2d0 2s0 3s0 3d1 6h4/9d0 8d1 4d2 8c3 9c3",
            "win": -21,
            "playerId": "pid4511013"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "pid5693395",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jd1 Jh2 3h3 5c4",
            "rows": "Ad0 As1 8h3/6d0 9s0 6c2 Tc2 9h4/7h0 7c0 Kd1 Kc3 Kh4",
            "win": 20.4,
            "playerId": "pid5693395"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:43:28",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000048-1": [
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid4511013",
            "orderIndex": 1,
            "hero": false,
            "dead": "5c1 8c2 5s3 Kc4",
            "rows": "Kh0 Ks3 As3/2h1 8h1 5h2 6h2 Ah4/2d0 6d0 7d0 Jd0 Ad4",
            "win": -20,
            "playerId": "pid4511013"
        },
        {
            "inFantasy": true,
            "result": 20,
            "playerName": "pid5693395",
            "orderIndex": 0,
            "hero": true,
            "dead": "6s0 9s0 Jh0",
            "rows": "Qh0 Qc0 Qs0/2c0 4c0 7c0 Jc0 Ac0/3h0 3d0 Th0 Td0 Tc0",
            "win": 19.4,
            "playerId": "pid5693395"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:44:07",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000049-1": [
        {
            "inFantasy": true,
            "result": -9,
            "playerName": "pid4511013",
            "orderIndex": 0,
            "hero": false,
            "dead": "6d0 3h1",
            "rows": "Kc0 Ad0 As0/9d0 9c0 Jh0 Jc0 Qd0/4h0 5c0 6s0 7c0 8s0",
            "win": -9,
            "playerId": "pid4511013"
        },
        {
            "inFantasy": true,
            "result": 9,
            "playerName": "pid5693395",
            "orderIndex": 1,
            "hero": true,
            "dead": "5s0 2s0 9s0",
            "rows": "Ts0 Qh0 Qs0/3c0 4c0 6c0 8c0 Tc0/4d0 5d0 8d0 Jd0 Kd0",
            "win": 8.7,
            "playerId": "pid5693395"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:44:51",
    "roomId": "21931339"
}


{
    "stakes": 1,
    "handData": {"210330110554-21931339-0000050-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid4511013",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jd1 4d2 5d3 2d4",
            "rows": "Ks0 Kh3 Ah4/Qc0 Td1 2h2 Tc2 Qh3/5h0 7d0 8s0 9c1 5s4",
            "win": 0,
            "playerId": "pid4511013"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5693395",
            "orderIndex": 0,
            "hero": true,
            "dead": "8h1 6d2 3d3 9d4",
            "rows": "Ac1 As2 6c4/2c0 3h0 4c0 3c1 4h2/7s0 Js0 7h3 Kc3 3s4",
            "win": 0,
            "playerId": "pid5693395"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "2550563",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 06:46:03",
    "roomId": "21931339"
}


