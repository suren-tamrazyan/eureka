


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000170-1": [
        {
            "inFantasy": false,
            "result": 4,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "Td1 Qc2 8c3 3s4",
            "rows": "Jc3 9c4 Jh4/2d0 3c0 3d1 2h2 7d3/6s0 7c0 8d0 9h1 Th2",
            "win": 0.8,
            "playerId": "pid5684226"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5118808",
            "orderIndex": 2,
            "hero": false,
            "dead": "Jd1 4s2 As3 4c4",
            "rows": "7h0 Kd1 Ts4/2c0 9d0 2s2 Js2 5s4/5h0 5c0 Qd1 5d3 Qh3",
            "win": -1.2,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": 2,
            "playerName": "pid1503276",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qs1 4h2 Tc3 6c4",
            "rows": "Kc0 Ks3 Ah4/3h0 Ad1 Ac1 4d2 Kh3/6d0 7s0 8s0 8h2 6h4",
            "win": 0.4,
            "playerId": "pid1503276"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:43:35",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000171-1": [
        {
            "inFantasy": false,
            "result": -26,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qs1 8c2 4h3 7c4",
            "rows": "Ad1 Kd4 Kc4/2h0 5c0 2d2 4c2 5d3/7s0 8d0 Tc0 Jd1 9s3",
            "win": -5.2,
            "playerId": "pid5684226"
        },
        {
            "inFantasy": false,
            "result": 7,
            "playerName": "pid5118808",
            "orderIndex": 1,
            "hero": false,
            "dead": "9h1 4d2 2s3 7h4",
            "rows": "5h3 Ac3 5s4/3s0 6c0 6s1 6d2 3c4/Jh0 Qh0 Qc0 Js1 Jc2",
            "win": 1.4,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": true,
            "result": 19,
            "playerName": "pid1503276",
            "orderIndex": 2,
            "hero": false,
            "dead": "8s0 9c1",
            "rows": "Ts0 Ah0 As0/3d0 7d0 9d0 Td0 Qd0/3h0 6h0 8h0 Th0 Kh0",
            "win": 3.7,
            "playerId": "pid1503276"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:45:01",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000172-1": [
        {
            "inFantasy": true,
            "result": 48,
            "playerName": "pid5684226",
            "orderIndex": 2,
            "hero": true,
            "dead": "7h0 3c0",
            "rows": "8c0 9d0 Qs0/4h0 4s0 5h0 5d0 5c0/Th0 Tc0 Kd0 Kc0 Ks0",
            "win": 9.3,
            "playerId": "pid5684226"
        },
        {
            "inFantasy": false,
            "result": -24,
            "playerName": "pid5118808",
            "orderIndex": 0,
            "hero": false,
            "dead": "7d1 3d2 7s3 2s4",
            "rows": "Kh0 Ac1 As3/2h0 4d0 6d0 6s1 6c2/9c0 Qc2 Jc3 Ts4 Jd4",
            "win": -4.8,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": -24,
            "playerName": "pid1503276",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qd1 3s2 9h3 9s4",
            "rows": "Ad1 Ah3 Qh4/2d0 4c0 5s0 2c2 Td4/7c0 8d0 6h1 8s2 8h3",
            "win": -4.8,
            "playerId": "pid1503276"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:45:59",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000173-1": [
        {
            "inFantasy": false,
            "result": -13,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "2h1 Ts2 Js3 2c4",
            "rows": "3h1 7s2 2s3/5s0 7h0 8h1 4c2 Ac4/2d0 8d0 Ad0 3d3 5d4",
            "win": -2.6,
            "playerId": "pid5684226"
        },
        {
            "inFantasy": false,
            "result": 36,
            "playerName": "pid5118808",
            "orderIndex": 2,
            "hero": false,
            "dead": "3c1 Jd2 6d3 Tc4",
            "rows": "9d0 Kc0 Kd1/4s0 4h2 6h2 6c3 Jc4/Qc0 Qs0 Qd1 Ks3 Kh4",
            "win": 7,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": -23,
            "playerName": "pid1503276",
            "orderIndex": 0,
            "hero": false,
            "dead": "5c1 8c2 3s3 4d4",
            "rows": "Ah0 Qh3 Th4/5h0 7d1 7c1 Jh2 6s4/9h0 9c0 Td0 9s2 8s3",
            "win": -4.6,
            "playerId": "pid1503276"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:47:38",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000174-1": [
        {
            "inFantasy": false,
            "result": -31,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "5s1 7c2 4c3 Jh4",
            "rows": "Kh2 Kc2 7h3/8s0 9c0 Ts0 8h3 Tc4/5d0 Qd0 6d1 9d1 3s4",
            "win": -6.2,
            "playerId": "pid5684226"
        },
        {
            "inFantasy": true,
            "result": 26,
            "playerName": "pid5118808",
            "orderIndex": 1,
            "hero": false,
            "dead": "2d0 2h1",
            "rows": "Qh0 Ad0 Ac0/3h0 3c0 4s0 Jd0 Jc0/5c0 6s0 7d0 8d0 9h0",
            "win": 5,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid1503276",
            "orderIndex": 2,
            "hero": false,
            "dead": "8c1 2s2 3d3 2c4",
            "rows": "Kd0 Ks2 7s4/4d0 5h0 6c0 6h1 4h3/Qs0 Th1 Qc2 Js3 Td4",
            "win": 1,
            "playerId": "pid1503276"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:48:41",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000175-1": [
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "pid5684226",
            "orderIndex": 2,
            "hero": true,
            "dead": "Js1 Tc2 Jc3 5d4",
            "rows": "Kc0 Qs2 Ad4/4s0 7d1 2c2 2d3 5h4/8d0 8s0 9s0 9d1 9h3",
            "win": 1.7,
            "playerId": "pid5684226"
        },
        {
            "inFantasy": false,
            "result": -28,
            "playerName": "pid5118808",
            "orderIndex": 0,
            "hero": false,
            "dead": "4c1 3h2 3d3 2h4",
            "rows": "Kh0 Ac1 Kd2/Td0 Qc2 6d3 Jh3 Th4/2s0 6s0 As0 5s1 3c4",
            "win": -5.6,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": true,
            "result": 19,
            "playerName": "pid1503276",
            "orderIndex": 1,
            "hero": false,
            "dead": "3s0 5c1",
            "rows": "8c0 9c0 Qd0/Ts0 Jd0 Qh0 Ks0 Ah0/4h0 4d0 7h0 7c0 7s0",
            "win": 3.7,
            "playerId": "pid1503276"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:50:11",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000176-1": [
        {
            "inFantasy": false,
            "result": 37,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "3s1 Ts2 5h3 2h4",
            "rows": "Ac0 5d2 As3/7d0 7s0 6s1 4h2 6h4/Js0 Kd0 Jc1 Jh3 Kc4",
            "win": 7.2,
            "playerId": "pid5684226"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5118808",
            "orderIndex": 2,
            "hero": false,
            "dead": "5s1 7h2 4c3 3d4",
            "rows": "8c2 Jd3 Ks3/3h0 9d0 9c0 6c2 6d4/Th0 Tc0 2s1 Td1 4s4",
            "win": -2,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": -27,
            "playerName": "pid1503276",
            "orderIndex": 0,
            "hero": false,
            "dead": "8s1 9s2 2d3 8h4",
            "rows": "Kh0 Ad1 9h4/3c0 7c0 5c1 4d3 Ah4/Qd0 Qs0 Qh2 Qc2 8d3",
            "win": -5.4,
            "playerId": "pid1503276"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:52:06",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000177-1": [
        {
            "inFantasy": true,
            "result": 31,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "6c0 2h0 Td0",
            "rows": "Qc0 Qs0 Kc0/4d0 5h0 6h0 7h0 8d0/3s0 4s0 6s0 8s0 Js0",
            "win": 6,
            "playerId": "pid5684226"
        },
        {
            "inFantasy": false,
            "result": -33,
            "playerName": "pid5118808",
            "orderIndex": 1,
            "hero": false,
            "dead": "3c1 3d2 2d3 2c4",
            "rows": "Kh0 As1 Ad2/4c0 8c0 4h2 Jc3 Ah4/Qh0 Qd0 Ts1 Th3 7d4",
            "win": -6.6,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": 2,
            "playerName": "pid1503276",
            "orderIndex": 2,
            "hero": false,
            "dead": "8h1 Tc2 2s3 5c4",
            "rows": "Ac0 6d3 Jh4/5s0 7s0 7c1 3h2 5d3/9h0 Kd0 Ks1 9d2 9s4",
            "win": 0.4,
            "playerId": "pid1503276"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:53:09",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000178-1": [
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "pid5684226",
            "orderIndex": 2,
            "hero": true,
            "dead": "2s1 7s2 9c3 5d4",
            "rows": "Qd0 4s4 Ks4/6c0 Tc1 4d2 Kh3 Kd3/5h0 8h0 Qh0 9h1 Ah2",
            "win": -4.2,
            "playerId": "pid5684226"
        },
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid5118808",
            "orderIndex": 0,
            "hero": false,
            "dead": "9s1 6s2 Jd3 4h4",
            "rows": "Ad0 Qs4 As4/7c0 7h1 Ts1 Th2 5s3/8d0 8c0 Qc0 Js2 8s3",
            "win": 0.2,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": 20,
            "playerName": "pid1503276",
            "orderIndex": 1,
            "hero": false,
            "dead": "9d1 Jc2 5c3 Td4",
            "rows": "6h3 Ac3 6d4/2d0 2c0 4c0 2h2 Kc4/3h0 3s0 3c1 Jh1 3d2",
            "win": 3.9,
            "playerId": "pid1503276"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:54:43",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000179-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "Ts1 6s2 3c3 5s4",
            "rows": "Kc0 9s4 Jc4/3h0 Jh0 9h1 6h3 8h3/9d0 Qd0 6d1 Td2 Ad2",
            "win": -1.2,
            "playerId": "pid5684226"
        },
        {
            "inFantasy": true,
            "result": 55,
            "playerName": "pid5118808",
            "orderIndex": 2,
            "hero": false,
            "dead": "4c0 7h1 Ac2",
            "rows": "Qh0 Qc0 Qs0/2h0 3s0 4h0 5c0 As0/8d0 8c0 8s0 Kh0 Kd0",
            "win": 10.7,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": -49,
            "playerName": "pid1503276",
            "orderIndex": 0,
            "hero": false,
            "dead": "Tc1 9c2 Th3 6c4",
            "rows": "Ah1 5d2 Ks4/3d0 7c0 4s1 4d2 7s3/2d0 2c0 Js0 Jd3 7d4",
            "win": -9.8,
            "playerId": "pid1503276"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:56:11",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000180-1": [
        {
            "inFantasy": false,
            "result": -28,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "3d1 3h2 9d3 6c4",
            "rows": "9h2 2h3 Jc3/4s0 7h1 7d1 5d2 2d4/8d0 9c0 Js0 Qc0 Jd4",
            "win": -5.6,
            "playerId": "pid5684226"
        },
        {
            "inFantasy": true,
            "result": 68,
            "playerName": "pid5118808",
            "orderIndex": 1,
            "hero": false,
            "dead": "Td0 Th1 Ah2",
            "rows": "Qh0 Qd0 Qs0/2s0 3c0 4h0 5h0 6d0/3s0 6s0 7s0 8s0 As0",
            "win": 13.2,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": -40,
            "playerName": "pid1503276",
            "orderIndex": 2,
            "hero": false,
            "dead": "Ts1 9s2 5c3 5s4",
            "rows": "Ad0 Ac0 6h3/Tc0 4c2 8h2 7c4 8c4/Jh0 Ks0 Kd1 Kc1 Kh3",
            "win": -8,
            "playerId": "pid1503276"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:57:22",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000181-1": [
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid5684226",
            "orderIndex": 2,
            "hero": true,
            "dead": "3c1 9d2 Ts3 3d4",
            "rows": "Ac0 5h4 Kc4/5c0 7d0 Jh1 Jd1 7h2/2s0 Ks0 Kd2 4h3 4c3",
            "win": -3.6,
            "playerId": "pid5684226"
        },
        {
            "inFantasy": true,
            "result": 48,
            "playerName": "pid5118808",
            "orderIndex": 0,
            "hero": false,
            "dead": "2h0 8h1 6c2",
            "rows": "Th0 Jc0 Js0/4s0 6s0 7s0 8s0 9s0/2d0 5d0 8d0 Qd0 Ad0",
            "win": 9.3,
            "playerId": "pid5118808"
        },
        {
            "inFantasy": false,
            "result": -30,
            "playerName": "pid1503276",
            "orderIndex": 1,
            "hero": false,
            "dead": "7c1 6h2 8c3 Tc4",
            "rows": "Ah0 Kh1 Qs4/2c0 5s0 4d2 3s3 As4/9h0 Td0 Qc1 9c2 Qh3",
            "win": -6,
            "playerId": "pid1503276"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 00:59:34",
    "roomId": "21907751"
}


