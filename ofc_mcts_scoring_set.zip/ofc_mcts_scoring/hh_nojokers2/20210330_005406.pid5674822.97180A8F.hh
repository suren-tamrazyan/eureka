{
    "stakes": 20,
    "handData": {"210330045840-21910804-0000001-1": [
        {
            "inFantasy": true,
            "result": 22,
            "playerName": "pid2634961",
            "orderIndex": 0,
            "hero": false,
            "dead": "3c0 4c1 7c2",
            "rows": "Kh0 Kc0 Ks0/2h0 4h0 8h0 9h0 Th0/3s0 7s0 8s0 Js0 As0",
            "win": 427,
            "playerId": "pid2634961"
        },
        {
            "inFantasy": true,
            "result": -22,
            "playerName": "pid4483271",
            "orderIndex": 1,
            "hero": false,
            "dead": "3d0",
            "rows": "6d0 8d0 Kd0/5c0 6c0 8c0 Jc0 Qc0/3h0 5h0 7h0 Jh0 Ah0",
            "win": -440,
            "playerId": "pid4483271"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": false,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 21:54:06",
    "roomId": "21910804"
}


{
    "stakes": 20,
    "handData": {"210330045840-21910804-0000002-1": [
        {
            "inFantasy": true,
            "result": 17,
            "playerName": "pid2634961",
            "orderIndex": 1,
            "hero": false,
            "dead": "7c0 Th1 Kd2",
            "rows": "Jd0 Js0 Ac0/4h0 4d0 4s0 8c0 8s0/2c0 3h0 3d0 3c0 3s0",
            "win": 330,
            "playerId": "pid2634961"
        },
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid4483271",
            "orderIndex": 0,
            "hero": false,
            "dead": "4c1 9c2 9h3 6s4",
            "rows": "Kc0 Qs3 Ks4/As0 2d2 Jc2 5d3 Ah4/6d0 7d0 Td0 8d1 Qd1",
            "win": -340,
            "playerId": "pid4483271"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": false,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 21:54:39",
    "roomId": "21910804"
}


{
    "stakes": 20,
    "handData": {"210330045840-21910804-0000003-1": [
        {
            "inFantasy": true,
            "result": -13,
            "playerName": "pid2634961",
            "orderIndex": 0,
            "hero": false,
            "dead": "7s0 3h1 2c2",
            "rows": "5h0 5c0 6h0/9s0 Ts0 Jc0 Qh0 Ks0/4d0 7d0 Jd0 Kd0 Ad0",
            "win": -260,
            "playerId": "pid2634961"
        },
        {
            "inFantasy": true,
            "result": 13,
            "playerName": "pid4483271",
            "orderIndex": 1,
            "hero": false,
            "dead": "3c0 Tc1",
            "rows": "6d0 6c0 Qs0/2h0 4h0 9h0 Th0 Jh0/5d0 5s0 8h0 8d0 8s0",
            "win": 252,
            "playerId": "pid4483271"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": false,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 21:55:47",
    "roomId": "21910804"
}


{
    "stakes": 20,
    "handData": {"210330045840-21910804-0000004-1": [
        {
            "inFantasy": false,
            "result": 22,
            "playerName": "pid4483271",
            "orderIndex": 1,
            "hero": false,
            "dead": "4h1 2h2 Ac3 4c4",
            "rows": "Kh0 Kc2 Jh4/7d0 Td0 Jd1 6d3 8d4/Qs0 As0 8s1 9s2 Ks3",
            "win": 427,
            "playerId": "pid4483271"
        },
        {
            "inFantasy": false,
            "result": -22,
            "playerName": "pid5674822",
            "orderIndex": 0,
            "hero": true,
            "dead": "7s1 8c2 6h3 Ts4",
            "rows": "Js0 6c1 7c3/2d0 9d0 Jc3 2c4 Qd4/7h0 Qh0 Ah1 5h2 8h2",
            "win": -440,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 21:56:42",
    "roomId": "21910804"
}


{
    "stakes": 20,
    "handData": {"210330045840-21910804-0000005-1": [
        {
            "inFantasy": true,
            "result": 4,
            "playerName": "pid4483271",
            "orderIndex": 0,
            "hero": false,
            "dead": "6h0 3d1",
            "rows": "8h0 Jd0 Qd0/6c0 9c0 Tc0 Jc0 Kc0/2h0 2s0 4h0 4d0 4s0",
            "win": 78,
            "playerId": "pid4483271"
        },
        {
            "inFantasy": false,
            "result": -4,
            "playerName": "pid5674822",
            "orderIndex": 1,
            "hero": true,
            "dead": "3h1 Js2 2c3 2d4",
            "rows": "Ah1 8c3 Ad4/5h0 Jh0 5d1 5s2 6s3/Kh0 Kd0 Ks0 3s2 7h4",
            "win": -80,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 21:57:31",
    "roomId": "21910804"
}


{
    "stakes": 20,
    "handData": {"210330045840-21910804-0000006-1": [
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid4483271",
            "orderIndex": 1,
            "hero": false,
            "dead": "7d1 Jd2 Qc3 2h4",
            "rows": "Ad0 Ac1 3d3/2s0 9c0 4d2 4c2 4s3/Qh0 Kh0 7h1 Qs4 Kd4",
            "win": -340,
            "playerId": "pid4483271"
        },
        {
            "inFantasy": true,
            "result": 17,
            "playerName": "pid5674822",
            "orderIndex": 0,
            "hero": true,
            "dead": "5c0 6c0 9s0",
            "rows": "Ks0 Ah0 As0/8h0 8s0 Td0 Tc0 Qd0/2c0 3h0 4h0 5h0 6h0",
            "win": 330,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 21:58:16",
    "roomId": "21910804"
}


{
    "stakes": 20,
    "handData": {"210330045840-21910804-0000007-1": [
        {
            "inFantasy": false,
            "result": 19,
            "playerName": "pid4483271",
            "orderIndex": 0,
            "hero": false,
            "dead": "Kc1 8d2 6d3 2h4",
            "rows": "Ad0 Ac0 8c3/3s1 Ts1 Th3 5d4 5s4/7h0 Jh0 Kh0 4h2 5h2",
            "win": 369,
            "playerId": "pid4483271"
        },
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid5674822",
            "orderIndex": 1,
            "hero": true,
            "dead": "5c1 Tc2 9h3 Qs4",
            "rows": "Kd0 Js2 3d3/2c0 3c0 3h2 7c3 Qd4/6s0 8s0 6h1 8h1 9d4",
            "win": -380,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 21:59:29",
    "roomId": "21910804"
}


{
    "stakes": 20,
    "handData": {"210330045840-21910804-0000008-1": [
        {
            "inFantasy": true,
            "result": 27,
            "playerName": "pid4483271",
            "orderIndex": 1,
            "hero": false,
            "dead": "2d0 6c1 5h2",
            "rows": "Jc0 Ac0 As0/4s0 6s0 Ts0 Js0 Qs0/7d0 7c0 8d0 8c0 8s0",
            "win": 417,
            "playerId": "pid4483271"
        },
        {
            "inFantasy": false,
            "result": -27,
            "playerName": "pid5674822",
            "orderIndex": 0,
            "hero": true,
            "dead": "9s1 Th2 5s3 Td4",
            "rows": "7s3 9h3 Ah4/Qd0 Jh1 2h2 2s2 3s4/2c0 3h0 4c0 5d0 6h1",
            "win": -430,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 22:00:22",
    "roomId": "21910804"
}


{
    "stakes": 20,
    "handData": {"210330045840-21910804-0000009-1": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "pid4483271",
            "orderIndex": 1,
            "hero": false,
            "dead": "6c1 6s2 4d3 Kh4",
            "rows": "Ah1 9d3 Ad4/3h0 Tc0 2d2 3d2 2c4/5h0 5d0 Qd0 Qh1 6h3",
            "win": 291,
            "playerId": "pid4483271"
        },
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid5674822",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h1 Js2 9s3 As4",
            "rows": "8d1 8h3 Ks3/9h0 Ts0 Th1 7d2 6d4/4c0 Jc0 Kc0 5c2 4s4",
            "win": -300,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 22:01:11",
    "roomId": "21910804"
}


{
    "stakes": 20,
    "handData": {"210330045840-21910804-0000010-1": [
        {
            "inFantasy": true,
            "result": 19,
            "playerName": "pid4483271",
            "orderIndex": 0,
            "hero": false,
            "dead": "9c0 Jd1 Th2",
            "rows": "Qc0 Qs0 Ac0/2c0 3d0 4s0 Kd0 Ks0/5h0 5d0 5s0 6h0 6s0",
            "win": 369,
            "playerId": "pid4483271"
        },
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid5674822",
            "orderIndex": 1,
            "hero": true,
            "dead": "9d1 Kh2 2s3 Qd4",
            "rows": "Ah1 Ad1 9h4/4h0 5c0 6d0 4c2 7d4/8d0 8s0 2h2 8h3 8c3",
            "win": -380,
            "playerId": "pid5674822"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9PHP",
    "joined": true,
    "clubId": "1223093",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-29 22:02:17",
    "roomId": "21910804"
}


