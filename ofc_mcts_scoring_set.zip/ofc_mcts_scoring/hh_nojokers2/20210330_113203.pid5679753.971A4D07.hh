{
    "stakes": 0.2,
    "handData": {"210330091909-21924920-0000000-1": [
        {
            "inFantasy": false,
            "result": 11,
            "playerName": "pid5478342",
            "orderIndex": 1,
            "hero": false,
            "dead": "Tc1 4d2 8c3 Ks4",
            "rows": "Ah0 As0 Jd4/5c0 Jh2 Js2 5d3 6c4/6d0 Td0 Qd1 Ad1 2d3",
            "win": 2.1,
            "playerId": "pid5478342"
        },
        {
            "inFantasy": false,
            "result": -11,
            "playerName": "pid5679753",
            "orderIndex": 0,
            "hero": true,
            "dead": "2c1 Ac2 5s3 9s4",
            "rows": "Kc0 3s3 Kh4/2s0 7h0 2h1 7c1 5h2/Th0 Ts0 8s2 8d3 7s4",
            "win": -2.2,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:32:03",
    "roomId": "21924920"
}


{
    "stakes": 0.2,
    "handData": {"210330091909-21924920-0000001-1": [
        {
            "inFantasy": true,
            "result": -4,
            "playerName": "pid5478342",
            "orderIndex": 0,
            "hero": false,
            "dead": "3d0 3h1 2s2",
            "rows": "9h0 Kd0 Ks0/6s0 8h0 8d0 Jh0 Jc0/2c0 5c0 9c0 Qc0 Ac0",
            "win": -0.8,
            "playerId": "pid5478342"
        },
        {
            "inFantasy": true,
            "result": 4,
            "playerName": "pid5679753",
            "orderIndex": 1,
            "hero": true,
            "dead": "6c0 2h0",
            "rows": "Qh0 Qd0 Kc0/4h0 5d0 6h0 7h0 8c0/5s0 7s0 9s0 Qs0 As0",
            "win": 0.8,
            "playerId": "pid5679753"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:33:06",
    "roomId": "21924920"
}


{
    "stakes": 0.2,
    "handData": {"210330091909-21924920-0000002-1": [
        {
            "inFantasy": false,
            "result": 7,
            "playerName": "pid5478342",
            "orderIndex": 2,
            "hero": false,
            "dead": "Th1 8h2 3s3 As4",
            "rows": "Qh0 5d3 Kh3/7d0 Kd1 7h2 Ts2 Ad4/2h0 Jh0 Jd0 2d1 5s4",
            "win": 1.4,
            "playerId": "pid5478342"
        },
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid5679753",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qs1 Js2 4h3 3d4",
            "rows": "Ks0 9s2 6h3/4c0 7c1 2c2 3c3 4d4/8d0 8c0 Td0 8s1 Kc4",
            "win": 1,
            "playerId": "pid5679753"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid1793219",
            "orderIndex": 1,
            "hero": false,
            "dead": "4s1 7s2 2s3 6c4",
            "rows": "Qd0 Ac1 Ah2/5h0 6d0 3h1 6s2 5c3/9h0 Jc0 9c3 Tc4 Qc4",
            "win": -2.4,
            "playerId": "pid1793219"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:34:51",
    "roomId": "21924920"
}


{
    "stakes": 0.2,
    "handData": {"210330091909-21924920-0000003-1": [
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid5478342",
            "orderIndex": 1,
            "hero": false,
            "dead": "9h1 7h2 9c3 Jd4",
            "rows": "Kd0 Kh2 Th3/5h0 Ac0 4d1 5c3 Jh4/9s0 Js0 8s1 6s2 As4",
            "win": -3.2,
            "playerId": "pid5478342"
        },
        {
            "inFantasy": false,
            "result": 32,
            "playerName": "pid5679753",
            "orderIndex": 2,
            "hero": true,
            "dead": "2s1 4c2 6c3 7c4",
            "rows": "Kc0 Qh3 Ks4/8h0 3s2 Jc2 8d3 3d4/5d0 6d0 7d0 3c1 4s1",
            "win": 6.2,
            "playerId": "pid5679753"
        },
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid1793219",
            "orderIndex": 0,
            "hero": false,
            "dead": "5s1 2d2 Ts3 Tc4",
            "rows": "Ah1 Ad2 Qd3/6h0 4h1 2h2 3h3 2c4/8c0 9d0 Td0 Qc0 Qs4",
            "win": -3.2,
            "playerId": "pid1793219"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:37:12",
    "roomId": "21924920"
}


{
    "stakes": 0.2,
    "handData": {"210330091909-21924920-0000004-1": [
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid5478342",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qs1 4d2 Ts3 6d4",
            "rows": "Kh0 Qh1 9c4/5s0 Ad0 As1 Tc2 3d3/2c0 Jc0 2s2 9s3 9h4",
            "win": -3.2,
            "playerId": "pid5478342"
        },
        {
            "inFantasy": true,
            "result": 44,
            "playerName": "pid5679753",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jd0 3s0",
            "rows": "Qc0 Kd0 Ks0/5d0 6c0 7c0 8s0 9d0/2h0 4h0 8h0 Jh0 Ah0",
            "win": 8.5,
            "playerId": "pid5679753"
        },
        {
            "inFantasy": false,
            "result": -28,
            "playerName": "pid1793219",
            "orderIndex": 2,
            "hero": false,
            "dead": "5c1 6h2 3h3 4c4",
            "rows": "Ac1 Qd3 8d4/Th0 Td0 7d2 8c2 7h3/4s0 6s0 7s0 Js1 5h4",
            "win": -5.6,
            "playerId": "pid1793219"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:38:34",
    "roomId": "21924920"
}


{
    "stakes": 0.2,
    "handData": {"210330091909-21924920-0000005-1": [
        {
            "inFantasy": false,
            "result": 2,
            "playerName": "pid5679753",
            "orderIndex": 1,
            "hero": true,
            "dead": "6c1 5h2 3d3 Qd4",
            "rows": "Ac0 Kc3 As4/2d0 3s0 2h1 9h2 9c3/7h0 Jc0 Ts1 Th2 Jh4",
            "win": 0.4,
            "playerId": "pid5679753"
        },
        {
            "inFantasy": false,
            "result": -2,
            "playerName": "pid1793219",
            "orderIndex": 0,
            "hero": false,
            "dead": "2c1 Kd2 9s3 2s4",
            "rows": "Ks1 7s2 Kh2/6s0 8s0 5s1 Ah3 Ad3/4h0 4s0 Tc0 4d4 Jd4",
            "win": -0.4,
            "playerId": "pid1793219"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:39:50",
    "roomId": "21924920"
}


{
    "stakes": 0.2,
    "handData": {"210330091909-21924920-0000006-1": [
        {
            "inFantasy": true,
            "result": 25,
            "playerName": "pid5679753",
            "orderIndex": 0,
            "hero": true,
            "dead": "8h0 4s0 6c0",
            "rows": "9c0 Ah0 Ac0/2c0 2s0 7h0 7d0 7s0/Th0 Tc0 Ts0 Kh0 Ks0",
            "win": 4.8,
            "playerId": "pid5679753"
        },
        {
            "inFantasy": true,
            "result": -25,
            "playerName": "pid1793219",
            "orderIndex": 1,
            "hero": false,
            "dead": "3c0 5c1",
            "rows": "Jh0 Jd0 As0/8s0 9s0 Td0 Kd0 Kc0/2d0 3s0 4h0 5h0 6h0",
            "win": -5,
            "playerId": "pid1793219"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:40:31",
    "roomId": "21924920"
}


