{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000000-1": [
        {
            "inFantasy": false,
            "result": -11,
            "playerName": "pid4879184",
            "orderIndex": 1,
            "hero": false,
            "dead": "6c1 2s2 Jc3 9d4",
            "rows": "Ad0 Jh3 Kd4/9h0 9s0 3s1 4c2 3c3/Th0 Qs0 Ts1 7s2 Td4",
            "win": -55,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": false,
            "result": 11,
            "playerName": "pid5688837",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qh1 Jd2 As3 6h4",
            "rows": "Kh0 Qd4 Ac4/2d0 5d1 5c2 4d3 4s3/8c0 8s0 9c0 8h1 8d2",
            "win": 53.3,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:08:11",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000001-1": [
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "pid4879184",
            "orderIndex": 0,
            "hero": false,
            "dead": "3s1 Ah2 5h3 4s4",
            "rows": "Kh1 5s4 9c4/2c0 4d0 2d2 2s3 6c3/8s0 Td0 Jh0 Qd1 9s2",
            "win": -45,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "pid5688837",
            "orderIndex": 1,
            "hero": true,
            "dead": "7s1 5c2 Ts3 6s4",
            "rows": "Kd0 Jd1 Kc3/4h0 Ac0 Ad2 3d4 Jc4/7c0 8c0 Tc1 3c2 4c3",
            "win": 43.6,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:09:15",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000002-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid4879184",
            "orderIndex": 1,
            "hero": false,
            "dead": "6h1 4h2 5s3 3s4",
            "rows": "Ac1 6s3 9c4/2h0 8s0 Qh2 Qs2 8h4/Th0 Tc0 Jc0 Td1 Jd3",
            "win": -30,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "pid5688837",
            "orderIndex": 0,
            "hero": true,
            "dead": "6d0 3h0",
            "rows": "Qd0 Qc0 As0/7d0 8c0 9s0 Kc0 Ks0/2d0 2c0 2s0 4c0 4s0",
            "win": 29.1,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:09:48",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000003-1": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid4879184",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qc1 5h2 6c3 7c4",
            "rows": "Ks0 4h2 Jc4/9c0 Td0 8d1 7d2 7h4/3h0 Jh0 3d1 5d3 5s3",
            "win": 29.1,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5688837",
            "orderIndex": 1,
            "hero": true,
            "dead": "8s1 9s2 2h3 Ad4",
            "rows": "Kh0 Ah2 Ts4/2c0 Tc0 2s1 5c2 Th3/Qd0 Qs0 4d1 7s3 8h4",
            "win": -30,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:11:08",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000004-1": [
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "pid4879184",
            "orderIndex": 1,
            "hero": false,
            "dead": "Kh1 6d2 6h3 3h4",
            "rows": "8d1 Qd3 Ac4/5c0 Ts0 9d1 Ks2 Tc3/2d0 2s0 7h0 2h2 4d4",
            "win": -25,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid5688837",
            "orderIndex": 0,
            "hero": true,
            "dead": "3c1 4s2 8s3 3d4",
            "rows": "Ah0 Th3 8h4/5s0 5h1 5d1 7c2 6c3/Td0 Jh0 Qs0 8c2 9c4",
            "win": 24.2,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:12:26",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000005-1": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid4879184",
            "orderIndex": 0,
            "hero": false,
            "dead": "5s1 6d2 Td3 4s4",
            "rows": "6s1 Ad1 Jd2/4d0 8d0 9s0 8s3 6h4/2h0 Qh0 8h2 Qc3 9h4",
            "win": 29.1,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5688837",
            "orderIndex": 1,
            "hero": true,
            "dead": "Kd1 6c2 Qs3 Kh4",
            "rows": "Ah0 As1 Qd3/3s0 5d0 5c0 2c3 7c4/Jc0 Js1 Tc2 Ts2 4c4",
            "win": -30,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:13:51",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000006-1": [
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "pid4879184",
            "orderIndex": 1,
            "hero": false,
            "dead": "5d1 9c2 2d3 4d4",
            "rows": "Ad1 8s3 Jc3/3d0 8h0 Tc0 8d1 9s4/Qs0 Ks0 6h2 Qc2 Ts4",
            "win": -25,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid5688837",
            "orderIndex": 0,
            "hero": true,
            "dead": "Js1 5c2 Kd3 7d4",
            "rows": "Ac2 5h4 Td4/2c0 4c0 2s1 6d3 6s3/4h0 7h0 Qh0 Kh1 9h2",
            "win": 24.2,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:15:10",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000007-1": [
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid4879184",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jh1 8c2 9c3 6d4",
            "rows": "Ks0 Qd3 8s4/3d0 2s1 6h1 6s2 Kc4/4d0 4s0 Th0 Tc2 8d3",
            "win": -90,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "pid5688837",
            "orderIndex": 1,
            "hero": true,
            "dead": "5s1 5d2 9s3 3s4",
            "rows": "Kd0 Js2 Kh3/4c0 Ah0 Ad0 2h4 As4/8h0 Ts1 Jc1 9d2 Qc3",
            "win": 87.3,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:16:22",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000008-1": [
        {
            "inFantasy": false,
            "result": -11,
            "playerName": "pid4879184",
            "orderIndex": 1,
            "hero": false,
            "dead": "9h1 5d2 4d3 5c4",
            "rows": "Qh0 Qd1 6s4/2s0 Th0 2d1 Ks3 Td4/6c0 7c0 4c2 8c2 5s3",
            "win": -55,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": true,
            "result": 11,
            "playerName": "pid5688837",
            "orderIndex": 0,
            "hero": true,
            "dead": "5h0 2h0",
            "rows": "Tc0 Kh0 Kc0/4h0 4s0 8s0 Jh0 Jd0/3c0 3s0 Ah0 Ac0 As0",
            "win": 53.3,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:16:57",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000009-1": [
        {
            "inFantasy": true,
            "result": 19,
            "playerName": "pid4879184",
            "orderIndex": 0,
            "hero": false,
            "dead": "Ks0",
            "rows": "Tc0 Ts0 As0/5h0 6c0 7h0 8h0 9c0/2d0 4d0 Jd0 Kd0 Ad0",
            "win": 92.1,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid5688837",
            "orderIndex": 1,
            "hero": true,
            "dead": "3h1 Td2 7d3 3c4",
            "rows": "Ah1 Qd2 Kh3/5s0 6s0 6h1 2h2 9d3/4h0 4c0 Jh0 4s4 6d4",
            "win": -95,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:17:45",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000010-1": [
        {
            "inFantasy": false,
            "result": 8,
            "playerName": "pid4879184",
            "orderIndex": 1,
            "hero": false,
            "dead": "Th1 Jd2 Td3 5h4",
            "rows": "Qh0 Ah3 Qd4/3c0 7c0 Kd1 3d2 7h2/2s0 8s0 6s1 5s3 9s4",
            "win": 38.8,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid5688837",
            "orderIndex": 0,
            "hero": true,
            "dead": "2d1 6c2 7s3 9c4",
            "rows": "Ac0 9d2 7d3/5c0 Qs1 4d2 4s3 Ks4/2h0 3h0 9h0 6h1 Kh4",
            "win": -40,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:18:54",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000011-1": [
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "pid4879184",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qs0",
            "rows": "Jh0 Jc0 Kd0/3c0 3s0 8h0 8d0 8s0/7h0 7c0 9h0 9c0 9s0",
            "win": 145.5,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": false,
            "result": -30,
            "playerName": "pid5688837",
            "orderIndex": 1,
            "hero": true,
            "dead": "5d1 4d2 4h3 Ad4",
            "rows": "Ah1 Ks3 3d4/4c0 4s0 7d0 5c2 7s2/6c0 6s0 9d1 8c3 2s4",
            "win": -150,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:19:54",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000012-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid4879184",
            "orderIndex": 1,
            "hero": false,
            "dead": "7s1 4d2 2s3 6d4",
            "rows": "Ac0 7d4 Jd4/3c0 8h0 Qs2 8d3 Qc3/Jh0 Jc0 Kd1 Ks1 Js2",
            "win": -30,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5688837",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ad1 2d2 Kh3 7h4",
            "rows": "Ah0 As0 6c4/4c0 5c0 7c1 5s2 5d3/9h0 9d1 Ts2 9c3 5h4",
            "win": 29.1,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:21:03",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000013-1": [
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid4879184",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jd1 7d2 5c3 4c4",
            "rows": "6d3 6c4 Kd4/2c0 3d0 4s0 2s2 3c3/6h0 Th0 3h1 Ah1 8h2",
            "win": -75,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": true,
            "result": 15,
            "playerName": "pid5688837",
            "orderIndex": 1,
            "hero": true,
            "dead": "7h0 3s0 2d0",
            "rows": "4h0 4d0 Qd0/9s0 Td0 Jh0 Qh0 Ks0/8c0 9c0 Tc0 Jc0 Qc0",
            "win": 72.7,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:21:36",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000014-1": [
        {
            "inFantasy": false,
            "result": -22,
            "playerName": "pid4879184",
            "orderIndex": 1,
            "hero": false,
            "dead": "5h1 4h2 3h3 Qh4",
            "rows": "Kh0 8s2 Kd3/9s0 Ah0 6h1 Th4 Ts4/2d0 Td0 7d1 8d2 5d3",
            "win": -110,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": true,
            "result": 22,
            "playerName": "pid5688837",
            "orderIndex": 0,
            "hero": true,
            "dead": "4d0 7h0 Jd0",
            "rows": "9h0 9d0 Qd0/2c0 8c0 9c0 Qc0 Ac0/3s0 6s0 7s0 Ks0 As0",
            "win": 106.7,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:22:09",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000015-1": [
        {
            "inFantasy": false,
            "result": 32,
            "playerName": "pid4879184",
            "orderIndex": 0,
            "hero": false,
            "dead": "9s1 7c2 5c3 3d4",
            "rows": "Kd1 9h3 9c4/4h0 4c0 Th2 Ts3 5d4/6h0 6d0 Jh0 Js1 Jd2",
            "win": 155.2,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid3776916",
            "orderIndex": 1,
            "hero": false,
            "dead": "8h1 7s2 Qc3 3s4",
            "rows": "Ks0 Jc2 Kc3/Ah0 6s1 Ad1 5h2 4s4/2d0 4d0 9d0 Td3 3c4",
            "win": -80,
            "playerId": "pid3776916"
        },
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid5688837",
            "orderIndex": 2,
            "hero": true,
            "dead": "Kh1 5s2 Ac3 Tc4",
            "rows": "Qd0 Qh2 8c4/7h0 6c1 8d1 3h3 2c4/2s0 8s0 As0 Qs2 2h3",
            "win": -80,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:23:34",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000016-1": [
        {
            "inFantasy": false,
            "result": -28,
            "playerName": "pid4879184",
            "orderIndex": 2,
            "hero": false,
            "dead": "7s1 3c2 2s3 3h4",
            "rows": "Ks1 As3 5c4/5h0 5s0 6c1 6d2 4d3/9d0 9s0 Qc0 Qd2 6h4",
            "win": -140,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": false,
            "result": 17,
            "playerName": "pid3776916",
            "orderIndex": 0,
            "hero": false,
            "dead": "9c1 4c2 3s3 8d4",
            "rows": "Ad0 Kc2 Ac3/8c0 Tc0 8s1 8h2 9h3/Jh0 Qh0 Jc1 4s4 Jd4",
            "win": 82.4,
            "playerId": "pid3776916"
        },
        {
            "inFantasy": false,
            "result": 11,
            "playerName": "pid5688837",
            "orderIndex": 1,
            "hero": true,
            "dead": "Kd1 Kh2 2c3 2h4",
            "rows": "Qs2 Js3 Ah4/3d0 5d0 4h2 2d3 6s4/7d0 7c0 Ts0 7h1 Td1",
            "win": 53.3,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:25:05",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000017-1": [
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid4879184",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qs1 3d2 4d3 8d4",
            "rows": "Ac1 9c3 9h4/3c0 Kh2 Kc2 7d3 Qh4/6d0 7h0 9d0 Ts0 8h1",
            "win": -70,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": true,
            "result": 25,
            "playerName": "pid3776916",
            "orderIndex": 2,
            "hero": false,
            "dead": "7s0 6h1 9s2",
            "rows": "Qc0 Ad0 As0/2c0 2s0 Th0 Kd0 Ks0/4h0 4s0 5h0 5d0 5c0",
            "win": 121.2,
            "playerId": "pid3776916"
        },
        {
            "inFantasy": false,
            "result": -11,
            "playerName": "pid5688837",
            "orderIndex": 0,
            "hero": true,
            "dead": "7c1 2d2 Js3 5s4",
            "rows": "Ah2 8c3 Qd4/4c0 Tc0 6c1 6s1 2h4/3h0 Jh0 Jd0 3s2 Jc3",
            "win": -55,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:26:19",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000018-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid4879184",
            "orderIndex": 0,
            "hero": false,
            "dead": "5s1 Qc2 Kc3 3c4",
            "rows": "Kh0 Ks1 Ah4/2h0 4s0 As1 Ad3 6c4/Jh0 Js0 4d2 7s2 7c3",
            "win": -30,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": false,
            "result": -37,
            "playerName": "pid3776916",
            "orderIndex": 1,
            "hero": false,
            "dead": "4h1 7d2 2d3 9s4",
            "rows": "Th1 Ac2 Kd4/2c0 7h0 8s0 2s1 8d4/6d0 Jd0 Jc2 3d3 3s3",
            "win": -185,
            "playerId": "pid3776916"
        },
        {
            "inFantasy": false,
            "result": 43,
            "playerName": "pid5688837",
            "orderIndex": 2,
            "hero": true,
            "dead": "Ts1 Td2 Tc3 3h4",
            "rows": "9c2 4c3 9h4/5d0 5c0 6s0 5h1 6h3/Qh0 Qd0 8c1 8h2 Qs4",
            "win": 208.5,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:27:56",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000019-1": [
        {
            "inFantasy": true,
            "result": 52,
            "playerName": "pid4879184",
            "orderIndex": 2,
            "hero": false,
            "dead": "4d0 2d1",
            "rows": "Kd0 Ks0 As0/6c0 6s0 9d0 9c0 9s0/8h0 8d0 8c0 8s0 Jc0",
            "win": 252.2,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid3776916",
            "orderIndex": 0,
            "hero": false,
            "dead": "2h1 Jd2 5h3 Js4",
            "rows": "Ah0 Ad2 Qc4/Th0 6h1 6d1 7h2 7s4/2s0 3s0 4s0 3h3 3c3",
            "win": -100,
            "playerId": "pid3776916"
        },
        {
            "inFantasy": false,
            "result": -32,
            "playerName": "pid5688837",
            "orderIndex": 1,
            "hero": true,
            "dead": "7d1 5d2 7c3 2c4",
            "rows": "Ac0 Kc3 Qs4/4c0 Td0 Ts0 Tc1 5c4/Jh0 Qh1 4h2 9h2 Kh3",
            "win": -160,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:29:15",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000020-1": [
        {
            "inFantasy": true,
            "result": 19,
            "playerName": "pid4879184",
            "orderIndex": 1,
            "hero": false,
            "dead": "5c0 7h1",
            "rows": "Jd0 Qc0 Kd0/6h0 6d0 6c0 9c0 9s0/4d0 4c0 Th0 Td0 Tc0",
            "win": 92.1,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": true,
            "result": 35,
            "playerName": "pid3776916",
            "orderIndex": 2,
            "hero": false,
            "dead": "Ad0 7d1 Ac2",
            "rows": "8d0 8c0 8s0/2s0 3d0 4s0 5s0 As0/3h0 4h0 Jh0 Qh0 Kh0",
            "win": 169.7,
            "playerId": "pid3776916"
        },
        {
            "inFantasy": false,
            "result": -54,
            "playerName": "pid5688837",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qs1 5h2 Ts3 Qd4",
            "rows": "Ah1 Js3 Jc4/2h0 2c0 3s0 2d2 7c2/8h0 9h0 9d1 6s3 7s4",
            "win": -270,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:30:14",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000021-1": [
        {
            "inFantasy": false,
            "result": -36,
            "playerName": "pid4879184",
            "orderIndex": 0,
            "hero": false,
            "dead": "9d1 8h2 2s3 9s4",
            "rows": "Kd2 Ah3 7h4/3s0 4d0 3h1 5d1 5s3/6c0 8c0 Kc0 5c2 3d4",
            "win": -180,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": true,
            "result": 20,
            "playerName": "pid3776916",
            "orderIndex": 1,
            "hero": false,
            "dead": "5h0 Jd1 6s2",
            "rows": "Qh0 Qc0 Ac0/7c0 7s0 Td0 Ts0 Ks0/2h0 2d0 2c0 4h0 4s0",
            "win": 97,
            "playerId": "pid3776916"
        },
        {
            "inFantasy": false,
            "result": 16,
            "playerName": "pid5688837",
            "orderIndex": 2,
            "hero": true,
            "dead": "Jc1 6h2 Tc3 3c4",
            "rows": "As0 8s4 Ad4/4c0 Qs0 Qd2 Jh3 Js3/7d0 8d0 6d1 9c1 Th2",
            "win": 77.6,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:31:37",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000022-1": [
        {
            "inFantasy": false,
            "result": -2,
            "playerName": "pid4879184",
            "orderIndex": 2,
            "hero": false,
            "dead": "5d1 Kh2 7c3 2c4",
            "rows": "Qc0 Ac2 Ah3/6c0 7d0 7h2 6s3 Qd4/Jd0 Js0 3d1 3s1 6h4",
            "win": -10,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": false,
            "result": -32,
            "playerName": "pid3776916",
            "orderIndex": 0,
            "hero": false,
            "dead": "Ts1 8d2 3h3 2h4",
            "rows": "As0 3c2 Jh4/5c0 8s0 8c1 2d2 5s4/9h0 Qh0 Qs1 4h3 4c3",
            "win": -160,
            "playerId": "pid3776916"
        },
        {
            "inFantasy": true,
            "result": 34,
            "playerName": "pid5688837",
            "orderIndex": 1,
            "hero": true,
            "dead": "7s0 6d0 2s0",
            "rows": "8h0 Jc0 Ad0/4d0 4s0 9d0 9c0 9s0/Th0 Td0 Tc0 Kc0 Ks0",
            "win": 164.9,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:32:40",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000023-1": [
        {
            "inFantasy": true,
            "result": 35,
            "playerName": "pid4879184",
            "orderIndex": 1,
            "hero": false,
            "dead": "Td0 Jd1 8d2",
            "rows": "Kh0 Kd0 As0/4h0 5s0 6c0 7h0 8h0/2c0 3c0 4c0 Tc0 Qc0",
            "win": 169.7,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": false,
            "result": -32,
            "playerName": "pid3776916",
            "orderIndex": 2,
            "hero": false,
            "dead": "7d1 9s2 2s3 Kc4",
            "rows": "Ks0 Qs2 Jc3/6h0 Ac0 Ts2 5c3 7c4/3d0 5d0 9d1 Qd1 Ah4",
            "win": -160,
            "playerId": "pid3776916"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "pid5688837",
            "orderIndex": 0,
            "hero": true,
            "dead": "3s1 9c2 6s3 2h4",
            "rows": "6d1 8s2 Ad4/2d0 4d0 7s0 4s2 8c3/9h0 Qh0 Th1 5h3 3h4",
            "win": -15,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:33:40",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000024-1": [
        {
            "inFantasy": false,
            "result": 20,
            "playerName": "pid4879184",
            "orderIndex": 0,
            "hero": false,
            "dead": "8h1 6s2 Kd3 6d4",
            "rows": "Ah3 9d4 Jd4/4d0 Tc0 4c1 3c2 Td2/6h0 Jh0 Qh0 4h1 3h3",
            "win": 97,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid3776916",
            "orderIndex": 1,
            "hero": false,
            "dead": "6c1 7s2 4s3 As4",
            "rows": "Kc0 Th2 Kh3/7d0 5d1 Ad1 3s2 5h4/9h0 9c0 Jc0 7h3 2c4",
            "win": -80,
            "playerId": "pid3776916"
        },
        {
            "inFantasy": false,
            "result": -4,
            "playerName": "pid5688837",
            "orderIndex": 2,
            "hero": true,
            "dead": "7c1 Ts2 Ac3 2d4",
            "rows": "9s0 Ks1 Js4/2h0 5c0 5s1 2s2 8s4/3d0 Qd0 8c2 8d3 Qs3",
            "win": -20,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:35:11",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000025-1": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid4879184",
            "orderIndex": 2,
            "hero": false,
            "dead": "5h1 3h2 As3 Td4",
            "rows": "Jh3 2c4 2s4/7s0 8c0 Qc0 8d1 Qd2/3d0 5d0 4h1 6s2 7h3",
            "win": -60,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": false,
            "result": -7,
            "playerName": "pid3776916",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jc1 Qh2 9h3 9s4",
            "rows": "Ad1 2h3 9c4/8s0 4s2 7c2 Ac3 4d4/5c0 5s0 Th0 Tc0 Ts1",
            "win": -35,
            "playerId": "pid3776916"
        },
        {
            "inFantasy": false,
            "result": 19,
            "playerName": "pid5688837",
            "orderIndex": 1,
            "hero": true,
            "dead": "4c1 8h2 2d3 6c4",
            "rows": "Ah0 3c3 3s4/6d0 Qs0 Js2 9d3 Jd4/Kh0 Kc0 Kd1 Ks1 7d2",
            "win": 92.1,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:37:07",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000026-1": [
        {
            "inFantasy": false,
            "result": 42,
            "playerName": "pid4879184",
            "orderIndex": 1,
            "hero": false,
            "dead": "2d1 3h2 Td3 7d4",
            "rows": "Kd1 As3 Ah4/6d0 9s0 Qc1 6c2 6s3/5h0 6h0 Th0 Qh2 8h4",
            "win": 203.7,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid3776916",
            "orderIndex": 2,
            "hero": false,
            "dead": "Kc1 2s2 2c3 4s4",
            "rows": "Ac0 Kh3 Js4/3c0 7c0 7h1 3s2 2h3/8d0 9h0 Jc1 Jd2 9d4",
            "win": -75,
            "playerId": "pid3776916"
        },
        {
            "inFantasy": false,
            "result": -27,
            "playerName": "pid5688837",
            "orderIndex": 0,
            "hero": true,
            "dead": "8c1 Tc2 8s3 9c4",
            "rows": "Ad0 Qd2 4c4/3d0 5c0 5d1 Jh1 5s3/Ts0 Ks0 Qs2 7s3 4h4",
            "win": -135,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:38:24",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000027-1": [
        {
            "inFantasy": true,
            "result": 2,
            "playerName": "pid4879184",
            "orderIndex": 0,
            "hero": false,
            "dead": "3c0 3s1 4d2",
            "rows": "9s0 Kh0 Kc0/4h0 7h0 7c0 8h0 8s0/5c0 5s0 6h0 6d0 6c0",
            "win": 9.7,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": false,
            "result": 29,
            "playerName": "pid3776916",
            "orderIndex": 1,
            "hero": false,
            "dead": "6s1 Qc2 Jc3 2c4",
            "rows": "Kd0 Ah1 Ad4/2h0 5d1 9c2 5h3 9h4/Td0 Tc0 Ts0 Th2 Qh3",
            "win": 140.6,
            "playerId": "pid3776916"
        },
        {
            "inFantasy": false,
            "result": -31,
            "playerName": "pid5688837",
            "orderIndex": 2,
            "hero": true,
            "dead": "4s1 2d2 Ks3 2s4",
            "rows": "Qs0 Ac1 Qd3/7d0 8c0 7s1 3d3 3h4/Jd0 Js0 9d2 Jh2 As4",
            "win": -155,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:39:30",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000028-1": [
        {
            "inFantasy": false,
            "result": 33,
            "playerName": "pid4879184",
            "orderIndex": 2,
            "hero": false,
            "dead": "Kh1 3c2 Jd3 6c4",
            "rows": "Ad2 Ac3 Ts4/2h0 5h0 Qh2 4h3 Ah4/7h0 7s0 Jh0 7d1 7c1",
            "win": 160,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": true,
            "result": -10,
            "playerName": "pid3776916",
            "orderIndex": 0,
            "hero": false,
            "dead": "2s0 Jc1 8c2",
            "rows": "Qd0 Qc0 Kc0/2d0 3d0 8d0 9d0 Td0/3s0 5s0 9s0 Js0 As0",
            "win": -50,
            "playerId": "pid3776916"
        },
        {
            "inFantasy": true,
            "result": -23,
            "playerName": "pid5688837",
            "orderIndex": 1,
            "hero": true,
            "dead": "2c0",
            "rows": "Qs0 Kd0 Ks0/3h0 5d0 5c0 Th0 Tc0/4c0 4s0 6h0 6d0 6s0",
            "win": -115,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:40:37",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000029-1": [
        {
            "inFantasy": true,
            "result": 49,
            "playerName": "pid4879184",
            "orderIndex": 1,
            "hero": false,
            "dead": "Tc0 7h1 Qh2",
            "rows": "6d0 6c0 6s0/2d0 5d0 8d0 9d0 Kd0/5s0 7s0 8s0 Ts0 Ks0",
            "win": 237.6,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid3776916",
            "orderIndex": 2,
            "hero": false,
            "dead": "7c1 9h2 7d3 3h4",
            "rows": "Kh1 Qc2 5h4/3s0 4s0 8c2 Jd3 Js4/Ad0 Ac0 As0 Ah1 6h3",
            "win": -30,
            "playerId": "pid3776916"
        },
        {
            "inFantasy": false,
            "result": -43,
            "playerName": "pid5688837",
            "orderIndex": 0,
            "hero": true,
            "dead": "3c1 2s2 3d3 Jh4",
            "rows": "Kc1 Qd2 Jc3/4c0 5c0 8h2 4h3 Qs4/9c0 9s0 Td0 Th1 4d4",
            "win": -215,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:42:00",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000030-1": [
        {
            "inFantasy": true,
            "result": 49,
            "playerName": "pid4879184",
            "orderIndex": 0,
            "hero": false,
            "dead": "5c0 4s1 2c2",
            "rows": "Js0 Ah0 As0/2h0 4h0 8h0 Th0 Kh0/3h0 3c0 3s0 6d0 6s0",
            "win": 77.5,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "pid3776916",
            "orderIndex": 1,
            "hero": false,
            "dead": "Ts1 Td2 8c3 Ks4",
            "rows": "Qc1 Jc3 Qh4/6h0 7h0 6c1 5s2 5d4/Tc0 Jd0 Qd0 Kc2 Ac3",
            "win": -25,
            "playerId": "pid3776916"
        },
        {
            "inFantasy": false,
            "result": -44,
            "playerName": "pid5688837",
            "orderIndex": 2,
            "hero": true,
            "dead": "5h1 2d2 3d3 Ad4",
            "rows": "8d1 Kd2 4d3/4c0 9d0 Jh0 9h1 9c3/2s0 7s0 9s2 7c4 8s4",
            "win": -54.9,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:43:19",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000031-1": [
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid4879184",
            "orderIndex": 1,
            "hero": false,
            "dead": "6c1 4d2 3d3 2d4",
            "rows": "Kc0 7h3 Qc3/8c0 Jd0 5d1 Jc2 Qh4/3s0 Qs0 9s1 8s2 4s4",
            "win": -50,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": true,
            "result": 10,
            "playerName": "pid3776916",
            "orderIndex": 0,
            "hero": false,
            "dead": "2h0",
            "rows": "7d0 Ks0 As0/6s0 7s0 8h0 9h0 Tc0/2c0 3c0 4c0 9c0 Ac0",
            "win": 48.5,
            "playerId": "pid3776916"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": false,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:44:08",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000032-1": [
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid4879184",
            "orderIndex": 1,
            "hero": false,
            "dead": "4c1 Jd2 Ts3 Th4",
            "rows": "Kc0 8h1 8d4/3d0 9s0 As1 3h2 9h2/5h0 5s0 2h3 2c3 2s4",
            "win": -70,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": false,
            "result": 33,
            "playerName": "pid3776916",
            "orderIndex": 2,
            "hero": false,
            "dead": "7s1 7c2 6c3 7d4",
            "rows": "6h0 Ah0 Ad0/Jh1 Td2 9d3 9c4 Jc4/5c0 Qc0 Qh1 Qd2 Qs3",
            "win": 160,
            "playerId": "pid3776916"
        },
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid5688837",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ks1 5d2 7h3 Js4",
            "rows": "Kh2 Tc3 Kd3/4s0 6d0 6s0 2d2 4h4/3c0 8c0 3s1 8s1 Ac4",
            "win": -95,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:45:42",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000033-1": [
        {
            "inFantasy": false,
            "result": -39,
            "playerName": "pid4879184",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jd1 5c2 4s3 6h4",
            "rows": "Ks0 Qh2 Qd2/Ac0 3s1 4h1 Kh3 Td4/2d0 2s0 6c0 8c3 9h4",
            "win": -195,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": true,
            "result": 11,
            "playerName": "pid3776916",
            "orderIndex": 1,
            "hero": false,
            "dead": "3c0 4d1 2h2",
            "rows": "Tc0 Ad0 As0/6d0 6s0 7d0 7c0 9d0/8h0 9s0 Ts0 Jh0 Qc0",
            "win": 53.3,
            "playerId": "pid3776916"
        },
        {
            "inFantasy": true,
            "result": 28,
            "playerName": "pid5688837",
            "orderIndex": 2,
            "hero": true,
            "dead": "9c0 Th0",
            "rows": "Jc0 Kd0 Kc0/2c0 3d0 4c0 5h0 Ah0/5s0 7s0 8s0 Js0 Qs0",
            "win": 135.8,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:46:38",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000034-1": [
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid4879184",
            "orderIndex": 2,
            "hero": false,
            "dead": "5s1 3d2 Kd3 2d4",
            "rows": "As0 Kh2 Ks3/6s0 Jh0 9d1 Jd2 4d4/Qc0 Qs0 7h1 Qd3 5d4",
            "win": -70,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid3776916",
            "orderIndex": 0,
            "hero": false,
            "dead": "7s1 6h2 Js3 8h4",
            "rows": "Ac0 Ah1 Jc4/4s0 5h0 2h2 4h3 3c4/8c0 Th0 Tc1 8d2 Ts3",
            "win": -70,
            "playerId": "pid3776916"
        },
        {
            "inFantasy": false,
            "result": 28,
            "playerName": "pid5688837",
            "orderIndex": 1,
            "hero": true,
            "dead": "2s1 2c2 3s3 7c4",
            "rows": "3h3 9s4 Ad4/6d0 8s1 7d2 Td2 9h3/4c0 5c0 6c0 9c0 Kc1",
            "win": 135.8,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:48:21",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000035-1": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "pid4879184",
            "orderIndex": 1,
            "hero": false,
            "dead": "8d1 Ad2 4d3 Qs4",
            "rows": "Kc0 Kd2 2s3/2c0 7s0 2h1 5c1 7h2/Jc0 Js0 Td3 Ts4 Jh4",
            "win": 116.4,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": false,
            "result": -35,
            "playerName": "pid3776916",
            "orderIndex": 2,
            "hero": false,
            "dead": "4s1 6c2 3d3 Tc4",
            "rows": "Kh0 Ac3 3h4/4c0 8c0 4h1 3c2 8h3/7d0 9d0 Qd1 9s2 6d4",
            "win": -175,
            "playerId": "pid3776916"
        },
        {
            "inFantasy": false,
            "result": 11,
            "playerName": "pid5688837",
            "orderIndex": 0,
            "hero": true,
            "dead": "7c1 Ks2 5h3 3s4",
            "rows": "Ah0 Jd4 As4/2d0 6h0 6s1 9h3 9c3/5d0 5s0 8s1 Qh2 Qc2",
            "win": 53.3,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:49:29",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000036-1": [
        {
            "inFantasy": true,
            "result": 13,
            "playerName": "pid4879184",
            "orderIndex": 0,
            "hero": false,
            "dead": "3s0 2d1",
            "rows": "7h0 Kh0 Ks0/5h0 Td0 Tc0 Jh0 Jc0/4h0 4c0 4s0 6c0 6s0",
            "win": 63,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid3776916",
            "orderIndex": 1,
            "hero": false,
            "dead": "4d1 Ts2 3c3 Qc4",
            "rows": "As0 Jd3 Ad4/6d0 7d0 5c2 5s2 6h3/9h0 9c0 8h1 8d1 Qh4",
            "win": -30,
            "playerId": "pid3776916"
        },
        {
            "inFantasy": true,
            "result": -7,
            "playerName": "pid5688837",
            "orderIndex": 2,
            "hero": true,
            "dead": "7c0 2h0 5d0",
            "rows": "3h0 3d0 Ah0/8c0 9d0 Th0 Js0 Qd0/2s0 7s0 8s0 9s0 Qs0",
            "win": -35,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:50:15",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000037-1": [
        {
            "inFantasy": false,
            "result": -11,
            "playerName": "pid4879184",
            "orderIndex": 2,
            "hero": false,
            "dead": "Kh1 2c2 4d3 9h4",
            "rows": "Ah0 5c2 Kd3/7d0 8d0 8h1 9c2 9d4/6s0 Qs0 8s1 Ks3 3s4",
            "win": -55,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": true,
            "result": 46,
            "playerName": "pid3776916",
            "orderIndex": 0,
            "hero": false,
            "dead": "9s0 5s1 7h2",
            "rows": "6h0 6d0 Qd0/4c0 7c0 Tc0 Kc0 Ac0/5h0 Jh0 Jd0 Jc0 Js0",
            "win": 223.1,
            "playerId": "pid3776916"
        },
        {
            "inFantasy": false,
            "result": -35,
            "playerName": "pid5688837",
            "orderIndex": 1,
            "hero": true,
            "dead": "Ts1 7s2 4s3 As4",
            "rows": "Ad0 2d3 5d4/3c0 8c0 6c2 Qc2 3d3/Th0 Qh0 3h1 4h1 2s4",
            "win": -175,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:51:21",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000038-1": [
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid4879184",
            "orderIndex": 1,
            "hero": false,
            "dead": "Ks1 Th2 8h3 4d4",
            "rows": "Ad0 Ac0 6s3/3c0 7h0 2s1 2h2 Ts4/Qc0 Jh1 Qs2 4h3 9c4",
            "win": -80,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": true,
            "result": 32,
            "playerName": "pid3776916",
            "orderIndex": 2,
            "hero": false,
            "dead": "4c0 8c1 9s2",
            "rows": "3d0 3s0 Jd0/Td0 Js0 Qh0 Kc0 Ah0/2d0 2c0 5h0 5d0 5s0",
            "win": 155.2,
            "playerId": "pid3776916"
        },
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid5688837",
            "orderIndex": 0,
            "hero": true,
            "dead": "7c1 Qd2 5c3 9d4",
            "rows": "Kd0 Kh1 9h3/3h0 As1 4s2 7s4 8d4/6c0 7d0 8s0 6d2 6h3",
            "win": -80,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:52:45",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000039-1": [
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid4879184",
            "orderIndex": 0,
            "hero": false,
            "dead": "3c1 8c2 2h3 Qs4",
            "rows": "5s2 Th3 Qc4/4d0 Jd0 3d1 As3 4s4/5h0 6h0 9h0 7h1 8s2",
            "win": -80,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": false,
            "result": 16,
            "playerName": "pid5688837",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qd1 3s2 6d3 2s4",
            "rows": "Kc0 Jc4 Ks4/9d0 Ad0 2d2 2c2 Ac3/3h0 4h0 8h1 Kh1 Ah3",
            "win": 77.6,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:54:01",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000040-1": [
        {
            "inFantasy": false,
            "result": -4,
            "playerName": "pid4879184",
            "orderIndex": 1,
            "hero": false,
            "dead": "6c1 3d2 6d3 3c4",
            "rows": "Kc0 Ks1 Qd4/5d0 Ad0 Ac2 7d3 Tc4/4h0 Th0 9h1 8h2 Qh3",
            "win": -20,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": true,
            "result": 4,
            "playerName": "pid5688837",
            "orderIndex": 0,
            "hero": true,
            "dead": "2s0 8c0",
            "rows": "Jc0 Ah0 As0/2d0 3h0 4c0 5c0 6s0/7h0 8d0 9s0 Ts0 Js0",
            "win": 19.4,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:54:38",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000041-1": [
        {
            "inFantasy": true,
            "result": 25,
            "playerName": "pid4879184",
            "orderIndex": 0,
            "hero": false,
            "dead": "5d0 4d1",
            "rows": "8d0 Qh0 Qc0/3h0 6h0 7h0 Th0 Jh0/2c0 3c0 6c0 Tc0 Ac0",
            "win": 121.2,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": false,
            "result": -25,
            "playerName": "pid5688837",
            "orderIndex": 1,
            "hero": true,
            "dead": "9c1 Jc2 Td3 Ts4",
            "rows": "Kc0 Kd2 3d4/6d0 7d1 8s1 As2 2h4/5h0 5s0 Qs0 4h3 4s3",
            "win": -125,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:55:34",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000042-1": [
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "pid4879184",
            "orderIndex": 2,
            "hero": false,
            "dead": "2d1 5d2 Td3 4c4",
            "rows": "Kd0 Kh1 Tc3/3d0 3c0 2c2 6d2 2s4/8s0 Qc0 Qh1 8d3 Ad4",
            "win": -105,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": false,
            "result": 26,
            "playerName": "pid1251760",
            "orderIndex": 0,
            "hero": false,
            "dead": "5c1 Qd2 8h3 6s4",
            "rows": "Kc0 As2 Ac4/7h0 4h1 7d1 4d3 Qs4/9c0 Jc0 Js0 Jd2 Jh3",
            "win": 126.1,
            "playerId": "pid1251760"
        },
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "pid5688837",
            "orderIndex": 1,
            "hero": true,
            "dead": "9s1 9h2 Ks3 3s4",
            "rows": "Ts1 Th3 Ah4/3h0 5h1 4s2 6h3 2h4/5s0 6c0 7s0 9d0 8c2",
            "win": -25,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:57:14",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000043-1": [
        {
            "inFantasy": true,
            "result": -15,
            "playerName": "pid4879184",
            "orderIndex": 1,
            "hero": false,
            "dead": "2s0 5c1",
            "rows": "Ts0 Qs0 Kc0/2h0 3h0 4h0 6h0 Jh0/7d0 7s0 8h0 8d0 8s0",
            "win": -75,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": true,
            "result": 24,
            "playerName": "pid1251760",
            "orderIndex": 2,
            "hero": false,
            "dead": "Ks0 2d1 Qd2",
            "rows": "Td0 Tc0 Ah0/3c0 3s0 6d0 6c0 6s0/4d0 4c0 9h0 9d0 9s0",
            "win": 116.4,
            "playerId": "pid1251760"
        },
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "pid5688837",
            "orderIndex": 0,
            "hero": true,
            "dead": "3d1 Th2 Kd3 7h4",
            "rows": "Ad1 Kh2 As4/4s0 5d0 5s0 5h3 Js4/2c0 9c0 7c1 Ac2 Jc3",
            "win": -45,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:58:13",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000044-1": [
        {
            "inFantasy": false,
            "result": -25,
            "playerName": "pid4879184",
            "orderIndex": 0,
            "hero": false,
            "dead": "Th1 3h2 7d3 7c4",
            "rows": "Kc1 9s3 Jc4/2d0 5h0 6d0 6c2 Jh4/7s0 Js0 Qs1 2s2 4s3",
            "win": -125,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "pid1251760",
            "orderIndex": 1,
            "hero": false,
            "dead": "Kh1 2c2 9d3 2h4",
            "rows": "Ah0 As1 6s2/4h0 4d0 5d1 5c2 Ad4/Td0 Ts0 8c3 Tc3 Qc4",
            "win": -15,
            "playerId": "pid1251760"
        },
        {
            "inFantasy": true,
            "result": 28,
            "playerName": "pid5688837",
            "orderIndex": 2,
            "hero": true,
            "dead": "Jd0 8s0 Ks0",
            "rows": "Qh0 Qd0 Ac0/4c0 5s0 6h0 7h0 8h0/3d0 3c0 3s0 9h0 9c0",
            "win": 135.8,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 09:59:27",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000045-1": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid4879184",
            "orderIndex": 2,
            "hero": false,
            "dead": "9s1 6s2 4s3 Tc4",
            "rows": "Qc0 Kh3 Qd4/5d0 6d0 5c1 6c1 Th4/8h0 9h0 Td2 Jd2 7c3",
            "win": 14.5,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": true,
            "result": 33,
            "playerName": "pid1251760",
            "orderIndex": 0,
            "hero": false,
            "dead": "7s0 7h1 6h2",
            "rows": "Qs0 Ah0 Ac0/2d0 Jh0 Js0 Kd0 Kc0/3d0 3c0 4h0 4d0 4c0",
            "win": 160,
            "playerId": "pid1251760"
        },
        {
            "inFantasy": false,
            "result": -36,
            "playerName": "pid5688837",
            "orderIndex": 1,
            "hero": true,
            "dead": "8d1 8c2 3h3 Jc4",
            "rows": "As0 Ad2 9c4/2h0 2c0 7d0 Qh3 9d4/Ts0 3s1 5s1 Ks2 8s3",
            "win": -180,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:00:49",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000046-1": [
        {
            "inFantasy": true,
            "result": 28,
            "playerName": "pid4879184",
            "orderIndex": 1,
            "hero": false,
            "dead": "Td0",
            "rows": "Jd0 Kd0 Ac0/4h0 5s0 6h0 7d0 8c0/4s0 9s0 Ts0 Js0 Qs0",
            "win": 135.8,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid1251760",
            "orderIndex": 2,
            "hero": false,
            "dead": "Qh1 Qc2 Tc3 As4",
            "rows": "2h0 Qd3 Ks4/3s0 4d1 6c1 5c2 Ah3/6d0 7h0 9c0 Th2 6s4",
            "win": -40,
            "playerId": "pid1251760"
        },
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid5688837",
            "orderIndex": 0,
            "hero": true,
            "dead": "3h1 4c2 3d3 Jc4",
            "rows": "Ad0 Kc2 8d4/2c0 2s0 2d1 3c2 7s3/Jh0 Kh0 5h1 9h3 5d4",
            "win": -100,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:02:31",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000047-1": [
        {
            "inFantasy": false,
            "result": -7,
            "playerName": "pid4879184",
            "orderIndex": 0,
            "hero": false,
            "dead": "Ts1 2c2 9s3 4h4",
            "rows": "Qc1 Ks3 9c4/4s0 7s0 4d1 5d3 6s4/5h0 9h0 Th0 5s2 Tc2",
            "win": -35,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid1251760",
            "orderIndex": 1,
            "hero": false,
            "dead": "4c1 7c2 6h3 5c4",
            "rows": "Ac0 8c3 As3/2d0 3h0 9d1 3s2 Ad4/Kd0 Kc0 Jc1 Qd2 Ah4",
            "win": -95,
            "playerId": "pid1251760"
        },
        {
            "inFantasy": false,
            "result": 26,
            "playerName": "pid5688837",
            "orderIndex": 2,
            "hero": true,
            "dead": "Js1 2s2 Qs3 Jd4",
            "rows": "8s2 Qh3 8d4/3d0 7d1 6c2 6d3 3c4/2h0 7h0 Jh0 Kh0 8h1",
            "win": 126.1,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:04:11",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000048-1": [
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid4879184",
            "orderIndex": 2,
            "hero": false,
            "dead": "Ts1 4c2 2s3 4d4",
            "rows": "Ad1 3h3 3s3/8d0 9c0 Jh0 Jd1 5d4/Kd0 Kc0 6d2 6c2 Td4",
            "win": 4.8,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid1251760",
            "orderIndex": 0,
            "hero": false,
            "dead": "Ks1 Qd2 As3 6h4",
            "rows": "Ac0 Ah2 6s3/2h0 3d0 4h0 3c4 Qh4/7c0 7h1 7s1 5s2 Jc3",
            "win": -80,
            "playerId": "pid1251760"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "pid5688837",
            "orderIndex": 1,
            "hero": true,
            "dead": "8h1 5c2 Tc3 7d4",
            "rows": "Kh2 Qc3 Th4/2c0 9d0 2d1 9h1 5h2/8s0 Js0 Qs0 9s3 4s4",
            "win": 72.7,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:06:12",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000049-1": [
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid4879184",
            "orderIndex": 1,
            "hero": false,
            "dead": "8c1 Qc2 9d3 5s4",
            "rows": "Kh1 Qh3 Ac3/5c0 3h1 6d2 6c2 6s4/7d0 8d0 9s0 Js0 Jh4",
            "win": -90,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid1251760",
            "orderIndex": 2,
            "hero": false,
            "dead": "Ah1 5h2 Jc3 7h4",
            "rows": "Kc0 Ks1 7c2/2s0 6h0 4h2 4c3 3s4/9h0 Td0 9c1 Ts3 Qd4",
            "win": -90,
            "playerId": "pid1251760"
        },
        {
            "inFantasy": false,
            "result": 36,
            "playerName": "pid5688837",
            "orderIndex": 0,
            "hero": true,
            "dead": "3c1 Ad2 Th3 Tc4",
            "rows": "8h1 2h4 2d4/5d0 Jd0 3d2 4d3 Kd3/4s0 7s0 Qs0 As1 8s2",
            "win": 174.6,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:07:44",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000050-1": [
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid4879184",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qc1 4s2 4d3 8d4",
            "rows": "5s2 9s2 5h4/3c0 4c0 6h0 5d1 2s4/8s0 Jh0 9h1 7d3 Th3",
            "win": 48.5,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": false,
            "result": 17,
            "playerName": "pid1251760",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qh1 Kc2 Ah3 Tc4",
            "rows": "Kh0 Ad2 As2/2c0 7c0 8h1 8c1 7s3/6s0 Js0 Td3 6d4 6c4",
            "win": 82.4,
            "playerId": "pid1251760"
        },
        {
            "inFantasy": false,
            "result": -27,
            "playerName": "pid5688837",
            "orderIndex": 2,
            "hero": true,
            "dead": "7h1 Jc2 2h3 3d4",
            "rows": "Ac0 3s3 Jd3/3h0 4h0 5c0 9d2 9c2/Kd0 Ts1 Ks1 2d4 Qs4",
            "win": -135,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:09:36",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000051-1": [
        {
            "inFantasy": false,
            "result": -26,
            "playerName": "pid4879184",
            "orderIndex": 2,
            "hero": false,
            "dead": "8c1 Kd2 6d3 Td4",
            "rows": "7s2 9d2 4s3/2h0 Qh1 3h3 2d4 Qs4/3s0 6s0 Js0 Ks0 9s1",
            "win": -130,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": true,
            "result": 34,
            "playerName": "pid1251760",
            "orderIndex": 0,
            "hero": false,
            "dead": "4c0 6h1 2s2",
            "rows": "8s0 Jh0 Jc0/3d0 4d0 7d0 8d0 Qd0/5h0 5d0 5c0 9h0 9c0",
            "win": 164.9,
            "playerId": "pid1251760"
        },
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid5688837",
            "orderIndex": 1,
            "hero": true,
            "dead": "5s1 2c2 Tc3 6c4",
            "rows": "As0 Ac1 8h4/4h0 Ts0 7h2 7c2 Th4/Qc0 Kc0 Kh1 Ah3 Ad3",
            "win": -40,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:10:41",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000052-1": [
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid4879184",
            "orderIndex": 1,
            "hero": false,
            "dead": "7s1 4h2 4c3 2s4",
            "rows": "6s2 Ts2 4d3/3s0 5h0 9c1 3d4 6d4/8h0 Jc0 Js0 8d1 Jh3",
            "win": -85,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid1251760",
            "orderIndex": 2,
            "hero": false,
            "dead": "Ah1 Kc2 Tc3 3h4",
            "rows": "Kh0 Kd1 As4/2h0 2d2 2c3 Ac3 Qc4/5s0 6c0 7d0 8s1 9h2",
            "win": 14.5,
            "playerId": "pid1251760"
        },
        {
            "inFantasy": true,
            "result": 14,
            "playerName": "pid5688837",
            "orderIndex": 0,
            "hero": true,
            "dead": "3c0 5c0 7c0",
            "rows": "Qh0 Qs0 Ks0/6h0 7h0 8c0 9d0 Th0/5d0 Td0 Jd0 Qd0 Ad0",
            "win": 67.9,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:11:43",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000053-1": [
        {
            "inFantasy": false,
            "result": -31,
            "playerName": "pid4879184",
            "orderIndex": 0,
            "hero": false,
            "dead": "3c1 7c2 Jd3 Ah4",
            "rows": "Kc0 Qc2 Qd3/Ad0 Ac0 3h1 4h2 Qh4/5h0 8d0 8c1 Th3 Ts4",
            "win": -155,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": true,
            "result": 47,
            "playerName": "pid1251760",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jh0 Td1",
            "rows": "9h0 9c0 9s0/2h0 3s0 4c0 5d0 6c0/5s0 7s0 8s0 Ks0 As0",
            "win": 227.9,
            "playerId": "pid1251760"
        },
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid5688837",
            "orderIndex": 2,
            "hero": true,
            "dead": "4s1 Tc2 5c3 4d4",
            "rows": "3d0 Kd3 Kh4/2c0 Jc0 2s2 7d2 Js3/6s0 Qs0 6h1 6d1 8h4",
            "win": -80,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:13:09",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000054-1": [
        {
            "inFantasy": true,
            "result": -51,
            "playerName": "pid4879184",
            "orderIndex": 2,
            "hero": false,
            "dead": "2d0",
            "rows": "7s0 Jh0 Kd0/3d0 5h0 5s0 8h0 8c0/4c0 6c0 7c0 9c0 Qc0",
            "win": -255,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": true,
            "result": -12,
            "playerName": "pid1251760",
            "orderIndex": 0,
            "hero": false,
            "dead": "3h0 7h1",
            "rows": "Tc0 Ts0 Kc0/2c0 3s0 4h0 5c0 Ah0/7d0 8d0 9d0 Jd0 Qd0",
            "win": -60,
            "playerId": "pid1251760"
        },
        {
            "inFantasy": true,
            "result": 63,
            "playerName": "pid5688837",
            "orderIndex": 1,
            "hero": true,
            "dead": "4d0 3c0",
            "rows": "Ad0 Ac0 As0/2s0 4s0 9s0 Js0 Ks0/6h0 9h0 Th0 Qh0 Kh0",
            "win": 305.5,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:14:08",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000055-1": [
        {
            "inFantasy": false,
            "result": 2,
            "playerName": "pid4879184",
            "orderIndex": 1,
            "hero": false,
            "dead": "Js1 4s2 Ac3 7c4",
            "rows": "4c2 9d3 Qc4/3c0 4d0 7s0 5d1 6c4/6h0 8h0 Th1 5h2 7h3",
            "win": 9.7,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": false,
            "result": -38,
            "playerName": "pid1251760",
            "orderIndex": 2,
            "hero": false,
            "dead": "Td1 Ts2 9c3 Jc4",
            "rows": "As0 Ah2 Ad4/3d0 8c0 3s1 2h3 Ks4/9s0 Kd0 Qh1 Tc2 Jd3",
            "win": -190,
            "playerId": "pid1251760"
        },
        {
            "inFantasy": true,
            "result": 36,
            "playerName": "pid5688837",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jh0 9h0",
            "rows": "Qs0 Kh0 Kc0/3h0 4h0 5s0 6d0 7d0/2d0 2c0 2s0 8d0 8s0",
            "win": 174.6,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:15:20",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000056-1": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid4879184",
            "orderIndex": 0,
            "hero": false,
            "dead": "7h1 4h2 9h3 8h4",
            "rows": "Jh2 5h3 Td4/3d0 5d0 6d1 8d2 Kd3/3c0 8c0 9c0 Kc1 Jc4",
            "win": 29.1,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid1251760",
            "orderIndex": 1,
            "hero": false,
            "dead": "4d1 2c2 2d3 Ks4",
            "rows": "Kh0 Ah1 As1/3h0 3s0 Tc2 Qh3 Ts4/6s0 8s0 7s2 4c3 5s4",
            "win": 29.1,
            "playerId": "pid1251760"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5688837",
            "orderIndex": 2,
            "hero": true,
            "dead": "6c1 6h2 Qc3 5c4",
            "rows": "Ad0 Js2 Ac3/2s0 7d0 4s1 7c3 2h4/9s0 Th0 Qs1 9d2 Qd4",
            "win": -60,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:17:04",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000057-1": [
        {
            "inFantasy": false,
            "result": -49,
            "playerName": "pid4879184",
            "orderIndex": 2,
            "hero": false,
            "dead": "6h1 Kh2 Qd3 2h4",
            "rows": "Ah0 Ac1 8h4/3h0 4h0 5s0 4c2 5d2/Td0 Jh1 7d3 7s3 9c4",
            "win": -245,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": true,
            "result": -4,
            "playerName": "pid1251760",
            "orderIndex": 0,
            "hero": false,
            "dead": "5h0 8s1 4d2",
            "rows": "Jd0 Qh0 Qc0/3s0 9h0 9s0 Th0 Ts0/2c0 3c0 5c0 Jc0 Kc0",
            "win": -20,
            "playerId": "pid1251760"
        },
        {
            "inFantasy": true,
            "result": 53,
            "playerName": "pid5688837",
            "orderIndex": 1,
            "hero": true,
            "dead": "8c0 2d0 2s0",
            "rows": "6d0 6c0 6s0/3d0 8d0 9d0 Kd0 Ad0/4s0 Js0 Qs0 Ks0 As0",
            "win": 257,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:17:51",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000058-1": [
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid4879184",
            "orderIndex": 1,
            "hero": false,
            "dead": "5d1 5s2 Qd3 4h4",
            "rows": "Kh0 Kd1 8s4/3h2 3c2 4d3 9d3 9s4/4c0 8c0 Tc0 Kc0 Qc1",
            "win": 4.8,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": false,
            "result": -52,
            "playerName": "pid1251760",
            "orderIndex": 2,
            "hero": false,
            "dead": "2s1 Th2 4s3 6s4",
            "rows": "Td1 2d2 Ks3/5h0 9c0 7d1 7s2 8h3/Jh0 Jc0 Qs0 Ts4 Qh4",
            "win": -260,
            "playerId": "pid1251760"
        },
        {
            "inFantasy": true,
            "result": 51,
            "playerName": "pid5688837",
            "orderIndex": 0,
            "hero": true,
            "dead": "3d0 3s0 5c0",
            "rows": "9h0 Jd0 Js0/6h0 6d0 6c0 7h0 7c0/8d0 Ah0 Ad0 Ac0 As0",
            "win": 247.3,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:19:08",
    "roomId": "21937330"
}


{
    "stakes": 5,
    "handData": {"210330132421-21937330-0000059-1": [
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "pid4879184",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jd0 6d1",
            "rows": "Kc0 Ad0 Ac0/5d0 6s0 7s0 8d0 9c0/9h0 Tc0 Jc0 Qh0 Ks0",
            "win": 101.8,
            "playerId": "pid4879184"
        },
        {
            "inFantasy": false,
            "result": -26,
            "playerName": "pid1251760",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qc1 Td2 2d3 7c4",
            "rows": "Ah1 4s3 Js4/2h0 4c0 5s0 5h2 5c3/8h0 9d0 Jh1 Th2 Qs4",
            "win": -130,
            "playerId": "pid1251760"
        },
        {
            "inFantasy": true,
            "result": 5,
            "playerName": "pid5688837",
            "orderIndex": 2,
            "hero": true,
            "dead": "3h0 3c0 2c0",
            "rows": "Qd0 Kh0 Kd0/4h0 4d0 7h0 7d0 8c0/2s0 8s0 9s0 Ts0 As0",
            "win": 24.2,
            "playerId": "pid5688837"
        }
    ]},
    "appName": "Ppp",
    "price": "1AUD",
    "joined": true,
    "clubId": "802765",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 10:19:57",
    "roomId": "21937330"
}


