{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000170-1": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid1793219",
            "orderIndex": 0,
            "hero": false,
            "dead": "5c1 Ac2 Kd3 2d4",
            "rows": "Qs0 9d4 Kc4/4h0 6c1 9c1 4c3 6d3/3c0 3s0 Tc0 Jh2 Jc2",
            "win": 2.3,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5684224",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qd1 Js2 8c3 Kh4",
            "rows": "Ad1 As2 8h4/7s0 9s0 2c1 7d3 5d4/5h0 Th0 Qh0 9h2 Ah3",
            "win": -2.4,
            "playerId": "pid5684224"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid2923305",
            "orderIndex": 2,
            "hero": false,
            "dead": "4d1 8d2 Qc3 2s4",
            "rows": "8s1 Ks3 4s4/3d0 5s0 6h0 3h3 2h4/Td0 Ts0 Jd1 7h2 7c2",
            "win": 0,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:53:29",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000171-1": [
        {
            "inFantasy": false,
            "result": -4,
            "playerName": "pid1793219",
            "orderIndex": 2,
            "hero": false,
            "dead": "Ts1 5s2 6h3 Ad4",
            "rows": "Ac0 7h3 3d4/4c0 9c1 Qc1 8c2 Qs4/2d0 7d0 Kd0 8d2 5d3",
            "win": -0.8,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5684224",
            "orderIndex": 0,
            "hero": true,
            "dead": "4s1 3c2 3s3 2s4",
            "rows": "8s1 Qd2 5c4/6s0 Jc0 Jd1 9s3 Js4/9h0 Th0 Kh0 Ah2 Qh3",
            "win": 1.2,
            "playerId": "pid5684224"
        },
        {
            "inFantasy": false,
            "result": -2,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "9d1 7s2 2c3 6c4",
            "rows": "As0 4d4 7c4/Td0 Tc1 8h2 Kc3 Ks3/3h0 4h0 Jh0 5h1 2h2",
            "win": -0.4,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:54:32",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000172-1": [
        {
            "inFantasy": false,
            "result": 19,
            "playerName": "pid1793219",
            "orderIndex": 1,
            "hero": false,
            "dead": "Td1 Jc2 2s3 4c4",
            "rows": "Ad0 Ac0 9c4/3h0 6h1 8c2 6c3 8d4/4s0 7s0 Qs1 Qh2 7h3",
            "win": 3.7,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": false,
            "result": -25,
            "playerName": "pid5684224",
            "orderIndex": 2,
            "hero": true,
            "dead": "3s1 Qc2 Ts3 Ks4",
            "rows": "Kh1 Kc2 As3/2h0 9d0 Jd0 2d2 8h4/5c0 7c0 6s1 5d3 4d4",
            "win": -5,
            "playerId": "pid5684224"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "5h1 3c2 2c3 Ah4",
            "rows": "4h2 5s3 9s3/8s0 Th0 Tc1 Jh1 Js4/7d0 Qd0 Kd0 3d2 6d4",
            "win": 1.2,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:55:47",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000173-1": [
        {
            "inFantasy": true,
            "result": 37,
            "playerName": "pid1793219",
            "orderIndex": 0,
            "hero": false,
            "dead": "4h0 Jc1 3s2",
            "rows": "Kh0 Ah0 Ac0/4s0 5s0 6c0 7c0 8s0/2d0 4d0 7d0 Jd0 Qd0",
            "win": 7.2,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid5684224",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jh1 8d2 3d3 6s4",
            "rows": "Qh0 8h2 Qs4/2c0 Kc0 4c1 2h3 2s4/5d0 9d0 9c1 9s2 6d3",
            "win": 0.2,
            "playerId": "pid5684224"
        },
        {
            "inFantasy": false,
            "result": -38,
            "playerName": "pid2923305",
            "orderIndex": 2,
            "hero": false,
            "dead": "5c1 5h2 3h3 Js4",
            "rows": "Ad0 7s2 As2/6h0 8c0 9h1 3c4 7h4/Td0 Tc0 Th1 Qc3 Kd3",
            "win": -7.6,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:56:48",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000174-1": [
        {
            "inFantasy": false,
            "result": 13,
            "playerName": "pid1793219",
            "orderIndex": 2,
            "hero": false,
            "dead": "3d1 2d2 5s3 2s4",
            "rows": "Ac0 Ah2 Qd4/4d0 8h0 4c1 7c2 8d3/Ts0 Ks0 Kd1 Td3 Ad4",
            "win": 2.5,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": true,
            "result": 18,
            "playerName": "pid5684224",
            "orderIndex": 0,
            "hero": true,
            "dead": "3s0",
            "rows": "7d0 7s0 Tc0/2h0 3c0 4h0 5d0 6c0/6s0 8s0 9s0 Qs0 As0",
            "win": 3.5,
            "playerId": "pid5684224"
        },
        {
            "inFantasy": false,
            "result": -31,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "9d1 4s2 6d3 8c4",
            "rows": "Kc2 Kh3 9c4/2c0 Jc0 5c1 Jd2 Jh3/6h0 7h0 Qh0 9h1 Qc4",
            "win": -6.2,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:57:38",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000175-1": [
        {
            "inFantasy": true,
            "result": 15,
            "playerName": "pid1793219",
            "orderIndex": 1,
            "hero": false,
            "dead": "2s0 2h1 3h2",
            "rows": "Kh0 Kd0 Ac0/4s0 Th0 Tc0 Jd0 Js0/6d0 6c0 6s0 9d0 9s0",
            "win": 2.9,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": false,
            "result": -13,
            "playerName": "pid5684224",
            "orderIndex": 2,
            "hero": true,
            "dead": "5s1 4h2 5d3 5h4",
            "rows": "Ad1 5c2 3c3/2d0 7s0 Td2 2c3 Kc4/8d0 8s0 Qs0 Qh1 8h4",
            "win": -2.6,
            "playerId": "pid5684224"
        },
        {
            "inFantasy": false,
            "result": -2,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "3s1 Qd2 8c3 3d4",
            "rows": "Ks0 Ah2 As4/6h0 7d0 7c1 9c2 9h3/Jh0 Jc0 4c1 4d3 7h4",
            "win": -0.4,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 13:58:51",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000176-1": [
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "pid1793219",
            "orderIndex": 0,
            "hero": false,
            "dead": "6s1 Ks2 3d3 9h4",
            "rows": "Qc0 8s3 9c3/5d0 2h1 7h1 5s2 Ah4/Tc0 Ts0 Jh0 Th2 Td4",
            "win": -1,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid5684224",
            "orderIndex": 1,
            "hero": true,
            "dead": "7d1 7s2 5h3 9s4",
            "rows": "Kc0 Kh1 9d4/3s0 4h0 4s1 Js2 3h4/6d0 6c0 Ac2 Qh3 Qd3",
            "win": -2.8,
            "playerId": "pid5684224"
        },
        {
            "inFantasy": true,
            "result": 19,
            "playerName": "pid2923305",
            "orderIndex": 2,
            "hero": false,
            "dead": "7c0 6h1 3c2",
            "rows": "Kd0 Ad0 As0/8h0 8c0 Jd0 Jc0 Qs0/2d0 2c0 2s0 4d0 4c0",
            "win": 3.7,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 14:00:01",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000177-1": [
        {
            "inFantasy": false,
            "result": -50,
            "playerName": "pid1793219",
            "orderIndex": 2,
            "hero": false,
            "dead": "2d1 Jh2 2h3 2s4",
            "rows": "Qh2 5h3 Ad4/3c0 4h0 5s0 3s1 4s2/9h0 9d0 7d1 Td3 As4",
            "win": -10,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": true,
            "result": 47,
            "playerName": "pid5684224",
            "orderIndex": 0,
            "hero": true,
            "dead": "Js0 4d0",
            "rows": "Th0 Tc0 Ts0/5d0 6s0 7s0 8c0 9s0/5c0 6c0 9c0 Jc0 Ac0",
            "win": 9.1,
            "playerId": "pid5684224"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qs1 4c2 6d3 Jd4",
            "rows": "Kd0 Ks2 Qc4/2c0 3d0 8d1 8s1 3h3/6h0 7h0 Ah2 Kh3 8h4",
            "win": 0.6,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 14:01:12",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000178-1": [
        {
            "inFantasy": false,
            "result": -48,
            "playerName": "pid1793219",
            "orderIndex": 1,
            "hero": false,
            "dead": "8s1 Td2 8c3 2s4",
            "rows": "Ac1 Kh2 Kd3/3h0 9h0 4h1 6h2 Tc4/7h0 7s0 Jc0 7d3 4s4",
            "win": -9.6,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": true,
            "result": 22,
            "playerName": "pid5684224",
            "orderIndex": 2,
            "hero": true,
            "dead": "As0 4c0",
            "rows": "3d0 3c0 3s0/6s0 7c0 8h0 9c0 Th0/8d0 9s0 Ts0 Jh0 Qh0",
            "win": 4.3,
            "playerId": "pid5684224"
        },
        {
            "inFantasy": true,
            "result": 26,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "4d0 Js1",
            "rows": "Ks0 Ah0 Ad0/2h0 6d0 6c0 Qd0 Qs0/2d0 5h0 5d0 5c0 5s0",
            "win": 5,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 14:01:56",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000179-1": [
        {
            "inFantasy": false,
            "result": -35,
            "playerName": "pid1793219",
            "orderIndex": 0,
            "hero": false,
            "dead": "5c1 3d2 5s3 3h4",
            "rows": "Ad0 Ac0 4c4/5d0 5h1 6d2 6c2 Ah3/9s0 Qh0 Tc1 8c3 Jd4",
            "win": -7,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": true,
            "result": 39,
            "playerName": "pid5684224",
            "orderIndex": 1,
            "hero": true,
            "dead": "7c0 7d0",
            "rows": "Kd0 Kc0 Ks0/Td0 Js0 Qs0 Kh0 As0/2h0 2d0 2c0 8h0 8d0",
            "win": 7.6,
            "playerId": "pid5684224"
        },
        {
            "inFantasy": true,
            "result": -4,
            "playerName": "pid2923305",
            "orderIndex": 2,
            "hero": false,
            "dead": "3c0 9c1",
            "rows": "Jc0 Qd0 Qc0/3s0 4s0 7s0 8s0 Ts0/4h0 6h0 7h0 Th0 Jh0",
            "win": -0.8,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 14:02:38",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000180-1": [
        {
            "inFantasy": true,
            "result": -20,
            "playerName": "pid1793219",
            "orderIndex": 2,
            "hero": false,
            "dead": "8s0 3d1 5s2",
            "rows": "Jc0 Js0 Ad0/6h0 6d0 9c0 Th0 Tc0/4d0 4c0 Qd0 Qc0 Qs0",
            "win": -4,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": true,
            "result": 33,
            "playerName": "pid5684224",
            "orderIndex": 0,
            "hero": true,
            "dead": "3s0 2d0",
            "rows": "Kd0 Kc0 Ks0/5d0 6s0 7d0 8h0 9s0/2h0 4h0 9h0 Jh0 Qh0",
            "win": 6.4,
            "playerId": "pid5684224"
        },
        {
            "inFantasy": false,
            "result": -13,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "4s1 Jd2 8c3 2s4",
            "rows": "Ah1 Kh4 As4/3c0 5h0 5c1 2c2 3h3/7c0 7s0 Ts0 7h2 Td3",
            "win": -2.6,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 14:03:19",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000181-1": [
        {
            "inFantasy": false,
            "result": -34,
            "playerName": "pid1793219",
            "orderIndex": 1,
            "hero": false,
            "dead": "6h1 Ts2 3s3 4d4",
            "rows": "Kh2 Ac3 9s4/3c0 5d0 4h2 6d3 6c4/9h0 Tc0 Js0 8d1 Qd1",
            "win": -6.8,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": true,
            "result": 0,
            "playerName": "pid5684224",
            "orderIndex": 2,
            "hero": true,
            "dead": "2s0 2c0",
            "rows": "Kd0 Ah0 Ad0/4c0 Th0 Td0 Jh0 Jd0/5h0 6s0 7d0 8s0 9c0",
            "win": 0,
            "playerId": "pid5684224"
        },
        {
            "inFantasy": true,
            "result": 34,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "3d0 2d1 5s2",
            "rows": "7s0 Kc0 Ks0/2h0 3h0 7h0 8h0 Qh0/5c0 7c0 8c0 Jc0 Qc0",
            "win": 6.6,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 14:04:02",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000182-1": [
        {
            "inFantasy": false,
            "result": -1,
            "playerName": "pid1793219",
            "orderIndex": 0,
            "hero": false,
            "dead": "4c1 7s2 2c3 3d4",
            "rows": "Ac0 7h1 4h4/3h0 Qs0 5s1 Jc2 5c4/2d0 Kd0 8d2 7d3 9d3",
            "win": -0.2,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid5684224",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jd1 Qc2 Qh3 Ts4",
            "rows": "Qd0 As1 5d3/2h0 2s0 3s1 7c3 Ad4/6h0 8s0 6c2 9s2 8h4",
            "win": -3,
            "playerId": "pid5684224"
        },
        {
            "inFantasy": false,
            "result": 16,
            "playerName": "pid2923305",
            "orderIndex": 2,
            "hero": false,
            "dead": "6s1 6d2 4d3 Ks4",
            "rows": "Kh0 4s2 Ah4/Jh0 5h2 9h3 Th3 Td4/8c0 9c0 Tc0 3c1 Kc1",
            "win": 3.1,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 14:05:34",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000183-1": [
        {
            "inFantasy": false,
            "result": 17,
            "playerName": "pid1793219",
            "orderIndex": 2,
            "hero": false,
            "dead": "5c1 7d2 5s3 Jd4",
            "rows": "Qs0 Qh3 As3/2h0 4s0 3h1 3c1 4d2/8d0 Tc0 8c2 8s4 Kc4",
            "win": 3.3,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5684224",
            "orderIndex": 0,
            "hero": true,
            "dead": "6d1 2d2 Jc3 5d4",
            "rows": "6h1 Qd2 Ah4/4h0 7c0 9h0 7h1 Kd4/2s0 Js0 3s2 6s3 Ts3",
            "win": 1.2,
            "playerId": "pid5684224"
        },
        {
            "inFantasy": false,
            "result": -23,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "Th1 3d2 2c3 4c4",
            "rows": "7s0 Ad2 Ac2/8h0 Jh0 5h3 Td4 Kh4/9c0 Qc0 9d1 9s1 Ks3",
            "win": -4.6,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 14:06:31",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000184-1": [
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "pid1793219",
            "orderIndex": 1,
            "hero": false,
            "dead": "2h0",
            "rows": "Qs0 Kh0 Kc0/5c0 7d0 7c0 9h0 9s0/4d0 5h0 6s0 7s0 8c0",
            "win": 4.1,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5684224",
            "orderIndex": 2,
            "hero": true,
            "dead": "Jc1 5d2 6h3 2s4",
            "rows": "Ah0 Qc2 8h4/2c0 4h0 Kd2 Ad3 Ac3/Td0 Js0 Tc1 Ts1 Jh4",
            "win": 0,
            "playerId": "pid5684224"
        },
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "7h1 3s2 Qd3 9c4",
            "rows": "As0 Ks3 Qh4/5s0 6d0 3d1 6c1 3c2/4c0 4s0 8s2 8d3 9d4",
            "win": -4.2,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 14:07:39",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000185-1": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid1793219",
            "orderIndex": 0,
            "hero": false,
            "dead": "Js1 7d2 4d3 2c4",
            "rows": "9h2 8d4 Td4/3d0 3c0 6c0 Jd1 Jc1/5s0 8s0 7s2 5h3 5d3",
            "win": 2.3,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5684224",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qs1 Qd2 4h3 9c4",
            "rows": "Ad0 Kc2 Ks3/2s0 6s0 7c0 2d2 8h4/9d0 3h1 3s1 Jh3 4c4",
            "win": -1.2,
            "playerId": "pid5684224"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid2923305",
            "orderIndex": 2,
            "hero": false,
            "dead": "Ts1 Qc2 2h3 9s4",
            "rows": "Qh0 Kd0 Kh2/As0 Ac1 Th3 Tc3 Ah4/4s0 6d0 7h1 5c2 6h4",
            "win": -1.2,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 14:09:20",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000186-1": [
        {
            "inFantasy": false,
            "result": 28,
            "playerName": "pid1793219",
            "orderIndex": 2,
            "hero": false,
            "dead": "8c1 6s2 6c3 9s4",
            "rows": "Jc3 Jh4 Qc4/2d0 3d0 5d0 5c0 3h1/Th0 Js1 7c2 8s2 9h3",
            "win": 5.4,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid5684224",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qh1 Jd2 Qs3 As4",
            "rows": "Ad0 8h2 Ah3/3s0 4d0 7s2 3c3 Td4/5h0 Kh0 Kd1 Kc1 2h4",
            "win": -2.8,
            "playerId": "pid5684224"
        },
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "Ts1 9c2 Tc3 7h4",
            "rows": "Ks0 Ac1 4c4/4h0 4s0 5s2 2c3 2s3/8d0 9d0 Qd1 6d2 6h4",
            "win": -2.8,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 14:10:22",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000187-1": [
        {
            "inFantasy": false,
            "result": 28,
            "playerName": "pid1793219",
            "orderIndex": 1,
            "hero": false,
            "dead": "6c1 9h2 Jc3 2c4",
            "rows": "Qc3 Tc4 Qh4/4d0 8c0 6h1 5d2 7d3/2s0 3s0 Js0 7s1 4s2",
            "win": 5.4,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": false,
            "result": 8,
            "playerName": "pid5684224",
            "orderIndex": 2,
            "hero": true,
            "dead": "Jh1 7h2 Jd3 3c4",
            "rows": "Ah0 Ad0 3h4/7c0 4c1 9c1 Ac2 As2/Th0 Qd0 Td3 Kh3 Ts4",
            "win": 1.6,
            "playerId": "pid5684224"
        },
        {
            "inFantasy": false,
            "result": -36,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "6d1 8d2 9s3 9d4",
            "rows": "Kc1 Qs2 Kd3/2d0 5s2 4h3 2h4 6s4/3d0 5h0 5c0 8s0 8h1",
            "win": -7.2,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 14:11:38",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000188-1": [
        {
            "inFantasy": true,
            "result": 0,
            "playerName": "pid1793219",
            "orderIndex": 0,
            "hero": false,
            "dead": "3c0",
            "rows": "6d0 7c0 9c0/2s0 6s0 7s0 8s0 Ts0/6h0 Th0 Jh0 Kh0 Ah0",
            "win": 0,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": true,
            "result": 12,
            "playerName": "pid5684224",
            "orderIndex": 1,
            "hero": true,
            "dead": "5h0 2h0 2d0",
            "rows": "Qh0 Kd0 Ks0/6c0 7d0 8h0 9d0 Tc0/3d0 4d0 Td0 Jd0 Ad0",
            "win": 2.3,
            "playerId": "pid5684224"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid2923305",
            "orderIndex": 2,
            "hero": false,
            "dead": "9h1 Js2 As3 4s4",
            "rows": "Kc1 3s4 Jc4/5d0 5c0 7h0 2c2 5s3/8d0 Qd0 Qc1 8c2 Qs3",
            "win": -2.4,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 14:12:19",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000189-1": [
        {
            "inFantasy": false,
            "result": 11,
            "playerName": "pid1793219",
            "orderIndex": 2,
            "hero": false,
            "dead": "Kh1 Th2 9s3 5c4",
            "rows": "7d2 7s2 8s4/Jc0 Jh1 Jd1 Qs3 Ks3/3h0 4h0 6h0 7h0 5s4",
            "win": 2.1,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": false,
            "result": -26,
            "playerName": "pid5684224",
            "orderIndex": 0,
            "hero": true,
            "dead": "2c1 Tc2 5h3 Ah4",
            "rows": "Qh1 Qd3 8d4/4d0 6d0 Ad1 Td2 5d3/3s0 Ts0 As0 4s2 2d4",
            "win": -5.2,
            "playerId": "pid5684224"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "pid2923305",
            "orderIndex": 1,
            "hero": false,
            "dead": "3d1 7c2 6c3 3c4",
            "rows": "Kd0 Ac2 Kc4/2h0 2s0 8h1 4c3 8c3/9d0 Qc0 9c1 9h2 6s4",
            "win": 2.9,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 14:13:17",
    "roomId": "21947173"
}


{
    "stakes": 0.2,
    "handData": {"210330175926-21947173-0000190-1": [
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid1793219",
            "orderIndex": 1,
            "hero": false,
            "dead": "3h1 9c2 3d3 5h4",
            "rows": "8d1 Kc2 Js4/2d0 4s0 6h0 4c2 Kh4/Th0 Ts0 Jd1 Tc3 Jc3",
            "win": -3.6,
            "playerId": "pid1793219"
        },
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid5684224",
            "orderIndex": 2,
            "hero": true,
            "dead": "8c1 4h2 Qc3 Jh4",
            "rows": "Ks3 Qs4 Ah4/6d0 6c0 Td0 2h1 2s1/9d0 9s0 3c2 9h2 3s3",
            "win": -3.2,
            "playerId": "pid5684224"
        },
        {
            "inFantasy": true,
            "result": 34,
            "playerName": "pid2923305",
            "orderIndex": 0,
            "hero": false,
            "dead": "5c0 6s1",
            "rows": "8h0 8s0 Qh0/4d0 5d0 7d0 Qd0 Kd0/7h0 7s0 Ad0 Ac0 As0",
            "win": 6.6,
            "playerId": "pid2923305"
        }
    ]},
    "appName": "Ppp",
    "price": "0.9USD",
    "joined": true,
    "clubId": "2244178",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 14:14:47",
    "roomId": "21947173"
}


