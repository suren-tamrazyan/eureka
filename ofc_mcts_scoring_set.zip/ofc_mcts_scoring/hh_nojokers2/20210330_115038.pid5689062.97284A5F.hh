{
    "stakes": 0.2,
    "handData": {"210330091909-21924920-0000007-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid3798060",
            "orderIndex": 1,
            "hero": false,
            "dead": "8c1 8s2 5d3 7s4",
            "rows": "As0 Jc3 Ah3/4d0 5h1 6c1 5c2 6s4/Tc0 Qd0 Kh0 Td2 9h4",
            "win": 0,
            "playerId": "pid3798060"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "7h1 Qc2 4c3 7d4",
            "rows": "Kd0 Ks1 4h3/3d0 6h1 9d2 Ad3 4s4/8h0 8d0 Th0 Ts2 2s4",
            "win": 0,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:50:38",
    "roomId": "21924920"
}


{
    "stakes": 0.2,
    "handData": {"210330091909-21924920-0000008-1": [
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid3798060",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jh1 4d2 Kh3 Qc4",
            "rows": "Qd2 As3 9h4/2s0 3h0 3d0 6c3 Ah4/Jc0 Kc0 5c1 9c1 Ac2",
            "win": -3,
            "playerId": "pid3798060"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "2d1 9d2 6d3 Kd4",
            "rows": "Qs0 Ks2 Qh3/4s0 4c1 7c2 7h4 Ad4/8h0 8s0 Td0 Tc1 Th3",
            "win": 2.9,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:51:59",
    "roomId": "21924920"
}


{
    "stakes": 0.2,
    "handData": {"210330091909-21924920-0000009-1": [
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid3798060",
            "orderIndex": 1,
            "hero": false,
            "dead": "8s1 8c2 6d3 7d4",
            "rows": "7c2 7h3 Jh3/2d0 4d0 4c0 5d1 2c4/9c0 Qs0 Qc1 9s2 Js4",
            "win": -2.8,
            "playerId": "pid3798060"
        },
        {
            "inFantasy": true,
            "result": 14,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "5s0",
            "rows": "Jd0 Kd0 Ks0/7s0 8h0 8d0 Th0 Tc0/2h0 3h0 4s0 5c0 Ah0",
            "win": 2.7,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:52:51",
    "roomId": "21924920"
}


{
    "stakes": 0.2,
    "handData": {"210330091909-21924920-0000010-1": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid3798060",
            "orderIndex": 0,
            "hero": false,
            "dead": "9h1 3h2 Qd3 9d4",
            "rows": "2h0 Kh1 Ac4/7s0 5h1 6h2 5c3 5s4/8c0 8s0 Jh0 Td2 8h3",
            "win": -1.2,
            "playerId": "pid3798060"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qh1 3d2 8d3 6s4",
            "rows": "Ad0 As2 Qc3/4c0 6d0 7c0 4d2 7d4/Js0 2c1 2s1 2d3 Ah4",
            "win": 1.2,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:54:27",
    "roomId": "21924920"
}


{
    "stakes": 0.2,
    "handData": {"210330091909-21924920-0000011-1": [
        {
            "inFantasy": false,
            "result": -25,
            "playerName": "pid3798060",
            "orderIndex": 1,
            "hero": false,
            "dead": "8c1 2h2 3d3 2d4",
            "rows": "Kc0 Ah3 5h4/3h0 6s0 3c2 8s2 6c3/Qh0 Qs0 Th1 Td1 Jc4",
            "win": -5,
            "playerId": "pid3798060"
        },
        {
            "inFantasy": true,
            "result": 25,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "2c0 2s0 7d0",
            "rows": "9d0 Ad0 As0/6d0 7h0 8h0 9h0 Tc0/4h0 4s0 Kh0 Kd0 Ks0",
            "win": 4.8,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:55:09",
    "roomId": "21924920"
}


{
    "stakes": 0.2,
    "handData": {"210330091909-21924920-0000012-1": [
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid3798060",
            "orderIndex": 0,
            "hero": false,
            "dead": "8c1 4s2 Jh3 Ac4",
            "rows": "As0 5c4 9d4/2s0 5h0 3c2 Th3 Ts3/8d0 Tc0 7c1 9h1 6c2",
            "win": -3.4,
            "playerId": "pid3798060"
        },
        {
            "inFantasy": false,
            "result": 17,
            "playerName": "pid5689062",
            "orderIndex": 1,
            "hero": true,
            "dead": "5d1 5s2 8s3 2d4",
            "rows": "Ad0 Qs2 Qd3/4h0 4c0 6d0 3s2 3h4/9c0 9s1 Kc1 Kh3 Kd4",
            "win": 3.3,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:56:26",
    "roomId": "21924920"
}


{
    "stakes": 0.2,
    "handData": {"210330091909-21924920-0000013-1": [
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid3798060",
            "orderIndex": 1,
            "hero": false,
            "dead": "2h1 Qd2 2s3 2d4",
            "rows": "Ah1 3s4 9h4/4h0 4d1 6h2 4c3 5s3/5c0 7c0 8c0 Qc0 9c2",
            "win": -1.6,
            "playerId": "pid3798060"
        },
        {
            "inFantasy": true,
            "result": 8,
            "playerName": "pid5689062",
            "orderIndex": 0,
            "hero": true,
            "dead": "5h0",
            "rows": "9d0 Ac0 As0/7d0 8h0 8d0 Kh0 Kd0/4s0 7s0 9s0 Ts0 Qs0",
            "win": 1.6,
            "playerId": "pid5689062"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1962979",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 08:59:17",
    "roomId": "21924920"
}


