{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000182-1": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5397550",
            "orderIndex": 1,
            "hero": false,
            "dead": "3s1 5h2 As3 7d4",
            "rows": "Qd0 Qh2 8d4/2s0 7h0 2h1 8s2 7s3/Td0 Tc0 Jd1 5c3 6h4",
            "win": 0,
            "playerId": "pid5397550"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "Js1 5d2 Kh3 Ac4",
            "rows": "Ah0 Ad1 Jh4/4h0 4c0 3d3 6d3 4s4/9c0 Qc0 2c1 9h2 Qs2",
            "win": 0,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:09:38",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000183-1": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid5397550",
            "orderIndex": 0,
            "hero": false,
            "dead": "Ah1 6c2 Qc3 9h4",
            "rows": "Qh0 Qd0 6s4/3c0 Ks0 5s2 3d3 5d4/Jd0 Ts1 Jh1 Th2 Js3",
            "win": 0.6,
            "playerId": "pid5397550"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "Tc1 2s2 5c3 3s4",
            "rows": "Ad0 Ac0 5h4/4d0 7h1 7c1 4h2 Jc3/8c0 Qs0 9s2 8d3 8s4",
            "win": -0.6,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:10:44",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000184-1": [
        {
            "inFantasy": true,
            "result": -6,
            "playerName": "pid5397550",
            "orderIndex": 1,
            "hero": false,
            "dead": "3s0",
            "rows": "Td0 Ts0 Jh0/5s0 7h0 Qh0 Ah0 As0/3c0 6c0 7c0 8c0 Qc0",
            "win": -1.2,
            "playerId": "pid5397550"
        },
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "3h0 4h0 8s0",
            "rows": "Tc0 Ks0 Ac0/6d0 7d0 8d0 9d0 Qd0/2h0 2c0 Jd0 Jc0 Js0",
            "win": 1.2,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:11:20",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000185-1": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid5397550",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qd1 Jc2 4c3 Kd4",
            "rows": "Kh1 Qs2 Tc3/2s0 6c0 5d2 5h3 Ts4/3h0 3c0 9s0 3s1 4h4",
            "win": 1.2,
            "playerId": "pid5397550"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "9d1 9c2 6s3 Ks4",
            "rows": "Kc0 Td2 Qc3/Jd0 As0 6d1 5c2 5s4/8h0 Qh0 9h1 6h3 3d4",
            "win": -1.2,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:12:38",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000186-1": [
        {
            "inFantasy": false,
            "result": 14,
            "playerName": "pid5397550",
            "orderIndex": 1,
            "hero": false,
            "dead": "Kc1 Js2 8s3 7c4",
            "rows": "Kh0 Ks1 9d2/6h0 8h0 5h2 5d3 6d4/Th0 Td0 3d1 Ts3 7d4",
            "win": 2.7,
            "playerId": "pid5397550"
        },
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "8c1 Qs2 Kd3 Qh4",
            "rows": "Qc0 Ah1 4h4/2d0 4c1 2h2 8d2 4d3/9h0 9s0 Jh0 7h3 2s4",
            "win": -2.8,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:13:35",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000187-1": [
        {
            "inFantasy": true,
            "result": 22,
            "playerName": "pid5397550",
            "orderIndex": 0,
            "hero": false,
            "dead": "3h0 4s1",
            "rows": "6s0 Jh0 Js0/3d0 8d0 Td0 Qd0 Ad0/2h0 2d0 2s0 7h0 7s0",
            "win": 4.3,
            "playerId": "pid5397550"
        },
        {
            "inFantasy": false,
            "result": -22,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "5d1 4d2 6h3 Ks4",
            "rows": "9s1 Kc2 9c3/8h0 Th0 4h1 Tc2 9d3/3c0 Qh0 Qc0 6d4 6c4",
            "win": -4.4,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:14:36",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000188-1": [
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5397550",
            "orderIndex": 1,
            "hero": false,
            "dead": "3s1 Jh2 4s3 Ts4",
            "rows": "Ad1 5c3 7s4/2h0 6h2 Td2 2c3 2d4/3d0 4c0 6s0 7c0 5h1",
            "win": -2,
            "playerId": "pid5397550"
        },
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "8h1 6c2 2s3 3h4",
            "rows": "Ah2 Ks3 7d4/4d0 9d0 9s0 5d1 9c2/Jc0 Qc0 Js1 Qd3 Jd4",
            "win": 1.9,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:15:41",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000189-1": [
        {
            "inFantasy": false,
            "result": -13,
            "playerName": "pid5397550",
            "orderIndex": 0,
            "hero": false,
            "dead": "7d1 7h2 Jc3 4h4",
            "rows": "Qh0 As2 Qs4/2d0 2s0 3c0 8s2 8d3/9h0 9c1 Tc1 4s3 Ts4",
            "win": -2.6,
            "playerId": "pid5397550"
        },
        {
            "inFantasy": false,
            "result": 13,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "6c1 Th2 6s3 3s4",
            "rows": "Ks1 Kd2 3d4/Qd0 Ac1 Ah2 7c3 Ad4/2h0 5h0 8h0 Jh0 3h3",
            "win": 2.5,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:16:54",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000190-1": [
        {
            "inFantasy": true,
            "result": 3,
            "playerName": "pid5397550",
            "orderIndex": 1,
            "hero": false,
            "dead": "7s0",
            "rows": "8c0 9h0 Kh0/2h0 2d0 2s0 Ah0 As0/5h0 5d0 5c0 6h0 6d0",
            "win": 0.6,
            "playerId": "pid5397550"
        },
        {
            "inFantasy": true,
            "result": -3,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "Td0 3h0",
            "rows": "Kd0 Kc0 Ad0/6c0 7d0 8d0 9c0 Th0/5s0 9s0 Js0 Qs0 Ks0",
            "win": -0.6,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:17:28",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000191-1": [
        {
            "inFantasy": false,
            "result": 14,
            "playerName": "pid5397550",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qh1 8s2 5c3 6s4",
            "rows": "Kh1 Ad1 Ac4/3s0 Jh0 2h3 Js3 3c4/4c0 Qc0 Kc0 Qd2 Ks2",
            "win": 2.7,
            "playerId": "pid5397550"
        },
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "9c1 9d2 3h3 Kd4",
            "rows": "Ah1 6d2 6c3/4d0 8c0 7c1 9h3 7d4/Th0 Tc0 Jc0 5d2 Qs4",
            "win": -2.8,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:18:50",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000192-1": [
        {
            "inFantasy": true,
            "result": 33,
            "playerName": "pid5397550",
            "orderIndex": 1,
            "hero": false,
            "dead": "Ts0 2s1 2h2",
            "rows": "Js0 Ah0 As0/5h0 5d0 5c0 6h0 6d0/8h0 8d0 Qh0 Qd0 Qc0",
            "win": 6.4,
            "playerId": "pid5397550"
        },
        {
            "inFantasy": false,
            "result": -33,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "7c1 9s2 5s3 Th4",
            "rows": "Ks0 Qs2 Kh3/2d0 3d0 3h1 6s2 9d4/4c0 Jc0 4s1 7d3 9h4",
            "win": -6.6,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:19:50",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000193-1": [
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid5397550",
            "orderIndex": 0,
            "hero": false,
            "dead": "2s1 Td2 5d3 4s4",
            "rows": "Qh0 Qs1 6c4/4d0 5c0 Ad1 6h3 Ac3/3h0 3c0 8c2 8s2 3d4",
            "win": 1.9,
            "playerId": "pid5397550"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "2c1 7s2 4c3 Jh4",
            "rows": "8d1 Kh4 Ah4/9h0 9c0 Th0 7d1 Tc3/3s0 5s0 Ts2 Js2 9s3",
            "win": -2,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:21:08",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000194-1": [
        {
            "inFantasy": true,
            "result": 26,
            "playerName": "pid5397550",
            "orderIndex": 1,
            "hero": false,
            "dead": "Tc0",
            "rows": "8d0 8c0 8s0/Jh0 Qc0 Ah0 Ad0 As0/2s0 3h0 4s0 5h0 6h0",
            "win": 5,
            "playerId": "pid5397550"
        },
        {
            "inFantasy": false,
            "result": -26,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h1 3s2 9d3 4d4",
            "rows": "Kh3 Ks3 3c4/Js0 Qh0 Jc1 7h2 2c4/5d0 6d0 7c0 3d1 4h2",
            "win": -5.2,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:21:56",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000195-1": [
        {
            "inFantasy": true,
            "result": -17,
            "playerName": "pid5397550",
            "orderIndex": 0,
            "hero": false,
            "dead": "3c0",
            "rows": "8c0 9d0 9s0/Tc0 Ts0 Qh0 Kd0 Ad0/4d0 5c0 5s0 6h0 6s0",
            "win": -3.4,
            "playerId": "pid5397550"
        },
        {
            "inFantasy": false,
            "result": 17,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "3d1 2s2 3s3 6c4",
            "rows": "Ac2 As3 7d4/4s0 Js0 Jc1 Jd2 5d3/5h0 8h0 Th0 4h1 2h4",
            "win": 3.3,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:22:46",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000196-1": [
        {
            "inFantasy": false,
            "result": -25,
            "playerName": "pid5397550",
            "orderIndex": 1,
            "hero": false,
            "dead": "4h1 Qc2 Ad3 4s4",
            "rows": "Js1 Kh2 Kc2/8s0 Ah0 Ac0 Qd3 2s4/3d0 Td0 Th1 2h3 3c4",
            "win": -5,
            "playerId": "pid5397550"
        },
        {
            "inFantasy": true,
            "result": 25,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jd0 3s0 Kd0",
            "rows": "9d0 9c0 9s0/2d0 3h0 4c0 5s0 6d0/7h0 7d0 7c0 Qh0 Qs0",
            "win": 4.8,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:23:18",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000197-1": [
        {
            "inFantasy": true,
            "result": -12,
            "playerName": "pid5397550",
            "orderIndex": 0,
            "hero": false,
            "dead": "5d0 4d1",
            "rows": "3d0 3s0 Kd0/2c0 4c0 8c0 9c0 Jc0/2h0 5h0 8h0 Th0 Qh0",
            "win": -2.4,
            "playerId": "pid5397550"
        },
        {
            "inFantasy": true,
            "result": 12,
            "playerName": "pid5684226",
            "orderIndex": 1,
            "hero": true,
            "dead": "Ad0 6h0 5c0",
            "rows": "7h0 7d0 7s0/8d0 9d0 Tc0 Jd0 Qc0/4s0 5s0 Ts0 Js0 As0",
            "win": 2.3,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:23:48",
    "roomId": "21907751"
}


{
    "stakes": 0.2,
    "handData": {"210330040443-21907751-0000198-1": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid5397550",
            "orderIndex": 1,
            "hero": false,
            "dead": "5d1 Ts2 8h3 Th4",
            "rows": "Qh0 Ad3 Jc4/3c0 6h0 5s2 2d3 4d4/Td0 Jd0 8s1 9c1 Qc2",
            "win": -2.4,
            "playerId": "pid5397550"
        },
        {
            "inFantasy": true,
            "result": 12,
            "playerName": "pid5684226",
            "orderIndex": 0,
            "hero": true,
            "dead": "4c0 6c0 3h0",
            "rows": "5h0 5c0 Tc0/7d0 8d0 9d0 Qd0 Kd0/4s0 6s0 Js0 Qs0 As0",
            "win": 2.3,
            "playerId": "pid5684226"
        }
    ]},
    "appName": "Ppp",
    "price": "1USD",
    "joined": true,
    "clubId": "1657430",
    "rules": "progressive17_nojokers",
    "endDateTime": "2021-03-30 01:24:26",
    "roomId": "21907751"
}


