{
    "stakes": 0.5,
    "handData": {"21173170-1": [
        {
            "inFantasy": false,
            "result": -27,
            "playerName": "pid920703",
            "orderIndex": 0,
            "hero": false,
            "dead": "Kd1 7d2 6s3 4c4",
            "rows": "Ks0 Kh1 As3/5h0 2h1 4s2 5c3 4h4/9c0 9s0 Jc0 Th2 6c4",
            "win": -13.5,
            "playerId": "pid920703"
        },
        {
            "inFantasy": false,
            "result": 27,
            "playerName": "pid712799",
            "orderIndex": 1,
            "hero": true,
            "dead": "9d1 8c2 3c3 6h4",
            "rows": "Ad2 Qs3 Ah4/5s0 8s0 2s1 7s1 3s3/7h0 9h0 Jh0 Qh2 8h4",
            "win": 13.09,
            "playerId": "pid712799"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 03:37:51",
    "roomId": "21173170"
}


{
    "stakes": 0.5,
    "handData": {"21173170-2": [
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid920703",
            "orderIndex": 1,
            "hero": false,
            "dead": "4h1 4c2 6s3 2s4",
            "rows": "As2 Ks3 Ts4/2c0 3d0 5c0 3s1 5s1/9d0 9s0 Qs2 7d3 Qh4",
            "win": -8,
            "playerId": "pid920703"
        },
        {
            "inFantasy": true,
            "result": 16,
            "playerName": "pid712799",
            "orderIndex": 0,
            "hero": true,
            "dead": "5h0 5d0 4s0",
            "rows": "6d0 7h0 7s0/9h0 Th0 Js0 Qd0 Kd0/6c0 8c0 Tc0 Jc0 Kc0",
            "win": 7.76,
            "playerId": "pid712799"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 03:38:19",
    "roomId": "21173170"
}


{
    "stakes": 0.5,
    "handData": {"21173170-3": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid920703",
            "orderIndex": 0,
            "hero": false,
            "dead": "3s1 6h2 6c3 3d4",
            "rows": "Kh0 Kc0 Jh3/4s0 5c0 4d1 Qh3 6s4/8h0 Ts1 Td2 Tc2 Ac4",
            "win": 0,
            "playerId": "pid920703"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid712799",
            "orderIndex": 1,
            "hero": true,
            "dead": "4c1 9s2 Ah3 2d4",
            "rows": "Kd0 Ks0 2s3/5d0 7c1 4h2 6d2 8c4/9c0 Th0 Js1 2c3 8d4",
            "win": 0,
            "playerId": "pid712799"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 03:39:35",
    "roomId": "21173170"
}


{
    "stakes": 0.5,
    "handData": {"21173170-4": [
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "pid920703",
            "orderIndex": 1,
            "hero": false,
            "dead": "Kc1 5h2 5c3 3s4",
            "rows": "Ah1 7h3 Jh4/4s0 8h0 8s0 8c2 5s4/Qh0 Qs0 2c1 Qd2 2d3",
            "win": 4.36,
            "playerId": "pid920703"
        },
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "pid712799",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ad1 2h2 4h3 5d4",
            "rows": "Kh0 As3 6s4/3h0 8d0 9h1 9s1 3c2/Ts0 Js0 7s2 7c3 Jd4",
            "win": -4.5,
            "playerId": "pid712799"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 03:40:19",
    "roomId": "21173170"
}


{
    "stakes": 0.5,
    "handData": {"21173170-5": [
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid920703",
            "orderIndex": 0,
            "hero": false,
            "dead": "5h1 3h2 3s3 2h4",
            "rows": "9s2 Qc3 4c4/2s0 6h1 4d2 6s3 6c4/7c0 8s0 9c0 Jh0 Th1",
            "win": -8.5,
            "playerId": "pid920703"
        },
        {
            "inFantasy": false,
            "result": 17,
            "playerName": "pid712799",
            "orderIndex": 1,
            "hero": true,
            "dead": "Kh1 3c2 9d3 Td4",
            "rows": "Ah1 Ac3 Jc4/2c0 7s0 5c2 7h2 7d3/3d0 5d0 Kd0 6d1 Jd4",
            "win": 8.24,
            "playerId": "pid712799"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 03:41:28",
    "roomId": "21173170"
}


{
    "stakes": 0.5,
    "handData": {"21173170-6": [
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid920703",
            "orderIndex": 1,
            "hero": false,
            "dead": "5d1 2s2 4c3 8c4",
            "rows": "Qs2 As3 9c4/Jc0 Jd1 7s2 3h3 Jh4/2h0 6h0 7h0 9h0 4h1",
            "win": -8.5,
            "playerId": "pid920703"
        },
        {
            "inFantasy": true,
            "result": 17,
            "playerName": "pid712799",
            "orderIndex": 0,
            "hero": true,
            "dead": "Kh0 Js0 2c0",
            "rows": "Td0 Tc0 Ac0/4s0 5s0 6s0 8s0 9s0/3d0 4d0 6d0 7d0 Qd0",
            "win": 8.24,
            "playerId": "pid712799"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 03:41:57",
    "roomId": "21173170"
}


{
    "stakes": 0.5,
    "handData": {"21173170-7": [
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid920703",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qh1 Qc2 7s3 6c4",
            "rows": "Ad2 8d4 Td4/3c0 9h0 2s1 2d3 9c3/Jd0 Qd0 Kd0 5d1 6d2",
            "win": 2.42,
            "playerId": "pid920703"
        },
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "pid712799",
            "orderIndex": 1,
            "hero": true,
            "dead": "8s1 3d2 6s3 4s4",
            "rows": "9d1 Qs1 Ac3/3s0 Jc0 Tc2 Js2 4c3/5h0 5c0 7d0 5s4 Kc4",
            "win": -2.5,
            "playerId": "pid712799"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 03:43:04",
    "roomId": "21173170"
}


{
    "stakes": 0.5,
    "handData": {"21173170-8": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid920703",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qc1 Kh2 Jd3 Ac4",
            "rows": "Ah0 Ad1 8d4/3d0 5c1 6c2 6s2 5h3/7h0 7c0 Th0 Qs3 Td4",
            "win": 0,
            "playerId": "pid920703"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid712799",
            "orderIndex": 0,
            "hero": true,
            "dead": "2c1 8c2 9s3 2h4",
            "rows": "9h1 9d2 Tc3/5d0 7s0 Js1 Jc2 3s3/4h0 Kd0 Ks0 4d4 Kc4",
            "win": 0,
            "playerId": "pid712799"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 03:43:53",
    "roomId": "21173170"
}


{
    "stakes": 0.5,
    "handData": {"21173170-9": [
        {
            "inFantasy": true,
            "result": 25,
            "playerName": "pid920703",
            "orderIndex": 0,
            "hero": false,
            "dead": "9s0 3s1 2h2",
            "rows": "Td0 Ts0 Ad0/3c0 8c0 9c0 Qc0 Kc0/5d0 5s0 Jh0 Jc0 Js0",
            "win": 12.12,
            "playerId": "pid920703"
        },
        {
            "inFantasy": false,
            "result": -25,
            "playerName": "pid712799",
            "orderIndex": 1,
            "hero": true,
            "dead": "4d1 Th2 Ac3 2d4",
            "rows": "Qs0 Ah2 As2/3h0 2c1 3d1 2s3 Tc4/7h0 7s0 Jd0 6d3 8s4",
            "win": -12.5,
            "playerId": "pid712799"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 03:44:28",
    "roomId": "21173170"
}


{
    "stakes": 0.5,
    "handData": {"21173170-10": [
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid920703",
            "orderIndex": 1,
            "hero": false,
            "dead": "3s1 7d2 3h3 5h4",
            "rows": "9c3 9d4 Qd4/Qh1 Qc1 6s2 Js2 6d3/2c0 3c0 4c0 5c0 7c0",
            "win": 2.42,
            "playerId": "pid920703"
        },
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "pid712799",
            "orderIndex": 0,
            "hero": true,
            "dead": "9s1 Td2 As3 4h4",
            "rows": "Ac0 3d3 7s3/2h0 9h0 Ah2 8s4 Qs4/4d0 Kd0 2d1 8d1 Ad2",
            "win": -2.5,
            "playerId": "pid712799"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 03:45:12",
    "roomId": "21173170"
}


{
    "stakes": 0.5,
    "handData": {"21173170-11": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "pid920703",
            "orderIndex": 0,
            "hero": false,
            "dead": "Th1 Ad2 Qh3 2d4",
            "rows": "Kc0 As1 Ac2/2s0 8h0 8s1 6d3 6s4/3d0 3c0 3s2 9h3 Jd4",
            "win": 7.27,
            "playerId": "pid920703"
        },
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid712799",
            "orderIndex": 1,
            "hero": true,
            "dead": "2h1 Js2 5s3 4s4",
            "rows": "Qs0 Qd1 9d3/Kd0 Ah1 Ts2 Kh3 9s4/5c0 7c0 8c0 9c2 5h4",
            "win": -7.5,
            "playerId": "pid712799"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 03:46:42",
    "roomId": "21173170"
}


{
    "stakes": 0.5,
    "handData": {"21173170-12": [
        {
            "inFantasy": true,
            "result": 20,
            "playerName": "pid920703",
            "orderIndex": 1,
            "hero": false,
            "dead": "5c0 3h1 2s2",
            "rows": "Kh0 Kd0 As0/9c0 Th0 Ts0 Qd0 Qs0/8d0 8s0 Jh0 Jc0 Js0",
            "win": 9.7,
            "playerId": "pid920703"
        },
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid712799",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ac1 9s2 7h3 4s4",
            "rows": "Qh0 Qc1 3d3/8c0 Ks1 Ah2 6c4 9d4/3c0 4h0 5d0 6s2 2d3",
            "win": -10,
            "playerId": "pid712799"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 03:47:19",
    "roomId": "21173170"
}


{
    "stakes": 0.5,
    "handData": {"21173170-13": [
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "pid920703",
            "orderIndex": 0,
            "hero": false,
            "dead": "4d1 Td2 3c3 4h4",
            "rows": "As0 2c3 2h4/9s0 Qc0 Qs1 Jd2 Qd4/Kd0 Kc0 Kh1 7s2 Ks3",
            "win": 8.73,
            "playerId": "pid920703"
        },
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid712799",
            "orderIndex": 1,
            "hero": true,
            "dead": "4s1 Js2 Jc3 5d4",
            "rows": "Qh0 2s3 8s4/8d0 3s1 6s1 3h2 8c4/9d0 9c0 Th0 Tc2 5s3",
            "win": -9,
            "playerId": "pid712799"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 03:48:35",
    "roomId": "21173170"
}


{
    "stakes": 0.5,
    "handData": {"21173170-14": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid920703",
            "orderIndex": 1,
            "hero": false,
            "dead": "5s1 Th2 2d3 3c4",
            "rows": "As1 Ac2 Kd4/4c0 6c0 2s2 2h3 4s3/8s0 9s0 Qh0 Qs1 7c4",
            "win": 0,
            "playerId": "pid920703"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid712799",
            "orderIndex": 0,
            "hero": true,
            "dead": "3s1 2c2 4h3 5c4",
            "rows": "Kh2 Ks2 5h3/9c0 Jh0 6h1 6s1 9d3/3d0 7d0 Td0 7s4 Kc4",
            "win": 0,
            "playerId": "pid712799"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 03:49:49",
    "roomId": "21173170"
}


{
    "stakes": 0.5,
    "handData": {"21173170-15": [
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "pid920703",
            "orderIndex": 0,
            "hero": false,
            "dead": "7h1 Ah2 Js3 2c4",
            "rows": "Kd0 Qd3 6h4/3d0 5s0 7d1 8s3 3h4/9s0 Qh0 Qs1 4h2 4s2",
            "win": -2.5,
            "playerId": "pid920703"
        },
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid712799",
            "orderIndex": 1,
            "hero": true,
            "dead": "4d1 Ts2 Ad3 9d4",
            "rows": "3s1 Kh2 Td4/2s0 6s0 Jh0 Jd2 Ks4/Tc0 Qc0 7c1 3c3 4c3",
            "win": 2.42,
            "playerId": "pid712799"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 03:51:04",
    "roomId": "21173170"
}


{
    "stakes": 0.5,
    "handData": {"21173170-16": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid920703",
            "orderIndex": 1,
            "hero": false,
            "dead": "4c1 Ks2 3c3 3d4",
            "rows": "As0 Ah1 8c3/7c0 9c0 9d2 Qs3 7d4/Tc0 Ts0 Js1 Th2 8h4",
            "win": 0,
            "playerId": "pid920703"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid712799",
            "orderIndex": 0,
            "hero": true,
            "dead": "Kh1 Td2 4h3 4d4",
            "rows": "Ad0 Kd2 3h3/9s0 2s1 8s3 2c4 Jh4/5h0 5d0 5s0 5c1 7h2",
            "win": 0,
            "playerId": "pid712799"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 03:51:53",
    "roomId": "21173170"
}


{
    "stakes": 0.5,
    "handData": {"21173170-17": [
        {
            "inFantasy": true,
            "result": 32,
            "playerName": "pid920703",
            "orderIndex": 0,
            "hero": false,
            "dead": "9h0 5h1 3c2",
            "rows": "Jh0 Kd0 Ks0/6d0 6c0 6s0 Th0 Td0/2d0 2s0 8h0 8c0 8s0",
            "win": 15.52,
            "playerId": "pid920703"
        },
        {
            "inFantasy": false,
            "result": -32,
            "playerName": "pid712799",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jd1 7d2 Kc3 9c4",
            "rows": "Ac1 Ad2 4c3/2c0 3d0 5d1 4h3 Qs4/5s0 7s0 Js0 As2 Qd4",
            "win": -16,
            "playerId": "pid712799"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 03:52:32",
    "roomId": "21173170"
}


{
    "stakes": 0.5,
    "handData": {"21173170-18": [
        {
            "inFantasy": false,
            "result": 14,
            "playerName": "pid920703",
            "orderIndex": 1,
            "hero": false,
            "dead": "6s1 8c2 5d3 6c4",
            "rows": "Ac0 Kc2 Kh3/2d0 3c1 7c1 2s3 3d4/4h0 4c0 Qs0 4s2 Kd4",
            "win": 6.79,
            "playerId": "pid920703"
        },
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid712799",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h1 8s2 Th3 6h4",
            "rows": "Jc2 9c4 Qc4/3h0 5c0 6d1 7h3 7d3/9d0 Ts0 Qd0 Td1 9s2",
            "win": -7,
            "playerId": "pid712799"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 03:53:22",
    "roomId": "21173170"
}


{
    "stakes": 0.5,
    "handData": {"21173170-19": [
        {
            "inFantasy": true,
            "result": 20,
            "playerName": "pid920703",
            "orderIndex": 0,
            "hero": false,
            "dead": "4s0 3s1",
            "rows": "6d0 Kh0 Kc0/7h0 8d0 9s0 Ah0 As0/Jh0 Jd0 Js0 Qh0 Qd0",
            "win": 9.7,
            "playerId": "pid920703"
        },
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid712799",
            "orderIndex": 1,
            "hero": true,
            "dead": "7d1 Ts2 7s3 2c4",
            "rows": "Ad1 3d3 Tc4/3c0 5d0 5s0 5h1 4d3/8h0 Th0 2h2 3h2 6s4",
            "win": -10,
            "playerId": "pid712799"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 03:54:07",
    "roomId": "21173170"
}


{
    "stakes": 0.5,
    "handData": {"21173170-20": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid920703",
            "orderIndex": 1,
            "hero": false,
            "dead": "7d1 Qd2 7h3 5s4",
            "rows": "Kh1 7s3 Qh4/3c0 6d0 8d0 As3 3d4/4d0 4c0 Th1 Td2 Tc2",
            "win": 1.45,
            "playerId": "pid920703"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "pid712799",
            "orderIndex": 0,
            "hero": true,
            "dead": "4h1 6h2 5d3 Jh4",
            "rows": "Ah0 Jd2 8h4/2h0 7c0 9d2 Kd3 Ac3/4s0 Ks0 3s1 Js1 Qs4",
            "win": -1.5,
            "playerId": "pid712799"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 03:54:56",
    "roomId": "21173170"
}


{
    "stakes": 0.5,
    "handData": {"21173170-21": [
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid920703",
            "orderIndex": 0,
            "hero": false,
            "dead": "2h1 3c2 2s3 5d4",
            "rows": "3s1 3h3 Kc3/4s0 5h0 7c0 5s1 4c2/Th0 Qd0 6s2 6d4 Jh4",
            "win": -9,
            "playerId": "pid920703"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "pid712799",
            "orderIndex": 1,
            "hero": true,
            "dead": "9d1 2d2 As3 9c4",
            "rows": "Ah1 Td4 Kd4/4h0 8h0 7h2 Qh2 9h3/2c0 6c0 Jc0 Qc1 Tc3",
            "win": 8.73,
            "playerId": "pid712799"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 03:56:07",
    "roomId": "21173170"
}


{
    "stakes": 0.5,
    "handData": {"21173170-22": [
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "pid920703",
            "orderIndex": 1,
            "hero": false,
            "dead": "2c1 5s2 Tc3 Kd4",
            "rows": "Td1 Ks2 5h3/9d0 Jd0 4h1 9s3 As4/3d0 3s0 Qh0 7s2 Qc4",
            "win": -2.5,
            "playerId": "pid920703"
        },
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid712799",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ts1 4s2 4d3 3c4",
            "rows": "2s3 6s4 Qs4/8c0 9c0 8d1 7h2 7c3/3h0 6h0 Th0 Ah1 Jh2",
            "win": 2.42,
            "playerId": "pid712799"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 03:57:04",
    "roomId": "21173170"
}


{
    "stakes": 0.5,
    "handData": {"21173170-23": [
        {
            "inFantasy": false,
            "result": 13,
            "playerName": "pid920703",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jc1 2c2 7d3 9d4",
            "rows": "Ac2 8c3 8h4/2d0 5c0 Qs1 Qh2 Ah4/7h0 9h0 Jh0 5h1 4h3",
            "win": 6.3,
            "playerId": "pid920703"
        },
        {
            "inFantasy": false,
            "result": -13,
            "playerName": "pid712799",
            "orderIndex": 1,
            "hero": true,
            "dead": "5s1 Jd2 2h3 2s4",
            "rows": "Kh0 Ks1 6h3/4c0 8s0 7s2 Kd3 Qc4/3d0 3s0 Th1 Td2 4s4",
            "win": -6.5,
            "playerId": "pid712799"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 03:58:16",
    "roomId": "21173170"
}


{
    "stakes": 0.5,
    "handData": {"21173170-24": [
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid920703",
            "orderIndex": 1,
            "hero": false,
            "dead": "2s1 3c2 5h3 7h4",
            "rows": "Kc0 Ac1 Kh2/4h0 6s0 6d2 Ts4 Jh4/8h0 Td0 7d1 8c3 8s3",
            "win": -7.5,
            "playerId": "pid920703"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "pid712799",
            "orderIndex": 0,
            "hero": true,
            "dead": "9d1 As2 8d3 4s4",
            "rows": "Ad0 Ah1 9c3/5d0 3d2 5c2 3h3 7s4/6h0 6c0 Jc0 Js1 Ks4",
            "win": 7.27,
            "playerId": "pid712799"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 03:59:08",
    "roomId": "21173170"
}


{
    "stakes": 0.5,
    "handData": {"21173170-25": [
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "pid920703",
            "orderIndex": 0,
            "hero": false,
            "dead": "7c1 5c2 8c3 9d4",
            "rows": "7d2 As3 Ac4/2s0 6h0 3d1 2d2 3s3/9h0 Tc0 Qs0 Ks1 Kh4",
            "win": -10.5,
            "playerId": "pid920703"
        },
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "pid712799",
            "orderIndex": 1,
            "hero": true,
            "dead": "3h0 2h0 2c0",
            "rows": "Kc0 Ah0 Ad0/6d0 6c0 9s0 Qh0 Qd0/4c0 4s0 5h0 5d0 5s0",
            "win": 10.18,
            "playerId": "pid712799"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 03:59:50",
    "roomId": "21173170"
}


{
    "stakes": 0.5,
    "handData": {"21173170-26": [
        {
            "inFantasy": false,
            "result": 14,
            "playerName": "pid920703",
            "orderIndex": 1,
            "hero": false,
            "dead": "Kc1 3h2 Ac3 Jh4",
            "rows": "Ks2 Kh3 As4/2d0 4c0 7d1 7c1 2s4/9h0 Th0 Ts0 8h2 9d3",
            "win": 6.79,
            "playerId": "pid920703"
        },
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid712799",
            "orderIndex": 0,
            "hero": true,
            "dead": "5d1 3s2 4h3 2h4",
            "rows": "Ad1 5s3 Td3/4d0 Qd0 Qh1 5h2 Qs2/6c0 9c0 Tc0 6h4 Jd4",
            "win": -7,
            "playerId": "pid712799"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 04:00:44",
    "roomId": "21173170"
}


{
    "stakes": 0.5,
    "handData": {"21173170-27": [
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "pid920703",
            "orderIndex": 0,
            "hero": false,
            "dead": "6d0 5c1",
            "rows": "8h0 8d0 8s0/7h0 9d0 9c0 9s0 Tc0/4d0 4c0 4s0 Kh0 Kc0",
            "win": 14.55,
            "playerId": "pid920703"
        },
        {
            "inFantasy": false,
            "result": -30,
            "playerName": "pid712799",
            "orderIndex": 1,
            "hero": true,
            "dead": "8c1 Qc2 Jd3 6h4",
            "rows": "Ac1 7d3 Js4/Th0 Jc0 Qd0 Td1 Jh2/3s0 5s0 6c2 2h3 7s4",
            "win": -15,
            "playerId": "pid712799"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 04:01:52",
    "roomId": "21173170"
}


{
    "stakes": 0.5,
    "handData": {"21173170-28": [
        {
            "inFantasy": true,
            "result": 8,
            "playerName": "pid920703",
            "orderIndex": 1,
            "hero": false,
            "dead": "Ts0 9h1",
            "rows": "Jh0 Qh0 Ac0/4d0 7d0 8d0 Jd0 Kd0/5h0 5d0 5c0 6h0 6c0",
            "win": 3.88,
            "playerId": "pid920703"
        },
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid712799",
            "orderIndex": 0,
            "hero": true,
            "dead": "9d1 4c2 4h3 As4",
            "rows": "Ks2 Td3 Th4/2h0 3s1 7h1 3c3 2s4/7s0 8s0 9c0 Tc0 6s2",
            "win": -4,
            "playerId": "pid712799"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 04:03:10",
    "roomId": "21173170"
}


