{
    "stakes": 0.5,
    "handData": {"21187174-1": [
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "pid899252",
            "orderIndex": 1,
            "hero": true,
            "dead": "Td1 Jc2 5s3 3d4",
            "rows": "Ad1 Kd2 6s4/4s0 6d0 2s1 2d2 6c4/7h0 8h0 9h0 Ts3 Jh3",
            "win": -2.5,
            "playerId": "pid899252"
        },
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid895780",
            "orderIndex": 0,
            "hero": false,
            "dead": "2h1 Qh2 Qd3 7c4",
            "rows": "Kc1 Qs2 Ks2/3c0 4c0 4d3 5d3 3s4/8d0 9d0 Js0 9s1 8s4",
            "win": 2.37,
            "playerId": "pid895780"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 19:52:45",
    "roomId": "21187174"
}


{
    "stakes": 0.5,
    "handData": {"21187174-2": [
        {
            "inFantasy": false,
            "result": -24,
            "playerName": "pid899252",
            "orderIndex": 0,
            "hero": true,
            "dead": "4h1 2h2 2s3 4d4",
            "rows": "Ac1 Ah3 Kc4/3h0 3c0 5s0 9s3 Qd4/6d0 6s0 8d1 Qh2 Qs2",
            "win": -12,
            "playerId": "pid899252"
        },
        {
            "inFantasy": true,
            "result": 24,
            "playerName": "pid895780",
            "orderIndex": 1,
            "hero": false,
            "dead": "Td0 9d1",
            "rows": "Kh0 Ks0 Ad0/2c0 3s0 4s0 5c0 As0/8h0 8c0 Jh0 Jd0 Js0",
            "win": 11.4,
            "playerId": "pid895780"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 19:53:33",
    "roomId": "21187174"
}


{
    "stakes": 0.5,
    "handData": {"21187174-3": [
        {
            "inFantasy": false,
            "result": 20,
            "playerName": "pid899252",
            "orderIndex": 1,
            "hero": true,
            "dead": "2c1 7s2 9h3 6d4",
            "rows": "Kh0 8h3 Kc3/8s0 Ts1 8d2 Tc2 Ad4/3c0 3s0 Qh0 Qd1 Qs4",
            "win": 9.5,
            "playerId": "pid899252"
        },
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid895780",
            "orderIndex": 0,
            "hero": false,
            "dead": "7c1 2h2 Jh3 7h4",
            "rows": "Ac1 5s3 Td4/9s0 Jc0 6h2 Js2 As4/4c0 4s0 Ks0 4d1 3h3",
            "win": -10,
            "playerId": "pid895780"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 19:55:13",
    "roomId": "21187174"
}


{
    "stakes": 0.5,
    "handData": {"21187174-4": [
        {
            "inFantasy": true,
            "result": -2,
            "playerName": "pid899252",
            "orderIndex": 0,
            "hero": true,
            "dead": "9s0 3s0",
            "rows": "Kc0 Ad0 As0/7s0 8d0 9d0 Tc0 Jh0/3h0 4h0 9h0 Th0 Ah0",
            "win": -1,
            "playerId": "pid899252"
        },
        {
            "inFantasy": false,
            "result": 2,
            "playerName": "pid895780",
            "orderIndex": 1,
            "hero": false,
            "dead": "2c1 4s2 8c3 2d4",
            "rows": "Js3 3d4 5s4/5h0 5c0 6h0 6s2 6c3/7h0 7d0 Td1 Ts1 7c2",
            "win": 0.95,
            "playerId": "pid895780"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 19:56:07",
    "roomId": "21187174"
}


{
    "stakes": 0.5,
    "handData": {"21187174-5": [
        {
            "inFantasy": false,
            "result": -1,
            "playerName": "pid899252",
            "orderIndex": 1,
            "hero": true,
            "dead": "Js1 7h2 8h3 4s4",
            "rows": "Ad0 Ks1 Qh4/4c0 6h0 Th3 Ah3 6s4/2d0 Qd0 5d1 4d2 Td2",
            "win": -0.5,
            "playerId": "pid899252"
        },
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid895780",
            "orderIndex": 0,
            "hero": false,
            "dead": "3s1 2h2 2s3 3h4",
            "rows": "Ts2 4h3 Kd3/5c0 6c0 7c1 9d2 Ac4/8d0 8s0 Jc0 Jd1 8c4",
            "win": 0.5,
            "playerId": "pid895780"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 19:57:43",
    "roomId": "21187174"
}


{
    "stakes": 0.5,
    "handData": {"21187174-6": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid899252",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h1 3d2 Jc3 4d4",
            "rows": "Qc0 Kh2 Qs4/6d0 As1 7d2 Ah3 8d4/5s0 6s0 7s0 8s1 Ts3",
            "win": 2.85,
            "playerId": "pid899252"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid895780",
            "orderIndex": 1,
            "hero": false,
            "dead": "Tc1 Js2 5h3 6h4",
            "rows": "Th1 Ac2 6c3/3h0 9h0 3s1 8h3 8c4/2d0 5d0 Jd0 Ad2 9d4",
            "win": -3,
            "playerId": "pid895780"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 19:58:42",
    "roomId": "21187174"
}


{
    "stakes": 0.5,
    "handData": {"21187174-7": [
        {
            "inFantasy": true,
            "result": 13,
            "playerName": "pid899252",
            "orderIndex": 1,
            "hero": true,
            "dead": "6d0",
            "rows": "Td0 Ts0 Jd0/4c0 5h0 6c0 7d0 8c0/7h0 9h0 Th0 Kh0 Ah0",
            "win": 6.17,
            "playerId": "pid899252"
        },
        {
            "inFantasy": false,
            "result": -13,
            "playerName": "pid895780",
            "orderIndex": 0,
            "hero": false,
            "dead": "7c1 9d2 8h3 5s4",
            "rows": "3d1 Ad3 Js4/2h0 4h0 5c0 2c1 2d4/8s0 Ks0 4s2 Qs2 2s3",
            "win": -6.5,
            "playerId": "pid895780"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 19:59:37",
    "roomId": "21187174"
}


{
    "stakes": 0.5,
    "handData": {"21187174-8": [
        {
            "inFantasy": false,
            "result": 7,
            "playerName": "pid899252",
            "orderIndex": 0,
            "hero": true,
            "dead": "2d1 4s2 Qh3 4h4",
            "rows": "Kh1 Ah2 Jh4/7h0 Ts0 8d2 7d3 8s3/6h0 6d0 6c0 3h1 3c4",
            "win": 3.32,
            "playerId": "pid899252"
        },
        {
            "inFantasy": false,
            "result": -7,
            "playerName": "pid895780",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jd1 Th2 7c3 Js4",
            "rows": "Ks0 8h2 Ac4/2h0 3d0 9s1 9c2 2s4/4c0 5c0 Qd1 Qc3 Qs3",
            "win": -3.5,
            "playerId": "pid895780"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 20:00:41",
    "roomId": "21187174"
}


{
    "stakes": 0.5,
    "handData": {"21187174-9": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid899252",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jh1 4c2 Kc3 3h4",
            "rows": "Ks0 Kd1 7d3/8h0 2d1 6d2 2c3 Qc4/9d0 9s0 Ts0 9c2 Jd4",
            "win": -6,
            "playerId": "pid899252"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid895780",
            "orderIndex": 0,
            "hero": false,
            "dead": "8s1 6h2 5c3 6s4",
            "rows": "As2 Qh3 Kh4/8d0 Th1 Td1 Tc2 Jc4/2s0 3s0 4s0 Qs0 Js3",
            "win": 5.7,
            "playerId": "pid895780"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 20:02:04",
    "roomId": "21187174"
}


{
    "stakes": 0.5,
    "handData": {"21187174-10": [
        {
            "inFantasy": false,
            "result": 14,
            "playerName": "pid899252",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ah1 Qc2 Qs3 2h4",
            "rows": "9h0 Jc3 Ks4/4s0 6s0 8s1 5s2 7d4/5d0 Qd0 8d1 4d2 2d3",
            "win": 6.65,
            "playerId": "pid899252"
        },
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid895780",
            "orderIndex": 1,
            "hero": false,
            "dead": "5h1 8h2 2c3 9c4",
            "rows": "Kd0 3s3 Kc3/Qh0 4c1 Jh2 4h4 Ac4/7c0 8c0 9s0 Jd1 Tc2",
            "win": -7,
            "playerId": "pid895780"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 20:03:12",
    "roomId": "21187174"
}


{
    "stakes": 0.5,
    "handData": {"21187174-11": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid899252",
            "orderIndex": 1,
            "hero": true,
            "dead": "6h1 Kc2 6c3 3c4",
            "rows": "Kh0 Kd0 Ah3/4d0 4c1 Qh2 5c3 9h4/7s0 Ts0 Js1 9c2 7h4",
            "win": 0,
            "playerId": "pid899252"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid895780",
            "orderIndex": 0,
            "hero": false,
            "dead": "6d1 8s2 4s3 2d4",
            "rows": "As1 5h3 Ad3/2s0 Jh0 Jc1 3h2 3s2/Td0 Tc0 Qs0 5d4 7d4",
            "win": 0,
            "playerId": "pid895780"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 20:04:41",
    "roomId": "21187174"
}


{
    "stakes": 0.5,
    "handData": {"21187174-12": [
        {
            "inFantasy": false,
            "result": 8,
            "playerName": "pid899252",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jh1 4h2 Kd3 6s4",
            "rows": "Qc2 Qh4 Ad4/4s0 6h0 4c1 6d1 5s2/7h0 8c0 8s0 9h3 9s3",
            "win": 3.8,
            "playerId": "pid899252"
        },
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid895780",
            "orderIndex": 1,
            "hero": false,
            "dead": "7d1 3d2 Js3 7s4",
            "rows": "3h2 6c3 Jc3/2d0 2c0 4d0 5d1 8h4/Tc0 Qs0 Th1 Td2 Ah4",
            "win": -4,
            "playerId": "pid895780"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 20:05:32",
    "roomId": "21187174"
}


{
    "stakes": 0.5,
    "handData": {"21187174-13": [
        {
            "inFantasy": true,
            "result": 17,
            "playerName": "pid899252",
            "orderIndex": 1,
            "hero": true,
            "dead": "3h0",
            "rows": "Qd0 Ah0 As0/8h0 Th0 Td0 Tc0 Jc0/5c0 5s0 9d0 9c0 9s0",
            "win": 8.07,
            "playerId": "pid899252"
        },
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid895780",
            "orderIndex": 0,
            "hero": false,
            "dead": "3s1 5d2 8c3 3c4",
            "rows": "Kd1 Ac3 6d4/2c0 4d0 4c1 4h2 7d2/Ts0 Js0 Qs0 8s3 2s4",
            "win": -8.5,
            "playerId": "pid895780"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 20:06:12",
    "roomId": "21187174"
}


{
    "stakes": 0.5,
    "handData": {"21187174-14": [
        {
            "inFantasy": false,
            "result": -4,
            "playerName": "pid899252",
            "orderIndex": 0,
            "hero": true,
            "dead": "7h1 Qc2 7d3 2c4",
            "rows": "Ad1 Qs3 Kc3/5h0 9s0 8h1 9h2 7c4/Th0 Ts0 Jh0 Js2 Td4",
            "win": -2,
            "playerId": "pid899252"
        },
        {
            "inFantasy": false,
            "result": 4,
            "playerName": "pid895780",
            "orderIndex": 1,
            "hero": false,
            "dead": "Tc1 5d2 7s3 2s4",
            "rows": "Ks0 Ah2 Ac3/Jd0 3h1 8c2 8d3 3s4/6d0 6s0 Qd0 6h1 4h4",
            "win": 1.9,
            "playerId": "pid895780"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 20:07:20",
    "roomId": "21187174"
}


{
    "stakes": 0.5,
    "handData": {"21187174-15": [
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid899252",
            "orderIndex": 1,
            "hero": true,
            "dead": "8s1 9s2 9c3 6s4",
            "rows": "9h0 As1 Ac4/3s0 4s0 4d1 Ts2 Td4/5c0 Qc0 Qh2 8h3 8d3",
            "win": -4,
            "playerId": "pid899252"
        },
        {
            "inFantasy": true,
            "result": 8,
            "playerName": "pid895780",
            "orderIndex": 0,
            "hero": false,
            "dead": "4c0 2s1 2h2",
            "rows": "Qd0 Kh0 Kd0/5d0 6c0 7d0 8c0 9d0/5h0 7h0 Th0 Jh0 Ah0",
            "win": 3.8,
            "playerId": "pid895780"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 20:08:05",
    "roomId": "21187174"
}


{
    "stakes": 0.5,
    "handData": {"21187174-16": [
        {
            "inFantasy": true,
            "result": 12,
            "playerName": "pid899252",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qh0 Js0 2c0",
            "rows": "Kd0 Ad0 As0/3h0 4c0 5d0 6d0 7d0/6c0 7c0 Tc0 Jc0 Kc0",
            "win": 5.7,
            "playerId": "pid899252"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid895780",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jd1 2h2 9c3 2s4",
            "rows": "Ac0 9s2 3c3/Qs0 4h1 6h1 Td3 Ts4/8h0 8d0 Ks0 8c2 Kh4",
            "win": -6,
            "playerId": "pid895780"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 20:09:20",
    "roomId": "21187174"
}


{
    "stakes": 0.5,
    "handData": {"21187174-17": [
        {
            "inFantasy": false,
            "result": -7,
            "playerName": "pid899252",
            "orderIndex": 1,
            "hero": true,
            "dead": "2c1 Ts2 Qd3 2d4",
            "rows": "Qh0 Ks1 Kh2/5c0 4d1 3d2 4s3 5s4/7h0 7d0 9d0 9s3 8s4",
            "win": -3.5,
            "playerId": "pid899252"
        },
        {
            "inFantasy": false,
            "result": 7,
            "playerName": "pid895780",
            "orderIndex": 0,
            "hero": false,
            "dead": "9c1 7s2 4c3 3s4",
            "rows": "Ah0 As1 4h4/2h0 8h0 2s1 Jd3 Jh4/Qs0 Kd0 6h2 6s2 Qc3",
            "win": 3.32,
            "playerId": "pid895780"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 20:10:51",
    "roomId": "21187174"
}


{
    "stakes": 0.5,
    "handData": {"21187174-18": [
        {
            "inFantasy": true,
            "result": 3,
            "playerName": "pid899252",
            "orderIndex": 0,
            "hero": true,
            "dead": "9h0 9c0",
            "rows": "Ah0 Ad0 As0/3c0 4c0 5c0 6d0 7h0/2s0 4s0 6s0 8s0 9s0",
            "win": 1.42,
            "playerId": "pid899252"
        },
        {
            "inFantasy": true,
            "result": -3,
            "playerName": "pid895780",
            "orderIndex": 1,
            "hero": false,
            "dead": "7d0 6h1 5s2",
            "rows": "Kh0 Kd0 Ac0/8d0 8c0 Th0 Td0 Tc0/Jh0 Jd0 Qd0 Qc0 Qs0",
            "win": -1.5,
            "playerId": "pid895780"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 20:11:44",
    "roomId": "21187174"
}


{
    "stakes": 0.5,
    "handData": {"21187174-19": [
        {
            "inFantasy": true,
            "result": 0,
            "playerName": "pid899252",
            "orderIndex": 1,
            "hero": true,
            "dead": "2c0",
            "rows": "Td0 Ad0 Ac0/4d0 Jh0 Jd0 Qd0 Qc0/3h0 4c0 5c0 6h0 7h0",
            "win": 0,
            "playerId": "pid899252"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid895780",
            "orderIndex": 0,
            "hero": false,
            "dead": "2s1 Kh2 4h3 8c4",
            "rows": "Kd0 Kc0 Th4/5h0 6d0 5d1 9h2 9s3/Js0 8s1 4s2 3s3 Ks4",
            "win": 0,
            "playerId": "pid895780"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 20:12:29",
    "roomId": "21187174"
}


{
    "stakes": 0.5,
    "handData": {"21187174-20": [
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid899252",
            "orderIndex": 0,
            "hero": true,
            "dead": "Td1 8h2 6c3 3s4",
            "rows": "As0 7c3 Qs4/5h0 8c0 5s1 8d1 7s2/Jd0 Kd0 2d2 2s3 6d4",
            "win": -9.5,
            "playerId": "pid899252"
        },
        {
            "inFantasy": true,
            "result": 19,
            "playerName": "pid895780",
            "orderIndex": 1,
            "hero": false,
            "dead": "3d0 2c1",
            "rows": "9c0 Qd0 Qc0/4h0 7d0 8s0 Kh0 Ks0/5d0 5c0 Ah0 Ad0 Ac0",
            "win": 9.02,
            "playerId": "pid895780"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 20:13:10",
    "roomId": "21187174"
}


{
    "stakes": 0.5,
    "handData": {"21187174-21": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid899252",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jc1 Kh2 4h3 4s4",
            "rows": "Ad1 Ks3 9s4/6c0 6s0 2s1 9h3 8d4/4d0 4c0 Tc0 Th2 Td2",
            "win": 5.7,
            "playerId": "pid899252"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid895780",
            "orderIndex": 0,
            "hero": false,
            "dead": "7s1 2h2 Qs3 5d4",
            "rows": "Kc0 Ah2 8h3/3h0 6h0 7c0 5s4 6d4/Qd0 Jd1 Js1 8s2 Jh3",
            "win": -6,
            "playerId": "pid895780"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 20:14:21",
    "roomId": "21187174"
}


{
    "stakes": 0.5,
    "handData": {"21187174-22": [
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid899252",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ks1 Jh2 2c3 5h4",
            "rows": "As0 Ac2 Qd3/5c0 3d1 4d1 2s3 Kc4/6h0 8h0 Th0 Qh2 9h4",
            "win": -4,
            "playerId": "pid899252"
        },
        {
            "inFantasy": false,
            "result": 8,
            "playerName": "pid895780",
            "orderIndex": 1,
            "hero": false,
            "dead": "Kd1 8s2 7d3 Jc4",
            "rows": "Ad0 Js2 Td3/2d0 3s0 6s2 Ah3 3c4/8d0 Tc0 7c1 Jd1 9c4",
            "win": 3.8,
            "playerId": "pid895780"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 20:15:20",
    "roomId": "21187174"
}


{
    "stakes": 0.5,
    "handData": {"21187174-23": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid899252",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jc1 5h2 9h3 3s4",
            "rows": "Kc1 Qc3 9s4/6s0 4h1 Ad2 4c3 5d4/2h0 2d0 2c0 8s0 8h2",
            "win": 5.7,
            "playerId": "pid899252"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid895780",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qd1 Ts2 7c3 Qh4",
            "rows": "2s1 3d4 9c4/5s0 9d1 4s2 Td3 Js3/3c0 7h0 8d0 Jh0 7s2",
            "win": -6,
            "playerId": "pid895780"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 20:17:12",
    "roomId": "21187174"
}


{
    "stakes": 0.5,
    "handData": {"21187174-24": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "pid899252",
            "orderIndex": 0,
            "hero": true,
            "dead": "Js1 8d2 Qd3 Td4",
            "rows": "As1 Jd2 Ks2/3c0 6c0 5c1 Qc3 2c4/4h0 Th0 Ah0 5h3 7h4",
            "win": -1.5,
            "playerId": "pid899252"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid895780",
            "orderIndex": 1,
            "hero": false,
            "dead": "7d1 4s2 5d3 9s4",
            "rows": "Kc1 Kh2 Ac3/8h0 9d0 8s1 7s2 9c4/3h0 3d0 Tc0 Ts3 3s4",
            "win": 1.42,
            "playerId": "pid895780"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 20:18:27",
    "roomId": "21187174"
}


{
    "stakes": 0.5,
    "handData": {"21187174-25": [
        {
            "inFantasy": false,
            "result": -7,
            "playerName": "pid899252",
            "orderIndex": 1,
            "hero": true,
            "dead": "5h1 3d2 8d3 Qc4",
            "rows": "Qd1 8h2 7c4/2s0 Th0 Kd1 8s3 Tc4/4c0 8c0 9c0 Ac2 2c3",
            "win": -3.5,
            "playerId": "pid899252"
        },
        {
            "inFantasy": true,
            "result": 7,
            "playerName": "pid895780",
            "orderIndex": 0,
            "hero": false,
            "dead": "4d0 3c1",
            "rows": "6c0 9h0 Jc0/2h0 3h0 4h0 5s0 6s0/7h0 7d0 7s0 Kc0 Ks0",
            "win": 3.32,
            "playerId": "pid895780"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 20:19:21",
    "roomId": "21187174"
}


{
    "stakes": 0.5,
    "handData": {"21187174-26": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid899252",
            "orderIndex": 0,
            "hero": true,
            "dead": "5h1 9c2 2d3 3h4",
            "rows": "Kd3 4c4 Tc4/2h0 4d0 5d0 3s2 Ah3/Ts0 Js0 8c1 9h1 Qd2",
            "win": 5.7,
            "playerId": "pid899252"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid895780",
            "orderIndex": 1,
            "hero": false,
            "dead": "5c1 Jd2 Jc3 8h4",
            "rows": "Ac0 Ad1 Jh4/6s0 9s0 Qh2 6h3 8s4/7c0 Kc0 Kh1 7s2 7d3",
            "win": -6,
            "playerId": "pid895780"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 20:20:18",
    "roomId": "21187174"
}


{
    "stakes": 0.5,
    "handData": {"21187174-27": [
        {
            "inFantasy": false,
            "result": 7,
            "playerName": "pid899252",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qs1 6s2 7c3 Ad4",
            "rows": "Kd0 Kc1 6d3/2c0 5s0 As3 2h4 5d4/6h0 Th0 7d1 7h2 Td2",
            "win": 3.32,
            "playerId": "pid899252"
        },
        {
            "inFantasy": false,
            "result": -7,
            "playerName": "pid895780",
            "orderIndex": 0,
            "hero": false,
            "dead": "8d1 Js2 3h3 4c4",
            "rows": "3s3 3d4 Jd4/2d0 4h0 5h0 5c1 4d3/Ts0 Ks0 Qh1 Tc2 Qc2",
            "win": -3.5,
            "playerId": "pid895780"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 20:21:30",
    "roomId": "21187174"
}


{
    "stakes": 0.5,
    "handData": {"21187174-28": [
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "pid899252",
            "orderIndex": 0,
            "hero": true,
            "dead": "7h0 4h0",
            "rows": "Jc0 Js0 Kh0/8c0 8s0 9h0 9d0 9s0/Td0 Ts0 Ah0 Ac0 As0",
            "win": 14.25,
            "playerId": "pid899252"
        },
        {
            "inFantasy": false,
            "result": -30,
            "playerName": "pid895780",
            "orderIndex": 1,
            "hero": false,
            "dead": "5c1 Ks2 2c3 3d4",
            "rows": "Kc0 5d3 8d4/2d0 4d0 7c1 4c2 7d3/3s0 6s0 5s1 Qs2 6d4",
            "win": -15,
            "playerId": "pid895780"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 20:22:32",
    "roomId": "21187174"
}


