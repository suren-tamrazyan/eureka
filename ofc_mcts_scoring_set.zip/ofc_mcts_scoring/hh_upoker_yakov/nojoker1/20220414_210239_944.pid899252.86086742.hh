{
    "stakes": 0.5,
    "handData": {"21185826-1": [
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "pid899252",
            "orderIndex": 0,
            "hero": true,
            "dead": "8s1 6c2 7h3 3h4",
            "rows": "Kd0 Ks2 9s4/2s0 9h0 5c1 9c2 2d4/3c0 Tc0 Td1 6h3 6d3",
            "win": 4.27,
            "playerId": "pid899252"
        },
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "pid895780",
            "orderIndex": 1,
            "hero": false,
            "dead": "Ts1 4d2 4s3 8c4",
            "rows": "7c2 5d3 Th4/2c0 3d0 6s0 Kh3 8h4/Jc0 Qd0 4c1 Qc1 Qh2",
            "win": -4.5,
            "playerId": "pid895780"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 18:02:39",
    "roomId": "21185826"
}


{
    "stakes": 0.5,
    "handData": {"21185826-2": [
        {
            "inFantasy": true,
            "result": 16,
            "playerName": "pid899252",
            "orderIndex": 1,
            "hero": true,
            "dead": "8d0 7h0",
            "rows": "5h0 5c0 Ac0/8h0 9h0 Td0 Jd0 Qc0/3h0 3c0 3s0 4h0 4d0",
            "win": 7.6,
            "playerId": "pid899252"
        },
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid895780",
            "orderIndex": 0,
            "hero": false,
            "dead": "9s1 Qh2 6d3 Kc4",
            "rows": "Kh0 Ad2 Ah3/4s0 8s1 7c3 5d4 9d4/2c0 6c0 9c0 8c1 4c2",
            "win": -8,
            "playerId": "pid895780"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 18:03:30",
    "roomId": "21185826"
}


{
    "stakes": 0.5,
    "handData": {"21185826-3": [
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid899252",
            "orderIndex": 0,
            "hero": true,
            "dead": "2c1 As2 3c3 2h4",
            "rows": "Ad0 Ac0 Tc2/7s0 4c1 5s3 7d3 4d4/8h0 8d0 Kh1 Kc2 Jc4",
            "win": 4.75,
            "playerId": "pid899252"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid895780",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qh1 4h2 4s3 7c4",
            "rows": "6s2 9h4 Ks4/9s0 Th0 3h1 3d1 9c3/2d0 2s0 Js0 Qd2 Jd3",
            "win": -5,
            "playerId": "pid895780"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 18:04:14",
    "roomId": "21185826"
}


{
    "stakes": 0.5,
    "handData": {"21185826-4": [
        {
            "inFantasy": true,
            "result": 18,
            "playerName": "pid899252",
            "orderIndex": 1,
            "hero": true,
            "dead": "8c0 6d0 5c0",
            "rows": "Jd0 Js0 Kh0/9h0 9s0 Th0 Td0 Qh0/2h0 2c0 2s0 3d0 3s0",
            "win": 8.55,
            "playerId": "pid899252"
        },
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid895780",
            "orderIndex": 0,
            "hero": false,
            "dead": "3h1 8d2 Ad3 6c4",
            "rows": "Ac0 As0 Jh4/4d0 7c0 6h1 4s2 6s2/Qd0 Kd1 9d3 Qc3 7s4",
            "win": -9,
            "playerId": "pid895780"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 18:04:58",
    "roomId": "21185826"
}


{
    "stakes": 0.5,
    "handData": {"21185826-5": [
        {
            "inFantasy": false,
            "result": 19,
            "playerName": "pid899252",
            "orderIndex": 0,
            "hero": true,
            "dead": "2c1 8d2 Js3 8c4",
            "rows": "Ad0 Td4 Ah4/9h0 Th0 Qc1 9d3 Qs3/6s0 Ks0 2s1 5s2 7s2",
            "win": 9.02,
            "playerId": "pid899252"
        },
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid895780",
            "orderIndex": 1,
            "hero": false,
            "dead": "3c1 5h2 2h3 3d4",
            "rows": "8h3 Ac3 Ts4/6d0 Jc0 5d1 6h1 Jh2/4h0 4s0 Qh0 Qd2 5c4",
            "win": -9.5,
            "playerId": "pid895780"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 18:05:44",
    "roomId": "21185826"
}


{
    "stakes": 0.5,
    "handData": {"21185826-6": [
        {
            "inFantasy": true,
            "result": 16,
            "playerName": "pid899252",
            "orderIndex": 1,
            "hero": true,
            "dead": "Ts0 9c0 8s0",
            "rows": "Jd0 Jc0 Kd0/2c0 3s0 4h0 5d0 Ac0/6h0 8h0 9h0 Kh0 Ah0",
            "win": 7.6,
            "playerId": "pid899252"
        },
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid895780",
            "orderIndex": 0,
            "hero": false,
            "dead": "Th1 4c2 Qh3 Qc4",
            "rows": "4s1 Ks2 2h3/5c0 9s0 7s3 5s4 8c4/4d0 8d0 Td0 3d1 Ad2",
            "win": -8,
            "playerId": "pid895780"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 18:06:56",
    "roomId": "21185826"
}


