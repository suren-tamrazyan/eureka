{
    "stakes": 0.1,
    "handData": {"21168314-1": [
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid714419",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qd1 5c2 4d3 2s4",
            "rows": "Td2 8s3 9c4/6s0 7c0 Js1 Jd2 3d3/5h0 Qh0 Kh0 8h1 7h4",
            "win": 0.97,
            "playerId": "pid714419"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid868494",
            "orderIndex": 1,
            "hero": false,
            "dead": "Tc1 9d2 Ah3 3c4",
            "rows": "Qc0 Qs2 3s4/5d0 Th1 Ts1 Kd2 6h4/2c0 4c0 6c0 4s3 6d3",
            "win": -1,
            "playerId": "pid868494"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-13 21:25:00",
    "roomId": "21168314"
}


{
    "stakes": 0.1,
    "handData": {"21168314-2": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid714419",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qd1 6h2 7h3 2d4",
            "rows": "Ks1 Ad2 3s4/Td0 Ts0 8s3 Qs3 Tc4/4h0 5h0 8h0 3h1 2h2",
            "win": 1.16,
            "playerId": "pid714419"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid868494",
            "orderIndex": 0,
            "hero": false,
            "dead": "Th1 Ac2 3c3 4c4",
            "rows": "Jh1 Jd2 As3/4s0 6c0 6s1 4d2 5s3/7d0 9d0 9c0 Js4 Kc4",
            "win": -1.2,
            "playerId": "pid868494"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-13 21:27:09",
    "roomId": "21168314"
}


{
    "stakes": 0.1,
    "handData": {"21168314-3": [
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "pid714419",
            "orderIndex": 0,
            "hero": true,
            "dead": "7c1 5s2 6d3 2s4",
            "rows": "Ac0 6c3 Js4/4d0 Qd0 2d1 5d1 Td2/8h0 Kh0 3h2 9h3 2h4",
            "win": 0.87,
            "playerId": "pid714419"
        },
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "pid868494",
            "orderIndex": 1,
            "hero": false,
            "dead": "8d1 9c2 7h3 4s4",
            "rows": "5c0 Qc1 Jc4/9d0 Th0 3d1 Ad3 Qh4/6s0 7s0 8s2 As2 3s3",
            "win": -0.9,
            "playerId": "pid868494"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-13 21:29:00",
    "roomId": "21168314"
}


{
    "stakes": 0.1,
    "handData": {"21168314-4": [
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid714419",
            "orderIndex": 1,
            "hero": true,
            "dead": "5d1 Ts2 4c3 3h4",
            "rows": "As1 Js4 Ks4/3s0 2h1 2c2 7d2 3d3/6d0 6s0 Qh0 Qc0 6h3",
            "win": 0.1,
            "playerId": "pid714419"
        },
        {
            "inFantasy": false,
            "result": -1,
            "playerName": "pid868494",
            "orderIndex": 0,
            "hero": false,
            "dead": "5s1 3c2 5h3 7h4",
            "rows": "Kh2 Qs3 Th4/Td0 Jc0 Jd2 Tc3 8c4/4h0 4d0 4s0 9h1 9d1",
            "win": -0.1,
            "playerId": "pid868494"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-13 21:30:28",
    "roomId": "21168314"
}


{
    "stakes": 0.1,
    "handData": {"21168314-5": [
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "pid714419",
            "orderIndex": 0,
            "hero": true,
            "dead": "9s1 Jd2 3d3 2s4",
            "rows": "Qd1 Kd2 Jh3/4s0 6h0 Ah2 9c3 Jc4/8d0 8s0 Ts0 8c1 7s4",
            "win": -2.1,
            "playerId": "pid714419"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "pid868494",
            "orderIndex": 1,
            "hero": false,
            "dead": "4d1 8h2 Td3 4h4",
            "rows": "Qc1 Ac3 Ad4/5h0 6s1 5d2 6d2 Kh3/2c0 3h0 3c0 3s0 2d4",
            "win": 2.03,
            "playerId": "pid868494"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-13 21:31:51",
    "roomId": "21168314"
}


{
    "stakes": 0.1,
    "handData": {"21168314-6": [
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid714419",
            "orderIndex": 1,
            "hero": true,
            "dead": "8d1 5s2 4d3 4c4",
            "rows": "Ks0 6h3 7d4/3h0 Jh0 Th1 Js2 7h4/2c0 Qc0 Qd1 2d2 Qh3",
            "win": -1,
            "playerId": "pid714419"
        },
        {
            "inFantasy": true,
            "result": 10,
            "playerName": "pid868494",
            "orderIndex": 0,
            "hero": false,
            "dead": "6c0 5h1 4s2",
            "rows": "Kc0 Ah0 As0/8h0 9d0 9c0 9s0 Qs0/3d0 5d0 Td0 Jd0 Kd0",
            "win": 0.97,
            "playerId": "pid868494"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-13 21:33:20",
    "roomId": "21168314"
}


{
    "stakes": 0.1,
    "handData": {"21168314-7": [
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid714419",
            "orderIndex": 0,
            "hero": true,
            "dead": "7d1 2d2 9s3 Jd4",
            "rows": "Qd0 Ts1 Td3/5h0 Kc0 Ks0 4s3 Qc4/Ac0 4d1 2s2 5d2 Jc4",
            "win": -1.5,
            "playerId": "pid714419"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "pid868494",
            "orderIndex": 1,
            "hero": false,
            "dead": "4h1 2h2 4c3 3d4",
            "rows": "8h1 8d2 3h4/5c0 9d0 Jh3 Ah3 As4/6s0 7h0 7s0 6d1 6c2",
            "win": 1.45,
            "playerId": "pid868494"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-13 21:35:03",
    "roomId": "21168314"
}


{
    "stakes": 0.1,
    "handData": {"21168314-8": [
        {
            "inFantasy": false,
            "result": -11,
            "playerName": "pid714419",
            "orderIndex": 1,
            "hero": true,
            "dead": "8d1 8c2 4h3 5h4",
            "rows": "Jd2 Th3 Jc4/3s0 Ad0 Ac0 2h1 6d4/5c0 Td0 6s1 6h2 5d3",
            "win": -1.1,
            "playerId": "pid714419"
        },
        {
            "inFantasy": false,
            "result": 11,
            "playerName": "pid868494",
            "orderIndex": 0,
            "hero": false,
            "dead": "8s1 9s2 6c3 8h4",
            "rows": "Ah0 7h3 7c3/2s0 5s0 Qs2 7s4 Js4/3d0 3c0 Kh1 Ks1 Kc2",
            "win": 1.06,
            "playerId": "pid868494"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-13 21:37:18",
    "roomId": "21168314"
}


{
    "stakes": 0.1,
    "handData": {"21168314-9": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid714419",
            "orderIndex": 0,
            "hero": true,
            "dead": "8s1 Th2 4h3 8d4",
            "rows": "As0 Kd2 Ah3/3d0 9s0 3s1 9h1 2d3/6c0 7c0 Jc2 Kh4 Ac4",
            "win": -0.6,
            "playerId": "pid714419"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid868494",
            "orderIndex": 1,
            "hero": false,
            "dead": "3h1 8h2 Jd3 6h4",
            "rows": "Kc0 Qs2 3c3/4d0 Jh0 Ad2 2h4 2c4/5s0 6s0 8c1 9d1 5d3",
            "win": 0.58,
            "playerId": "pid868494"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-13 21:39:19",
    "roomId": "21168314"
}


{
    "stakes": 0.1,
    "handData": {"21168314-10": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid714419",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qh1 As2 6c3 4s4",
            "rows": "Ad0 Ac1 7c3/2c0 7h0 4d1 4c2 7d3/5d0 5s0 Jh2 6d4 8s4",
            "win": -1.2,
            "playerId": "pid714419"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid868494",
            "orderIndex": 0,
            "hero": false,
            "dead": "6h1 Kh2 5h3 7s4",
            "rows": "Ks1 Jc3 8c4/3s0 9h0 3h2 2h3 3c4/Td0 Qd0 Kd0 3d1 8d2",
            "win": 1.16,
            "playerId": "pid868494"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-13 21:41:38",
    "roomId": "21168314"
}


{
    "stakes": 0.1,
    "handData": {"21168314-11": [
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid714419",
            "orderIndex": 0,
            "hero": true,
            "dead": "8h1 8c2 5d3 8s4",
            "rows": "Ah0 Kh3 9h4/2d0 6h1 7s1 6c3 Th4/9c0 9s0 Qc0 4h2 4s2",
            "win": -1.9,
            "playerId": "pid714419"
        },
        {
            "inFantasy": false,
            "result": 19,
            "playerName": "pid868494",
            "orderIndex": 1,
            "hero": false,
            "dead": "3h1 2c2 Tc3 2s4",
            "rows": "Qd3 Ac3 Qs4/Jh0 Jc0 Js1 3c2 7h4/Td0 Jd0 Ad0 8d1 Kd2",
            "win": 1.84,
            "playerId": "pid868494"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-13 21:42:57",
    "roomId": "21168314"
}


{
    "stakes": 0.1,
    "handData": {"21168314-12": [
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid714419",
            "orderIndex": 1,
            "hero": true,
            "dead": "Tc1 Ks2 Jd3 3h4",
            "rows": "Kd0 Kh1 9h3/4c0 Js0 4h1 Jc2 2d3/7h0 Qh0 As2 8s4 9s4",
            "win": -1.9,
            "playerId": "pid714419"
        },
        {
            "inFantasy": true,
            "result": 19,
            "playerName": "pid868494",
            "orderIndex": 0,
            "hero": false,
            "dead": "4s0",
            "rows": "Qd0 Qs0 Kc0/6d0 6s0 7s0 8h0 8c0/2h0 2s0 5h0 5d0 5s0",
            "win": 1.84,
            "playerId": "pid868494"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-13 21:44:42",
    "roomId": "21168314"
}


{
    "stakes": 0.1,
    "handData": {"21168314-13": [
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid714419",
            "orderIndex": 0,
            "hero": true,
            "dead": "6s1 5h2 3c3 3s4",
            "rows": "Kh0 Qd2 6c4/Ac1 4h2 8h3 8c3 9s4/2s0 4s0 7s0 Js0 5s1",
            "win": 0.48,
            "playerId": "pid714419"
        },
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "pid868494",
            "orderIndex": 1,
            "hero": false,
            "dead": "9d1 4d2 2c3 3d4",
            "rows": "Qh0 Jc3 8d4/2d0 9c0 Qc2 Qs3 Kc4/5d0 5c0 Td1 Ts1 Jd2",
            "win": -0.5,
            "playerId": "pid868494"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-13 21:46:28",
    "roomId": "21168314"
}


{
    "stakes": 0.1,
    "handData": {"21168314-14": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "pid714419",
            "orderIndex": 1,
            "hero": true,
            "dead": "7s1 6s2 Qd3 4h4",
            "rows": "Ad0 Kd2 5s3/2h0 8h0 9h1 2d4 Ks4/9c0 Qc0 Kc1 3c2 4c3",
            "win": -0.3,
            "playerId": "pid714419"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid868494",
            "orderIndex": 0,
            "hero": false,
            "dead": "9s1 3d2 7c3 5c4",
            "rows": "2c0 Kh3 Qs4/4s0 Td0 Ts2 Th3 5d4/3h0 Ah0 6h1 Jh1 Qh2",
            "win": 0.29,
            "playerId": "pid868494"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-13 21:48:27",
    "roomId": "21168314"
}


{
    "stakes": 0.1,
    "handData": {"21168314-15": [
        {
            "inFantasy": false,
            "result": -1,
            "playerName": "pid714419",
            "orderIndex": 0,
            "hero": true,
            "dead": "8h1 8c2 7s3 2d4",
            "rows": "Qc0 3s4 Jc4/2h0 Kh0 6h1 6c2 Kd3/4d0 Td0 6d1 7d2 5d3",
            "win": -0.1,
            "playerId": "pid714419"
        },
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid868494",
            "orderIndex": 1,
            "hero": false,
            "dead": "4s1 Tc2 5s3 5c4",
            "rows": "Ks2 Ad2 Qd4/9s0 Js0 9h1 8d3 Kc4/4h0 Qh0 Ah0 3h1 5h3",
            "win": 0.1,
            "playerId": "pid868494"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-13 21:49:55",
    "roomId": "21168314"
}


{
    "stakes": 0.1,
    "handData": {"21168314-16": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "pid714419",
            "orderIndex": 1,
            "hero": true,
            "dead": "4s1 9c2 8s3 Td4",
            "rows": "Qh0 Th2 Qd3/Ad1 2d2 6c3 6s4 Ah4/7d0 8h0 9d0 Ts0 Jd1",
            "win": 1.45,
            "playerId": "pid714419"
        },
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid868494",
            "orderIndex": 0,
            "hero": false,
            "dead": "4c1 Jh2 2s3 6h4",
            "rows": "Qc1 Qs1 5s3/3h0 Kh0 2h2 9h2 Ks3/7c0 Tc0 Jc0 3c4 9s4",
            "win": -1.5,
            "playerId": "pid868494"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-13 21:51:53",
    "roomId": "21168314"
}


{
    "stakes": 0.1,
    "handData": {"21168314-17": [
        {
            "inFantasy": true,
            "result": 2,
            "playerName": "pid714419",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h0",
            "rows": "3h0 6d0 9d0/2s0 3s0 5s0 7s0 Ts0/4c0 9c0 Qc0 Kc0 Ac0",
            "win": 0.19,
            "playerId": "pid714419"
        },
        {
            "inFantasy": false,
            "result": -2,
            "playerName": "pid868494",
            "orderIndex": 1,
            "hero": false,
            "dead": "6h1 Qs2 Ah3 8s4",
            "rows": "Qd0 Qh1 8d2/5h0 Js0 5d3 7h4 7d4/3c0 8c0 6c1 5c2 2c3",
            "win": -0.2,
            "playerId": "pid868494"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-13 21:53:06",
    "roomId": "21168314"
}


{
    "stakes": 0.1,
    "handData": {"21168314-18": [
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid714419",
            "orderIndex": 1,
            "hero": true,
            "dead": "6d1 Td2 7c3 6c4",
            "rows": "Qd1 As3 Jd4/4c0 5d1 2h2 5c3 9c4/3d0 3s0 Kd0 Kc0 Ks2",
            "win": 0.1,
            "playerId": "pid714419"
        },
        {
            "inFantasy": true,
            "result": -1,
            "playerName": "pid868494",
            "orderIndex": 0,
            "hero": false,
            "dead": "4d0",
            "rows": "9h0 9s0 Ad0/5s0 Jc0 Qh0 Qs0 Kh0/2c0 2s0 7d0 8h0 8c0",
            "win": -0.1,
            "playerId": "pid868494"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-13 21:53:59",
    "roomId": "21168314"
}


{
    "stakes": 0.1,
    "handData": {"21168314-19": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid714419",
            "orderIndex": 0,
            "hero": true,
            "dead": "2d1 5s2 6h3 8c4",
            "rows": "Ac0 Kh2 As3/7c0 3c1 Td2 Tc3 Qh4/4c0 4s0 Jd0 4h1 Jh4",
            "win": -0.6,
            "playerId": "pid714419"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid868494",
            "orderIndex": 1,
            "hero": false,
            "dead": "6c1 7h2 3h3 Th4",
            "rows": "5h2 Qc3 5c4/9s0 Jc0 Js2 2s3 Ah4/8d0 9d0 Kd0 8h1 8s1",
            "win": 0.58,
            "playerId": "pid868494"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-13 21:55:18",
    "roomId": "21168314"
}


{
    "stakes": 0.1,
    "handData": {"21168314-20": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid714419",
            "orderIndex": 1,
            "hero": true,
            "dead": "Tc1 5s2 2s3 Kd4",
            "rows": "6c0 8s3 8c4/2d0 9d0 3d1 6d1 Td2/7h0 Jh0 2h2 3h3 Th4",
            "win": 1.16,
            "playerId": "pid714419"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid868494",
            "orderIndex": 0,
            "hero": false,
            "dead": "4h1 6s2 7d3 4d4",
            "rows": "Qs0 Ts1 As4/4s0 9h0 8h1 9s2 Ah3/Jc0 Ac0 9c2 4c3 3c4",
            "win": -1.2,
            "playerId": "pid868494"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-13 21:57:18",
    "roomId": "21168314"
}


{
    "stakes": 0.1,
    "handData": {"21168314-21": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid714419",
            "orderIndex": 0,
            "hero": true,
            "dead": "3h1 2d2 Ks3 2c4",
            "rows": "Kh0 Kc1 Ah3/5c0 9h0 As1 5d2 9d2/Qd0 Qs0 Qh3 8h4 Td4",
            "win": -0.6,
            "playerId": "pid714419"
        },
        {
            "inFantasy": false,
            "result": -2,
            "playerName": "pid918727",
            "orderIndex": 1,
            "hero": false,
            "dead": "Ts1 4h2 Qc3 8d4",
            "rows": "Kd2 2h3 Jh4/5s0 8s0 6c2 4c3 7h4/3c0 Tc0 Jc0 8c1 Ac1",
            "win": -0.2,
            "playerId": "pid918727"
        },
        {
            "inFantasy": false,
            "result": 8,
            "playerName": "pid868494",
            "orderIndex": 2,
            "hero": false,
            "dead": "2s1 9c2 6d3 5h4",
            "rows": "6h3 7c4 Th4/7s0 Js0 3s1 4s1 9s3/3d0 7d0 Ad0 4d2 Jd2",
            "win": 0.77,
            "playerId": "pid868494"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-13 21:59:55",
    "roomId": "21168314"
}


{
    "stakes": 0.1,
    "handData": {"21168314-22": [
        {
            "inFantasy": true,
            "result": 29,
            "playerName": "pid714419",
            "orderIndex": 2,
            "hero": true,
            "dead": "5s0 3c0",
            "rows": "Kh0 Kc0 As0/6h0 6c0 7h0 7s0 Qd0/4d0 4s0 8h0 8d0 8c0",
            "win": 2.81,
            "playerId": "pid714419"
        },
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid918727",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qh1 2d2 2h3 Ts4",
            "rows": "4c0 Ad2 Th4/7c0 9s0 Tc1 Td2 9c4/3d0 3s0 3h1 5d3 6d3",
            "win": -2,
            "playerId": "pid918727"
        },
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "pid868494",
            "orderIndex": 1,
            "hero": false,
            "dead": "2c1 Jd2 9h3 9d4",
            "rows": "Js0 Qs1 Jh2/7d0 Kd0 6s1 Qc4 Ks4/5h0 Ah0 Ac2 4h3 5c3",
            "win": -0.9,
            "playerId": "pid868494"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-13 22:02:40",
    "roomId": "21168314"
}


{
    "stakes": 0.1,
    "handData": {"21168314-23": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid714419",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jd1 7c2 6s3 Th4",
            "rows": "7s2 Jh4 Kd4/3c0 5c0 9s0 5h2 3s3/4h0 4s0 8d1 8s1 8h3",
            "win": 0.29,
            "playerId": "pid714419"
        },
        {
            "inFantasy": false,
            "result": -11,
            "playerName": "pid918727",
            "orderIndex": 2,
            "hero": false,
            "dead": "Ac1 Qc2 4d3 6c4",
            "rows": "Ks0 8c4 9h4/2d0 5d0 3h1 2h2 2c2/Tc0 Jc0 Ts1 4c3 Td3",
            "win": -1.1,
            "playerId": "pid918727"
        },
        {
            "inFantasy": false,
            "result": 8,
            "playerName": "pid868494",
            "orderIndex": 0,
            "hero": false,
            "dead": "Js1 7h2 2s3 5s4",
            "rows": "Qh0 Qd0 7d3/9c0 6h1 6d2 9d3 Kh4/3d0 Ad0 As1 Ah2 Qs4",
            "win": 0.77,
            "playerId": "pid868494"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-13 22:05:15",
    "roomId": "21168314"
}


{
    "stakes": 0.1,
    "handData": {"21168314-24": [
        {
            "inFantasy": false,
            "result": 25,
            "playerName": "pid714419",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jh1 Kd2 3h3 3s4",
            "rows": "Kc0 Ks0 As4/2s0 2d1 2c1 Td2 Ad4/5c0 8c0 7d2 4c3 6s3",
            "win": 2.42,
            "playerId": "pid714419"
        },
        {
            "inFantasy": false,
            "result": -30,
            "playerName": "pid918727",
            "orderIndex": 1,
            "hero": false,
            "dead": "Js1 9s2 5d3 2h4",
            "rows": "Ac0 Ah1 9h4/7c0 Qh0 7s1 8d3 3c4/3d0 4d0 6h2 6c2 6d3",
            "win": -3,
            "playerId": "pid918727"
        },
        {
            "inFantasy": true,
            "result": 5,
            "playerName": "pid868494",
            "orderIndex": 2,
            "hero": false,
            "dead": "8s0",
            "rows": "4s0 9d0 9c0/5h0 7h0 Th0 Tc0 Ts0/Jd0 Qd0 Qc0 Qs0 Kh0",
            "win": 0.48,
            "playerId": "pid868494"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-13 22:07:59",
    "roomId": "21168314"
}


{
    "stakes": 0.1,
    "handData": {"21168314-25": [
        {
            "inFantasy": true,
            "result": 33,
            "playerName": "pid714419",
            "orderIndex": 2,
            "hero": true,
            "dead": "3d0 2d0",
            "rows": "8h0 Ah0 Ac0/4h0 4c0 6c0 Kh0 Ks0/5d0 8d0 9d0 Jd0 Qd0",
            "win": 3.2,
            "playerId": "pid714419"
        },
        {
            "inFantasy": false,
            "result": -25,
            "playerName": "pid918727",
            "orderIndex": 0,
            "hero": false,
            "dead": "9c1 5c2 2h3 3c4",
            "rows": "Ad0 5h2 6h3/2c0 7s0 7h1 7d1 8c3/Ts0 Jh0 Js2 4d4 Qs4",
            "win": -2.5,
            "playerId": "pid918727"
        },
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid868494",
            "orderIndex": 1,
            "hero": false,
            "dead": "5s1 2s2 Jc3 4s4",
            "rows": "As1 Qc3 8s4/7c0 Kc0 Kd1 6d2 6s4/9h0 Th0 Qh0 Tc2 Td3",
            "win": -0.8,
            "playerId": "pid868494"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-13 22:10:23",
    "roomId": "21168314"
}


{
    "stakes": 0.1,
    "handData": {"21168314-26": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid714419",
            "orderIndex": 0,
            "hero": true,
            "dead": "9s1 2h2 7h3 Ks4",
            "rows": "Qh0 4s2 Th2/6h0 7s0 5s1 8d1 8h4/3c0 Jc0 3s3 Jd3 Ad4",
            "win": 0.58,
            "playerId": "pid714419"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid868494",
            "orderIndex": 1,
            "hero": false,
            "dead": "3h1 3d2 4c3 5d4",
            "rows": "6c1 Qc2 9c4/2c0 Kh0 5c1 Ac3 As4/2d0 9d0 Td0 6d2 Js3",
            "win": -0.6,
            "playerId": "pid868494"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-13 22:12:10",
    "roomId": "21168314"
}


{
    "stakes": 0.1,
    "handData": {"21168314-27": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid714419",
            "orderIndex": 1,
            "hero": true,
            "dead": "2c1 8d2 4c3 9s4",
            "rows": "6d1 Qh2 4s3/3d0 5d0 7c0 6h2 Ad3/Ts0 Js0 Jc1 Jd4 Kc4",
            "win": 0.58,
            "playerId": "pid714419"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid868494",
            "orderIndex": 0,
            "hero": false,
            "dead": "8h1 2d2 7h3 2s4",
            "rows": "Ks0 5h2 Kh4/9d1 As1 3h2 9h3 Td4/2h0 3c0 4d0 5c0 3s3",
            "win": -0.6,
            "playerId": "pid868494"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-13 22:14:46",
    "roomId": "21168314"
}


{
    "stakes": 0.1,
    "handData": {"21168314-28": [
        {
            "inFantasy": false,
            "result": 11,
            "playerName": "pid714419",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jh1 3s2 2c3 3d4",
            "rows": "Kc1 Td3 Th4/5c0 8h0 5d1 8d2 6s4/9s0 Qh0 Qd0 6h2 9d3",
            "win": 1.06,
            "playerId": "pid714419"
        },
        {
            "inFantasy": false,
            "result": -11,
            "playerName": "pid868494",
            "orderIndex": 1,
            "hero": false,
            "dead": "3h1 Js2 2d3 4s4",
            "rows": "Qs3 8s4 9c4/5s1 7d1 Qc2 Kd2 Ks3/3c0 7h0 Tc0 Jd0 Ah0",
            "win": -1.1,
            "playerId": "pid868494"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-13 22:17:27",
    "roomId": "21168314"
}


