{
    "stakes": 2,
    "handData": {"21174000-1": [
        {
            "inFantasy": false,
            "result": 20,
            "playerName": "pid521784",
            "orderIndex": 0,
            "hero": true,
            "dead": "8h1 9d2 7s3 7c4",
            "rows": "Kd2 Jh4 Kh4/4s0 5d0 4d1 Jc2 5h3/Th0 Td0 Ts0 3s1 3d3",
            "win": 232.8,
            "playerId": "pid521784"
        },
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid920703",
            "orderIndex": 1,
            "hero": false,
            "dead": "Tc1 5c2 4h3 2s4",
            "rows": "Ah0 Ac1 Qs4/6d0 7d1 6c2 9c2 9s3/8d0 8s0 Ks0 As3 3h4",
            "win": -240,
            "playerId": "pid920703"
        }
    ]},
    "appName": "Upoker",
    "price": "1BRL",
    "joined": true,
    "clubId": "88559",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 04:54:02",
    "roomId": "21174000"
}


{
    "stakes": 2,
    "handData": {"21174000-2": [
        {
            "inFantasy": true,
            "result": 18,
            "playerName": "pid521784",
            "orderIndex": 1,
            "hero": true,
            "dead": "Tc0 2h0",
            "rows": "Qs0 Kd0 Ks0/4h0 4c0 7h0 7d0 Jh0/3d0 3s0 Ah0 Ac0 As0",
            "win": 209.52,
            "playerId": "pid521784"
        },
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid920703",
            "orderIndex": 0,
            "hero": false,
            "dead": "Td1 4d2 2d3 7c4",
            "rows": "2s3 8h4 Qh4/5s0 6d0 6c1 5d2 2c3/Ts0 Jc0 Qc0 9h1 8s2",
            "win": -216,
            "playerId": "pid920703"
        }
    ]},
    "appName": "Upoker",
    "price": "1BRL",
    "joined": true,
    "clubId": "88559",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 04:54:30",
    "roomId": "21174000"
}


{
    "stakes": 2,
    "handData": {"21174000-3": [
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid521784",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jc1 4s2 Qc3 5h4",
            "rows": "Kd0 Jd2 8h4/3c0 6h0 2c1 2s2 3h3/9h0 Td0 Th1 7d3 9d4",
            "win": -228,
            "playerId": "pid521784"
        },
        {
            "inFantasy": false,
            "result": 19,
            "playerName": "pid920703",
            "orderIndex": 1,
            "hero": false,
            "dead": "9s1 Qs2 9c3 4c4",
            "rows": "Ad0 Ac1 Kc4/3s0 6d0 3d2 6s2 Ts3/4h0 Qh0 2h1 7h3 Jh4",
            "win": 221.16,
            "playerId": "pid920703"
        }
    ]},
    "appName": "Upoker",
    "price": "1BRL",
    "joined": true,
    "clubId": "88559",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 04:55:12",
    "roomId": "21174000"
}


{
    "stakes": 2,
    "handData": {"21174000-4": [
        {
            "inFantasy": false,
            "result": -22,
            "playerName": "pid521784",
            "orderIndex": 1,
            "hero": true,
            "dead": "8s1 5s2 5c3 2s4",
            "rows": "Kh0 9d3 Ah4/3d0 7h0 7c2 4c3 Jd4/8c0 Qc0 Tc1 Ac1 2c2",
            "win": -264,
            "playerId": "pid521784"
        },
        {
            "inFantasy": true,
            "result": 22,
            "playerName": "pid920703",
            "orderIndex": 0,
            "hero": false,
            "dead": "3s0 3h1 2d2",
            "rows": "6h0 Jh0 Js0/4d0 5d0 7d0 Qd0 Ad0/8h0 8d0 Kd0 Kc0 Ks0",
            "win": 256.08,
            "playerId": "pid920703"
        }
    ]},
    "appName": "Upoker",
    "price": "1BRL",
    "joined": true,
    "clubId": "88559",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 04:56:21",
    "roomId": "21174000"
}


{
    "stakes": 2,
    "handData": {"21174000-5": [
        {
            "inFantasy": false,
            "result": 14,
            "playerName": "pid521784",
            "orderIndex": 0,
            "hero": true,
            "dead": "3s1 Ts2 4s3 2d4",
            "rows": "9d3 Kh4 Ks4/7s0 Jc0 4h1 4c2 7d2/8h0 Qd0 Qc0 8s1 7c3",
            "win": 162.96,
            "playerId": "pid521784"
        },
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid920703",
            "orderIndex": 1,
            "hero": false,
            "dead": "Tc1 Kd2 4d3 2c4",
            "rows": "Qs1 Ac1 Kc3/2s0 8d0 6c2 2h3 5s4/3h0 9h0 Th0 3d2 6d4",
            "win": -168,
            "playerId": "pid920703"
        }
    ]},
    "appName": "Upoker",
    "price": "1BRL",
    "joined": true,
    "clubId": "88559",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 04:57:13",
    "roomId": "21174000"
}


{
    "stakes": 2,
    "handData": {"21174000-6": [
        {
            "inFantasy": true,
            "result": -11,
            "playerName": "pid521784",
            "orderIndex": 1,
            "hero": true,
            "dead": "5h0 2s0",
            "rows": "Qd0 Qs0 Kc0/6h0 Th0 Tc0 Jd0 Jc0/3h0 3c0 3s0 8d0 8c0",
            "win": -132,
            "playerId": "pid521784"
        },
        {
            "inFantasy": false,
            "result": 11,
            "playerName": "pid920703",
            "orderIndex": 0,
            "hero": false,
            "dead": "9c1 6s2 6d3 8h4",
            "rows": "Kh0 Kd2 Js4/5d0 Ad2 4s3 As3 5s4/7d0 7c0 9s0 7h1 7s1",
            "win": 128.04,
            "playerId": "pid920703"
        }
    ]},
    "appName": "Upoker",
    "price": "1BRL",
    "joined": true,
    "clubId": "88559",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 04:57:39",
    "roomId": "21174000"
}


{
    "stakes": 2,
    "handData": {"21174000-7": [
        {
            "inFantasy": false,
            "result": -23,
            "playerName": "pid521784",
            "orderIndex": 0,
            "hero": true,
            "dead": "8d1 8c2 Qh3 6s4",
            "rows": "Kh0 Js2 Qd4/3h0 4c1 5s1 As3 8s4/6d0 6c0 Ts0 9h2 9c3",
            "win": -276,
            "playerId": "pid521784"
        },
        {
            "inFantasy": true,
            "result": 23,
            "playerName": "pid920703",
            "orderIndex": 1,
            "hero": false,
            "dead": "6h0 2d1",
            "rows": "Qs0 Ah0 Ad0/7d0 7c0 7s0 9s0 Tc0/3d0 3c0 Kd0 Kc0 Ks0",
            "win": 267.72,
            "playerId": "pid920703"
        }
    ]},
    "appName": "Upoker",
    "price": "1BRL",
    "joined": true,
    "clubId": "88559",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 04:58:22",
    "roomId": "21174000"
}


{
    "stakes": 2,
    "handData": {"21174000-8": [
        {
            "inFantasy": false,
            "result": 11,
            "playerName": "pid521784",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jd1 2c2 Qc3 2s4",
            "rows": "Td0 6d2 Ts3/8h0 Jh0 Jc1 8c4 9c4/3s0 Ks0 5s1 Kc2 3d3",
            "win": 128.04,
            "playerId": "pid521784"
        },
        {
            "inFantasy": false,
            "result": -11,
            "playerName": "pid920703",
            "orderIndex": 0,
            "hero": false,
            "dead": "5c1 5d2 4s3 4d4",
            "rows": "Ad0 Ac0 Kh3/2d0 6h0 6s2 7h3 7d4/Js0 8s1 9h1 8d2 Qd4",
            "win": -132,
            "playerId": "pid920703"
        }
    ]},
    "appName": "Upoker",
    "price": "1BRL",
    "joined": true,
    "clubId": "88559",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 04:59:24",
    "roomId": "21174000"
}


{
    "stakes": 2,
    "handData": {"21174000-9": [
        {
            "inFantasy": false,
            "result": 14,
            "playerName": "pid521784",
            "orderIndex": 0,
            "hero": true,
            "dead": "Kh1 9c2 5s3 4c4",
            "rows": "Ac1 2h2 3h3/8s0 9h0 Th1 Js2 Qc3/2d0 6d0 Kd0 3d4 Td4",
            "win": 162.96,
            "playerId": "pid521784"
        },
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid920703",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jd1 8h2 2s3 7d4",
            "rows": "Qd1 Qs2 Ks3/3s0 4s0 5h0 5d2 Ad4/7c0 Jc0 8c1 2c3 Jh4",
            "win": -168,
            "playerId": "pid920703"
        }
    ]},
    "appName": "Upoker",
    "price": "1BRL",
    "joined": true,
    "clubId": "88559",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 05:00:06",
    "roomId": "21174000"
}


{
    "stakes": 2,
    "handData": {"21174000-10": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid521784",
            "orderIndex": 1,
            "hero": true,
            "dead": "2d1 7c2 4s3 3s4",
            "rows": "Ad0 9c3 As3/6c0 6s0 Ts1 5d2 Tc4/8d0 Qd0 Qs1 2h2 5h4",
            "win": -72,
            "playerId": "pid521784"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid920703",
            "orderIndex": 0,
            "hero": false,
            "dead": "Td1 Kd2 Th3 7d4",
            "rows": "Kh1 Jc3 Ac3/4c0 7h0 6d1 6h2 8c4/9s0 Js0 Ks0 8s2 Jd4",
            "win": 69.84,
            "playerId": "pid920703"
        }
    ]},
    "appName": "Upoker",
    "price": "1BRL",
    "joined": true,
    "clubId": "88559",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 05:01:07",
    "roomId": "21174000"
}


{
    "stakes": 2,
    "handData": {"21174000-11": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid521784",
            "orderIndex": 0,
            "hero": true,
            "dead": "",
            "rows": "/4c0 7c0/2h0 2s0 8h0",
            "win": 0,
            "playerId": "pid521784"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid920703",
            "orderIndex": 1,
            "hero": false,
            "dead": "",
            "rows": "Qc0/7s0 8s0/2d0 9d0",
            "win": 0,
            "playerId": "pid920703"
        }
    ]},
    "appName": "Upoker",
    "price": "1BRL",
    "joined": true,
    "clubId": "88559",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 05:02:02",
    "roomId": "21174000"
}


