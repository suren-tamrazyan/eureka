{
    "stakes": 0.2,
    "handData": {"21166694-181": [
        {
            "inFantasy": false,
            "result": 16,
            "playerName": "pid713627",
            "orderIndex": 1,
            "hero": true,
            "dead": "4s1 3s2 Qs3 7s4",
            "rows": "Ah0 Ad2 Kc4/5h0 5c0 2h1 2s3 9d4/9s0 Th0 8c1 7h2 6c3",
            "win": 3.1,
            "playerId": "pid713627"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "pid626647",
            "orderIndex": 2,
            "hero": false,
            "dead": "6h1 3c2 3h3 Jc4",
            "rows": "As0 Ac2 Jd3/Td1 Ts1 2d2 6d3 6s4/8h0 9c0 Tc0 Jh0 Qd4",
            "win": 3.49,
            "playerId": "pid626647"
        },
        {
            "inFantasy": false,
            "result": -34,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "2c1 5d2 5s3 7d4",
            "rows": "Js1 Ks3 Kd4/3d0 4h0 4c1 4d2 9h3/8d0 8s0 Qc0 Qh2 7c4",
            "win": -6.8,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 00:29:33",
    "roomId": "21166694"
}


{
    "stakes": 0.2,
    "handData": {"21166694-182": [
        {
            "inFantasy": true,
            "result": 13,
            "playerName": "pid713627",
            "orderIndex": 0,
            "hero": true,
            "dead": "5h0 5c0 2c0",
            "rows": "9c0 Jd0 Js0/6d0 7h0 8s0 9h0 Th0/4d0 7d0 8d0 Td0 Kd0",
            "win": 2.52,
            "playerId": "pid713627"
        },
        {
            "inFantasy": true,
            "result": 11,
            "playerName": "pid626647",
            "orderIndex": 1,
            "hero": false,
            "dead": "8h0 6h1 5d2",
            "rows": "Qd0 Qc0 Ac0/3d0 3c0 4h0 4c0 Jh0/2s0 7s0 Ts0 Ks0 As0",
            "win": 2.13,
            "playerId": "pid626647"
        },
        {
            "inFantasy": false,
            "result": -24,
            "playerName": "pid767560",
            "orderIndex": 2,
            "hero": false,
            "dead": "9s1 2h2 Ah3 2d4",
            "rows": "Ad1 3h2 6s3/9d0 Qs0 Qh2 3s3 4s4/7c0 8c0 Tc0 6c1 Kc4",
            "win": -4.8,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 00:31:00",
    "roomId": "21166694"
}


{
    "stakes": 0.2,
    "handData": {"21166694-183": [
        {
            "inFantasy": false,
            "result": 19,
            "playerName": "pid713627",
            "orderIndex": 1,
            "hero": true,
            "dead": "3h1 3d2 3s3 4s4",
            "rows": "Ah1 Qh4 Qs4/6d0 8s0 9s1 9d2 8d3/Ts0 Jc0 Js0 Td2 Th3",
            "win": 3.68,
            "playerId": "pid713627"
        },
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "3c1 6s2 7d3 2h4",
            "rows": "Kh0 Kd0 Ac2/7s0 5h1 7c1 7h3 9c3/2d0 Qd0 8h2 5s4 9h4",
            "win": -3.8,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 00:32:09",
    "roomId": "21166694"
}


{
    "stakes": 0.2,
    "handData": {"21166694-184": [
        {
            "inFantasy": true,
            "result": 18,
            "playerName": "pid713627",
            "orderIndex": 0,
            "hero": true,
            "dead": "3c0",
            "rows": "4s0 5s0 6s0/4d0 6d0 Td0 Jd0 Kd0/5h0 9h0 Qh0 Kh0 Ah0",
            "win": 3.49,
            "playerId": "pid713627"
        },
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid767560",
            "orderIndex": 1,
            "hero": false,
            "dead": "7d1 3d2 6c3 2c4",
            "rows": "Kc2 As3 Qc4/9d0 Qs0 7c1 Qd1 9c2/2h0 6h0 Th0 7h3 Jc4",
            "win": -3.6,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 00:32:45",
    "roomId": "21166694"
}


{
    "stakes": 0.2,
    "handData": {"21166694-185": [
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid713627",
            "orderIndex": 1,
            "hero": true,
            "dead": "6c1 Qc2 Kc3 5h4",
            "rows": "7d1 Ad2 Qd4/4c0 Th0 Tc3 Jc3 Jh4/2s0 3s0 Qs0 7s1 6s2",
            "win": 1.94,
            "playerId": "pid713627"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "3h1 9h2 3d3 2h4",
            "rows": "Kd0 Kh1 Ah3/6h0 7h0 7c1 Jd2 8d4/Td0 Ts0 5s2 5c3 4d4",
            "win": -2,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 00:33:56",
    "roomId": "21166694"
}


{
    "stakes": 0.2,
    "handData": {"21166694-186": [
        {
            "inFantasy": false,
            "result": 8,
            "playerName": "pid713627",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h1 Qs2 3h3 6d4",
            "rows": "Ac0 Qd2 8c4/6h0 Tc0 Jc1 Jd2 6s3/Kh0 Kd0 4h1 Kc3 4s4",
            "win": 1.55,
            "playerId": "pid713627"
        },
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid767560",
            "orderIndex": 1,
            "hero": false,
            "dead": "9d1 8h2 Qc3 5c4",
            "rows": "Th2 Ah2 Jh4/2c0 9c0 9s3 Ks3 2s4/3s0 8s0 As0 5s1 Js1",
            "win": -1.6,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 00:35:07",
    "roomId": "21166694"
}


{
    "stakes": 0.2,
    "handData": {"21166694-187": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "pid713627",
            "orderIndex": 1,
            "hero": true,
            "dead": "8s1 Qh2 9c3 Ts4",
            "rows": "Ac2 Ah3 Qd4/Kd0 6d1 2d2 6s3 Ks4/3s0 4s0 5s0 As0 Js1",
            "win": 2.91,
            "playerId": "pid713627"
        },
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jc1 Td2 Kc3 4h4",
            "rows": "Ad3 5h4 Tc4/3d0 4c0 3c1 8d1 4d2/2h0 3h0 7h0 Th2 Kh3",
            "win": -3,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 00:36:18",
    "roomId": "21166694"
}


{
    "stakes": 0.2,
    "handData": {"21166694-188": [
        {
            "inFantasy": true,
            "result": 37,
            "playerName": "pid713627",
            "orderIndex": 0,
            "hero": true,
            "dead": "5s0 4s0 2h0",
            "rows": "Qh0 Ad0 Ac0/9d0 9c0 Kh0 Kd0 Ks0/6h0 6d0 6c0 6s0 7c0",
            "win": 7.17,
            "playerId": "pid713627"
        },
        {
            "inFantasy": false,
            "result": -37,
            "playerName": "pid767560",
            "orderIndex": 1,
            "hero": false,
            "dead": "7d1 5h2 Ts3 2c4",
            "rows": "Ah0 Qd3 8s4/3d0 Th0 Td1 Js1 3s3/4c0 Kc0 4h2 4d2 8c4",
            "win": -7.4,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 00:36:55",
    "roomId": "21166694"
}


{
    "stakes": 0.2,
    "handData": {"21166694-189": [
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "pid713627",
            "orderIndex": 1,
            "hero": true,
            "dead": "6s0 3d0 2c0",
            "rows": "Kc0 Ah0 As0/8h0 8d0 8c0 Td0 Qs0/3s0 4d0 5h0 6c0 7h0",
            "win": 1.16,
            "playerId": "pid713627"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jc1 5c2 3h3 6d4",
            "rows": "4h3 Tc4 Jh4/6h0 Qc0 4c1 Qh1 Qd3/5s0 8s0 Ts0 2s2 4s2",
            "win": -1.2,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 00:37:31",
    "roomId": "21166694"
}


{
    "stakes": 0.2,
    "handData": {"21166694-190": [
        {
            "inFantasy": false,
            "result": 4,
            "playerName": "pid713627",
            "orderIndex": 0,
            "hero": true,
            "dead": "6c1 6d2 Jc3 9d4",
            "rows": "Ah0 Kc2 Ad3/3c0 4d0 3s1 3h3 9c4/Th0 Tc0 Td1 Qs2 Kh4",
            "win": 0.77,
            "playerId": "pid713627"
        },
        {
            "inFantasy": false,
            "result": -4,
            "playerName": "pid767560",
            "orderIndex": 1,
            "hero": false,
            "dead": "4c1 7h2 3d3 8d4",
            "rows": "Ac0 2h2 Jd4/5h0 8c1 Kd1 5s3 5c4/Ts0 Js0 Ks0 6s2 2s3",
            "win": -0.8,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 00:38:43",
    "roomId": "21166694"
}


{
    "stakes": 0.2,
    "handData": {"21166694-191": [
        {
            "inFantasy": true,
            "result": 25,
            "playerName": "pid713627",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qs0 Jh0 5d0",
            "rows": "9h0 9d0 As0/4c0 4s0 7h0 7c0 Kd0/2h0 3h0 4h0 5h0 6h0",
            "win": 4.85,
            "playerId": "pid713627"
        },
        {
            "inFantasy": false,
            "result": -25,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "6c1 3c2 7s3 6d4",
            "rows": "Ac1 Jd2 Ah3/5s0 8d0 Kc1 Kh3 Qh4/Tc0 Ts0 Qc0 6s2 9c4",
            "win": -5,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 00:39:19",
    "roomId": "21166694"
}


{
    "stakes": 0.2,
    "handData": {"21166694-192": [
        {
            "inFantasy": true,
            "result": 32,
            "playerName": "pid713627",
            "orderIndex": 0,
            "hero": true,
            "dead": "Kc0 7c0 4h0",
            "rows": "8h0 8d0 8c0/2s0 3s0 7s0 Ts0 Js0/2d0 3d0 4d0 5d0 Kd0",
            "win": 6.2,
            "playerId": "pid713627"
        },
        {
            "inFantasy": false,
            "result": -32,
            "playerName": "pid767560",
            "orderIndex": 1,
            "hero": false,
            "dead": "9d1 4c2 5h3 7d4",
            "rows": "Ad0 9c3 Qc4/6h0 Td1 Tc1 3h2 5s3/Th0 Jc0 Qd0 9s2 Ks4",
            "win": -6.4,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 00:39:54",
    "roomId": "21166694"
}


{
    "stakes": 0.2,
    "handData": {"21166694-193": [
        {
            "inFantasy": true,
            "result": 17,
            "playerName": "pid713627",
            "orderIndex": 1,
            "hero": true,
            "dead": "5d0 4s0 3c0",
            "rows": "7h0 Td0 Ts0/9c0 Tc0 Js0 Qh0 Ks0/8d0 8c0 Ah0 Ad0 As0",
            "win": 3.29,
            "playerId": "pid713627"
        },
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "2c1 3s2 9s3 2h4",
            "rows": "Ac2 7c3 Kc4/6c0 6h1 8h1 Qs2 Qc3/2d0 6d0 7d0 9d0 3d4",
            "win": -3.4,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 00:40:44",
    "roomId": "21166694"
}


