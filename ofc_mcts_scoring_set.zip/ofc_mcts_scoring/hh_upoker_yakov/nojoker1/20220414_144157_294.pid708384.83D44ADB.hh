{
    "stakes": 0.5,
    "handData": {"21179429-1": [
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid708384",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jd1 Th2 5h3 6d4",
            "rows": "Td2 As3 7s4/3c0 Ts0 3s1 3h2 Jc3/6s0 7c0 8h0 5c1 9c4",
            "win": 4.85,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "7h1 3d2 9d3 Tc4",
            "rows": "Kh0 Qd2 Qs3/8s0 9s0 2d1 9h2 8d3/Jh0 Js0 4d1 Kc4 Ah4",
            "win": -5,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 11:41:57",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-2": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid708384",
            "orderIndex": 0,
            "hero": true,
            "dead": "Js1 6s2 9s3 5d4",
            "rows": "Ks0 5h3 Td4/2c0 3c1 Ac1 9c2 Kd4/9d0 Jd0 Ad0 2d2 7d3",
            "win": 1.45,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "pid767560",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jh1 2h2 Ah3 8h4",
            "rows": "4s2 5c3 As4/3d0 6c0 7h1 7s1 3h4/9h0 Th0 Tc0 Ts2 8d3",
            "win": -1.5,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 11:43:03",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-3": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid708384",
            "orderIndex": 1,
            "hero": true,
            "dead": "2h1 8s2 Jd3 4s4",
            "rows": "Qc0 Qs1 Ac2/3d0 6c0 6h1 Ah3 Qd4/7s0 Th0 7d2 Tc3 5h4",
            "win": 0,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "5s1 4c2 4d3 Ts4",
            "rows": "Kc0 Ad2 Ks3/Jc0 2s1 Js1 Kd4 As4/8h0 8d0 Qh0 8c2 5c3",
            "win": 0,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 11:44:08",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-4": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid708384",
            "orderIndex": 0,
            "hero": true,
            "dead": "Tc1 6d2 Qd3 3c4",
            "rows": "Kc0 Kd1 8s4/Ac0 As1 2h3 Jh3 6c4/9c0 9s0 Jd0 3h2 3d2",
            "win": 1.45,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "pid767560",
            "orderIndex": 1,
            "hero": false,
            "dead": "4h1 4c2 Th3 2d4",
            "rows": "Ad1 6s2 5s4/Qh0 Js1 Qc2 2c3 Qs3/4s0 5c0 6h0 7s0 8h4",
            "win": -1.5,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 11:45:12",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-5": [
        {
            "inFantasy": true,
            "result": -1,
            "playerName": "pid708384",
            "orderIndex": 1,
            "hero": true,
            "dead": "2h0 2d0",
            "rows": "Qs0 Ad0 As0/3h0 3s0 8h0 Td0 Ts0/4c0 6c0 Jc0 Qc0 Kc0",
            "win": -0.5,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "6h1 3c2 Ks3 7d4",
            "rows": "Ac1 Ah3 Kh4/8s0 7s1 Jh2 Js3 8c4/4d0 9d0 Qd0 Kd0 6d2",
            "win": 0.5,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 11:45:47",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-6": [
        {
            "inFantasy": false,
            "result": -25,
            "playerName": "pid708384",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ts1 Jd2 6d3 Tc4",
            "rows": "Qc2 9d3 9h4/2s0 3d0 8c1 8s1 8d4/4h0 4c0 6h0 4s2 6s3",
            "win": -12.5,
            "playerId": "pid708384"
        },
        {
            "inFantasy": true,
            "result": 25,
            "playerName": "pid767560",
            "orderIndex": 1,
            "hero": false,
            "dead": "7h0 3h1 2h2",
            "rows": "Kd0 Kc0 Ks0/4d0 5s0 6c0 7s0 8h0/Jc0 Js0 Qh0 Qd0 Qs0",
            "win": 12.12,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 11:46:32",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-7": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid708384",
            "orderIndex": 1,
            "hero": true,
            "dead": "7h1 Jc2 Js3 4d4",
            "rows": "Ks2 Ah2 Kc3/3d0 5h0 6h0 3h1 5s4/2c0 9c0 2s1 9h3 8h4",
            "win": -6,
            "playerId": "pid708384"
        },
        {
            "inFantasy": true,
            "result": 12,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "8s0 6s1 4h2",
            "rows": "9s0 Qd0 Qc0/3c0 5c0 6c0 8c0 Tc0/5d0 7d0 9d0 Jd0 Ad0",
            "win": 5.82,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 11:47:27",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-8": [
        {
            "inFantasy": true,
            "result": 25,
            "playerName": "pid708384",
            "orderIndex": 0,
            "hero": true,
            "dead": "2s0 2c0",
            "rows": "9d0 Qh0 Qc0/7d0 7c0 Kd0 Kc0 Ks0/8c0 8s0 Ah0 Ad0 As0",
            "win": 12.12,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": -25,
            "playerName": "pid767560",
            "orderIndex": 1,
            "hero": false,
            "dead": "6h1 6s2 5h3 3c4",
            "rows": "5s2 5d4 Jd4/2h0 4s0 8h1 2d3 4d3/Th0 Jh0 Jc0 Tc1 Js2",
            "win": -12.5,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 11:48:02",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-9": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid708384",
            "orderIndex": 1,
            "hero": true,
            "dead": "Ts1 2d2 9h3 2h4",
            "rows": "Ah0 Ac3 4s4/8d1 4h2 6s2 5d3 3h4/6c0 7c0 Jc0 Qc0 9c1",
            "win": 0,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "6d1 2c2 4d3 3d4",
            "rows": "Kd0 Kc2 Qs4/8h0 9d0 5c1 8c2 Td4/Jd0 Js0 Th1 2s3 Jh3",
            "win": 0,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 11:49:14",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-10": [
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid708384",
            "orderIndex": 0,
            "hero": true,
            "dead": "9s1 Ac2 2s3 2c4",
            "rows": "Qs0 Jc1 4h4/3h0 8s1 8d2 3s3 Kh4/2d0 4d0 6d0 5d2 Ad3",
            "win": 4.85,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid767560",
            "orderIndex": 1,
            "hero": false,
            "dead": "8c1 4s2 9h3 2h4",
            "rows": "5s1 Qc1 6h3/3d0 6c0 9c0 9d2 4c4/Jh0 Js0 Ah2 7s3 7c4",
            "win": -5,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 11:50:25",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-11": [
        {
            "inFantasy": false,
            "result": 14,
            "playerName": "pid708384",
            "orderIndex": 1,
            "hero": true,
            "dead": "9s1 4s2 2c3 Qd4",
            "rows": "Jd1 Kd3 Js4/2d0 3s0 6d0 Ad2 Ac2/Jh0 Kh0 Th1 3h3 5h4",
            "win": 6.79,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "2s1 6h2 3c3 7h4",
            "rows": "Ah1 6s3 Jc4/9d0 9c0 Qh1 4h3 As4/4d0 5c0 6c0 3d2 7c2",
            "win": -7,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 11:51:35",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-12": [
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid708384",
            "orderIndex": 0,
            "hero": true,
            "dead": "4c1 4d2 9h3 9d4",
            "rows": "Ac0 Kh1 9s4/2h0 3c0 6s0 6c3 3s4/7d0 Jd1 5d2 Kd2 2d3",
            "win": -5,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid767560",
            "orderIndex": 1,
            "hero": false,
            "dead": "4s1 Td2 7h3 Th4",
            "rows": "Ad2 8s3 Ah4/3d0 3h1 6h1 Ks2 6d3/5c0 9c0 Jc0 Qc0 8c4",
            "win": 4.85,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 11:52:42",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-13": [
        {
            "inFantasy": false,
            "result": -37,
            "playerName": "pid708384",
            "orderIndex": 1,
            "hero": true,
            "dead": "Kc1 3d2 Td3 Qc4",
            "rows": "Ah1 Jh3 Kh4/2s0 3s0 4h0 4c3 3c4/6d0 8c0 5s1 7d2 9d2",
            "win": -18.5,
            "playerId": "pid708384"
        },
        {
            "inFantasy": true,
            "result": 37,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qh0 3h1 2d2",
            "rows": "7h0 7c0 7s0/5h0 5d0 5c0 Jc0 Js0/6h0 6c0 6s0 Ad0 As0",
            "win": 17.94,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 11:53:28",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-14": [
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid708384",
            "orderIndex": 0,
            "hero": true,
            "dead": "Tc1 6s2 8d3 Js4",
            "rows": "Qd1 3d3 Ks4/2h0 7s2 Kd2 Ah3 2s4/8h0 8c0 8s0 Jd0 Jh1",
            "win": -7,
            "playerId": "pid708384"
        },
        {
            "inFantasy": true,
            "result": 14,
            "playerName": "pid767560",
            "orderIndex": 1,
            "hero": false,
            "dead": "9h0 6h1 3h2",
            "rows": "Qc0 Qs0 As0/2c0 3c0 4c0 5c0 7c0/5d0 7d0 9d0 Td0 Ad0",
            "win": 6.79,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 11:54:14",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-15": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid708384",
            "orderIndex": 1,
            "hero": true,
            "dead": "8c1 9s2 Kc3 9c4",
            "rows": "Qh0 Jc4 Kh4/4s0 2c1 Jd2 Js2 4h3/7c0 7s0 Tc0 Ts1 7d3",
            "win": 5.82,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "Th1 Jh2 2s3 2h4",
            "rows": "Kd0 Ks1 4d4/6d0 Qs1 3h2 3s2 Qc3/4c0 5c0 Ac0 5s3 3c4",
            "win": -6,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 11:55:28",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-16": [
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid708384",
            "orderIndex": 0,
            "hero": true,
            "dead": "4d1 2d2 5d3 As4",
            "rows": "9s1 3d4 3s4/2s0 8h0 Jh1 Jd2 5c3/3c0 Qh0 Qs0 6c2 6d3",
            "win": -9.5,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": 19,
            "playerName": "pid767560",
            "orderIndex": 1,
            "hero": false,
            "dead": "3h1 9h2 Tc3 9c4",
            "rows": "Qd0 Qc2 Kh4/4h0 Js0 4s1 Kc1 Kd2/7h0 7d0 8d3 8s3 7c4",
            "win": 9.21,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 11:56:45",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-17": [
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid708384",
            "orderIndex": 1,
            "hero": true,
            "dead": "6c1 5s2 6h3 5c4",
            "rows": "Ac0 Tc3 Th4/2s0 7c0 3s1 2c2 3c2/Jh0 Qd0 8h1 Jc3 Jd4",
            "win": -8,
            "playerId": "pid708384"
        },
        {
            "inFantasy": true,
            "result": 16,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "7s0",
            "rows": "Kc0 Ah0 Ad0/9h0 9d0 9s0 Td0 Qc0/2h0 4h0 7h0 Qh0 Kh0",
            "win": 7.76,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 11:57:37",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-18": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid708384",
            "orderIndex": 0,
            "hero": true,
            "dead": "Td1 Th2 2c3 3c4",
            "rows": "Qs1 Ah1 Qc2/5c0 5s2 6d3 9h4 As4/9s0 Ts0 Jc0 Qd0 Kd3",
            "win": 0,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid767560",
            "orderIndex": 1,
            "hero": false,
            "dead": "3s1 2d2 2s3 3d4",
            "rows": "Kc0 Ks1 9c2/5d0 Ad0 Ac0 6s3 Jh3/7h0 4c1 7c2 5h4 Qh4",
            "win": 0,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 11:58:54",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-19": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid708384",
            "orderIndex": 1,
            "hero": true,
            "dead": "Kd1 8d2 5h3 3h4",
            "rows": "7h2 7s3 9s4/2d0 Jd1 Jh2 Ks3 Jc4/2c0 5c0 8c0 Kc0 Qc1",
            "win": 1.45,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "3d1 2h2 9c3 6d4",
            "rows": "Kh0 4h3 Js4/Tc0 Ah1 Td2 Qd2 Th4/2s0 4s0 As0 6s1 5s3",
            "win": -1.5,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:00:01",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-20": [
        {
            "inFantasy": false,
            "result": 14,
            "playerName": "pid708384",
            "orderIndex": 0,
            "hero": true,
            "dead": "9s1 4d2 Jc3 9h4",
            "rows": "Ah1 3s2 Ac3/2d0 8c0 5h1 5c3 8s4/7c0 7s0 Qh0 Qs2 Qc4",
            "win": 6.79,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid767560",
            "orderIndex": 1,
            "hero": false,
            "dead": "7d1 Js2 6d3 5s4",
            "rows": "Kc0 2s3 6h4/Qd0 Ad1 As1 4h2 4c4/6s0 7h0 9c0 8h2 Ts3",
            "win": -7,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:01:16",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-21": [
        {
            "inFantasy": true,
            "result": 15,
            "playerName": "pid708384",
            "orderIndex": 1,
            "hero": true,
            "dead": "7d0 5s0 4s0",
            "rows": "Td0 Ad0 As0/6s0 7h0 8c0 9d0 Th0/2c0 6c0 9c0 Jc0 Kc0",
            "win": 7.27,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jd1 2s2 5c3 3d4",
            "rows": "Js2 8d3 Kd3/6d0 7c0 3s1 4c1 5d2/2h0 9h0 Kh0 3h4 Jh4",
            "win": -7.5,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:02:03",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-22": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid708384",
            "orderIndex": 0,
            "hero": true,
            "dead": "5s1 2s2 3s3 8c4",
            "rows": "Ac0 Ad2 5c3/2d0 4s0 2c1 6d1 Ks4/Ts0 Qh0 Tc2 Qs3 Td4",
            "win": -3,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid767560",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jd1 Jh2 6c3 9d4",
            "rows": "Kc0 6h3 Js4/3d0 3c1 7s1 7h2 9c2/4d0 4c0 8h0 5h3 4h4",
            "win": 2.91,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:03:12",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-23": [
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "pid708384",
            "orderIndex": 1,
            "hero": true,
            "dead": "5s1 7h2 9s3 Ah4",
            "rows": "Ac0 9c2 Jh4/3h0 Js0 4s1 Th3 3s4/8d0 Qd0 2d1 4d2 9d3",
            "win": -2.5,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "2h1 7c2 8c3 5c4",
            "rows": "4h2 6h2 8s3/Jc0 Kc0 Qs1 9h3 Tc4/3d0 Td0 Kd0 Ad1 7d4",
            "win": 2.42,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:04:22",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-24": [
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid708384",
            "orderIndex": 0,
            "hero": true,
            "dead": "4s1 3d2 2s3 7h4",
            "rows": "Kd0 Ah1 Th4/6c0 9d0 5c2 9c2 6s3/Js0 Qs0 Jd1 8h3 9h4",
            "win": -5,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid767560",
            "orderIndex": 1,
            "hero": false,
            "dead": "8d1 8s2 Jc3 9s4",
            "rows": "Ks0 5s3 Qc4/2c0 7d0 6d1 6h2 7s4/5h0 Jh0 3h1 Kh2 Qh3",
            "win": 4.85,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:05:34",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-25": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid708384",
            "orderIndex": 1,
            "hero": true,
            "dead": "3c1 Ks2 4h3 Qd4",
            "rows": "As1 Tc3 Kh4/6s0 7c0 8s1 7d3 Qs4/4d0 4c0 Qh0 9h2 9d2",
            "win": 2.91,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "7h1 3d2 7s3 3h4",
            "rows": "Ac2 Ah3 Th4/8h0 Td0 9c1 Jc1 5d4/3s0 4s0 5s0 Ts2 9s3",
            "win": -3,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:06:42",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-26": [
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid708384",
            "orderIndex": 0,
            "hero": true,
            "dead": "Js1 Ks2 8d3 2s4",
            "rows": "Ts1 9h3 Jc4/2d0 Ad1 As2 4s3 4c4/5c0 Tc0 Kc0 Ac0 7c2",
            "win": 2.42,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "pid767560",
            "orderIndex": 1,
            "hero": false,
            "dead": "Td1 6h2 6c3 2h4",
            "rows": "Ah0 Qd2 7h4/8c0 9c0 3d1 8h2 9s3/Kh0 Kd0 7s1 3h3 3s4",
            "win": -2.5,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:07:52",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-27": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "pid708384",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qd1 As2 Jh3 8s4",
            "rows": "Kc0 Kh3 Qh4/3d0 5c0 4d1 5d3 3s4/6h0 6c0 2c1 2s2 6s2",
            "win": 7.27,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "8c1 Tc2 8d3 2h4",
            "rows": "Ks0 Ah3 6d4/9d0 4h1 9c1 3c2 4c2/7d0 7c0 Qc0 9s3 9h4",
            "win": -7.5,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:09:02",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-28": [
        {
            "inFantasy": true,
            "result": -9,
            "playerName": "pid708384",
            "orderIndex": 0,
            "hero": true,
            "dead": "6h0 5c0",
            "rows": "Qc0 Kh0 Kd0/2h0 2d0 4h0 4c0 7d0/6c0 7s0 8s0 9h0 Td0",
            "win": -4.5,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "pid767560",
            "orderIndex": 1,
            "hero": false,
            "dead": "9d1 6s2 Tc3 5h4",
            "rows": "Ah0 Ac0 6d4/7h0 2c2 2s2 8h3 8c4/3s0 Js0 Ts1 As1 4s3",
            "win": 4.36,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:09:39",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-29": [
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "pid708384",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qs1 9c2 9h3 Jc4",
            "rows": "Ah0 Ad2 Jh3/2d0 6d0 6s1 4d2 Ac4/7c0 Kc0 Ks1 8c3 Js4",
            "win": -10.5,
            "playerId": "pid708384"
        },
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "7s0 3d1 2h2",
            "rows": "Td0 Tc0 Qh0/4c0 4s0 9d0 9s0 Jd0/5h0 5d0 5c0 5s0 8h0",
            "win": 10.18,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:10:25",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-30": [
        {
            "inFantasy": false,
            "result": -4,
            "playerName": "pid708384",
            "orderIndex": 0,
            "hero": true,
            "dead": "7d1 7s2 Qs3 Th4",
            "rows": "Qd1 Qh2 8h3/4s0 5d0 5s2 Ad3 5h4/9d0 9c0 9s0 3h1 Ks4",
            "win": -2,
            "playerId": "pid708384"
        },
        {
            "inFantasy": true,
            "result": 4,
            "playerName": "pid767560",
            "orderIndex": 1,
            "hero": false,
            "dead": "6d0 4h1 2d2",
            "rows": "Qc0 Kh0 Kc0/3d0 3c0 7c0 Jh0 Jd0/2s0 3s0 8s0 Ts0 As0",
            "win": 1.94,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:11:10",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-31": [
        {
            "inFantasy": true,
            "result": 7,
            "playerName": "pid708384",
            "orderIndex": 1,
            "hero": true,
            "dead": "3c0",
            "rows": "6c0 Jc0 Kd0/5d0 6s0 7c0 8d0 9d0/3h0 6h0 7h0 8h0 Ah0",
            "win": 3.39,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": -7,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "2h1 Kc2 4c3 5h4",
            "rows": "Ac2 2d3 2s4/4h0 4d0 Tc0 Ts1 Qs3/6d0 7s0 5s1 9h2 8s4",
            "win": -3.5,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:11:47",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-32": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid708384",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jc1 3c2 6c3 9h4",
            "rows": "Jd2 Ac3 9s4/4s0 8c1 8s1 4c2 Ks3/7d0 7c0 7s0 Tc0 9d4",
            "win": -6,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid767560",
            "orderIndex": 1,
            "hero": false,
            "dead": "5d1 Qh2 5h3 Qd4",
            "rows": "Td2 As3 Ad4/3h0 3s0 2s1 Kc3 2h4/9c0 Th0 Js0 Qs1 Kd2",
            "win": 5.82,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:12:55",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-33": [
        {
            "inFantasy": false,
            "result": -35,
            "playerName": "pid708384",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jc1 Jd2 8c3 6c4",
            "rows": "Qs2 Qc3 9s4/3c0 4s0 4c1 7c1 7h4/2h0 6h0 8h0 Ah2 Kh3",
            "win": -17.5,
            "playerId": "pid708384"
        },
        {
            "inFantasy": true,
            "result": 35,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jh0 7s1 2d2",
            "rows": "Kd0 Kc0 Ks0/2s0 3h0 4h0 5h0 As0/6d0 7d0 8d0 9d0 Td0",
            "win": 16.97,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:13:43",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-34": [
        {
            "inFantasy": true,
            "result": -3,
            "playerName": "pid708384",
            "orderIndex": 0,
            "hero": true,
            "dead": "2c0",
            "rows": "9h0 Kh0 Kc0/2h0 3s0 4d0 5h0 6d0/5d0 7d0 9d0 Qd0 Ad0",
            "win": -1.5,
            "playerId": "pid708384"
        },
        {
            "inFantasy": true,
            "result": 3,
            "playerName": "pid767560",
            "orderIndex": 1,
            "hero": false,
            "dead": "6h0 4s1 3d2",
            "rows": "Qc0 Kd0 Ah0/7c0 7s0 8d0 8c0 8s0/9c0 9s0 Th0 Td0 Ts0",
            "win": 1.45,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:14:32",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-35": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid708384",
            "orderIndex": 1,
            "hero": true,
            "dead": "2h1 9s2 5h3 8c4",
            "rows": "Ah1 As3 Kc4/5c0 6h0 Tc0 5s1 Ts4/Jd0 Qd0 3d2 Js2 Qc3",
            "win": 2.91,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "Kh1 3s2 9c3 4s4",
            "rows": "Ks2 4c3 6c3/7s0 8h0 Jh1 Jc1 Qh4/4d0 6d0 Kd0 9d2 2d4",
            "win": -3,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:15:44",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-36": [
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "pid708384",
            "orderIndex": 0,
            "hero": true,
            "dead": "8s0 6c0 4s0",
            "rows": "9s0 Jh0 Jc0/2h0 2c0 3h0 3d0 3c0/5h0 5d0 5s0 7d0 7c0",
            "win": 14.55,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": -30,
            "playerName": "pid767560",
            "orderIndex": 1,
            "hero": false,
            "dead": "6s1 6h2 2s3 7s4",
            "rows": "Qh0 Qd0 Kd1/Kh0 Kc0 Js2 Qc3 Ks3/9d0 7h1 Tc2 Td4 Qs4",
            "win": -15,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:16:22",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-37": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid708384",
            "orderIndex": 1,
            "hero": true,
            "dead": "4d1 4h2 7s3 4s4",
            "rows": "Kh0 Qs1 Jh4/3s0 As0 Ad2 6s3 5s4/8h0 8d0 Jd1 Js2 8c3",
            "win": 5.82,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "5c1 2s2 3c3 2d4",
            "rows": "Qd0 5d2 Td4/3d0 9s0 4c1 Ac1 Ks2/6h0 Th0 Qh3 Ah3 6c4",
            "win": -6,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:17:36",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-38": [
        {
            "inFantasy": false,
            "result": -7,
            "playerName": "pid708384",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qd1 2s2 8s3 5d4",
            "rows": "Ad1 Ts2 6s4/7c0 Jh1 4d2 Jc3 6d4/2d0 3h0 4c0 5h0 As3",
            "win": -3.5,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": 7,
            "playerName": "pid767560",
            "orderIndex": 1,
            "hero": false,
            "dead": "5s1 Qc2 8c3 3c4",
            "rows": "Kc0 Ks2 6c4/2h0 8d0 2c1 3d1 3s2/Th0 Tc0 6h3 Qs3 Td4",
            "win": 3.39,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:18:47",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-39": [
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid708384",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qc1 Qh2 6c3 2h4",
            "rows": "Ac0 7c3 Kd3/2c0 3s0 5c0 5h2 Qs4/6h0 7s1 Tc1 8d2 6s4",
            "win": -9,
            "playerId": "pid708384"
        },
        {
            "inFantasy": true,
            "result": 18,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "Th0 8h1",
            "rows": "9h0 9c0 Ks0/2s0 3c0 4d0 5s0 As0/2d0 3d0 7d0 9d0 Td0",
            "win": 8.73,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:19:34",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-40": [
        {
            "inFantasy": false,
            "result": 7,
            "playerName": "pid708384",
            "orderIndex": 0,
            "hero": true,
            "dead": "2s1 9c2 9h3 3d4",
            "rows": "Ah2 5h4 7h4/7d0 8h0 5d1 5c3 5s3/4c0 Tc0 Qc0 Jc1 Kc2",
            "win": 3.39,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": -7,
            "playerName": "pid767560",
            "orderIndex": 1,
            "hero": false,
            "dead": "As1 Qd2 9d3 4h4",
            "rows": "3h2 3c2 Qs4/2d0 Js0 2h1 Jh3 Ts4/8c0 Kh0 Ks0 Kd1 6d3",
            "win": -3.5,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:20:44",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-41": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "pid708384",
            "orderIndex": 1,
            "hero": true,
            "dead": "9c1 9h2 8h3 8s4",
            "rows": "Qc0 8c2 Th3/2d0 6d0 3c2 3s3 Jd4/7c0 7s0 7d1 Jc1 Jh4",
            "win": -1.5,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "2s1 5h2 Qd3 2h4",
            "rows": "Kd0 Ks0 Ts4/Ac0 As0 Qh2 Kh2 4h4/6s0 9d1 Tc1 6h3 9s3",
            "win": 1.45,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:21:57",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-42": [
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid708384",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qh1 Ad2 Qs3 2h4",
            "rows": "Ks0 3h3 4c3/6d0 2d1 7c1 2c2 Th4/5h0 5s0 Jc0 Js2 9c4",
            "win": -10,
            "playerId": "pid708384"
        },
        {
            "inFantasy": true,
            "result": 20,
            "playerName": "pid767560",
            "orderIndex": 1,
            "hero": false,
            "dead": "9h0 6c1",
            "rows": "Kh0 Kd0 Ac0/2s0 3d0 4d0 5c0 6h0/8c0 9d0 Tc0 Jh0 Qd0",
            "win": 9.7,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:22:46",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-43": [
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid708384",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qd1 2c2 Qs3 4s4",
            "rows": "Ac0 As1 7d3/2s0 3d0 6h0 2d1 2h3/8d0 8h2 Jc2 6c4 Tc4",
            "win": -5,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "9d1 8c2 Th3 3h4",
            "rows": "Kd0 Jd3 Ad4/4d0 9h0 6d2 9c2 4c3/6s0 7s0 3s1 8s1 Js4",
            "win": 4.85,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:23:55",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-44": [
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid708384",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ah1 4h2 5d3 5s4",
            "rows": "Kc0 2s2 2h3/3c0 6s0 5h1 5c1 Ac4/8s0 Th0 Qs2 9h3 7d4",
            "win": -5,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid767560",
            "orderIndex": 1,
            "hero": false,
            "dead": "Js1 9s2 2d3 2c4",
            "rows": "Ks2 4c3 Tc4/3h0 Jh0 Qd2 As3 Qh4/4d0 Td0 Ad0 6d1 8d1",
            "win": 4.85,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:25:07",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-45": [
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid708384",
            "orderIndex": 1,
            "hero": true,
            "dead": "Kc1 Qd2 Js3 Td4",
            "rows": "As0 Jc4 Kd4/4s0 6s0 3d1 6d1 3s3/7h0 Th0 4h2 5h2 Jh3",
            "win": -5,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "3c1 7s2 Qh3 2d4",
            "rows": "Kh0 Ah3 Qc4/8c0 2s1 8d1 8s3 3h4/5c0 5s0 9h0 5d2 9d2",
            "win": 4.85,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:26:12",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-46": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid708384",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qh1 6s2 3s3 2d4",
            "rows": "Kh0 Ks1 8s3/3d0 Ah0 5c3 6c4 9c4/7c0 9s0 Js1 7d2 Jc2",
            "win": 0,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid767560",
            "orderIndex": 1,
            "hero": false,
            "dead": "Tc1 6d2 Qc3 2c4",
            "rows": "Kc0 Kd1 Jh3/2h0 8d0 2s1 8c2 6h3/5s0 As0 4c2 5h4 9d4",
            "win": 0,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:27:23",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-47": [
        {
            "inFantasy": false,
            "result": -1,
            "playerName": "pid708384",
            "orderIndex": 1,
            "hero": true,
            "dead": "7c1 7h2 8d3 As4",
            "rows": "Kc0 Ac1 Td3/3c0 5s0 5c1 4d2 4c2/2h0 9h0 5h3 3h4 Kh4",
            "win": -0.5,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "9d1 9c2 Ah3 2s4",
            "rows": "Ks1 Jh3 4h4/3s0 5d0 6d2 7s2 Ad3/Th0 Tc0 Qd0 Qc1 Qs4",
            "win": 0.5,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:28:31",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-48": [
        {
            "inFantasy": false,
            "result": -4,
            "playerName": "pid708384",
            "orderIndex": 0,
            "hero": true,
            "dead": "3d1 8c2 6c3 5d4",
            "rows": "Kc1 Ad3 As4/4d0 5h0 7d1 7s2 5c4/Th0 Jh0 Jd0 2c2 2h3",
            "win": -2,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": 4,
            "playerName": "pid767560",
            "orderIndex": 1,
            "hero": false,
            "dead": "9d1 6h2 6d3 Js4",
            "rows": "2d0 Kh4 Kd4/8h0 Td0 8s1 3h2 Ts2/3c0 4c0 9c1 7c3 Ac3",
            "win": 1.94,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:29:43",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-49": [
        {
            "inFantasy": true,
            "result": 13,
            "playerName": "pid708384",
            "orderIndex": 1,
            "hero": true,
            "dead": "Js0 Td0 9s0",
            "rows": "Ah0 Ac0 As0/2c0 4c0 5c0 8c0 Jc0/3h0 5h0 9h0 Th0 Jh0",
            "win": 6.3,
            "playerId": "pid708384"
        },
        {
            "inFantasy": true,
            "result": -13,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "Tc0 7c1",
            "rows": "Ts0 Kc0 Ks0/2h0 7h0 8h0 Qh0 Kh0/4d0 5d0 Jd0 Qd0 Ad0",
            "win": -6.5,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:30:27",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-50": [
        {
            "inFantasy": true,
            "result": 22,
            "playerName": "pid708384",
            "orderIndex": 0,
            "hero": true,
            "dead": "9c0 3d0 2s0",
            "rows": "Qc0 Kd0 Kc0/5c0 6h0 7d0 8s0 9d0/3h0 8h0 Th0 Jh0 Qh0",
            "win": 10.67,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": -22,
            "playerName": "pid767560",
            "orderIndex": 1,
            "hero": false,
            "dead": "3s1 4c2 2c3 2d4",
            "rows": "Kh0 Ks2 Ts3/7c0 9s0 7s1 4s2 3c4/Jd0 Jc0 8d1 8c3 2h4",
            "win": -11,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:31:04",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-51": [
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid708384",
            "orderIndex": 1,
            "hero": true,
            "dead": "5h1 Td2 6s3 3c4",
            "rows": "Ah0 8d2 4d4/7c0 9s0 4s1 Kc3 Ks3/2d0 2s0 Jh1 Jc2 2c4",
            "win": 4.85,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "3s1 4c2 8h3 4h4",
            "rows": "5c1 As2 3h3/6c0 7s0 9h0 6h1 2h3/Jd0 Kd0 9d2 Th4 Qd4",
            "win": -5,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:32:21",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-52": [
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid708384",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jc1 8c2 5c3 6h4",
            "rows": "Qs0 Ad3 Ts4/3s0 Kd1 4d2 Ks3 9c4/7h0 7s0 9d0 7c1 9h2",
            "win": -4,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": 8,
            "playerName": "pid767560",
            "orderIndex": 1,
            "hero": false,
            "dead": "3d1 Qh2 8d3 4h4",
            "rows": "Ac0 As3 Td4/2h0 2c0 8h0 2s2 6c4/5s0 6s1 8s1 4s2 7d3",
            "win": 3.88,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:33:32",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-53": [
        {
            "inFantasy": false,
            "result": -31,
            "playerName": "pid708384",
            "orderIndex": 1,
            "hero": true,
            "dead": "8c1 4h2 Jc3 3s4",
            "rows": "Ac1 As2 9h4/2h0 6d0 7h0 7d1 5d4/Ts0 Qs0 Kd2 Qh3 Ks3",
            "win": -15.5,
            "playerId": "pid708384"
        },
        {
            "inFantasy": true,
            "result": 31,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "Kh0 8h1 3h2",
            "rows": "5h0 5c0 5s0/3c0 6c0 7c0 9c0 Qc0/2d0 9d0 Td0 Jd0 Qd0",
            "win": 15.03,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:34:18",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-54": [
        {
            "inFantasy": false,
            "result": -25,
            "playerName": "pid708384",
            "orderIndex": 0,
            "hero": true,
            "dead": "3c1 2c2 Td3 2s4",
            "rows": "Kh2 Ac3 Kc4/5d0 5c0 6c0 5h1 Th2/7h0 7d0 4c1 3d3 8s4",
            "win": -12.5,
            "playerId": "pid708384"
        },
        {
            "inFantasy": true,
            "result": 25,
            "playerName": "pid767560",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jc0 8h1 2d2",
            "rows": "Jh0 Qh0 Qd0/3s0 5s0 6s0 7s0 As0/4d0 8d0 9d0 Kd0 Ad0",
            "win": 12.12,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:35:04",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-55": [
        {
            "inFantasy": false,
            "result": 14,
            "playerName": "pid708384",
            "orderIndex": 1,
            "hero": true,
            "dead": "As1 Jh2 2d3 Qs4",
            "rows": "Ks0 Kd2 Ad3/4c0 8s0 8h1 5h2 5d4/3h0 3d0 Ts1 Th3 Kc4",
            "win": 6.79,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "2h1 7c2 9h3 4h4",
            "rows": "Qd1 Qc2 9c3/8d0 Jc0 6c1 2c3 Ac4/2s0 3s0 6s0 7s2 9s4",
            "win": -7,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:36:12",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-56": [
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "pid708384",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jd0 8s0",
            "rows": "Qd0 Qc0 Kc0/2c0 3h0 4d0 5h0 Ad0/6h0 6c0 6s0 9h0 9d0",
            "win": 10.18,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "pid767560",
            "orderIndex": 1,
            "hero": false,
            "dead": "Kd1 Tc2 As3 2h4",
            "rows": "7s2 8c2 Th4/3d0 4h0 4s0 4c3 9c4/5c0 Jc0 Jh1 Js1 Kh3",
            "win": -10.5,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:36:50",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-57": [
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "pid708384",
            "orderIndex": 1,
            "hero": true,
            "dead": "Th1 5d2 6c3 2c4",
            "rows": "Ks0 Ad2 Qd4/3s0 Ac0 3h1 4c1 4h3/7h0 Jc0 7d2 Js3 7c4",
            "win": -2.5,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "9c1 Ah2 Kc3 Td4",
            "rows": "2h1 6h2 Qc4/5s0 Ts0 2s3 7s3 8s4/3d0 8d0 9d0 Kd1 Jd2",
            "win": 2.42,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:37:55",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-58": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid708384",
            "orderIndex": 0,
            "hero": true,
            "dead": "9h1 6c2 6h3 7h4",
            "rows": "Qh1 Ah3 Jh4/3h0 5h0 3d1 3c2 4s2/7s0 Kd0 Kc0 4d3 7c4",
            "win": 0,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid767560",
            "orderIndex": 1,
            "hero": false,
            "dead": "8d1 5d2 3s3 8s4",
            "rows": "As0 Ks2 Ts3/2d0 5c0 6d0 2s1 5s1/9s0 8h2 4c3 Th4 Tc4",
            "win": 0,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:39:11",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-59": [
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid708384",
            "orderIndex": 1,
            "hero": true,
            "dead": "Td1 3s2 Kd3 5s4",
            "rows": "Kc1 Qd2 5h3/2s0 7d0 8s1 9d3 9h4/6h0 6d0 Jd0 6c2 Ad4",
            "win": 0.5,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": -1,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "2h1 9c2 6s3 9s4",
            "rows": "Kh1 Qs2 Jh4/3h0 5d0 7s0 2c2 7h3/4d0 4c0 Tc1 Js3 4s4",
            "win": -0.5,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:40:21",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-60": [
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid708384",
            "orderIndex": 0,
            "hero": true,
            "dead": "2c1 2d2 3s3 3c4",
            "rows": "Kc0 Qh2 Ks3/3d0 4s0 4d1 4c3 Qd4/9d0 Th0 8d1 7s2 9c4",
            "win": -8,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": 16,
            "playerName": "pid767560",
            "orderIndex": 1,
            "hero": false,
            "dead": "5d1 Jd2 6s3 2s4",
            "rows": "Tc3 6h4 Ad4/6d0 7c0 8h2 Td2 9s3/Ah0 Ac0 As0 8c1 8s1",
            "win": 7.76,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:41:29",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-61": [
        {
            "inFantasy": false,
            "result": 16,
            "playerName": "pid708384",
            "orderIndex": 1,
            "hero": true,
            "dead": "Ts1 9c2 3c3 4h4",
            "rows": "6c3 7d4 Jd4/4d0 8c0 3h1 3d1 4c2/2c0 Qh0 Qc0 Qs2 Qd3",
            "win": 7.76,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "7h1 As2 4s3 2s4",
            "rows": "Kc0 Ks0 Ac4/5d1 6d1 Kd2 5c3 5s3/7c0 Tc0 Jc0 Th2 8h4",
            "win": -8,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:42:41",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-62": [
        {
            "inFantasy": false,
            "result": -1,
            "playerName": "pid708384",
            "orderIndex": 0,
            "hero": true,
            "dead": "5h1 Jd2 7d3 6d4",
            "rows": "Ac2 Jc3 7h4/2h0 4c0 6h2 3h3 6c4/2s0 3s0 6s0 8s1 Js1",
            "win": -0.5,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid767560",
            "orderIndex": 1,
            "hero": false,
            "dead": "4h1 3c2 Qc3 4s4",
            "rows": "Ah2 3d3 9c4/5s0 5d1 Tc1 Ts2 7s4/2d0 9d0 Qd0 Ad0 Kd3",
            "win": 0.5,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:43:51",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-63": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid708384",
            "orderIndex": 1,
            "hero": true,
            "dead": "9d1 5h2 8c3 6d4",
            "rows": "Kd2 9c4 Ad4/2d0 6h0 5c1 3s2 4d3/9h0 Th0 Js0 7s1 8s3",
            "win": 5.82,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "5d1 3h2 Ac3 8d4",
            "rows": "6c1 3c2 Ah4/2h0 7c0 2c1 4s3 Qh4/Jd0 Jc0 Qc0 Jh2 Td3",
            "win": -6,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:44:58",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-64": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid708384",
            "orderIndex": 0,
            "hero": true,
            "dead": "7d1 Td2 Kd3 3d4",
            "rows": "Qd2 Ad3 Kh4/6c0 9c0 Tc1 8h3 3c4/4s0 Ts0 Ks0 Qs1 3s2",
            "win": 0,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid767560",
            "orderIndex": 1,
            "hero": false,
            "dead": "4h1 2h2 6h3 4d4",
            "rows": "Ac1 9d2 6d3/5s0 Js1 5c2 4c3 7h4/9h0 Th0 Jc0 Kc0 6s4",
            "win": 0,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:46:04",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-65": [
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid708384",
            "orderIndex": 1,
            "hero": true,
            "dead": "5s1 3d2 4h3 4s4",
            "rows": "Ks0 Kc1 9h3/3s0 As0 Ah1 4c2 Qs4/Th0 Ts0 7h2 7s3 Jd4",
            "win": 2.42,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "2c1 Kd2 6s3 5c4",
            "rows": "Tc3 Ad3 6h4/3h0 Jc0 8h2 8d2 6c4/2d0 4d0 5d0 7d1 Td1",
            "win": -2.5,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:47:12",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-66": [
        {
            "inFantasy": true,
            "result": 20,
            "playerName": "pid708384",
            "orderIndex": 0,
            "hero": true,
            "dead": "7s0 6c0",
            "rows": "4d0 4c0 9c0/9s0 Tc0 Js0 Qh0 Kd0/8s0 Ah0 Ad0 Ac0 As0",
            "win": 9.7,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid767560",
            "orderIndex": 1,
            "hero": false,
            "dead": "7d1 8h2 Qc3 2s4",
            "rows": "Ks0 8d3 9h3/Jc0 3h1 4h2 Jh2 4s4/5s0 6d0 7h0 6s1 3c4",
            "win": -10,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:47:48",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-67": [
        {
            "inFantasy": true,
            "result": 23,
            "playerName": "pid708384",
            "orderIndex": 1,
            "hero": true,
            "dead": "6s0 3d0",
            "rows": "Js0 Ah0 As0/2h0 7h0 Th0 Jh0 Qh0/3c0 4c0 5c0 6c0 7c0",
            "win": 11.15,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": -23,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "Td1 9h2 Ts3 2c4",
            "rows": "Ad2 Ac2 6h3/Jc0 8h1 8s1 5d3 5s4/9d0 9c0 Qc0 Qs0 Qd4",
            "win": -11.5,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:48:23",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-68": [
        {
            "inFantasy": true,
            "result": 20,
            "playerName": "pid708384",
            "orderIndex": 0,
            "hero": true,
            "dead": "As0 8c0",
            "rows": "Kh0 Kd0 Kc0/2d0 3h0 4s0 5c0 6d0/7c0 8d0 9d0 Td0 Js0",
            "win": 9.7,
            "playerId": "pid708384"
        },
        {
            "inFantasy": true,
            "result": -20,
            "playerName": "pid767560",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jc0 Jd1 Th2",
            "rows": "Qc0 Qs0 Ks0/2c0 3d0 4h0 5h0 Ac0/4d0 5d0 6c0 7s0 8s0",
            "win": -10,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:49:07",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-69": [
        {
            "inFantasy": true,
            "result": 16,
            "playerName": "pid708384",
            "orderIndex": 1,
            "hero": true,
            "dead": "7s0 5h0",
            "rows": "Jh0 Kc0 Ks0/3h0 3s0 9s0 Td0 Tc0/2d0 2c0 4h0 4c0 4s0",
            "win": 7.76,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "7h1 7d2 Qs3 6d4",
            "rows": "Qd0 Th4 Ad4/4d0 9h0 2s2 5c3 5s3/3c0 8c0 7c1 Ac1 9c2",
            "win": -8,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:49:44",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-70": [
        {
            "inFantasy": false,
            "result": 4,
            "playerName": "pid708384",
            "orderIndex": 0,
            "hero": true,
            "dead": "4h1 2c2 4d3 Qc4",
            "rows": "Ac0 Ah1 Kh4/3h0 5d0 6c0 6h2 5s4/Js0 Th1 9c2 9s3 Tc3",
            "win": 1.94,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": -4,
            "playerName": "pid767560",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qs1 2h2 2d3 6d4",
            "rows": "Kc1 Qh3 9d4/8c0 7d2 Ad2 8h3 8d4/3s0 4c0 5h0 6s0 7c1",
            "win": -2,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:50:51",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-71": [
        {
            "inFantasy": true,
            "result": 16,
            "playerName": "pid708384",
            "orderIndex": 1,
            "hero": true,
            "dead": "7s0 4h0 2h0",
            "rows": "Qc0 Kh0 Ac0/2d0 4d0 7d0 9d0 Td0/3c0 3s0 8h0 8d0 8s0",
            "win": 7.76,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "9c1 7c2 Qs3 7h4",
            "rows": "Ah0 9h3 Jd4/3d0 3h1 6h1 4c2 Th4/4s0 5s0 Js0 Ts2 9s3",
            "win": -8,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:51:27",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-72": [
        {
            "inFantasy": false,
            "result": 7,
            "playerName": "pid708384",
            "orderIndex": 0,
            "hero": true,
            "dead": "6d1 6s2 Ad3 3s4",
            "rows": "Kh0 Qh2 Kd4/5d0 Ac1 As1 6h3 9h3/7h0 7d0 Th0 Ts2 Qd4",
            "win": 3.39,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": -7,
            "playerName": "pid767560",
            "orderIndex": 1,
            "hero": false,
            "dead": "Kc1 Ks2 9c3 Td4",
            "rows": "9s2 Jc2 Tc4/3c0 2d1 4d1 5c3 2c4/4c0 5h0 7s0 8s0 6c3",
            "win": -3.5,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:52:31",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-73": [
        {
            "inFantasy": true,
            "result": 13,
            "playerName": "pid708384",
            "orderIndex": 1,
            "hero": true,
            "dead": "3h0 3c0",
            "rows": "5s0 6c0 6s0/8d0 9d0 Th0 Jc0 Qh0/8h0 9c0 Td0 Js0 Qs0",
            "win": 6.3,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": -13,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "5h1 Kd2 4d3 6h4",
            "rows": "5d2 Qd2 Ad3/2h0 2d0 4c0 3d1 Ks4/9s0 Ts0 7h1 Tc3 Kh4",
            "win": -6.5,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:53:08",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-74": [
        {
            "inFantasy": false,
            "result": -13,
            "playerName": "pid708384",
            "orderIndex": 0,
            "hero": true,
            "dead": "5d1 7h2 4d3 3d4",
            "rows": "As0 8s3 8c4/6h0 9d0 Td1 9c2 3s4/Jc0 Qc0 3c1 Ac2 6c3",
            "win": -6.5,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": 13,
            "playerName": "pid767560",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qd1 8h2 4s3 9s4",
            "rows": "Ks0 Kd3 Ah4/Qs0 Qh1 2h2 Jd3 2c4/6d0 6s0 7c0 7s1 7d2",
            "win": 6.3,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:54:18",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-75": [
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid708384",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jh1 Kc2 7s3 2h4",
            "rows": "Ah0 Jc4 Ad4/2c0 7d0 4c1 2s2 7h2/9d0 Qs0 9h1 5h3 5c3",
            "win": -10,
            "playerId": "pid708384"
        },
        {
            "inFantasy": true,
            "result": 20,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "Tc0 2d1",
            "rows": "Kd0 Ac0 As0/5s0 8s0 9s0 Ts0 Ks0/3h0 3d0 Qh0 Qd0 Qc0",
            "win": 9.7,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:55:00",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-76": [
        {
            "inFantasy": true,
            "result": 26,
            "playerName": "pid708384",
            "orderIndex": 0,
            "hero": true,
            "dead": "9h0 7s0 4h0",
            "rows": "Js0 Kd0 Kc0/2c0 4c0 5c0 6c0 Qc0/3d0 8d0 9d0 Jd0 Qd0",
            "win": 12.61,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": -26,
            "playerName": "pid767560",
            "orderIndex": 1,
            "hero": false,
            "dead": "3h1 Qh2 5h3 5s4",
            "rows": "Ad0 3s3 5d3/2h0 2d0 7d0 6h2 As4/Ts0 8h1 8s1 Jc2 9c4",
            "win": -13,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:55:39",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-77": [
        {
            "inFantasy": false,
            "result": 20,
            "playerName": "pid708384",
            "orderIndex": 1,
            "hero": true,
            "dead": "Kd1 Tc2 Ad3 5s4",
            "rows": "Kc0 Ks2 7s4/4s0 Th1 Td1 8d2 4d4/9h0 9s0 Jd0 9c3 Jc3",
            "win": 9.7,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "3d1 4c2 Ts3 8s4",
            "rows": "As2 9d3 Jh4/2s0 5c0 6h1 6s1 Ac4/8h0 Qh0 Qs0 Js2 Qd3",
            "win": -10,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:56:49",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-78": [
        {
            "inFantasy": true,
            "result": 15,
            "playerName": "pid708384",
            "orderIndex": 0,
            "hero": true,
            "dead": "5s0 4s0",
            "rows": "7s0 9c0 Ah0/8d0 9d0 Jd0 Qd0 Ad0/2c0 2s0 Kh0 Kd0 Kc0",
            "win": 7.27,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid767560",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qs1 Qh2 6h3 5d4",
            "rows": "As1 Td3 Jc4/3s0 6s0 6d1 2d2 9h4/7h0 8h0 8c0 4h2 4d3",
            "win": -7.5,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:57:25",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-79": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid708384",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jd1 Kd2 7h3 2s4",
            "rows": "As2 3h3 Ad4/5s0 9s0 2h1 5c1 2c2/8d0 8c0 Qd0 Qc3 6c4",
            "win": 1.45,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "2d1 Js2 Jh3 5h4",
            "rows": "Kh0 6h4 6s4/5d0 8s0 Qh1 7c3 7s3/9h0 9d0 Tc1 9c2 Td2",
            "win": -1.5,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:58:36",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-80": [
        {
            "inFantasy": true,
            "result": 40,
            "playerName": "pid708384",
            "orderIndex": 0,
            "hero": true,
            "dead": "7h0 5h0 5c0",
            "rows": "Ah0 Ad0 As0/2s0 7s0 8s0 Ts0 Qs0/2d0 3d0 Td0 Jd0 Kd0",
            "win": 19.4,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": -40,
            "playerName": "pid767560",
            "orderIndex": 1,
            "hero": false,
            "dead": "5s1 4s2 3s3 6c4",
            "rows": "Kh0 Qc3 Th4/4h0 9d0 Ac1 9s3 4c4/Jh0 Jc0 8h1 2h2 2c2",
            "win": -20,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 12:59:14",
    "roomId": "21179429"
}


{
    "stakes": 0.5,
    "handData": {"21179429-81": [
        {
            "inFantasy": true,
            "result": 33,
            "playerName": "pid708384",
            "orderIndex": 1,
            "hero": true,
            "dead": "4h0 3h0 2c0",
            "rows": "9d0 Ah0 Ac0/5h0 5d0 5c0 Jh0 Js0/Qd0 Qs0 Kh0 Kd0 Kc0",
            "win": 16,
            "playerId": "pid708384"
        },
        {
            "inFantasy": false,
            "result": -33,
            "playerName": "pid767560",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qc1 2d2 3c3 2h4",
            "rows": "Ad2 7c3 As3/4c0 8d0 8s1 6d4 Tc4/7h0 8h0 9h0 6s1 Th2",
            "win": -16.5,
            "playerId": "pid767560"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 13:00:04",
    "roomId": "21179429"
}


