{
    "stakes": 0.5,
    "handData": {"21183760-1": [
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid899265",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ts1 3s2 9d3 7h4",
            "rows": "Jh2 8h4 As4/4s0 7d0 8s1 9c3 9s3/6c0 Tc0 Kc0 3c1 5c2",
            "win": 4.75,
            "playerId": "pid899265"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid131192",
            "orderIndex": 1,
            "hero": false,
            "dead": "2s1 2c2 Jc3 5d4",
            "rows": "Ks1 Ac2 Kh4/4h0 9h0 Th2 3h3 Qh4/2d0 3d0 Jd0 4d1 8d3",
            "win": -5,
            "playerId": "pid131192"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 16:21:53",
    "roomId": "21183760"
}


{
    "stakes": 0.5,
    "handData": {"21183760-2": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid899265",
            "orderIndex": 1,
            "hero": true,
            "dead": "9h1 3c2 4s3 7s4",
            "rows": "As0 Kc3 Ks3/7h0 8s0 8c1 6h2 Ts4/Td0 Qd0 2d1 7d2 Tc4",
            "win": 0,
            "playerId": "pid899265"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid131192",
            "orderIndex": 0,
            "hero": false,
            "dead": "9c1 8d2 8h3 6s4",
            "rows": "Qs0 Qh2 Th3/4h0 Ac2 5h3 Jh4 Kd4/9d0 9s0 Jd0 Jc1 Js1",
            "win": 0,
            "playerId": "pid131192"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 16:23:12",
    "roomId": "21183760"
}


{
    "stakes": 0.5,
    "handData": {"21183760-3": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid899265",
            "orderIndex": 0,
            "hero": true,
            "dead": "7s1 Qd2 7d3 8d4",
            "rows": "Ah0 9h3 As3/5h0 6d0 6h1 5s4 Js4/9d0 Tc0 9c1 Qh2 Qs2",
            "win": 0,
            "playerId": "pid899265"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid131192",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jh1 4s2 6c3 6s4",
            "rows": "Kh0 Kc0 8s4/2h0 4h1 7h2 7c2 2c3/3h0 3d0 Qc1 Td3 3c4",
            "win": 0,
            "playerId": "pid131192"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 16:24:08",
    "roomId": "21183760"
}


{
    "stakes": 0.5,
    "handData": {"21183760-4": [
        {
            "inFantasy": true,
            "result": -9,
            "playerName": "pid899265",
            "orderIndex": 1,
            "hero": true,
            "dead": "7c0 3h0 2d0",
            "rows": "Qh0 Kc0 Ks0/6d0 7h0 8d0 9d0 Th0/5s0 8s0 9s0 Js0 As0",
            "win": -4.5,
            "playerId": "pid899265"
        },
        {
            "inFantasy": true,
            "result": 9,
            "playerName": "pid131192",
            "orderIndex": 0,
            "hero": false,
            "dead": "8c0 6c1",
            "rows": "Jh0 Jd0 Kd0/2h0 2c0 2s0 5h0 5d0/4d0 4c0 4s0 Tc0 Ts0",
            "win": 4.27,
            "playerId": "pid131192"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 16:24:52",
    "roomId": "21183760"
}


