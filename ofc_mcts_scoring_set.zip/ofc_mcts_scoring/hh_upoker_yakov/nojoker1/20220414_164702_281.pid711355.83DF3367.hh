{
    "stakes": 1,
    "handData": {"21180835-1": [
        {
            "inFantasy": false,
            "result": -11,
            "playerName": "pid575312",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qh1 8c2 4h3 5h4",
            "rows": "As1 Qc2 Kd4/4d0 6d0 4c1 2h2 5s4/7h0 9d0 9s0 5c3 7c3",
            "win": -11,
            "playerId": "pid575312"
        },
        {
            "inFantasy": false,
            "result": 11,
            "playerName": "pid711355",
            "orderIndex": 1,
            "hero": true,
            "dead": "2d1 2s2 9h3 8s4",
            "rows": "5d3 Td4 Ah4/9c0 8d1 Th1 Qs2 Jh3/3d0 3c0 3s0 6s0 6c2",
            "win": 10.67,
            "playerId": "pid711355"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 13:47:02",
    "roomId": "21180835"
}


{
    "stakes": 1,
    "handData": {"21180835-2": [
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid575312",
            "orderIndex": 1,
            "hero": false,
            "dead": "Js1 As2 6d3 4c4",
            "rows": "Kc0 9d3 Jd4/4d0 7h1 8c1 7d2 8h3/3h0 3s0 Qd0 3c2 8s4",
            "win": -17,
            "playerId": "pid575312"
        },
        {
            "inFantasy": false,
            "result": 17,
            "playerName": "pid711355",
            "orderIndex": 0,
            "hero": true,
            "dead": "9s1 7c2 Qc3 2s4",
            "rows": "Jc1 Ah2 Ac4/2c0 6s0 2d1 2h2 Jh3/5h0 5c0 Th0 5d3 Qh4",
            "win": 16.49,
            "playerId": "pid711355"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 13:48:16",
    "roomId": "21180835"
}


{
    "stakes": 1,
    "handData": {"21180835-3": [
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid575312",
            "orderIndex": 0,
            "hero": false,
            "dead": "7s1 Qh2 Td3 2s4",
            "rows": "As0 Tc3 Ac3/4h0 8d0 4s1 4d2 5c4/Jh0 Qc0 Jc1 Js2 Ad4",
            "win": -10,
            "playerId": "pid575312"
        },
        {
            "inFantasy": true,
            "result": 10,
            "playerName": "pid711355",
            "orderIndex": 1,
            "hero": true,
            "dead": "Ts0 8c0 3s0",
            "rows": "7h0 7c0 Kc0/2h0 2c0 6h0 6d0 6c0/5h0 5s0 9h0 9d0 9c0",
            "win": 9.7,
            "playerId": "pid711355"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 13:49:06",
    "roomId": "21180835"
}


{
    "stakes": 1,
    "handData": {"21180835-4": [
        {
            "inFantasy": true,
            "result": 25,
            "playerName": "pid575312",
            "orderIndex": 1,
            "hero": false,
            "dead": "5c0 5d1 2h2",
            "rows": "7h0 Ah0 As0/6d0 7s0 8s0 9s0 Tc0/4h0 4s0 Jd0 Jc0 Js0",
            "win": 24.25,
            "playerId": "pid575312"
        },
        {
            "inFantasy": false,
            "result": -25,
            "playerName": "pid711355",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qd1 2c2 Qh3 3c4",
            "rows": "Ad0 2s2 Ks4/7d0 3h1 5s1 3d2 5h3/8h0 8c0 Ts0 Th3 7c4",
            "win": -25,
            "playerId": "pid711355"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 13:49:50",
    "roomId": "21180835"
}


{
    "stakes": 1,
    "handData": {"21180835-5": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid575312",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qc1 9h2 5h3 8c4",
            "rows": "Kd0 7c3 9s3/4s0 5d0 2c1 Ah2 Qh4/6s0 Tc0 Th1 6c2 9d4",
            "win": -6,
            "playerId": "pid575312"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid711355",
            "orderIndex": 1,
            "hero": true,
            "dead": "9c1 4d2 5s3 Ts4",
            "rows": "Kc0 Ac1 Qd4/3h0 8d0 8h1 2d2 Kh4/Jh0 Jc0 Qs2 6h3 6d3",
            "win": 5.82,
            "playerId": "pid711355"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 13:51:13",
    "roomId": "21180835"
}


{
    "stakes": 1,
    "handData": {"21180835-6": [
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "pid575312",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jc1 7d2 2d3 Jh4",
            "rows": "Kh1 Ac1 Js3/5c0 6c0 7h2 3c3 3d4/Ts0 Qd0 Qs0 Tc2 Ks4",
            "win": -5,
            "playerId": "pid575312"
        },
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid711355",
            "orderIndex": 0,
            "hero": true,
            "dead": "6d1 2c2 9s3 4c4",
            "rows": "Kd1 4d3 8d3/7s0 Jd0 Qc0 7c2 8s4/3h0 4h0 8h1 6h2 5h4",
            "win": 4.85,
            "playerId": "pid711355"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 13:51:58",
    "roomId": "21180835"
}


{
    "stakes": 1,
    "handData": {"21180835-7": [
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid575312",
            "orderIndex": 0,
            "hero": false,
            "dead": "2h1 5s2 4c3 2s4",
            "rows": "Ac0 As0 9s4/8h0 7d1 7s1 3s2 Qh4/Tc0 Ts0 9h2 Kd3 Ks3",
            "win": -8,
            "playerId": "pid575312"
        },
        {
            "inFantasy": false,
            "result": 8,
            "playerName": "pid711355",
            "orderIndex": 1,
            "hero": true,
            "dead": "6c1 9c2 3c3 Ah4",
            "rows": "Qs0 4d2 6s3/3d0 8s0 Kc1 2c2 2d4/5h0 7h0 6h1 8d3 4s4",
            "win": 7.76,
            "playerId": "pid711355"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 13:54:35",
    "roomId": "21180835"
}


