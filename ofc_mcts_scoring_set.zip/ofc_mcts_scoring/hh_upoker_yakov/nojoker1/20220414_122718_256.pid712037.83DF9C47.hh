{
    "stakes": 0.5,
    "handData": {"21178050-1": [
        {
            "inFantasy": false,
            "result": -7,
            "playerName": "pid910944",
            "orderIndex": 0,
            "hero": false,
            "dead": "3s1 2c2 5d3 6h4",
            "rows": "Kc0 Jc4 Qs4/Ah0 Tc1 3h2 Jd3 Ad3/8s0 9d0 Th0 7d1 Js2",
            "win": -3.5,
            "playerId": "pid910944"
        },
        {
            "inFantasy": false,
            "result": 7,
            "playerName": "pid712037",
            "orderIndex": 1,
            "hero": true,
            "dead": "7s1 Ac2 3c3 3d4",
            "rows": "Kh0 Ks1 As4/4s0 9h0 4c2 5c2 5h3/6c0 6s0 Jh1 2d3 2h4",
            "win": 3.39,
            "playerId": "pid712037"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 09:27:18",
    "roomId": "21178050"
}


{
    "stakes": 0.5,
    "handData": {"21178050-2": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid910944",
            "orderIndex": 1,
            "hero": false,
            "dead": "6d1 5s2 2d3 6h4",
            "rows": "Qs0 Qh2 Js4/3c0 Kd0 Ks1 6c3 6s3/5d0 9h0 9s1 9c2 9d4",
            "win": 0,
            "playerId": "pid910944"
        },
        {
            "inFantasy": true,
            "result": 0,
            "playerName": "pid712037",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ts0 8s0",
            "rows": "Jd0 Kc0 Ac0/3h0 3d0 4h0 4d0 4c0/2h0 2s0 7h0 7d0 7s0",
            "win": 0,
            "playerId": "pid712037"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 09:28:02",
    "roomId": "21178050"
}


{
    "stakes": 0.5,
    "handData": {"21178050-3": [
        {
            "inFantasy": true,
            "result": -5,
            "playerName": "pid910944",
            "orderIndex": 0,
            "hero": false,
            "dead": "5s0",
            "rows": "Tc0 Jd0 Ah0/4h0 4d0 6h0 8h0 8c0/2h0 2s0 3h0 3d0 3c0",
            "win": -2.5,
            "playerId": "pid910944"
        },
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid712037",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qh1 Qs2 2c3 Td4",
            "rows": "Ac0 8d3 Js4/5h0 4c1 6s1 3s2 7s2/9h0 9d0 Kc0 Kd3 Kh4",
            "win": 2.42,
            "playerId": "pid712037"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 09:28:46",
    "roomId": "21178050"
}


{
    "stakes": 0.5,
    "handData": {"21178050-4": [
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid910944",
            "orderIndex": 1,
            "hero": false,
            "dead": "2d1 8d2 4c3 2c4",
            "rows": "Kc1 Qs2 7h4/Ah0 5h2 9s3 Ks3 2h4/3d0 4h0 5d0 6s0 7s1",
            "win": -8.5,
            "playerId": "pid910944"
        },
        {
            "inFantasy": false,
            "result": 17,
            "playerName": "pid712037",
            "orderIndex": 0,
            "hero": true,
            "dead": "3c1 7c2 9d3 6h4",
            "rows": "Kh3 Ad4 As4/3s0 4s0 Qd2 Qc2 3h3/6d0 7d0 Jd0 4d1 Td1",
            "win": 8.24,
            "playerId": "pid712037"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 09:29:40",
    "roomId": "21178050"
}


{
    "stakes": 0.5,
    "handData": {"21178050-5": [
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid910944",
            "orderIndex": 0,
            "hero": false,
            "dead": "9h1 Ks2 9d3 9c4",
            "rows": "Kd0 Kh1 9s2/6d0 7h1 6s2 7d3 Qs4/5c0 7c0 Jc0 Qc3 Tc4",
            "win": -9.5,
            "playerId": "pid910944"
        },
        {
            "inFantasy": true,
            "result": 19,
            "playerName": "pid712037",
            "orderIndex": 1,
            "hero": true,
            "dead": "Kc0 Qh0 3d0",
            "rows": "Ah0 Ad0 As0/4d0 5h0 6h0 7s0 8h0/3s0 4s0 5s0 8s0 Ts0",
            "win": 9.21,
            "playerId": "pid712037"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 09:30:32",
    "roomId": "21178050"
}


{
    "stakes": 0.5,
    "handData": {"21178050-6": [
        {
            "inFantasy": true,
            "result": -6,
            "playerName": "pid910944",
            "orderIndex": 1,
            "hero": false,
            "dead": "5d0 2d1",
            "rows": "9s0 Kc0 Ks0/3c0 3s0 7d0 Qd0 Qc0/8h0 9h0 Th0 Jh0 Ah0",
            "win": -3,
            "playerId": "pid910944"
        },
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "pid712037",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jc0 3h0 2s0",
            "rows": "Kh0 Ad0 Ac0/4s0 5h0 6h0 7c0 8s0/4d0 8d0 9d0 Td0 Jd0",
            "win": 2.91,
            "playerId": "pid712037"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 09:31:09",
    "roomId": "21178050"
}


{
    "stakes": 0.5,
    "handData": {"21178050-7": [
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid910944",
            "orderIndex": 0,
            "hero": false,
            "dead": "6d1 5c2 2h3 8d4",
            "rows": "Ac1 Ad2 6h3/7h0 Kd0 Kh1 9h4 Th4/2s0 Js0 Ks0 3s2 Qs3",
            "win": -7.5,
            "playerId": "pid910944"
        },
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "pid712037",
            "orderIndex": 1,
            "hero": true,
            "dead": "Tc1 Ts2 3d3 4s4",
            "rows": "Ah0 As1 Qh4/5h0 5d0 7d2 7s2 6s3/2c0 Jc0 8c1 Jh3 2d4",
            "win": 7.27,
            "playerId": "pid712037"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 09:32:59",
    "roomId": "21178050"
}


{
    "stakes": 0.5,
    "handData": {"21178050-8": [
        {
            "inFantasy": false,
            "result": -24,
            "playerName": "pid910944",
            "orderIndex": 1,
            "hero": false,
            "dead": "Tc1 4c2 5h3 6s4",
            "rows": "Kd0 Qd1 9s4/Js0 Ac1 4d3 Jc3 4h4/8h0 9h0 Th0 8s2 Td2",
            "win": -12,
            "playerId": "pid910944"
        },
        {
            "inFantasy": true,
            "result": 24,
            "playerName": "pid712037",
            "orderIndex": 0,
            "hero": true,
            "dead": "7c0 3h0 3c0",
            "rows": "2h0 2d0 2c0/5d0 6d0 7d0 8c0 9d0/3s0 4s0 5s0 Qs0 As0",
            "win": 11.64,
            "playerId": "pid712037"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 09:33:30",
    "roomId": "21178050"
}


{
    "stakes": 0.5,
    "handData": {"21178050-9": [
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid910944",
            "orderIndex": 0,
            "hero": false,
            "dead": "7d1 8d2 Kh3 4c4",
            "rows": "Kc0 3h3 3s3/8s0 9c0 6s2 7h2 6c4/2h0 Jh0 2s1 Jc1 As4",
            "win": -9,
            "playerId": "pid910944"
        },
        {
            "inFantasy": true,
            "result": 18,
            "playerName": "pid712037",
            "orderIndex": 1,
            "hero": true,
            "dead": "6h0 5s0 4h0",
            "rows": "Td0 Kd0 Ks0/8h0 Jd0 Js0 Qh0 Qs0/3c0 5c0 7c0 8c0 Ac0",
            "win": 8.73,
            "playerId": "pid712037"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 09:34:43",
    "roomId": "21178050"
}


