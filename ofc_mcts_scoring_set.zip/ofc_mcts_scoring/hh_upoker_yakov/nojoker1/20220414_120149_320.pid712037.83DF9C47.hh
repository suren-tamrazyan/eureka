{
    "stakes": 0.1,
    "handData": {"21177423-1": [
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "pid907066",
            "orderIndex": 0,
            "hero": false,
            "dead": "3d1 5s2 3h3 7h4",
            "rows": "Ad0 Ah3 Ks4/8c0 Tc1 Ts1 4s2 Jc4/5h0 6h0 Th0 Kh2 Qh3",
            "win": -2.1,
            "playerId": "pid907066"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "pid712037",
            "orderIndex": 1,
            "hero": true,
            "dead": "9d1 9s2 2h3 5c4",
            "rows": "As0 6d3 Ac4/3s0 3c1 7c1 Jh2 7s4/8h0 8d0 Qc0 8s2 Qd3",
            "win": 2.03,
            "playerId": "pid712037"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 09:01:49",
    "roomId": "21177423"
}


{
    "stakes": 0.1,
    "handData": {"21177423-2": [
        {
            "inFantasy": false,
            "result": -38,
            "playerName": "pid907066",
            "orderIndex": 1,
            "hero": false,
            "dead": "5c1 6c2 5h3 4s4",
            "rows": "Qd0 8c2 Ks4/2s0 3c0 Kc1 3d2 3h3/7h0 7c0 Js1 Ac3 9c4",
            "win": -3.8,
            "playerId": "pid907066"
        },
        {
            "inFantasy": true,
            "result": 38,
            "playerName": "pid712037",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ts0 5s0 4h0",
            "rows": "Qc0 Qs0 Ad0/2h0 2c0 8d0 8s0 Jd0/Th0 Jh0 Qh0 Kh0 Ah0",
            "win": 3.68,
            "playerId": "pid712037"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 09:02:36",
    "roomId": "21177423"
}


{
    "stakes": 0.1,
    "handData": {"21177423-3": [
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid907066",
            "orderIndex": 0,
            "hero": false,
            "dead": "4s1 Qh2 6c3 5s4",
            "rows": "Ah0 Qs2 Jc3/7h0 9s0 8s1 8c3 Tc4/Td0 Qd0 7d1 4d2 2d4",
            "win": -1.6,
            "playerId": "pid907066"
        },
        {
            "inFantasy": true,
            "result": 16,
            "playerName": "pid712037",
            "orderIndex": 1,
            "hero": true,
            "dead": "4c0",
            "rows": "Kh0 Kc0 Ac0/7s0 8h0 8d0 Jh0 Jd0/2h0 2c0 2s0 3h0 3s0",
            "win": 1.55,
            "playerId": "pid712037"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 09:03:20",
    "roomId": "21177423"
}


{
    "stakes": 0.1,
    "handData": {"21177423-4": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid907066",
            "orderIndex": 1,
            "hero": false,
            "dead": "Kh1 3d2 2c3 4c4",
            "rows": "Ad0 8c2 As3/3s0 7d0 3c2 8s4 Ks4/9c0 Jh0 9s1 Jc1 Qd3",
            "win": -0.6,
            "playerId": "pid907066"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid712037",
            "orderIndex": 0,
            "hero": true,
            "dead": "6c1 Qh2 6s3 3h4",
            "rows": "Kc1 Qc3 6h4/2d0 2s0 4d0 Ts3 7s4/8h0 9h0 8d1 Jd2 Js2",
            "win": 0.58,
            "playerId": "pid712037"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 09:04:39",
    "roomId": "21177423"
}


{
    "stakes": 0.1,
    "handData": {"21177423-5": [
        {
            "inFantasy": false,
            "result": -23,
            "playerName": "pid907066",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qd1 9s2 9c3 2d4",
            "rows": "As0 Kd3 Ah3/7h0 7d0 6d1 Ts2 Js4/8c0 Jd0 Jh1 3c2 2s4",
            "win": -2.3,
            "playerId": "pid907066"
        },
        {
            "inFantasy": false,
            "result": 23,
            "playerName": "pid712037",
            "orderIndex": 1,
            "hero": true,
            "dead": "5h1 3h2 8h3 3d4",
            "rows": "Qs0 Jc3 Qc3/7c0 7s1 6s2 Th2 6c4/4h0 4c0 9d0 4s1 4d4",
            "win": 2.23,
            "playerId": "pid712037"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 09:06:00",
    "roomId": "21177423"
}


{
    "stakes": 0.1,
    "handData": {"21177423-6": [
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid907066",
            "orderIndex": 1,
            "hero": false,
            "dead": "7s1 4s2 2c3 3c4",
            "rows": "Ad0 7h3 Kd4/3h0 8c0 8d1 6d3 6c4/9c0 9s0 Js1 Qc2 Qs2",
            "win": -1.7,
            "playerId": "pid907066"
        },
        {
            "inFantasy": true,
            "result": 17,
            "playerName": "pid712037",
            "orderIndex": 0,
            "hero": true,
            "dead": "8h0",
            "rows": "Th0 Ts0 As0/2h0 3d0 4d0 5h0 6s0/4c0 5c0 6h0 7c0 8s0",
            "win": 1.64,
            "playerId": "pid712037"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 09:07:02",
    "roomId": "21177423"
}


