{
    "stakes": 0.2,
    "handData": {"21178407-1": [
        {
            "inFantasy": false,
            "result": 23,
            "playerName": "pid476780",
            "orderIndex": 0,
            "hero": false,
            "dead": "2c1 Th2 9s3 6c4",
            "rows": "Ad1 9d4 As4/4d0 5s0 6s0 3s3 7s3/Jh0 Jd0 Ks1 Kd2 Kc2",
            "win": 4.37,
            "playerId": "pid476780"
        },
        {
            "inFantasy": false,
            "result": -23,
            "playerName": "pid899257",
            "orderIndex": 1,
            "hero": true,
            "dead": "8h1 8d2 8s3 5d4",
            "rows": "Qc2 2s3 7h4/3d0 4s0 7c1 3c2 6d3/8c0 9h0 Js0 Qs1 Td4",
            "win": -4.6,
            "playerId": "pid899257"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 09:51:08",
    "roomId": "21178407"
}


{
    "stakes": 0.2,
    "handData": {"21178407-2": [
        {
            "inFantasy": true,
            "result": 4,
            "playerName": "pid476780",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jc0 5s1 3s2",
            "rows": "Td0 Tc0 Kc0/5d0 6d0 7h0 8s0 9s0/2h0 3h0 4h0 8h0 9h0",
            "win": 0.76,
            "playerId": "pid476780"
        },
        {
            "inFantasy": false,
            "result": -4,
            "playerName": "pid899257",
            "orderIndex": 0,
            "hero": true,
            "dead": "5h1 2c2 5c3 2d4",
            "rows": "Kd1 4d4 6c4/6s0 8d0 Jd2 Ah3 As3/Qd0 Qc0 Qs0 Qh1 3c2",
            "win": -0.8,
            "playerId": "pid899257"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 09:52:13",
    "roomId": "21178407"
}


{
    "stakes": 0.2,
    "handData": {"21178407-3": [
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "pid476780",
            "orderIndex": 0,
            "hero": false,
            "dead": "7s1 Ks2 Kh3 9d4",
            "rows": "Qd1 Kd3 Ac4/7d0 7c0 2c2 3c2 Kc4/8d0 Td0 Js0 Ts1 8h3",
            "win": -1,
            "playerId": "pid476780"
        },
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid899257",
            "orderIndex": 1,
            "hero": true,
            "dead": "4s1 Jh2 Th3 7h4",
            "rows": "Ah0 5d3 5h4/9s0 2d2 6d2 6h3 Qc4/4c0 6c0 Jc0 8c1 Tc1",
            "win": 0.95,
            "playerId": "pid899257"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 09:53:47",
    "roomId": "21178407"
}


{
    "stakes": 0.2,
    "handData": {"21178407-4": [
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid476780",
            "orderIndex": 1,
            "hero": false,
            "dead": "8c1 7d2 4c3 2d4",
            "rows": "8d2 Ks3 4h4/Jd0 9s1 Jc1 Td2 9d4/3h0 3c0 Qc0 Qs0 6h3",
            "win": -3.4,
            "playerId": "pid476780"
        },
        {
            "inFantasy": false,
            "result": 17,
            "playerName": "pid899257",
            "orderIndex": 0,
            "hero": true,
            "dead": "6d1 6c2 Jh3 Ad4",
            "rows": "Qh0 Ac2 Qd3/Kh1 5s2 7h3 Kd4 Kc4/3d0 4s0 5h0 6s0 7c1",
            "win": 3.23,
            "playerId": "pid899257"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 09:54:41",
    "roomId": "21178407"
}


{
    "stakes": 0.2,
    "handData": {"21178407-5": [
        {
            "inFantasy": false,
            "result": 2,
            "playerName": "pid476780",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qs1 2s2 2c3 9s4",
            "rows": "Ah1 Kh3 6h4/4d0 Jd0 6d1 2d2 5d4/6c0 7c0 8c0 Ac2 Qc3",
            "win": 0.38,
            "playerId": "pid476780"
        },
        {
            "inFantasy": true,
            "result": -2,
            "playerName": "pid899257",
            "orderIndex": 1,
            "hero": true,
            "dead": "5h0",
            "rows": "Td0 Tc0 Qh0/3h0 3c0 7d0 9h0 9c0/3s0 4s0 Js0 Ks0 As0",
            "win": -0.4,
            "playerId": "pid899257"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 09:55:15",
    "roomId": "21178407"
}


{
    "stakes": 0.2,
    "handData": {"21178407-6": [
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid476780",
            "orderIndex": 1,
            "hero": false,
            "dead": "Th1 Ts2 3d3 4s4",
            "rows": "Ac0 Ad1 6s2/2h0 7c0 8c0 7s4 9s4/Ks0 4h1 Jd2 6c3 9c3",
            "win": -2,
            "playerId": "pid476780"
        },
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid899257",
            "orderIndex": 0,
            "hero": true,
            "dead": "3c1 Qc2 Kh3 4d4",
            "rows": "Ah0 3s3 Kc3/Js0 8h1 Tc1 Jc2 As4/6d0 7d0 Td0 9d2 Qd4",
            "win": 1.9,
            "playerId": "pid899257"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 09:56:11",
    "roomId": "21178407"
}


{
    "stakes": 0.2,
    "handData": {"21178407-7": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid476780",
            "orderIndex": 0,
            "hero": false,
            "dead": "Kh1 2s2 4c3 Jc4",
            "rows": "5d1 5h3 Qs4/3h0 8h0 6h1 3s2 8s4/9d0 9s0 Qc0 9c2 Jd3",
            "win": 1.14,
            "playerId": "pid476780"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid899257",
            "orderIndex": 1,
            "hero": true,
            "dead": "9h1 Tc2 5c3 3d4",
            "rows": "Qh0 Ts2 Kc4/Ks0 7d1 8d1 Ah2 Ad3/2d0 2c0 Js0 2h3 3c4",
            "win": -1.2,
            "playerId": "pid899257"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 09:57:38",
    "roomId": "21178407"
}


{
    "stakes": 0.2,
    "handData": {"21178407-8": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid476780",
            "orderIndex": 1,
            "hero": false,
            "dead": "8c1 7c2 Qc3 6c4",
            "rows": "Kd3 Kc3 Ac4/3s0 6h0 5h1 5c2 3h4/Td0 Jh0 Jc0 9c1 Ts2",
            "win": 0.57,
            "playerId": "pid476780"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "pid899257",
            "orderIndex": 0,
            "hero": true,
            "dead": "2s1 2d2 9h3 6s4",
            "rows": "4s1 Jd3 9d4/3d0 7h0 5d1 Qd3 Ah4/8d0 8s0 Tc0 8h2 Th2",
            "win": -0.6,
            "playerId": "pid899257"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 09:58:26",
    "roomId": "21178407"
}



{
    "stakes": 0.2,
    "handData": {"21178407-10": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid476780",
            "orderIndex": 1,
            "hero": false,
            "dead": "2h1 5d2 9c3 4c4",
            "rows": "As1 9h4 Ts4/3c0 4h0 2c2 4s2 2d3/7c0 8s0 Qc0 8h1 Qd3",
            "win": 1.14,
            "playerId": "pid476780"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid899257",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qh1 Qs2 7s3 9d4",
            "rows": "Kd0 Ks1 3s3/Ad0 Tc1 5h2 Th2 Js4/6c0 6s0 8c0 Jh3 Td4",
            "win": -1.2,
            "playerId": "pid899257"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 10:00:43",
    "roomId": "21178407"
}


{
    "stakes": 0.2,
    "handData": {"21178407-11": [
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "pid476780",
            "orderIndex": 0,
            "hero": false,
            "dead": "6s1 5s2 2d3 8d4",
            "rows": "3h2 3s2 Jc3/Td0 Kh0 9s1 Jh4 Jd4/Qd0 Qc0 Qs0 8s1 7h3",
            "win": -1,
            "playerId": "pid476780"
        },
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid899257",
            "orderIndex": 1,
            "hero": true,
            "dead": "As1 3c2 4c3 5d4",
            "rows": "Ks0 Ac3 9d4/2c0 6c0 2s2 7c3 7s4/5h0 9h0 Th1 Qh1 4h2",
            "win": 0.95,
            "playerId": "pid899257"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 10:02:21",
    "roomId": "21178407"
}


{
    "stakes": 0.2,
    "handData": {"21178407-12": [
        {
            "inFantasy": false,
            "result": -13,
            "playerName": "pid476780",
            "orderIndex": 1,
            "hero": false,
            "dead": "3c1 Js2 4s3 9d4",
            "rows": "Ac2 Th3 Ks3/3d0 3s0 9h0 8h2 Qd4/4c0 Kc0 7c1 Jc1 Kh4",
            "win": -2.6,
            "playerId": "pid476780"
        },
        {
            "inFantasy": false,
            "result": 13,
            "playerName": "pid899257",
            "orderIndex": 0,
            "hero": true,
            "dead": "4h1 8c2 Ah3 9c4",
            "rows": "Qs0 9s3 Qh3/6s0 2h1 8s1 8d2 2d4/7d0 Jh0 Jd0 5h2 5c4",
            "win": 2.47,
            "playerId": "pid899257"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 10:03:25",
    "roomId": "21178407"
}


{
    "stakes": 0.2,
    "handData": {"21178407-13": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid476780",
            "orderIndex": 0,
            "hero": false,
            "dead": "2s1 5h2 5d3 2d4",
            "rows": "4s3 4h4 6h4/Qh0 Qd1 7c2 Ts2 Th3/5c0 6c0 Qc0 Kc0 Jc1",
            "win": -1.2,
            "playerId": "pid476780"
        },
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "pid899257",
            "orderIndex": 1,
            "hero": true,
            "dead": "3c0",
            "rows": "8c0 8s0 Kh0/5s0 7h0 9c0 9s0 Jd0/2h0 2c0 Ah0 Ad0 Ac0",
            "win": 1.14,
            "playerId": "pid899257"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 10:03:58",
    "roomId": "21178407"
}


{
    "stakes": 0.2,
    "handData": {"21178407-14": [
        {
            "inFantasy": false,
            "result": 2,
            "playerName": "pid476780",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qs1 Kd2 2s3 9h4",
            "rows": "Ah0 6h4 6c4/7h0 4c1 4d2 6s3 7d3/2c0 8c0 Jc0 8s1 2h2",
            "win": 0.38,
            "playerId": "pid476780"
        },
        {
            "inFantasy": false,
            "result": -2,
            "playerName": "pid899257",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jh1 7c2 7s3 Ad4",
            "rows": "Kc0 As2 6d4/5h0 2d1 5c1 9d2 Ac4/Th0 Td0 Qh0 Tc3 Jd3",
            "win": -0.4,
            "playerId": "pid899257"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 10:04:44",
    "roomId": "21178407"
}


{
    "stakes": 0.2,
    "handData": {"21178407-15": [
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid476780",
            "orderIndex": 0,
            "hero": false,
            "dead": "3c1 Td2 Qh3 Jd4",
            "rows": "Qc2 Kh3 Kc3/4h0 5h0 7s0 7h2 6h4/8h0 8c0 8s1 9d1 9c4",
            "win": -2.8,
            "playerId": "pid476780"
        },
        {
            "inFantasy": false,
            "result": 14,
            "playerName": "pid899257",
            "orderIndex": 1,
            "hero": true,
            "dead": "8d1 Qs2 7c3 Qd4",
            "rows": "Kd0 As2 Ks4/3d0 4s0 4c1 7d1 3s3/6c0 6s0 2d2 5s3 5d4",
            "win": 2.66,
            "playerId": "pid899257"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 10:06:01",
    "roomId": "21178407"
}


{
    "stakes": 0.2,
    "handData": {"21178407-16": [
        {
            "inFantasy": false,
            "result": -31,
            "playerName": "pid476780",
            "orderIndex": 1,
            "hero": false,
            "dead": "4d1 Kh2 4h3 Kc4",
            "rows": "Ad1 Ac2 Ks3/2d0 5d0 5c0 2s3 6d4/7s0 Th0 8h1 7c2 Kd4",
            "win": -6.2,
            "playerId": "pid476780"
        },
        {
            "inFantasy": true,
            "result": 31,
            "playerName": "pid899257",
            "orderIndex": 0,
            "hero": true,
            "dead": "Tc0 4c0",
            "rows": "9h0 9d0 9s0/Jh0 Qh0 Qc0 Qs0 As0/3h0 3d0 3s0 8d0 8c0",
            "win": 5.89,
            "playerId": "pid899257"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 10:06:30",
    "roomId": "21178407"
}


{
    "stakes": 0.2,
    "handData": {"21178407-17": [
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid476780",
            "orderIndex": 0,
            "hero": false,
            "dead": "2h1 2s2 7h3 8h4",
            "rows": "4h2 4s2 Ac3/3h0 6c0 5h1 6h1 3c3/9c0 Td0 Qh0 Qd4 Ah4",
            "win": -3.4,
            "playerId": "pid476780"
        },
        {
            "inFantasy": true,
            "result": 17,
            "playerName": "pid899257",
            "orderIndex": 1,
            "hero": true,
            "dead": "3s0",
            "rows": "Tc0 Ts0 Ad0/4c0 6d0 9s0 Kc0 Ks0/8d0 8c0 Jh0 Jd0 Jc0",
            "win": 3.23,
            "playerId": "pid899257"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 10:07:18",
    "roomId": "21178407"
}


