{
    "stakes": 0.5,
    "handData": {"21184406-1": [
        {
            "inFantasy": false,
            "result": 2,
            "playerName": "pid858715",
            "orderIndex": 0,
            "hero": false,
            "dead": "Ac1 Th2 2c3 6d4",
            "rows": "Ad0 Ah2 9h4/3h0 5c0 4s2 3c3 5h3/Jh0 Js0 Qh1 Qs1 9d4",
            "win": 0.97,
            "playerId": "pid858715"
        },
        {
            "inFantasy": false,
            "result": -2,
            "playerName": "pid652412",
            "orderIndex": 1,
            "hero": true,
            "dead": "8h1 4h2 3d3 Qc4",
            "rows": "Jc2 Ks2 Kc3/8d0 9c0 6s1 8c1 6c4/7d0 7s0 Tc0 3s3 Td4",
            "win": -1,
            "playerId": "pid652412"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 17:34:45",
    "roomId": "21184406"
}


{
    "stakes": 0.5,
    "handData": {"21184406-2": [
        {
            "inFantasy": true,
            "result": -8,
            "playerName": "pid858715",
            "orderIndex": 1,
            "hero": false,
            "dead": "Kd0 9d1 6h2",
            "rows": "4h0 4d0 4s0/7d0 8c0 9h0 Th0 Js0/2c0 5c0 9c0 Qc0 Kc0",
            "win": -4,
            "playerId": "pid858715"
        },
        {
            "inFantasy": true,
            "result": 8,
            "playerName": "pid652412",
            "orderIndex": 0,
            "hero": true,
            "dead": "7s0 2s0",
            "rows": "6d0 6c0 6s0/9s0 Td0 Jh0 Qd0 Ks0/3h0 5h0 7h0 8h0 Ah0",
            "win": 3.88,
            "playerId": "pid652412"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 17:35:33",
    "roomId": "21184406"
}


{
    "stakes": 0.5,
    "handData": {"21184406-3": [
        {
            "inFantasy": true,
            "result": -7,
            "playerName": "pid858715",
            "orderIndex": 0,
            "hero": false,
            "dead": "4s0",
            "rows": "9h0 9c0 Ks0/5d0 7h0 Jc0 Js0 Qd0/3c0 3s0 8h0 8c0 8s0",
            "win": -3.5,
            "playerId": "pid858715"
        },
        {
            "inFantasy": true,
            "result": 7,
            "playerName": "pid652412",
            "orderIndex": 1,
            "hero": true,
            "dead": "2d0",
            "rows": "Qs0 Kd0 Kc0/7s0 Jh0 Ah0 Ad0 Ac0/6h0 6d0 6s0 Th0 Tc0",
            "win": 3.39,
            "playerId": "pid652412"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 17:36:21",
    "roomId": "21184406"
}


{
    "stakes": 0.5,
    "handData": {"21184406-4": [
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid858715",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qh1 6d2 Qc3 3c4",
            "rows": "Jd0 Ah2 Ts4/5c0 7d1 7c1 Kh3 Tc4/4s0 Ks0 As0 8s2 3s3",
            "win": 4.85,
            "playerId": "pid858715"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid652412",
            "orderIndex": 0,
            "hero": true,
            "dead": "5d1 7h2 8c3 3h4",
            "rows": "Qs0 Kc0 Qd2/Ad0 2s2 5s3 6h4 Jc4/5h0 9h0 9d1 9c1 9s3",
            "win": -5,
            "playerId": "pid652412"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 17:37:44",
    "roomId": "21184406"
}


{
    "stakes": 0.5,
    "handData": {"21184406-5": [
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "pid858715",
            "orderIndex": 0,
            "hero": false,
            "dead": "Td1 6c2 8d3 3h4",
            "rows": "Ah1 Jc2 9d4/Qh0 Qs0 5c2 7h3 Qd3/4s0 6s0 8s0 Js1 7c4",
            "win": -10.5,
            "playerId": "pid858715"
        },
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "pid652412",
            "orderIndex": 1,
            "hero": true,
            "dead": "8h1 2d2 8c3 Kh4",
            "rows": "Jh1 Ad2 As3/6h0 6d0 3d1 3c3 Kc4/9c0 Tc0 Ts0 9s2 9h4",
            "win": 10.18,
            "playerId": "pid652412"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 17:39:05",
    "roomId": "21184406"
}


{
    "stakes": 0.5,
    "handData": {"21184406-6": [
        {
            "inFantasy": false,
            "result": -28,
            "playerName": "pid858715",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jd1 5c2 Kc3 6c4",
            "rows": "Qh1 5h2 Js4/4s0 6d0 2h1 2d2 4c3/8h0 8c0 Th0 Tc3 9d4",
            "win": -14,
            "playerId": "pid858715"
        },
        {
            "inFantasy": true,
            "result": 28,
            "playerName": "pid652412",
            "orderIndex": 0,
            "hero": true,
            "dead": "9h0 6s0 2c0",
            "rows": "Kd0 Ks0 Ad0/5s0 6h0 7c0 8d0 9s0/3h0 3d0 3c0 3s0 Qs0",
            "win": 13.58,
            "playerId": "pid652412"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 17:39:50",
    "roomId": "21184406"
}


{
    "stakes": 0.5,
    "handData": {"21184406-7": [
        {
            "inFantasy": false,
            "result": -1,
            "playerName": "pid858715",
            "orderIndex": 0,
            "hero": false,
            "dead": "4h1 4s2 8d3 7c4",
            "rows": "Kc0 8c3 7s4/5s0 6h0 As1 6s2 Ad4/3d0 Td0 Ts1 3c2 3s3",
            "win": -0.5,
            "playerId": "pid858715"
        },
        {
            "inFantasy": true,
            "result": 1,
            "playerName": "pid652412",
            "orderIndex": 1,
            "hero": true,
            "dead": "2d0",
            "rows": "9d0 9s0 Qh0/4d0 5h0 7d0 Th0 Tc0/2c0 4c0 6c0 Jc0 Qc0",
            "win": 0.5,
            "playerId": "pid652412"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 17:40:34",
    "roomId": "21184406"
}


{
    "stakes": 0.5,
    "handData": {"21184406-8": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid858715",
            "orderIndex": 1,
            "hero": false,
            "dead": "As1 6d2 4s3 5h4",
            "rows": "Kd0 8s2 7d4/2c0 9c0 3c1 3s3 9d3/4h0 Ah0 8h1 7h2 6h4",
            "win": -3,
            "playerId": "pid858715"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid652412",
            "orderIndex": 0,
            "hero": true,
            "dead": "6c1 8d2 Ad3 6s4",
            "rows": "Qd0 Qh3 Ts4/Kc0 Ks0 5d2 Jd3 5s4/9s0 Jc0 7c1 Tc1 8c2",
            "win": 2.91,
            "playerId": "pid652412"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 17:41:55",
    "roomId": "21184406"
}


{
    "stakes": 0.5,
    "handData": {"21184406-9": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid858715",
            "orderIndex": 0,
            "hero": false,
            "dead": "Td1 5s2 5h3 2s4",
            "rows": "Ks0 7h2 Th4/3c0 6d0 9d1 8h2 Ah3/4c0 4s0 Qd1 4d3 4h4",
            "win": 0,
            "playerId": "pid858715"
        },
        {
            "inFantasy": true,
            "result": 0,
            "playerName": "pid652412",
            "orderIndex": 1,
            "hero": true,
            "dead": "2c0",
            "rows": "3d0 Ac0 As0/3s0 7c0 7s0 Jh0 Js0/2d0 8d0 8c0 Kh0 Kc0",
            "win": 0,
            "playerId": "pid652412"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 17:42:40",
    "roomId": "21184406"
}


{
    "stakes": 0.5,
    "handData": {"21184406-10": [
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid858715",
            "orderIndex": 1,
            "hero": false,
            "dead": "Kc1 7d2 4d3 7s4",
            "rows": "Td2 Qc3 Kd4/4c0 5d0 2c1 Ac1 Jd4/5h0 7h0 9h0 Kh2 3h3",
            "win": 4.85,
            "playerId": "pid858715"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid652412",
            "orderIndex": 0,
            "hero": true,
            "dead": "3d1 9d2 Ks3 2d4",
            "rows": "Ad0 As0 Ah4/5s0 6s0 4h1 4s2 Jh4/Tc0 7c1 9c2 8h3 Jc3",
            "win": -5,
            "playerId": "pid652412"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 17:43:59",
    "roomId": "21184406"
}


{
    "stakes": 0.5,
    "handData": {"21184406-11": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid858715",
            "orderIndex": 0,
            "hero": false,
            "dead": "Kh1 6s2 3s3 5d4",
            "rows": "As0 Ad3 Qh4/2s0 7h0 8h1 2h2 6d4/3c0 Jc0 5c1 8c2 Ac3",
            "win": -3,
            "playerId": "pid858715"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid652412",
            "orderIndex": 1,
            "hero": true,
            "dead": "5h1 2d2 9h3 7s4",
            "rows": "Jh1 Ah2 Td4/6h0 Th0 6c1 9c2 Ts3/4s0 Kd0 Kc0 Qc3 Ks4",
            "win": 2.91,
            "playerId": "pid652412"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 17:45:20",
    "roomId": "21184406"
}


{
    "stakes": 0.5,
    "handData": {"21184406-12": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid858715",
            "orderIndex": 1,
            "hero": false,
            "dead": "9d1 7h2 3d3 Qd4",
            "rows": "Ks0 5h3 7s3/4h0 4s0 Td1 8s2 Ah4/6c0 8c0 2c1 7c2 Kh4",
            "win": 0,
            "playerId": "pid858715"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid652412",
            "orderIndex": 0,
            "hero": true,
            "dead": "5c1 2d2 8h3 3h4",
            "rows": "Ad1 As1 Th3/3c0 4d0 Kc3 8d4 9h4/9s0 Jh0 Jc0 Jd2 Js2",
            "win": 0,
            "playerId": "pid652412"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 17:46:41",
    "roomId": "21184406"
}


{
    "stakes": 0.5,
    "handData": {"21184406-13": [
        {
            "inFantasy": false,
            "result": -30,
            "playerName": "pid858715",
            "orderIndex": 0,
            "hero": false,
            "dead": "Kd1 5c2 Jc3 5d4",
            "rows": "As0 2c3 Qd4/Ts0 3h1 9s2 6c3 9h4/8c0 Qc0 Kc0 4c1 9c2",
            "win": -15,
            "playerId": "pid858715"
        },
        {
            "inFantasy": false,
            "result": 30,
            "playerName": "pid652412",
            "orderIndex": 1,
            "hero": true,
            "dead": "6d1 5h2 Th3 7c4",
            "rows": "Ad1 Ah2 Jh3/Tc0 Jd0 8d1 7d2 9d4/2s0 4s0 5s0 6s3 3s4",
            "win": 14.55,
            "playerId": "pid652412"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 17:47:58",
    "roomId": "21184406"
}


{
    "stakes": 0.5,
    "handData": {"21184406-14": [
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid858715",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qd1 6c2 Jh3 Ah4",
            "rows": "As0 Ad2 5s4/5d0 5c0 9s1 6s2 6h3/8h0 Tc0 8c1 8s3 3c4",
            "win": -8,
            "playerId": "pid858715"
        },
        {
            "inFantasy": true,
            "result": 16,
            "playerName": "pid652412",
            "orderIndex": 0,
            "hero": true,
            "dead": "Kh0 Td0 6d0",
            "rows": "Jd0 Jc0 Ac0/2h0 2c0 2s0 3d0 3s0/9h0 9c0 Qh0 Qc0 Qs0",
            "win": 7.76,
            "playerId": "pid652412"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 17:48:44",
    "roomId": "21184406"
}


{
    "stakes": 0.5,
    "handData": {"21184406-15": [
        {
            "inFantasy": true,
            "result": 31,
            "playerName": "pid858715",
            "orderIndex": 0,
            "hero": false,
            "dead": "Kh0 Qh1 4d2",
            "rows": "9h0 9d0 9s0/2s0 3s0 4h0 5h0 6s0/2c0 4c0 7c0 9c0 Jc0",
            "win": 15.03,
            "playerId": "pid858715"
        },
        {
            "inFantasy": false,
            "result": -31,
            "playerName": "pid652412",
            "orderIndex": 1,
            "hero": true,
            "dead": "2h1 4s2 2d3 5s4",
            "rows": "Kd0 3d2 Kc3/8c0 Td0 As2 8d3 Ah4/Jh0 Jd0 7d1 7s1 Qs4",
            "win": -15.5,
            "playerId": "pid652412"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 17:49:29",
    "roomId": "21184406"
}


{
    "stakes": 0.5,
    "handData": {"21184406-16": [
        {
            "inFantasy": true,
            "result": 20,
            "playerName": "pid858715",
            "orderIndex": 1,
            "hero": false,
            "dead": "2d0",
            "rows": "3c0 6s0 9c0/4h0 7h0 8h0 Jh0 Kh0/5d0 5s0 Td0 Tc0 Ts0",
            "win": 9.7,
            "playerId": "pid858715"
        },
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid652412",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qd1 8s2 8d3 6h4",
            "rows": "Ah0 Kd2 5c3/2h0 Js0 3s2 7d4 Th4/7c0 8c0 5h1 6d1 9s3",
            "win": -10,
            "playerId": "pid652412"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 17:50:25",
    "roomId": "21184406"
}


