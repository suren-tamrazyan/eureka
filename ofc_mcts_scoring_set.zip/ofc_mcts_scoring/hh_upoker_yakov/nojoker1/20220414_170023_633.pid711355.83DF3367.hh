{
    "stakes": 3,
    "handData": {"21182503-1": [
        {
            "inFantasy": false,
            "result": 14,
            "playerName": "pid908241",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jh1 3d2 7h3 6c4",
            "rows": "Kd0 Kc0 Qh4/4c0 5c0 4h1 2c2 5h3/8s0 8h1 Th2 Ts3 Tc4",
            "win": 40.74,
            "playerId": "pid908241"
        },
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid711355",
            "orderIndex": 1,
            "hero": true,
            "dead": "8c1 6h2 2h3 5s4",
            "rows": "Qd0 Td2 Ac4/3h0 6d0 Kh1 Ks1 7c4/9c0 Jc0 Js2 9d3 9s3",
            "win": -42,
            "playerId": "pid711355"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 14:00:23",
    "roomId": "21182503"
}


{
    "stakes": 3,
    "handData": {"21182503-2": [
        {
            "inFantasy": true,
            "result": 16,
            "playerName": "pid908241",
            "orderIndex": 1,
            "hero": false,
            "dead": "5d0 3c1",
            "rows": "Qh0 Kh0 Ah0/8h0 9c0 Tc0 Jd0 Qs0/4d0 4s0 6h0 6c0 6s0",
            "win": 46.56,
            "playerId": "pid908241"
        },
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid711355",
            "orderIndex": 0,
            "hero": true,
            "dead": "9s1 4c2 5s3 2c4",
            "rows": "As0 Qc2 Ac3/7d0 7s0 2h1 3h2 7c3/3d0 Td0 6d1 Kd4 Kc4",
            "win": -48,
            "playerId": "pid711355"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 14:01:02",
    "roomId": "21182503"
}


{
    "stakes": 3,
    "handData": {"21182503-3": [
        {
            "inFantasy": false,
            "result": 14,
            "playerName": "pid908241",
            "orderIndex": 0,
            "hero": false,
            "dead": "3d1 2d2 9h3 3c4",
            "rows": "Kc0 Kh1 Jc4/2c0 Ah0 Ac0 9c3 Ks4/8d0 5h1 8h2 Jd2 Jh3",
            "win": 40.74,
            "playerId": "pid908241"
        },
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid711355",
            "orderIndex": 1,
            "hero": true,
            "dead": "8s1 As2 6s3 6h4",
            "rows": "Qc2 Ts3 Qs4/3h0 5c0 5s1 4h2 4s3/9d0 Td0 Qd0 Ad1 Tc4",
            "win": -42,
            "playerId": "pid711355"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 14:02:17",
    "roomId": "21182503"
}


{
    "stakes": 3,
    "handData": {"21182503-4": [
        {
            "inFantasy": true,
            "result": 16,
            "playerName": "pid908241",
            "orderIndex": 1,
            "hero": false,
            "dead": "6h0 2s1",
            "rows": "Ts0 Ah0 Ad0/4h0 4d0 7d0 Qh0 Qd0/2c0 5c0 6c0 Jc0 Ac0",
            "win": 46.56,
            "playerId": "pid908241"
        },
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid711355",
            "orderIndex": 0,
            "hero": true,
            "dead": "6s1 7h2 4s3 5s4",
            "rows": "Kd0 8s2 8c3/2h0 5d0 9h1 9c2 8h3/Js0 Qc0 Jd1 8d4 Ks4",
            "win": -48,
            "playerId": "pid711355"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 14:02:58",
    "roomId": "21182503"
}


{
    "stakes": 3,
    "handData": {"21182503-5": [
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid908241",
            "orderIndex": 0,
            "hero": false,
            "dead": "9h1 3h2 3c3 7c4",
            "rows": "Qc0 Kc2 7s3/4h0 5h0 5s1 Tc1 Ts3/2d0 8d0 3d2 9d4 Jd4",
            "win": -24,
            "playerId": "pid908241"
        },
        {
            "inFantasy": false,
            "result": 8,
            "playerName": "pid711355",
            "orderIndex": 1,
            "hero": true,
            "dead": "5c1 4d2 5d3 6d4",
            "rows": "Ad0 Kd3 Jc4/6h0 8c0 6c2 6s3 7h4/Js0 Ks0 4s1 As1 8s2",
            "win": 23.28,
            "playerId": "pid711355"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 14:04:08",
    "roomId": "21182503"
}


{
    "stakes": 3,
    "handData": {"21182503-6": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid908241",
            "orderIndex": 1,
            "hero": false,
            "dead": "Kh1 9c2 5s3 2d4",
            "rows": "Kc0 Ks0 8s4/Ah0 Ad0 2c2 4h3 5d3/7h0 7c1 Td1 Qh2 Ts4",
            "win": 8.73,
            "playerId": "pid908241"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "pid711355",
            "orderIndex": 0,
            "hero": true,
            "dead": "3d1 8c2 9d3 8d4",
            "rows": "Th2 Kd3 9s4/4d0 Jh0 5c1 4c3 Jc4/2s0 3s0 7s0 6s1 4s2",
            "win": -9,
            "playerId": "pid711355"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 14:05:23",
    "roomId": "21182503"
}


{
    "stakes": 3,
    "handData": {"21182503-7": [
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "pid908241",
            "orderIndex": 0,
            "hero": false,
            "dead": "4s0 3d1",
            "rows": "9h0 9d0 Kh0/2c0 7c0 8c0 Tc0 Ac0/2h0 3h0 4h0 5h0 Ah0",
            "win": 87.3,
            "playerId": "pid908241"
        },
        {
            "inFantasy": false,
            "result": -30,
            "playerName": "pid711355",
            "orderIndex": 1,
            "hero": true,
            "dead": "6h1 3s2 5d3 Ks4",
            "rows": "Ts3 6d4 6s4/2s0 4c0 5c0 4d2 5s2/Th0 Jh0 7h1 8h1 9s3",
            "win": -90,
            "playerId": "pid711355"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 14:06:05",
    "roomId": "21182503"
}


{
    "stakes": 3,
    "handData": {"21182503-8": [
        {
            "inFantasy": true,
            "result": 23,
            "playerName": "pid908241",
            "orderIndex": 1,
            "hero": false,
            "dead": "2d0",
            "rows": "Kh0 Ah0 As0/4d0 4c0 4s0 5c0 Js0/9h0 9d0 Td0 Tc0 Ts0",
            "win": 66.93,
            "playerId": "pid908241"
        },
        {
            "inFantasy": false,
            "result": -23,
            "playerName": "pid711355",
            "orderIndex": 0,
            "hero": true,
            "dead": "3d1 8d2 3c3 2c4",
            "rows": "Ac1 Ad2 6s3/Jd0 Qc1 Kd2 3s4 Ks4/4h0 5h0 6h0 8h0 7d3",
            "win": -69,
            "playerId": "pid711355"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 14:06:50",
    "roomId": "21182503"
}


{
    "stakes": 3,
    "handData": {"21182503-9": [
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid908241",
            "orderIndex": 0,
            "hero": false,
            "dead": "9c1 As2 4d3 Ah4",
            "rows": "Qc0 2h4 2s4/5s0 3s1 7h1 5d2 5c3/6h0 6c0 Td0 6d2 Tc3",
            "win": 8.73,
            "playerId": "pid908241"
        },
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "pid711355",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qs1 3c2 3h3 4h4",
            "rows": "Kd2 9s4 Qh4/6s0 9h0 9d2 8c3 8s3/7c0 Jh0 Jc0 7d1 Jd1",
            "win": -9,
            "playerId": "pid711355"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 14:08:34",
    "roomId": "21182503"
}


