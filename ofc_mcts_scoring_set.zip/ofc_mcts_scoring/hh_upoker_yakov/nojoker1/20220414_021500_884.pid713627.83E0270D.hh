{
    "stakes": 0.5,
    "handData": {"21169926-1": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid358057",
            "orderIndex": 1,
            "hero": false,
            "dead": "4s1 7d2 3c3 Ah4",
            "rows": "Kc0 Ac2 As3/2s0 3h0 6d0 3s2 Ks4/Ts0 9d1 Jc1 8d3 Jd4",
            "win": -6,
            "playerId": "pid358057"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid713627",
            "orderIndex": 0,
            "hero": true,
            "dead": "7s1 Qd2 5d3 8s4",
            "rows": "9s3 Jh4 Kh4/2d0 Js0 2h1 2c1 4d3/5c0 8c0 9c0 6c2 Qc2",
            "win": 5.82,
            "playerId": "pid713627"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-13 23:15:00",
    "roomId": "21169926"
}


{
    "stakes": 0.5,
    "handData": {"21169926-2": [
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid358057",
            "orderIndex": 0,
            "hero": false,
            "dead": "Ac1 Ad2 Kd3 4d4",
            "rows": "Kh0 Kc2 Jh4/3s0 5c0 7s0 7c1 Ks4/Qd0 Qc1 9s2 Th3 Tc3",
            "win": -5,
            "playerId": "pid358057"
        },
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid713627",
            "orderIndex": 1,
            "hero": true,
            "dead": "2h1 2s2 3h3 2c4",
            "rows": "Ah0 9c3 9d4/4s0 5h0 5s1 8d2 8c4/7d0 Jd0 Jc1 6c2 6h3",
            "win": 4.85,
            "playerId": "pid713627"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-13 23:16:07",
    "roomId": "21169926"
}


{
    "stakes": 0.5,
    "handData": {"21169926-3": [
        {
            "inFantasy": false,
            "result": 21,
            "playerName": "pid358057",
            "orderIndex": 1,
            "hero": false,
            "dead": "5h1 8d2 Ks3 Tc4",
            "rows": "Ac1 Ah3 Js4/2h0 6c0 2s2 8c2 8s4/4c0 4s0 9s0 9c1 9d3",
            "win": 10.18,
            "playerId": "pid358057"
        },
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "pid713627",
            "orderIndex": 0,
            "hero": true,
            "dead": "6d1 5d2 Jd3 Ts4",
            "rows": "Kc1 Kh2 Ad3/2d0 4h1 4d2 7c3 Kd4/7h0 9h0 Td0 Jc0 Qc4",
            "win": -10.5,
            "playerId": "pid713627"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-13 23:17:04",
    "roomId": "21169926"
}


{
    "stakes": 0.5,
    "handData": {"21169926-4": [
        {
            "inFantasy": true,
            "result": 7,
            "playerName": "pid358057",
            "orderIndex": 0,
            "hero": false,
            "dead": "6c0 5s1 4s2",
            "rows": "7s0 Ah0 As0/3d0 4d0 8d0 9d0 Td0/7h0 9h0 Jh0 Qh0 Kh0",
            "win": 3.39,
            "playerId": "pid358057"
        },
        {
            "inFantasy": false,
            "result": -7,
            "playerName": "pid713627",
            "orderIndex": 1,
            "hero": true,
            "dead": "Js1 9s2 5c3 Ts4",
            "rows": "Ad2 Ac3 Kd4/2d0 3s1 5h1 2s3 2h4/4c0 7c0 8c0 Qc0 Tc2",
            "win": -3.5,
            "playerId": "pid713627"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-13 23:17:55",
    "roomId": "21169926"
}


{
    "stakes": 0.5,
    "handData": {"21169926-5": [
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid358057",
            "orderIndex": 1,
            "hero": false,
            "dead": "3s1 6c2 5h3 7s4",
            "rows": "Kd0 Ks0 Ad4/5c0 7h0 5d1 7d1 2h3/8s0 8h2 9h2 4h3 Qc4",
            "win": -9.5,
            "playerId": "pid358057"
        },
        {
            "inFantasy": true,
            "result": 19,
            "playerName": "pid713627",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jh0 9d0 8c0",
            "rows": "Tc0 Ts0 Qh0/2c0 3c0 4d0 5s0 6d0/2s0 4s0 6s0 9s0 As0",
            "win": 9.21,
            "playerId": "pid713627"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-13 23:18:23",
    "roomId": "21169926"
}


{
    "stakes": 0.5,
    "handData": {"21169926-6": [
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid358057",
            "orderIndex": 0,
            "hero": false,
            "dead": "2c1 2h2 As3 2s4",
            "rows": "Ad0 Ac2 Ts4/3h0 6h0 3d1 3s3 7c3/Tc0 Qd0 Jd1 Ah2 Jc4",
            "win": -9,
            "playerId": "pid358057"
        },
        {
            "inFantasy": false,
            "result": 18,
            "playerName": "pid713627",
            "orderIndex": 1,
            "hero": true,
            "dead": "7s1 9s2 7h3 Jh4",
            "rows": "Qc1 Kc2 Kd4/5s0 8h1 5c2 Js3 5d4/7d0 8s0 9d0 Th0 6d3",
            "win": 8.73,
            "playerId": "pid713627"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-13 23:19:43",
    "roomId": "21169926"
}


{
    "stakes": 0.5,
    "handData": {"21169926-7": [
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid358057",
            "orderIndex": 1,
            "hero": false,
            "dead": "2s1 7c2 2h3 9s4",
            "rows": "Kd0 Ad3 Ac3/4c1 5h1 Qd2 Qc2 Td4/7s0 8s0 9d0 Jh0 Th4",
            "win": -10,
            "playerId": "pid358057"
        },
        {
            "inFantasy": true,
            "result": 20,
            "playerName": "pid713627",
            "orderIndex": 0,
            "hero": true,
            "dead": "Kh0 9h0",
            "rows": "7h0 7d0 Ah0/2c0 3c0 6c0 8c0 Jc0/3s0 6s0 Js0 Ks0 As0",
            "win": 9.7,
            "playerId": "pid713627"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-13 23:20:06",
    "roomId": "21169926"
}


{
    "stakes": 0.5,
    "handData": {"21169926-8": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid358057",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qh1 6s2 2d3 Ac4",
            "rows": "Kc0 Ah1 Kd3/3s0 4d0 3c2 4h2 4s4/9c0 Ts0 Tc1 8h3 7c4",
            "win": -3,
            "playerId": "pid358057"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid713627",
            "orderIndex": 1,
            "hero": true,
            "dead": "9d1 6c2 5c3 Kh4",
            "rows": "Qd0 6d1 8c2/4c0 Ks0 Ad1 5s2 Td3/2h0 7h0 7s3 Jh4 Js4",
            "win": 2.91,
            "playerId": "pid713627"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-13 23:21:14",
    "roomId": "21169926"
}


{
    "stakes": 0.5,
    "handData": {"21169926-9": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid358057",
            "orderIndex": 1,
            "hero": false,
            "dead": "3d1 5d2 3h3 4h4",
            "rows": "Kc1 8d3 9d4/5h0 Jh0 Jc2 6h3 4s4/9c0 9s0 Qc0 Qd1 Qs2",
            "win": 5.82,
            "playerId": "pid358057"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid713627",
            "orderIndex": 0,
            "hero": true,
            "dead": "Qh1 2c2 7h3 2d4",
            "rows": "Ac0 Kh1 Ah3/7d1 Tc2 7s3 6s4 8h4/3s0 5s0 Js0 Ks0 8s2",
            "win": -6,
            "playerId": "pid713627"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-13 23:21:58",
    "roomId": "21169926"
}


{
    "stakes": 0.5,
    "handData": {"21169926-10": [
        {
            "inFantasy": false,
            "result": -11,
            "playerName": "pid358057",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jd1 6c2 Qd3 6s4",
            "rows": "Ad0 As0 8s4/3h0 4s1 5h3 5c3 7h4/7c0 Qc0 9c1 Tc2 Jc2",
            "win": -5.5,
            "playerId": "pid358057"
        },
        {
            "inFantasy": false,
            "result": 11,
            "playerName": "pid713627",
            "orderIndex": 1,
            "hero": true,
            "dead": "4d1 2s2 Ks3 3s4",
            "rows": "7d2 8d3 8c3/5d1 9d1 9s2 4c4 6d4/2d0 3c0 4h0 5s0 Ah0",
            "win": 5.33,
            "playerId": "pid713627"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-13 23:23:26",
    "roomId": "21169926"
}


{
    "stakes": 0.5,
    "handData": {"21169926-11": [
        {
            "inFantasy": false,
            "result": -2,
            "playerName": "pid358057",
            "orderIndex": 1,
            "hero": false,
            "dead": "3s1 Js2 5d3 3h4",
            "rows": "Kc0 7d4 9s4/8s0 8c1 8d2 Qc2 Th3/5h0 9h0 Qh0 6h1 8h3",
            "win": -1,
            "playerId": "pid358057"
        },
        {
            "inFantasy": false,
            "result": 2,
            "playerName": "pid713627",
            "orderIndex": 0,
            "hero": true,
            "dead": "6c1 2h2 6d3 2s4",
            "rows": "Ad1 Ah2 9d4/7s0 Ts0 Jc1 7c2 Tc3/3c0 Qd0 Qs0 4c3 4s4",
            "win": 0.97,
            "playerId": "pid713627"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-13 23:24:14",
    "roomId": "21169926"
}


{
    "stakes": 0.5,
    "handData": {"21169926-12": [
        {
            "inFantasy": false,
            "result": -30,
            "playerName": "pid358057",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qh1 Ad2 Kd3 5h4",
            "rows": "Kc0 2d2 2s2/8c0 7d1 Jd1 4c3 As4/6d0 6c0 9s0 6h3 9d4",
            "win": -15,
            "playerId": "pid358057"
        },
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "pid713627",
            "orderIndex": 1,
            "hero": true,
            "dead": "7c0 5d0 2c0",
            "rows": "Th0 Tc0 Ts0/8s0 Jh0 Jc0 Js0 Qs0/3h0 4h0 7h0 9h0 Kh0",
            "win": 14.55,
            "playerId": "pid713627"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-13 23:24:48",
    "roomId": "21169926"
}


{
    "stakes": 0.5,
    "handData": {"21169926-13": [
        {
            "inFantasy": false,
            "result": -28,
            "playerName": "pid358057",
            "orderIndex": 1,
            "hero": false,
            "dead": "7d1 2d2 3c3 2c4",
            "rows": "Ad0 Ah1 7s4/5c0 9s2 Td2 Th3 3d4/4c0 4s0 Js0 Jc1 Jd3",
            "win": -14,
            "playerId": "pid358057"
        },
        {
            "inFantasy": true,
            "result": 28,
            "playerName": "pid713627",
            "orderIndex": 0,
            "hero": true,
            "dead": "4h0",
            "rows": "6s0 Kh0 Kc0/5d0 6h0 7c0 8h0 9h0/6d0 Qh0 Qd0 Qc0 Qs0",
            "win": 13.58,
            "playerId": "pid713627"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-13 23:25:18",
    "roomId": "21169926"
}


{
    "stakes": 0.5,
    "handData": {"21169926-14": [
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid358057",
            "orderIndex": 0,
            "hero": false,
            "dead": "Kh1 8c2 5c3 6d4",
            "rows": "As0 Ac1 Th4/2d0 4h0 2c2 7c3 7s4/8d0 Tc0 Qc1 9d2 Jc3",
            "win": 0.5,
            "playerId": "pid358057"
        },
        {
            "inFantasy": true,
            "result": -1,
            "playerName": "pid713627",
            "orderIndex": 1,
            "hero": true,
            "dead": "6h0",
            "rows": "Ts0 Qh0 Qs0/4c0 4s0 5h0 5s0 8h0/3d0 7d0 Td0 Jd0 Qd0",
            "win": -0.5,
            "playerId": "pid713627"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-13 23:25:50",
    "roomId": "21169926"
}


{
    "stakes": 0.5,
    "handData": {"21169926-15": [
        {
            "inFantasy": true,
            "result": 14,
            "playerName": "pid358057",
            "orderIndex": 1,
            "hero": false,
            "dead": "5c0 5d1 4s2",
            "rows": "7c0 Ad0 Ac0/8c0 9h0 Tc0 Jh0 Qh0/3h0 3d0 3s0 6h0 6s0",
            "win": 6.79,
            "playerId": "pid358057"
        },
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid713627",
            "orderIndex": 0,
            "hero": true,
            "dead": "2h1 5s2 5h3 4d4",
            "rows": "4h2 Kh2 8d4/7h0 9d1 Td1 Ah3 Kc4/Jd0 Js0 Qd0 Qc0 Jc3",
            "win": -7,
            "playerId": "pid713627"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-13 23:26:53",
    "roomId": "21169926"
}


