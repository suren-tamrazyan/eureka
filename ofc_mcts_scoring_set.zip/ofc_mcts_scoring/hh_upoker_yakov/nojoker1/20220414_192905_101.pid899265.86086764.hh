{
    "stakes": 2,
    "handData": {"21183662-1": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid131192",
            "orderIndex": 0,
            "hero": false,
            "dead": "2d1 3c2 Js3 7s4",
            "rows": "Kh2 Kd3 Qs4/5d0 9d0 9c2 Ad3 8h4/4d0 4s0 Qc0 4c1 Qd1",
            "win": -24,
            "playerId": "pid131192"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid899265",
            "orderIndex": 1,
            "hero": true,
            "dead": "9h1 Ts2 7h3 3s4",
            "rows": "Qh0 Jc1 Jh2/5s0 Kc0 Ks2 Tc3 Jd4/2h0 2s0 6s1 6d3 9s4",
            "win": 22.8,
            "playerId": "pid899265"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 16:29:05",
    "roomId": "21183662"
}


{
    "stakes": 2,
    "handData": {"21183662-2": [
        {
            "inFantasy": false,
            "result": -7,
            "playerName": "pid131192",
            "orderIndex": 1,
            "hero": false,
            "dead": "4s1 9c2 Jd3 Ts4",
            "rows": "Ks0 Jc4 As4/4d0 5c0 5h1 3d2 3h3/Th0 Qs0 Qc1 2c2 Qh3",
            "win": -14,
            "playerId": "pid131192"
        },
        {
            "inFantasy": false,
            "result": 7,
            "playerName": "pid899265",
            "orderIndex": 0,
            "hero": true,
            "dead": "3s1 6h2 2d3 2h4",
            "rows": "Ad1 5d4 6c4/6d0 6s0 7c0 4h2 7d2/8h0 9h0 8s1 9d3 9s3",
            "win": 13.3,
            "playerId": "pid899265"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 16:30:00",
    "roomId": "21183662"
}


{
    "stakes": 2,
    "handData": {"21183662-3": [
        {
            "inFantasy": false,
            "result": -16,
            "playerName": "pid131192",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qh1 Kd2 9d3 8d4",
            "rows": "6d0 Ad1 6s2/4h0 9h0 9s1 5d3 7h3/3s0 Ts0 3d2 9c4 Qs4",
            "win": -32,
            "playerId": "pid131192"
        },
        {
            "inFantasy": false,
            "result": 16,
            "playerName": "pid899265",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qd1 2s2 8h3 6c4",
            "rows": "Ks0 Qc1 Td4/4s0 5c2 7d2 4d3 7s4/Jh0 Jc0 Js0 Jd1 8c3",
            "win": 30.4,
            "playerId": "pid899265"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 16:31:18",
    "roomId": "21183662"
}


{
    "stakes": 2,
    "handData": {"21183662-4": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid131192",
            "orderIndex": 1,
            "hero": false,
            "dead": "4s1 7s2 7c3 Kh4",
            "rows": "Kc1 Ah3 Ad4/3c0 5c0 3h2 Tc3 As4/6h0 7h0 Qh0 5h1 8h2",
            "win": 0,
            "playerId": "pid131192"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid899265",
            "orderIndex": 0,
            "hero": true,
            "dead": "3s1 6s2 5s3 2c4",
            "rows": "Qc0 Jh2 Qd3/Jd0 Kd0 Td1 5d2 3d3/2h0 4h0 4c1 6d4 9d4",
            "win": 0,
            "playerId": "pid899265"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 16:32:11",
    "roomId": "21183662"
}


{
    "stakes": 2,
    "handData": {"21183662-5": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid131192",
            "orderIndex": 0,
            "hero": false,
            "dead": "6s1 Qc2 2c3 7d4",
            "rows": "Kc1 9c3 Jh4/3h0 3s0 8s1 7s2 3c4/5d0 9d0 Kd0 Jd2 Td3",
            "win": 22.8,
            "playerId": "pid131192"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid899265",
            "orderIndex": 1,
            "hero": true,
            "dead": "7h1 9h2 4h3 2h4",
            "rows": "Qd1 Qh2 6h3/5c0 Tc0 4c2 7c3 8d4/9s0 Qs0 As0 5s1 6c4",
            "win": -24,
            "playerId": "pid899265"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 16:33:25",
    "roomId": "21183662"
}


{
    "stakes": 2,
    "handData": {"21183662-6": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid131192",
            "orderIndex": 1,
            "hero": false,
            "dead": "7h1 2c2 7s3 3c4",
            "rows": "Ah1 5s4 8s4/6s0 Ts0 9h2 6c3 Tc3/4c0 4s0 Jc0 Jd1 4h2",
            "win": 22.8,
            "playerId": "pid131192"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid899265",
            "orderIndex": 0,
            "hero": true,
            "dead": "8d1 Qs2 Qd3 5h4",
            "rows": "Kh0 Ks1 9c3/3h0 As0 Ad1 2h2 Kc4/6d0 7c0 5d2 9d3 Qc4",
            "win": -24,
            "playerId": "pid899265"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 16:34:09",
    "roomId": "21183662"
}


{
    "stakes": 2,
    "handData": {"21183662-7": [
        {
            "inFantasy": false,
            "result": 13,
            "playerName": "pid131192",
            "orderIndex": 0,
            "hero": false,
            "dead": "2c1 7c2 3h3 9s4",
            "rows": "Qd0 Qc3 Jc4/Ah0 Ac0 4h2 8c3 Js4/6c0 8s0 3c1 3s1 3d2",
            "win": 24.7,
            "playerId": "pid131192"
        },
        {
            "inFantasy": false,
            "result": -13,
            "playerName": "pid899265",
            "orderIndex": 1,
            "hero": true,
            "dead": "4c1 8h2 4d3 4s4",
            "rows": "As0 Ad1 2s3/5s0 6d0 7d0 7h2 6h3/9h0 Tc1 Kc2 7s4 8d4",
            "win": -26,
            "playerId": "pid899265"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 16:35:14",
    "roomId": "21183662"
}


{
    "stakes": 2,
    "handData": {"21183662-8": [
        {
            "inFantasy": true,
            "result": 26,
            "playerName": "pid131192",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jd0",
            "rows": "Kd0 Kc0 Ac0/4s0 7s0 9s0 Ts0 Js0/2h0 4h0 8h0 Jh0 Kh0",
            "win": 49.4,
            "playerId": "pid131192"
        },
        {
            "inFantasy": false,
            "result": -26,
            "playerName": "pid899265",
            "orderIndex": 0,
            "hero": true,
            "dead": "5c1 7h2 Tc3 3s4",
            "rows": "Ks0 Qc3 Ah4/3c0 6h0 6c2 6s2 7c3/4d0 7d0 8d1 Td1 Th4",
            "win": -52,
            "playerId": "pid899265"
        }
    ]},
    "appName": "Upoker",
    "price": "1.6AUD",
    "joined": true,
    "clubId": "102080",
    "rules": "progressive16_refant14_nojokers",
    "endDateTime": "2022-04-14 16:36:07",
    "roomId": "21183662"
}


