{
    "stakes": 1,
    "handData": {"21176421-1": [
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid920703",
            "orderIndex": 0,
            "hero": false,
            "dead": "4h1 4c2 Ad3 3d4",
            "rows": "Ks0 Ac1 Kd2/2c0 2d1 Qc3 Jd4 Kh4/7d0 9s0 Td0 Tc2 Ts3",
            "win": -10,
            "playerId": "pid920703"
        },
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid711257",
            "orderIndex": 1,
            "hero": true,
            "dead": "8c1 5d2 8d3 2s4",
            "rows": "7c2 Qd3 9d4/4s0 6d0 Jc0 Jh3 6c4/2h0 7h0 Qh1 Ah1 5h2",
            "win": 9.7,
            "playerId": "pid711257"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 07:58:30",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-2": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "pid920703",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qc1 2d2 Qh3 5d4",
            "rows": "Ah0 As0 Kh1/4c2 5h2 3s3 4d3 5s4/8c0 8s0 Jh0 Js1 Ac4",
            "win": 14.55,
            "playerId": "pid920703"
        },
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid711257",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jd1 4s2 7c3 8d4",
            "rows": "Ks0 Kc2 4h3/2s0 3c0 5c0 9h4 Jc4/Th0 6c1 6s1 9s2 Td3",
            "win": -15,
            "playerId": "pid711257"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 07:59:23",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-3": [
        {
            "inFantasy": true,
            "result": 23,
            "playerName": "pid920703",
            "orderIndex": 0,
            "hero": false,
            "dead": "Ts0 9c1 3c2",
            "rows": "Qc0 Ad0 Ac0/3s0 4c0 5d0 6s0 7d0/4h0 7h0 8h0 Th0 Kh0",
            "win": 22.31,
            "playerId": "pid920703"
        },
        {
            "inFantasy": false,
            "result": -23,
            "playerName": "pid711257",
            "orderIndex": 1,
            "hero": true,
            "dead": "7c1 4d2 7s3 2s4",
            "rows": "Ah0 3h2 5s3/2c0 6h0 8d1 6d2 Qh3/Jc0 Qd0 Ks1 5h4 Kd4",
            "win": -23,
            "playerId": "pid711257"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:00:06",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-4": [
        {
            "inFantasy": false,
            "result": 17,
            "playerName": "pid920703",
            "orderIndex": 1,
            "hero": false,
            "dead": "7c1 9h2 5s3 4c4",
            "rows": "Ad0 8h4 Ac4/2s0 2h1 5c1 Jd2 Js3/6c0 6s0 Td0 6h2 Tc3",
            "win": 16.49,
            "playerId": "pid920703"
        },
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid711257",
            "orderIndex": 0,
            "hero": true,
            "dead": "2c1 5h2 4s3 Th4",
            "rows": "Qh1 As3 Kd4/7s0 Ts0 7h1 3c2 9c3/2d0 7d0 Qd0 9d2 6d4",
            "win": -17,
            "playerId": "pid711257"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:00:56",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-5": [
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "pid920703",
            "orderIndex": 0,
            "hero": false,
            "dead": "8d0 5s1 2h2",
            "rows": "9d0 Qd0 Qs0/7d0 8s0 9h0 Tc0 Jc0/2c0 4c0 6c0 7c0 Kc0",
            "win": 20.37,
            "playerId": "pid920703"
        },
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "pid711257",
            "orderIndex": 1,
            "hero": true,
            "dead": "9s1 9c2 5c3 8h4",
            "rows": "Ah0 As0 Ac4/2d0 3c0 3d1 Jh2 Ts4/6d0 6s1 Kh2 6h3 Ks3",
            "win": -21,
            "playerId": "pid711257"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:01:32",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-6": [
        {
            "inFantasy": false,
            "result": 8,
            "playerName": "pid920703",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qc1 9h2 Th3 8c4",
            "rows": "Ac1 Kh3 Jc4/5c0 6d0 4h2 5h3 4s4/8s0 Ts0 Qd0 Jd1 9s2",
            "win": 7.76,
            "playerId": "pid920703"
        },
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid711257",
            "orderIndex": 0,
            "hero": true,
            "dead": "9c1 9d2 8h3 2h4",
            "rows": "Ah2 Tc3 Kd4/3d0 4d0 2c1 6c1 2d3/7s0 Qs0 As0 Js2 Jh4",
            "win": -8,
            "playerId": "pid711257"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:02:14",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-7": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid920703",
            "orderIndex": 0,
            "hero": false,
            "dead": "7h1 8h2 5c3 5h4",
            "rows": "6h3 Qd3 Kh4/4c0 6c0 6s1 9s1 9c2/3d0 3c0 Td0 Ts2 7d4",
            "win": -12,
            "playerId": "pid920703"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid711257",
            "orderIndex": 1,
            "hero": true,
            "dead": "2s1 5d2 4d3 Tc4",
            "rows": "Ad0 5s3 Qc4/8c0 Jc0 Qs1 8s3 8d4/3h0 4h0 Ah1 9h2 Th2",
            "win": 11.64,
            "playerId": "pid711257"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:03:13",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-8": [
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid920703",
            "orderIndex": 2,
            "hero": false,
            "dead": "7d1 Tc2 3s3 Qh4",
            "rows": "2s0 Ah1 Ad2/5c0 7h0 Js2 6s4 Th4/9c0 9s0 9d1 6c3 8c3",
            "win": 0,
            "playerId": "pid920703"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid711257",
            "orderIndex": 0,
            "hero": true,
            "dead": "7s1 Jc2 3d3 2c4",
            "rows": "4h3 5h3 Qd4/4s0 8s0 6h1 5d2 7c2/Td0 Kd0 Kc0 Ts1 4c4",
            "win": 0,
            "playerId": "pid711257"
        },
        {
            "inFantasy": false,
            "result": 0,
            "playerName": "pid907066",
            "orderIndex": 1,
            "hero": false,
            "dead": "8d1 9h2 5s3 6d4",
            "rows": "Kh0 As1 Ac2/3c0 Jd1 4d2 Jh4 Ks4/2h0 2d0 Qs0 8h3 Qc3",
            "win": 0,
            "playerId": "pid907066"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:05:10",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-9": [
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid711257",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jc1 9s2 8s3 Ts4",
            "rows": "Ah0 9c2 Jd4/2h1 6s1 2s2 Qd3 Ac4/3d0 9d0 Kd0 Ad0 8d3",
            "win": 5.82,
            "playerId": "pid711257"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid907066",
            "orderIndex": 0,
            "hero": false,
            "dead": "4s1 Ks2 Kh3 Qs4",
            "rows": "4d3 7d3 5c4/7h0 Th0 9h1 8c2 3s4/4c0 Qc0 Kc0 7c1 6c2",
            "win": -6,
            "playerId": "pid907066"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:06:28",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-10": [
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid711257",
            "orderIndex": 0,
            "hero": true,
            "dead": "8h1 Jh2 6h3 7s4",
            "rows": "Ah0 Ad2 Tc4/4c0 8d1 7d2 4h3 8c4/5d0 5s0 Ks0 Kd1 5h3",
            "win": 9.7,
            "playerId": "pid711257"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid907066",
            "orderIndex": 1,
            "hero": false,
            "dead": "5c1 Td2 Qd3 3d4",
            "rows": "Ts1 8s2 Kc4/4s0 7c0 Jc1 4d3 3s4/2d0 9d0 9s0 2c2 9h3",
            "win": -10,
            "playerId": "pid907066"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:07:53",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-11": [
        {
            "inFantasy": true,
            "result": 18,
            "playerName": "pid711257",
            "orderIndex": 1,
            "hero": true,
            "dead": "7s0 4d0 2h0",
            "rows": "Qd0 Kd0 Ks0/5h0 6c0 7d0 8h0 9s0/4c0 7c0 Tc0 Qc0 Ac0",
            "win": 17.46,
            "playerId": "pid711257"
        },
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid907066",
            "orderIndex": 0,
            "hero": false,
            "dead": "8c1 9d2 2s3 4s4",
            "rows": "Ad2 Ts3 8d4/2c0 5c0 5d1 6d2 5s3/8s0 9h0 Td0 Jh1 7h4",
            "win": -18,
            "playerId": "pid907066"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:08:36",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-12": [
        {
            "inFantasy": false,
            "result": -9,
            "playerName": "pid711257",
            "orderIndex": 0,
            "hero": true,
            "dead": "5d1 5s2 6s3 Jc4",
            "rows": "Ks2 Ts3 Kc4/7s0 5c1 7d2 8d3 8s4/3h0 5h0 6h0 8h0 9h1",
            "win": -9,
            "playerId": "pid711257"
        },
        {
            "inFantasy": false,
            "result": 9,
            "playerName": "pid907066",
            "orderIndex": 1,
            "hero": false,
            "dead": "8c1 Kd2 As3 3s4",
            "rows": "Ah0 Ac0 Jd4/4h1 4s2 9c3 Qd3 4c4/2d0 6d0 Td0 3d1 Ad2",
            "win": 8.73,
            "playerId": "pid907066"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:09:59",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-13": [
        {
            "inFantasy": true,
            "result": -10,
            "playerName": "pid711257",
            "orderIndex": 1,
            "hero": true,
            "dead": "3c0 2s0",
            "rows": "Qh0 Qs0 Kd0/7d0 9d0 9s0 Jh0 Js0/3d0 4h0 5s0 6h0 7c0",
            "win": -10,
            "playerId": "pid711257"
        },
        {
            "inFantasy": true,
            "result": 10,
            "playerName": "pid907066",
            "orderIndex": 0,
            "hero": false,
            "dead": "8d0 5c1 4s2",
            "rows": "Qd0 Qc0 Ks0/5h0 6c0 7h0 8c0 9c0/2h0 2d0 2c0 3h0 3s0",
            "win": 9.7,
            "playerId": "pid907066"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:10:47",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-14": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid711257",
            "orderIndex": 0,
            "hero": true,
            "dead": "6d1 4s2 8d3 2c4",
            "rows": "Kh0 9c4 Jd4/As0 2d1 5s1 3h2 4c3/8s0 9h0 Td0 7d2 6h3",
            "win": 11.64,
            "playerId": "pid711257"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid907066",
            "orderIndex": 1,
            "hero": false,
            "dead": "5d1 Ks2 Ad3 5c4",
            "rows": "Ac0 Kd3 Ah3/3d0 7s0 7c1 6c2 6s2/Ts0 Jc0 8h1 Tc4 Qd4",
            "win": -12,
            "playerId": "pid907066"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:12:08",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-15": [
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid711257",
            "orderIndex": 1,
            "hero": true,
            "dead": "6s1 Qd2 2c3 2s4",
            "rows": "Ad0 As0 3s3/7h0 7c0 4h1 9h2 8d4/Th0 Ks1 Kh2 Td3 7d4",
            "win": -14,
            "playerId": "pid711257"
        },
        {
            "inFantasy": false,
            "result": 14,
            "playerName": "pid907066",
            "orderIndex": 0,
            "hero": false,
            "dead": "4s1 Ts2 6h3 7s4",
            "rows": "Kd0 Kc2 Jd4/3d0 5h0 5d1 Js2 3h3/8h0 8c0 6d1 8s3 9s4",
            "win": 13.58,
            "playerId": "pid907066"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:13:34",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-16": [
        {
            "inFantasy": false,
            "result": -23,
            "playerName": "pid711257",
            "orderIndex": 0,
            "hero": true,
            "dead": "3c1 Qs2 Qh3 4h4",
            "rows": "Kd0 Kc2 Td3/2s0 6c0 4s1 3d2 Qd4/7d0 Th0 9d1 8c3 7s4",
            "win": -23,
            "playerId": "pid711257"
        },
        {
            "inFantasy": true,
            "result": 23,
            "playerName": "pid907066",
            "orderIndex": 1,
            "hero": false,
            "dead": "9s0 4d1",
            "rows": "Jc0 Ah0 As0/2d0 3h0 4c0 5h0 6s0/2h0 6h0 7h0 9h0 Kh0",
            "win": 22.31,
            "playerId": "pid907066"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:14:20",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-17": [
        {
            "inFantasy": false,
            "result": -5,
            "playerName": "pid711257",
            "orderIndex": 1,
            "hero": true,
            "dead": "5s1 4s2 9c3 3d4",
            "rows": "Qd1 Ah2 As4/8c0 2h2 2s3 8s3 5h4/9h0 9d0 Th0 Ts0 Tc1",
            "win": -5,
            "playerId": "pid711257"
        },
        {
            "inFantasy": false,
            "result": 5,
            "playerName": "pid907066",
            "orderIndex": 0,
            "hero": false,
            "dead": "3c1 Js2 6s3 2d4",
            "rows": "Ac0 Ad1 8d4/3s0 4d0 3h2 Kc3 Kh4/7h0 7s0 7c1 7d2 9s3",
            "win": 4.85,
            "playerId": "pid907066"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:15:44",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-18": [
        {
            "inFantasy": true,
            "result": -31,
            "playerName": "pid711257",
            "orderIndex": 0,
            "hero": true,
            "dead": "Th0 8d0 5s0",
            "rows": "3h0 3c0 3s0/Qh0 Qd0 Qs0 Kd0 Ac0/7s0 8h0 9d0 Tc0 Js0",
            "win": -31,
            "playerId": "pid711257"
        },
        {
            "inFantasy": true,
            "result": 31,
            "playerName": "pid907066",
            "orderIndex": 1,
            "hero": false,
            "dead": "Kh0 Td1 9h2",
            "rows": "Ah0 Ad0 As0/2h0 2c0 2s0 6h0 6c0/4h0 4d0 4s0 8c0 8s0",
            "win": 30.07,
            "playerId": "pid907066"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:16:31",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-19": [
        {
            "inFantasy": true,
            "result": -5,
            "playerName": "pid711257",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jh0 6c0 4s0",
            "rows": "Qd0 Kh0 Kd0/7h0 7c0 8h0 8c0 8s0/9h0 9c0 Ah0 Ad0 As0",
            "win": -5,
            "playerId": "pid711257"
        },
        {
            "inFantasy": true,
            "result": 5,
            "playerName": "pid907066",
            "orderIndex": 0,
            "hero": false,
            "dead": "Qh0 5h1 2d2",
            "rows": "Th0 Td0 Tc0/2s0 3s0 5s0 7s0 Ks0/3h0 3d0 3c0 6h0 6d0",
            "win": 4.85,
            "playerId": "pid907066"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:17:14",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-20": [
        {
            "inFantasy": false,
            "result": -23,
            "playerName": "pid711257",
            "orderIndex": 0,
            "hero": true,
            "dead": "6c1 2d2 Td3 7h4",
            "rows": "Qd3 Ac3 Tc4/4d0 6h0 4h1 7c2 7d4/2s0 9s0 Ks0 Ts1 Js2",
            "win": -23,
            "playerId": "pid711257"
        },
        {
            "inFantasy": true,
            "result": 23,
            "playerName": "pid907066",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qh0 9c1 4s2",
            "rows": "8h0 8d0 Kd0/3d0 3c0 5h0 5d0 5s0/6d0 6s0 Ah0 Ad0 As0",
            "win": 22.31,
            "playerId": "pid907066"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:18:00",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-21": [
        {
            "inFantasy": false,
            "result": 2,
            "playerName": "pid711257",
            "orderIndex": 1,
            "hero": true,
            "dead": "8c1 8h2 Qh3 3d4",
            "rows": "Ac0 8s2 Qc3/3s0 5h0 6s1 6h3 6d4/7d0 7c0 4d1 7s2 7h4",
            "win": 1.94,
            "playerId": "pid711257"
        },
        {
            "inFantasy": false,
            "result": -2,
            "playerName": "pid907066",
            "orderIndex": 0,
            "hero": false,
            "dead": "Tc1 Kh2 4h3 5c4",
            "rows": "Qs0 Ah2 Ad4/2c0 2s0 9h1 Kd3 2h4/5d0 Jd0 Js1 Jc2 3h3",
            "win": -2,
            "playerId": "pid907066"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:19:24",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-22": [
        {
            "inFantasy": false,
            "result": -35,
            "playerName": "pid711257",
            "orderIndex": 0,
            "hero": true,
            "dead": "9h1 Tc2 5h3 3c4",
            "rows": "Ac0 Ah1 Qc3/4c0 4h1 Jh2 2d3 Qh4/5d0 6d0 8d0 7h2 8c4",
            "win": -35,
            "playerId": "pid711257"
        },
        {
            "inFantasy": true,
            "result": 35,
            "playerName": "pid907066",
            "orderIndex": 1,
            "hero": false,
            "dead": "3s0 2s1 2c2",
            "rows": "Kh0 Kc0 Ks0/7c0 8h0 9c0 Th0 Jd0/6s0 8s0 9s0 Ts0 As0",
            "win": 33.95,
            "playerId": "pid907066"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:20:08",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-23": [
        {
            "inFantasy": false,
            "result": -18,
            "playerName": "pid711257",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qh1 Qs2 7h3 2c4",
            "rows": "Ad1 Ah2 6c3/3d0 9d0 8c1 6h4 9h4/Td0 Tc0 Js0 Ts2 As3",
            "win": -18,
            "playerId": "pid711257"
        },
        {
            "inFantasy": true,
            "result": 18,
            "playerName": "pid907066",
            "orderIndex": 0,
            "hero": false,
            "dead": "7c0 2h1 2d2",
            "rows": "Jh0 Jd0 Ac0/4h0 4s0 8d0 8s0 Kh0/3c0 3s0 5h0 5d0 5s0",
            "win": 17.46,
            "playerId": "pid907066"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:20:57",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-24": [
        {
            "inFantasy": false,
            "result": -3,
            "playerName": "pid711257",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ah1 8d2 Td3 2c4",
            "rows": "7s3 3s4 6d4/9h1 9s1 Th2 Ts2 4c3/2d0 3d0 4s0 5c0 6h0",
            "win": -3,
            "playerId": "pid711257"
        },
        {
            "inFantasy": false,
            "result": 3,
            "playerName": "pid907066",
            "orderIndex": 1,
            "hero": false,
            "dead": "5d1 Ks2 3h3 6c4",
            "rows": "Qs1 8s3 Ac4/6s0 Jd0 7d1 Jh2 4d3/3c0 8c0 Qc0 Jc2 9c4",
            "win": 2.91,
            "playerId": "pid907066"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:22:17",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-25": [
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid711257",
            "orderIndex": 1,
            "hero": true,
            "dead": "6c1 2c2 Kh3 3d4",
            "rows": "Kc0 5c1 9c2/3h0 Th0 7h2 Tc3 3s4/9s0 Qs0 2s1 5s3 8s4",
            "win": 9.7,
            "playerId": "pid711257"
        },
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid907066",
            "orderIndex": 0,
            "hero": false,
            "dead": "Ks1 9h2 8h3 4s4",
            "rows": "Ac1 Jh3 As4/3c0 7c0 4d2 6d3 Ah4/2d0 5d0 9d0 Kd1 Qd2",
            "win": -10,
            "playerId": "pid907066"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:23:35",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-26": [
        {
            "inFantasy": false,
            "result": 14,
            "playerName": "pid711257",
            "orderIndex": 0,
            "hero": true,
            "dead": "7c1 Ac2 4d3 5c4",
            "rows": "Qs0 7s4 Jd4/4h0 5h2 9h2 7h3 Ah3/9d0 Kd0 Ad0 2d1 6d1",
            "win": 13.58,
            "playerId": "pid711257"
        },
        {
            "inFantasy": false,
            "result": -14,
            "playerName": "pid907066",
            "orderIndex": 1,
            "hero": false,
            "dead": "8d1 9s2 7d3 4s4",
            "rows": "Qd0 6h2 Jh4/Td0 Js0 3d1 3s1 8s4/6c0 8c0 Jc2 3c3 9c3",
            "win": -14,
            "playerId": "pid907066"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:24:51",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-27": [
        {
            "inFantasy": false,
            "result": -1,
            "playerName": "pid711257",
            "orderIndex": 1,
            "hero": true,
            "dead": "Th1 4h2 7d3 6h4",
            "rows": "Qc0 Ad1 6s4/3h0 4c0 9d2 9s2 4d3/2h0 2c0 Js1 2d3 Jd4",
            "win": -1,
            "playerId": "pid711257"
        },
        {
            "inFantasy": false,
            "result": 1,
            "playerName": "pid907066",
            "orderIndex": 0,
            "hero": false,
            "dead": "2s1 Kc2 Ah3 5s4",
            "rows": "Ks0 9h1 Kh2/9c0 As0 Ac2 6d3 8s4/5h0 8h0 8c1 Tc3 8d4",
            "win": 1,
            "playerId": "pid907066"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:26:13",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-28": [
        {
            "inFantasy": false,
            "result": -11,
            "playerName": "pid711257",
            "orderIndex": 0,
            "hero": true,
            "dead": "2d1 Th2 Kc3 Td4",
            "rows": "Ts1 2c3 Jc4/6c0 7c0 4d1 5h2 6h3/3d0 Qh0 Qd0 Qs2 3c4",
            "win": -11,
            "playerId": "pid711257"
        },
        {
            "inFantasy": true,
            "result": 11,
            "playerName": "pid907066",
            "orderIndex": 1,
            "hero": false,
            "dead": "5c0 4c1",
            "rows": "8h0 Kd0 Ks0/7h0 8d0 9d0 Tc0 Jd0/3s0 5s0 6s0 9s0 As0",
            "win": 10.67,
            "playerId": "pid907066"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:26:56",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-29": [
        {
            "inFantasy": false,
            "result": -10,
            "playerName": "pid711257",
            "orderIndex": 1,
            "hero": true,
            "dead": "3h1 5d2 Kd3 2s4",
            "rows": "Kc0 As2 Kh3/4h0 8c0 4c2 9c4 Ac4/Th0 Td0 Ts1 Qs1 Qd3",
            "win": -10,
            "playerId": "pid711257"
        },
        {
            "inFantasy": false,
            "result": 10,
            "playerName": "pid907066",
            "orderIndex": 0,
            "hero": false,
            "dead": "8h1 Qc2 3c3 4d4",
            "rows": "Ks0 6c3 Jd4/9h0 7c1 9s1 5c3 7s4/3d0 7d0 Ad0 2d2 6d2",
            "win": 9.7,
            "playerId": "pid907066"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:28:19",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-30": [
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid711257",
            "orderIndex": 0,
            "hero": true,
            "dead": "8h1 Jd2 5d3 2d4",
            "rows": "Kd0 4s2 8s4/5c0 Th0 9d1 3s2 Td4/6s0 7s0 6h1 7h3 7d3",
            "win": 11.64,
            "playerId": "pid711257"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid907066",
            "orderIndex": 1,
            "hero": false,
            "dead": "3d1 4d2 9c3 9s4",
            "rows": "Ac0 Ad1 Kc4/2c0 2s0 Qc2 5s3 Ts4/Qh0 Kh0 Ah1 3h2 Jh3",
            "win": -12,
            "playerId": "pid907066"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:29:45",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-31": [
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid711257",
            "orderIndex": 1,
            "hero": true,
            "dead": "4d1 Qs2 6d3 3s4",
            "rows": "As2 8d3 Ah3/Th0 7h1 7d1 5s2 Ts4/6c0 7c0 Qc0 Kc0 5h4",
            "win": -6,
            "playerId": "pid711257"
        },
        {
            "inFantasy": false,
            "result": 6,
            "playerName": "pid907066",
            "orderIndex": 0,
            "hero": false,
            "dead": "8s1 7s2 3c3 2s4",
            "rows": "Ac0 Qd2 Jh4/4c0 4s0 6h0 5c2 6s3/9s0 2h1 2d1 Jc3 9c4",
            "win": 5.82,
            "playerId": "pid907066"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:31:05",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-32": [
        {
            "inFantasy": false,
            "result": -13,
            "playerName": "pid711257",
            "orderIndex": 0,
            "hero": true,
            "dead": "Tc1 8c2 Qs3 3h4",
            "rows": "As0 5d3 Ac3/3d0 6c0 6s1 2c2 Ad4/8h0 Kh0 Jh1 Qh2 5c4",
            "win": -13,
            "playerId": "pid711257"
        },
        {
            "inFantasy": false,
            "result": 13,
            "playerName": "pid907066",
            "orderIndex": 1,
            "hero": false,
            "dead": "7c1 6h2 2h3 2s4",
            "rows": "Ks0 Qd2 Qc3/7h0 9d0 7d1 9h1 Ts4/Jd0 Jc0 3s2 Th3 Td4",
            "win": 12.61,
            "playerId": "pid907066"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:32:22",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-33": [
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid711257",
            "orderIndex": 1,
            "hero": true,
            "dead": "7h1 Jh2 6h3 2d4",
            "rows": "Ac0 8c3 Qs4/3c0 4s1 5h1 3s2 4h4/Td0 Tc0 Ts0 9d2 2s3",
            "win": -17,
            "playerId": "pid711257"
        },
        {
            "inFantasy": true,
            "result": 17,
            "playerName": "pid907066",
            "orderIndex": 0,
            "hero": false,
            "dead": "3h0",
            "rows": "6c0 6s0 Js0/9s0 Th0 Jd0 Qh0 Kd0/5d0 5c0 Ah0 Ad0 As0",
            "win": 16.49,
            "playerId": "pid907066"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:33:05",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-34": [
        {
            "inFantasy": false,
            "result": 20,
            "playerName": "pid711257",
            "orderIndex": 0,
            "hero": true,
            "dead": "Td1 2h2 Ah3 3h4",
            "rows": "Kh0 Kc2 2s3/4h0 4s0 8d1 7h3 8c4/5h0 5c0 Jd1 Jc2 Js4",
            "win": 19.4,
            "playerId": "pid711257"
        },
        {
            "inFantasy": false,
            "result": -20,
            "playerName": "pid907066",
            "orderIndex": 1,
            "hero": false,
            "dead": "6s1 4c2 3s3 6d4",
            "rows": "Ad0 Ac0 5d2/9c0 9s0 2d1 9d3 Ks3/Qh0 Th1 Ts2 7c4 Kd4",
            "win": -20,
            "playerId": "pid907066"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:34:25",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-35": [
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "pid711257",
            "orderIndex": 1,
            "hero": true,
            "dead": "3s0 3c0",
            "rows": "Th0 Td0 Ad0/4d0 4s0 6h0 6c0 Qh0/5h0 7h0 7d0 7c0 7s0",
            "win": 20.37,
            "playerId": "pid711257"
        },
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "pid907066",
            "orderIndex": 0,
            "hero": false,
            "dead": "2d1 Qd2 5d3 6s4",
            "rows": "Ah1 Ac1 9c3/2h0 3h0 4c0 2s3 Kh4/8s0 Ts0 Kd2 Kc2 Jd4",
            "win": -21,
            "playerId": "pid907066"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:35:10",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-36": [
        {
            "inFantasy": true,
            "result": 28,
            "playerName": "pid711257",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ad0 9h0",
            "rows": "2h0 2d0 2c0/3c0 4c0 6c0 Jc0 Qc0/3s0 4s0 6s0 Ks0 As0",
            "win": 27.16,
            "playerId": "pid711257"
        },
        {
            "inFantasy": false,
            "result": -28,
            "playerName": "pid907066",
            "orderIndex": 1,
            "hero": false,
            "dead": "7h1 6h2 7d3 6d4",
            "rows": "Kh1 Jd2 Qs4/3h0 4h0 5c0 4d1 3d3/8c0 Td0 8s2 Tc3 9s4",
            "win": -28,
            "playerId": "pid907066"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:35:56",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-37": [
        {
            "inFantasy": true,
            "result": 21,
            "playerName": "pid711257",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qh0 5c0",
            "rows": "Ks0 Ac0 As0/3d0 4d0 8d0 9d0 Td0/2h0 2s0 4h0 4c0 4s0",
            "win": 20.37,
            "playerId": "pid711257"
        },
        {
            "inFantasy": false,
            "result": -21,
            "playerName": "pid907066",
            "orderIndex": 0,
            "hero": false,
            "dead": "9s1 5s2 8c3 2c4",
            "rows": "Kd2 9c3 Kh3/6c0 7d0 6s1 7s2 5d4/3h0 Th0 Tc0 3c1 6d4",
            "win": -21,
            "playerId": "pid907066"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:36:42",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-38": [
        {
            "inFantasy": false,
            "result": -2,
            "playerName": "pid711257",
            "orderIndex": 0,
            "hero": true,
            "dead": "Kh1 9c2 Ts3 Th4",
            "rows": "Ac0 Qs2 As3/5d0 7h0 8c2 8d3 7s4/6h0 6c0 6d1 Jc1 Qh4",
            "win": -2,
            "playerId": "pid711257"
        },
        {
            "inFantasy": true,
            "result": 2,
            "playerName": "pid907066",
            "orderIndex": 1,
            "hero": false,
            "dead": "8h0 2h1",
            "rows": "4d0 4c0 Ah0/Td0 Jd0 Qc0 Ks0 Ad0/3h0 3c0 5h0 5c0 5s0",
            "win": 1.94,
            "playerId": "pid907066"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:37:27",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-39": [
        {
            "inFantasy": true,
            "result": 26,
            "playerName": "pid711257",
            "orderIndex": 1,
            "hero": true,
            "dead": "9h0 4d0 3c0",
            "rows": "7d0 7s0 Js0/2h0 2s0 8h0 8c0 8s0/6d0 6s0 Th0 Td0 Ts0",
            "win": 25.22,
            "playerId": "pid711257"
        },
        {
            "inFantasy": false,
            "result": -26,
            "playerName": "pid907066",
            "orderIndex": 0,
            "hero": false,
            "dead": "2d1 Tc2 5s3 3d4",
            "rows": "9c3 Ad3 9s4/4s0 5d0 5c0 3s1 4c2/7c0 8d0 Jd1 Jh2 9d4",
            "win": -26,
            "playerId": "pid907066"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:38:14",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-40": [
        {
            "inFantasy": false,
            "result": 2,
            "playerName": "pid711257",
            "orderIndex": 0,
            "hero": true,
            "dead": "3s1 7c2 4d3 7s4",
            "rows": "Qd0 As3 Qh4/6s0 9c0 9s1 2d2 6h3/5h0 8h0 8d1 8c2 Jd4",
            "win": 1.94,
            "playerId": "pid711257"
        },
        {
            "inFantasy": false,
            "result": -2,
            "playerName": "pid907066",
            "orderIndex": 1,
            "hero": false,
            "dead": "4h1 2h2 3h3 Tc4",
            "rows": "Qc1 Ts3 5c4/9d0 7d1 Js2 Ad3 Th4/5d0 5s0 Kh0 Kd0 Kc2",
            "win": -2,
            "playerId": "pid907066"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:39:31",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-41": [
        {
            "inFantasy": true,
            "result": 29,
            "playerName": "pid711257",
            "orderIndex": 1,
            "hero": true,
            "dead": "7h0",
            "rows": "2d0 2s0 8d0/5c0 6c0 8c0 Tc0 Jc0/2h0 3h0 4h0 5h0 Ah0",
            "win": 28.13,
            "playerId": "pid711257"
        },
        {
            "inFantasy": false,
            "result": -29,
            "playerName": "pid907066",
            "orderIndex": 0,
            "hero": false,
            "dead": "3d1 4d2 7d3 6h4",
            "rows": "Ac0 Kd1 3c2/8h0 9h0 Qh2 8s4 Ad4/Js0 Ks0 Ts1 Td3 Kh3",
            "win": -29,
            "playerId": "pid907066"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:40:16",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-42": [
        {
            "inFantasy": true,
            "result": 6,
            "playerName": "pid711257",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jd0",
            "rows": "Qd0 Ah0 Ad0/2d0 3c0 4c0 5c0 As0/9s0 Ts0 Jc0 Qh0 Kc0",
            "win": 5.82,
            "playerId": "pid711257"
        },
        {
            "inFantasy": false,
            "result": -6,
            "playerName": "pid907066",
            "orderIndex": 1,
            "hero": false,
            "dead": "Qs1 4h2 4s3 3h4",
            "rows": "Ks0 9d3 Qc4/4d0 7s0 5s1 8d1 6d2/2h0 Th0 9h2 6h3 7h4",
            "win": -6,
            "playerId": "pid907066"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:41:00",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-43": [
        {
            "inFantasy": false,
            "result": 24,
            "playerName": "pid160696",
            "orderIndex": 1,
            "hero": false,
            "dead": "4d1 6s2 Jd3 Kh4",
            "rows": "As0 4h3 4c4/9h0 9d1 2c2 7s2 5s4/5h0 5d0 Qc0 5c1 Qh3",
            "win": 23.28,
            "playerId": "pid160696"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid711257",
            "orderIndex": 2,
            "hero": true,
            "dead": "7d1 Qd2 Kd3 3s4",
            "rows": "Kc0 Ad2 9s4/6d0 8h0 6c1 Qs3 Ah4/2s0 Js0 Ts1 Jh2 Td3",
            "win": -12,
            "playerId": "pid711257"
        },
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid907066",
            "orderIndex": 0,
            "hero": false,
            "dead": "Tc1 Th2 3c3 7h4",
            "rows": "Ac2 9c3 Ks4/3d0 4s0 6h0 3h1 7c3/8s0 Jc0 8c1 2d2 8d4",
            "win": -12,
            "playerId": "pid907066"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:42:59",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-44": [
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid160696",
            "orderIndex": 0,
            "hero": false,
            "dead": "Th1 Js2 2s3 Jh4",
            "rows": "Qh1 Kh1 Ks3/4c0 8c0 Qc2 6s4 7c4/9d0 Td0 Kd0 7d2 6d3",
            "win": -8,
            "playerId": "pid160696"
        },
        {
            "inFantasy": false,
            "result": 16,
            "playerName": "pid711257",
            "orderIndex": 1,
            "hero": true,
            "dead": "6c1 2d2 Qd3 2c4",
            "rows": "As0 Kc3 4s4/5h0 7s0 6h2 5c3 3d4/9h0 Tc0 8s1 Qs1 Jc2",
            "win": 15.52,
            "playerId": "pid711257"
        },
        {
            "inFantasy": false,
            "result": -8,
            "playerName": "pid907066",
            "orderIndex": 2,
            "hero": false,
            "dead": "4d1 3c2 3h3 3s4",
            "rows": "Ad0 Ac1 7h4/2h0 8d0 9c2 9s2 8h3/5s0 Ts0 Jd1 5d3 4h4",
            "win": -8,
            "playerId": "pid907066"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:44:45",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-45": [
        {
            "inFantasy": false,
            "result": 42,
            "playerName": "pid160696",
            "orderIndex": 2,
            "hero": false,
            "dead": "3c1 8d2 Qs3 2s4",
            "rows": "Js3 Ah4 Ac4/9s0 Tc0 9c1 Th2 8c3/6h0 6c0 Qd0 6s1 Qc2",
            "win": 40.74,
            "playerId": "pid160696"
        },
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid711257",
            "orderIndex": 0,
            "hero": true,
            "dead": "Jh1 4c2 3s3 Jd4",
            "rows": "Ks0 8s3 Jc4/2d0 7s0 5d2 7c2 5c4/Td0 Ts0 9h1 9d1 8h3",
            "win": -15,
            "playerId": "pid711257"
        },
        {
            "inFantasy": false,
            "result": -27,
            "playerName": "pid907066",
            "orderIndex": 1,
            "hero": false,
            "dead": "Ad1 2h2 Kc3 2c4",
            "rows": "As0 Kd2 Kh3/3d0 5s0 7d0 5h2 7h3/Qh0 4d1 4s1 3h4 6d4",
            "win": -27,
            "playerId": "pid907066"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:46:39",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-46": [
        {
            "inFantasy": true,
            "result": 67,
            "playerName": "pid160696",
            "orderIndex": 1,
            "hero": false,
            "dead": "9d0 3c1 2c2",
            "rows": "Kh0 Kd0 Kc0/5c0 6c0 8c0 Tc0 Qc0/3h0 4h0 7h0 8h0 Ah0",
            "win": 65,
            "playerId": "pid160696"
        },
        {
            "inFantasy": false,
            "result": -56,
            "playerName": "pid711257",
            "orderIndex": 2,
            "hero": true,
            "dead": "As1 7s2 2d3 9h4",
            "rows": "Qs0 Qd2 Qh4/Jh0 Ks0 6d3 6s3 Ts4/4d0 5d0 3d1 Jd1 Td2",
            "win": -56,
            "playerId": "pid711257"
        },
        {
            "inFantasy": false,
            "result": -11,
            "playerName": "pid907066",
            "orderIndex": 0,
            "hero": false,
            "dead": "9c1 3s2 5h3 7d4",
            "rows": "Ac1 8s3 Ad4/4s0 6h0 2h2 2s2 4c3/8d0 Th0 Jc0 9s1 7c4",
            "win": -11,
            "playerId": "pid907066"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:47:53",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-47": [
        {
            "inFantasy": true,
            "result": -2,
            "playerName": "pid160696",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jh0 6d1 2c2",
            "rows": "Kh0 Kc0 Ac0/8d0 9h0 Tc0 Jd0 Qs0/3s0 4s0 8s0 9s0 Js0",
            "win": -2,
            "playerId": "pid160696"
        },
        {
            "inFantasy": false,
            "result": -13,
            "playerName": "pid711257",
            "orderIndex": 1,
            "hero": true,
            "dead": "3d1 7s2 Ks3 7c4",
            "rows": "Ad0 4h3 As3/9d0 Td1 7h2 9c4 Ts4/3c0 5c0 8c0 4c1 6c2",
            "win": -13,
            "playerId": "pid711257"
        },
        {
            "inFantasy": true,
            "result": 15,
            "playerName": "pid907066",
            "orderIndex": 2,
            "hero": false,
            "dead": "Jc0 7d1 6s2",
            "rows": "Qd0 Qc0 Kd0/6h0 8h0 Th0 Qh0 Ah0/2h0 2d0 2s0 5d0 5s0",
            "win": 14.55,
            "playerId": "pid907066"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:49:12",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-48": [
        {
            "inFantasy": false,
            "result": -42,
            "playerName": "pid160696",
            "orderIndex": 2,
            "hero": false,
            "dead": "Qc1 3c2 6s3 Qs4",
            "rows": "As1 4d2 4h3/5s0 6h0 6c0 9c2 5d4/8d0 Td0 8s1 Ts3 Qd4",
            "win": -42,
            "playerId": "pid160696"
        },
        {
            "inFantasy": true,
            "result": 64,
            "playerName": "pid711257",
            "orderIndex": 0,
            "hero": true,
            "dead": "Ac0 Jh0 5c0",
            "rows": "Kh0 Kd0 Kc0/8c0 9s0 Th0 Jc0 Qh0/3d0 7d0 9d0 Jd0 Ad0",
            "win": 62.08,
            "playerId": "pid711257"
        },
        {
            "inFantasy": false,
            "result": -22,
            "playerName": "pid907066",
            "orderIndex": 1,
            "hero": false,
            "dead": "6d1 2d2 3s3 Ks4",
            "rows": "Tc1 2c4 2s4/7s0 Js0 4s2 7c2 7h3/5h0 8h0 Ah0 3h1 2h3",
            "win": -22,
            "playerId": "pid907066"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:50:22",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-49": [
        {
            "inFantasy": false,
            "result": -46,
            "playerName": "pid160696",
            "orderIndex": 1,
            "hero": false,
            "dead": "9h1 4h2 Ad3 6c4",
            "rows": "Ah0 Kd1 Kh2/3d0 8h0 5h2 6h4 7d4/Tc0 Jc0 Td1 Th3 Ts3",
            "win": -46,
            "playerId": "pid160696"
        },
        {
            "inFantasy": true,
            "result": 47,
            "playerName": "pid711257",
            "orderIndex": 2,
            "hero": true,
            "dead": "Kc0 7c0 2h0",
            "rows": "3h0 3c0 3s0/2d0 5d0 8d0 9d0 Jd0/2s0 5s0 8s0 9s0 Ks0",
            "win": 45.59,
            "playerId": "pid711257"
        },
        {
            "inFantasy": false,
            "result": -1,
            "playerName": "pid907066",
            "orderIndex": 0,
            "hero": false,
            "dead": "2c1 6d2 Qd3 9c4",
            "rows": "Ac2 As3 Jh4/Qh0 4c1 4s1 7h2 Qs3/4d0 5c0 6s0 7s0 8c4",
            "win": -1,
            "playerId": "pid907066"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:51:37",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-50": [
        {
            "inFantasy": false,
            "result": -44,
            "playerName": "pid160696",
            "orderIndex": 0,
            "hero": false,
            "dead": "Kc1 6h2 Jc3 Js4",
            "rows": "Kh0 Kd0 Qd2/3h0 2c1 As2 2d3 6s4/7h0 7s0 5h1 7d3 5s4",
            "win": -44,
            "playerId": "pid160696"
        },
        {
            "inFantasy": true,
            "result": 7,
            "playerName": "pid711257",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jd0 6d0 2h0",
            "rows": "Th0 Tc0 Ah0/4h0 5d0 6c0 7c0 8d0/2s0 4s0 9s0 Qs0 Ks0",
            "win": 6.79,
            "playerId": "pid711257"
        },
        {
            "inFantasy": true,
            "result": 37,
            "playerName": "pid907066",
            "orderIndex": 2,
            "hero": false,
            "dead": "Ad0 Td1 4d2",
            "rows": "3d0 3c0 3s0/8h0 9d0 Ts0 Jh0 Qh0/4c0 5c0 8c0 9c0 Ac0",
            "win": 35.89,
            "playerId": "pid907066"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:52:35",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-51": [
        {
            "inFantasy": false,
            "result": -63,
            "playerName": "pid160696",
            "orderIndex": 2,
            "hero": false,
            "dead": "4s1 8d2 9s3 2d4",
            "rows": "Ts3 4d4 6c4/7c0 8c0 9d1 Jd2 Tc3/2h0 3h0 Th0 Ah1 Kc2",
            "win": -63,
            "playerId": "pid160696"
        },
        {
            "inFantasy": false,
            "result": 20,
            "playerName": "pid711257",
            "orderIndex": 0,
            "hero": true,
            "dead": "Td1 Js2 6d3 2c4",
            "rows": "Kh1 8s3 4c4/3c0 5s0 5d2 5c3 3s4/7d0 Qh0 Qd0 Qs1 Qc2",
            "win": 19.4,
            "playerId": "pid711257"
        },
        {
            "inFantasy": true,
            "result": 43,
            "playerName": "pid907066",
            "orderIndex": 1,
            "hero": false,
            "dead": "Kd0 4h1 3d2",
            "rows": "Jh0 Jc0 Ad0/2s0 6s0 7s0 Ks0 As0/5h0 6h0 7h0 8h0 9h0",
            "win": 41.71,
            "playerId": "pid907066"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:54:01",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-52": [
        {
            "inFantasy": false,
            "result": -46,
            "playerName": "pid160696",
            "orderIndex": 1,
            "hero": false,
            "dead": "Ts1 6d2 2s3 As4",
            "rows": "Kd1 7s3 Qd3/9s0 9h1 8s2 Tc2 Jc4/2h0 3d0 5s0 6c0 7c4",
            "win": -46,
            "playerId": "pid160696"
        },
        {
            "inFantasy": false,
            "result": -46,
            "playerName": "pid711257",
            "orderIndex": 2,
            "hero": true,
            "dead": "7h1 9c2 Kc3 8d4",
            "rows": "Ks1 8c2 Kh2/3c0 Qc0 3s1 Jh3 Td4/2d0 7d0 Jd0 5d3 9d4",
            "win": -46,
            "playerId": "pid711257"
        },
        {
            "inFantasy": true,
            "result": 92,
            "playerName": "pid907066",
            "orderIndex": 0,
            "hero": false,
            "dead": "Js0 5c1 2c2",
            "rows": "Ah0 Ad0 Ac0/3h0 5h0 6h0 8h0 Th0/4h0 4d0 4c0 4s0 Qs0",
            "win": 90,
            "playerId": "pid907066"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:55:26",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-53": [
        {
            "inFantasy": false,
            "result": -48,
            "playerName": "pid160696",
            "orderIndex": 0,
            "hero": false,
            "dead": "5c1 Ac2 5d3 Jh4",
            "rows": "Ah0 Ad1 Kh2/2c0 4d0 2d2 4h3 Jc3/6h0 6d0 Td1 3d4 8c4",
            "win": -48,
            "playerId": "pid160696"
        },
        {
            "inFantasy": false,
            "result": -4,
            "playerName": "pid711257",
            "orderIndex": 1,
            "hero": true,
            "dead": "Ts1 Th2 9h3 Ks4",
            "rows": "Qs0 As3 Qc4/Jd0 9c1 Kd1 Js2 9d3/4c0 5h0 6c0 8h2 7d4",
            "win": -4,
            "playerId": "pid711257"
        },
        {
            "inFantasy": true,
            "result": 52,
            "playerName": "pid907066",
            "orderIndex": 2,
            "hero": false,
            "dead": "8d0 3h1 2h2",
            "rows": "9s0 Tc0 Kc0/7h0 7c0 7s0 Qh0 Qd0/2s0 3s0 4s0 5s0 6s0",
            "win": 50.44,
            "playerId": "pid907066"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:57:00",
    "roomId": "21176421"
}


{
    "stakes": 1,
    "handData": {"21176421-54": [
        {
            "inFantasy": false,
            "result": -39,
            "playerName": "pid160696",
            "orderIndex": 2,
            "hero": false,
            "dead": "Qs1 4s2 7h3 9c4",
            "rows": "Ac1 5d2 Qd3/7d0 9d0 Tc1 8h2 Th3/3h0 3d0 Js0 2h4 5s4",
            "win": -30.02,
            "playerId": "pid160696"
        },
        {
            "inFantasy": true,
            "result": 10,
            "playerName": "pid711257",
            "orderIndex": 0,
            "hero": true,
            "dead": "3s0",
            "rows": "7c0 Ts0 Ah0/4h0 5h0 6d0 7s0 8c0/2d0 2c0 Kh0 Kd0 Kc0",
            "win": 9.7,
            "playerId": "pid711257"
        },
        {
            "inFantasy": true,
            "result": 29,
            "playerName": "pid907066",
            "orderIndex": 1,
            "hero": false,
            "dead": "8s0 8d1 6c2",
            "rows": "Qh0 Qc0 Ks0/2s0 3c0 4d0 5c0 6h0/9h0 9s0 Jh0 Jd0 Jc0",
            "win": 19.41,
            "playerId": "pid907066"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 08:58:15",
    "roomId": "21176421"
}


