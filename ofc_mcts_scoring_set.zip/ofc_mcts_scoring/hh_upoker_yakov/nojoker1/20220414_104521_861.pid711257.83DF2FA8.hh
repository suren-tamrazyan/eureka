{
    "stakes": 1,
    "handData": {"21176137-1": [
        {
            "inFantasy": false,
            "result": 15,
            "playerName": "pid920703",
            "orderIndex": 1,
            "hero": false,
            "dead": "7h1 7s2 5h3 4d4",
            "rows": "As1 Ac3 5d4/2s0 6h0 6d0 3d2 2d4/8h0 Ts0 8d1 Jd2 8c3",
            "win": 14.55,
            "playerId": "pid920703"
        },
        {
            "inFantasy": false,
            "result": -15,
            "playerName": "pid711257",
            "orderIndex": 0,
            "hero": true,
            "dead": "3c1 8s2 Kc3 7c4",
            "rows": "Kh0 Ah3 Ad3/9s0 3s1 9c1 Js2 Ks4/6c0 6s0 Qd0 Qs2 Tc4",
            "win": -15,
            "playerId": "pid711257"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 07:45:21",
    "roomId": "21176137"
}


{
    "stakes": 1,
    "handData": {"21176137-2": [
        {
            "inFantasy": true,
            "result": 25,
            "playerName": "pid920703",
            "orderIndex": 0,
            "hero": false,
            "dead": "4s0 2s1 2h2",
            "rows": "7d0 Th0 Tc0/3c0 4c0 5c0 6c0 Ac0/9h0 9d0 Jh0 Jd0 Js0",
            "win": 24.25,
            "playerId": "pid920703"
        },
        {
            "inFantasy": false,
            "result": -25,
            "playerName": "pid711257",
            "orderIndex": 1,
            "hero": true,
            "dead": "Qs1 Ad2 Kc3 2d4",
            "rows": "As0 Ah1 7h4/6h0 6s0 8c2 5h3 2c4/9c0 9s0 Qc1 Kh2 Kd3",
            "win": -25,
            "playerId": "pid711257"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 07:46:04",
    "roomId": "21176137"
}


{
    "stakes": 1,
    "handData": {"21176137-3": [
        {
            "inFantasy": false,
            "result": -12,
            "playerName": "pid920703",
            "orderIndex": 1,
            "hero": false,
            "dead": "5d1 5s2 6c3 5h4",
            "rows": "Ah0 As2 Tc3/2h0 3d0 4h0 2s2 4d4/9s0 Js1 Qs1 7s3 Qc4",
            "win": -12,
            "playerId": "pid920703"
        },
        {
            "inFantasy": false,
            "result": 12,
            "playerName": "pid711257",
            "orderIndex": 0,
            "hero": true,
            "dead": "5c1 6h2 Kd3 2d4",
            "rows": "Qd0 7h4 Th4/6d0 Jh2 Jc2 8h3 8d3/3h0 3s0 8s0 3c1 8c1",
            "win": 11.64,
            "playerId": "pid711257"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 07:46:50",
    "roomId": "21176137"
}


{
    "stakes": 1,
    "handData": {"21176137-4": [
        {
            "inFantasy": false,
            "result": -19,
            "playerName": "pid920703",
            "orderIndex": 0,
            "hero": false,
            "dead": "5h1 6d2 3d3 9s4",
            "rows": "Kc0 Ks2 Ts3/8c0 Qd1 Qc1 6c2 Jc4/3h0 6h0 Jh0 4h3 7h4",
            "win": -19,
            "playerId": "pid920703"
        },
        {
            "inFantasy": false,
            "result": 19,
            "playerName": "pid711257",
            "orderIndex": 1,
            "hero": true,
            "dead": "7c1 6s2 2c3 5c4",
            "rows": "Ad1 Ac2 Jd4/3c0 4c0 9h0 4s2 4d3/Js0 Qs0 Th1 Ah3 Kd4",
            "win": 18.43,
            "playerId": "pid711257"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 07:47:57",
    "roomId": "21176137"
}


{
    "stakes": 1,
    "handData": {"21176137-5": [
        {
            "inFantasy": false,
            "result": -30,
            "playerName": "pid920703",
            "orderIndex": 1,
            "hero": false,
            "dead": "Jh1 Js2 Qc3 4s4",
            "rows": "Ah0 Ks3 8c4/6s0 2h1 6c1 8h2 2c3/7d0 7s0 Th0 9d2 7c4",
            "win": -30,
            "playerId": "pid920703"
        },
        {
            "inFantasy": true,
            "result": 30,
            "playerName": "pid711257",
            "orderIndex": 0,
            "hero": true,
            "dead": "As0 3c0 3d0",
            "rows": "4h0 4d0 4c0/3h0 5h0 7h0 9h0 Kh0/5d0 8d0 Jd0 Qd0 Kd0",
            "win": 29.1,
            "playerId": "pid711257"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 07:48:29",
    "roomId": "21176137"
}


{
    "stakes": 1,
    "handData": {"21176137-6": [
        {
            "inFantasy": false,
            "result": -34,
            "playerName": "pid920703",
            "orderIndex": 0,
            "hero": false,
            "dead": "Jh1 5d2 5c3 2h4",
            "rows": "Ac0 As1 8d4/5s0 6d0 5h2 7d2 3d4/4d0 4s0 4h1 Th3 Ts3",
            "win": -34,
            "playerId": "pid920703"
        },
        {
            "inFantasy": true,
            "result": 34,
            "playerName": "pid711257",
            "orderIndex": 1,
            "hero": true,
            "dead": "Ah0 Jd0 2d0",
            "rows": "8h0 8c0 8s0/2s0 3s0 6s0 7s0 Qs0/7c0 Tc0 Jc0 Qc0 Kc0",
            "win": 32.98,
            "playerId": "pid711257"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 07:48:54",
    "roomId": "21176137"
}


{
    "stakes": 1,
    "handData": {"21176137-7": [
        {
            "inFantasy": false,
            "result": -33,
            "playerName": "pid920703",
            "orderIndex": 1,
            "hero": false,
            "dead": "6s1 6c2 8d3 6h4",
            "rows": "Kh1 Ks2 8c3/2c0 3c0 7s0 9c4 Tc4/5h0 5c0 Ts1 Js2 Jh3",
            "win": -33,
            "playerId": "pid920703"
        },
        {
            "inFantasy": true,
            "result": 33,
            "playerName": "pid711257",
            "orderIndex": 0,
            "hero": true,
            "dead": "Td0 8h0 2s0",
            "rows": "Kc0 Ah0 Ac0/3h0 3d0 3s0 7h0 7d0/4h0 4d0 4c0 9h0 9s0",
            "win": 32.01,
            "playerId": "pid711257"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 07:49:21",
    "roomId": "21176137"
}


{
    "stakes": 1,
    "handData": {"21176137-8": [
        {
            "inFantasy": false,
            "result": -17,
            "playerName": "pid920703",
            "orderIndex": 0,
            "hero": false,
            "dead": "9c1 7s2 6c3 9s4",
            "rows": "3d2 7d3 Kd3/2c0 5h0 4d1 4s1 Ac4/8d0 Td0 Qc0 Tc2 8c4",
            "win": -17,
            "playerId": "pid920703"
        },
        {
            "inFantasy": false,
            "result": 17,
            "playerName": "pid711257",
            "orderIndex": 1,
            "hero": true,
            "dead": "Jh1 2d2 Ts3 6d4",
            "rows": "Ah0 Ad0 2h3/7c0 7h1 Kc2 Jd4 Js4/8s0 Th0 Jc1 Qs2 9d3",
            "win": 16.49,
            "playerId": "pid711257"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 07:50:20",
    "roomId": "21176137"
}


{
    "stakes": 1,
    "handData": {"21176137-9": [
        {
            "inFantasy": false,
            "result": 4,
            "playerName": "pid920703",
            "orderIndex": 1,
            "hero": false,
            "dead": "2h1 2s2 Qh3 Jd4",
            "rows": "As0 5h2 Ah4/6h0 Ts0 8c1 7s3 9c4/Kh0 Kc0 4d1 4h2 4c3",
            "win": 3.88,
            "playerId": "pid920703"
        },
        {
            "inFantasy": true,
            "result": -4,
            "playerName": "pid711257",
            "orderIndex": 0,
            "hero": true,
            "dead": "5s0 3h0 2c0",
            "rows": "Qc0 Ad0 Ac0/6c0 7c0 8d0 9d0 Th0/8h0 9s0 Td0 Jc0 Qd0",
            "win": -4,
            "playerId": "pid711257"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 07:50:46",
    "roomId": "21176137"
}


{
    "stakes": 1,
    "handData": {"21176137-10": [
        {
            "inFantasy": true,
            "result": 11,
            "playerName": "pid920703",
            "orderIndex": 0,
            "hero": false,
            "dead": "5d0 4c1 2s2",
            "rows": "Jh0 Jc0 Qd0/6d0 7h0 8d0 9h0 Th0/4s0 6s0 9s0 Ts0 Ks0",
            "win": 10.67,
            "playerId": "pid920703"
        },
        {
            "inFantasy": false,
            "result": -11,
            "playerName": "pid711257",
            "orderIndex": 1,
            "hero": true,
            "dead": "3s1 Qc2 Td3 2c4",
            "rows": "Tc1 Qh3 9d4/5h0 8s0 7c1 4h3 7d4/3d0 Jd0 Kd0 2d2 Ad2",
            "win": -11,
            "playerId": "pid711257"
        }
    ]},
    "appName": "Upoker",
    "price": "1USD",
    "joined": true,
    "clubId": "14115",
    "rules": "progressive17_nojokers",
    "endDateTime": "2022-04-14 07:51:34",
    "roomId": "21176137"
}


